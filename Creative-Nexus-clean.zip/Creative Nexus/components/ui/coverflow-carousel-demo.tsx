import CoverflowCarousel from "@/components/ui/coverflow-carousel";

const items = [
  {
    id: "1",
    image:
      "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&auto=format&fit=crop&q=80",
    alt: "Mountain lake at sunrise",
  },
  {
    id: "2",
    image:
      "https://images.unsplash.com/photo-1448375240586-882707db888b?w=800&auto=format&fit=crop&q=80",
    alt: "Forest path",
  },
  {
    id: "3",
    image:
      "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=800&auto=format&fit=crop&q=80",
    alt: "Desert dunes",
  },
  {
    id: "4",
    image:
      "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800&auto=format&fit=crop&q=80",
    alt: "Coastal cliffs",
  },
  {
    id: "5",
    image:
      "https://images.unsplash.com/photo-1426604966848-d7adac402bff?w=800&auto=format&fit=crop&q=80",
    alt: "Valley overlook",
  },
];

export default function CoverflowCarouselDemo() {
  return (
    <div className="flex w-full items-center justify-center py-10">
      <CoverflowCarousel items={items} loop />
    </div>
  );
}
