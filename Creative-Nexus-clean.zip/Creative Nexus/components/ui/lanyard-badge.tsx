"use client"

import * as React from "react"

/**
 * Lanyard Badge — an event badge hanging from a patterned lanyard.
 *
 * Two strands come down from above the frame and meet at a side-release
 * buckle; a short strap, a split ring and a metal swivel clasp hold the card.
 * The strap is a verlet rope drawn as a textured ribbon on a 2D canvas.
 * The card is real HTML turned in 3D with CSS, so both faces can hold anything.
 *
 * Drag the card and the strap pulls taut; flick it sideways and it spins on
 * the ring; tap it (or press Enter) to flip it over.
 */

export interface LanyardBadgeProps {
  key?: React.Key
  /** Card front. Replaces the built-in front entirely. */
  front?: React.ReactNode
  /** Card back. Replaces the built-in back entirely. */
  back?: React.ReactNode
  /** Built-in front: the event / card title. */
  title?: string
  /** Built-in front: the line under the title. */
  subtitle?: string
  /** Built-in back: the wearer's / card's name. */
  name?: string
  /** Built-in back: the wearer's role / card rarity. */
  role?: string
  /** Optional card portrait / artwork URL */
  imageUrl?: string
  /** Optional lore backstory for the back face */
  lore?: string
  /** Optional stats line for the back face */
  statsLine?: string
  /** Script line printed along the strap. */
  strapText?: string
  /** Condensed label printed along the strap, between the script lines. */
  strapLabel?: string
  /** Strap colour, #rrggbb. */
  strapColor?: string
  /** Ornament and print colour, on the strap and the built-in card. */
  inkColor?: string
  /** Built-in card stock colour. */
  cardColor?: string
  /** Show the "Show back / Show front" button in the top corner. */
  flipButton?: boolean
  /** Card width in px. Height follows at 3:2, strap width at a tenth. */
  cardWidth?: number
  /** Root height. A definite length — never a percentage. */
  height?: string
  /** Extra root class names. */
  className?: string
}

// #region physics
export type Pt = { x: number; y: number; px: number; py: number; w: number }
export type Link = [number, number, number]
export type Spin = { a: number; v: number }

/** Verlet step. `w` is inverse mass; 0 pins a point in place. */
export function integrate(pts: Pt[], dt: number, gravity: number, damping: number) {
  for (const p of pts) {
    if (!p.w) continue
    const vx = (p.x - p.px) * damping
    const vy = (p.y - p.py) * damping
    p.px = p.x
    p.py = p.y
    p.x += vx
    p.y += vy + gravity * dt * dt
  }
}

/** Relax distance constraints, heavier points moving less. */
export function solve(pts: Pt[], links: Link[], iterations: number) {
  for (let k = 0; k < iterations; k++) {
    for (const [i, j, rest] of links) {
      const a = pts[i]
      const b = pts[j]
      const ws = a.w + b.w
      if (!ws) continue
      const dx = b.x - a.x
      const dy = b.y - a.y
      const d = Math.hypot(dx, dy) || 1e-6
      const f = (d - rest) / (d * ws)
      a.x += dx * f * a.w
      a.y += dy * f * a.w
      b.x -= dx * f * b.w
      b.y -= dy * f * b.w
    }
  }
}

/**
 * The card's turn on the ring. The strap's own twist is the spring pulling it
 * back to `target`; `drive` is whatever is twisting it right now.
 */
export function spinStep(s: Spin, target: number, dt: number, drive: number) {
  s.v += (-(s.a - target) * 18 - s.v * 3.2 + drive) * dt
  s.a += s.v * dt
}

/** How far the card swings from hanging straight down, in radians. Right is positive. */
export function swingAngle(top: Pt, bottom: Pt) {
  return Math.atan2(bottom.x - top.x, bottom.y - top.y)
}
// #endregion

const DISPLAY = '"Oswald", "Bebas Neue", "Arial Narrow", Impact, sans-serif'
const SCRIPT = '"Segoe Script", "Brush Script MT", "Snell Roundhand", cursive'

/** A mandala: rings, petals, a bead circle and a flower in the middle. */
function drawMandala(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number) {
  ctx.save()
  ctx.translate(cx, cy)
  ctx.lineWidth = Math.max(0.8, r * 0.018)
  for (const k of [1, 0.9, 0.62, 0.26]) {
    ctx.beginPath()
    ctx.arc(0, 0, r * k, 0, Math.PI * 2)
    ctx.stroke()
  }
  for (let i = 0; i < 16; i++) {
    ctx.save()
    ctx.rotate((i / 16) * Math.PI * 2)
    ctx.beginPath()
    ctx.ellipse(0, -r * 0.76, r * 0.07, r * 0.13, 0, 0, Math.PI * 2)
    ctx.stroke()
    ctx.rotate(Math.PI / 16)
    ctx.beginPath()
    ctx.arc(0, -r * 0.95, r * 0.018, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()
  }
  for (let i = 0; i < 8; i++) {
    ctx.save()
    ctx.rotate((i / 8) * Math.PI * 2)
    ctx.beginPath()
    ctx.moveTo(0, -r * 0.26)
    ctx.bezierCurveTo(r * 0.12, -r * 0.4, r * 0.1, -r * 0.52, 0, -r * 0.6)
    ctx.bezierCurveTo(-r * 0.1, -r * 0.52, -r * 0.12, -r * 0.4, 0, -r * 0.26)
    ctx.stroke()
    ctx.restore()
  }
  ctx.beginPath()
  ctx.arc(0, 0, r * 0.07, 0, Math.PI * 2)
  ctx.fill()
  ctx.restore()
}

/**
 * The printed strap, `length` css px long, laid out along the canvas height so
 * each rope segment can crop its own slice. Returns a canvas in device px.
 */
function makeStrap(
  length: number,
  width: number,
  dpr: number,
  opts: { color: string; ink: string; text: string; label: string; plain?: boolean },
) {
  const c = document.createElement("canvas")
  c.width = Math.max(1, Math.round(width * dpr))
  c.height = Math.max(1, Math.round(length * dpr))
  const ctx = c.getContext("2d")
  if (!ctx) return c
  // strap space: x runs down the strap, y runs across it
  ctx.setTransform(0, dpr, -dpr, 0, c.width, 0)
  ctx.fillStyle = opts.color
  ctx.fillRect(0, 0, length, width)
  ctx.strokeStyle = ctx.fillStyle = opts.ink

  if (!opts.plain) {
    ctx.save()
    ctx.beginPath()
    ctx.rect(0, 0, length, width)
    ctx.clip()
    ctx.textBaseline = "middle"
    const scriptFont = "400 " + Math.round(width * 0.5) + "px " + SCRIPT
    const labelFont = "700 " + Math.round(width * 0.36) + "px " + DISPLAY
    ctx.font = scriptFont
    const scriptW = ctx.measureText(opts.text).width
    ctx.font = labelFont
    const labelW = ctx.measureText(opts.label).width
    const gap = width * 0.6
    let x = width * 0.4
    let flip = 1
    while (x < length) {
      // a mandala too big for the strap, so only an arc of it shows
      ctx.globalAlpha = 0.55
      drawMandala(ctx, x + width * 1.3, width * (0.5 + flip * 0.28), width * 1.35)
      x += width * 2.8
      ctx.globalAlpha = 0.95
      ctx.font = scriptFont
      ctx.fillText(opts.text, x, width * 0.52)
      x += scriptW + gap
      if (opts.label) {
        ctx.font = labelFont
        ctx.fillText("-  " + opts.label + "  -", x, width * 0.53)
        x += labelW + ctx.measureText("-    -").width + gap
      }
      flip = -flip
    }
    ctx.restore()
  }

  // woven edges catch a little light
  ctx.globalAlpha = 0.35
  ctx.lineWidth = 1
  ctx.beginPath()
  ctx.moveTo(0, 1.5)
  ctx.lineTo(length, 1.5)
  ctx.moveTo(0, width - 1.5)
  ctx.lineTo(length, width - 1.5)
  ctx.stroke()
  return c
}

function usePrefersReducedMotion() {
  const [reduced, setReduced] = React.useState(false)
  React.useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)")
    setReduced(mq.matches)
    const h = (e: MediaQueryListEvent) => setReduced(e.matches)
    mq.addEventListener("change", h)
    return () => mq.removeEventListener("change", h)
  }, [])
  return reduced
}

function Ornament({ className = "", style }: { className?: string; style?: React.CSSProperties }) {
  const ring = Array.from({ length: 16 }, (_, i) => i * 22.5)
  return (
    <svg viewBox="-100 -100 200 200" fill="none" stroke="currentColor" strokeWidth={1.4} className={className} style={style} aria-hidden="true">
      <circle r={96} />
      <circle r={86} />
      <circle r={60} />
      <circle r={25} />
      {ring.map((a) => (
        <ellipse key={a} cx={0} cy={-73} rx={6.5} ry={12} transform={"rotate(" + a + ")"} />
      ))}
      {ring.map((a) => (
        <circle key={"d" + a} cx={0} cy={-91} r={1.8} fill="currentColor" transform={"rotate(" + (a + 11.25) + ")"} />
      ))}
      {ring.slice(0, 8).map((_, i) => (
        <path key={"p" + i} d="M0 -25 C 12 -38, 10 -50, 0 -58 C -10 -50, -12 -38, 0 -25" transform={"rotate(" + i * 45 + ")"} />
      ))}
      <circle r={6} fill="currentColor" />
    </svg>
  )
}

function Arrow({ className = "", style }: { className?: string; style?: React.CSSProperties }) {
  return (
    <svg viewBox="0 0 20 200" fill="none" stroke="currentColor" strokeWidth={1.4} className={className} style={style} aria-hidden="true">
      <path d="M10 4 L10 196 M3 18 L10 4 L17 18 M4 182 L10 170 L16 182 M4 194 L10 182 L16 194" />
    </svg>
  )
}

export default function LanyardBadge({
  front,
  back,
  title = "The Future Is Handmade",
  subtitle = "Design Week · Vol. 2 · 2026",
  name = "Alex Morgan",
  role = "Documentation",
  imageUrl,
  lore,
  statsLine,
  strapText = "the future is handmade",
  strapLabel = "DESIGN WEEK 2026",
  strapColor = "#141312",
  inkColor = "#b59a6c",
  cardColor = "#e8dfcc",
  flipButton = true,
  cardWidth = 260,
  height = "100%",
  className = "",
}: LanyardBadgeProps) {
  const rootRef = React.useRef<HTMLElement | null>(null)
  const canvasRef = React.useRef<HTMLCanvasElement | null>(null)
  const cardRef = React.useRef<HTMLDivElement | null>(null)
  const innerRef = React.useRef<HTMLDivElement | null>(null)
  const reduced = usePrefersReducedMotion()
  const flipRef = React.useRef<() => void>(() => {})
  
  // which face is turned toward the viewer
  const [showBack, setShowBack] = React.useState(false)
  const backRef = React.useRef(showBack)
  backRef.current = showBack

  const cw = cardWidth
  const ch = Math.round(cardWidth * 1.5)
  const ringR = Math.max(7, Math.round(cw * 0.036))
  const clipH = Math.round(cw * 0.1)

  const look = React.useRef({ strapText, strapLabel, strapColor, inkColor })
  look.current = { strapText, strapLabel, strapColor, inkColor }

  // Callback to update canvas textures without recreating the physics simulation
  const updateTexturesRef = React.useRef<(() => void) | null>(null)

  React.useEffect(() => {
    if (updateTexturesRef.current) {
      updateTexturesRef.current()
    }
  }, [strapText, strapLabel, strapColor, inkColor])

  React.useEffect(() => {
    const root = rootRef.current
    const canvas = canvasRef.current
    const card = cardRef.current
    const inner = innerRef.current
    const ctx = canvas?.getContext("2d")
    if (!root || !canvas || !card || !inner || !ctx) return

    const sw = Math.max(14, Math.round(cw * 0.1)) // strap width
    const lowLen = sw * 2.2 // buckle to ring
    const arm = ringR * 2 + clipH + ch * 0.55 // ring to card's center of mass
    const N = 14

    let pts: Pt[] = []
    let links: Link[] = []
    let left: number[] = []
    let right: number[] = []
    let low: number[] = []
    let iB = 0
    let iT = 0
    let iC = 0
    let strandRest = 1
    let dpr = 1
    let W = 1
    let H = 1
    let strapTex: HTMLCanvasElement | null = null
    let plainTex: HTMLCanvasElement | null = null
    const spin: Spin = { a: 0, v: 0 }
    let spinTarget = backRef.current ? Math.PI : 0
    spin.a = spinTarget
    let smoothSwing = 0

    const add = (x: number, y: number, w: number) => {
      pts.push({ x, y, px: x, py: y, w })
      return pts.length - 1
    }
    const strand = (from: number, to: number, n: number, slack: number) => {
      const a = pts[from]
      const b = pts[to]
      const rest = (Math.hypot(b.x - a.x, b.y - a.y) * slack) / n
      const ids = [from]
      for (let i = 1; i < n; i++) ids.push(add(a.x + ((b.x - a.x) * i) / n, a.y + ((b.y - a.y) * i) / n, 1))
      ids.push(to)
      for (let i = 0; i < n; i++) links.push([ids[i], ids[i + 1], rest])
      return { ids, rest }
    }

    const refreshTextures = () => {
      const c = look.current
      const opts = { color: c.strapColor, ink: c.inkColor, text: c.strapText, label: c.strapLabel }
      strapTex = makeStrap(strandRest * N + 4, sw, dpr, opts)
      plainTex = makeStrap(lowLen + 4, sw * 0.8, dpr, { ...opts, plain: true })
    }
    updateTexturesRef.current = refreshTextures

    const build = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2)
      W = Math.max(1, root.clientWidth)
      H = Math.max(1, root.clientHeight)
      canvas.width = Math.round(W * dpr)
      canvas.height = Math.round(H * dpr)

      pts = []
      links = []
      const cx = W / 2
      const spread = Math.min(W * 0.16, cw * 0.55)
      const top = -sw * 2
      const bY = Math.max(H * 0.16, Math.min(H * 0.42, H - (lowLen + ringR * 2 + clipH + ch) - 28))

      const aL = add(cx - spread, top, 0)
      iB = add(cx, bY, 1.4)
      const l = strand(aL, iB, N, 1.03)
      const aR = add(cx + spread, top, 0)
      const r = strand(aR, iB, N, 1.03)
      iT = add(cx, bY + lowLen, 0.8)
      const lo = strand(iB, iT, 3, 1)
      iC = add(cx, bY + lowLen + arm, 0.25)
      links.push([iT, iC, arm])
      left = l.ids
      right = r.ids
      low = lo.ids
      strandRest = l.rest

      refreshTextures()

      if (reduced) {
        for (let i = 0; i < 600; i++) {
          integrate(pts, STEP, GRAVITY, 0.98)
          solve(pts, links, ITER)
        }
      } else {
        // graceful initial entrance swing
        pts[iC].x += cw * 0.35
        pts[iC].px = pts[iC].x - 1.5
        spin.v = 2.5
      }
    }

    const STEP = 1 / 120
    const GRAVITY = 2400
    const ITER = 18

    // ---- drawing ---------------------------------------------------------
    const ribbon = (ids: number[], tex: HTMLCanvasElement, rest: number, light: number) => {
      const Wt = tex.width
      for (let i = 0; i < ids.length - 1; i++) {
        const a = pts[ids[i]]
        const b = pts[ids[i + 1]]
        const dx = (b.x - a.x) * dpr
        const dy = (b.y - a.y) * dpr
        const len = Math.hypot(dx, dy) || 1e-6
        const tx = dx / len
        const ty = dy / len
        const nx = ty
        const ny = -tx
        const v0 = i * rest * dpr
        const dv = rest * dpr
        const k = len / dv
        ctx.setTransform(nx, ny, tx * k, ty * k, a.x * dpr - (nx * Wt) / 2 - tx * k * v0, a.y * dpr - (ny * Wt) / 2 - ty * k * v0)
        const src = Math.min(dv + 1.5, tex.height - v0)
        if (src > 0) ctx.drawImage(tex, 0, v0, Wt, src, 0, v0, Wt, src)
        const shade = 0.22 * (1 - Math.max(0, nx * light))
        ctx.fillStyle = "rgba(0,0,0," + shade.toFixed(3) + ")"
        ctx.fillRect(0, v0, Wt, dv + 1)
      }
    }

    const metal = (x0: number, y0: number, x1: number, y1: number) => {
      const g = ctx.createLinearGradient(x0, y0, x1, y1)
      g.addColorStop(0, "#f4efe4")
      g.addColorStop(0.45, "#b9b0a0")
      g.addColorStop(0.55, "#8f8778")
      g.addColorStop(1, "#ece6da")
      return g
    }

    const draw = () => {
      ctx.setTransform(1, 0, 0, 1, 0, 0)
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      if (!strapTex || !plainTex) return
      ctx.imageSmoothingEnabled = true
      ribbon(left, strapTex, strandRest, -1)
      ribbon(right, strapTex, strandRest, 1)
      ribbon(low, plainTex, (lowLen * 1) / 3, 0)

      // side-release buckle, turned to follow the short strap
      const B = pts[iB]
      const T = pts[iT]
      const ang = Math.atan2(T.x - B.x, T.y - B.y)
      const u = sw / 20
      ctx.setTransform(dpr, 0, 0, dpr, B.x * dpr, B.y * dpr)
      ctx.rotate(-ang)
      ctx.shadowColor = "rgba(0,0,0,0.3)"
      ctx.shadowBlur = 6 * dpr
      ctx.shadowOffsetY = 2 * dpr
      ctx.fillStyle = metal(-16 * u, 0, 16 * u, 0)
      ctx.beginPath()
      ctx.roundRect(-15 * u, -14 * u, 30 * u, 17 * u, 3 * u)
      ctx.fill()
      ctx.beginPath()
      ctx.roundRect(-11 * u, 1 * u, 22 * u, 15 * u, [2 * u, 2 * u, 6 * u, 6 * u])
      ctx.fill()
      ctx.shadowColor = "transparent"
      ctx.fillStyle = "rgba(40,36,30,0.55)"
      ctx.fillRect(-10 * u, -9 * u, 20 * u, 2.2 * u)
      ctx.fillRect(-5 * u, 6 * u, 10 * u, 3 * u)
      ctx.strokeStyle = "rgba(255,255,255,0.6)"
      ctx.lineWidth = 0.8 * u
      ctx.beginPath()
      ctx.moveTo(-13 * u, -12.5 * u)
      ctx.lineTo(13 * u, -12.5 * u)
      ctx.stroke()

      // split ring directly at T connecting the lower strap
      ctx.setTransform(dpr, 0, 0, dpr, T.x * dpr, (T.y + ringR * 0.8) * dpr)
      ctx.lineWidth = Math.max(2.5, ringR * 0.38)
      ctx.strokeStyle = metal(-ringR, -ringR, ringR, ringR)
      ctx.beginPath()
      ctx.arc(0, 0, ringR, 0, Math.PI * 2)
      ctx.stroke()
    }

    const place = () => {
      const T = pts[iT]
      const C = pts[iC]
      let rawSwing = swingAngle(T, C)
      if (isNaN(rawSwing)) rawSwing = 0
      // Clamp swing to prevent unnatural flipping
      rawSwing = Math.max(-1.15, Math.min(1.15, rawSwing))
      smoothSwing += (rawSwing - smoothSwing) * 0.22

      // Position card top center exactly at the ring center so clip connects seamlessly
      card.style.transform =
        "translate3d(" + (T.x - cw / 2).toFixed(2) + "px," + (T.y + ringR * 0.8).toFixed(2) + "px,0) rotate(" + (-smoothSwing).toFixed(4) + "rad)"
      inner.style.transform = "perspective(1100px) rotateY(" + spin.a.toFixed(4) + "rad)"
      const edge = 1 - Math.abs(Math.cos(spin.a))
      inner.style.setProperty("--lyd-dim", (edge * 0.5).toFixed(3))
      inner.style.setProperty("--lyd-shine", (50 + Math.sin(spin.a) * 70 + smoothSwing * 90).toFixed(1) + "%")
    }

    // ---- interaction -----------------------------------------------------
    type Drag = { 
      id: number; 
      ox: number; 
      oy: number; 
      tx: number; 
      ty: number; 
      sx: number; 
      sy: number; 
      moved: boolean;
      vx: number;
      vy: number;
      lastX: number;
      lastY: number;
    }
    let drag: Drag | null = null

    const local = (e: PointerEvent) => {
      const r = root.getBoundingClientRect()
      return [e.clientX - r.left, e.clientY - r.top]
    }
    const flip = () => {
      spinTarget = spinTarget === 0 ? Math.PI : 0
      setShowBack(spinTarget !== 0)
    }
    flipRef.current = flip

    const onDown = (e: PointerEvent) => {
      if (e.button > 0) return
      const [x, y] = local(e)
      const T = pts[iT]
      drag = { 
        id: e.pointerId, 
        ox: T.x - x, 
        oy: T.y - y, 
        tx: T.x, 
        ty: T.y, 
        sx: x, 
        sy: y, 
        moved: false,
        vx: 0,
        vy: 0,
        lastX: x,
        lastY: y
      }
      pts[iT].w = 0
      try {
        card.setPointerCapture(e.pointerId)
      } catch {}
      card.style.cursor = "grabbing"
    }

    const onMove = (e: PointerEvent) => {
      if (!drag || e.pointerId !== drag.id) return
      const [x, y] = local(e)
      drag.vx = x - drag.lastX
      drag.vy = y - drag.lastY
      drag.lastX = x
      drag.lastY = y
      drag.tx = x + drag.ox
      drag.ty = y + drag.oy
      if (Math.hypot(x - drag.sx, y - drag.sy) > 8) drag.moved = true
    }

    const onUp = (e: PointerEvent) => {
      if (!drag || e.pointerId !== drag.id) return
      if (!drag.moved) {
        flip()
      } else {
        // Impart natural throw momentum onto the card!
        const T = pts[iT]
        const C = pts[iC]
        const throwImpulse = Math.min(22, Math.max(-22, drag.vx)) * 1.4
        T.px = T.x - throwImpulse
        C.px = C.x - throwImpulse * 1.3
        // Sideways flick imparts spinning force
        spin.v += throwImpulse * 0.05
      }
      try {
        card.releasePointerCapture(e.pointerId)
      } catch {}
      drag = null
      pts[iT].w = 0.8
      card.style.cursor = "grab"
    }

    card.addEventListener("pointerdown", onDown)
    card.addEventListener("pointermove", onMove)
    card.addEventListener("pointerup", onUp)
    card.addEventListener("pointercancel", onUp)

    // ---- loop --------------------------------------------------------------
    let raf = 0
    let acc = 0
    let last = performance.now()
    let t = 0
    const tick = (now: number) => {
      acc += Math.min(0.05, (now - last) / 1000)
      last = now
      let steps = 0
      while (acc >= STEP && steps < 8) {
        acc -= STEP
        steps++
        t += STEP
        if (drag) {
          const T = pts[iT]
          const oldTx = T.x
          const oldTy = T.y
          // Responsive spring-damped tracking
          T.x += (drag.tx - T.x) * 0.28
          T.y += (drag.ty - T.y) * 0.28
          T.px = oldTx
          T.py = oldTy

          // Also guide the card's lower point C to smoothly orient with the drag
          const C = pts[iC]
          const oldCx = C.x
          const oldCy = C.y
          C.x += (T.x + drag.vx * 0.35 - C.x) * 0.14
          C.y += (T.y + arm - C.y) * 0.14
          C.px = oldCx
          C.py = oldCy
        }
        const C = pts[iC]
        if (!reduced && !drag) {
          // a natural subtle atmospheric ambient sway
          C.x += (18 * Math.sin(t * 0.65) + 10 * Math.sin(t * 1.8)) * STEP * STEP
        }
        integrate(pts, STEP, GRAVITY, 0.992)
        solve(pts, links, ITER)
        const vx = (C.x - C.px) / STEP
        spinStep(spin, spinTarget, STEP, reduced ? 0 : vx * 0.003)
      }
      draw()
      place()
      raf = requestAnimationFrame(tick)
    }

    build()
    const ro = new ResizeObserver(build)
    ro.observe(root)
    raf = requestAnimationFrame(tick)

    return () => {
      cancelAnimationFrame(raf)
      ro.disconnect()
      card.removeEventListener("pointerdown", onDown)
      card.removeEventListener("pointermove", onMove)
      card.removeEventListener("pointerup", onUp)
      card.removeEventListener("pointercancel", onUp)
    }
  }, [reduced, cw, ch, ringR, clipH])

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault()
      flipRef.current?.()
    }
  }

  return (
    <div
      ref={rootRef as any}
      className={["relative w-full overflow-hidden select-none touch-none", className].filter(Boolean).join(" ")}
      style={{ height }}
    >
      <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none" />

      {flipButton && (
        <button
          type="button"
          onClick={() => flipRef.current?.()}
          className="absolute top-4 right-4 z-20 px-3.5 py-1.5 rounded-full text-xs font-mono tracking-wider border transition-all cursor-pointer backdrop-blur-md hover:brightness-110 active:scale-95 shadow-md"
          style={{
            color: inkColor,
            borderColor: `${inkColor}40`,
            backgroundColor: `${strapColor}dd`,
          }}
        >
          {showBack ? "Show front" : "Show back"}
        </button>
      )}

      <div
        ref={cardRef}
        tabIndex={0}
        role="button"
        aria-label="Lanyard badge card. Click, drag, or press Enter to flip."
        onKeyDown={onKeyDown}
        className="absolute left-0 top-0 cursor-grab active:cursor-grabbing focus:outline-none touch-none"
        style={{
          width: cw,
          height: ch,
          transformOrigin: "50% 0",
          willChange: "transform",
        }}
      >
        {/* Metal Swivel Clasp Assembly connecting Split Ring directly to Card Slot */}
        <div
          className="absolute left-1/2 -translate-x-1/2 pointer-events-none z-30 flex flex-col items-center select-none"
          style={{
            top: `${-ringR * 1.8}px`,
            width: '28px',
          }}
          aria-hidden="true"
        >
          {/* Top Loop linked over the split ring */}
          <div
            className="w-4 h-4 rounded-full border-2 border-stone-400 shadow-sm"
            style={{
              background: 'linear-gradient(135deg, #f4efe4 0%, #a49b8c 100%)',
              borderColor: 'rgba(50,45,40,0.5)',
            }}
          />
          {/* Swivel Collar */}
          <div
            className="w-2.5 h-1.5 -my-0.5 rounded-[1px] shadow-xs"
            style={{
              background: 'linear-gradient(90deg, #ece6da 0%, #8f8778 50%, #ece6da 100%)',
              border: '1px solid rgba(0,0,0,0.3)',
            }}
          />
          {/* Clasp Body & Jaw pinching into the slot */}
          <div
            className="w-5 h-5 rounded-b-md shadow-sm relative flex items-center justify-center overflow-hidden"
            style={{
              background: 'linear-gradient(180deg, #f4efe4 0%, #b9b0a0 45%, #7a7265 100%)',
              border: '1px solid rgba(0,0,0,0.35)',
            }}
          >
            {/* Clasp hinge rivet */}
            <div className="w-1.5 h-1.5 rounded-full bg-stone-700/80 border border-stone-300/50" />
            {/* Clasp spring jaw that hooks through the slot */}
            <div className="absolute -bottom-1 inset-x-1 h-2 bg-stone-800/90 rounded-b-sm border-t border-black/40" />
          </div>
        </div>

        <div
          ref={innerRef}
          className="relative w-full h-full rounded-2xl shadow-2xl overflow-hidden border border-black/10"
          style={{
            transformStyle: "preserve-3d",
            willChange: "transform",
          }}
        >
          {/* Front Face */}
          <div
            className={`absolute inset-0 rounded-2xl overflow-hidden ${front ? 'p-0' : 'p-6'} flex flex-col justify-between`}
            style={{
              backfaceVisibility: "hidden",
              WebkitBackfaceVisibility: "hidden",
              backgroundColor: cardColor,
              color: inkColor,
              transform: "rotateY(0deg)",
            }}
          >
            {/* Shading & shine overlay */}
            <div
              className="absolute inset-0 pointer-events-none transition-opacity z-30"
              style={{
                background:
                  "linear-gradient(calc(var(--lyd-shine, 50%) * 3.6deg), rgba(255,255,255,0.35) 0%, transparent 40%, rgba(0,0,0,var(--lyd-dim, 0)) 100%)",
              }}
            />

            {/* Slotted punched hole with clip jaw visible */}
            <div
              className="mx-auto w-9 h-2.5 rounded-full mt-2.5 mb-1 z-20 shrink-0 border border-black/40 shadow-inner flex items-center justify-center overflow-hidden"
              style={{ 
                backgroundColor: 'rgba(0, 0, 0, 0.85)',
                boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.9), 0 1px 0 rgba(255,255,255,0.15)'
              }}
            >
              <div 
                className="w-3.5 h-full opacity-90"
                style={{
                  background: 'linear-gradient(180deg, #8f8778 0%, #50493f 100%)'
                }}
              />
            </div>

            {front ? (
              front
            ) : (
              <div className="relative z-10 flex flex-col justify-between h-full pt-1">
                <div className="flex items-center justify-between border-b pb-2" style={{ borderColor: `${inkColor}30` }}>
                  <span className="font-mono text-[10px] tracking-widest uppercase font-bold">ARCHIVAL PASS</span>
                  <span className="font-mono text-[10px] tracking-widest uppercase font-bold">2026</span>
                </div>

                <div className="my-auto text-center flex flex-col items-center py-2">
                  {imageUrl ? (
                    <div 
                      className="relative w-24 h-24 sm:w-28 sm:h-28 mb-3 rounded-full p-1 border-2 shadow-lg flex items-center justify-center overflow-hidden"
                      style={{ 
                        borderColor: `${inkColor}70`, 
                        backgroundColor: `${inkColor}15`,
                        boxShadow: `0 8px 24px -4px ${inkColor}33`
                      }}
                    >
                      <img 
                        src={imageUrl} 
                        alt={title} 
                        className="w-full h-full rounded-full object-cover object-center filter contrast-105"
                      />
                      <div className="absolute inset-0 rounded-full border border-white/20 pointer-events-none" />
                    </div>
                  ) : (
                    <Ornament className="w-20 h-20 mb-3 opacity-85" style={{ color: inkColor }} />
                  )}
                  <h3
                    className="text-xl sm:text-2xl font-bold tracking-tight leading-tight uppercase max-w-[90%] truncate"
                    style={{ fontFamily: DISPLAY }}
                  >
                    {title}
                  </h3>
                  <p className="text-xs mt-1.5 opacity-80 font-mono tracking-wider max-w-[90%] truncate">{subtitle}</p>
                </div>

                <div className="flex items-end justify-between pt-2.5 border-t" style={{ borderColor: `${inkColor}30` }}>
                  <div className="flex items-center gap-1.5">
                    <Arrow className="w-3 h-8 opacity-60" style={{ color: inkColor }} />
                    <div className="text-[9px] font-mono leading-tight opacity-75">
                      <div>AUTHENTICATED</div>
                      <div>OFFICIAL RELIC</div>
                    </div>
                  </div>
                  <div className="text-[10px] font-mono font-bold tracking-widest">№ 0842</div>
                </div>
              </div>
            )}
          </div>

          {/* Back Face */}
          <div
            className={`absolute inset-0 rounded-2xl overflow-hidden ${back ? 'p-0' : 'p-6'} flex flex-col justify-between`}
            style={{
              backfaceVisibility: "hidden",
              WebkitBackfaceVisibility: "hidden",
              backgroundColor: cardColor,
              color: inkColor,
              transform: "rotateY(180deg)",
            }}
          >
            {/* Shading & shine overlay */}
            <div
              className="absolute inset-0 pointer-events-none transition-opacity z-30"
              style={{
                background:
                  "linear-gradient(calc(var(--lyd-shine, 50%) * 3.6deg), rgba(255,255,255,0.3) 0%, transparent 40%, rgba(0,0,0,var(--lyd-dim, 0)) 100%)",
              }}
            />

            {/* Slotted punched hole */}
            <div
              className="mx-auto w-9 h-2.5 rounded-full mt-2.5 mb-1 z-20 shrink-0 border border-black/40 shadow-inner flex items-center justify-center overflow-hidden"
              style={{ 
                backgroundColor: 'rgba(0, 0, 0, 0.85)',
                boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.9), 0 1px 0 rgba(255,255,255,0.15)'
              }}
            >
              <div 
                className="w-3.5 h-full opacity-90"
                style={{
                  background: 'linear-gradient(180deg, #8f8778 0%, #50493f 100%)'
                }}
              />
            </div>

            {back ? (
              back
            ) : (
              <div className="relative z-10 flex flex-col justify-between h-full pt-1">
                <div className="flex items-center justify-between border-b pb-2" style={{ borderColor: `${inkColor}30` }}>
                  <span className="font-mono text-[10px] tracking-widest uppercase font-bold">DELEGATE DOSSIER</span>
                  <Ornament className="w-4 h-4 opacity-75" style={{ color: inkColor }} />
                </div>

                <div className="my-auto text-center py-2 flex flex-col items-center">
                  <div
                    className="w-16 h-16 rounded-full mx-auto mb-2 border flex items-center justify-center font-bold text-lg overflow-hidden shadow-inner"
                    style={{
                      borderColor: `${inkColor}50`,
                      backgroundColor: `${inkColor}15`,
                      fontFamily: DISPLAY,
                    }}
                  >
                    {imageUrl ? (
                      <img src={imageUrl} alt={name} className="w-full h-full object-cover opacity-85 filter contrast-105" />
                    ) : (
                      name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")
                    )}
                  </div>
                  <h4 className="text-lg font-bold tracking-tight max-w-[90%] truncate uppercase" style={{ fontFamily: DISPLAY }}>
                    {name}
                  </h4>
                  <p
                    className="text-xs mt-1 px-2.5 py-0.5 rounded-full inline-block font-mono tracking-wider font-semibold"
                    style={{
                      backgroundColor: `${inkColor}20`,
                      color: inkColor,
                    }}
                  >
                    {role}
                  </p>

                  {lore && (
                    <p className="text-[10px] mt-2 italic px-3 line-clamp-3 opacity-80 leading-relaxed font-sans">
                      "{lore}"
                    </p>
                  )}

                  {statsLine && (
                    <div className="mt-2 text-[9.5px] font-mono font-bold tracking-wider opacity-90 px-2 py-0.5 rounded bg-black/20 border border-white/5">
                      {statsLine}
                    </div>
                  )}
                </div>

                <div className="space-y-1.5 pt-2 border-t" style={{ borderColor: `${inkColor}30` }}>
                  {/* Decorative barcode */}
                  <div className="flex items-center justify-between gap-1 h-5 px-1">
                    {Array.from({ length: 32 }).map((_, i) => (
                      <div
                        key={i}
                        className="h-full"
                        style={{
                          width: i % 3 === 0 ? "3px" : "1.5px",
                          backgroundColor: inkColor,
                          opacity: i % 5 === 0 ? 0.3 : 0.8,
                        }}
                      />
                    ))}
                  </div>
                  <div className="flex justify-between text-[9px] font-mono tracking-widest opacity-60">
                    <span>VERIFIED ID</span>
                    <span>CREATIVE NEXUS ARCHIVE</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export { LanyardBadge }
