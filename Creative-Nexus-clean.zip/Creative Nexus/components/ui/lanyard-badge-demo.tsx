import LanyardBadge from "@/components/ui/lanyard-badge"

export default function LanyardBadgeDemo() {
  return (
    <div className="w-full flex items-center justify-center min-h-[600px] bg-slate-950/80 rounded-3xl overflow-hidden border border-white/10">
      <LanyardBadge height="600px" cardWidth={240} />
    </div>
  )
}
