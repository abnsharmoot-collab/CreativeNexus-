import PolaroidLineCarousel from "@/components/ui/polaroid-line-carousel";

export default function PolaroidLineCarouselDemo() {
  return (
    <div className="w-full flex items-center justify-center min-h-[500px]">
      <PolaroidLineCarousel height="520px" cardWidth={260} />
    </div>
  );
}
