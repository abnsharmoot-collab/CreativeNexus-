"use client";

import { WorksWheel, type WorksWheelItem } from "@/components/ui/works-wheel";

// Curated high-resolution Unsplash assets for the interactive WorksWheel demo
const WORKS: WorksWheelItem[] = [
  {
    title: "Prismatic Rift",
    image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80",
    href: "#prismatic-rift",
  },
  {
    title: "Ember Clouds",
    image: "https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead?auto=format&fit=crop&w=1200&q=80",
    href: "#ember-clouds",
  },
  {
    title: "Neon Portal",
    image: "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1200&q=80",
    href: "#neon-portal",
  },
  {
    title: "Geometric Core",
    image: "https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=1200&q=80",
    href: "#geometric-core",
  },
  {
    title: "Celestial Light",
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1200&q=80",
    href: "#celestial-light",
  },
  {
    title: "Cyber Uplight",
    image: "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=1200&q=80",
    href: "#cyber-uplight",
  },
  {
    title: "Indigo Marble",
    image: "https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&w=1200&q=80",
    href: "#indigo-marble",
  },
  {
    title: "Launch Perspective",
    image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=1200&q=80",
    href: "#launch-perspective",
  },
  {
    title: "Cosmic Odyssey",
    image: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1200&q=80",
    href: "#cosmic-odyssey",
  },
];

export function WorksWheelDemo() {
  return (
    <div className="bg-[#031211] text-[#eafffa] w-full min-h-[640px] h-[80vh] rounded-2xl overflow-hidden border border-teal-500/20 shadow-2xl relative">
      <WorksWheel items={WORKS} label="Archive '26" action="Explore" />
    </div>
  );
}

export default WorksWheelDemo;
