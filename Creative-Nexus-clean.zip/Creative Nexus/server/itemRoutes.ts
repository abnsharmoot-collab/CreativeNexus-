import { Router, Request, Response } from 'express';
import { requireAuth, requireOwner } from './discordRbac';
import {
  getAllUnifiedItems,
  getUnifiedItemById,
  saveUnifiedItem,
  deleteUnifiedItem,
  deleteAllUnifiedItems,
  getUserInventory,
  useBattleItem,
  getDuplicateCardConfig,
  saveDuplicateCardConfig
} from './itemService';
import { ItemCategory } from '../src/types/items';

export function createItemRoutes(): Router {
  const router = Router();

  // 1. GET /api/items - Retrieve all unified items (Optionally filter by ?category=BATTLE,COMPANION,etc.)
  router.get('/', async (req, res) => {
    try {
      const category = req.query.category as ItemCategory | undefined;
      const allItems = await getAllUnifiedItems();

      const filtered = category
        ? allItems.filter(i => i.category === category)
        : allItems;

      res.json({
        success: true,
        items: filtered,
        total: filtered.length
      });
    } catch (err: any) {
      console.error('Error fetching unified items:', err);
      res.status(500).json({ error: err.message || 'Failed to fetch items' });
    }
  });

  // 2. GET /api/items/my-inventory - Get authenticated user's inventory with item data
  router.get('/my-inventory', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const inventory = await getUserInventory(user.discordId);
      const allItems = await getAllUnifiedItems();
      const itemMap = new Map(allItems.map(i => [i.id, i]));

      const hydratedInventory = Object.values(inventory).map(entry => {
        const itemData = itemMap.get(entry.itemId);
        return {
          ...entry,
          itemData: itemData || entry.itemData
        };
      });

      res.json({
        success: true,
        inventory: hydratedInventory,
        itemsMap: inventory
      });
    } catch (err: any) {
      console.error('Error fetching user inventory:', err);
      res.status(500).json({ error: err.message || 'Failed to fetch inventory' });
    }
  });

  // 3. POST /api/items/owner/save - Create or update an item (Owner only)
  router.post('/owner/save', requireAuth, requireOwner, async (req, res) => {
    try {
      const user = req.authUser!;
      const itemData = req.body;

      if (!itemData || !itemData.name) {
        return res.status(400).json({ error: 'Item name is required' });
      }

      const saved = await saveUnifiedItem(itemData, user.discordId);
      res.json({
        success: true,
        item: saved,
        message: `Item '${saved.name}' saved successfully.`
      });
    } catch (err: any) {
      console.error('Error saving item:', err);
      res.status(500).json({ error: err.message || 'Failed to save item' });
    }
  });

  // 4. DELETE /api/items/owner/:id - Delete an item (Owner only)
  const handleDeleteItem = async (req: Request, res: Response) => {
    try {
      const rawId = req.params.id || (req.params as any)[0] || req.query.id || req.query.itemId || req.body?.itemId || req.body?.id || '';
      let id = String(rawId).trim();
      try {
        id = decodeURIComponent(id);
      } catch {}
      id = id.trim();

      if (!id) {
        return res.status(400).json({ error: 'Item ID is required' });
      }

      await deleteUnifiedItem(id);
      res.json({
        success: true,
        deletedId: id,
        message: `Item '${id}' deleted successfully.`
      });
    } catch (err: any) {
      console.error('Error deleting item:', err);
      res.status(500).json({ error: err.message || 'Failed to delete item' });
    }
  };

  router.delete('/owner/:id', requireAuth, requireOwner, handleDeleteItem);
  router.delete('/owner', requireAuth, requireOwner, handleDeleteItem);
  router.post('/owner/delete', requireAuth, requireOwner, handleDeleteItem);
  router.post('/owner/delete-item', requireAuth, requireOwner, handleDeleteItem);
  router.post('/owner/delete/:id', requireAuth, requireOwner, handleDeleteItem);
  router.delete('/:id', requireAuth, requireOwner, handleDeleteItem);
  router.post('/delete', requireAuth, requireOwner, handleDeleteItem);
  router.post('/delete-item', requireAuth, requireOwner, handleDeleteItem);

  // 4a. DELETE ALL /api/items/owner/all - Delete all items (Owner only)
  const handleDeleteAllItems = async (req: Request, res: Response) => {
    try {
      const count = await deleteAllUnifiedItems();
      res.json({
        success: true,
        deletedCount: count,
        message: `All items (${count}) deleted successfully.`
      });
    } catch (err: any) {
      console.error('Error deleting all items:', err);
      res.status(500).json({ error: err.message || 'Failed to delete all items' });
    }
  };

  router.delete('/owner/all', requireAuth, requireOwner, handleDeleteAllItems);
  router.delete('/owner/delete-all', requireAuth, requireOwner, handleDeleteAllItems);
  router.post('/owner/delete-all', requireAuth, requireOwner, handleDeleteAllItems);
  router.post('/delete-all', requireAuth, requireOwner, handleDeleteAllItems);

  // 4b. GET /api/items/owner/export - Export all unified items as backup JSON
  router.get('/owner/export', requireAuth, requireOwner, async (req, res) => {
    try {
      const allItems = await getAllUnifiedItems(true);
      res.json({
        success: true,
        version: 2,
        exportedAt: new Date().toISOString(),
        count: allItems.length,
        items: allItems
      });
    } catch (err: any) {
      console.error('Error exporting items:', err);
      res.status(500).json({ error: err.message || 'Failed to export items' });
    }
  });

  // 4c. POST /api/items/owner/import - Import unified items from backup JSON
  router.post('/owner/import', requireAuth, requireOwner, async (req, res) => {
    try {
      const user = req.authUser!;
      const rawItems = req.body?.items || req.body;
      const list = Array.isArray(rawItems) ? rawItems : (rawItems?.items ? rawItems.items : []);
      if (!Array.isArray(list) || list.length === 0) {
        return res.status(400).json({ error: 'No valid items found to import' });
      }

      let importedCount = 0;
      for (const item of list) {
        if (item && item.name) {
          await saveUnifiedItem(item, user.discordId);
          importedCount++;
        }
      }

      const refreshed = await getAllUnifiedItems(true);
      res.json({
        success: true,
        count: importedCount,
        items: refreshed,
        message: `Successfully imported ${importedCount} items into catalog.`
      });
    } catch (err: any) {
      console.error('Error importing items:', err);
      res.status(500).json({ error: err.message || 'Failed to import items' });
    }
  });

  // 5. POST /api/items/use-battle-item - Consume a battle item in combat (Auth required)
  router.post('/use-battle-item', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const { itemId } = req.body;

      if (!itemId) {
        return res.status(400).json({ error: 'itemId is required' });
      }

      const result = await useBattleItem(user.discordId, itemId);
      res.json({
        success: true,
        ...result
      });
    } catch (err: any) {
      console.error('Error using battle item:', err);
      res.status(400).json({ error: err.message || 'Failed to use battle item' });
    }
  });

  // 6. GET /api/cards/duplicate-config - Duplicate cards reward settings
  router.get('/duplicate-config', async (_req, res) => {
    try {
      const config = await getDuplicateCardConfig();
      res.json({
        success: true,
        config
      });
    } catch (err: any) {
      console.error('Error fetching duplicate config:', err);
      res.status(500).json({ error: err.message || 'Failed to fetch duplicate reward config' });
    }
  });

  // 7. POST /api/cards/owner/duplicate-config - Update duplicate cards settings (Owner only)
  router.post('/owner/duplicate-config', requireAuth, requireOwner, async (req, res) => {
    try {
      const user = req.authUser!;
      const config = req.body;

      const saved = await saveDuplicateCardConfig(config, user.username || user.discordId);
      res.json({
        success: true,
        config: saved,
        message: 'Duplicate card reward configuration updated successfully.'
      });
    } catch (err: any) {
      console.error('Error saving duplicate config:', err);
      res.status(500).json({ error: err.message || 'Failed to update duplicate reward config' });
    }
  });

  return router;
}

export function setupItemRoutes(app: any) {
  const router = createItemRoutes();
  app.use('/api/items', router);
  // Also mount duplicate config aliases on /api/cards so both routes work seamlessly
  app.get('/api/cards/duplicate-config', async (_req, res) => {
    try {
      const config = await getDuplicateCardConfig();
      res.json({ success: true, config });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });
  app.post('/api/cards/owner/duplicate-config', requireAuth, requireOwner, async (req, res) => {
    try {
      const user = req.authUser!;
      const config = req.body;
      const saved = await saveDuplicateCardConfig(config, user.username || user.discordId);
      res.json({ success: true, config: saved, message: 'Duplicate card reward configuration updated successfully.' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });
}

