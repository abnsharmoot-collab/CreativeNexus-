import { getFirestoreInstance } from './discordStaffSync';
import { doc, getDoc, setDoc, deleteDoc, collection, getDocs } from 'firebase/firestore';
import {
  CharacterDefinition,
  CharacterStage,
  LoveItemDefinition,
  UserCharacterProgress,
  UserLoveItemOwnership,
  LoveLevelThreshold,
  GiveGiftResult,
  ClaimPassiveCoinsResult,
  ClaimSpecialRewardResult,
  SpecialRewardDefinition,
  SpecialRewardsConfig,
  TriggerRandomGiftResult,
  CharacterRandomGift,
  DEFAULT_LOVE_LEVEL_THRESHOLDS
} from '../src/types/characterLove';
import { DEFAULT_CHARACTERS, DEFAULT_LOVE_ITEMS } from '../src/data/defaultCharacterLove';
import { CardRarity } from '../src/types/cards';
import { getUserCardProfile, saveUserProfile, recordTransaction, openCardPack } from './cardService';
import { getAllUnifiedItems, saveUnifiedItem, deleteUnifiedItem, rollUnifiedItemForPack } from './itemService';

// In-memory caches for instant responsiveness
let charactersCatalog: CharacterDefinition[] = [...DEFAULT_CHARACTERS];
let loveThresholds: LoveLevelThreshold[] = [...DEFAULT_LOVE_LEVEL_THRESHOLDS];

export const DEFAULT_SPECIAL_REWARDS_CONFIG: SpecialRewardsConfig = {
  cycleHours: 72, // 3 days
  rewards: [
    {
      id: 'spec_pack_rare',
      type: 'PACKAGE',
      name: 'Quantum Azure Vault [Pack]',
      nameAr: 'حزمة كوانتوم الزرقاء [نادرة]',
      rarity: 'RARE',
      packageId: 'RARE',
      dropWeight: 20,
      bonusCoins: 100,
      iconUrl: '/src/assets/images/pack_rare_azure_1790930951669.jpg',
      description: 'Exclusive 3-Day Companion favor: Quantum Azure Vault Booster Pack',
      descriptionAr: 'منحة الرفيقة الخاصة كل 3 أيام: حزمة بطاقات كوانتوم النادرة',
      isActive: true
    },
    {
      id: 'spec_pack_uncommon',
      type: 'PACKAGE',
      name: 'Prism Emerald Drive [Pack]',
      nameAr: 'حزمة بريزم إميرالد [غير شائعة]',
      rarity: 'UNCOMMON',
      packageId: 'UNCOMMON',
      dropWeight: 25,
      bonusCoins: 50,
      iconUrl: '/src/assets/images/pack_uncommon_prism_1790930937753.jpg',
      description: 'Companion gift: Prism Emerald Drive Booster Pack',
      descriptionAr: 'مكافأة الرفيقة: حزمة بريزم إميرالد غير الشائعة',
      isActive: true
    },
    {
      id: 'spec_pack_epic',
      type: 'PACKAGE',
      name: 'Hyperion Amethyst Nexus [Pack]',
      nameAr: 'حزمة هايبريون البنفسجية [ملحمية]',
      rarity: 'EPIC',
      packageId: 'EPIC',
      dropWeight: 10,
      bonusCoins: 200,
      iconUrl: '/src/assets/images/pack_epic_hyperion_1790930972693.jpg',
      description: 'Rare 3-Day Companion favor: Hyperion Amethyst Pack',
      descriptionAr: 'بركة كبرى كل 3 أيام: حزمة هايبريون الملحمية النادرة',
      isActive: true
    },
    {
      id: 'spec_pack_legendary',
      type: 'PACKAGE',
      name: 'Sovereign Solar Eclipse [Pack]',
      nameAr: 'حزمة كسوف الشمس السيادي [أسطورية]',
      rarity: 'LEGENDARY',
      packageId: 'LEGENDARY',
      dropWeight: 4,
      bonusCoins: 500,
      iconUrl: '/src/assets/images/pack_legendary_sovereign_1790930990391.jpg',
      description: 'Mythical Sovereign Solar Eclipse booster pack',
      descriptionAr: 'حزمة كسوف الشمس الأسطورية الفاخرة للرفقاء المميزين',
      isActive: true
    },
    {
      id: 'spec_item_honey',
      type: 'ITEM',
      name: 'Babylonian Golden Palm Honey',
      nameAr: 'عسل النخيل البابلي الذهبي',
      rarity: 'COMMON',
      itemId: 'item_date_honey',
      dropWeight: 25,
      bonusCoins: 40,
      bonusLovePoints: 30,
      iconUrl: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=400&q=80',
      description: 'Sacred Euphrates date honey for raising affection',
      descriptionAr: 'عسل النخيل الفراتي لرفع المودة والأنس',
      isActive: true
    },
    {
      id: 'spec_item_lapis',
      type: 'ITEM',
      name: 'Sacred Mesopotamian Lapis Pendant',
      nameAr: 'قلادة اللازورد الرافدينية المقدسة',
      rarity: 'RARE',
      itemId: 'item_lapis_pendant',
      dropWeight: 12,
      bonusCoins: 120,
      bonusLovePoints: 80,
      iconUrl: 'https://images.unsplash.com/photo-1600003014755-ba31aa59c4b6?auto=format&fit=crop&w=400&q=80',
      description: 'Celestial lapis pendant favored by companions',
      descriptionAr: 'قلادة لازورد ملكية نادرة تضاعف المحبة',
      isActive: true
    },
    {
      id: 'spec_item_pomegranate',
      type: 'ITEM',
      name: 'Royal Sanctuary Ruby Pomegranate',
      nameAr: 'رمانة الملاذ الياقوتية الملكية',
      rarity: 'EPIC',
      itemId: 'item_pomegranate',
      dropWeight: 4,
      bonusCoins: 250,
      bonusLovePoints: 150,
      iconUrl: 'https://images.unsplash.com/photo-1541344999736-83eca872f241?auto=format&fit=crop&w=400&q=80',
      description: 'Delicacy of royalty offering massive affection boost',
      descriptionAr: 'تحفة ملوكية نادرة تمنح قفزة كبرى في المحبة',
      isActive: true
    }
  ],
  updatedAt: new Date().toISOString()
};

let specialRewardsConfig: SpecialRewardsConfig = { ...DEFAULT_SPECIAL_REWARDS_CONFIG };
let hasLoadedSpecialRewards = false;

const userProgressCache = new Map<string, Record<string, UserCharacterProgress>>();
const userInventoryCache = new Map<string, Record<string, UserLoveItemOwnership>>();

let hasLoadedCharacters = false;
let hasLoadedItems = false;
let hasLoadedThresholds = false;

// Compute Level from current points
export function calculateLevelFromPoints(points: number, thresholds: LoveLevelThreshold[]): {
  level: number;
  currentThreshold: LoveLevelThreshold;
  nextThreshold: LoveLevelThreshold | null;
  progressPercent: number;
} {
  const sorted = [...thresholds].sort((a, b) => a.level - b.level);
  let currentLevel = 1;

  for (const t of sorted) {
    if (points >= t.requiredPoints) {
      currentLevel = t.level;
    } else {
      break;
    }
  }

  const currentThreshold = sorted.find(t => t.level === currentLevel) || sorted[0];
  const nextThreshold = sorted.find(t => t.level === currentLevel + 1) || null;

  let progressPercent = 100;
  if (nextThreshold) {
    const range = nextThreshold.requiredPoints - currentThreshold.requiredPoints;
    const currentOver = points - currentThreshold.requiredPoints;
    progressPercent = range > 0 ? Math.min(100, Math.max(0, Math.round((currentOver / range) * 100))) : 100;
  }

  return {
    level: currentLevel,
    currentThreshold,
    nextThreshold,
    progressPercent
  };
}

// Compute active stage for a character given a level
export function computeActiveStage(character: CharacterDefinition, level: number): CharacterStage {
  if (!character.stages || character.stages.length === 0) {
    return {
      id: `${character.id}_stage_1`,
      stageNumber: 1,
      name: 'Stage 1',
      nameAr: 'المرحلة 1',
      requiredLevel: 1,
      imageUrl: character.avatarUrl
    };
  }

  const sortedStages = [...character.stages].sort((a, b) => a.stageNumber - b.stageNumber);
  let active = sortedStages[0];

  for (const stage of sortedStages) {
    if (level >= stage.requiredLevel) {
      active = stage;
    }
  }

  return active;
}

// ----------------------------------------------------
// CATALOG LOADERS
// ----------------------------------------------------
export async function getAllCharacters(forceRefresh = false): Promise<CharacterDefinition[]> {
  if (hasLoadedCharacters && !forceRefresh) {
    return charactersCatalog;
  }

  try {
    const db = getFirestoreInstance();
    if (db) {
      const snap = await getDocs(collection(db, 'character_love_characters'));
      if (!snap.empty) {
        const customMap = new Map<string, CharacterDefinition>();
        snap.docs.forEach(d => {
          const data = d.data() as CharacterDefinition;
          customMap.set(d.id, { ...data, id: d.id });
        });

        // Merge defaults with custom/overridden characters
        const merged: CharacterDefinition[] = [];
        for (const def of DEFAULT_CHARACTERS) {
          if (customMap.has(def.id)) {
            merged.push(customMap.get(def.id)!);
            customMap.delete(def.id);
          } else {
            merged.push(def);
          }
        }
        for (const remaining of customMap.values()) {
          merged.push(remaining);
        }
        charactersCatalog = merged.filter(c => c.isActive !== false).sort((a, b) => a.order - b.order);
      }
    }
  } catch (err: any) {
    console.warn('CharacterLoveService: Warning loading characters from Firestore:', err?.message);
  }

  hasLoadedCharacters = true;
  return charactersCatalog;
}

export async function getAllItems(forceRefresh = false): Promise<LoveItemDefinition[]> {
  const unified = await getAllUnifiedItems(forceRefresh);
  return unified as LoveItemDefinition[];
}

export async function getLoveThresholds(forceRefresh = false): Promise<LoveLevelThreshold[]> {
  if (hasLoadedThresholds && !forceRefresh) {
    return loveThresholds;
  }

  try {
    const db = getFirestoreInstance();
    if (db) {
      const snap = await getDoc(doc(db, 'site_settings', 'love_level_thresholds'));
      if (snap.exists()) {
        const data = snap.data();
        if (Array.isArray(data?.thresholds) && data.thresholds.length > 0) {
          loveThresholds = data.thresholds;
        }
      }
    }
  } catch (err: any) {
    console.warn('CharacterLoveService: Warning loading thresholds from Firestore:', err?.message);
  }

  hasLoadedThresholds = true;
  return loveThresholds;
}

// ----------------------------------------------------
// USER PROGRESS & INVENTORY
// ----------------------------------------------------
export async function getUserCharacterProgress(discordId: string): Promise<Record<string, UserCharacterProgress>> {
  const cleanId = String(discordId).trim();
  const cached = userProgressCache.get(cleanId);
  const characters = await getAllCharacters();
  const thresholds = await getLoveThresholds();

  if (cached) {
    // Ensure all current characters have an entry
    let changed = false;
    for (const char of characters) {
      if (!cached[char.id]) {
        const activeStage = computeActiveStage(char, 1);
        cached[char.id] = {
          characterId: char.id,
          lovePoints: 0,
          level: 1,
          currentStageNumber: activeStage.stageNumber,
          totalGiftsGiven: 0,
          lastInteractedAt: new Date().toISOString(),
          unlockedStageNumbers: [1]
        };
        changed = true;
      }
    }
    return cached;
  }

  const progressMap: Record<string, UserCharacterProgress> = {};

  try {
    const db = getFirestoreInstance();
    if (db) {
      const snap = await getDoc(doc(db, 'user_character_love', cleanId));
      if (snap.exists()) {
        const data = snap.data();
        if (data?.progress && typeof data.progress === 'object') {
          Object.assign(progressMap, data.progress);
        }
      }
    }
  } catch (err: any) {
    console.warn('CharacterLoveService: Warning loading user progress:', err?.message);
  }

  // Ensure every active character is initialized
  for (const char of characters) {
    if (!progressMap[char.id]) {
      const activeStage = computeActiveStage(char, 1);
      progressMap[char.id] = {
        characterId: char.id,
        lovePoints: 0,
        level: 1,
        currentStageNumber: activeStage.stageNumber,
        totalGiftsGiven: 0,
        lastInteractedAt: new Date().toISOString(),
        unlockedStageNumbers: [1]
      };
    } else {
      // Recalculate level to keep in sync with active thresholds
      const calc = calculateLevelFromPoints(progressMap[char.id].lovePoints, thresholds);
      progressMap[char.id].level = calc.level;
      const stage = computeActiveStage(char, calc.level);
      progressMap[char.id].currentStageNumber = stage.stageNumber;
      if (!progressMap[char.id].unlockedStageNumbers) {
        progressMap[char.id].unlockedStageNumbers = [1];
      }
      if (!progressMap[char.id].unlockedStageNumbers.includes(stage.stageNumber)) {
        progressMap[char.id].unlockedStageNumbers.push(stage.stageNumber);
      }
    }
  }

  userProgressCache.set(cleanId, progressMap);
  return progressMap;
}

export async function getUserInventory(discordId: string): Promise<Record<string, UserLoveItemOwnership>> {
  const cleanId = String(discordId).trim();
  const cached = userInventoryCache.get(cleanId);
  if (cached) return cached;

  const inventory: Record<string, UserLoveItemOwnership> = {};

  try {
    const db = getFirestoreInstance();
    if (db) {
      const snap = await getDoc(doc(db, 'user_love_inventory', cleanId));
      if (snap.exists()) {
        const data = snap.data();
        if (data?.items && typeof data.items === 'object') {
          Object.assign(inventory, data.items);
        }
      }
    }
  } catch (err: any) {
    console.warn('CharacterLoveService: Warning loading user inventory:', err?.message);
  }

  // If user has 0 items ever, seed with generous welcome gifts so they can immediately test!
  if (Object.keys(inventory).length === 0) {
    const now = new Date().toISOString();
    inventory['item_date_honey'] = {
      itemId: 'item_date_honey',
      count: 3,
      firstAcquiredAt: now,
      lastAcquiredAt: now
    };
    inventory['item_celestial_rose'] = {
      itemId: 'item_celestial_rose',
      count: 2,
      firstAcquiredAt: now,
      lastAcquiredAt: now
    };
    inventory['item_lapis_pendant'] = {
      itemId: 'item_lapis_pendant',
      count: 1,
      firstAcquiredAt: now,
      lastAcquiredAt: now
    };

    saveUserInventory(cleanId, inventory).catch(() => {});
  }

  userInventoryCache.set(cleanId, inventory);
  return inventory;
}

export async function saveUserProgress(discordId: string, progress: Record<string, UserCharacterProgress>): Promise<void> {
  const cleanId = String(discordId).trim();
  userProgressCache.set(cleanId, progress);

  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'user_character_love', cleanId), {
        discordId: cleanId,
        progress,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    }
  } catch (err: any) {
    console.warn('CharacterLoveService: Note persisting progress to Firestore:', err?.message);
  }
}

export async function saveUserInventory(discordId: string, items: Record<string, UserLoveItemOwnership>): Promise<void> {
  const cleanId = String(discordId).trim();
  userInventoryCache.set(cleanId, items);

  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'user_love_inventory', cleanId), {
        discordId: cleanId,
        items,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    }
  } catch (err: any) {
    console.warn('CharacterLoveService: Note persisting inventory to Firestore:', err?.message);
  }
}

// ----------------------------------------------------
// GIVE GIFT ACTION (CORE LOVE SYSTEM MECHANIC)
// ----------------------------------------------------
export async function giveGiftToCharacter(
  discordId: string,
  characterId: string,
  itemId: string,
  quantity = 1
): Promise<GiveGiftResult> {
  const cleanId = String(discordId).trim();
  const count = Math.max(1, Math.min(50, quantity));

  const characters = await getAllCharacters();
  const character = characters.find(c => c.id === characterId);
  if (!character) {
    throw new Error(`Character ${characterId} not found`);
  }

  const items = await getAllItems();
  const item = items.find(i => i.id === itemId);
  if (!item) {
    throw new Error(`Item ${itemId} not found`);
  }

  const inventory = await getUserInventory(cleanId);
  const currentOwnership = inventory[itemId];
  if (!currentOwnership || currentOwnership.count < count) {
    throw new Error(`Insufficient items. You possess ${currentOwnership?.count || 0} of this gift.`);
  }

  // Deduct from inventory
  currentOwnership.count -= count;
  if (currentOwnership.count <= 0) {
    delete inventory[itemId];
  }
  await saveUserInventory(cleanId, inventory);

  // Check if character loves this item
  const isTargetMatched = item.targetCharacterId === characterId || item.targetCharacterId === 'ANY';
  const isBelovedInList = Array.isArray(character.lovedItemIds) && character.lovedItemIds.includes(itemId);
  const isBelovedGift = isTargetMatched || isBelovedInList;

  // Compute love points with beloved bonus (1.3x bonus if beloved)
  const basePointsPerUnit = item.lovePoints || 20;
  const multiplier = isBelovedGift ? 1.35 : 1.0;
  const pointsAwarded = Math.round(basePointsPerUnit * count * multiplier);

  // Update character progress
  const progressMap = await getUserCharacterProgress(cleanId);
  let charProgress = progressMap[characterId];
  if (!charProgress) {
    charProgress = {
      characterId,
      lovePoints: 0,
      level: 1,
      currentStageNumber: 1,
      totalGiftsGiven: 0,
      lastInteractedAt: new Date().toISOString(),
      unlockedStageNumbers: [1]
    };
    progressMap[characterId] = charProgress;
  }

  const prevPoints = charProgress.lovePoints;
  const prevLevel = charProgress.level;
  const prevStageNum = charProgress.currentStageNumber;

  const newPoints = prevPoints + pointsAwarded;
  charProgress.lovePoints = newPoints;
  charProgress.totalGiftsGiven = (charProgress.totalGiftsGiven || 0) + count;
  charProgress.lastInteractedAt = new Date().toISOString();
  if (isBelovedGift) {
    charProgress.favoriteGiftId = itemId;
  }

  const thresholds = await getLoveThresholds();
  const levelData = calculateLevelFromPoints(newPoints, thresholds);
  const newLevel = levelData.level;
  charProgress.level = newLevel;

  const newStage = computeActiveStage(character, newLevel);
  charProgress.currentStageNumber = newStage.stageNumber;

  if (!charProgress.unlockedStageNumbers) {
    charProgress.unlockedStageNumbers = [1];
  }
  if (!charProgress.unlockedStageNumbers.includes(newStage.stageNumber)) {
    charProgress.unlockedStageNumbers.push(newStage.stageNumber);
  }

  const leveledUp = newLevel > prevLevel;
  const newStageUnlocked = newStage.stageNumber > prevStageNum;

  await saveUserProgress(cleanId, progressMap);

  return {
    success: true,
    characterId,
    itemId,
    pointsAwarded,
    isBelovedGift,
    previousPoints: prevPoints,
    newPoints,
    previousLevel: prevLevel,
    newLevel,
    leveledUp,
    newStageUnlocked,
    currentStage: newStage,
    remainingItemCount: inventory[itemId]?.count || 0,
    progress: charProgress,
    message: isBelovedGift
      ? `${character.name} absolutely adored your gift! (+${pointsAwarded} Love Points)`
      : `Gift received! (+${pointsAwarded} Love Points)`
  };
}

// ----------------------------------------------------
// INTEGRATION WITH EXISTING CARD PACKAGES
// ----------------------------------------------------
export async function rollLoveItemForPack(
  discordId: string,
  packType: CardRarity
): Promise<LoveItemDefinition | null> {
  const unified = await rollUnifiedItemForPack(discordId, packType);
  return unified as LoveItemDefinition | null;
}

// ----------------------------------------------------
// OWNER MANAGEMENT CONTROLS
// ----------------------------------------------------
export async function ownerSaveCharacter(
  characterData: Partial<CharacterDefinition> & { id?: string },
  ownerUsername: string
): Promise<CharacterDefinition> {
  const id = characterData.id?.trim() || `char_custom_${Date.now()}`;
  const now = new Date().toISOString();

  // Validate or construct stages
  let stages: CharacterStage[] = (Array.isArray(characterData.stages) ? characterData.stages : []).map((st, i) => ({
    id: st.id || `${id}_stage_${i + 1}`,
    stageNumber: st.stageNumber || i + 1,
    name: st.name || `Stage ${i + 1}`,
    nameAr: st.nameAr || `المرحلة ${i + 1}`,
    requiredLevel: typeof st.requiredLevel === 'number' ? st.requiredLevel : (i * 2 + 1),
    requiredPoints: typeof st.requiredPoints === 'number' ? st.requiredPoints : undefined,
    passiveCoinReward: typeof st.passiveCoinReward === 'number' ? st.passiveCoinReward : ((st.stageNumber || (i + 1)) * 50),
    imageUrl: st.imageUrl || characterData.avatarUrl || '/src/assets/images/companion_stage1_1792010085166.jpg',
    quote: st.quote,
    quoteAr: st.quoteAr,
    perkDescription: st.perkDescription,
    perkDescriptionAr: st.perkDescriptionAr
  }));

  if (stages.length === 0) {
    stages = [
      {
        id: `${id}_stage_1`,
        stageNumber: 1,
        name: 'Stage 1: Beginning',
        nameAr: 'المرحلة 1: البداية',
        requiredLevel: 1,
        passiveCoinReward: 50,
        imageUrl: characterData.avatarUrl || '/src/assets/images/companion_stage1_1792010085166.jpg'
      }
    ];
  }

  const existing = charactersCatalog.find(c => c.id === id);

  const character: CharacterDefinition = {
    id,
    name: characterData.name?.trim() || existing?.name || 'New Companion',
    nameAr: characterData.nameAr?.trim() || existing?.nameAr || 'شخصية جديدة',
    title: characterData.title?.trim() || existing?.title || 'Sanctuary Companion',
    titleAr: characterData.titleAr?.trim() || existing?.titleAr || 'رفيق الملاذ',
    description: characterData.description?.trim() || existing?.description || '',
    descriptionAr: characterData.descriptionAr?.trim() || existing?.descriptionAr || '',
    avatarUrl: characterData.avatarUrl?.trim() || existing?.avatarUrl || stages[0].imageUrl,
    stages,
    themeColor: characterData.themeColor || existing?.themeColor || '#f43f5e',
    accentGradient: characterData.accentGradient || existing?.accentGradient,
    scale: typeof characterData.scale === 'number' ? characterData.scale : (existing?.scale ?? 1.0),
    offsetX: typeof characterData.offsetX === 'number' ? characterData.offsetX : (existing?.offsetX ?? 0),
    offsetY: typeof characterData.offsetY === 'number' ? characterData.offsetY : (existing?.offsetY ?? 0),
    imageWidth: characterData.imageWidth !== undefined ? characterData.imageWidth : (existing?.imageWidth ?? 'auto'),
    imageHeight: characterData.imageHeight !== undefined ? characterData.imageHeight : (existing?.imageHeight ?? 'auto'),
    layering: characterData.layering || existing?.layering || 'popout_overflow',
    overflowMode: characterData.overflowMode || existing?.overflowMode || 'visible',
    zIndex: typeof characterData.zIndex === 'number' ? characterData.zIndex : (existing?.zIndex ?? 20),
    cardHeight: typeof characterData.cardHeight === 'number' ? characterData.cardHeight : existing?.cardHeight,
    cardWidth: typeof characterData.cardWidth === 'number' ? characterData.cardWidth : existing?.cardWidth,
    gradientFade: characterData.gradientFade || existing?.gradientFade,
    audioConfig: characterData.audioConfig || existing?.audioConfig,
    clickTransform: characterData.clickTransform || existing?.clickTransform,
    randomGifts: Array.isArray(characterData.randomGifts)
      ? characterData.randomGifts
      : (existing?.randomGifts || []),
    lovedItemIds: characterData.lovedItemIds || existing?.lovedItemIds || [],
    order: typeof characterData.order === 'number' ? characterData.order : (existing?.order ?? charactersCatalog.length + 1),
    isActive: characterData.isActive !== false,
    isCustom: true,
    createdBy: ownerUsername,
    createdAt: existing?.createdAt || now,
    updatedAt: now
  };

  // Update catalog cache
  const idx = charactersCatalog.findIndex(c => c.id === id);
  if (idx >= 0) {
    charactersCatalog[idx] = character;
  } else {
    charactersCatalog.push(character);
  }

  // Persist to Firestore
  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'character_love_characters', id), character, { merge: true });
    }
  } catch (err: any) {
    console.warn('CharacterLoveService: Error saving character to Firestore:', err?.message);
  }

  return character;
}

export async function ownerDeleteCharacter(characterId: string): Promise<boolean> {
  const cleanId = characterId.trim();
  charactersCatalog = charactersCatalog.filter(c => c.id !== cleanId);

  try {
    const db = getFirestoreInstance();
    if (db) {
      await deleteDoc(doc(db, 'character_love_characters', cleanId));
    }
  } catch (err: any) {
    console.warn('CharacterLoveService: Error deleting character from Firestore:', err?.message);
  }

  return true;
}

export async function ownerSaveItem(
  itemData: Partial<LoveItemDefinition> & { id?: string },
  ownerUsername: string
): Promise<LoveItemDefinition> {
  const unified = await saveUnifiedItem({ ...itemData, category: itemData.category || 'COMPANION' }, ownerUsername);
  return unified as LoveItemDefinition;
}

export async function ownerDeleteItem(itemId: string): Promise<boolean> {
  return deleteUnifiedItem(itemId);
}

export async function ownerManualAdjust(
  targetDiscordId: string,
  characterId: string,
  options: { level?: number; lovePoints?: number }
): Promise<UserCharacterProgress> {
  const cleanId = String(targetDiscordId).trim();
  const progressMap = await getUserCharacterProgress(cleanId);
  const characters = await getAllCharacters();
  const character = characters.find(c => c.id === characterId);
  if (!character) {
    throw new Error(`Character ${characterId} not found`);
  }

  const thresholds = await getLoveThresholds();
  let charProgress = progressMap[characterId];
  if (!charProgress) {
    charProgress = {
      characterId,
      lovePoints: 0,
      level: 1,
      currentStageNumber: 1,
      totalGiftsGiven: 0,
      lastInteractedAt: new Date().toISOString(),
      unlockedStageNumbers: [1]
    };
    progressMap[characterId] = charProgress;
  }

  if (typeof options.lovePoints === 'number') {
    charProgress.lovePoints = Math.max(0, options.lovePoints);
    const calc = calculateLevelFromPoints(charProgress.lovePoints, thresholds);
    charProgress.level = calc.level;
  }

  if (typeof options.level === 'number') {
    const reqLevel = Math.max(1, Math.min(20, options.level));
    charProgress.level = reqLevel;
    const thresh = thresholds.find(t => t.level === reqLevel);
    if (thresh && charProgress.lovePoints < thresh.requiredPoints) {
      charProgress.lovePoints = thresh.requiredPoints;
    }
  }

  const activeStage = computeActiveStage(character, charProgress.level);
  charProgress.currentStageNumber = activeStage.stageNumber;

  if (!charProgress.unlockedStageNumbers) charProgress.unlockedStageNumbers = [1];
  for (const st of character.stages) {
    if (charProgress.level >= st.requiredLevel && !charProgress.unlockedStageNumbers.includes(st.stageNumber)) {
      charProgress.unlockedStageNumbers.push(st.stageNumber);
    }
  }

  charProgress.lastInteractedAt = new Date().toISOString();
  await saveUserProgress(cleanId, progressMap);

  return charProgress;
}

export async function ownerSaveThresholds(thresholds: LoveLevelThreshold[]): Promise<LoveLevelThreshold[]> {
  loveThresholds = thresholds.sort((a, b) => a.level - b.level);
  hasLoadedThresholds = true;

  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'site_settings', 'love_level_thresholds'), {
        thresholds: loveThresholds,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    }
  } catch (err: any) {
    console.warn('CharacterLoveService: Error saving thresholds to Firestore:', err?.message);
  }

  return loveThresholds;
}

// ----------------------------------------------------
// PASSIVE COIN REWARDS (12-HOUR CYCLE)
// ----------------------------------------------------
export const PASSIVE_COIN_COOLDOWN_MS = 12 * 60 * 60 * 1000; // 12 hours in milliseconds

export async function claimPassiveCoins(
  discordId: string,
  characterId: string
): Promise<ClaimPassiveCoinsResult> {
  const cleanId = String(discordId).trim();
  const characters = await getAllCharacters();
  const character = characters.find(c => c.id === characterId);
  if (!character) {
    throw new Error(`Companion ${characterId} not found`);
  }

  const progressMap = await getUserCharacterProgress(cleanId);
  const charProgress = progressMap[characterId];
  if (!charProgress) {
    throw new Error(`No progress found for companion ${characterId}`);
  }

  // Calculate user's current stage based on level thresholds
  const thresholds = await getLoveThresholds();
  const calc = calculateLevelFromPoints(charProgress.lovePoints, thresholds);
  const activeStage = computeActiveStage(character, calc.level);

  // Check 12-hour cooldown
  const now = Date.now();
  if (charProgress.lastPassiveCoinClaimAt) {
    const lastClaim = new Date(charProgress.lastPassiveCoinClaimAt).getTime();
    const elapsed = now - lastClaim;
    if (elapsed < PASSIVE_COIN_COOLDOWN_MS) {
      const remainingMs = PASSIVE_COIN_COOLDOWN_MS - elapsed;
      const nextClaimDate = new Date(lastClaim + PASSIVE_COIN_COOLDOWN_MS).toISOString();
      throw new Error(`COOLDOWN_ACTIVE:${remainingMs}:${nextClaimDate}`);
    }
  }

  // Calculate reward for user's current stage
  const coinsReward = typeof activeStage.passiveCoinReward === 'number'
    ? activeStage.passiveCoinReward
    : (activeStage.stageNumber * 50);

  // Credit coins to user profile in cardService
  const userProfile = await getUserCardProfile(cleanId);
  userProfile.coins = (userProfile.coins || 0) + coinsReward;
  await saveUserProfile(userProfile);

  await recordTransaction({
    type: 'ADMIN_GIFT',
    userId: cleanId,
    username: userProfile.username,
    amount: coinsReward,
    balanceAfter: userProfile.coins,
    performedBy: 'SYSTEM',
    reason: `Passive Character Coin Generation: ${character.name} (Stage ${activeStage.stageNumber})`
  });

  // Update progress timestamp
  const claimTimestamp = new Date(now).toISOString();
  charProgress.lastPassiveCoinClaimAt = claimTimestamp;
  await saveUserProgress(cleanId, progressMap);

  const nextClaimAvailableAt = new Date(now + PASSIVE_COIN_COOLDOWN_MS).toISOString();

  return {
    success: true,
    characterId,
    coinsAwarded: coinsReward,
    newBalance: userProfile.coins,
    stageNumber: activeStage.stageNumber,
    lastPassiveCoinClaimAt: claimTimestamp,
    nextClaimAvailableAt,
    message: `Collected ${coinsReward} coins from ${character.name}!`
  };
}

// ----------------------------------------------------
// RANDOM COMPANION GIFTS & REWARDS
// ----------------------------------------------------
export async function triggerRandomGift(
  discordId: string,
  characterId: string
): Promise<TriggerRandomGiftResult> {
  const cleanId = String(discordId).trim();
  const characters = await getAllCharacters();
  const character = characters.find(c => c.id === characterId);
  if (!character) {
    throw new Error(`Companion ${characterId} not found`);
  }

  const gifts = Array.isArray(character.randomGifts) && character.randomGifts.length > 0
    ? character.randomGifts
    : [];

  if (gifts.length === 0) {
    return {
      success: true,
      giftDropped: false,
      message: 'No gifts currently configured for this companion.'
    };
  }

  // Calculate weighted random selection based on dropChance
  const totalWeight = gifts.reduce((sum, g) => sum + Math.max(0.1, Number(g.dropChance) || 10), 0);
  let randomRoll = Math.random() * totalWeight;
  let selectedGift = gifts[0];

  for (const g of gifts) {
    const w = Math.max(0.1, Number(g.dropChance) || 10);
    if (randomRoll <= w) {
      selectedGift = g;
      break;
    }
    randomRoll -= w;
  }

  const progressMap = await getUserCharacterProgress(cleanId);
  const charProgress = progressMap[characterId];

  let newCoinsBalance: number | undefined;
  const coinsAwarded = selectedGift.rewardCoins || 0;
  const lovePointsAwarded = selectedGift.rewardLovePoints || 0;

  // 1. Credit coins if any
  if (coinsAwarded > 0) {
    const userProfile = await getUserCardProfile(cleanId);
    userProfile.coins = (userProfile.coins || 0) + coinsAwarded;
    await saveUserProfile(userProfile);
    newCoinsBalance = userProfile.coins;

    await recordTransaction({
      type: 'ADMIN_GIFT',
      userId: cleanId,
      username: userProfile.username,
      amount: coinsAwarded,
      balanceAfter: userProfile.coins,
      performedBy: 'SYSTEM',
      reason: `Companion Surprise Gift: ${selectedGift.name}`
    });
  }

  // 2. Credit love points if any
  if (lovePointsAwarded > 0 && charProgress) {
    charProgress.lovePoints += lovePointsAwarded;
    const thresholds = await getLoveThresholds();
    const calc = calculateLevelFromPoints(charProgress.lovePoints, thresholds);
    charProgress.level = calc.level;
    const activeStage = computeActiveStage(character, calc.level);
    charProgress.currentStageNumber = activeStage.stageNumber;
  }

  // 3. Add gift item to user inventory
  const inventory = await getUserInventory(cleanId);
  const itemId = selectedGift.rewardItemId || selectedGift.id;
  const now = new Date().toISOString();

  if (inventory[itemId]) {
    inventory[itemId].count += 1;
    inventory[itemId].lastAcquiredAt = now;
  } else {
    inventory[itemId] = {
      itemId,
      count: 1,
      firstAcquiredAt: now,
      lastAcquiredAt: now,
      itemData: {
        name: selectedGift.name,
        nameAr: selectedGift.nameAr,
        imageUrl: selectedGift.imageUrl,
        rarity: selectedGift.rarity
      }
    };
  }
  await saveUserInventory(cleanId, inventory);

  // 4. Update progress timestamp
  if (charProgress) {
    charProgress.lastRandomGiftClaimAt = now;
    await saveUserProgress(cleanId, progressMap);
  }

  return {
    success: true,
    giftDropped: true,
    gift: selectedGift,
    coinsAwarded,
    lovePointsAwarded,
    itemAddedToInventory: true,
    newCoinsBalance,
    newLovePoints: charProgress?.lovePoints,
    lastClaimAt: now,
    message: `Received ${selectedGift.name}!`
  };
}

// ----------------------------------------------------
// SPECIAL 3-DAY REWARDS CONFIG & ACTIONS
// ----------------------------------------------------
export async function getSpecialRewardsConfig(forceRefresh = false): Promise<SpecialRewardsConfig> {
  if (hasLoadedSpecialRewards && !forceRefresh) {
    return specialRewardsConfig;
  }

  try {
    const db = getFirestoreInstance();
    if (db) {
      const snap = await getDoc(doc(db, 'site_settings', 'character_love_special_rewards'));
      if (snap.exists()) {
        const data = snap.data() as SpecialRewardsConfig;
        if (data && Array.isArray(data.rewards) && data.rewards.length > 0) {
          specialRewardsConfig = {
            cycleHours: typeof data.cycleHours === 'number' && data.cycleHours > 0 ? data.cycleHours : 72,
            rewards: data.rewards,
            updatedAt: data.updatedAt || new Date().toISOString(),
            updatedBy: data.updatedBy
          };
        }
      }
    }
  } catch (err: any) {
    console.warn('CharacterLoveService: Note reading special rewards from Firestore:', err?.message);
  }

  hasLoadedSpecialRewards = true;
  return specialRewardsConfig;
}

export async function ownerSaveSpecialRewardsConfig(
  configData: Partial<SpecialRewardsConfig>,
  ownerUsername: string
): Promise<SpecialRewardsConfig> {
  const cycleHours = typeof configData.cycleHours === 'number' && configData.cycleHours > 0
    ? Math.max(1, Math.min(720, configData.cycleHours))
    : (specialRewardsConfig.cycleHours || 72);

  const rawRewards = Array.isArray(configData.rewards) ? configData.rewards : specialRewardsConfig.rewards;
  const sanitizedRewards: SpecialRewardDefinition[] = rawRewards.map((r, i) => ({
    id: r.id || `spec_reward_${Date.now()}_${i}`,
    type: r.type === 'ITEM' ? 'ITEM' : 'PACKAGE',
    name: r.name?.trim() || `Special Reward ${i + 1}`,
    nameAr: r.nameAr?.trim() || `مكافأة خاصة ${i + 1}`,
    rarity: r.rarity || 'RARE',
    packageId: r.type === 'PACKAGE' ? (r.packageId || 'RARE') : undefined,
    itemId: r.type === 'ITEM' ? (r.itemId || 'item_date_honey') : undefined,
    dropWeight: typeof r.dropWeight === 'number' && r.dropWeight > 0 ? r.dropWeight : 10,
    bonusCoins: typeof r.bonusCoins === 'number' ? Math.max(0, r.bonusCoins) : 0,
    bonusLovePoints: typeof r.bonusLovePoints === 'number' ? Math.max(0, r.bonusLovePoints) : 0,
    iconUrl: r.iconUrl?.trim(),
    description: r.description?.trim(),
    descriptionAr: r.descriptionAr?.trim(),
    isActive: r.isActive !== false
  }));

  specialRewardsConfig = {
    cycleHours,
    rewards: sanitizedRewards,
    updatedAt: new Date().toISOString(),
    updatedBy: ownerUsername
  };
  hasLoadedSpecialRewards = true;

  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'site_settings', 'character_love_special_rewards'), specialRewardsConfig, { merge: true });
    }
  } catch (err: any) {
    console.warn('CharacterLoveService: Error saving special rewards to Firestore:', err?.message);
  }

  return specialRewardsConfig;
}

export async function ownerResetSpecialRewardCooldown(
  targetDiscordId: string,
  characterId: string
): Promise<UserCharacterProgress> {
  const cleanId = String(targetDiscordId).trim();
  const progressMap = await getUserCharacterProgress(cleanId);
  const charProgress = progressMap[characterId];
  if (!charProgress) {
    throw new Error(`Companion progress for ${characterId} not found.`);
  }

  delete charProgress.lastSpecialRewardClaimAt;
  charProgress.lastInteractedAt = new Date().toISOString();
  await saveUserProgress(cleanId, progressMap);

  return charProgress;
}

export async function ownerUpdateStageCoins(
  characterId: string,
  stageNumber: number,
  passiveCoins: number
): Promise<CharacterDefinition> {
  const characters = await getAllCharacters();
  const character = characters.find(c => c.id === characterId);
  if (!character) {
    throw new Error(`Character ${characterId} not found`);
  }

  const stage = character.stages.find(s => s.stageNumber === stageNumber);
  if (!stage) {
    throw new Error(`Stage ${stageNumber} not found on character ${characterId}`);
  }

  stage.passiveCoinReward = Math.max(0, Math.floor(passiveCoins));
  character.updatedAt = new Date().toISOString();

  // Save character
  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'character_love_characters', character.id), character, { merge: true });
    }
  } catch (err: any) {
    console.warn('CharacterLoveService: Error updating stage coins in Firestore:', err?.message);
  }

  return character;
}

export async function claimSpecialReward(
  discordId: string,
  characterId: string
): Promise<ClaimSpecialRewardResult> {
  const cleanId = String(discordId).trim();
  const characters = await getAllCharacters();
  const character = characters.find(c => c.id === characterId);
  if (!character) {
    throw new Error(`Companion ${characterId} not found`);
  }

  const progressMap = await getUserCharacterProgress(cleanId);
  let charProgress = progressMap[characterId];
  if (!charProgress) {
    charProgress = {
      characterId,
      lovePoints: 0,
      level: 1,
      currentStageNumber: 1,
      totalGiftsGiven: 0,
      lastInteractedAt: new Date().toISOString(),
      unlockedStageNumbers: [1]
    };
    progressMap[characterId] = charProgress;
  }

  // Load Special Rewards Configuration
  const config = await getSpecialRewardsConfig();
  const activeRewards = config.rewards.filter(r => r.isActive !== false);
  if (activeRewards.length === 0) {
    throw new Error('No special rewards currently configured by the Owner.');
  }

  // Validate 3-day cycle cooldown
  const cycleHours = config.cycleHours || 72;
  const cooldownMs = cycleHours * 60 * 60 * 1000;
  const now = Date.now();

  if (charProgress.lastSpecialRewardClaimAt) {
    const lastClaim = new Date(charProgress.lastSpecialRewardClaimAt).getTime();
    const elapsed = now - lastClaim;
    if (elapsed < cooldownMs) {
      const remainingMs = cooldownMs - elapsed;
      const nextClaimDate = new Date(lastClaim + cooldownMs).toISOString();
      throw new Error(`COOLDOWN_ACTIVE:${remainingMs}:${nextClaimDate}`);
    }
  }

  // Weighted random selection strictly from owner-configured rewards
  const totalWeight = activeRewards.reduce((sum, r) => sum + Math.max(0.1, Number(r.dropWeight) || 10), 0);
  let roll = Math.random() * totalWeight;
  let selectedReward = activeRewards[0];

  for (const r of activeRewards) {
    const w = Math.max(0.1, Number(r.dropWeight) || 10);
    if (roll <= w) {
      selectedReward = r;
      break;
    }
    roll -= w;
  }

  let drawnCard: any = null;
  let awardedItemName = selectedReward.name;
  let awardedItemNameAr = selectedReward.nameAr;

  // 1. Grant Package or Item
  if (selectedReward.type === 'PACKAGE') {
    const packType = selectedReward.packageId || 'RARE';
    try {
      const packResult = await openCardPack(cleanId, packType, undefined, {
        isFree: true,
        reason: `3-Day Special Companion Reward from ${character.name}`
      });
      if (packResult && packResult.openedCard) {
        drawnCard = packResult.openedCard;
      }
    } catch (packErr: any) {
      console.warn('Notice granting pack card in claimSpecialReward:', packErr?.message);
    }
  } else {
    // Add Item to user love inventory
    const itemId = selectedReward.itemId || 'item_date_honey';
    const items = await getAllItems();
    const itemDef = items.find(i => i.id === itemId);
    if (itemDef) {
      awardedItemName = itemDef.name;
      awardedItemNameAr = itemDef.nameAr;
    }

    const inventory = await getUserInventory(cleanId);
    const nowIso = new Date(now).toISOString();

    if (inventory[itemId]) {
      inventory[itemId].count += 1;
      inventory[itemId].lastAcquiredAt = nowIso;
    } else {
      inventory[itemId] = {
        itemId,
        count: 1,
        firstAcquiredAt: nowIso,
        lastAcquiredAt: nowIso,
        itemData: {
          name: itemDef?.name || selectedReward.name,
          nameAr: itemDef?.nameAr || selectedReward.nameAr,
          imageUrl: itemDef?.imageUrl || selectedReward.iconUrl,
          rarity: itemDef?.rarity || selectedReward.rarity
        }
      };
    }
    await saveUserInventory(cleanId, inventory);
  }

  // 2. Bonus Coins
  const coinsAwarded = selectedReward.bonusCoins || 0;
  const userProfile = await getUserCardProfile(cleanId);
  if (coinsAwarded > 0) {
    userProfile.coins = (userProfile.coins || 0) + coinsAwarded;
    await saveUserProfile(userProfile);

    await recordTransaction({
      type: 'ADMIN_GIFT',
      userId: cleanId,
      username: userProfile.username,
      amount: coinsAwarded,
      balanceAfter: userProfile.coins,
      performedBy: 'SYSTEM',
      reason: `3-Day Special Reward Bonus: ${selectedReward.name} from ${character.name}`
    });
  }

  // 3. Bonus Love Points
  const lovePointsAwarded = selectedReward.bonusLovePoints || 0;
  if (lovePointsAwarded > 0) {
    charProgress.lovePoints += lovePointsAwarded;
    const thresholds = await getLoveThresholds();
    const calc = calculateLevelFromPoints(charProgress.lovePoints, thresholds);
    charProgress.level = calc.level;
    const activeStage = computeActiveStage(character, calc.level);
    charProgress.currentStageNumber = activeStage.stageNumber;
  }

  // 4. Update timestamps
  const claimTimestamp = new Date(now).toISOString();
  charProgress.lastSpecialRewardClaimAt = claimTimestamp;
  charProgress.lastInteractedAt = claimTimestamp;
  await saveUserProgress(cleanId, progressMap);

  const nextSpecialRewardAvailableAt = new Date(now + cooldownMs).toISOString();

  return {
    success: true,
    characterId,
    reward: selectedReward,
    awardedType: selectedReward.type,
    awardedPackageId: selectedReward.packageId,
    awardedItemId: selectedReward.itemId,
    awardedItemName,
    awardedItemNameAr,
    drawnCard,
    coinsAwarded,
    lovePointsAwarded,
    newBalance: userProfile.coins,
    lastSpecialRewardClaimAt: claimTimestamp,
    nextSpecialRewardAvailableAt,
    message: `Received 3-Day Special Favor: ${selectedReward.name}!`
  };
}
