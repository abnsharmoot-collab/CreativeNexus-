import fs from 'fs';
import path from 'path';
import { getFirestoreInstance } from './discordStaffSync';
import { doc, getDoc, setDoc, getDocs, collection, deleteDoc } from 'firebase/firestore';
import { STORY_CHAPTERS as DEFAULT_STORY_CHAPTERS } from '../src/config/storyConfig';
import { StoryBattleDefinition, StoryChapterDefinition, UserStoryProgress } from '../src/types/story';
import { getUserCardProfile, saveUserProfile, recordTransaction } from './cardService';
import { calculateLevelProgression, XP_CONFIG } from '../src/config/progressionConfig';

// In-memory cache for fast story progression
const storyProgressCache = new Map<string, UserStoryProgress>();

// Dynamic battles & chapters storage
const STORY_DATA_FILE = path.join(process.cwd(), 'server', 'story-battles-data.json');
let dynamicBattles: StoryBattleDefinition[] = [];
let deletedBattleIds = new Set<string>();
let dynamicChapters: StoryChapterDefinition[] = [];
let deletedChapterIds = new Set<string>();
let isInitialized = false;

function loadLocalStoryBattles(): void {
  try {
    if (fs.existsSync(STORY_DATA_FILE)) {
      const raw = fs.readFileSync(STORY_DATA_FILE, 'utf-8');
      const data = JSON.parse(raw);
      if (Array.isArray(data.customBattles)) {
        dynamicBattles = data.customBattles;
      }
      if (Array.isArray(data.deletedBattleIds)) {
        deletedBattleIds = new Set(data.deletedBattleIds);
      }
      if (Array.isArray(data.customChapters)) {
        dynamicChapters = data.customChapters;
      }
      if (Array.isArray(data.deletedChapterIds)) {
        deletedChapterIds = new Set(data.deletedChapterIds);
      }
    }
  } catch (err) {
    console.warn('StoryService: Could not load local story battles data:', err);
  }
}

function persistLocalStoryBattles(): void {
  try {
    const data = {
      customBattles: dynamicBattles,
      deletedBattleIds: Array.from(deletedBattleIds),
      customChapters: dynamicChapters,
      deletedChapterIds: Array.from(deletedChapterIds)
    };
    fs.writeFileSync(STORY_DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.warn('StoryService: Failed to persist local story battles:', err);
  }
}

/**
 * Initialize dynamic story battles and chapters from Firestore with file fallback
 */
export async function initializeStoryBattles(): Promise<void> {
  if (isInitialized) return;
  loadLocalStoryBattles();

  try {
    const db = getFirestoreInstance();
    if (db) {
      // 1. Load custom chapters
      const chapSnap = await Promise.race([
        getDocs(collection(db, 'story_chapters')),
        new Promise<any>((_, reject) => setTimeout(() => reject(new Error('Firestore read timeout')), 3000))
      ]).catch(() => null);

      if (chapSnap && !chapSnap.empty) {
        const firestoreChapters: StoryChapterDefinition[] = [];
        chapSnap.forEach(docSnap => {
          const d = docSnap.data() as StoryChapterDefinition;
          if (d && d.id) {
            firestoreChapters.push(d);
          }
        });
        if (firestoreChapters.length > 0) {
          const cMap = new Map<string, StoryChapterDefinition>();
          dynamicChapters.forEach(c => cMap.set(c.id, c));
          firestoreChapters.forEach(c => cMap.set(c.id, c));
          dynamicChapters = Array.from(cMap.values());
        }
      }

      // 2. Load custom battles
      const snap = await Promise.race([
        getDocs(collection(db, 'story_battles')),
        new Promise<any>((_, reject) => setTimeout(() => reject(new Error('Firestore read timeout')), 3000))
      ]).catch(() => null);

      if (snap && !snap.empty) {
        const firestoreBattles: StoryBattleDefinition[] = [];
        snap.forEach(docSnap => {
          const d = docSnap.data() as StoryBattleDefinition;
          if (d && d.id) {
            firestoreBattles.push(d);
          }
        });

        if (firestoreBattles.length > 0) {
          // Merge with local
          const map = new Map<string, StoryBattleDefinition>();
          dynamicBattles.forEach(b => map.set(b.id, b));
          firestoreBattles.forEach(b => map.set(b.id, b));
          dynamicBattles = Array.from(map.values());
        }
      }

      persistLocalStoryBattles();
    }
  } catch (err: any) {
    console.warn('StoryService: Firestore init error, using local fallback:', err?.message);
  }

  isInitialized = true;
}

/**
 * Get all story chapters merged with owner-customized chapters & battles
 */
export async function getAllStoryChapters(): Promise<StoryChapterDefinition[]> {
  await initializeStoryBattles();

  // Clone default chapters
  const baseChapters: StoryChapterDefinition[] = JSON.parse(JSON.stringify(DEFAULT_STORY_CHAPTERS));

  // Merge dynamic chapters
  const chaptersMap = new Map<string, StoryChapterDefinition>();
  for (const c of baseChapters) {
    if (!deletedChapterIds.has(c.id)) {
      chaptersMap.set(c.id, c);
    }
  }

  // Overlay / add custom chapters
  for (const c of dynamicChapters) {
    if (deletedChapterIds.has(c.id)) continue;
    const existing = chaptersMap.get(c.id);
    if (existing) {
      chaptersMap.set(c.id, {
        ...existing,
        ...c,
        battles: existing.battles // preserve battles
      });
    } else {
      chaptersMap.set(c.id, {
        ...c,
        battles: Array.isArray(c.battles) ? c.battles : []
      });
    }
  }

  const chapters = Array.from(chaptersMap.values());

  // Remove deleted battles across all chapters
  chapters.forEach(ch => {
    ch.battles = (ch.battles || []).filter(b => !deletedBattleIds.has(b.id));
  });

  // Apply or append dynamic battles
  for (const customBattle of dynamicBattles) {
    if (deletedBattleIds.has(customBattle.id)) continue;

    const targetChapter = chapters.find(c => c.id === customBattle.chapterId) || chapters[0];
    if (!targetChapter) continue;

    if (!Array.isArray(targetChapter.battles)) {
      targetChapter.battles = [];
    }

    const existingIndex = targetChapter.battles.findIndex(b => b.id === customBattle.id);

    if (existingIndex !== -1) {
      targetChapter.battles[existingIndex] = customBattle;
    } else {
      targetChapter.battles.push(customBattle);
    }
  }

  // Ensure battle numbering is sequential within each chapter
  chapters.forEach((ch, chIdx) => {
    ch.chapterNumber = chIdx + 1;
    ch.battles.forEach((b, bIdx) => {
      b.battleNumber = bIdx + 1;
    });
  });

  return chapters;
}

/**
 * Save / Create / Update a story chapter definition (Owner only)
 */
export async function saveStoryChapter(chapterData: Partial<StoryChapterDefinition>): Promise<{ success: boolean; chapter: StoryChapterDefinition; error?: string }> {
  await initializeStoryBattles();

  const id = chapterData.id && chapterData.id.trim() ? chapterData.id.trim() : `chapter_${Date.now()}`;
  const title = chapterData.title?.trim() || 'New Story Chapter';
  const titleAr = chapterData.titleAr?.trim() || title;
  const subtitle = chapterData.subtitle?.trim() || 'Chapter Chronicle';
  const subtitleAr = chapterData.subtitleAr?.trim() || subtitle;
  const description = chapterData.description?.trim() || 'Explore an uncharted realm of tactical card warfare.';
  const descriptionAr = chapterData.descriptionAr?.trim() || description;
  const bannerImageUrl = chapterData.bannerImageUrl?.trim() || '/src/assets/images/mesopotamian_hero_bg_1789787787421.jpg';
  const accentColor = chapterData.accentColor || '#2dd4bf';
  const badgeText = chapterData.badgeText?.trim() || 'NEW CHAPTER';
  const badgeTextAr = chapterData.badgeTextAr?.trim() || 'فصل جديد';

  const fullChapter: StoryChapterDefinition = {
    id,
    chapterNumber: chapterData.chapterNumber || (dynamicChapters.length + 2),
    title,
    titleAr,
    subtitle,
    subtitleAr,
    description,
    descriptionAr,
    bannerImageUrl,
    accentColor,
    badgeText,
    badgeTextAr,
    battles: Array.isArray(chapterData.battles) ? chapterData.battles : []
  };

  deletedChapterIds.delete(id);

  const existingIdx = dynamicChapters.findIndex(c => c.id === id);
  if (existingIdx !== -1) {
    dynamicChapters[existingIdx] = {
      ...dynamicChapters[existingIdx],
      ...fullChapter,
      battles: dynamicChapters[existingIdx].battles.length > 0 ? dynamicChapters[existingIdx].battles : fullChapter.battles
    };
  } else {
    dynamicChapters.push(fullChapter);
  }

  persistLocalStoryBattles();

  try {
    const db = getFirestoreInstance();
    if (db) {
      setDoc(doc(db, 'story_chapters', id), fullChapter, { merge: true }).catch(err => {
        console.warn('StoryService: Firestore chapter write error:', err);
      });
    }
  } catch {}

  return { success: true, chapter: fullChapter };
}

/**
 * Delete a story chapter (Owner only)
 */
export async function deleteStoryChapter(chapterId: string): Promise<{ success: boolean; error?: string }> {
  await initializeStoryBattles();
  const cleanId = String(chapterId).trim();

  deletedChapterIds.add(cleanId);
  dynamicChapters = dynamicChapters.filter(c => c.id !== cleanId);

  persistLocalStoryBattles();

  try {
    const db = getFirestoreInstance();
    if (db) {
      deleteDoc(doc(db, 'story_chapters', cleanId)).catch(() => {});
    }
  } catch {}

  return { success: true };
}

/**
 * Find a story battle definition by ID across dynamic and default definitions
 */
export async function getStoryBattleById(battleId: string): Promise<{ battle: StoryBattleDefinition; chapter: StoryChapterDefinition } | null> {
  const chapters = await getAllStoryChapters();
  for (const chapter of chapters) {
    const battle = chapter.battles.find(b => b.id === battleId);
    if (battle) return { battle, chapter };
  }
  return null;
}

/**
 * Save / Create / Update a story battle definition (Owner only)
 */
export async function saveStoryBattle(battleData: Partial<StoryBattleDefinition>): Promise<{ success: boolean; battle: StoryBattleDefinition; error?: string }> {
  await initializeStoryBattles();

  const id = battleData.id && battleData.id.trim() ? battleData.id.trim() : `battle_${Date.now()}`;
  const chapterId = battleData.chapterId || 'chapter_1';
  const name = battleData.name?.trim() || 'Custom Story Clash';
  const nameAr = battleData.nameAr?.trim() || name;
  const title = battleData.title?.trim() || 'Vanguard Defense Protocol';
  const titleAr = battleData.titleAr?.trim() || title;
  const description = battleData.description?.trim() || 'A powerful hostile formation engages your active deck.';
  const descriptionAr = battleData.descriptionAr?.trim() || description;
  const introText = battleData.introText?.trim() || 'Prepare your active champion for tactical engagement.';
  const introTextAr = battleData.introTextAr?.trim() || introText;
  const difficulty = battleData.difficulty || 'NORMAL';
  const fightType = battleData.fightType || (battleData.difficulty === 'CHAPTER_FINALE' ? 'CHAPTER_FINALE' : battleData.difficulty === 'BOSS' ? 'BOSS' : 'NORMAL');
  const isChapterFinale = Boolean(battleData.isChapterFinale || difficulty === 'CHAPTER_FINALE' || fightType === 'CHAPTER_FINALE');
  const enemyCommanderName = battleData.enemyCommanderName?.trim() || 'Ancient Overlord';
  const enemyCommanderNameAr = battleData.enemyCommanderNameAr?.trim() || enemyCommanderName;
  const enemyCommanderAvatar = battleData.enemyCommanderAvatar?.trim() || '/src/assets/images/meso_king_relief_1789787818475.jpg';
  const backgroundImageUrl = battleData.backgroundImageUrl?.trim() || '';
  const customCharacterName = battleData.customCharacterName?.trim() || enemyCommanderName;
  const customCharacterNameAr = battleData.customCharacterNameAr?.trim() || enemyCommanderNameAr;

  // Ensure strictly 1 to 4 cards
  const enemyDeckCardIds = Array.isArray(battleData.enemyDeckCardIds) && battleData.enemyDeckCardIds.length > 0
    ? battleData.enemyDeckCardIds.slice(0, 4)
    : ['card_kinetic_scout', 'card_core_recruit'];

  const rewardCoins = typeof battleData.rewardCoins === 'number' && battleData.rewardCoins >= 0 ? battleData.rewardCoins : 50;
  const rewardXp = typeof battleData.rewardXp === 'number' && battleData.rewardXp >= 0 ? battleData.rewardXp : 60;
  const firstClearBonusCoins = typeof battleData.firstClearBonusCoins === 'number' && battleData.firstClearBonusCoins >= 0 ? battleData.firstClearBonusCoins : 40;
  const unlockRequirementId = battleData.unlockRequirementId !== undefined ? battleData.unlockRequirementId : null;

  const fullBattle: StoryBattleDefinition = {
    id,
    chapterId,
    battleNumber: battleData.battleNumber || 1,
    name,
    nameAr,
    title,
    titleAr,
    description,
    descriptionAr,
    introText,
    introTextAr,
    difficulty,
    fightType,
    isChapterFinale,
    enemyCommanderName,
    enemyCommanderNameAr,
    enemyCommanderAvatar,
    backgroundImageUrl,
    customCharacterName,
    customCharacterNameAr,
    enemyDeckCardIds,
    rewardCoins,
    rewardXp,
    firstClearBonusCoins,
    unlockRequirementId
  };

  // Remove from deleted set if was previously deleted
  deletedBattleIds.delete(id);

  // Update in memory
  const existingIdx = dynamicBattles.findIndex(b => b.id === id);
  if (existingIdx !== -1) {
    dynamicBattles[existingIdx] = fullBattle;
  } else {
    dynamicBattles.push(fullBattle);
  }

  // Persist locally
  persistLocalStoryBattles();

  // Persist to Firestore in background
  try {
    const db = getFirestoreInstance();
    if (db) {
      setDoc(doc(db, 'story_battles', id), fullBattle, { merge: true }).catch(err => {
        console.warn('StoryService: Firestore battle write error:', err);
      });
    }
  } catch {}

  return { success: true, battle: fullBattle };
}

/**
 * Delete a story battle (Owner only)
 */
export async function deleteStoryBattle(battleId: string): Promise<{ success: boolean; error?: string }> {
  await initializeStoryBattles();
  const cleanId = String(battleId).trim();

  // Mark in deleted set
  deletedBattleIds.add(cleanId);
  dynamicBattles = dynamicBattles.filter(b => b.id !== cleanId);

  persistLocalStoryBattles();

  // Delete from Firestore
  try {
    const db = getFirestoreInstance();
    if (db) {
      deleteDoc(doc(db, 'story_battles', cleanId)).catch(() => {});
    }
  } catch {}

  return { success: true };
}

/**
 * Get user's story mode progress
 */
export async function getUserStoryProgress(userId: string): Promise<UserStoryProgress> {
  const cleanId = String(userId).trim();
  const cached = storyProgressCache.get(cleanId);
  if (cached) return cached;

  let progress: UserStoryProgress = {
    userId: cleanId,
    completedBattleIds: [],
    claimedRewardBattleIds: [],
    totalBattlesWon: 0,
    totalBattlesLost: 0,
    updatedAt: new Date().toISOString()
  };

  try {
    const db = getFirestoreInstance();
    if (db) {
      const snap = await Promise.race([
        getDoc(doc(db, 'user_story_progress', cleanId)),
        new Promise<any>((_, reject) => setTimeout(() => reject(new Error('Firestore read timeout')), 2500))
      ]);

      if (snap && snap.exists()) {
        const d = snap.data();
        progress = {
          userId: cleanId,
          completedBattleIds: Array.isArray(d?.completedBattleIds) ? d.completedBattleIds : [],
          claimedRewardBattleIds: Array.isArray(d?.claimedRewardBattleIds) ? d.claimedRewardBattleIds : [],
          totalBattlesWon: typeof d?.totalBattlesWon === 'number' ? d.totalBattlesWon : 0,
          totalBattlesLost: typeof d?.totalBattlesLost === 'number' ? d.totalBattlesLost : 0,
          updatedAt: d?.updatedAt || new Date().toISOString()
        };
      }
    }
  } catch (err: any) {
    console.warn('StoryService: Firestore read progress error:', err?.message);
  }

  storyProgressCache.set(cleanId, progress);
  return progress;
}

/**
 * Record a story mode battle result and award validated coins server-side
 */
export async function recordStoryBattleCompletion(
  userId: string,
  battleId: string,
  outcome: 'VICTORY' | 'DEFEAT'
): Promise<{
  success: boolean;
  progress: UserStoryProgress;
  coinsAwarded: number;
  xpAwarded: number;
  isFirstClear: boolean;
  newBalance: number;
  message: string;
}> {
  const cleanId = String(userId).trim();
  const battleLookup = await getStoryBattleById(battleId);

  if (!battleLookup) {
    throw new Error('Battle definition not found');
  }

  const { battle } = battleLookup;
  const progress = await getUserStoryProgress(cleanId);
  const profile = await getUserCardProfile(cleanId);

  if (outcome === 'DEFEAT') {
    progress.totalBattlesLost += 1;
    progress.updatedAt = new Date().toISOString();
    storyProgressCache.set(cleanId, progress);

    try {
      const db = getFirestoreInstance();
      if (db) {
        setDoc(doc(db, 'user_story_progress', cleanId), progress, { merge: true }).catch(() => {});
      }
    } catch {}

    return {
      success: true,
      progress,
      coinsAwarded: 0,
      xpAwarded: 10,
      isFirstClear: false,
      newBalance: profile.coins,
      message: 'Defeat recorded. Re-evaluate your squad formation and try again!'
    };
  }

  // --- VICTORY OUTCOME ---
  if (battle.unlockRequirementId && !progress.completedBattleIds.includes(battle.unlockRequirementId)) {
    throw new Error('Unlock requirement not met. Previous battle must be completed first.');
  }

  const isFirstClear = !progress.claimedRewardBattleIds.includes(battleId);

  const baseCoins = battle.rewardCoins;
  const firstClearBonus = isFirstClear ? battle.firstClearBonusCoins : 0;
  const replayCoins = isFirstClear ? baseCoins : Math.round(baseCoins * 0.35);
  const totalCoinsAwarded = isFirstClear ? (baseCoins + firstClearBonus) : replayCoins;
  const xpAwarded = battle.rewardXp;

  if (!progress.completedBattleIds.includes(battleId)) {
    progress.completedBattleIds.push(battleId);
  }
  if (isFirstClear) {
    progress.claimedRewardBattleIds.push(battleId);
  }
  progress.totalBattlesWon += 1;
  progress.updatedAt = new Date().toISOString();

  profile.coins += totalCoinsAwarded;
  profile.xp = (profile.xp || 0) + xpAwarded;
  profile.level = calculateLevelProgression(profile.xp).level;
  profile.updatedAt = new Date().toISOString();

  await saveUserProfile(profile);

  try {
    const db = getFirestoreInstance();
    if (db) {
      setDoc(doc(db, 'user_story_progress', cleanId), progress, { merge: true }).catch(() => {});
    }
  } catch {}

  return {
    success: true,
    progress,
    coinsAwarded: totalCoinsAwarded,
    xpAwarded,
    isFirstClear,
    newBalance: profile.coins,
    message: isFirstClear
      ? `Victory! First-clear bonus unlocked! Earned ${totalCoinsAwarded} coins and ${xpAwarded} XP!`
      : `Victory recorded! Earned ${totalCoinsAwarded} replay coins and ${xpAwarded} XP!`
  };
}
