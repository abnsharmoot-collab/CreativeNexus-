import crypto from 'crypto';
import { getFirestoreInstance } from './discordStaffSync';
import { doc, getDoc, setDoc, deleteDoc, collection, getDocs, query, where } from 'firebase/firestore';
import { PlayerDeck, MAX_DECK_CARDS, MIN_DECK_CARDS, calculateDeckStats } from '../src/types/decks';
import { getUserCardProfile, loadCustomCardsFromFirestore, STARTER_CARD_IDS } from './cardService';
import { CollectibleCardData } from '../src/types/cards';

// In-memory cache for fast responsive lookups
const userDecksCache = new Map<string, PlayerDeck[]>();

/**
 * Get all decks for a user.
 * If user has no decks, automatically provisions a default starter deck (up to 4 starter cards).
 */
export async function getUserDecks(
  userId: string,
  userMeta?: { username?: string; displayName?: string; avatarUrl?: string }
): Promise<PlayerDeck[]> {
  const cleanId = String(userId).trim();
  const cached = userDecksCache.get(cleanId);
  if (cached && cached.length > 0) {
    return cached;
  }

  const loadedDecks: PlayerDeck[] = [];

  try {
    const db = getFirestoreInstance();
    if (db) {
      // Query decks where userId == cleanId
      const q = query(collection(db, 'user_decks'), where('userId', '==', cleanId));
      const snap = await Promise.race([
        getDocs(q),
        new Promise<any>((_, reject) => setTimeout(() => reject(new Error('Firestore read timeout')), 2500))
      ]);

      if (snap && !snap.empty) {
        snap.forEach(d => {
          const data = d.data() as PlayerDeck;
          if (data && data.id && Array.isArray(data.cardIds)) {
            loadedDecks.push(data);
          }
        });
      }
    }
  } catch (err: any) {
    console.warn('DeckService: Firestore error reading decks:', err?.message);
  }

  // If no decks found, provision a starter deck
  if (loadedDecks.length === 0) {
    const profile = await getUserCardProfile(cleanId, userMeta);
    const catalog = await loadCustomCardsFromFirestore(true);

    // Pick up to 4 owned cards (or fallback to starter card IDs)
    const ownedIds = Object.keys(profile.cards || {});
    let starterCards = ownedIds.length > 0
      ? ownedIds.slice(0, MAX_DECK_CARDS)
      : STARTER_CARD_IDS.slice(0, MAX_DECK_CARDS);

    // Find cards in catalog to compute stats
    const resolvedCards = starterCards
      .map(id => catalog.find(c => c.id === id))
      .filter((c): c is CollectibleCardData => Boolean(c));

    const stats = calculateDeckStats(resolvedCards);
    const now = new Date().toISOString();

    const initialDeck: PlayerDeck = {
      id: `deck_starter_${cleanId.slice(-6)}`,
      userId: cleanId,
      name: 'Nexus Vanguard Alpha',
      banner: 'astral_void',
      cardIds: starterCards,
      isActive: true,
      power: stats.power,
      defense: stats.defense,
      speed: stats.speed,
      synergy: stats.synergy,
      createdAt: now,
      updatedAt: now
    };

    loadedDecks.push(initialDeck);
    userDecksCache.set(cleanId, loadedDecks);

    // Save to Firestore in background
    try {
      const db = getFirestoreInstance();
      if (db) {
        setDoc(doc(db, 'user_decks', initialDeck.id), initialDeck).catch(() => {});
      }
    } catch {}

    return loadedDecks;
  }

  // Ensure at least one deck is active
  if (!loadedDecks.some(d => d.isActive)) {
    loadedDecks[0].isActive = true;
  }

  userDecksCache.set(cleanId, loadedDecks);
  return loadedDecks;
}

/**
 * Save or update a deck with server-side validation:
 * - Deck must belong to authenticated user
 * - Card count must be between 1 and 4
 * - No duplicate card IDs
 * - All cards must be owned by user
 * - Calculates Power, Defense, Speed, Synergy server-side
 */
export async function saveUserDeck(
  userId: string,
  deckData: {
    id?: string;
    name: string;
    banner?: string;
    cardIds: string[];
    itemIds?: string[];
    isActive?: boolean;
  }
): Promise<{ success: boolean; deck?: PlayerDeck; error?: string }> {
  const cleanId = String(userId).trim();
  const { name, banner, cardIds, itemIds, isActive } = deckData;

  // 1. Validate card count (Rule: Max 4, Min 1)
  if (!Array.isArray(cardIds) || cardIds.length < MIN_DECK_CARDS) {
    return { success: false, error: `A deck must contain at least ${MIN_DECK_CARDS} card.` };
  }
  if (cardIds.length > MAX_DECK_CARDS) {
    return { success: false, error: `A deck cannot contain more than ${MAX_DECK_CARDS} battle cards.` };
  }

  // 2. Validate uniqueness (No duplicate cards in deck)
  const uniqueCardIds = Array.from(new Set(cardIds));
  if (uniqueCardIds.length !== cardIds.length) {
    return { success: false, error: 'A deck cannot contain duplicate cards.' };
  }

  // 3. Validate user ownership of each card
  const profile = await getUserCardProfile(cleanId);
  const ownedCards = profile.cards || {};

  for (const cardId of cardIds) {
    if (!ownedCards[cardId] || ownedCards[cardId].count <= 0) {
      return {
        success: false,
        error: `Validation failed: Card ID [${cardId}] is not in your collection.`
      };
    }
  }

  // 4. Resolve card data to calculate stats server-side
  const catalog = await loadCustomCardsFromFirestore(true);
  const resolvedCards: CollectibleCardData[] = [];
  for (const cardId of cardIds) {
    const found = catalog.find(c => c.id === cardId);
    if (!found) {
      return { success: false, error: `Card ID [${cardId}] could not be found in the catalog.` };
    }
    resolvedCards.push(found);
  }

  const stats = calculateDeckStats(resolvedCards);
  const now = new Date().toISOString();

  // Load existing decks
  const existingDecks = await getUserDecks(cleanId);
  const deckId = deckData.id && deckData.id.trim()
    ? deckData.id.trim()
    : `deck_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;

  const shouldBeActive = typeof isActive === 'boolean'
    ? isActive
    : existingDecks.length === 0;

  // Sanitize up to 4 chosen consumables
  const sanitizedItemIds = Array.isArray(itemIds)
    ? itemIds.filter(id => typeof id === 'string' && id.trim().length > 0).slice(0, 4)
    : undefined;

  const targetDeck: PlayerDeck = {
    id: deckId,
    userId: cleanId,
    name: (name || 'Battle Formation').trim().slice(0, 40),
    banner: banner || 'astral_void',
    cardIds,
    itemIds: sanitizedItemIds,
    isActive: shouldBeActive,
    power: stats.power,
    defense: stats.defense,
    speed: stats.speed,
    synergy: stats.synergy,
    createdAt: now,
    updatedAt: now
  };

  // If this deck is active, deactivate other decks
  let updatedDecks: PlayerDeck[];
  const existingIdx = existingDecks.findIndex(d => d.id === deckId);

  if (shouldBeActive) {
    existingDecks.forEach(d => {
      if (d.id !== deckId) d.isActive = false;
    });
  }

  if (existingIdx >= 0) {
    targetDeck.createdAt = existingDecks[existingIdx].createdAt || now;
    existingDecks[existingIdx] = targetDeck;
    updatedDecks = existingDecks;
  } else {
    updatedDecks = [targetDeck, ...existingDecks];
  }

  userDecksCache.set(cleanId, updatedDecks);

  // Persist to Firestore
  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'user_decks', targetDeck.id), targetDeck);
      if (shouldBeActive) {
        // Also update other decks to isActive: false
        for (const other of updatedDecks) {
          if (other.id !== deckId) {
            setDoc(doc(db, 'user_decks', other.id), { isActive: false }, { merge: true }).catch(() => {});
          }
        }
      }
    }
  } catch (err: any) {
    console.warn('DeckService: Firestore error saving deck:', err?.message);
  }

  return { success: true, deck: targetDeck };
}

/**
 * Set an existing deck as the Active Deck
 */
export async function setActiveDeck(
  userId: string,
  deckId: string
): Promise<{ success: boolean; activeDeck?: PlayerDeck; error?: string }> {
  const cleanId = String(userId).trim();
  const decks = await getUserDecks(cleanId);
  const target = decks.find(d => d.id === deckId);

  if (!target) {
    return { success: false, error: 'Deck not found or does not belong to you.' };
  }

  // Validate that all cards in the deck are still owned
  const profile = await getUserCardProfile(cleanId);
  const ownedCards = profile.cards || {};
  for (const cid of target.cardIds) {
    if (!ownedCards[cid] || ownedCards[cid].count <= 0) {
      return { success: false, error: 'Deck contains cards no longer in your inventory.' };
    }
  }

  decks.forEach(d => {
    d.isActive = (d.id === deckId);
  });
  userDecksCache.set(cleanId, decks);

  try {
    const db = getFirestoreInstance();
    if (db) {
      for (const d of decks) {
        setDoc(doc(db, 'user_decks', d.id), { isActive: d.isActive }, { merge: true }).catch(() => {});
      }
    }
  } catch {}

  return { success: true, activeDeck: target };
}

/**
 * Delete a deck
 */
export async function deleteUserDeck(
  userId: string,
  deckId: string
): Promise<{ success: boolean; error?: string }> {
  const cleanId = String(userId).trim();
  const decks = await getUserDecks(cleanId);
  const targetIdx = decks.findIndex(d => d.id === deckId);

  if (targetIdx === -1) {
    return { success: false, error: 'Deck not found.' };
  }

  const wasActive = decks[targetIdx].isActive;
  decks.splice(targetIdx, 1);

  if (wasActive && decks.length > 0) {
    decks[0].isActive = true;
  }

  userDecksCache.set(cleanId, decks);

  try {
    const db = getFirestoreInstance();
    if (db) {
      await deleteDoc(doc(db, 'user_decks', deckId));
      if (wasActive && decks.length > 0) {
        setDoc(doc(db, 'user_decks', decks[0].id), { isActive: true }, { merge: true }).catch(() => {});
      }
    }
  } catch (err: any) {
    console.warn('DeckService: Firestore error deleting deck:', err?.message);
  }

  return { success: true };
}

/**
 * Get active deck with populated cards
 */
export async function getActiveDeckWithCards(
  userId: string
): Promise<{ deck: PlayerDeck; cards: CollectibleCardData[] } | null> {
  const decks = await getUserDecks(userId);
  const activeDeck = decks.find(d => d.isActive) || decks[0] || null;
  if (!activeDeck) return null;

  const catalog = await loadCustomCardsFromFirestore(true);
  const cards = activeDeck.cardIds
    .map(id => catalog.find(c => c.id === id))
    .filter((c): c is CollectibleCardData => Boolean(c));

  return { deck: activeDeck, cards };
}
