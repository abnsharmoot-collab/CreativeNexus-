import express from 'express';
import {
  getUserCardProfile,
  claimDailyReward,
  openCardPack,
  toggleCardShowcase,
  ownerGrantCoins,
  getCoinTransactions,
  loadCustomCardsFromFirestore,
  saveCustomCard,
  importCustomCards,
  deleteCustomCard,
  deleteMultipleCustomCards,
  deleteAllCustomCards,
  restoreDefaultStarterCards,
  getOwnerCardStats,
  getPackDefinitions,
  savePackImages,
  savePackCustomizations,
  loadRevealSfxFromFirestore,
  saveRevealSfxSettings,
  getGlobalRatingSettings,
  saveGlobalRatingSettings,
  getPlayerProfileData,
  customizeUserProfile,
  claimAchievementReward,
  exportAllCardsBackup
} from './cardService';
import { requireAuth, requireOwner } from './discordRbac';
import { CARD_PACKS, DEFAULT_COLLECTIBLE_CARDS } from '../src/data/defaultCards';
import { CardRarity } from '../src/types/cards';
import { db } from '../src/db';
import { users, staff } from '../src/db/schema';
import { getFirestoreInstance } from './discordStaffSync';
import { collection, getDocs } from 'firebase/firestore';
import { recordAuditEvent } from './auditService';
import { saveUnifiedItem, getAllUnifiedItems } from './itemService';

export function setupCardRoutes(app: express.Express) {
  const router = express.Router();

  // 1. GET /api/cards/catalog (Public/Auth) - List of packs and available cards
  router.get('/catalog', async (req, res) => {
    try {
      const cards = await loadCustomCardsFromFirestore();
      const packs = await getPackDefinitions();
      const ratingSettings = await getGlobalRatingSettings();
      res.json({
        success: true,
        packs,
        cards,
        totalCards: cards.length,
        ratingSettings
      });
    } catch (err: any) {
      console.error('Error fetching card catalog:', err);
      res.status(500).json({ error: 'Failed to load card catalog' });
    }
  });

  // 1.1 POST /api/cards/owner/rating-settings (Owner only!) - Save OVR number place & size for all cards
  router.post('/owner/rating-settings', requireAuth, requireOwner, async (req, res) => {
    try {
      const owner = req.authUser!;
      const settings = req.body;
      const result = await saveGlobalRatingSettings(owner.displayName || owner.username, settings);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'CARD_VAULT',
        action: `Owner updated global card rating number settings (Size: ${result.ratingSettings.fontSize}px, X: ${result.ratingSettings.offsetX}px, Y: ${result.ratingSettings.offsetY}px)`,
        path: '/api/cards/owner/rating-settings',
        targetElement: 'card_rating_config'
      }, req);

      res.json({
        success: true,
        ratingSettings: result.ratingSettings,
        cards: result.cards
      });
    } catch (err: any) {
      console.error('Error saving rating settings:', err);
      res.status(500).json({ error: err.message || 'Failed to update rating settings' });
    }
  });

  // 2. GET /api/cards/me (Auth required) - Current user coin balance & card collection
  router.get('/me', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const profile = await getUserCardProfile(user.discordId, {
        username: user.username,
        displayName: user.displayName,
        avatarUrl: user.avatarUrl
      });
      const playerProfile = await getPlayerProfileData(user.discordId, user.discordId, {
        username: user.username,
        displayName: user.displayName,
        avatarUrl: user.avatarUrl,
        role: user.role,
        isOwner: user.isOwner,
        isStaff: user.isStaff,
        staffRank: user.staffRank,
        staffPoints: user.staffPoints,
        discordRoles: user.discordRoles,
        roleNames: (user as any).roleNames
      });
      res.json({
        success: true,
        profile,
        playerProfile
      });
    } catch (err: any) {
      console.error('Error fetching user card profile:', err);
      res.status(500).json({ error: 'Failed to load user card profile' });
    }
  });

  // 2.1 GET /api/cards/profile/:discordId (Public & Community Player Profile)
  router.get('/profile/:discordId', async (req, res) => {
    try {
      const targetDiscordId = req.params.discordId;
      if (!targetDiscordId) {
        return res.status(400).json({ error: 'targetDiscordId is required' });
      }
      const authUser = (req as any).authUser;
      const requesterId = authUser?.discordId;
      const userMeta = authUser?.discordId === targetDiscordId ? {
        username: authUser.username,
        displayName: authUser.displayName,
        avatarUrl: authUser.avatarUrl,
        role: authUser.role,
        isOwner: authUser.isOwner,
        isStaff: authUser.isStaff,
        staffRank: authUser.staffRank,
        staffPoints: authUser.staffPoints,
        discordRoles: authUser.discordRoles,
        roleNames: authUser.roleNames
      } : undefined;
      const playerProfile = await getPlayerProfileData(targetDiscordId, requesterId, userMeta);
      res.json({
        success: true,
        profile: playerProfile
      });
    } catch (err: any) {
      console.error('Error fetching player profile:', err);
      res.status(404).json({ error: err.message || 'Player profile not found' });
    }
  });

  // 2.2 POST /api/cards/profile/customize (Auth required) - Player Profile Customization
  router.post('/profile/customize', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const { favoriteCardId, showcaseCardIds, selectedTitleId, featuredBadgeIds, bannerUrl } = req.body;

      const updated = await customizeUserProfile(user.discordId, {
        favoriteCardId,
        showcaseCardIds,
        selectedTitleId,
        featuredBadgeIds,
        bannerUrl
      });

      await recordAuditEvent({
        eventType: 'INTERACTION',
        category: 'PROFILE_CUSTOMIZATION',
        action: `User ${user.displayName || user.username} updated Player Profile (Title: ${updated.selectedTitle?.name || 'None'}, Fav: ${updated.favoriteCard?.name || 'None'})`,
        path: '/api/cards/profile/customize',
        targetElement: 'player_profile_customizer',
        userId: user.discordId,
        username: user.username,
        displayName: user.displayName,
        role: user.role
      }, req);

      res.json({
        success: true,
        profile: updated
      });
    } catch (err: any) {
      console.error('Error customizing profile:', err);
      res.status(400).json({ error: err.message || 'Failed to update player profile' });
    }
  });

  // 3. POST /api/cards/daily-claim (Auth required) - Claim 20 coins once per 24 hours
  router.post('/daily-claim', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const result = await claimDailyReward(user.discordId, {
        username: user.username,
        displayName: user.displayName,
        avatarUrl: user.avatarUrl
      });

      if (!result.success) {
        return res.status(429).json({
          success: false,
          error: result.message,
          nextClaimInMs: result.nextClaimInMs,
          coins: result.newBalance
        });
      }

      res.json({
        success: true,
        coinsAwarded: result.coinsAwarded,
        coins: result.newBalance,
        nextClaimInMs: result.nextClaimInMs,
        message: result.message
      });
    } catch (err: any) {
      console.error('Error claiming daily coins:', err);
      res.status(500).json({ error: 'Failed to claim daily reward' });
    }
  });

  // 3.1 POST /api/cards/claim-achievement (Auth required) - Claim coins for unlocked achievement
  router.post('/claim-achievement', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const { achievementId } = req.body;

      if (!achievementId) {
        return res.status(400).json({ error: 'achievementId is required' });
      }

      const result = await claimAchievementReward(user.discordId, String(achievementId), {
        username: user.username,
        displayName: user.displayName,
        avatarUrl: user.avatarUrl,
        role: user.role,
        isOwner: user.isOwner,
        isStaff: user.isStaff,
        staffRank: user.staffRank,
        staffPoints: user.staffPoints
      });

      if (!result.success) {
        return res.status(400).json(result);
      }

      await recordAuditEvent({
        eventType: 'INTERACTION',
        category: 'CARD_VAULT',
        action: `User ${user.displayName || user.username} claimed achievement reward: ${achievementId} (+${result.coinsAwarded} Coins with ${result.multiplier}x multiplier)`,
        path: '/api/cards/claim-achievement',
        targetElement: 'achievement_claim',
        userId: user.discordId,
        username: user.username,
        displayName: user.displayName,
        role: user.role
      }, req);

      res.json(result);
    } catch (err: any) {
      console.error('Error claiming achievement reward:', err);
      res.status(500).json({ error: err.message || 'Failed to claim achievement reward' });
    }
  });

  // 4. POST /api/cards/open-pack (Auth required) - Buy and open a pack
  router.post('/open-pack', requireAuth, async (req, res) => {
    try {
      const user = req.authUser || (req as any).user;
      if (!user?.discordId) {
        return res.status(401).json({ error: 'User Discord session not found. Please log in.' });
      }

      const { packType, asOwner } = req.body || {};
      if (!packType || !['COMMON', 'UNCOMMON', 'RARE', 'EPIC', 'LEGENDARY'].includes(packType)) {
        return res.status(400).json({ error: 'Invalid pack type specified' });
      }

      const result = await openCardPack(user.discordId, packType as CardRarity, {
        username: user.username,
        displayName: user.displayName,
        avatarUrl: user.avatarUrl,
        isOwner: user.isOwner || user.role === 'OWNER',
        role: user.role
      });

      if (!result.success) {
        return res.status(400).json({
          success: false,
          error: result.message,
          remainingCoins: result.remainingCoins
        });
      }

      res.json(result);
    } catch (err: any) {
      console.error('Error opening pack:', err);
      res.status(500).json({ error: err.message || 'Failed to open card pack' });
    }
  });

  // 5. POST /api/cards/showcase (Auth required) - Toggle card on showcase
  router.post('/showcase', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const { cardId } = req.body;

      if (!cardId) {
        return res.status(400).json({ error: 'cardId is required' });
      }

      const result = await toggleCardShowcase(user.discordId, String(cardId));
      res.json({
        success: true,
        ...result
      });
    } catch (err: any) {
      console.error('Error toggling showcase card:', err);
      res.status(400).json({ error: err.message || 'Failed to update showcase' });
    }
  });

  // 6. GET /api/cards/transactions (Auth required) - Coin ledger
  router.get('/transactions', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const allTx = await getCoinTransactions(100);

      // If Owner, show all transactions. If regular user, only show transactions concerning themselves.
      const isOwnerUser = user.role === 'OWNER' || user.isOwner === true;
      const filtered = isOwnerUser
        ? allTx
        : allTx.filter(t => t.userId === user.discordId);

      res.json({
        success: true,
        transactions: filtered
      });
    } catch (err: any) {
      console.error('Error getting transactions:', err);
      res.status(500).json({ error: 'Failed to retrieve transactions' });
    }
  });

  // 7. POST /api/cards/owner/give-coins (Owner only!) - Manual coin management
  router.post('/owner/give-coins', requireAuth, requireOwner, async (req, res) => {
    try {
      const owner = req.authUser!;
      const { targetDiscordId, amount, reason } = req.body;

      if (!targetDiscordId) {
        return res.status(400).json({ error: 'Target user Discord ID is required' });
      }

      const parsedAmount = parseInt(String(amount), 10);
      if (isNaN(parsedAmount) || parsedAmount === 0) {
        return res.status(400).json({ error: 'Amount must be a non-zero integer' });
      }

      const result = await ownerGrantCoins(
        owner.discordId,
        owner.displayName || owner.username,
        String(targetDiscordId),
        parsedAmount,
        reason || 'Owner grant'
      );

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'CARD_VAULT',
        action: `Owner granted ${parsedAmount > 0 ? '+' : ''}${parsedAmount} coins to user ${result.targetUser} (${targetDiscordId}). Reason: ${reason || 'Owner grant'}`,
        path: '/api/cards/owner/give-coins',
        targetElement: 'owner_coin_management'
      }, req);

      res.json(result);
    } catch (err: any) {
      console.error('Error granting coins:', err);
      res.status(500).json({ error: err.message || 'Failed to grant coins' });
    }
  });

  // 8. GET /api/cards/owner/users (Owner only!) - Search/list users for coin management
  router.get('/owner/users', requireAuth, requireOwner, async (req, res) => {
    try {
      const userList: { discordId: string; username: string; displayName: string; avatarUrl?: string }[] = [];
      const seen = new Set<string>();

      // 1. Load from staff table
      try {
        const staffMembers = await db.select().from(staff);
        for (const s of staffMembers) {
          if (!seen.has(s.discordId)) {
            seen.add(s.discordId);
            userList.push({
              discordId: s.discordId,
              username: s.username,
              displayName: s.displayName,
              avatarUrl: s.avatarUrl
            });
          }
        }
      } catch (e) {
        // Ignore fallback
      }

      // 2. Load from users table
      try {
        const dbUsers = await db.select().from(users);
        for (const u of dbUsers) {
          if (!seen.has(u.discordId)) {
            seen.add(u.discordId);
            userList.push({
              discordId: u.discordId,
              username: u.username,
              displayName: u.displayName || u.username,
              avatarUrl: u.avatarUrl || undefined
            });
          }
        }
      } catch (e) {
        // Ignore fallback
      }

      // 3. Load from Firestore user_cards
      try {
        const firestoreDb = getFirestoreInstance();
        if (firestoreDb) {
          const snap = await getDocs(collection(firestoreDb, 'user_cards'));
          snap.forEach(d => {
            const data = d.data();
            if (data && data.discordId && !seen.has(data.discordId)) {
              seen.add(data.discordId);
              userList.push({
                discordId: data.discordId,
                username: data.username || 'Collector',
                displayName: data.displayName || data.username || 'Collector',
                avatarUrl: data.avatarUrl || undefined
              });
            }
          });
        }
      } catch (e) {
        // Ignore fallback
      }

      res.json({
        success: true,
        users: userList
      });
    } catch (err: any) {
      console.error('Error fetching users for owner management:', err);
      res.status(500).json({ error: 'Failed to retrieve users' });
    }
  });

  // 9. GET /api/cards/owner/cards (Owner only!) - Full card catalog including inactive cards & ability metadata
  router.get('/owner/cards', requireAuth, requireOwner, async (req, res) => {
    try {
      const cards = await loadCustomCardsFromFirestore(true);
      res.json({
        success: true,
        cards,
        totalCards: cards.length
      });
    } catch (err: any) {
      console.error('Error fetching owner cards:', err);
      res.status(500).json({ error: 'Failed to load card catalog' });
    }
  });

  // 10. GET /api/cards/owner/stats (Owner only!) - Economy and catalog statistics
  router.get('/owner/stats', requireAuth, requireOwner, async (req, res) => {
    try {
      const stats = await getOwnerCardStats();
      res.json({
        success: true,
        stats
      });
    } catch (err: any) {
      console.error('Error fetching owner card stats:', err);
      res.status(500).json({ error: 'Failed to load stats' });
    }
  });

  // 11. POST /api/cards/owner/manage-card (Owner only!) - Add or update a card
  router.post('/owner/manage-card', requireAuth, requireOwner, async (req, res) => {
    try {
      const owner = req.authUser!;
      const cardData = req.body;

      if (!cardData || !cardData.name || typeof cardData.name !== 'string' || cardData.name.trim().length === 0) {
        return res.status(400).json({ error: 'Card name is required' });
      }

      const savedCard = await saveCustomCard(cardData, owner.displayName || owner.username);

      // Automatically ensure owner has at least 1 copy of forged card in their collection & profile
      if (owner.discordId) {
        try {
          const profile = await getUserCardProfile(owner.discordId, {
            username: owner.username,
            displayName: owner.displayName,
            avatarUrl: owner.avatarUrl
          });
          if (!profile.cards[savedCard.id] || profile.cards[savedCard.id].count <= 0) {
            profile.cards[savedCard.id] = {
              cardId: savedCard.id,
              count: 1,
              firstAcquiredAt: new Date().toISOString(),
              lastAcquiredAt: new Date().toISOString()
            };
          }
        } catch (copyErr) {
          console.warn('Could not assign owner copy of forged card:', copyErr);
        }
      }

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'CARD_VAULT',
        action: `Owner forged/updated card "${savedCard.name}" (${savedCard.rarity} | ${savedCard.id}). Abilities: ${savedCard.abilities?.length || 0}`,
        path: '/api/cards/owner/manage-card',
        targetElement: savedCard.id
      }, req);

      res.json({
        success: true,
        card: savedCard
      });
    } catch (err: any) {
      console.error('Error managing custom card:', err);
      res.status(500).json({ error: err.message || 'Failed to save card' });
    }
  });

  // 11b. POST /api/cards/owner/import-cards (Owner only!) - Import single or bulk cards & items from backup JSON
  router.post('/owner/import-cards', requireAuth, requireOwner, async (req, res) => {
    try {
      const owner = req.authUser!;
      const bodyPayload = req.body || {};
      const cardsPayload = bodyPayload.cards || (Array.isArray(bodyPayload) ? bodyPayload : bodyPayload.catalog || bodyPayload.data);
      const rawItems = bodyPayload.items || bodyPayload.gameItems || (cardsPayload && typeof cardsPayload === 'object' && (cardsPayload as any).items);

      // 1. Sync items if present in import backup payload
      let importedItemsCount = 0;
      if (Array.isArray(rawItems) && rawItems.length > 0) {
        for (const itm of rawItems) {
          if (itm && (itm.name || itm.id)) {
            try {
              await saveUnifiedItem(itm, owner.discordId);
              importedItemsCount++;
            } catch (itemErr: any) {
              console.warn('Notice importing item with card backup:', itemErr?.message);
            }
          }
        }
        // Force refresh item catalog
        await getAllUnifiedItems(true);
      }

      // 2. Import cards if present
      let cardCount = 0;
      let reloadedCatalog: any[] = [];
      let savedCardsList: any[] = [];

      if (cardsPayload && (Array.isArray(cardsPayload) ? cardsPayload.length > 0 : true)) {
        const result = await importCustomCards(cardsPayload, owner.displayName || owner.username);
        if (result.success && result.count > 0) {
          cardCount = result.count;
          savedCardsList = result.cards;
        }
      }

      if (cardCount === 0 && importedItemsCount === 0) {
        return res.status(400).json({
          error: 'No valid cards or items found in import payload. Please ensure the file contains valid card or item definitions.'
        });
      }

      reloadedCatalog = await loadCustomCardsFromFirestore(false, true);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'CARD_VAULT',
        action: `Owner imported ${cardCount} cards and ${importedItemsCount} items from backup file into catalog (total active cards: ${reloadedCatalog.length})`,
        path: '/api/cards/owner/import-cards',
        targetElement: 'cards_and_items_batch_import'
      }, req);

      res.json({
        success: true,
        count: cardCount,
        itemsCount: importedItemsCount,
        cards: reloadedCatalog,
        savedCards: savedCardsList,
        message: importedItemsCount > 0 && cardCount > 0
          ? `Successfully synchronized & imported ${cardCount} cards and ${importedItemsCount} items into catalog!`
          : cardCount > 0
          ? `Successfully imported ${cardCount} cards into catalog!`
          : `Successfully imported ${importedItemsCount} items into catalog!`
      });
    } catch (err: any) {
      console.error('Error importing cards and items:', err);
      res.status(500).json({ error: err.message || 'Failed to import cards and items' });
    }
  });

  // 11c. GET /api/cards/owner/export-backup (Owner only!) - Download complete backup file of all cards
  router.get('/owner/export-backup', requireAuth, requireOwner, async (req, res) => {
    try {
      const backup = await exportAllCardsBackup();
      const filename = `nexus-all-cards-backup-${new Date().toISOString().slice(0, 10)}.json`;
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.json(backup);
    } catch (err: any) {
      console.error('Error generating card backup export:', err);
      res.status(500).json({ error: 'Failed to generate card backup' });
    }
  });

  // 12. DELETE /api/cards/owner/cards/:id (Owner only!) - Delete or deactivate card
  const handleDeleteCard = async (req: express.Request, res: express.Response) => {
    try {
      const owner = req.authUser!;
      const cardId = req.params.id || req.body?.cardId;

      if (!cardId) {
        return res.status(400).json({ error: 'cardId is required' });
      }

      const result = await deleteCustomCard(String(cardId), owner.displayName || owner.username);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'CARD_VAULT',
        action: `Owner deleted/deactivated card ${cardId}. WasCustom: ${result.wasCustom}`,
        path: '/api/cards/owner/cards',
        targetElement: String(cardId)
      }, req);

      res.json(result);
    } catch (err: any) {
      console.error('Error deleting card:', err);
      res.status(500).json({ error: err.message || 'Failed to delete card' });
    }
  };

  router.delete('/owner/cards/:id', requireAuth, requireOwner, handleDeleteCard);
  router.post('/owner/delete-card', requireAuth, requireOwner, handleDeleteCard);

  // 12b. POST /api/cards/owner/bulk-delete (Owner only!) - Delete multiple selected cards
  router.post('/owner/bulk-delete', requireAuth, requireOwner, async (req, res) => {
    try {
      const owner = req.authUser!;
      const { cardIds } = req.body;

      if (!Array.isArray(cardIds) || cardIds.length === 0) {
        return res.status(400).json({ error: 'cardIds array is required' });
      }

      const result = await deleteMultipleCustomCards(cardIds, owner.displayName || owner.username);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'CARD_VAULT',
        action: `Owner bulk deleted ${cardIds.length} cards (${result.deletedCount} custom deleted, ${result.deactivatedCount} deactivated)`,
        path: '/api/cards/owner/bulk-delete',
        targetElement: cardIds.join(', ')
      }, req);

      res.json(result);
    } catch (err: any) {
      console.error('Error bulk deleting cards:', err);
      res.status(500).json({ error: err.message || 'Failed to bulk delete cards' });
    }
  });

  // 12c. POST /api/cards/owner/delete-all (Owner only!) - Delete/clear all cards from catalog
  router.post('/owner/delete-all', requireAuth, requireOwner, async (req, res) => {
    try {
      const owner = req.authUser!;
      const result = await deleteAllCustomCards(owner.displayName || owner.username);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'CARD_VAULT',
        action: `Owner cleared all cards from catalog (${result.totalCleared} total cards)`,
        path: '/api/cards/owner/delete-all',
        targetElement: 'all_cards'
      }, req);

      res.json(result);
    } catch (err: any) {
      console.error('Error clearing all cards:', err);
      res.status(500).json({ error: err.message || 'Failed to clear all cards' });
    }
  });

  // 12d. POST /api/cards/owner/restore-defaults (Owner only!) - Restore starter default cards
  router.post('/owner/restore-defaults', requireAuth, requireOwner, async (req, res) => {
    try {
      const owner = req.authUser!;
      const result = await restoreDefaultStarterCards(owner.displayName || owner.username);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'CARD_VAULT',
        action: `Owner restored default relic cards (${result.restoredCount} cards restored)`,
        path: '/api/cards/owner/restore-defaults',
        targetElement: 'starter_cards'
      }, req);

      res.json(result);
    } catch (err: any) {
      console.error('Error restoring starter cards:', err);
      res.status(500).json({ error: err.message || 'Failed to restore default cards' });
    }
  });

  // 13. POST /api/cards/owner/pack-customizations (Owner only!) - Customise Card Shop Pack name, image, and open image
  router.post('/owner/pack-customizations', requireAuth, requireOwner, async (req, res) => {
    try {
      const owner = req.authUser!;
      const { packCustomizations } = req.body;

      if (!packCustomizations || typeof packCustomizations !== 'object') {
        return res.status(400).json({ error: 'packCustomizations object is required' });
      }

      const updatedPacks = await savePackCustomizations(owner.displayName || owner.username, packCustomizations);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'CARD_VAULT',
        action: `Owner customized Card Shop packs (${Object.keys(packCustomizations).join(', ')})`,
        path: '/api/cards/owner/pack-customizations',
        targetElement: 'card_shop_packs'
      }, req);

      res.json({
        success: true,
        packs: updatedPacks,
        message: 'Card Shop pack settings and unseal artwork updated successfully!'
      });
    } catch (err: any) {
      console.error('Error updating pack settings:', err);
      res.status(500).json({ error: err.message || 'Failed to update pack settings' });
    }
  });

  // Legacy route: POST /api/cards/owner/pack-images
  router.post('/owner/pack-images', requireAuth, requireOwner, async (req, res) => {
    try {
      const owner = req.authUser!;
      const { packImages, packCustomizations } = req.body;

      let updatedPacks: any[];
      if (packCustomizations && typeof packCustomizations === 'object') {
        updatedPacks = await savePackCustomizations(owner.displayName || owner.username, packCustomizations);
      } else if (packImages && typeof packImages === 'object') {
        updatedPacks = await savePackImages(owner.displayName || owner.username, packImages);
      } else {
        return res.status(400).json({ error: 'packCustomizations or packImages object is required' });
      }

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'CARD_VAULT',
        action: `Owner updated Card Shop pack artwork/settings`,
        path: '/api/cards/owner/pack-images',
        targetElement: 'card_shop_packs'
      }, req);

      res.json({
        success: true,
        packs: updatedPacks,
        message: 'Card Shop pack settings updated successfully!'
      });
    } catch (err: any) {
      console.error('Error updating pack artwork:', err);
      res.status(500).json({ error: err.message || 'Failed to update pack artwork' });
    }
  });

  // 14. GET /api/cards/reveal-sfx (Public/Auth) - Fetch active reveal audio configuration
  router.get('/reveal-sfx', async (_req, res) => {
    try {
      const sfxConfig = await loadRevealSfxFromFirestore();
      res.json({
        success: true,
        sfxConfig
      });
    } catch (err: any) {
      console.error('Error loading reveal SFX:', err);
      res.status(500).json({ error: 'Failed to load reveal sound settings' });
    }
  });

  // 15. POST /api/cards/owner/reveal-sfx (Owner only!) - Configure card reveal sound effects
  router.post('/owner/reveal-sfx', requireAuth, requireOwner, async (req, res) => {
    try {
      const owner = req.authUser!;
      const { sfxConfig } = req.body;

      if (!sfxConfig || typeof sfxConfig !== 'object') {
        return res.status(400).json({ error: 'sfxConfig object is required' });
      }

      const updatedSfx = await saveRevealSfxSettings(owner.displayName || owner.username, sfxConfig);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'CARD_VAULT',
        action: `Owner updated Card Reveal SFX: Volume=${updatedSfx.volume}, CustomSlots=${Object.keys(updatedSfx.deviceAudio || {}).join(',')}`,
        path: '/api/cards/owner/reveal-sfx',
        targetElement: 'card_reveal_sfx'
      }, req);

      res.json({
        success: true,
        sfxConfig: updatedSfx,
        message: 'Card reveal sound effects updated successfully!'
      });
    } catch (err: any) {
      console.error('Error updating reveal SFX:', err);
      res.status(500).json({ error: err.message || 'Failed to update sound effects' });
    }
  });

  // 16. GET /api/cards/card-back (Public/Auth) - Fetch custom card back PNG
  router.get('/card-back', async (_req, res) => {
    try {
      const { loadCardBackFromFirestore } = await import('./cardService');
      const cardBack = await loadCardBackFromFirestore();
      res.json({
        success: true,
        imageUrl: cardBack.imageUrl || ''
      });
    } catch (err: any) {
      console.error('Error loading card back:', err);
      res.status(500).json({ error: 'Failed to load card back setting' });
    }
  });

  // 17. POST /api/cards/owner/card-back (Owner only!) - Set custom card back PNG
  router.post('/owner/card-back', requireAuth, requireOwner, async (req, res) => {
    try {
      const owner = req.authUser!;
      const { imageUrl } = req.body;
      const { saveCardBackSettings } = await import('./cardService');

      const saved = await saveCardBackSettings(owner.displayName || owner.username, String(imageUrl || ''));

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'CARD_VAULT',
        action: `Owner updated Card Back PNG: ${imageUrl ? 'Custom PNG configured' : 'Reset to default'}`,
        path: '/api/cards/owner/card-back',
        targetElement: 'card_back_png'
      }, req);

      res.json({
        success: true,
        imageUrl: saved.imageUrl,
        message: 'Card back artwork updated successfully!'
      });
    } catch (err: any) {
      console.error('Error saving card back:', err);
      res.status(500).json({ error: err.message || 'Failed to update card back' });
    }
  });

  // 18. GET /api/cards/legendary-combat-sfx - Fetch custom legendary combat audio settings
  router.get('/legendary-combat-sfx', async (_req, res) => {
    try {
      const { loadLegendaryCombatSfxFromFirestore } = await import('./cardService');
      const sfxConfig = await loadLegendaryCombatSfxFromFirestore();
      res.json({
        success: true,
        sfxConfig: sfxConfig || null
      });
    } catch (err: any) {
      console.error('Error loading legendary combat SFX:', err);
      res.status(500).json({ error: 'Failed to load combat audio settings' });
    }
  });

  // 19. POST /api/cards/legendary-combat-sfx - Save custom legendary combat audio settings
  router.post('/legendary-combat-sfx', async (req, res) => {
    try {
      const { sfxConfig } = req.body;
      if (!sfxConfig || typeof sfxConfig !== 'object') {
        return res.status(400).json({ error: 'sfxConfig is required' });
      }
      const { saveLegendaryCombatSfxSettings } = await import('./cardService');
      const username = req.authUser?.displayName || req.authUser?.username || 'Owner';
      const saved = await saveLegendaryCombatSfxSettings(username, sfxConfig);
      res.json({
        success: true,
        sfxConfig: saved,
        message: 'Legendary battle sound effects saved!'
      });
    } catch (err: any) {
      console.error('Error saving legendary combat SFX:', err);
      res.status(500).json({ error: err.message || 'Failed to save combat audio settings' });
    }
  });

  app.use('/api/cards', router);
}

