import crypto from 'crypto';
import { getFirestoreInstance } from './discordStaffSync';
import { doc, getDoc, setDoc, deleteDoc, collection, getDocs, query, orderBy, limit, addDoc } from 'firebase/firestore';
import { DEFAULT_COLLECTIBLE_CARDS, CARD_PACKS } from '../src/data/defaultCards';
import {
  CollectibleCardData,
  CardRarity,
  UserCardProfile,
  CardOwnership,
  CoinTransaction,
  PackOpenResult,
  CardAbility,
  CardStatItem,
  CardStateItem,
  AbilityCategory,
  CardStateType,
  calculateCardPowerRating,
  calculateCardOverallRating,
  getUnifiedCardStats,
  getDefaultCardStats
} from '../src/types/cards';
import { calculateLevelProgression, XP_CONFIG } from '../src/config/progressionConfig';
import { DATA_DRIVEN_TITLES, isTitleUnlocked } from '../src/config/titlesConfig';
import { DATA_DRIVEN_BADGES, isBadgeUnlocked } from '../src/config/badgesConfig';
import { PlayerProfileData, CollectionStatistics, PlayerTitle, PlayerBadge, StaffModeratorInfo } from '../src/types/progression';
import { db } from '../src/db';
import { users, staff } from '../src/db/schema';
import { eq } from 'drizzle-orm';
import { getTierForPoints, RANK_TIERS } from '../src/types/rankMap';
import { ALL_ACHIEVEMENTS, getAchievementCoinReward, getRoleCoinMultiplier } from '../src/types/achievements';
import { rollLoveItemForPack } from './characterLoveService';
import { evaluateDuplicateReward, rollUnifiedItemForPack, getAllUnifiedItems } from './itemService';
import { DuplicateRewardAwarded } from '../src/types/items';

export const STARTER_CARD_IDS = ['card_core_recruit', 'card_kinetic_scout', 'card_alloy_sentry', 'card_circuit_sentry'];
export const WELCOME_BONUS_COINS = 50;

export function generateStarterCards(): Record<string, CardOwnership> {
  const starterCards: Record<string, CardOwnership> = {};
  const now = new Date().toISOString();
  for (const id of STARTER_CARD_IDS) {
    starterCards[id] = {
      cardId: id,
      count: 1,
      firstAcquiredAt: now,
      lastAcquiredAt: now
    };
  }
  return starterCards;
}
const DAILY_CLAIM_AMOUNT = 20;
const DAILY_COOLDOWN_MS = 24 * 60 * 60 * 1000; // 24 hours in ms

// In-memory cache for fast responsive lookups
const userCardsCache = new Map<string, UserCardProfile>();
const transactionsBuffer: CoinTransaction[] = [];
let customCardsCatalog: CollectibleCardData[] = [];
let deletedCardIds = new Set<string>();
let hasLoadedCustomCards = false;

export interface GlobalRatingSettings {
  fontSize: number; // default 24
  offsetX: number;  // default 16
  offsetY: number;  // default 14
}

let globalRatingSettings: GlobalRatingSettings = {
  fontSize: 24,
  offsetX: 16,
  offsetY: 14
};
let hasLoadedRatingSettings = false;

export async function getGlobalRatingSettings(): Promise<GlobalRatingSettings> {
  if (hasLoadedRatingSettings) return globalRatingSettings;
  try {
    const db = getFirestoreInstance();
    if (db) {
      const snap = await getDoc(doc(db, 'site_settings', 'card_rating_config'));
      if (snap.exists()) {
        const d = snap.data();
        if (typeof d?.fontSize === 'number') globalRatingSettings.fontSize = d.fontSize;
        if (typeof d?.offsetX === 'number') globalRatingSettings.offsetX = d.offsetX;
        if (typeof d?.offsetY === 'number') globalRatingSettings.offsetY = d.offsetY;
      }
    }
  } catch (err: any) {
    console.warn('CardService: Note loading card_rating_config:', err?.message);
  }
  hasLoadedRatingSettings = true;
  return globalRatingSettings;
}

export async function saveGlobalRatingSettings(
  ownerUser: string,
  settings: Partial<GlobalRatingSettings>
): Promise<{ ratingSettings: GlobalRatingSettings; cards: CollectibleCardData[] }> {
  if (typeof settings.fontSize === 'number' && settings.fontSize >= 10 && settings.fontSize <= 80) {
    globalRatingSettings.fontSize = settings.fontSize;
  }
  if (typeof settings.offsetX === 'number' && settings.offsetX >= 0 && settings.offsetX <= 120) {
    globalRatingSettings.offsetX = settings.offsetX;
  }
  if (typeof settings.offsetY === 'number' && settings.offsetY >= 0 && settings.offsetY <= 120) {
    globalRatingSettings.offsetY = settings.offsetY;
  }
  hasLoadedRatingSettings = true;

  // Apply to all existing custom cards in catalog
  for (const card of customCardsCatalog) {
    card.ratingFontSize = globalRatingSettings.fontSize;
    card.ratingOffsetX = globalRatingSettings.offsetX;
    card.ratingOffsetY = globalRatingSettings.offsetY;
  }

  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'site_settings', 'card_rating_config'), {
        ...globalRatingSettings,
        updatedBy: ownerUser,
        updatedAt: new Date().toISOString()
      }, { merge: true });

      for (const card of customCardsCatalog) {
        setDoc(doc(db, 'custom_cards', card.id), {
          ratingFontSize: globalRatingSettings.fontSize,
          ratingOffsetX: globalRatingSettings.offsetX,
          ratingOffsetY: globalRatingSettings.offsetY,
          updatedAt: new Date().toISOString()
        }, { merge: true }).catch(() => {});
      }
    }
  } catch (err: any) {
    console.warn('CardService: Error saving card_rating_config:', err?.message);
  }

  const allCards = await getAllCards(true);
  return {
    ratingSettings: globalRatingSettings,
    cards: allCards
  };
}

function getAllCards(includeInactive: boolean = false): CollectibleCardData[] {
  const merged: CollectibleCardData[] = DEFAULT_COLLECTIBLE_CARDS
    .filter(c => !deletedCardIds.has(c.id))
    .map(c => {
      const stats = getUnifiedCardStats(c);
      const ovr = typeof c.overallRating === 'number'
        ? c.overallRating
        : calculateCardOverallRating(stats, c.rarity);
      return {
        ...c,
        isActive: c.isActive !== false,
        overallRating: ovr,
        powerRating: ovr,
        power: ovr,
        ratingFontSize: typeof c.ratingFontSize === 'number' ? c.ratingFontSize : globalRatingSettings.fontSize,
        ratingOffsetX: typeof c.ratingOffsetX === 'number' ? c.ratingOffsetX : globalRatingSettings.offsetX,
        ratingOffsetY: typeof c.ratingOffsetY === 'number' ? c.ratingOffsetY : globalRatingSettings.offsetY,
      };
    });

  for (const custom of customCardsCatalog) {
    if (deletedCardIds.has(custom.id)) continue;
    const stats = getUnifiedCardStats(custom);
    const ovr = typeof custom.overallRating === 'number'
      ? custom.overallRating
      : calculateCardOverallRating(stats, custom.rarity);
    const cardWithDefaults: CollectibleCardData = {
      ...custom,
      overallRating: ovr,
      powerRating: ovr,
      power: ovr,
      ratingFontSize: typeof custom.ratingFontSize === 'number' ? custom.ratingFontSize : globalRatingSettings.fontSize,
      ratingOffsetX: typeof custom.ratingOffsetX === 'number' ? custom.ratingOffsetX : globalRatingSettings.offsetX,
      ratingOffsetY: typeof custom.ratingOffsetY === 'number' ? custom.ratingOffsetY : globalRatingSettings.offsetY,
    };
    const idx = merged.findIndex(c => c.id === custom.id);
    if (idx >= 0) {
      merged[idx] = cardWithDefaults;
    } else {
      merged.push(cardWithDefaults);
    }
  }
  if (!includeInactive) {
    return merged.filter(c => c.isActive !== false);
  }
  return merged;
}

export async function loadCustomCardsFromFirestore(includeInactive: boolean = false, forceReload: boolean = false): Promise<CollectibleCardData[]> {
  if (hasLoadedCustomCards && !forceReload) return getAllCards(includeInactive);
  try {
    const db = getFirestoreInstance();
    if (!db) return getAllCards(includeInactive);

    // 1. Load deleted cards registry
    try {
      const metaSnap = await getDoc(doc(db, 'system_meta', 'deleted_cards'));
      if (metaSnap.exists()) {
        const metaData = metaSnap.data();
        if (Array.isArray(metaData?.ids)) {
          deletedCardIds = new Set(metaData.ids.map((id: any) => String(id).trim()));
        }
      }
    } catch (metaErr: any) {
      console.warn('CardService: Notice reading deleted_cards registry:', metaErr?.message);
    }

    // 2. Load custom cards
    const snap = await getDocs(collection(db, 'custom_cards'));
    const loaded: CollectibleCardData[] = [];
    snap.forEach(d => {
      const data = d.data() as CollectibleCardData;
      if (data && data.id && data.name) {
        loaded.push(data);
      }
    });
    customCardsCatalog = loaded;
    hasLoadedCustomCards = true;
  } catch (err: any) {
    console.warn('CardService: Notice loading custom cards:', err?.message);
  }
  return getAllCards(includeInactive);
}

const KNOWN_SOVEREIGN_OWNER_IDS = ['871043296280076308', '831102094521532418', '1099135885699727460', '1306936292197797929', '1371864097523765358'];

export function checkIsOwnerUser(discordId: string, userMeta?: { isOwner?: boolean; role?: string }): boolean {
  if (userMeta?.isOwner || userMeta?.role === 'OWNER') return true;
  const clean = String(discordId || '').trim();
  if (KNOWN_SOVEREIGN_OWNER_IDS.includes(clean)) return true;
  if (process.env.OWNER_DISCORD_ID && clean === process.env.OWNER_DISCORD_ID.trim()) return true;
  return false;
}

/**
 * Get or create server-side user card profile
 */
export async function getUserCardProfile(
  discordId: string,
  userMeta?: { username?: string; displayName?: string; avatarUrl?: string; isOwner?: boolean; role?: string }
): Promise<UserCardProfile> {
  const cleanId = String(discordId).trim();
  const isOwnerUser = checkIsOwnerUser(cleanId, userMeta);
  const cached = userCardsCache.get(cleanId);
  if (cached) {
    if (isOwnerUser) {
      cached.coins = 999999999;
      cached.isUnlimitedCoins = true;
    }
    return computeProfileStatus(cached);
  }

  // Attempt to load from Firestore
  try {
    const db = getFirestoreInstance();
    if (db) {
      const docRef = doc(db, 'user_cards', cleanId);
      const snap = await Promise.race([
        getDoc(docRef),
        new Promise<any>((_, reject) => setTimeout(() => reject(new Error('Firestore read timeout')), 2500))
      ]);
      if (snap && snap.exists()) {
        const data = snap.data() as UserCardProfile;
        const ownedCards = data.cards && Object.keys(data.cards).length > 0
          ? data.cards
          : generateStarterCards();

        // Validate favorite card ownership
        let validFavoriteCardId: string | null = null;
        if (data.favoriteCardId && ownedCards[data.favoriteCardId] && ownedCards[data.favoriteCardId].count > 0) {
          validFavoriteCardId = data.favoriteCardId;
        }

        // Validate showcase cards ownership (max 5)
        const validShowcase = Array.isArray(data.showcaseCardIds)
          ? data.showcaseCardIds.filter(id => ownedCards[id] && ownedCards[id].count > 0).slice(0, 5)
          : [];

        // Compute retro-active XP if not yet populated
        const packsOpenedCount = typeof data.totalPacksOpened === 'number' ? data.totalPacksOpened : 0;
        const uniqueCardsCount = Object.keys(ownedCards).length;
        const retroXp = (packsOpenedCount * XP_CONFIG.PACK_OPEN) + (uniqueCardsCount * XP_CONFIG.NEW_CARD_DISCOVERED);
        const resolvedXp = typeof data.xp === 'number' && data.xp > 0 ? data.xp : Math.max(0, retroXp);
        const resolvedLevel = calculateLevelProgression(resolvedXp).level;

        const isUnlimited = isOwnerUser || data.isUnlimitedCoins === true;
        const resolvedCoins = isUnlimited ? 999999999 : (typeof data.coins === 'number' ? Math.max(0, data.coins) : WELCOME_BONUS_COINS);

        const profile: UserCardProfile = {
          discordId: cleanId,
          username: userMeta?.username || data.username || 'Collector',
          displayName: userMeta?.displayName || data.displayName || userMeta?.username || 'Collector',
          avatarUrl: userMeta?.avatarUrl || data.avatarUrl,
          coins: resolvedCoins,
          isUnlimitedCoins: isUnlimited,
          lastDailyClaim: data.lastDailyClaim,
          totalPacksOpened: packsOpenedCount,
          cards: ownedCards,
          showcaseCardIds: validShowcase,
          favoriteCardId: validFavoriteCardId,
          selectedTitleId: data.selectedTitleId || 'NOVICE_SEEKER',
          unlockedTitleIds: Array.isArray(data.unlockedTitleIds) ? data.unlockedTitleIds : ['NOVICE_SEEKER'],
          featuredBadgeIds: Array.isArray(data.featuredBadgeIds) ? data.featuredBadgeIds.slice(0, 4) : [],
          unlockedBadgeIds: Array.isArray(data.unlockedBadgeIds) ? data.unlockedBadgeIds : [],
          xp: resolvedXp,
          level: resolvedLevel,
          setsCompletedCount: typeof data.setsCompletedCount === 'number' ? data.setsCompletedCount : 0,
          cosmetics: data.cosmetics || {},
          canClaimDaily: true,
          updatedAt: data.updatedAt || new Date().toISOString()
        };
        userCardsCache.set(cleanId, profile);
        return computeProfileStatus(profile);
      }
    }
  } catch (err: any) {
    console.warn('CardService: Firestore read error for user_cards:', err?.message);
  }

  // Brand new collector profile with Welcome Bonus & 4 Starter Battle Cards
  const isUnlimited = isOwnerUser;
  const newProfile: UserCardProfile = {
    discordId: cleanId,
    username: userMeta?.username || 'Collector',
    displayName: userMeta?.displayName || userMeta?.username || 'Collector',
    avatarUrl: userMeta?.avatarUrl,
    coins: isUnlimited ? 999999999 : WELCOME_BONUS_COINS,
    isUnlimitedCoins: isUnlimited,
    totalPacksOpened: 0,
    cards: generateStarterCards(),
    showcaseCardIds: [],
    favoriteCardId: null,
    selectedTitleId: 'NOVICE_SEEKER',
    unlockedTitleIds: ['NOVICE_SEEKER'],
    featuredBadgeIds: [],
    unlockedBadgeIds: [],
    xp: 0,
    level: 1,
    setsCompletedCount: 0,
    cosmetics: {},
    canClaimDaily: true,
    updatedAt: new Date().toISOString()
  };

  userCardsCache.set(cleanId, newProfile);
  // Non-blocking background save so user profile resolution responds instantly
  saveUserProfile(newProfile).catch(err => console.warn('Background save profile error:', err?.message));

  // Log initial bonus
  recordTransaction({
    type: 'INITIAL_BONUS',
    userId: cleanId,
    username: newProfile.username,
    amount: WELCOME_BONUS_COINS,
    balanceAfter: newProfile.coins,
    performedBy: 'SYSTEM',
    reason: 'Welcome to the Sanctuary Card Vault'
  });

  return computeProfileStatus(newProfile);
}

function computeProfileStatus(profile: UserCardProfile): UserCardProfile {
  let canClaim = true;
  let nextAvailable: string | undefined;

  if (profile.lastDailyClaim) {
    const lastClaimTime = new Date(profile.lastDailyClaim).getTime();
    const now = Date.now();
    const elapsed = now - lastClaimTime;
    if (elapsed < DAILY_COOLDOWN_MS) {
      canClaim = false;
      nextAvailable = new Date(lastClaimTime + DAILY_COOLDOWN_MS).toISOString();
    }
  }

  return {
    ...profile,
    canClaimDaily: canClaim,
    nextDailyClaimAvailableAt: nextAvailable
  };
}

export async function saveUserProfile(profile: UserCardProfile): Promise<void> {
  userCardsCache.set(profile.discordId, profile);
  try {
    const db = getFirestoreInstance();
    if (db) {
      const docRef = doc(db, 'user_cards', profile.discordId);
      const writePromise = setDoc(docRef, {
        discordId: profile.discordId,
        username: profile.username,
        displayName: profile.displayName,
        avatarUrl: profile.avatarUrl || null,
        coins: profile.coins,
        lastDailyClaim: profile.lastDailyClaim || null,
        totalPacksOpened: profile.totalPacksOpened || 0,
        cards: profile.cards || {},
        showcaseCardIds: profile.showcaseCardIds || [],
        favoriteCardId: profile.favoriteCardId || null,
        selectedTitleId: profile.selectedTitleId || null,
        unlockedTitleIds: profile.unlockedTitleIds || [],
        featuredBadgeIds: profile.featuredBadgeIds || [],
        unlockedBadgeIds: profile.unlockedBadgeIds || [],
        xp: profile.xp || 0,
        level: profile.level || 1,
        setsCompletedCount: profile.setsCompletedCount || 0,
        cosmetics: profile.cosmetics || {},
        updatedAt: new Date().toISOString()
      }, { merge: true });

      // 2-second timeout protection so Firestore network lag never hangs callers
      await Promise.race([
        writePromise,
        new Promise(resolve => setTimeout(resolve, 2000))
      ]);
    }
  } catch (err: any) {
    console.warn('CardService: Firestore save error:', err?.message);
  }
}

/**
 * Record a coin transaction in memory and Firestore
 */
export async function recordTransaction(data: {
  type: CoinTransaction['type'];
  userId: string;
  username: string;
  amount: number;
  balanceAfter: number;
  performedBy: string;
  reason?: string;
  details?: Record<string, any>;
}): Promise<CoinTransaction> {
  const tx: CoinTransaction = {
    id: `tx_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
    type: data.type,
    userId: data.userId,
    username: data.username,
    amount: data.amount,
    balanceAfter: data.balanceAfter,
    performedBy: data.performedBy,
    reason: data.reason || '',
    details: data.details,
    createdAt: new Date().toISOString()
  };

  transactionsBuffer.unshift(tx);
  if (transactionsBuffer.length > 1000) {
    transactionsBuffer.length = 1000;
  }

  try {
    const db = getFirestoreInstance();
    if (db) {
      const docRef = doc(db, 'card_transactions', tx.id);
      setDoc(docRef, tx).catch(err => {
        console.warn('CardService: Transaction log error:', err?.message);
      });
    }
  } catch (err: any) {
    console.warn('CardService: Firestore transaction write note:', err?.message);
  }

  return tx;
}

/**
 * Claim 20 daily coins with strictly enforced 24h server cooldown
 */
export async function claimDailyReward(
  discordId: string,
  userMeta?: { username?: string; displayName?: string; avatarUrl?: string }
): Promise<{ success: boolean; coinsAwarded: number; newBalance: number; nextClaimInMs: number; message: string }> {
  const profile = await getUserCardProfile(discordId, userMeta);
  const now = Date.now();

  if (profile.lastDailyClaim) {
    const lastClaim = new Date(profile.lastDailyClaim).getTime();
    const elapsed = now - lastClaim;
    if (elapsed < DAILY_COOLDOWN_MS) {
      const remainingMs = DAILY_COOLDOWN_MS - elapsed;
      const hours = Math.floor(remainingMs / (1000 * 60 * 60));
      const mins = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));
      return {
        success: false,
        coinsAwarded: 0,
        newBalance: profile.coins,
        nextClaimInMs: remainingMs,
        message: `Daily reward is on cooldown. Next claim available in ${hours}h ${mins}m.`
      };
    }
  }

  profile.coins += DAILY_CLAIM_AMOUNT;
  profile.xp = (profile.xp || 0) + XP_CONFIG.DAILY_CLAIM;
  profile.level = calculateLevelProgression(profile.xp).level;
  profile.lastDailyClaim = new Date(now).toISOString();
  profile.updatedAt = new Date(now).toISOString();

  await saveUserProfile(profile);

  await recordTransaction({
    type: 'DAILY_CLAIM',
    userId: profile.discordId,
    username: profile.username,
    amount: DAILY_CLAIM_AMOUNT,
    balanceAfter: profile.coins,
    performedBy: 'SYSTEM',
    reason: 'Daily 24h login reward'
  });

  return {
    success: true,
    coinsAwarded: DAILY_CLAIM_AMOUNT,
    newBalance: profile.coins,
    nextClaimInMs: DAILY_COOLDOWN_MS,
    message: `Claimed +${DAILY_CLAIM_AMOUNT} coins! Current balance: ${profile.coins} 🪙`
  };
}

/**
 * Claim coins for a completed achievement with role multiplier applied.
 * Multiplier is distributed based on staff rank/role from 1.0x up to 3.0x max strictly.
 * Coins rewards:
 *   - Easy: 5 - 20 coins
 *   - Medium: 30 - 50 coins
 *   - Hard / So hard: 60 - 80 coins
 */
export async function claimAchievementReward(
  discordId: string,
  achievementId: string,
  userMeta?: {
    username?: string;
    displayName?: string;
    avatarUrl?: string;
    role?: 'OWNER' | 'SUPER_ADMIN' | 'ADMIN' | 'MODERATOR' | 'STAFF' | 'MEMBER';
    isOwner?: boolean;
    isStaff?: boolean;
    staffRank?: string;
    staffPoints?: number;
  }
): Promise<{
  success: boolean;
  achievementId: string;
  baseCoins: number;
  multiplier: number;
  coinsAwarded: number;
  newBalance: number;
  claimedAt: string;
  multiplierInfo: { label: string; labelAr: string; multiplier: number; badgeClass: string };
  message: string;
}> {
  const profile = await getUserCardProfile(discordId, userMeta);

  if (!profile.claimedAchievements) {
    profile.claimedAchievements = {};
  }

  if (profile.claimedAchievements[achievementId]) {
    const existing = profile.claimedAchievements[achievementId];
    return {
      success: false,
      achievementId,
      baseCoins: existing.baseCoins || 0,
      multiplier: existing.multiplier || 1,
      coinsAwarded: 0,
      newBalance: profile.coins,
      claimedAt: existing.claimedAt,
      multiplierInfo: { label: 'Already Claimed', labelAr: 'تم استلامه مسبقاً', multiplier: 1, badgeClass: 'bg-zinc-800 text-zinc-400' },
      message: 'This achievement reward has already been claimed.'
    };
  }

  // Find achievement definition
  const achievementDef = ALL_ACHIEVEMENTS.find(a => a.id === achievementId);
  if (!achievementDef) {
    throw new Error(`Achievement ${achievementId} not found in registry`);
  }

  // Determine base coin reward based on difficulty
  const baseCoins = getAchievementCoinReward(achievementDef);

  // Compute staff / role multiplier (strictly 1.0x - 3.0x max)
  const isOwner = Boolean(
    userMeta?.isOwner || 
    userMeta?.role === 'OWNER' || 
    ['871043296280076308', '831102094521532418', '1099135885699727460', '1306936292197797929', '1371864097523765358'].includes(discordId)
  );

  const multInfo = getRoleCoinMultiplier(
    userMeta?.role,
    userMeta?.staffRank,
    isOwner,
    userMeta?.staffPoints
  );

  const multiplier = multInfo.multiplier; // strictly 1.0x to 3.0x max
  const coinsAwarded = Math.round(baseCoins * multiplier);

  profile.coins += coinsAwarded;
  const nowIso = new Date().toISOString();

  profile.claimedAchievements[achievementId] = {
    claimedAt: nowIso,
    baseCoins,
    coinsAwarded,
    multiplier
  };
  profile.updatedAt = nowIso;

  await saveUserProfile(profile);

  // Save to Firestore user_achievements as well
  try {
    const fsDb = getFirestoreInstance();
    if (fsDb) {
      await setDoc(doc(fsDb, 'user_achievements', discordId), {
        discordId,
        claimed: profile.claimedAchievements,
        updatedAt: nowIso
      }, { merge: true });
    }
  } catch (err: any) {
    console.warn('CardService: Note syncing claim to Firestore user_achievements:', err?.message);
  }

  await recordTransaction({
    type: 'DAILY_CLAIM' as any, // reuse positive reward type
    userId: profile.discordId,
    username: profile.username,
    amount: coinsAwarded,
    balanceAfter: profile.coins,
    performedBy: 'SYSTEM',
    reason: `Achievement unlocked: ${achievementDef.name} (${baseCoins} Base x ${multiplier}x ${multInfo.label} = +${coinsAwarded} Coins)`,
    details: {
      achievementId,
      baseCoins,
      multiplier,
      coinsAwarded
    }
  });

  return {
    success: true,
    achievementId,
    baseCoins,
    multiplier,
    coinsAwarded,
    newBalance: profile.coins,
    claimedAt: nowIso,
    multiplierInfo: multInfo,
    message: `Claimed +${coinsAwarded} Coins (${baseCoins} Base x ${multiplier}x ${multInfo.label})!`
  };
}

/**
 * Open a card pack: Deduct coins, roll card according to pack rarity odds, update collection
 */
export async function openCardPack(
  discordId: string,
  packType: CardRarity,
  userMeta?: { username?: string; displayName?: string; avatarUrl?: string; isOwner?: boolean; role?: string },
  options?: { isFree?: boolean; reason?: string }
): Promise<PackOpenResult> {
  const pack = CARD_PACKS.find(p => p.id === packType);
  if (!pack) {
    throw new Error(`Unknown pack type: ${packType}`);
  }

  const profile = await getUserCardProfile(discordId, userMeta);
  const isOwnerUser = checkIsOwnerUser(discordId, userMeta) || profile.isUnlimitedCoins === true;
  const isFreeGrant = options?.isFree === true;

  if (!isOwnerUser && !isFreeGrant && profile.coins < pack.price) {
    return {
      success: false,
      openedCard: DEFAULT_COLLECTIBLE_CARDS[0],
      isNew: false,
      duplicateCount: 0,
      remainingCoins: profile.coins,
      cards: profile.cards,
      message: `Insufficient coins. ${pack.name} costs ${pack.price} coins, but you only have ${profile.coins} coins.`
    };
  }

  // Deduct coins only for paid non-owner pack purchases
  if (!isOwnerUser && !isFreeGrant) {
    profile.coins = Math.max(0, profile.coins - pack.price);
  } else if (isOwnerUser) {
    profile.coins = 999999999;
    profile.isUnlimitedCoins = true;
  }
  profile.totalPacksOpened = (profile.totalPacksOpened || 0) + 1;

  // Determine drawn rarity by weighted odds
  const drawnRarity = rollRarityForPack(packType);

  // Pick a card from drawn rarity (only active cards drop from packs)
  const allCards = await loadCustomCardsFromFirestore(false);
  const activeCards = allCards.filter(c => c.isActive !== false);
  const pool = activeCards.filter(c => c.rarity === drawnRarity);
  const fallbackPool = activeCards.filter(c => c.rarity === 'COMMON');
  const cardPool = pool.length > 0 ? pool : (fallbackPool.length > 0 ? fallbackPool : activeCards);
  const pickedCard = cardPool[Math.floor(Math.random() * cardPool.length)] || DEFAULT_COLLECTIBLE_CARDS[0];

  // Update ownership
  const nowStr = new Date().toISOString();
  const existingOwnership = profile.cards[pickedCard.id];
  let isNew = false;
  let count = 1;

  if (existingOwnership) {
    count = existingOwnership.count + 1;
    profile.cards[pickedCard.id] = {
      cardId: pickedCard.id,
      count,
      firstAcquiredAt: existingOwnership.firstAcquiredAt || nowStr,
      lastAcquiredAt: nowStr
    };
  } else {
    isNew = true;
    profile.cards[pickedCard.id] = {
      cardId: pickedCard.id,
      count: 1,
      firstAcquiredAt: nowStr,
      lastAcquiredAt: nowStr
    };
  }

  // Award progression XP (50 XP for pack, +100 bonus for discovering a new unique card)
  const xpGained = XP_CONFIG.PACK_OPEN + (isNew ? XP_CONFIG.NEW_CARD_DISCOVERED : 0);
  profile.xp = (profile.xp || 0) + xpGained;
  profile.level = calculateLevelProgression(profile.xp).level;

  profile.updatedAt = nowStr;
  await saveUserProfile(profile);

  await recordTransaction({
    type: 'PACK_PURCHASE',
    userId: profile.discordId,
    username: profile.username,
    amount: -pack.price,
    balanceAfter: profile.coins,
    performedBy: 'USER',
    reason: `Opened ${pack.name} (-${pack.price} coins). Received: ${pickedCard.name} (${pickedCard.rarity})`,
    details: {
      packId: pack.id,
      cardId: pickedCard.id,
      cardRarity: pickedCard.rarity,
      isNew,
      count
    }
  });

  // Evaluate Duplicate Card Reward (if card was already owned - strictly grants upgrade material shards, NO coins)
  let duplicateReward: DuplicateRewardAwarded | null = null;
  const currentCatalogItems = await getAllUnifiedItems();
  const hasActiveItems = Array.isArray(currentCatalogItems) && currentCatalogItems.length > 0;

  if (!isNew && hasActiveItems) {
    try {
      duplicateReward = await evaluateDuplicateReward(profile.discordId, pickedCard.rarity);
    } catch (dupErr) {
      console.warn('CardService: Warning evaluating duplicate reward:', dupErr);
    }
  }

  // Roll unified item drop from this package (Battle items, Companion gifts, Upgrade materials)
  let droppedItem: any = null;
  if (hasActiveItems) {
    try {
      droppedItem = await rollUnifiedItemForPack(discordId, packType);
    } catch (err) {
      console.warn('CardService: Warning rolling unified pack item:', err);
      droppedItem = null;
    }
  }

  return {
    success: true,
    openedCard: pickedCard,
    isNew,
    duplicateCount: count,
    remainingCoins: profile.coins,
    cards: profile.cards,
    droppedItem: droppedItem || null,
    duplicateReward: duplicateReward || null,
    message: isNew
      ? `Discovered new card: ${pickedCard.name} (${pickedCard.rarity})!`
      : (duplicateReward?.message || `Received ${pickedCard.name} (${pickedCard.rarity}) (Total owned: x${count})!`)
  };
}

/**
 * Roll rarity tier based on pack type
 */
function rollRarityForPack(packType: CardRarity): CardRarity {
  const roll = Math.random() * 100; // 0 - 100

  switch (packType) {
    case 'COMMON':
      // 80% Common, 18% Uncommon, 2% Rare
      if (roll < 80) return 'COMMON';
      if (roll < 98) return 'UNCOMMON';
      return 'RARE';

    case 'UNCOMMON':
      // 55% Uncommon, 35% Common, 8% Rare, 2% Epic
      if (roll < 55) return 'UNCOMMON';
      if (roll < 90) return 'COMMON';
      if (roll < 98) return 'RARE';
      return 'EPIC';

    case 'RARE':
      // 60% Rare, 25% Uncommon, 12% Epic, 3% Legendary
      if (roll < 60) return 'RARE';
      if (roll < 85) return 'UNCOMMON';
      if (roll < 97) return 'EPIC';
      return 'LEGENDARY';

    case 'EPIC':
      // 65% Epic, 25% Rare, 10% Legendary
      if (roll < 65) return 'EPIC';
      if (roll < 90) return 'RARE';
      return 'LEGENDARY';

    case 'LEGENDARY':
      // Halloween 2026 is gained exclusively from the Legendary pack!
      // 12% chance of Halloween 2026 Mythic jackpot, 60% Legendary, 28% Epic
      if (roll < 12) return 'HALLOWEEN_2026';
      if (roll < 72) return 'LEGENDARY';
      return 'EPIC';

    default:
      return 'COMMON';
  }
}

/**
 * Toggle card in showcase (max 5)
 */
export async function toggleCardShowcase(
  discordId: string,
  cardId: string
): Promise<{ showcaseCardIds: string[]; isShowcased: boolean }> {
  const profile = await getUserCardProfile(discordId);
  const current = new Set(profile.showcaseCardIds || []);
  let isShowcased = false;

  if (current.has(cardId)) {
    current.delete(cardId);
    isShowcased = false;
  } else {
    if (current.size >= 5) {
      throw new Error('You can only showcase up to 5 cards at a time.');
    }
    current.add(cardId);
    isShowcased = true;
  }

  profile.showcaseCardIds = Array.from(current);
  profile.updatedAt = new Date().toISOString();
  await saveUserProfile(profile);

  return {
    showcaseCardIds: profile.showcaseCardIds,
    isShowcased
  };
}

/**
 * Compute total cards, unique cards, and dynamic rarity statistics
 */
export function computeCollectionStats(profile: UserCardProfile, allCards: CollectibleCardData[]): CollectionStatistics {
  const cardsMap = profile.cards || {};
  const cardLookup = new Map<string, CollectibleCardData>(allCards.map(c => [c.id, c]));

  let totalCards = 0;
  let uniqueCards = 0;
  let commonCount = 0;
  let uncommonCount = 0;
  let rareCount = 0;
  let epicCount = 0;
  let legendaryCount = 0;

  for (const [cardId, ownership] of Object.entries(cardsMap)) {
    if (ownership && ownership.count > 0) {
      uniqueCards++;
      totalCards += ownership.count;
      const card = cardLookup.get(cardId);
      const rarity = card?.rarity || 'COMMON';
      if (rarity === 'COMMON') commonCount += ownership.count;
      else if (rarity === 'UNCOMMON') uncommonCount += ownership.count;
      else if (rarity === 'RARE') rareCount += ownership.count;
      else if (rarity === 'EPIC') epicCount += ownership.count;
      else if (rarity === 'LEGENDARY') legendaryCount += ownership.count;
    }
  }

  const prog = calculateLevelProgression(profile.xp || 0);

  return {
    totalCards,
    uniqueCards,
    commonCount,
    uncommonCount,
    rareCount,
    epicCount,
    legendaryCount,
    setsCompleted: profile.setsCompletedCount || 0,
    packsOpened: profile.totalPacksOpened || 0,
    coinsEarned: profile.coins || 0,
    accountLevel: prog.level,
  };
}

/**
 * Get comprehensive Player Profile data for user across the entire website
 */
export async function getPlayerProfileData(
  targetDiscordId: string,
  requesterDiscordId?: string,
  userMeta?: {
    username?: string;
    displayName?: string;
    avatarUrl?: string;
    role?: 'OWNER' | 'SUPER_ADMIN' | 'ADMIN' | 'MODERATOR' | 'STAFF' | 'MEMBER';
    isOwner?: boolean;
    isStaff?: boolean;
    staffRank?: string;
    staffPoints?: number;
    discordRoles?: string[];
    roleNames?: string[];
  }
): Promise<PlayerProfileData> {
  const cleanId = String(targetDiscordId).trim();
  const profile = await getUserCardProfile(cleanId);
  const allCards = await loadCustomCardsFromFirestore(true);
  const cardLookup = new Map<string, CollectibleCardData>(allCards.map(c => [c.id, c]));

  // Check known Sovereign Owners
  const KNOWN_OWNER_IDS = ['871043296280076308', '831102094521532418', '1099135885699727460', '1306936292197797929', '1371864097523765358'];
  const isOwner = Boolean(
    userMeta?.isOwner || 
    KNOWN_OWNER_IDS.includes(cleanId) || 
    (process.env.OWNER_DISCORD_ID && cleanId === process.env.OWNER_DISCORD_ID.trim())
  );

  // Look up user metadata in database (staff and users tables)
  let resolvedUsername = userMeta?.username;
  let resolvedDisplayName = userMeta?.displayName;
  let resolvedAvatar = userMeta?.avatarUrl;
  let resolvedRole = userMeta?.role;
  let staffDoc: any = null;

  try {
    const staffRows = await db.select().from(staff).where(eq(staff.discordId, cleanId)).limit(1);
    if (staffRows.length > 0) {
      staffDoc = staffRows[0];
      if (!resolvedDisplayName) resolvedDisplayName = staffDoc.displayName;
      if (!resolvedUsername) resolvedUsername = staffDoc.username;
      if (!resolvedAvatar) resolvedAvatar = staffDoc.avatarUrl;
      if (!resolvedRole) {
        resolvedRole = isOwner ? 'OWNER' : (staffDoc.rank === 'SUPER_ADMIN' ? 'SUPER_ADMIN' : staffDoc.rank === 'ADMINISTRATOR' ? 'ADMIN' : 'MODERATOR');
      }
    }
  } catch (e) {
    console.warn('Notice looking up staff in getPlayerProfileData:', e);
  }

  // Firestore fallback for staff lookup if not found in SQL
  if (!staffDoc) {
    try {
      const fsDb = getFirestoreInstance();
      if (fsDb) {
        const snap = await Promise.race([
          getDoc(doc(fsDb, 'staff', cleanId)),
          new Promise<null>(res => setTimeout(() => res(null), 1200))
        ]);
        if (snap && (snap as any).exists?.()) {
          staffDoc = (snap as any).data();
          if (!resolvedDisplayName) resolvedDisplayName = staffDoc.displayName;
          if (!resolvedUsername) resolvedUsername = staffDoc.username;
          if (!resolvedAvatar) resolvedAvatar = staffDoc.avatarUrl;
          if (!resolvedRole) {
            resolvedRole = isOwner ? 'OWNER' : (staffDoc.rank === 'SUPER_ADMIN' ? 'SUPER_ADMIN' : staffDoc.rank === 'ADMINISTRATOR' ? 'ADMIN' : 'MODERATOR');
          }
        }
      }
    } catch {}
  }

  try {
    if (!resolvedDisplayName || !resolvedAvatar) {
      const userRows = await db.select().from(users).where(eq(users.discordId, cleanId)).limit(1);
      if (userRows.length > 0) {
        const u = userRows[0];
        if (!resolvedDisplayName) resolvedDisplayName = u.displayName || u.username;
        if (!resolvedUsername) resolvedUsername = u.username;
        if (!resolvedAvatar) resolvedAvatar = u.avatarUrl || u.avatar || undefined;
      }
    }
  } catch (e) {
    console.warn('Notice looking up user in getPlayerProfileData:', e);
  }

  if (isOwner) {
    resolvedRole = 'OWNER';
  } else if (!resolvedRole) {
    resolvedRole = 'MEMBER';
  }

  // Calculate Moderator & Staff Level information
  let staffInfo: StaffModeratorInfo | null = null;
  const isStaffOrMod = Boolean(
    staffDoc || 
    userMeta?.isStaff || 
    resolvedRole === 'MODERATOR' || 
    resolvedRole === 'ADMIN' || 
    resolvedRole === 'SUPER_ADMIN' || 
    isOwner
  );

  if (staffDoc || isStaffOrMod) {
    const points = typeof staffDoc?.points === 'number' ? staffDoc.points : (userMeta?.staffPoints ?? (isOwner ? 9999 : 0));
    const tier = getTierForPoints(points);
    const tierIndex = RANK_TIERS.findIndex(t => t.id === tier.id);
    const levelNum = tierIndex >= 0 ? tierIndex + 1 : Math.max(1, Math.floor(points / 10));

    const minP = tier.minPoints;
    const maxP = tier.maxPoints;
    const range = Math.max(1, maxP - minP);
    const progressPercent = Math.min(100, Math.max(0, Math.round(((points - minP) / range) * 100)));

    const nextTier = (tierIndex >= 0 && tierIndex < RANK_TIERS.length - 1) ? RANK_TIERS[tierIndex + 1] : null;

    staffInfo = {
      isStaff: true,
      isModerator: resolvedRole === 'MODERATOR' || resolvedRole === 'ADMIN' || resolvedRole === 'SUPER_ADMIN' || isOwner,
      rank: staffDoc?.rank || (isOwner ? 'OWNER' : (resolvedRole === 'ADMIN' ? 'ADMINISTRATOR' : 'MODERATOR')),
      rankName: tier.name,
      rankNameAr: tier.nameAr,
      level: levelNum,
      tierId: tier.id,
      tierSection: tier.section,
      points,
      minPoints: minP,
      maxPoints: maxP,
      progressPercent,
      nextTierName: nextTier?.name,
      nextTierPoints: nextTier?.minPoints,
      status: staffDoc?.status || 'ACTIVE',
      joinedAt: staffDoc?.joinedAt ? new Date(staffDoc.joinedAt).toISOString() : undefined,
      notes: staffDoc?.notes || undefined
    };
  }

  // Sync back resolved names to profile object
  if (resolvedUsername && (profile.username === 'Collector' || !profile.username)) {
    profile.username = resolvedUsername;
  }
  if (resolvedDisplayName && (profile.displayName === 'Collector' || !profile.displayName)) {
    profile.displayName = resolvedDisplayName;
  }
  if (resolvedAvatar && !profile.avatarUrl) {
    profile.avatarUrl = resolvedAvatar;
  }

  const stats = computeCollectionStats(profile, allCards);
  const progression = calculateLevelProgression(profile.xp || 0);

  // Validate and resolve favorite card
  let favoriteCard: CollectibleCardData | null = null;
  if (profile.favoriteCardId && profile.cards[profile.favoriteCardId] && profile.cards[profile.favoriteCardId].count > 0) {
    favoriteCard = cardLookup.get(profile.favoriteCardId) || null;
  }

  // Validate and resolve showcase cards (maintaining order, max 5)
  const validShowcaseIds = (profile.showcaseCardIds || []).filter(
    id => profile.cards[id] && profile.cards[id].count > 0
  ).slice(0, 5);
  
  const showcaseCards: CollectibleCardData[] = [];
  for (const id of validShowcaseIds) {
    const card = cardLookup.get(id);
    if (card) {
      showcaseCards.push(card);
    }
  }

  // Resolve unlocked titles & badges
  const unlockedTitles = DATA_DRIVEN_TITLES.filter(t => isTitleUnlocked(t, stats, profile.unlockedTitleIds));
  const unlockedBadges = DATA_DRIVEN_BADGES.filter(b => isBadgeUnlocked(b, stats, { hasClaimedDaily: !!profile.lastDailyClaim, coins: profile.coins }, profile.unlockedBadgeIds));

  // Resolve selected title
  let selectedTitle: PlayerTitle | null = null;
  if (profile.selectedTitleId) {
    selectedTitle = DATA_DRIVEN_TITLES.find(t => t.id === profile.selectedTitleId) || null;
  }
  if (!selectedTitle && unlockedTitles.length > 0) {
    selectedTitle = unlockedTitles[0];
  }

  // Resolve featured badges (max 4)
  const featuredBadges: PlayerBadge[] = [];
  const featuredIds = (profile.featuredBadgeIds || []).slice(0, 4);
  for (const bid of featuredIds) {
    const badge = DATA_DRIVEN_BADGES.find(b => b.id === bid);
    if (badge && unlockedBadges.some(ub => ub.id === badge.id)) {
      featuredBadges.push(badge);
    }
  }

  // If no featured badges yet, automatically feature the highest rarity unlocked badges up to 3
  if (featuredBadges.length === 0 && unlockedBadges.length > 0) {
    const rarityWeight = { LEGENDARY: 4, EPIC: 3, RARE: 2, UNCOMMON: 1, COMMON: 0 };
    const sorted = [...unlockedBadges].sort((a, b) => (rarityWeight[b.rarity] || 0) - (rarityWeight[a.rarity] || 0));
    featuredBadges.push(...sorted.slice(0, 3));
  }

  return {
    discordId: profile.discordId,
    username: profile.username || resolvedUsername || 'Collector',
    displayName: profile.displayName || resolvedDisplayName || profile.username || 'Collector',
    avatarUrl: profile.avatarUrl || resolvedAvatar,
    role: resolvedRole as any,
    isOwner,
    isStaff: Boolean(staffInfo?.isStaff || isOwner),
    isModerator: Boolean(staffInfo?.isModerator || resolvedRole === 'MODERATOR'),
    staffInfo,
    discordRoles: userMeta?.discordRoles || [],
    roleNames: userMeta?.roleNames || [],
    favoriteCardId: favoriteCard ? favoriteCard.id : null,
    favoriteCard,
    showcaseCardIds: validShowcaseIds,
    showcaseCards,
    selectedTitleId: selectedTitle ? selectedTitle.id : null,
    selectedTitle,
    featuredBadgeIds: featuredBadges.map(b => b.id),
    featuredBadges,
    level: progression.level,
    xp: progression.currentXp,
    progression,
    stats,
    unlockedTitles,
    allTitles: DATA_DRIVEN_TITLES,
    unlockedBadges,
    allBadges: DATA_DRIVEN_BADGES,
    coins: profile.coins,
    canClaimDaily: profile.canClaimDaily,
    nextDailyClaimAvailableAt: profile.nextDailyClaimAvailableAt,
    cosmetics: profile.cosmetics || {},
    bannerUrl: (profile as any).bannerUrl || profile.cosmetics?.profileBackground || null,
    joinedAt: staffDoc?.joinedAt ? new Date(staffDoc.joinedAt).toISOString() : undefined
  };
}

/**
 * Customize Player Profile (Favorite Card, Showcase, Title, Badges, Banner)
 * Server-authoritative ownership and unlock verification.
 */
export async function customizeUserProfile(
  discordId: string,
  payload: {
    favoriteCardId?: string | null;
    showcaseCardIds?: string[];
    selectedTitleId?: string | null;
    featuredBadgeIds?: string[];
    bannerUrl?: string | null;
  }
): Promise<PlayerProfileData> {
  const cleanId = String(discordId).trim();
  const profile = await getUserCardProfile(cleanId);
  const allCards = await loadCustomCardsFromFirestore(true);
  const stats = computeCollectionStats(profile, allCards);

  // 1. Validate Favorite Card
  if (payload.favoriteCardId !== undefined) {
    if (payload.favoriteCardId === null || payload.favoriteCardId === '') {
      profile.favoriteCardId = null;
    } else {
      const targetCardId = String(payload.favoriteCardId).trim();
      if (!profile.cards[targetCardId] || profile.cards[targetCardId].count <= 0) {
        throw new Error('You do not own this card and cannot select it as your Favorite Card.');
      }
      profile.favoriteCardId = targetCardId;
    }
  }

  // 2. Validate Showcase Cards (up to 5 cards)
  if (payload.showcaseCardIds !== undefined) {
    if (!Array.isArray(payload.showcaseCardIds)) {
      throw new Error('showcaseCardIds must be an array of card IDs.');
    }
    if (payload.showcaseCardIds.length > 5) {
      throw new Error('You can select a maximum of 5 cards for your showcase.');
    }
    const cleanIds: string[] = [];
    const seen = new Set<string>();
    for (const rawId of payload.showcaseCardIds) {
      const cid = String(rawId).trim();
      if (!cid || seen.has(cid)) continue;
      if (!profile.cards[cid] || profile.cards[cid].count <= 0) {
        throw new Error(`You do not own card ID "${cid}" and cannot add it to your showcase.`);
      }
      seen.add(cid);
      cleanIds.push(cid);
    }
    profile.showcaseCardIds = cleanIds;
  }

  // 3. Validate Selected Title
  if (payload.selectedTitleId !== undefined) {
    if (payload.selectedTitleId === null || payload.selectedTitleId === '') {
      profile.selectedTitleId = null;
    } else {
      const targetTitleId = String(payload.selectedTitleId).trim();
      const titleDef = DATA_DRIVEN_TITLES.find(t => t.id === targetTitleId);
      if (!titleDef) {
        throw new Error(`Title "${targetTitleId}" does not exist in the sanctuary registry.`);
      }
      const isUnlocked = isTitleUnlocked(titleDef, stats, profile.unlockedTitleIds);
      if (!isUnlocked) {
        throw new Error(`Title "${titleDef.name}" is locked. You must meet the unlock requirement first.`);
      }
      profile.selectedTitleId = targetTitleId;
    }
  }

  // 4. Validate Featured Badges (max 4)
  if (payload.featuredBadgeIds !== undefined) {
    if (!Array.isArray(payload.featuredBadgeIds)) {
      throw new Error('featuredBadgeIds must be an array of badge IDs.');
    }
    if (payload.featuredBadgeIds.length > 4) {
      throw new Error('You can feature a maximum of 4 badges.');
    }
    const cleanBadgeIds: string[] = [];
    const seenBadges = new Set<string>();
    for (const rawBid of payload.featuredBadgeIds) {
      const bid = String(rawBid).trim();
      if (!bid || seenBadges.has(bid)) continue;
      const badgeDef = DATA_DRIVEN_BADGES.find(b => b.id === bid);
      if (!badgeDef) {
        throw new Error(`Badge "${bid}" does not exist.`);
      }
      const isUnlocked = isBadgeUnlocked(badgeDef, stats, { hasClaimedDaily: !!profile.lastDailyClaim, coins: profile.coins }, profile.unlockedBadgeIds);
      if (!isUnlocked) {
        throw new Error(`Badge "${badgeDef.name}" is locked and cannot be featured.`);
      }
      seenBadges.add(bid);
      cleanBadgeIds.push(bid);
    }
    profile.featuredBadgeIds = cleanBadgeIds;
  }

  // 5. Validate and Save Banner URL
  if (payload.bannerUrl !== undefined) {
    if (payload.bannerUrl === null || payload.bannerUrl === '') {
      (profile as any).bannerUrl = null;
      if (profile.cosmetics) {
        profile.cosmetics.profileBackground = undefined;
      }
    } else {
      const cleanBanner = String(payload.bannerUrl).trim();
      (profile as any).bannerUrl = cleanBanner;
      profile.cosmetics = {
        ...(profile.cosmetics || {}),
        profileBackground: cleanBanner
      };
    }
  }

  profile.updatedAt = new Date().toISOString();
  await saveUserProfile(profile);

  return await getPlayerProfileData(cleanId, cleanId);
}

/**
 * Owner gives coins to a user with full audit logging
 */
export async function ownerGrantCoins(
  ownerDiscordId: string,
  ownerName: string,
  targetDiscordId: string,
  amount: number,
  reason: string = 'Owner grant'
): Promise<{ success: boolean; targetUser: string; newBalance: number; amountGranted: number; transactionId: string }> {
  if (isNaN(amount) || amount === 0) {
    throw new Error('Coin amount must be a non-zero integer.');
  }

  const cleanTarget = String(targetDiscordId).trim();
  const profile = await getUserCardProfile(cleanTarget);

  const prevBalance = profile.coins;
  profile.coins = Math.max(0, profile.coins + amount);
  profile.updatedAt = new Date().toISOString();

  await saveUserProfile(profile);

  const tx = await recordTransaction({
    type: 'OWNER_GRANT',
    userId: profile.discordId,
    username: profile.username,
    amount,
    balanceAfter: profile.coins,
    performedBy: `Owner ${ownerName} (${ownerDiscordId})`,
    reason: reason || 'Owner manual adjustment',
    details: {
      ownerDiscordId,
      ownerName,
      previousBalance: prevBalance,
      delta: amount
    }
  });

  return {
    success: true,
    targetUser: profile.username || profile.discordId,
    newBalance: profile.coins,
    amountGranted: amount,
    transactionId: tx.id
  };
}

/**
 * Get all coin transactions for audit log
 */
export async function getCoinTransactions(limitCount: number = 100): Promise<CoinTransaction[]> {
  // If memory buffer is empty or small, attempt preload from Firestore
  if (transactionsBuffer.length < 5) {
    try {
      const db = getFirestoreInstance();
      if (db) {
        const q = query(collection(db, 'card_transactions'), orderBy('createdAt', 'desc'), limit(limitCount));
        const snap = await getDocs(q);
        const existing = new Set(transactionsBuffer.map(t => t.id));
        snap.forEach(d => {
          const item = d.data() as CoinTransaction;
          if (item && item.id && !existing.has(item.id)) {
            transactionsBuffer.push(item);
            existing.add(item.id);
          }
        });
        transactionsBuffer.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      }
    } catch (err: any) {
      console.warn('CardService: Note fetching transactions:', err?.message);
    }
  }

  return transactionsBuffer.slice(0, limitCount);
}

/**
 * Owner saves or creates custom card
 */
export async function saveCustomCard(
  cardData: Partial<CollectibleCardData>,
  ownerUser: string
): Promise<CollectibleCardData> {
  const allCards = await loadCustomCardsFromFirestore(true);
  const id = cardData.id || `custom_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
  const rarity: CardRarity = cardData.rarity || 'COMMON';

  // 0. Unblock ID from deleted registry if it was previously marked deleted
  if (deletedCardIds.has(id)) {
    deletedCardIds.delete(id);
    try {
      const db = getFirestoreInstance();
      if (db) {
        await setDoc(doc(db, 'system_meta', 'deleted_cards'), {
          ids: Array.from(deletedCardIds),
          updatedAt: new Date().toISOString()
        }, { merge: true });
      }
    } catch (e) {}
  }

  // 1. Validate and sanitize stats / customStats
  let sanitizedStats: CardStatItem[] = [];
  const incomingStats = Array.isArray(cardData.stats) && cardData.stats.length > 0
    ? cardData.stats
    : (Array.isArray(cardData.customStats) && cardData.customStats.length > 0 ? cardData.customStats : []);

  if (incomingStats.length > 0) {
    for (const stat of incomingStats) {
      if (stat && typeof stat.name === 'string' && stat.name.trim().length > 0) {
        sanitizedStats.push({
          id: stat.id || `stat_${stat.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${Date.now()}`,
          name: String(stat.name).trim().slice(0, 50),
          value: typeof stat.value === 'number' ? Math.max(0, Math.min(100, stat.value)) : 50,
          maxValue: typeof stat.maxValue === 'number' && stat.maxValue > 0 ? Math.min(1000, stat.maxValue) : 100,
          icon: stat.icon ? String(stat.icon).trim().slice(0, 32) : 'zap',
          color: stat.color ? String(stat.color).trim().slice(0, 32) : '#f59e0b'
        });
      }
    }
  } else {
    // Default standard stats
    sanitizedStats = getDefaultCardStats(cardData.attack ?? 75, cardData.defense ?? 70, cardData.hp ?? 80);
  }

  // 2. Validate and sanitize abilities
  const sanitizedAbilities: CardAbility[] = [];
  const validAbilityCategories: AbilityCategory[] = [
    'PASSIVE',
    'ACTIVE',
    'TRIGGERED',
    'OFFENSIVE',
    'DEFENSIVE',
    'UTILITY',
    'ULTIMATE'
  ];

  if (Array.isArray(cardData.abilities)) {
    for (const ab of cardData.abilities) {
      if (ab && typeof ab.name === 'string' && ab.name.trim().length > 0) {
        const cat = validAbilityCategories.includes(ab.type as AbilityCategory)
          ? (ab.type as AbilityCategory)
          : 'ACTIVE';
        sanitizedAbilities.push({
          id: ab.id || `ab_${Date.now()}_${crypto.randomBytes(2).toString('hex')}`,
          name: String(ab.name).trim().slice(0, 100),
          description: String(ab.description || '').trim().slice(0, 500),
          type: cat,
          value: typeof ab.value === 'number' ? ab.value : undefined,
          duration: typeof ab.duration === 'number' ? Math.max(0, ab.duration) : undefined,
          cooldown: typeof ab.cooldown === 'number' ? Math.max(0, ab.cooldown) : undefined,
          trigger: ab.trigger ? String(ab.trigger).trim().slice(0, 100) : undefined,
          target: ab.target ? String(ab.target).trim().slice(0, 100) : undefined,
          enabled: ab.enabled !== false,
          cost: typeof ab.cost === 'number' ? Math.max(0, ab.cost) : undefined,
          powerValue: typeof ab.powerValue === 'number' ? ab.powerValue : undefined
        });
      }
    }
  }

  // 3. Validate and sanitize cardStates (gameplay architecture)
  const sanitizedStates: CardStateItem[] = [];
  const validStateTypes: CardStateType[] = [
    'NORMAL',
    'BUFFED',
    'DEBUFFED',
    'STUNNED',
    'PROTECTED',
    'EXHAUSTED',
    'HIDDEN',
    'ENRAGED'
  ];

  if (Array.isArray(cardData.cardStates)) {
    for (const st of cardData.cardStates) {
      if (st && typeof st.name === 'string' && st.name.trim().length > 0) {
        sanitizedStates.push({
          id: st.id || `st_${Date.now()}_${crypto.randomBytes(2).toString('hex')}`,
          name: validStateTypes.includes(st.name as CardStateType) ? st.name : String(st.name).trim().slice(0, 50),
          duration: typeof st.duration === 'number' ? Math.max(0, st.duration) : 0,
          effect: String(st.effect || '').trim().slice(0, 300),
          value: typeof st.value === 'number' ? st.value : undefined,
          source: st.source ? String(st.source).trim().slice(0, 100) : undefined,
          active: st.active !== false
        });
      }
    }
  }

  // 4. Calculate authoritative server-side OVR Rating (0 - 100 Scale)
  const computedOvr = typeof cardData.overallRating === 'number'
    ? cardData.overallRating
    : calculateCardOverallRating(sanitizedStats, rarity);

  const cleanCard: CollectibleCardData = {
    id,
    name: String(cardData.name || 'Ancient Relic').trim().slice(0, 100),
    title: String(cardData.title || 'Guardian of the Vault').trim().slice(0, 100),
    rarity,
    packType: cardData.packType || rarity,
    cardType: cardData.cardType ? String(cardData.cardType).trim().slice(0, 50) : 'Relic',
    description: String(cardData.description || 'Carved in stone from ancient antiquity.').trim().slice(0, 2000),
    lore: String(cardData.lore || '"Whispers of forgotten sovereigns echo in the clay."').trim().slice(0, 2000),
    imageUrl: cardData.imageUrl || DEFAULT_COLLECTIBLE_CARDS[0].imageUrl,
    attack: typeof cardData.attack === 'number' ? Math.max(0, Math.min(99999, cardData.attack)) : 500,
    defense: typeof cardData.defense === 'number' ? Math.max(0, Math.min(99999, cardData.defense)) : 500,
    hp: typeof cardData.hp === 'number' ? Math.max(0, Math.min(99999, cardData.hp)) : 600,
    element: cardData.element || 'STONE',
    power: computedOvr,
    powerRating: computedOvr,
    overallRating: computedOvr,
    stats: sanitizedStats,
    customStats: sanitizedStats,
    abilities: sanitizedAbilities,
    cardStates: sanitizedStates,
    series: String(cardData.series || 'Custom Collection').trim().slice(0, 100),
    cardNumber: typeof cardData.cardNumber === 'number' ? cardData.cardNumber : allCards.length + 1,
    accentColor: String(cardData.accentColor || '#fbbf24').slice(0, 32),
    foilStyle: cardData.foilStyle || 'standard',
    foilColor: cardData.foilColor ? String(cardData.foilColor).slice(0, 32) : undefined,
    revealVideoUrl: cardData.revealVideoUrl ? String(cardData.revealVideoUrl).trim().slice(0, 2000000) : undefined,
    isActive: cardData.isActive !== false,
    isCustom: cardData.isCustom ?? true,
    createdBy: cardData.createdBy || ownerUser,
    updatedAt: new Date().toISOString(),
    nameColor: cardData.nameColor ? String(cardData.nameColor).slice(0, 32) : undefined,
    borderColor: cardData.borderColor ? String(cardData.borderColor).slice(0, 32) : undefined,
    glowColor: cardData.glowColor ? String(cardData.glowColor).slice(0, 32) : undefined,
    glowIntensity: cardData.glowIntensity || undefined,
    frameStyle: cardData.frameStyle || undefined,
    cornerStyle: cardData.cornerStyle || undefined,
    badgeStyle: cardData.badgeStyle || undefined,
    backgroundTheme: cardData.backgroundTheme || undefined,
    ratingFontSize: typeof cardData.ratingFontSize === 'number' ? cardData.ratingFontSize : globalRatingSettings.fontSize,
    ratingOffsetX: typeof cardData.ratingOffsetX === 'number' ? cardData.ratingOffsetX : globalRatingSettings.offsetX,
    ratingOffsetY: typeof cardData.ratingOffsetY === 'number' ? cardData.ratingOffsetY : globalRatingSettings.offsetY,
  };

  // If rating size or offset was updated on this card, update the global settings and apply to all cards
  if (typeof cardData.ratingFontSize === 'number' || typeof cardData.ratingOffsetX === 'number' || typeof cardData.ratingOffsetY === 'number') {
    if (typeof cardData.ratingFontSize === 'number') globalRatingSettings.fontSize = cardData.ratingFontSize;
    if (typeof cardData.ratingOffsetX === 'number') globalRatingSettings.offsetX = cardData.ratingOffsetX;
    if (typeof cardData.ratingOffsetY === 'number') globalRatingSettings.offsetY = cardData.ratingOffsetY;
    hasLoadedRatingSettings = true;
    for (const c of customCardsCatalog) {
      c.ratingFontSize = globalRatingSettings.fontSize;
      c.ratingOffsetX = globalRatingSettings.offsetX;
      c.ratingOffsetY = globalRatingSettings.offsetY;
    }
  }

  const idx = customCardsCatalog.findIndex(c => c.id === id);
  if (idx >= 0) {
    customCardsCatalog[idx] = cleanCard;
  } else {
    customCardsCatalog.push(cleanCard);
  }

  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'custom_cards', id), cleanCard);
    }
  } catch (err: any) {
    console.warn('CardService: Error saving custom card to Firestore:', err?.message);
  }

  return cleanCard;
}

/**
 * Owner imports multiple cards or a backup file of cards at once
 * Robust parser supporting arrays, { cards: [...] }, { catalog: [...] }, { data: [...] }, key-value maps, and single cards
 */
export async function importCustomCards(
  cardsData: any,
  ownerUser: string
): Promise<{ success: boolean; count: number; cards: CollectibleCardData[] }> {
  let rawCards: any[] = [];
  if (Array.isArray(cardsData)) {
    rawCards = cardsData;
  } else if (cardsData && typeof cardsData === 'object') {
    if (Array.isArray(cardsData.cards)) {
      rawCards = cardsData.cards;
    } else if (Array.isArray(cardsData.catalog)) {
      rawCards = cardsData.catalog;
    } else if (Array.isArray(cardsData.data)) {
      rawCards = cardsData.data;
    } else if (Array.isArray(cardsData.items)) {
      rawCards = cardsData.items;
    } else if (Array.isArray(cardsData.cardList)) {
      rawCards = cardsData.cardList;
    } else if (Array.isArray(cardsData.customCards)) {
      rawCards = cardsData.customCards;
    } else if (Array.isArray(cardsData.cardsToExport)) {
      rawCards = cardsData.cardsToExport;
    } else if (Array.isArray(cardsData.allCards)) {
      rawCards = cardsData.allCards;
    } else if (cardsData.backup && typeof cardsData.backup === 'object' && Array.isArray(cardsData.backup.cards)) {
      rawCards = cardsData.backup.cards;
    } else if (cardsData.name && typeof cardsData.name === 'string') {
      rawCards = [cardsData];
    } else {
      // Check for dictionary object: { "card_id_1": {...}, "card_id_2": {...} }
      const values = Object.values(cardsData);
      const cardLike = values.filter((v: any) => v && typeof v === 'object' && (v.name || v.id || v.title));
      if (cardLike.length > 0) {
        rawCards = cardLike;
      }
    }
  }

  if (rawCards.length === 0) {
    return {
      success: false,
      count: 0,
      cards: [],
      error: 'No readable card definitions found in import data. Please ensure the file contains valid card objects.'
    } as any;
  }

  const savedCards: CollectibleCardData[] = [];
  let deletedIdsChanged = false;

  for (const raw of rawCards) {
    if (!raw || typeof raw !== 'object') continue;
    const cardToSave: Partial<CollectibleCardData> = { ...raw };
    if (!cardToSave.name || typeof cardToSave.name !== 'string' || cardToSave.name.trim().length === 0) {
      cardToSave.name = cardToSave.title || 'Imported Relic';
    }
    // Ensure card is marked active and custom so it always appears in the catalog
    cardToSave.isActive = raw.isActive !== false;
    cardToSave.isCustom = true;

    // Explicitly unblock ID if it was previously marked as deleted
    if (cardToSave.id && deletedCardIds.has(cardToSave.id)) {
      deletedCardIds.delete(cardToSave.id);
      deletedIdsChanged = true;
    }

    const saved = await saveCustomCard(cardToSave, ownerUser);
    savedCards.push(saved);
  }

  // Persist updated deleted_cards registry if any unblocked
  if (deletedIdsChanged) {
    try {
      const db = getFirestoreInstance();
      if (db) {
        await setDoc(doc(db, 'system_meta', 'deleted_cards'), {
          ids: Array.from(deletedCardIds),
          updatedAt: new Date().toISOString()
        }, { merge: true });
      }
    } catch (e) {}
  }

  // Force reload and cache sync
  hasLoadedCustomCards = false;
  await loadCustomCardsFromFirestore(true, true);

  return {
    success: true,
    count: savedCards.length,
    cards: savedCards
  };
}

/**
 * Generate a complete, authoritative backup of all catalog cards with full fidelity
 */
export async function exportAllCardsBackup(): Promise<{
  app: string;
  version: number;
  backupType: string;
  exportedAt: string;
  count: number;
  ratingSettings: any;
  cards: CollectibleCardData[];
  items?: any[];
}> {
  const allCards = await loadCustomCardsFromFirestore(true, true);
  const ratingSettings = await getGlobalRatingSettings();
  let allItems: any[] = [];
  try {
    allItems = await getAllUnifiedItems(true);
  } catch (err: any) {
    console.warn('Notice loading items for card export backup:', err?.message);
  }
  return {
    app: 'Creative Nexus Sovereign Card Studio',
    version: 2,
    backupType: 'full_catalog_backup',
    exportedAt: new Date().toISOString(),
    count: allCards.length,
    ratingSettings,
    cards: allCards,
    items: allItems
  };
}

/**
 * Owner deletes a card (completely removes it from the catalog)
 */
export async function deleteCustomCard(
  cardId: string,
  ownerUser: string
): Promise<{ success: boolean; message: string; deletedId: string; wasCustom: boolean }> {
  const cleanId = String(cardId).trim();
  const allCards = await loadCustomCardsFromFirestore(true);
  const target = allCards.find(c => c.id === cleanId);

  if (!target) {
    throw new Error(`Card with ID "${cleanId}" not found in catalog.`);
  }

  const isCustom = target.isCustom === true;

  // Add to deleted registry and purge from in-memory catalog
  deletedCardIds.add(cleanId);
  customCardsCatalog = customCardsCatalog.filter(c => c.id !== cleanId);

  try {
    const db = getFirestoreInstance();
    if (db) {
      if (isCustom) {
        await deleteDoc(doc(db, 'custom_cards', cleanId));
      }
      await setDoc(doc(db, 'system_meta', 'deleted_cards'), {
        ids: Array.from(deletedCardIds),
        updatedAt: new Date().toISOString()
      }, { merge: true });
    }
  } catch (err: any) {
    console.warn('CardService: Notice syncing deletion to Firestore:', err?.message);
  }

  return {
    success: true,
    message: `Card "${target.name}" was permanently removed from the catalog.`,
    deletedId: cleanId,
    wasCustom: isCustom
  };
}

/**
 * Owner deletes multiple cards at once (select a couple of cards to delete)
 */
export async function deleteMultipleCustomCards(
  cardIds: string[],
  ownerUser: string
): Promise<{ success: boolean; deletedCount: number; deactivatedCount: number; message: string }> {
  if (!Array.isArray(cardIds) || cardIds.length === 0) {
    return { success: true, deletedCount: 0, deactivatedCount: 0, message: 'No cards selected for deletion.' };
  }

  const allCards = await loadCustomCardsFromFirestore(true);
  const db = getFirestoreInstance();
  let deletedCount = 0;

  for (const rawId of cardIds) {
    const cleanId = String(rawId).trim();
    if (!cleanId) continue;
    const target = allCards.find(c => c.id === cleanId);
    if (!target) continue;

    deletedCardIds.add(cleanId);
    customCardsCatalog = customCardsCatalog.filter(c => c.id !== cleanId);

    if (db && target.isCustom === true) {
      try {
        await deleteDoc(doc(db, 'custom_cards', cleanId));
      } catch (e) {}
    }
    deletedCount++;
  }

  if (db) {
    try {
      await setDoc(doc(db, 'system_meta', 'deleted_cards'), {
        ids: Array.from(deletedCardIds),
        updatedAt: new Date().toISOString()
      }, { merge: true });
    } catch (e) {}
  }

  return {
    success: true,
    deletedCount,
    deactivatedCount: 0,
    message: `Successfully deleted ${deletedCount} card(s) from the catalog.`
  };
}

/**
 * Owner deletes/clears all cards in the catalog
 */
export async function deleteAllCustomCards(
  ownerUser: string
): Promise<{ success: boolean; totalCleared: number; message: string }> {
  const allCards = await loadCustomCardsFromFirestore(true);
  const db = getFirestoreInstance();
  let count = 0;

  for (const card of allCards) {
    deletedCardIds.add(card.id);
    count++;
  }
  for (const defaultCard of DEFAULT_COLLECTIBLE_CARDS) {
    deletedCardIds.add(defaultCard.id);
  }

  if (db) {
    for (const card of customCardsCatalog) {
      try {
        await deleteDoc(doc(db, 'custom_cards', card.id));
      } catch (e) {}
    }
    try {
      await setDoc(doc(db, 'system_meta', 'deleted_cards'), {
        ids: Array.from(deletedCardIds),
        updatedAt: new Date().toISOString()
      });
    } catch (e) {}
  }

  customCardsCatalog = [];

  return {
    success: true,
    totalCleared: count,
    message: `Successfully cleared all ${count} cards from the catalog.`
  };
}

/**
 * Owner restores default starter cards if needed
 */
export async function restoreDefaultStarterCards(
  ownerUser: string
): Promise<{ success: boolean; restoredCount: number; message: string }> {
  deletedCardIds.clear();
  const db = getFirestoreInstance();
  if (db) {
    try {
      await setDoc(doc(db, 'system_meta', 'deleted_cards'), {
        ids: [],
        updatedAt: new Date().toISOString()
      });
    } catch (e) {}
  }
  hasLoadedCustomCards = false;
  const reloaded = await loadCustomCardsFromFirestore(true, true);
  return {
    success: true,
    restoredCount: reloaded.length,
    message: `Restored ${reloaded.length} starter relic cards to the catalog.`
  };
}

/**
 * Comprehensive Card and Economy Stats for Owner Dashboard
 */
export async function getOwnerCardStats(): Promise<{
  totalCards: number;
  activeCards: number;
  inactiveCards: number;
  rarityBreakdown: Record<CardRarity, number>;
  totalCollectors: number;
  totalCoinsInCirculation: number;
  totalPacksOpened: number;
}> {
  const allCards = await loadCustomCardsFromFirestore(true);
  const activeCount = allCards.filter(c => c.isActive !== false).length;
  const inactiveCount = allCards.length - activeCount;

  const rarityBreakdown: Record<CardRarity, number> = {
    COMMON: 0,
    UNCOMMON: 0,
    RARE: 0,
    EPIC: 0,
    LEGENDARY: 0,
    HALLOWEEN_2026: 0
  };
  for (const c of allCards) {
    if (rarityBreakdown[c.rarity] !== undefined) {
      rarityBreakdown[c.rarity]++;
    }
  }

  let totalCoins = 0;
  let totalPacks = 0;
  let collectorCount = userCardsCache.size;

  for (const prof of userCardsCache.values()) {
    totalCoins += prof.coins || 0;
    totalPacks += prof.totalPacksOpened || 0;
  }

  return {
    totalCards: allCards.length,
    activeCards: activeCount,
    inactiveCards: inactiveCount,
    rarityBreakdown,
    totalCollectors: Math.max(collectorCount, 1),
    totalCoinsInCirculation: totalCoins,
    totalPacksOpened: totalPacks
  };
}

// ----------------------------------------------------
// CARD SHOP PACK ARTWORK MANAGEMENT (OWNER CUSTOMIZATION)
// ----------------------------------------------------
// OWNER PACK CUSTOMIZATION (NAME, CATALOG IMAGE, OPEN IMAGE)
// ----------------------------------------------------

export interface StoredPackCustomization {
  name?: string;
  imageUrl?: string;
  openImageUrl?: string;
}

let customPackSettings: Record<string, StoredPackCustomization> = {};
let hasLoadedPackSettings = false;

export async function loadPackSettingsFromFirestore(): Promise<Record<string, StoredPackCustomization>> {
  if (hasLoadedPackSettings) return customPackSettings;
  try {
    const db = getFirestoreInstance();
    if (db) {
      const snap = await getDoc(doc(db, 'site_settings', 'card_shop_packs'));
      if (snap.exists()) {
        const data = snap.data();
        if (data && data.packCustomizations && typeof data.packCustomizations === 'object') {
          customPackSettings = data.packCustomizations;
        }
        // Backward compatibility: merge legacy packImages
        if (data && data.packImages && typeof data.packImages === 'object') {
          for (const [key, url] of Object.entries(data.packImages)) {
            if (!customPackSettings[key]) customPackSettings[key] = {};
            if (!customPackSettings[key].imageUrl && typeof url === 'string') {
              customPackSettings[key].imageUrl = url;
            }
          }
        }
      }
    }
    hasLoadedPackSettings = true;
  } catch (err: any) {
    console.warn('CardService: Notice loading pack settings:', err?.message);
  }
  return customPackSettings;
}

export async function getPackDefinitions(): Promise<any[]> {
  const settings = await loadPackSettingsFromFirestore();
  return CARD_PACKS.map(p => {
    const custom = settings[p.id] || settings[p.rarity] || {};
    return {
      ...p,
      name: custom.name && custom.name.trim() ? custom.name.trim() : p.name,
      imageUrl: custom.imageUrl || p.imageUrl,
      openImageUrl: custom.openImageUrl || undefined
    };
  });
}

export async function savePackCustomizations(
  ownerUser: string,
  customizations: Record<string, StoredPackCustomization>
): Promise<any[]> {
  for (const [key, item] of Object.entries(customizations)) {
    customPackSettings[key] = {
      ...(customPackSettings[key] || {}),
      ...item
    };
  }
  hasLoadedPackSettings = true;

  try {
    const db = getFirestoreInstance();
    if (db) {
      // Also maintain legacy packImages map for any dependent queries
      const legacyImages: Record<string, string> = {};
      for (const [k, v] of Object.entries(customPackSettings)) {
        if (v.imageUrl) legacyImages[k] = v.imageUrl;
      }

      await setDoc(doc(db, 'site_settings', 'card_shop_packs'), {
        packCustomizations: customPackSettings,
        packImages: legacyImages,
        updatedBy: ownerUser,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    }
  } catch (err: any) {
    console.warn('CardService: Error saving pack customizations to Firestore:', err?.message);
  }

  return getPackDefinitions();
}

export async function savePackImages(
  ownerUser: string,
  images: Record<string, string>
): Promise<any[]> {
  const converted: Record<string, StoredPackCustomization> = {};
  for (const [k, url] of Object.entries(images)) {
    converted[k] = { imageUrl: url };
  }
  return savePackCustomizations(ownerUser, converted);
}

// ----------------------------------------------------
// OWNER CARD REVEAL SOUND EFFECTS CONFIGURATION
// ----------------------------------------------------

export interface DeviceAudioSlot {
  dataUrl?: string;
  fileName?: string;
  fileSize?: number;
}

export interface StoredRevealSfxConfig {
  volume: number;
  deviceAudio?: {
    cut?: DeviceAudioSlot;
    pull?: DeviceAudioSlot;
    reveal?: DeviceAudioSlot;
    legendary?: DeviceAudioSlot;
  };
  enabled: boolean;
}

let cachedRevealSfx: StoredRevealSfxConfig = {
  volume: 0.75,
  deviceAudio: {},
  enabled: true
};
let hasLoadedRevealSfx = false;

export async function loadRevealSfxFromFirestore(): Promise<StoredRevealSfxConfig> {
  if (hasLoadedRevealSfx) return cachedRevealSfx;
  try {
    const db = getFirestoreInstance();
    if (db) {
      const snap = await getDoc(doc(db, 'site_settings', 'card_reveal_sfx'));
      if (snap.exists()) {
        const data = snap.data();
        if (data && data.sfxConfig && typeof data.sfxConfig === 'object') {
          cachedRevealSfx = { ...cachedRevealSfx, ...data.sfxConfig };
        }
      }
    }
    hasLoadedRevealSfx = true;
  } catch (err: any) {
    console.warn('CardService: Notice loading reveal SFX:', err?.message);
  }
  return cachedRevealSfx;
}

export async function saveRevealSfxSettings(
  ownerUser: string,
  sfxConfig: Partial<StoredRevealSfxConfig>
): Promise<StoredRevealSfxConfig> {
  cachedRevealSfx = { ...cachedRevealSfx, ...sfxConfig };
  hasLoadedRevealSfx = true;

  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'site_settings', 'card_reveal_sfx'), {
        sfxConfig: cachedRevealSfx,
        updatedBy: ownerUser,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    }
  } catch (err: any) {
    console.warn('CardService: Error saving reveal SFX to Firestore:', err?.message);
  }

  return cachedRevealSfx;
}

// ----------------------------------------------------
// OWNER CARD BACK PNG CONFIGURATION
// ----------------------------------------------------

let cachedCardBack: { imageUrl?: string } = {};
let hasLoadedCardBack = false;

export async function loadCardBackFromFirestore(): Promise<{ imageUrl?: string }> {
  if (hasLoadedCardBack) return cachedCardBack;
  try {
    const db = getFirestoreInstance();
    if (db) {
      const snap = await getDoc(doc(db, 'site_settings', 'card_back'));
      if (snap.exists()) {
        const data = snap.data();
        if (data && typeof data.imageUrl === 'string') {
          cachedCardBack = { imageUrl: data.imageUrl };
        }
      }
    }
    hasLoadedCardBack = true;
  } catch (err: any) {
    console.warn('CardService: Notice loading card back:', err?.message);
  }
  return cachedCardBack;
}

export async function saveCardBackSettings(
  ownerUser: string,
  imageUrl: string
): Promise<{ imageUrl: string }> {
  cachedCardBack = { imageUrl };
  hasLoadedCardBack = true;
  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'site_settings', 'card_back'), {
        imageUrl,
        updatedBy: ownerUser,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    }
  } catch (err: any) {
    console.warn('CardService: Error saving card back to Firestore:', err?.message);
  }
  return cachedCardBack as { imageUrl: string };
}

// ----------------------------------------------------
// LEGENDARY COMBAT ACTION SFX CONFIGURATION
// ----------------------------------------------------

let cachedLegendarySfx: any = null;
let hasLoadedLegendarySfx = false;

export async function loadLegendaryCombatSfxFromFirestore(): Promise<any> {
  if (hasLoadedLegendarySfx && cachedLegendarySfx) return cachedLegendarySfx;
  try {
    const db = getFirestoreInstance();
    if (db) {
      const snap = await getDoc(doc(db, 'site_settings', 'legendary_combat_sfx'));
      if (snap.exists()) {
        const data = snap.data();
        if (data && data.sfxConfig) {
          cachedLegendarySfx = data.sfxConfig;
        }
      }
    }
    hasLoadedLegendarySfx = true;
  } catch (err: any) {
    console.warn('CardService: Notice loading legendary combat SFX:', err?.message);
  }
  return cachedLegendarySfx;
}

export async function saveLegendaryCombatSfxSettings(
  ownerUser: string,
  sfxConfig: any
): Promise<any> {
  cachedLegendarySfx = sfxConfig;
  hasLoadedLegendarySfx = true;
  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'site_settings', 'legendary_combat_sfx'), {
        sfxConfig,
        updatedBy: ownerUser,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    }
  } catch (err: any) {
    console.warn('CardService: Error saving legendary combat SFX to Firestore:', err?.message);
  }
  return cachedLegendarySfx;
}


