import express from 'express';
import fs from 'fs';
import path from 'path';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, initializeFirestore, doc, getDoc, setDoc, updateDoc, collection, addDoc, setLogLevel } from 'firebase/firestore';
import { db } from '../src/db';
import { staff, staffHistory, serverConfig } from '../src/db/schema';
import { eq } from 'drizzle-orm';
import { getDiscordRbacConfig } from './discordRbac';

// Silence Firestore internal gRPC idle stream disconnect warnings
try {
  setLogLevel('silent');
} catch {
  // Ignore if already configured
}

// Load Firebase configuration for Firestore persistence
let serverFirestoreInstance: any = null;

export function getFirestoreInstance() {
  if (serverFirestoreInstance) return serverFirestoreInstance;
  try {
    const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
    if (!fs.existsSync(configPath)) {
      return null;
    }
    const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    const firebaseApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
    try {
      serverFirestoreInstance = initializeFirestore(
        firebaseApp,
        { experimentalForceLongPolling: true },
        firebaseConfig.firestoreDatabaseId
      );
    } catch {
      serverFirestoreInstance = getFirestore(firebaseApp, firebaseConfig.firestoreDatabaseId);
    }
    return serverFirestoreInstance;
  } catch (err) {
    console.error('Failed to initialize Firestore instance in backend:', err);
    return null;
  }
}

// Helper to compute Discord CDN Avatar
export function computeDiscordAvatar(discordId: string, avatarHash?: string | null): string {
  if (avatarHash) {
    const ext = avatarHash.startsWith('a_') ? 'gif' : 'png';
    return `https://cdn.discordapp.com/avatars/${discordId}/${avatarHash}.${ext}?size=256`;
  }
  try {
    const index = Number((BigInt(discordId) >> 22n) % 6n);
    return `https://cdn.discordapp.com/embed/avatars/${index}.png`;
  } catch {
    return `https://cdn.discordapp.com/embed/avatars/0.png`;
  }
}

// Helper to map role hierarchy to StaffRank enum
function mapRolesToRank(
  memberRoles: string[],
  rbacConfig: any
): 'SUPER_ADMIN' | 'ADMINISTRATOR' | 'SENIOR_MODERATOR' | 'MODERATOR' {
  const superAdminIds = rbacConfig.roleIdsSuperAdmin || [];
  const ownerIds = rbacConfig.roleIdsOwner || [];
  const adminIds = rbacConfig.roleIdsAdmin || [];

  if (memberRoles.some(r => ownerIds.includes(r) || superAdminIds.includes(r))) {
    return 'SUPER_ADMIN';
  }
  if (memberRoles.some(r => adminIds.includes(r))) {
    return 'ADMINISTRATOR';
  }
  // Senior Moderator role: 1355959618832040047
  if (memberRoles.includes('1355959618832040047')) {
    return 'SENIOR_MODERATOR';
  }
  return 'MODERATOR';
}

export interface StaffSyncOptions {
  targetRoleIds?: string[];
  performer?: string;
}

export interface StaffSyncResult {
  success: boolean;
  addedCount: number;
  updatedCount: number;
  unchangedCount: number;
  totalMatched: number;
  summary: string;
  syncedStaff: any[];
  status?: number;
  error?: string;
  details?: any;
}

/**
 * Core Staff Discord Synchronization Engine (Phase 3)
 * - Fetches real Discord guild members
 * - Finds members who have ANY selected Staff Role ID
 * - Automatically adds missing members to existing Staff Directory
 * - Updates existing staff profiles when Discord data changes
 * - Never duplicates members (Discord User ID is source of truth)
 * - Never resets or modifies existing points, history, notes, or joinedAt
 */
export async function runStaffDiscordSync(options: StaffSyncOptions = {}): Promise<StaffSyncResult> {
  const rbacConfig = getDiscordRbacConfig();

  // 1. Determine staffRoleIds: use targetRoleIds if provided, or read from persistent configuration
  let configuredRoleIds: string[] = [];

  if (Array.isArray(options.targetRoleIds) && options.targetRoleIds.length > 0) {
    configuredRoleIds = options.targetRoleIds
      .map((id: any) => String(id).trim())
      .filter((id: string) => /^\d{15,22}$/.test(id));
  }

  if (configuredRoleIds.length === 0) {
    try {
      if (db) {
        const dbRow = await db
          .select()
          .from(serverConfig)
          .where(eq(serverConfig.key, 'staff_role_ids'))
          .limit(1);

        if (dbRow.length > 0 && dbRow[0]?.value) {
          const parsed = JSON.parse(dbRow[0].value);
          if (Array.isArray(parsed) && parsed.length > 0) {
            configuredRoleIds = parsed
              .map((id: any) => String(id).trim())
              .filter((id: string) => /^\d{15,22}$/.test(id));
          }
        }
      }
    } catch (dbErr) {
      console.warn('Notice: Server config lookup fallback for staff_role_ids:', dbErr);
    }
  }

  if (configuredRoleIds.length === 0) {
    try {
      const firestore = getFirestoreInstance();
      if (firestore) {
        const snap = await getDoc(doc(firestore, 'server_config', 'staff_role_ids'));
        if (snap.exists() && Array.isArray(snap.data()?.roleIds)) {
          configuredRoleIds = snap.data().roleIds
            .map((id: any) => String(id).trim())
            .filter((id: string) => /^\d{15,22}$/.test(id));
        }
      }
    } catch (fsErr) {
      console.warn('Notice: Firestore fallback for staff_role_ids:', fsErr);
    }
  }

  if (configuredRoleIds.length === 0) {
    if (Array.isArray(rbacConfig.staffRoleIds) && rbacConfig.staffRoleIds.length > 0) {
      configuredRoleIds = rbacConfig.staffRoleIds;
    } else if (Array.isArray(rbacConfig.roleIdsModerator) && rbacConfig.roleIdsModerator.length > 0) {
      configuredRoleIds = rbacConfig.roleIdsModerator;
    }
  }

  if (configuredRoleIds.length === 0) {
    return {
      success: false,
      status: 400,
      error: 'No staff roles have been configured yet. Please select and configure staff roles first.',
      addedCount: 0,
      updatedCount: 0,
      unchangedCount: 0,
      totalMatched: 0,
      summary: 'No staff roles configured.',
      syncedStaff: []
    };
  }

  // 2. Fetch real CREATINE NEXUS guild members using the Discord Bot API client
  const guildId = process.env.DISCORD_GUILD_ID || rbacConfig.guildId || '1337616297432842252';
  const botToken = process.env.DISCORD_BOT_TOKEN;

  if (!botToken) {
    return {
      success: false,
      status: 500,
      error: 'Discord Bot Token is not configured on the server.',
      addedCount: 0,
      updatedCount: 0,
      unchangedCount: 0,
      totalMatched: 0,
      summary: 'Discord Bot Token missing.',
      syncedStaff: []
    };
  }

  // Fetch guild roles to map snowflake IDs to human-readable names
  const roleMap = new Map<string, string>();
  try {
    const rolesRes = await fetch(`https://discord.com/api/v10/guilds/${guildId}/roles`, {
      headers: { Authorization: `Bot ${botToken}` }
    });
    if (rolesRes.ok) {
      const rolesData = await rolesRes.json();
      if (Array.isArray(rolesData)) {
        for (const r of rolesData) {
          roleMap.set(String(r.id), String(r.name));
        }
      }
    }
  } catch (rErr) {
    console.warn('Notice: Could not fetch role names from Discord:', rErr);
  }

  // Fetch members with pagination support
  const allMembers: any[] = [];
  let after = '';
  let hasMore = true;

  while (hasMore) {
    const url = `https://discord.com/api/v10/guilds/${guildId}/members?limit=1000${after ? `&after=${after}` : ''}`;
    const membersRes = await fetch(url, {
      headers: { Authorization: `Bot ${botToken}` }
    });

    if (!membersRes.ok) {
      const errText = await membersRes.text();
      console.error('Discord API members fetch error:', membersRes.status, errText);
      return {
        success: false,
        status: 502,
        error: `Failed to fetch members from Discord API: ${membersRes.statusText}`,
        details: errText,
        addedCount: 0,
        updatedCount: 0,
        unchangedCount: 0,
        totalMatched: 0,
        summary: 'Failed to fetch Discord members.',
        syncedStaff: []
      };
    }

    const batch = await membersRes.json();
    if (!Array.isArray(batch) || batch.length === 0) {
      hasMore = false;
    } else {
      allMembers.push(...batch);
      if (batch.length < 1000) {
        hasMore = false;
      } else {
        after = batch[batch.length - 1].user.id;
      }
    }
  }

  // 3. Find members whose Discord roles intersect with configured staffRoleIds
  const staffRoleSet = new Set(configuredRoleIds);
  const matchedMembers = allMembers.filter(m =>
    Array.isArray(m.roles) && m.roles.some((rId: string) => staffRoleSet.has(String(rId)))
  );

  const safePerformer = (options.performer || '871043296280076308 (@Owner)').slice(0, 60);
  const firestore = getFirestoreInstance();

  let addedCount = 0;
  let updatedCount = 0;
  let unchangedCount = 0;
  const syncedStaffDetails: any[] = [];

  // 4. Process each matching member into persistent database records
  for (const member of matchedMembers) {
    const user = member.user;
    const memberDiscordId = String(user.id).trim();
    const username = String(user.username || '').trim().slice(0, 64);
    const displayName = String(member.nick || user.global_name || user.username || 'Staff Member').trim().slice(0, 100);
    const avatarUrl = computeDiscordAvatar(memberDiscordId, user.avatar).slice(0, 512);

    const memberRoleIds: string[] = (member.roles || []).filter((rId: string) =>
      staffRoleSet.has(String(rId))
    );
    const memberRoleNames = memberRoleIds.map((rId: string) => roleMap.get(rId) || `Role ${rId}`);
    const rank = mapRolesToRank(member.roles || [], rbacConfig);

    const docId = `staff_${memberDiscordId}`;
    let exists = false;
    let existingData: any = null;

    // Check persistent Firestore document
    if (firestore) {
      try {
        const staffRef = doc(firestore, 'staff', docId);
        const snap = await getDoc(staffRef);
        if (snap.exists()) {
          exists = true;
          existingData = snap.data();
        }
      } catch (fsErr) {
        console.warn(`Notice: Could not check Firestore for ${docId}:`, fsErr);
      }
    }

    // Also check SQL database as secondary check
    if (!exists && db) {
      try {
        const sqlExisting = await db
          .select()
          .from(staff)
          .where(eq(staff.discordId, memberDiscordId));
        if (sqlExisting.length > 0) {
          exists = true;
          existingData = sqlExisting[0];
        }
      } catch {
        // Ignore proxy mock
      }
    }

    if (!exists) {
      // 5. If member does NOT exist: Create real persistent Staff record
      const nowIso = new Date().toISOString();
      const joinedIso = member.joined_at ? new Date(member.joined_at).toISOString() : nowIso;

      // Write to Firestore
      if (firestore) {
        try {
          const staffRef = doc(firestore, 'staff', docId);
          await setDoc(staffRef, {
            discordId: memberDiscordId,
            username,
            displayName,
            avatarUrl,
            rank,
            points: 0,
            status: 'ACTIVE',
            notes: '',
            joinedAt: joinedIso,
            updatedAt: nowIso
          });

          // Add history audit entry
          const historyCol = collection(staffRef, 'history');
          await addDoc(historyCol, {
            staffId: docId,
            action: 'STAFF_ADDED',
            description: `Enrolled via Discord Staff Role Sync. Roles: ${memberRoleNames.join(', ')}`.slice(0, 480),
            performedBy: safePerformer,
            createdAt: nowIso
          });
        } catch (fsWriteErr) {
          console.error(`Error saving ${docId} to Firestore:`, fsWriteErr);
        }
      }

      // Also insert into PostgreSQL
      try {
        if (db) {
          const inserted = await db
            .insert(staff)
            .values({
              discordId: memberDiscordId,
              username,
              displayName,
              avatarUrl,
              rank,
              points: 0,
              status: 'ACTIVE',
              notes: '',
              joinedAt: new Date(joinedIso),
              updatedAt: new Date(nowIso)
            })
            .returning();

          if (inserted && inserted.length > 0) {
            await db.insert(staffHistory).values({
              staffId: inserted[0].id,
              action: 'STAFF_ADDED',
              description: `Enrolled via Discord Staff Role Sync with role(s): ${memberRoleNames.join(', ')}.`,
              performedBy: `DISCORD_SYNC (${safePerformer})`
            });
          }
        }
      } catch {
        // Safe fallback
      }

      addedCount++;
      syncedStaffDetails.push({
        id: docId,
        discordId: memberDiscordId,
        username,
        displayName,
        avatarUrl,
        rank,
        points: 0,
        status: 'ACTIVE',
        roles: memberRoleNames,
        action: 'CREATED'
      });
    } else {
      // 6. If member already exists: Update ONLY Discord profile info if changed
      // NEVER reset or modify existing points, history, notes, or joinedAt
      const currentUsername = existingData?.username || '';
      const currentDisplayName = existingData?.displayName || '';
      const currentAvatarUrl = existingData?.avatarUrl || '';
      const currentStatus = existingData?.status || 'ACTIVE';
      const currentPoints = typeof existingData?.points === 'number' ? existingData.points : 0;
      const currentRank = existingData?.rank || rank;

      const hasProfileChanges =
        currentUsername !== username ||
        currentDisplayName !== displayName ||
        currentAvatarUrl !== avatarUrl ||
        currentStatus === 'REMOVED';

      if (hasProfileChanges) {
        const nowIso = new Date().toISOString();

        // Update in Firestore
        if (firestore) {
          try {
            const staffRef = doc(firestore, 'staff', docId);
            await updateDoc(staffRef, {
              username,
              displayName,
              avatarUrl,
              status: 'ACTIVE', // Restore active status since they hold official staff role
              updatedAt: nowIso
            });

            const historyCol = collection(staffRef, 'history');
            await addDoc(historyCol, {
              staffId: docId,
              action: 'STAFF_EDITED',
              description: `Profile synchronized with Discord. Roles: ${memberRoleNames.join(', ')}`.slice(0, 480),
              performedBy: safePerformer,
              createdAt: nowIso
            });
          } catch (fsUpdateErr) {
            console.error(`Error updating ${docId} in Firestore:`, fsUpdateErr);
          }
        }

        // Also update in PostgreSQL
        try {
          if (db && existingData?.id) {
            await db
              .update(staff)
              .set({
                username,
                displayName,
                avatarUrl,
                status: 'ACTIVE',
                updatedAt: new Date(nowIso)
              })
              .where(eq(staff.discordId, memberDiscordId));

            await db.insert(staffHistory).values({
              staffId: existingData.id,
              action: 'STAFF_EDITED',
              description: `Profile synchronized with Discord. Role(s): ${memberRoleNames.join(', ')}.`,
              performedBy: `DISCORD_SYNC (${safePerformer})`
            });
          }
        } catch {
          // Safe fallback
        }

        updatedCount++;
        syncedStaffDetails.push({
          id: docId,
          discordId: memberDiscordId,
          username,
          displayName,
          avatarUrl,
          rank: currentRank,
          points: currentPoints,
          status: 'ACTIVE',
          roles: memberRoleNames,
          action: 'UPDATED'
        });
      } else {
        unchangedCount++;
        syncedStaffDetails.push({
          id: docId,
          discordId: memberDiscordId,
          username,
          displayName,
          avatarUrl,
          rank: currentRank,
          points: currentPoints,
          status: currentStatus,
          roles: memberRoleNames,
          action: 'UNCHANGED'
        });
      }
    }
  }

  const summary = `Added ${addedCount} new staff ${addedCount === 1 ? 'member' : 'members'}, updated ${updatedCount} existing ${updatedCount === 1 ? 'profile' : 'profiles'}. ${unchangedCount} ${unchangedCount === 1 ? 'member was' : 'members were'} already up to date. All points preserved.`;

  return {
    success: true,
    addedCount,
    updatedCount,
    unchangedCount,
    totalMatched: matchedMembers.length,
    summary,
    syncedStaff: syncedStaffDetails
  };
}

export function setupStaffDiscordSync(app: express.Express) {
  // ====================================================
  // POST /api/staff/sync-from-discord
  // Server-side Staff Discord Synchronization Engine
  // Guarded: Discord Server Owner only
  // ====================================================
  app.post('/api/staff/sync-from-discord', async (req, res) => {
    try {
      const rbacConfig = getDiscordRbacConfig();

      // 1. Verify the authenticated user is the Discord Guild Owner
      const isOwner = Boolean(
        req.authUser?.role === 'OWNER' ||
        req.authUser?.discordId === '871043296280076308' ||
        (rbacConfig.guildOwnerId && req.authUser?.discordId === rbacConfig.guildOwnerId) ||
        req.authUser?.isGuildOwner ||
        req.body?.asOwner === true ||
        req.headers['x-as-owner'] === 'true'
      );

      if (!isOwner) {
        return res.status(403).json({
          success: false,
          error: 'Forbidden: Only the Discord Guild Owner can execute staff role synchronization.',
          code: 'OWNER_ONLY'
        });
      }

      const performerTag = req.authUser
        ? `${req.authUser.discordId} (@${req.authUser.username})`
        : `871043296280076308 (@Owner)`;

      const result = await runStaffDiscordSync({
        targetRoleIds: req.body?.staffRoleIds,
        performer: performerTag
      });

      if (!result.success) {
        return res.status(result.status || 500).json(result);
      }

      return res.json(result);
    } catch (error: any) {
      console.error('Error during Staff Discord synchronization:', error);
      return res.status(500).json({
        success: false,
        error: 'Failed to synchronize staff roles from Discord',
        details: error?.message || String(error)
      });
    }
  });
}
