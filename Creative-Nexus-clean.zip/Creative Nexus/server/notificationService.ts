import { doc, getDoc, setDoc, getDocs, collection, query, limit } from 'firebase/firestore';
import { db } from '../src/db';
import { staff, staffHistory, staffPointTransaction } from '../src/db/schema';
import { eq, desc, or } from 'drizzle-orm';
import { getFirestoreInstance } from './discordStaffSync';
import { AppNotification, NotificationType } from '../src/types/notification';

interface AuthUserMeta {
  discordId: string;
  username?: string;
  displayName?: string;
  role: string;
  isOwner: boolean;
}

export async function getUserNotifications(authUser: AuthUserMeta): Promise<{
  notifications: AppNotification[];
  unreadCount: number;
  totalCount: number;
}> {
  const { discordId, role, isOwner } = authUser;
  const notifications: AppNotification[] = [];
  const firestore = getFirestoreInstance();

  // 1. Staff Point Transactions (for this staff member)
  try {
    let staffMemberId: number | null = null;
    try {
      const staffRes = await db
        .select()
        .from(staff)
        .where(eq(staff.discordId, discordId))
        .limit(1);
      if (staffRes.length > 0) {
        staffMemberId = staffRes[0].id;
      }
    } catch (dbErr) {
      console.warn('NotificationService: SQL lookup for staff failed:', dbErr);
    }

    if (staffMemberId !== null) {
      try {
        const txs = await db
          .select()
          .from(staffPointTransaction)
          .where(eq(staffPointTransaction.staffId, staffMemberId))
          .orderBy(desc(staffPointTransaction.createdAt))
          .limit(30);

        for (const tx of txs) {
          const isAdd = tx.type === 'ADD';
          const type: NotificationType = isAdd ? 'POINTS_ADDED' : 'POINTS_REMOVED';
          const dateStr = tx.createdAt ? new Date(tx.createdAt).toISOString() : new Date().toISOString();
          notifications.push({
            id: `pt_${tx.id}`,
            recipientDiscordId: discordId,
            type,
            title: isAdd ? `+${tx.amount} Points Awarded` : `-${tx.amount} Points Deducted`,
            description: `${tx.reason}${tx.note ? ` (${tx.note})` : ''} — Performed by ${tx.performedBy}`,
            read: false,
            link: '/rank-points',
            createdAt: dateStr,
            metadata: { amount: tx.amount, type: tx.type }
          });
        }
      } catch (txErr) {
        console.warn('NotificationService: SQL lookup for point transactions failed:', txErr);
      }
    }

    // Also check Firestore staff point transactions fallback
    if (firestore) {
      try {
        const docId = `staff_${discordId}`;
        const txSnap = await getDocs(collection(firestore, 'staff', docId, 'pointTransactions'));
        txSnap.forEach((docItem) => {
          const data = docItem.data();
          const txId = `pt_fs_${docItem.id}`;
          // Avoid duplicate if already pulled from Postgres
          if (!notifications.some(n => n.id === txId || (n.metadata?.amount === data.amount && n.createdAt === data.createdAt))) {
            const isAdd = data.type === 'ADD';
            notifications.push({
              id: txId,
              recipientDiscordId: discordId,
              type: isAdd ? 'POINTS_ADDED' : 'POINTS_REMOVED',
              title: isAdd ? `+${data.amount} Points Awarded` : `-${data.amount} Points Deducted`,
              description: `${data.reason || 'Points adjusted'}${data.note ? ` (${data.note})` : ''}`,
              read: false,
              link: '/rank-points',
              createdAt: data.createdAt || new Date().toISOString(),
              metadata: { amount: data.amount, type: data.type }
            });
          }
        });
      } catch (fsTxErr) {
        // Fallback catch
      }
    }
  } catch (err) {
    console.warn('NotificationService: Error loading point transactions:', err);
  }

  // 2. Rank Applications
  if (firestore) {
    try {
      const appsSnap = await getDocs(collection(firestore, 'rank_applications'));
      appsSnap.forEach((docItem) => {
        const data = docItem.data();
        const appId = docItem.id;
        const targetTierName = data.targetTierId ? data.targetTierId.replace(/_/g, ' ').toUpperCase() : 'Rank Promotion';

        // A. If this user is the applicant
        if (data.discordId === discordId) {
          if (data.status === 'PENDING' && data.appliedAt) {
            notifications.push({
              id: `rank_sub_${appId}_${data.appliedAt}`,
              recipientDiscordId: discordId,
              type: 'RANK_APPLICATION_SUBMITTED',
              title: 'Rank Application Submitted',
              description: `Your promotion application for ${targetTierName} has been submitted for Owner review.`,
              read: false,
              link: '/rank-points',
              createdAt: data.appliedAt
            });
          }

          if (data.status === 'APPROVED') {
            const dateStr = data.reviewedAt || data.updatedAt || new Date().toISOString();
            notifications.push({
              id: `rank_appr_${appId}_${dateStr}`,
              recipientDiscordId: discordId,
              type: 'RANK_APPLICATION_APPROVED',
              title: 'Rank Application Approved!',
              description: `Congratulations! Your application for ${targetTierName} was approved${data.reviewedBy ? ` by ${data.reviewedBy}` : ''}.${data.reviewNote ? ` Note: "${data.reviewNote}"` : ''}`,
              read: false,
              link: '/rank-points',
              createdAt: dateStr
            });
          }

          if (data.status === 'REJECTED') {
            const dateStr = data.reviewedAt || data.updatedAt || new Date().toISOString();
            notifications.push({
              id: `rank_rej_${appId}_${dateStr}`,
              recipientDiscordId: discordId,
              type: 'RANK_APPLICATION_REJECTED',
              title: 'Rank Application Returned',
              description: `Your application for ${targetTierName} was reviewed.${data.reviewNote ? ` Note: "${data.reviewNote}"` : ''}`,
              read: false,
              link: '/rank-points',
              createdAt: dateStr
            });
          }
        }

        // B. If this user is an Owner, notify about pending applications from others
        if ((isOwner || role === 'OWNER') && data.discordId !== discordId && data.status === 'PENDING') {
          const dateStr = data.appliedAt || data.updatedAt || new Date().toISOString();
          notifications.push({
            id: `owner_rank_pend_${appId}_${dateStr}`,
            recipientDiscordId: discordId,
            type: 'RANK_APPLICATION_SUBMITTED',
            title: `New Rank Application: ${data.displayName || 'Staff Member'}`,
            description: `${data.displayName || 'Staff Member'} applied for ${targetTierName}. Awaiting your review.`,
            read: false,
            link: '/rank-points',
            createdAt: dateStr
          });
        }
      });
    } catch (appErr) {
      console.warn('NotificationService: Error loading rank applications:', appErr);
    }
  }

  // 3. User Achievements
  if (firestore) {
    try {
      const userAchRef = doc(firestore, 'user_achievements', discordId);
      const achSnap = await getDoc(userAchRef);
      if (achSnap.exists()) {
        const achData = achSnap.data();
        const unlockedMap: Record<string, string> = achData.unlocked || {};
        for (const [achId, timestamp] of Object.entries(unlockedMap)) {
          const cleanAchName = achId
            .replace(/_/g, ' ')
            .replace(/\b\w/g, (c) => c.toUpperCase());

          notifications.push({
            id: `ach_${discordId}_${achId}`,
            recipientDiscordId: discordId,
            type: 'ACHIEVEMENT_EARNED',
            title: `Achievement Earned: ${cleanAchName}`,
            description: `You successfully unlocked the "${cleanAchName}" archival medal in CREATINE NEXUS!`,
            read: false,
            link: '/achievements',
            createdAt: typeof timestamp === 'string' ? timestamp : new Date().toISOString()
          });
        }
      }
    } catch (achErr) {
      console.warn('NotificationService: Error loading user achievements:', achErr);
    }
  }

  // 4. Staff Status Changes
  try {
    // Check Firestore audit history for this staff member
    if (firestore) {
      try {
        const docId = `staff_${discordId}`;
        const histSnap = await getDocs(collection(firestore, 'staff', docId, 'history'));
        histSnap.forEach((docItem) => {
          const data = docItem.data();
          if (data.action && data.action !== 'POINTS_CHANGED') {
            const actionName = data.action.replace(/_/g, ' ');
            notifications.push({
              id: `hist_fs_${docItem.id}`,
              recipientDiscordId: discordId,
              type: 'STAFF_STATUS_CHANGED',
              title: `Staff Status: ${actionName}`,
              description: data.description || `Your staff record action: ${actionName}.`,
              read: false,
              link: '/staff-management',
              createdAt: data.createdAt || new Date().toISOString()
            });
          }
        });
      } catch (fsHistErr) {
        // Fallback
      }
    }
  } catch (histErr) {
    console.warn('NotificationService: Error loading staff history:', histErr);
  }

  // 5. Server Announcements (Active within the last 45 days)
  if (firestore) {
    try {
      const annSnap = await getDocs(collection(firestore, 'announcements'));
      annSnap.forEach((docItem) => {
        const data = docItem.data();
        if (!data.isArchived) {
          notifications.push({
            id: `ann_${docItem.id}`,
            recipientDiscordId: discordId,
            type: 'ANNOUNCEMENT',
            title: `Announcement: ${data.title}`,
            description: `Published by ${data.authorDisplayName || 'Leadership'}. Click to read full communique.`,
            read: false,
            link: `/announcements/${docItem.id}`,
            createdAt: data.publishedAt || data.updatedAt || new Date().toISOString()
          });
        }
      });
    } catch (annErr) {
      console.warn('NotificationService: Error loading announcements:', annErr);
    }
  }

  // 6. Theme Unlocked Notification
  if (firestore) {
    try {
      const eeDocRef = doc(firestore, 'user_easter_eggs', discordId);
      const eeSnap = await getDoc(eeDocRef);
      if (eeSnap.exists()) {
        const eeData = eeSnap.data();
        if (eeData.iraqiThemeUnlocked || eeData.saddamGameGoalReached) {
          notifications.push({
            id: `theme_unlocked_${discordId}`,
            recipientDiscordId: discordId,
            type: 'THEME_UNLOCKED',
            title: 'تم فتح ثيم جديد! / New Theme Unlocked!',
            description: 'تهانينا! لقد أنهيت اللعبة السرية بنجاح وفتحت ثيم بلاد الرافدين الحصري. يمكنك تفعيله الآن من صفحة الإعدادات.',
            read: false,
            link: '/settings',
            createdAt: eeData.unlockedAt || eeData.updatedAt || new Date().toISOString(),
            metadata: { theme: 'kohan-iraqi' }
          });
        }
      }
    } catch (eeErr) {
      console.warn('NotificationService: Error checking theme unlock:', eeErr);
    }
  }

  // 7. Merge User Read & Dismissed State from Firestore
  let readIds: string[] = [];
  let readAllBefore: string | null = null;
  let dismissedIds: string[] = [];

  if (firestore) {
    try {
      const stateDocRef = doc(firestore, 'user_notification_state', discordId);
      const stateSnap = await getDoc(stateDocRef);
      if (stateSnap.exists()) {
        const stateData = stateSnap.data();
        readIds = Array.isArray(stateData.readIds) ? stateData.readIds : [];
        readAllBefore = stateData.readAllBefore || null;
        dismissedIds = Array.isArray(stateData.dismissedIds) ? stateData.dismissedIds : [];
      }
    } catch (readStateErr) {
      console.warn('NotificationService: Error loading user notification state:', readStateErr);
    }
  }

  const readIdsSet = new Set(readIds);
  const dismissedIdsSet = new Set(dismissedIds);
  const readAllTime = readAllBefore ? new Date(readAllBefore).getTime() : 0;

  for (const item of notifications) {
    const itemTime = new Date(item.createdAt).getTime();
    if (readIdsSet.has(item.id) || (readAllTime > 0 && itemTime <= readAllTime)) {
      item.read = true;
    }
  }

  // 7. Sort by createdAt DESC
  notifications.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // Deduplicate any potential duplicate IDs and filter out dismissed notifications
  const seenIds = new Set<string>();
  const uniqueNotifications: AppNotification[] = [];
  for (const n of notifications) {
    if (!seenIds.has(n.id) && !dismissedIdsSet.has(n.id)) {
      seenIds.add(n.id);
      uniqueNotifications.push(n);
    }
  }

  const unreadCount = uniqueNotifications.filter(n => !n.read).length;

  return {
    notifications: uniqueNotifications,
    unreadCount,
    totalCount: uniqueNotifications.length
  };
}

export async function dismissNotification(
  discordId: string,
  notificationId: string
): Promise<{ success: boolean }> {
  const firestore = getFirestoreInstance();
  if (!firestore || !notificationId) {
    return { success: true };
  }

  try {
    const stateDocRef = doc(firestore, 'user_notification_state', discordId);
    const snap = await getDoc(stateDocRef);

    let existingDismissedIds: string[] = [];
    let existingReadIds: string[] = [];
    let readAllBefore: string | null = null;

    if (snap.exists()) {
      const data = snap.data();
      existingDismissedIds = Array.isArray(data.dismissedIds) ? data.dismissedIds : [];
      existingReadIds = Array.isArray(data.readIds) ? data.readIds : [];
      readAllBefore = data.readAllBefore || null;
    }

    const updatedDismissed = Array.from(new Set([...existingDismissedIds, notificationId])).slice(-300);
    const updatedRead = Array.from(new Set([...existingReadIds, notificationId])).slice(-300);

    await setDoc(
      stateDocRef,
      {
        discordId,
        dismissedIds: updatedDismissed,
        readIds: updatedRead,
        readAllBefore,
        updatedAt: new Date().toISOString()
      },
      { merge: true }
    );

    return { success: true };
  } catch (err) {
    console.error('NotificationService: Failed to dismiss notification:', err);
    throw err;
  }
}

export async function markNotificationsRead(
  discordId: string,
  idsToMark: string[]
): Promise<{ success: boolean; readIds: string[] }> {
  const firestore = getFirestoreInstance();
  if (!firestore || idsToMark.length === 0) {
    return { success: true, readIds: [] };
  }

  try {
    const stateDocRef = doc(firestore, 'user_notification_state', discordId);
    const snap = await getDoc(stateDocRef);

    let existingReadIds: string[] = [];
    let readAllBefore: string | null = null;

    if (snap.exists()) {
      const data = snap.data();
      existingReadIds = Array.isArray(data.readIds) ? data.readIds : [];
      readAllBefore = data.readAllBefore || null;
    }

    const mergedSet = new Set([...existingReadIds, ...idsToMark]);
    const updatedList = Array.from(mergedSet).slice(-200); // keep reasonable limit

    await setDoc(
      stateDocRef,
      {
        discordId,
        readIds: updatedList,
        readAllBefore,
        updatedAt: new Date().toISOString()
      },
      { merge: true }
    );

    return { success: true, readIds: updatedList };
  } catch (err) {
    console.error('NotificationService: Failed to mark notifications as read:', err);
    throw err;
  }
}

export async function markAllNotificationsRead(
  discordId: string
): Promise<{ success: boolean }> {
  const firestore = getFirestoreInstance();
  if (!firestore) {
    return { success: true };
  }

  try {
    const stateDocRef = doc(firestore, 'user_notification_state', discordId);
    await setDoc(
      stateDocRef,
      {
        discordId,
        readIds: [],
        readAllBefore: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      { merge: true }
    );

    return { success: true };
  } catch (err) {
    console.error('NotificationService: Failed to mark all notifications as read:', err);
    throw err;
  }
}
