import { doc, getDoc, setDoc } from 'firebase/firestore';
import { getFirestoreInstance } from './discordStaffSync';
import {
  CardUpgradeSystemConfig,
  CardUpgradeTransitionRule,
  CardUpgradeAttemptResult,
  DEFAULT_CARD_UPGRADE_CONFIG,
  RARITY_PROGRESSION
} from '../src/types/cardUpgrade';
import { CardRarity, CardStatItem, calculateCardOverallRating, calculateCardPowerRating, getUnifiedCardStats } from '../src/types/cards';
import { getUserCardProfile, saveUserProfile, loadCustomCardsFromFirestore, recordTransaction } from './cardService';
import { getUserInventory, saveUserInventory, getUnifiedItemById } from './itemService';

let upgradeConfigCache: CardUpgradeSystemConfig = { ...DEFAULT_CARD_UPGRADE_CONFIG };
let hasLoadedUpgradeConfig = false;

/**
 * Get Card Upgrade Configuration (loaded from Firestore with caching)
 */
export async function getCardUpgradeConfig(forceRefresh = false): Promise<CardUpgradeSystemConfig> {
  if (hasLoadedUpgradeConfig && !forceRefresh) {
    return upgradeConfigCache;
  }

  try {
    const db = getFirestoreInstance();
    if (db) {
      const snap = await getDoc(doc(db, 'settings', 'card_upgrades'));
      if (snap.exists()) {
        const data = snap.data() as Partial<CardUpgradeSystemConfig>;
        upgradeConfigCache = {
          enabled: data.enabled !== false,
          allowUniversalShards: data.allowUniversalShards !== false,
          universalShardItemId: data.universalShardItemId || 'item_shard_universal',
          transitions: {
            ...DEFAULT_CARD_UPGRADE_CONFIG.transitions,
            ...(data.transitions || {})
          },
          updatedAt: data.updatedAt || new Date().toISOString(),
          updatedBy: data.updatedBy
        };
        hasLoadedUpgradeConfig = true;
        return upgradeConfigCache;
      }
    }
  } catch (err: any) {
    console.warn('CardUpgradeService: Note loading upgrade config:', err?.message);
  }

  hasLoadedUpgradeConfig = true;
  return upgradeConfigCache;
}

/**
 * Save Card Upgrade Configuration (Owner only)
 */
export async function saveCardUpgradeConfig(
  config: Partial<CardUpgradeSystemConfig>,
  updatedBy: string
): Promise<CardUpgradeSystemConfig> {
  const current = await getCardUpgradeConfig();
  const updated: CardUpgradeSystemConfig = {
    enabled: config.enabled !== undefined ? config.enabled : current.enabled,
    allowUniversalShards: config.allowUniversalShards !== undefined ? config.allowUniversalShards : current.allowUniversalShards,
    universalShardItemId: config.universalShardItemId || current.universalShardItemId,
    transitions: {
      ...current.transitions,
      ...(config.transitions || {})
    },
    updatedAt: new Date().toISOString(),
    updatedBy
  };

  upgradeConfigCache = updated;

  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'settings', 'card_upgrades'), updated, { merge: true });
    }
  } catch (err: any) {
    console.error('CardUpgradeService: Error saving upgrade config to Firestore:', err);
  }

  return updated;
}

/**
 * Find next rarity in progression
 */
export function getNextRarityTier(currentRarity: CardRarity): CardRarity | null {
  const idx = RARITY_PROGRESSION.indexOf(currentRarity);
  if (idx < 0 || idx >= RARITY_PROGRESSION.length - 1) {
    return null; // Already max rarity
  }
  return RARITY_PROGRESSION[idx + 1];
}

/**
 * Perform a server-validated card upgrade attempt
 */
export async function performCardUpgrade(
  discordId: string,
  cardId: string,
  preferredShardItemId?: string
): Promise<CardUpgradeAttemptResult> {
  const cleanId = String(discordId).trim();
  const profile = await getUserCardProfile(cleanId);
  const ownership = profile.cards[cardId];

  if (!ownership || (ownership.count || 0) < 1) {
    throw new Error('You do not own this card or have 0 copies.');
  }

  // Load card details from catalog
  const catalog = await loadCustomCardsFromFirestore();
  const baseCard = catalog.find(c => c.id === cardId);
  if (!baseCard) {
    throw new Error(`Card definition '${cardId}' was not found in catalog.`);
  }

  // Active rarity: check if previously upgraded, otherwise base rarity
  const currentRarity: CardRarity = ownership.upgradedRarity || baseCard.rarity;
  const nextRarity = getNextRarityTier(currentRarity);

  if (!nextRarity) {
    throw new Error(`This card is already at the maximum rarity tier (${currentRarity})!`);
  }

  const upgradeConfig = await getCardUpgradeConfig();
  if (!upgradeConfig.enabled) {
    throw new Error('The card upgrade matrix is currently in stasis by the Overseer.');
  }

  const transitionKey = `${currentRarity}_TO_${nextRarity}`;
  const rule: CardUpgradeTransitionRule | undefined = upgradeConfig.transitions[transitionKey];

  if (!rule) {
    throw new Error(`No upgrade path configured for transition from ${currentRarity} to ${nextRarity}.`);
  }

  // Duplicate validation: Only accept duplicates of the EXACT same card
  const totalCopies = ownership.count || 1;
  const availableDuplicates = Math.max(0, totalCopies - 1);
  const requiredDuplicates = typeof rule.requiredDuplicates === 'number' ? rule.requiredDuplicates : 0;

  if (availableDuplicates < requiredDuplicates) {
    const missing = requiredDuplicates - availableDuplicates;
    throw new Error(
      `Insufficient duplicate copies! Upgrading '${baseCard.name}' from ${currentRarity} to ${nextRarity} requires ${requiredDuplicates} duplicate ${requiredDuplicates === 1 ? 'copy' : 'copies'} of the exact same card. You currently have ${availableDuplicates} duplicates (${totalCopies} total copies), missing ${missing}.`
    );
  }

  // Check user inventory for required shards
  const inventory = await getUserInventory(cleanId);
  const requiredShardCount = typeof rule.requiredShardCount === 'number' ? rule.requiredShardCount : 0;
  let chosenShardId = rule.requiredShardItemId || '';
  let shardItem = chosenShardId ? await getUnifiedItemById(chosenShardId) : null;
  let availableShards = chosenShardId ? (inventory[chosenShardId]?.count || 0) : 0;

  if (requiredShardCount > 0) {
    // Check if player requested or can use universal shard
    if (
      availableShards < requiredShardCount &&
      upgradeConfig.allowUniversalShards &&
      upgradeConfig.universalShardItemId
    ) {
      const universalCount = inventory[upgradeConfig.universalShardItemId]?.count || 0;
      if (universalCount >= requiredShardCount) {
        chosenShardId = upgradeConfig.universalShardItemId;
        shardItem = await getUnifiedItemById(chosenShardId);
        availableShards = universalCount;
      }
    }

    if (availableShards < requiredShardCount) {
      const shardName = shardItem?.name || chosenShardId || 'Upgrade Shard';
      throw new Error(
        `Insufficient Upgrade Shards! Upgrading from ${currentRarity} to ${nextRarity} requires ${requiredShardCount}x '${shardName}', but you currently have ${availableShards}.`
      );
    }
  }

  // Server-side probability roll (0 - 100)
  const roll = Math.random() * 100;
  const success = roll < rule.successRatePercent;

  // Baseline stats to upgrade from
  const currentAttack = ownership.customAttack ?? baseCard.attack ?? 75;
  const currentDefense = ownership.customDefense ?? baseCard.defense ?? 70;
  const currentHp = ownership.customHp ?? baseCard.hp ?? 80;
  const currentStats = ownership.upgradedStats || getUnifiedCardStats(baseCard);
  const previousOvr = calculateCardOverallRating(currentStats, currentRarity);
  const now = new Date().toISOString();

  if (success) {
    // Deduct duplicate copies
    const duplicatesDeducted = requiredDuplicates;
    ownership.count = Math.max(1, totalCopies - duplicatesDeducted);

    // Deduct shards
    let shardsDeducted = 0;
    if (requiredShardCount > 0 && chosenShardId && inventory[chosenShardId]) {
      shardsDeducted = requiredShardCount;
      inventory[chosenShardId].count = Math.max(0, inventory[chosenShardId].count - shardsDeducted);
      if (inventory[chosenShardId].count === 0) {
        delete inventory[chosenShardId];
      }
      await saveUserInventory(cleanId, inventory);
    }

    const remainingShardCount = chosenShardId ? (inventory[chosenShardId]?.count || 0) : 0;
    const remainingDuplicates = Math.max(0, ownership.count - 1);

    // Calculate new elevated stats
    const mult = rule.statMultiplier || 1.15;
    const boostAtk = rule.flatAttackBoost || 10;
    const boostDef = rule.flatDefenseBoost || 8;
    const boostHp = rule.flatHpBoost || 12;

    const newAttack = Math.min(100, Math.round(currentAttack * mult + boostAtk));
    const newDefense = Math.min(100, Math.round(currentDefense * mult + boostDef));
    const newHp = Math.min(100, Math.round(currentHp * mult + boostHp));

    const newStats: CardStatItem[] = currentStats.map(s => {
      let boosted = Math.round((s.value || 50) * mult);
      if (s.id === 'attack') boosted = newAttack;
      else if (s.id === 'defense') boosted = newDefense;
      else if (s.id === 'hp') boosted = newHp;
      return {
        ...s,
        value: Math.min(100, Math.max(s.value || 0, boosted))
      };
    });

    const newOvr = calculateCardOverallRating(newStats, nextRarity);
    const newPower = calculateCardPowerRating(newStats, nextRarity);
    const newLevel = (ownership.upgradeLevel || 0) + 1;

    // Mutate ownership
    ownership.upgradedRarity = nextRarity;
    ownership.upgradeLevel = newLevel;
    ownership.upgradedStats = newStats;
    ownership.customAttack = newAttack;
    ownership.customDefense = newDefense;
    ownership.customHp = newHp;
    ownership.upgradedAt = now;

    profile.cards[cardId] = ownership;
    profile.updatedAt = now;
    await saveUserProfile(profile);

    await recordTransaction({
      type: 'DAILY_CLAIM',
      userId: cleanId,
      username: profile.username,
      amount: 0,
      balanceAfter: profile.coins,
      performedBy: 'USER',
      reason: `Card Ascended: ${baseCard.name} upgraded from ${currentRarity} to ${nextRarity} (OVR ${previousOvr} -> ${newOvr})`,
      details: {
        cardId,
        previousRarity: currentRarity,
        newRarity: nextRarity,
        duplicatesConsumed: duplicatesDeducted,
        shardsConsumed: shardsDeducted,
        shardItemId: chosenShardId,
        roll: Number(roll.toFixed(1)),
        neededRoll: rule.successRatePercent,
        newOvr
      }
    });

    return {
      success: true,
      cardId,
      cardName: baseCard.name,
      cardNameAr: (baseCard as any).nameAr || baseCard.name,
      previousRarity: currentRarity,
      newRarity: nextRarity,
      duplicatesConsumed: duplicatesDeducted,
      remainingDuplicates,
      shardsConsumed: shardsDeducted,
      consumedItemId: chosenShardId,
      consumedItemName: shardItem?.name || chosenShardId || 'None',
      remainingShardCount,
      roll: Number(roll.toFixed(1)),
      neededRoll: rule.successRatePercent,
      previousOvr,
      newOvr,
      updatedCard: {
        id: cardId,
        rarity: nextRarity,
        attack: newAttack,
        defense: newDefense,
        hp: newHp,
        overallRating: newOvr,
        powerRating: newPower,
        stats: newStats,
        upgradeLevel: newLevel
      },
      message: `ASCENSION SUCCESS! ${baseCard.name} has risen from ${currentRarity} to ${nextRarity}! OVR boosted from ${previousOvr} to ${newOvr}!`,
      messageAr: `تمت الترقية بنجاح! ارتقى ${baseCard.name} من ${currentRarity} إلى ${nextRarity}! ارتفع التقييم العام من ${previousOvr} إلى ${newOvr}!`
    };
  } else {
    // Failure outcome - only consume resources if configured by owner
    let duplicatesDeducted = 0;
    if (rule.consumeDuplicatesOnFailure && requiredDuplicates > 0) {
      duplicatesDeducted = requiredDuplicates;
      ownership.count = Math.max(1, totalCopies - duplicatesDeducted);
      profile.cards[cardId] = ownership;
      profile.updatedAt = now;
      await saveUserProfile(profile);
    }

    let shardsDeducted = 0;
    if (rule.consumeShardsOnFailure && requiredShardCount > 0 && chosenShardId && inventory[chosenShardId]) {
      shardsDeducted = requiredShardCount;
      inventory[chosenShardId].count = Math.max(0, inventory[chosenShardId].count - shardsDeducted);
      if (inventory[chosenShardId].count === 0) {
        delete inventory[chosenShardId];
      }
      await saveUserInventory(cleanId, inventory);
    }

    const remainingShardCount = chosenShardId ? (inventory[chosenShardId]?.count || 0) : 0;
    const remainingDuplicates = Math.max(0, (ownership.count || 1) - 1);

    const dupNote = duplicatesDeducted > 0
      ? `${duplicatesDeducted} duplicate copies consumed`
      : 'Duplicates preserved';
    const shardNote = shardsDeducted > 0
      ? `${shardsDeducted}x ${shardItem?.name || chosenShardId} consumed`
      : 'Shards preserved';

    return {
      success: false,
      cardId,
      cardName: baseCard.name,
      cardNameAr: (baseCard as any).nameAr || baseCard.name,
      previousRarity: currentRarity,
      newRarity: currentRarity,
      duplicatesConsumed: duplicatesDeducted,
      remainingDuplicates,
      shardsConsumed: shardsDeducted,
      consumedItemId: chosenShardId,
      consumedItemName: shardItem?.name || chosenShardId || 'None',
      remainingShardCount,
      roll: Number(roll.toFixed(1)),
      neededRoll: rule.successRatePercent,
      previousOvr,
      newOvr: previousOvr,
      updatedCard: {
        id: cardId,
        rarity: currentRarity,
        attack: currentAttack,
        defense: currentDefense,
        hp: currentHp,
        overallRating: previousOvr,
        powerRating: calculateCardPowerRating(currentStats, currentRarity),
        stats: currentStats,
        upgradeLevel: ownership.upgradeLevel || 0
      },
      message: `Upgrade attempt failed. Roll: ${roll.toFixed(1)}% (Needed < ${rule.successRatePercent}%). ${dupNote}, ${shardNote}. Your card remains safe!`,
      messageAr: `فشلت محاولة الترقية. النتيجة: ${roll.toFixed(1)}% (المطلوب أقل من ${rule.successRatePercent}%). بطاقتك الأصلية بقيت آمنة دون ضرر!`
    };
  }
}
