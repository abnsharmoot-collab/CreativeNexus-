import { Express, Request, Response } from 'express';
import {
  getAllCharacters,
  getAllItems,
  getLoveThresholds,
  getUserCharacterProgress,
  getUserInventory,
  giveGiftToCharacter,
  ownerSaveCharacter,
  ownerDeleteCharacter,
  ownerSaveItem,
  ownerDeleteItem,
  ownerManualAdjust,
  ownerSaveThresholds,
  claimPassiveCoins,
  triggerRandomGift,
  getSpecialRewardsConfig,
  ownerSaveSpecialRewardsConfig,
  ownerResetSpecialRewardCooldown,
  ownerUpdateStageCoins,
  claimSpecialReward
} from './characterLoveService';
import { requireAuth, requireOwner, isOwner } from './discordRbac';
import { recordAuditEvent } from './auditService';

export function setupCharacterLoveRoutes(app: Express) {
  // 1. GET /api/character-love/characters (Public)
  app.get('/api/character-love/characters', async (req: Request, res: Response) => {
    try {
      const characters = await getAllCharacters();
      res.json({ success: true, characters });
    } catch (err: any) {
      console.error('Error in GET /api/character-love/characters:', err);
      res.status(500).json({ error: 'Failed to fetch characters', details: err?.message });
    }
  });

  // 2. GET /api/character-love/items (Public)
  app.get('/api/character-love/items', async (req: Request, res: Response) => {
    try {
      const items = await getAllItems();
      res.json({ success: true, items });
    } catch (err: any) {
      console.error('Error in GET /api/character-love/items:', err);
      res.status(500).json({ error: 'Failed to fetch items', details: err?.message });
    }
  });

  // 3. GET /api/character-love/thresholds (Public)
  app.get('/api/character-love/thresholds', async (req: Request, res: Response) => {
    try {
      const thresholds = await getLoveThresholds();
      res.json({ success: true, thresholds });
    } catch (err: any) {
      console.error('Error in GET /api/character-love/thresholds:', err);
      res.status(500).json({ error: 'Failed to fetch thresholds', details: err?.message });
    }
  });

  // 4. GET /api/character-love/progress (User state)
  app.get('/api/character-love/progress', async (req: Request, res: Response) => {
    try {
      const user = (req as any).authUser;
      const targetId = user?.discordId || (req.query.discordId as string) || 'guest_user';
      const progress = await getUserCharacterProgress(targetId);
      res.json({ success: true, discordId: targetId, progress });
    } catch (err: any) {
      console.error('Error in GET /api/character-love/progress:', err);
      res.status(500).json({ error: 'Failed to fetch character progress', details: err?.message });
    }
  });

  // 5. GET /api/character-love/inventory (User inventory)
  app.get('/api/character-love/inventory', async (req: Request, res: Response) => {
    try {
      const user = (req as any).authUser;
      const targetId = user?.discordId || (req.query.discordId as string) || 'guest_user';
      const inventory = await getUserInventory(targetId);
      res.json({ success: true, discordId: targetId, inventory });
    } catch (err: any) {
      console.error('Error in GET /api/character-love/inventory:', err);
      res.status(500).json({ error: 'Failed to fetch inventory', details: err?.message });
    }
  });

  // 6. POST /api/character-love/give-gift (Give Item)
  app.post('/api/character-love/give-gift', async (req: Request, res: Response) => {
    try {
      const user = (req as any).authUser;
      const targetId = user?.discordId || req.body.discordId || 'guest_user';
      const { characterId, itemId, count } = req.body;

      if (!characterId || !itemId) {
        return res.status(400).json({ error: 'characterId and itemId are required' });
      }

      const result = await giveGiftToCharacter(targetId, characterId, itemId, count || 1);

      try {
        await recordAuditEvent({
          eventType: 'INTERACTION',
          category: 'COMPANION',
          action: `Gift given to ${characterId} (+${result.pointsAwarded} pts, Level ${result.newLevel})`,
          path: '/characters',
          targetElement: `companion_${characterId}`
        }, req);
      } catch {}

      res.json(result);
    } catch (err: any) {
      console.error('Error in POST /api/character-love/give-gift:', err);
      res.status(400).json({ error: err?.message || 'Failed to give gift' });
    }
  });

  // 6b. POST /api/character-love/characters/:characterId/claim-coins (Passive 12h coin generator)
  app.post('/api/character-love/characters/:characterId/claim-coins', async (req: Request, res: Response) => {
    try {
      const user = (req as any).authUser;
      const targetId = user?.discordId || req.body.discordId || 'guest_user';
      const characterId = String(req.params.characterId);

      const result = await claimPassiveCoins(targetId, characterId);

      try {
        await recordAuditEvent({
          eventType: 'INTERACTION',
          category: 'COMPANION',
          action: `Claimed passive coin reward from ${characterId} (+${result.coinsAwarded} Coins, Stage ${result.stageNumber})`,
          path: '/characters',
          targetElement: `companion_${characterId}`
        }, req);
      } catch {}

      res.json(result);
    } catch (err: any) {
      const msg = err?.message || 'Failed to claim coins';
      if (msg.startsWith('COOLDOWN_ACTIVE:')) {
        const parts = msg.split(':');
        const remainingMs = parseInt(parts[1]) || 0;
        const nextClaimAt = parts.slice(2).join(':');
        return res.status(400).json({
          error: 'Cooldown is active. You must wait 12 hours between coin claims.',
          isCooldown: true,
          remainingMs,
          nextClaimAvailableAt: nextClaimAt
        });
      }
      console.error('Error in claim-coins:', err);
      res.status(400).json({ error: msg });
    }
  });

  // 6c. POST /api/character-love/characters/:characterId/trigger-gift (Random Companion Gift)
  app.post('/api/character-love/characters/:characterId/trigger-gift', async (req: Request, res: Response) => {
    try {
      const user = (req as any).authUser;
      const targetId = user?.discordId || req.body.discordId || 'guest_user';
      const characterId = String(req.params.characterId);

      const result = await triggerRandomGift(targetId, characterId);

      try {
        if (result.giftDropped && result.gift) {
          await recordAuditEvent({
            eventType: 'INTERACTION',
            category: 'COMPANION',
            action: `Received surprise gift "${result.gift.name}" from ${characterId}`,
            path: '/characters',
            targetElement: `companion_${characterId}`
          }, req);
        }
      } catch {}

      res.json(result);
    } catch (err: any) {
      console.error('Error in trigger-gift:', err);
      res.status(400).json({ error: err?.message || 'Failed to trigger gift' });
    }
  });

  // 6d. GET /api/character-love/special-rewards/config (Public)
  app.get('/api/character-love/special-rewards/config', async (req: Request, res: Response) => {
    try {
      const config = await getSpecialRewardsConfig();
      res.json({ success: true, config });
    } catch (err: any) {
      console.error('Error fetching special rewards config:', err);
      res.status(500).json({ error: 'Failed to fetch special rewards config', details: err?.message });
    }
  });

  // 6e. POST /api/character-love/characters/:characterId/claim-special-reward (3-Day Special Reward)
  app.post('/api/character-love/characters/:characterId/claim-special-reward', async (req: Request, res: Response) => {
    try {
      const user = (req as any).authUser;
      const targetId = user?.discordId || req.body.discordId || 'guest_user';
      const characterId = String(req.params.characterId);

      const result = await claimSpecialReward(targetId, characterId);

      try {
        await recordAuditEvent({
          eventType: 'INTERACTION',
          category: 'COMPANION',
          action: `Claimed 3-Day Special Reward "${result.reward.name}" (${result.awardedType}) from ${characterId}`,
          path: '/characters',
          targetElement: `companion_${characterId}`
        }, req);
      } catch {}

      res.json(result);
    } catch (err: any) {
      const msg = err?.message || 'Failed to claim special reward';
      if (msg.startsWith('COOLDOWN_ACTIVE:')) {
        const parts = msg.split(':');
        const remainingMs = parseInt(parts[1]) || 0;
        const nextClaimAt = parts.slice(2).join(':');
        return res.status(400).json({
          error: 'Special 3-day reward cooldown is active.',
          isCooldown: true,
          remainingMs,
          nextClaimAvailableAt: nextClaimAt
        });
      }
      console.error('Error in claim-special-reward:', err);
      res.status(400).json({ error: msg });
    }
  });

  // ----------------------------------------------------
  // OWNER CONTROLS (SECURED)
  // ----------------------------------------------------

  // 7. POST /api/character-love/owner/character
  app.post('/api/character-love/owner/character', requireAuth, requireOwner, async (req: Request, res: Response) => {
    try {
      const user = (req as any).authUser;
      const character = await ownerSaveCharacter(req.body, user?.username || 'Owner');

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'COMPANION',
        action: `Server Owner saved character: "${character.name}" (${character.id})`,
        path: '/characters',
        targetElement: `companion_${character.id}`
      }, req);

      res.json({ success: true, character });
    } catch (err: any) {
      console.error('Error saving character:', err);
      res.status(500).json({ error: 'Failed to save character', details: err?.message });
    }
  });

  // 8. DELETE /api/character-love/owner/character/:id
  app.delete('/api/character-love/owner/character/:id', requireAuth, requireOwner, async (req: Request, res: Response) => {
    try {
      const id = String(req.params.id);
      await ownerDeleteCharacter(id);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'COMPANION',
        action: `Server Owner deleted character: ${id}`,
        path: '/characters',
        targetElement: `companion_${id}`
      }, req);

      res.json({ success: true, characterId: id });
    } catch (err: any) {
      console.error('Error deleting character:', err);
      res.status(500).json({ error: 'Failed to delete character', details: err?.message });
    }
  });

  // 9. POST /api/character-love/owner/item
  app.post('/api/character-love/owner/item', requireAuth, requireOwner, async (req: Request, res: Response) => {
    try {
      const user = (req as any).authUser;
      const item = await ownerSaveItem(req.body, user?.username || 'Owner');

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'COMPANION',
        action: `Server Owner saved gift item: "${item.name}" (${item.id})`,
        path: '/characters',
        targetElement: `love_item_${item.id}`
      }, req);

      res.json({ success: true, item });
    } catch (err: any) {
      console.error('Error saving gift item:', err);
      res.status(500).json({ error: 'Failed to save gift item', details: err?.message });
    }
  });

  // 10. DELETE /api/character-love/owner/item/:id
  app.delete('/api/character-love/owner/item/:id', requireAuth, requireOwner, async (req: Request, res: Response) => {
    try {
      const id = String(req.params.id);
      await ownerDeleteItem(id);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'COMPANION',
        action: `Server Owner deleted gift item: ${id}`,
        path: '/characters',
        targetElement: `love_item_${id}`
      }, req);

      res.json({ success: true, itemId: id });
    } catch (err: any) {
      console.error('Error deleting gift item:', err);
      res.status(500).json({ error: 'Failed to delete gift item', details: err?.message });
    }
  });

  // 11. POST /api/character-love/owner/manual-adjust
  app.post('/api/character-love/owner/manual-adjust', requireAuth, requireOwner, async (req: Request, res: Response) => {
    try {
      const { discordId, characterId, level, lovePoints } = req.body;
      const targetUser = discordId || (req as any).authUser?.discordId || 'guest_user';

      if (!characterId) {
        return res.status(400).json({ error: 'characterId is required' });
      }

      const progress = await ownerManualAdjust(targetUser, characterId, { level, lovePoints });

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'COMPANION',
        action: `Server Owner manually adjusted ${characterId} for ${targetUser} (Level: ${progress.level}, Points: ${progress.lovePoints})`,
        path: '/characters',
        targetElement: `companion_${characterId}`
      }, req);

      res.json({ success: true, progress });
    } catch (err: any) {
      console.error('Error manually adjusting character:', err);
      res.status(500).json({ error: 'Failed to adjust character', details: err?.message });
    }
  });

  // 12. POST /api/character-love/owner/thresholds
  app.post('/api/character-love/owner/thresholds', requireAuth, requireOwner, async (req: Request, res: Response) => {
    try {
      const { thresholds } = req.body;
      if (!Array.isArray(thresholds) || thresholds.length === 0) {
        return res.status(400).json({ error: 'thresholds array is required' });
      }

      const updated = await ownerSaveThresholds(thresholds);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'COMPANION',
        action: `Server Owner updated Love Level thresholds (${updated.length} tiers)`,
        path: '/characters',
        targetElement: 'love_thresholds'
      }, req);

      res.json({ success: true, thresholds: updated });
    } catch (err: any) {
      console.error('Error saving thresholds:', err);
      res.status(500).json({ error: 'Failed to save thresholds', details: err?.message });
    }
  });

  // 13. POST /api/character-love/owner/special-rewards/config (Owner)
  app.post('/api/character-love/owner/special-rewards/config', requireAuth, requireOwner, async (req: Request, res: Response) => {
    try {
      const user = (req as any).authUser;
      const config = await ownerSaveSpecialRewardsConfig(req.body, user?.username || 'Owner');

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'COMPANION',
        action: `Server Owner updated 3-Day Special Rewards Pool (${config.rewards.length} eligible rewards, ${config.cycleHours}h cycle)`,
        path: '/characters',
        targetElement: 'special_rewards_config'
      }, req);

      res.json({ success: true, config });
    } catch (err: any) {
      console.error('Error saving special rewards config:', err);
      res.status(500).json({ error: 'Failed to save special rewards config', details: err?.message });
    }
  });

  // 14. POST /api/character-love/owner/special-rewards/reset-cooldown (Owner test helper)
  app.post('/api/character-love/owner/special-rewards/reset-cooldown', requireAuth, requireOwner, async (req: Request, res: Response) => {
    try {
      const user = (req as any).authUser;
      const targetUser = req.body.discordId || user?.discordId || 'guest_user';
      const characterId = String(req.body.characterId);

      const progress = await ownerResetSpecialRewardCooldown(targetUser, characterId);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'COMPANION',
        action: `Server Owner reset 3-day special reward cooldown for ${targetUser} on companion ${characterId}`,
        path: '/characters',
        targetElement: `companion_${characterId}`
      }, req);

      res.json({ success: true, progress });
    } catch (err: any) {
      console.error('Error resetting special reward cooldown:', err);
      res.status(500).json({ error: 'Failed to reset cooldown', details: err?.message });
    }
  });

  // 15. POST /api/character-love/owner/stage-coins (Owner updates stage coin amount)
  app.post('/api/character-love/owner/stage-coins', requireAuth, requireOwner, async (req: Request, res: Response) => {
    try {
      const { characterId, stageNumber, passiveCoins } = req.body;
      if (!characterId || typeof stageNumber !== 'number' || typeof passiveCoins !== 'number') {
        return res.status(400).json({ error: 'characterId, stageNumber, and passiveCoins are required' });
      }

      const character = await ownerUpdateStageCoins(characterId, stageNumber, passiveCoins);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'COMPANION',
        action: `Server Owner updated 12h passive coins for ${characterId} Stage ${stageNumber}: ${passiveCoins} coins`,
        path: '/characters',
        targetElement: `companion_stage_${stageNumber}`
      }, req);

      res.json({ success: true, character });
    } catch (err: any) {
      console.error('Error updating stage coins:', err);
      res.status(500).json({ error: 'Failed to update stage coins', details: err?.message });
    }
  });
}
