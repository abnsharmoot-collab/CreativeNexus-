import { 
  CombatActionType, 
  CombatRoundRequest, 
  CombatRoundResult, 
  CombatRulesConfig, 
  DEFAULT_COMBAT_RULES, 
  CombatSkillDefinition,
  COMBAT_PRESETS
} from '../src/types/combatRules';
import { getFirestoreInstance } from './discordStaffSync';
import { doc, getDoc, setDoc } from 'firebase/firestore';

// In-memory cache for live combat rules
let cachedCombatRules: CombatRulesConfig = { ...DEFAULT_COMBAT_RULES };

export async function getActiveCombatRules(): Promise<CombatRulesConfig> {
  try {
    const firestore = getFirestoreInstance();
    if (!firestore) return cachedCombatRules;

    const rulesDoc = await getDoc(doc(firestore, 'game_configs', 'combat_rules'));
    if (rulesDoc.exists()) {
      cachedCombatRules = rulesDoc.data() as CombatRulesConfig;
    }
  } catch (err) {
    console.warn('[CombatEngine] Falling back to default combat rules:', err);
  }
  return cachedCombatRules;
}

export async function saveCombatRules(rules: Partial<CombatRulesConfig>, updatedBy?: string): Promise<CombatRulesConfig> {
  const merged: CombatRulesConfig = {
    ...cachedCombatRules,
    ...rules,
    updatedAt: new Date().toISOString(),
    updatedBy: updatedBy || 'owner'
  };

  cachedCombatRules = merged;

  try {
    const firestore = getFirestoreInstance();
    if (firestore) {
      await setDoc(doc(firestore, 'game_configs', 'combat_rules'), merged);
    }
  } catch (err) {
    console.error('[CombatEngine] Error saving combat rules to Firestore:', err);
  }

  return merged;
}

export function selectOpponentCombatAction(
  playerState: CombatRoundRequest['playerState'],
  opponentState: CombatRoundRequest['opponentState'],
  skills: CombatSkillDefinition[]
): { action: CombatActionType; skillId?: string } {
  const isOpponentExhausted = opponentState.stamina <= 0;
  const oppStamina = opponentState.stamina;
  const oppHp = opponentState.hp;
  const playerStamina = playerState.stamina;
  const playerHp = playerState.hp;

  // Check if a skill is ready and has sufficient resources
  const readySkills = skills.filter(s => {
    const cd = opponentState.activeSkillCooldowns[s.id] || 0;
    return cd <= 0 && opponentState.energy >= s.energyCost && oppStamina >= s.staminaCost;
  });

  // Action scores
  let strikeScore = 45;
  let heavyScore = isOpponentExhausted || oppStamina < 25 ? -100 : 40;
  let defenseScore = 38;
  let skillScore = -50;
  let chosenSkillId: string | undefined = undefined;

  // Resource considerations
  if (oppStamina <= 20) {
    defenseScore += 45; // Must recover stamina
    strikeScore -= 20;
  } else if (oppStamina >= 60) {
    heavyScore += 25;
  }

  // Health considerations
  if (oppHp < 30) {
    defenseScore += 35;
    strikeScore += 10;
  }

  // Player state reactions
  if (playerState.isExhausted || playerStamina <= 15) {
    // Player cannot use Heavy, likely to defend or do weak strike
    heavyScore += 40; // Break defense / punish
    strikeScore += 15;
  }

  if (playerHp < 25) {
    // Finish off player
    heavyScore += 30;
    strikeScore += 25;
  }

  // Skill evaluation
  if (readySkills.length > 0) {
    const bestSkill = readySkills[0];
    chosenSkillId = bestSkill.id;
    skillScore = 55;
    if (bestSkill.type === 'defense' && oppHp < 50) skillScore += 30;
    if (bestSkill.type === 'buff' && oppStamina >= 50) skillScore += 25;
    if (bestSkill.type === 'attack') skillScore += 20;
  }

  // Pick action with highest score
  const candidateList: { action: CombatActionType; score: number; skillId?: string }[] = [
    { action: 'STRIKE', score: strikeScore },
    { action: 'HEAVY', score: heavyScore },
    { action: 'DEFENSE', score: defenseScore }
  ];

  if (chosenSkillId) {
    candidateList.push({ action: 'SKILL', score: skillScore, skillId: chosenSkillId });
  }

  candidateList.sort((a, b) => b.score - a.score);
  const best: { action: CombatActionType; score: number; skillId?: string } = candidateList[0] || { action: 'STRIKE', score: 0 };

  return { action: best.action, skillId: best.skillId };
}

export function resolveCombatRound(
  req: CombatRoundRequest,
  rules: CombatRulesConfig
): CombatRoundResult {
  const pAction = req.playerAction;
  const pSkill = pAction === 'SKILL' && req.playerSkillId
    ? rules.skills.find(s => s.id === req.playerSkillId)
    : undefined;

  // Server authoritative opponent action resolution
  const oppDecision = req.opponentAction 
    ? { action: req.opponentAction, skillId: req.opponentSkillId }
    : selectOpponentCombatAction(req.playerState, req.opponentState, rules.skills);

  const oAction = oppDecision.action;
  const oSkill = oAction === 'SKILL' && oppDecision.skillId
    ? rules.skills.find(s => s.id === oppDecision.skillId)
    : undefined;

  // 1. STAMINA & EXHAUSTION CALCULATION
  const pExhausted = req.playerState.stamina <= 0;
  const oExhausted = req.opponentState.stamina <= 0;

  // Action stamina costs
  let pStaminaCost = 0;
  let oStaminaCost = 0;

  if (pAction === 'STRIKE') pStaminaCost = rules.actions.STRIKE.staminaCost;
  else if (pAction === 'HEAVY') pStaminaCost = rules.actions.HEAVY.staminaCost;
  else if (pAction === 'DEFENSE') pStaminaCost = 0; // applied on block
  else if (pAction === 'SKILL' && pSkill) pStaminaCost = pSkill.staminaCost;

  if (oAction === 'STRIKE') oStaminaCost = rules.actions.STRIKE.staminaCost;
  else if (oAction === 'HEAVY') oStaminaCost = rules.actions.HEAVY.staminaCost;
  else if (oAction === 'DEFENSE') oStaminaCost = 0;
  else if (oAction === 'SKILL' && oSkill) oStaminaCost = oSkill.staminaCost;

  // 2. BASE DAMAGE & ENERGY CONFIG
  let pBaseDamage = 0;
  let oBaseDamage = 0;

  if (pAction === 'STRIKE') pBaseDamage = rules.actions.STRIKE.damage * (pExhausted ? (1 - rules.staminaConfig.exhaustionPenaltyStrikeReduction) : 1);
  else if (pAction === 'HEAVY') pBaseDamage = pExhausted ? 0 : rules.actions.HEAVY.damage;
  else if (pAction === 'DEFENSE') pBaseDamage = 0;
  else if (pAction === 'SKILL' && pSkill) pBaseDamage = pSkill.damage;

  if (oAction === 'STRIKE') oBaseDamage = rules.actions.STRIKE.damage * (oExhausted ? (1 - rules.staminaConfig.exhaustionPenaltyStrikeReduction) : 1);
  else if (oAction === 'HEAVY') oBaseDamage = oExhausted ? 0 : rules.actions.HEAVY.damage;
  else if (oAction === 'DEFENSE') oBaseDamage = 0;
  else if (oAction === 'SKILL' && oSkill) oBaseDamage = oSkill.damage;

  // Energy generation / consumption
  let pEnergyDelta = 0;
  let oEnergyDelta = 0;

  if (pAction === 'STRIKE') pEnergyDelta = rules.energyConfig.strikeGain;
  else if (pAction === 'HEAVY') pEnergyDelta = rules.energyConfig.heavyGain;
  else if (pAction === 'DEFENSE') pEnergyDelta = rules.energyConfig.defenseGain;
  else if (pAction === 'SKILL' && pSkill) pEnergyDelta = -pSkill.energyCost;

  if (oAction === 'STRIKE') oEnergyDelta = rules.energyConfig.strikeGain;
  else if (oAction === 'HEAVY') oEnergyDelta = rules.energyConfig.heavyGain;
  else if (oAction === 'DEFENSE') oEnergyDelta = rules.energyConfig.defenseGain;
  else if (oAction === 'SKILL' && oSkill) oEnergyDelta = -oSkill.energyCost;

  // 3. MATCHUP MATRIX LOOKUP
  const matrixKey = `${pAction}_vs_${oAction}` as keyof typeof rules.matchupMatrix;
  const matchupRule = rules.matchupMatrix[matrixKey] || {
    winner: 'TIE',
    result: 'CLASH',
    bannerText: 'CLASH',
    bannerTextAr: 'اشتباك',
    playerDamageMultiplier: 1.0,
    opponentDamageMultiplier: 1.0,
    playerStagger: false,
    opponentStagger: false,
    guardBreak: false,
    counterWindowGranted: 'NONE'
  };

  // Outcome calculation
  let playerDamageDealt = Math.round(pBaseDamage * matchupRule.playerDamageMultiplier);
  let opponentDamageDealt = Math.round(oBaseDamage * matchupRule.opponentDamageMultiplier);

  // Defense stamina recovery: always recovers +25 stamina, but 70% (+18) if opponent chooses Heavy
  const BASE_DEF_STAMINA = 25;
  if (pAction === 'DEFENSE') {
    const gain = oAction === 'HEAVY' ? Math.round(BASE_DEF_STAMINA * 0.70) : BASE_DEF_STAMINA;
    pStaminaCost = -gain;
  }
  if (oAction === 'DEFENSE') {
    const gain = pAction === 'HEAVY' ? Math.round(BASE_DEF_STAMINA * 0.70) : BASE_DEF_STAMINA;
    oStaminaCost = -gain;
  }

  // Handle Skill effects (Lifesteal, Healing, Shields)
  let playerHeal = 0;
  let opponentHeal = 0;
  if (pSkill?.effects.heal || pSkill?.effects.lifesteal) {
    playerHeal = pSkill.healing || 0;
  }
  if (oSkill?.effects.heal || oSkill?.effects.lifesteal) {
    opponentHeal = oSkill.healing || 0;
  }

  // Status Effects
  const statusEffectsPlayer: string[] = [];
  const statusEffectsOpponent: string[] = [];

  if (matchupRule.playerStagger) statusEffectsPlayer.push('staggered');
  if (matchupRule.opponentStagger) statusEffectsOpponent.push('staggered');
  if (matchupRule.guardBreak && (pAction === 'DEFENSE' || oAction === 'DEFENSE')) {
    if (pAction === 'DEFENSE') statusEffectsPlayer.push('guard_broken');
    if (oAction === 'DEFENSE') statusEffectsOpponent.push('guard_broken');
  }

  // State Updates
  const playerHpAfter = Math.min(req.playerState.maxHp, Math.max(0, req.playerState.hp - opponentDamageDealt + playerHeal));
  const opponentHpAfter = Math.min(req.opponentState.maxHp, Math.max(0, req.opponentState.hp - playerDamageDealt + opponentHeal));

  const playerStaminaAfter = Math.max(0, Math.min(req.playerState.maxStamina, req.playerState.stamina - pStaminaCost));
  const opponentStaminaAfter = Math.max(0, Math.min(req.opponentState.maxStamina, req.opponentState.stamina - oStaminaCost));

  const playerEnergyAfter = Math.max(0, Math.min(rules.energyConfig.maxEnergy, req.playerState.energy + pEnergyDelta));
  const opponentEnergyAfter = Math.max(0, Math.min(rules.energyConfig.maxEnergy, req.opponentState.energy + oEnergyDelta));

  const playerExhaustedAfter = playerStaminaAfter <= 0;
  const opponentExhaustedAfter = opponentStaminaAfter <= 0;

  // Cooldown progression
  const playerActiveCooldowns: Record<string, number> = {};
  Object.entries(req.playerState.activeSkillCooldowns || {}).forEach(([id, turns]) => {
    if (turns > 1) playerActiveCooldowns[id] = turns - 1;
  });
  if (pSkill) playerActiveCooldowns[pSkill.id] = pSkill.cooldown;

  const opponentActiveCooldowns: Record<string, number> = {};
  Object.entries(req.opponentState.activeSkillCooldowns || {}).forEach(([id, turns]) => {
    if (turns > 1) opponentActiveCooldowns[id] = turns - 1;
  });
  if (oSkill) opponentActiveCooldowns[oSkill.id] = oSkill.cooldown;

  // Counter window
  const counterWindowActive = matchupRule.counterWindowGranted === 'PLAYER';

  // Build Battle Log strings
  let battleLogText = '';
  let battleLogTextAr = '';

  if (pAction === 'STRIKE' && oAction === 'HEAVY') {
    battleLogText = `⚡ STRIKE INTERRUPTED HEAVY! You struck before the enemy finished charging (-${playerDamageDealt} HP).`;
    battleLogTextAr = `⚡ الهجوم السريع قطع الهجوم الثقيل! باغته قبل اكتمال ضربته (-${playerDamageDealt} نقطة صحة للخصم).`;
  } else if (pAction === 'HEAVY' && oAction === 'STRIKE') {
    battleLogText = `⚡ ENEMY STRIKE INTERRUPTED YOUR HEAVY! Your slow windup was broken (-${opponentDamageDealt} HP).`;
    battleLogTextAr = `⚡ هجوم الخصم السريع قطع هجومك الثقيل! تم إلغاء شحنتك (-${opponentDamageDealt} نقطة صحة لك).`;
  } else if (pAction === 'STRIKE' && oAction === 'DEFENSE') {
    battleLogText = `🛡️ BLOCKED! Enemy defense absorbed your strike (-${playerDamageDealt} HP). Opponent gained counter window!`;
    battleLogTextAr = `🛡️ تم الصد! امتص درع الخصم هجومك (-${playerDamageDealt} ضرر). كسب الخصم فرصة هجوم مضاد!`;
  } else if (pAction === 'DEFENSE' && oAction === 'STRIKE') {
    battleLogText = `🛡️ PERFECT BLOCK! You deflected the enemy strike (-${opponentDamageDealt} HP). COUNTER AVAILABLE!`;
    battleLogTextAr = `🛡️ صد مثالي! ارتد هجوم الخصم عن درعك (-${opponentDamageDealt} ضرر). هجومك المضاد جاهز الآن!`;
  } else if (pAction === 'HEAVY' && oAction === 'DEFENSE') {
    battleLogText = `💥 GUARD BREAK! Your heavy leg kick broke through the enemy guard (-${playerDamageDealt} HP)!`;
    battleLogTextAr = `💥 كسر الدرع! ركلتك الثقيلة بالقدم اخترقت حاجز الخصم مسددة (-${playerDamageDealt} ضرر)!`;
  } else if (pAction === 'DEFENSE' && oAction === 'HEAVY') {
    battleLogText = `💥 GUARD SHATTERED! Enemy heavy attack broke through your shield (-${opponentDamageDealt} HP).`;
    battleLogTextAr = `💥 تحطم الدرع! اخترق هجوم الخصم الثقيل دفاعك (-${opponentDamageDealt} ضرر).`;
  } else if (pAction === 'DEFENSE' && oAction === 'DEFENSE') {
    battleLogText = `🤝 STANDOFF! Both fighters held defensive stances, regaining stamina (+5 Stamina).`;
    battleLogTextAr = `🤝 ترقب متقابل! تمسك الطرفان بالدفاع مسترجعين قواهما (+5 طاقة تحمل).`;
  } else if (pAction === 'HEAVY' && oAction === 'HEAVY') {
    battleLogText = `⚔️ HEAVY CLASH! Both brutal attacks detonated simultaneously (-${opponentDamageDealt} HP / -${playerDamageDealt} HP)!`;
    battleLogTextAr = `⚔️ صراع هجمات ثقيلة! اصطدمت الضربتان العنيفتان معاً (-${opponentDamageDealt} ضرر لك / -${playerDamageDealt} للخصم)!`;
  } else {
    battleLogText = `⚔️ CLASH! Both fast strikes connected (-${playerDamageDealt} HP dealt, -${opponentDamageDealt} HP received).`;
    battleLogTextAr = `⚔️ اشتباك سريع! أصابت الضربتان في وقت واحد (-${playerDamageDealt} ضرر للخصم، -${opponentDamageDealt} ضرر لك).`;
  }

  // Animation and audio keys
  let animationKey = 'clash_trade';
  let soundKey = 'SWORD_CLASH';

  if (matchupRule.result === 'GUARD_BREAK') {
    animationKey = 'guard_break';
    soundKey = 'HEAVY_SLAM';
  } else if (matchupRule.result === 'BLOCKED') {
    animationKey = 'blocked_defend';
    soundKey = 'SHIELD_BLOCK';
  } else if (matchupRule.result === 'INTERRUPTED') {
    animationKey = 'strike_interrupt';
    soundKey = 'TACTICAL_SELECT';
  } else if (matchupRule.result === 'STANDOFF') {
    animationKey = 'defensive_standoff';
    soundKey = 'FORMATION_SUMMON';
  }

  return {
    playerAction: pAction,
    opponentAction: oAction,
    winner: matchupRule.winner.toLowerCase() as 'player' | 'opponent' | 'tie',
    result: matchupRule.result,
    bannerTitle: matchupRule.bannerText,
    bannerTitleAr: matchupRule.bannerTextAr,
    playerDamageTaken: opponentDamageDealt,
    opponentDamageTaken: playerDamageDealt,
    playerDamageDealt,
    opponentDamageDealt,
    playerStaminaDelta: -pStaminaCost,
    opponentStaminaDelta: -oStaminaCost,
    playerEnergyDelta: pEnergyDelta,
    opponentEnergyDelta: oEnergyDelta,
    playerHpAfter,
    opponentHpAfter,
    playerStaminaAfter,
    opponentStaminaAfter,
    playerEnergyAfter,
    opponentEnergyAfter,
    playerExhaustedAfter,
    opponentExhaustedAfter,
    counterWindowActive,
    isPlayerStaggered: matchupRule.playerStagger,
    isOpponentStaggered: matchupRule.opponentStagger,
    isPlayerGuardBroken: matchupRule.guardBreak && pAction === 'DEFENSE',
    isOpponentGuardBroken: matchupRule.guardBreak && oAction === 'DEFENSE',
    statusEffectsPlayer,
    statusEffectsOpponent,
    playerActiveCooldowns,
    opponentActiveCooldowns,
    battleLogText,
    battleLogTextAr,
    animationKey,
    soundKey
  };
}
