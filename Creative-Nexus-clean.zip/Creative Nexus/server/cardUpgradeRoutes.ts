import { Router } from 'express';
import { requireAuth, requireOwner } from './discordRbac';
import {
  getCardUpgradeConfig,
  saveCardUpgradeConfig,
  performCardUpgrade
} from './cardUpgradeService';

export function createCardUpgradeRoutes(): Router {
  const router = Router();

  // 1. GET /api/cards/upgrade-config - Get current upgrade transitions & probabilities
  router.get('/upgrade-config', async (_req, res) => {
    try {
      const config = await getCardUpgradeConfig();
      res.json({
        success: true,
        config
      });
    } catch (err: any) {
      console.error('Error fetching card upgrade config:', err);
      res.status(500).json({ error: err.message || 'Failed to fetch upgrade config' });
    }
  });

  // 2. POST /api/cards/owner/upgrade-config - Save upgrade settings (Owner only)
  router.post('/owner/upgrade-config', requireAuth, requireOwner, async (req, res) => {
    try {
      const user = req.authUser!;
      const config = req.body;

      if (!config) {
        return res.status(400).json({ error: 'Config body is required' });
      }

      const saved = await saveCardUpgradeConfig(config, user.username || user.discordId);
      res.json({
        success: true,
        config: saved,
        message: 'Card upgrade configuration updated successfully.'
      });
    } catch (err: any) {
      console.error('Error saving card upgrade config:', err);
      res.status(500).json({ error: err.message || 'Failed to save upgrade config' });
    }
  });

  // 3. POST /api/cards/upgrade - Attempt card rarity & stat upgrade (Auth required)
  router.post('/upgrade', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const { cardId, preferredShardItemId } = req.body;

      if (!cardId) {
        return res.status(400).json({ error: 'cardId is required' });
      }

      const result = await performCardUpgrade(user.discordId, cardId, preferredShardItemId);
      res.json(result);
    } catch (err: any) {
      console.error('Error performing card upgrade:', err);
      res.status(400).json({ error: err.message || 'Card upgrade attempt failed' });
    }
  });

  return router;
}

export function setupCardUpgradeRoutes(app: any) {
  const router = createCardUpgradeRoutes();
  app.use('/api/cards', router);
}
