import express from 'express';
import { requireAuth, requireOwner, requirePermission } from './discordRbac';
import { 
  getActiveCombatRules, 
  saveCombatRules, 
  resolveCombatRound 
} from './combatEngine';
import { COMBAT_PRESETS, CombatSkillDefinition, DEFAULT_COMBAT_RULES } from '../src/types/combatRules';
import { recordAuditEvent } from './auditService';

export function setupCombatRoutes(app: express.Express) {
  const router = express.Router();

  // 1. GET /api/combat/rules - Get active combat rules (Public / Auth)
  router.get('/rules', async (req, res) => {
    try {
      const rules = await getActiveCombatRules();
      res.json({ success: true, rules });
    } catch (err: any) {
      console.error('Error fetching combat rules:', err);
      res.status(500).json({ error: 'Failed to load combat rules' });
    }
  });

  // 2. POST /api/combat/resolve-round - Server-authoritative combat resolution!
  router.post('/resolve-round', async (req, res) => {
    try {
      const roundRequest = req.body;
      if (!roundRequest.playerAction) {
        return res.status(400).json({ error: 'playerAction is required (STRIKE|HEAVY|DEFENSE|SKILL)' });
      }

      const activeRules = await getActiveCombatRules();
      const result = resolveCombatRound(roundRequest, activeRules);

      res.json({ success: true, result });
    } catch (err: any) {
      console.error('Error in server combat resolution:', err);
      res.status(500).json({ error: err.message || 'Combat calculation error' });
    }
  });

  // 3. POST /api/combat/rules - Save modified rules (Owner & Admin only)
  router.post('/rules', requirePermission('MANAGE_SERVER_SETTINGS'), async (req, res) => {
    try {
      const updatedRules = req.body;
      const saved = await saveCombatRules(updatedRules, req.authUser?.discordId || 'owner');

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'ADMIN',
        action: `Updated Battle Arena combat rules (Preset: ${saved.presetName})`,
        path: '/api/combat/rules',
        userId: req.authUser?.discordId
      }, req);

      res.json({ success: true, rules: saved });
    } catch (err: any) {
      console.error('Error updating combat rules:', err);
      res.status(500).json({ error: err.message || 'Failed to update combat rules' });
    }
  });

  // 4. POST /api/combat/preset - Switch active preset (Owner & Admin only)
  router.post('/preset', requirePermission('MANAGE_SERVER_SETTINGS'), async (req, res) => {
    try {
      const { presetName } = req.body;
      const targetPreset = COMBAT_PRESETS[presetName];

      if (!targetPreset) {
        return res.status(400).json({ error: `Invalid preset: ${presetName}` });
      }

      const current = await getActiveCombatRules();
      const updated = await saveCombatRules({
        ...current,
        presetName: presetName as any,
        actions: {
          ...current.actions,
          ...(targetPreset.actions || {})
        }
      }, req.authUser?.discordId || 'owner');

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'ADMIN',
        action: `Switched Battle Arena Combat preset to "${presetName}"`,
        path: '/api/combat/preset',
        userId: req.authUser?.discordId
      }, req);

      res.json({ success: true, rules: updated });
    } catch (err: any) {
      console.error('Error setting combat preset:', err);
      res.status(500).json({ error: err.message || 'Failed to set preset' });
    }
  });

  // 5. POST /api/combat/skills - Add or update a combat skill (Owner only)
  router.post('/skills', requireOwner, async (req, res) => {
    try {
      const skill: CombatSkillDefinition = req.body;
      if (!skill.id || !skill.name) {
        return res.status(400).json({ error: 'Skill id and name are required' });
      }

      const current = await getActiveCombatRules();
      const filtered = current.skills.filter(s => s.id !== skill.id);
      filtered.push(skill);

      const updated = await saveCombatRules({
        ...current,
        skills: filtered
      }, req.authUser?.discordId || 'owner');

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'ADMIN',
        action: `Owner saved custom combat skill "${skill.name}" (ID: ${skill.id})`,
        path: '/api/combat/skills',
        userId: req.authUser?.discordId
      }, req);

      res.json({ success: true, skills: updated.skills });
    } catch (err: any) {
      console.error('Error saving combat skill:', err);
      res.status(500).json({ error: err.message || 'Failed to save combat skill' });
    }
  });

  // 6. DELETE /api/combat/skills/:id - Delete a combat skill (Owner only)
  router.delete('/skills/:id', requireOwner, async (req, res) => {
    try {
      const skillId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
      if (!skillId) {
        return res.status(400).json({ error: 'Skill ID is required' });
      }

      const current = await getActiveCombatRules();
      const filtered = current.skills.filter(s => s.id !== skillId);

      const updated = await saveCombatRules({
        ...current,
        skills: filtered
      }, req.authUser?.discordId || 'owner');

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'ADMIN',
        action: `Owner deleted combat skill "${skillId}"`,
        path: `/api/combat/skills/${skillId}`,
        userId: req.authUser?.discordId
      }, req);

      res.json({ success: true, skills: updated.skills });
    } catch (err: any) {
      console.error('Error deleting combat skill:', err);
      res.status(500).json({ error: err.message || 'Failed to delete combat skill' });
    }
  });

  // 7. POST /api/combat/reset-defaults - Reset to default rules (Owner only)
  router.post('/reset-defaults', requireOwner, async (req, res) => {
    try {
      const reset = await saveCombatRules(DEFAULT_COMBAT_RULES, req.authUser?.discordId || 'owner');
      res.json({ success: true, rules: reset });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Failed to reset rules' });
    }
  });

  app.use('/api/combat', router);
}
