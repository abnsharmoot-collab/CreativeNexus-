import express from 'express';
import { requireAuth } from './discordRbac';
import {
  getUserDecks,
  saveUserDeck,
  deleteUserDeck,
  setActiveDeck,
  getActiveDeckWithCards
} from './deckService';
import { recordAuditEvent } from './auditService';

export function setupDeckRoutes(app: express.Express) {
  const router = express.Router();

  // 1. GET /api/decks (Auth required) - List all decks of the user
  router.get('/', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const decks = await getUserDecks(user.discordId, {
        username: user.username,
        displayName: user.displayName,
        avatarUrl: user.avatarUrl
      });
      res.json({ success: true, decks });
    } catch (err: any) {
      console.error('Error fetching user decks:', err);
      res.status(500).json({ error: 'Failed to load decks' });
    }
  });

  // 2. GET /api/decks/active (Auth required) - Get user active deck with full card data
  router.get('/active', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const result = await getActiveDeckWithCards(user.discordId);
      if (!result) {
        return res.status(404).json({ error: 'No active deck found' });
      }
      res.json({ success: true, deck: result.deck, cards: result.cards });
    } catch (err: any) {
      console.error('Error fetching active deck:', err);
      res.status(500).json({ error: 'Failed to load active deck' });
    }
  });

  // 3. POST /api/decks (Auth required) - Create or save a deck (validated server-side)
  router.post('/', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const { id, name, banner, cardIds, itemIds, isActive } = req.body;

      const result = await saveUserDeck(user.discordId, {
        id,
        name,
        banner,
        cardIds,
        itemIds,
        isActive
      });

      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }

      await recordAuditEvent({
        eventType: 'INTERACTION',
        category: 'CARD_VAULT',
        action: `User saved deck "${result.deck?.name}" with ${result.deck?.cardIds.length} cards (Power: ${result.deck?.power})`,
        path: '/api/decks',
        targetElement: 'deck_builder'
      }, req);

      res.json({ success: true, deck: result.deck });
    } catch (err: any) {
      console.error('Error saving deck:', err);
      res.status(500).json({ error: err.message || 'Failed to save deck' });
    }
  });

  // 4. POST /api/decks/:id/set-active (Auth required) - Set active deck
  router.post('/:id/set-active', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const deckId = String(req.params.id);

      const result = await setActiveDeck(user.discordId, deckId);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }

      res.json({ success: true, activeDeck: result.activeDeck });
    } catch (err: any) {
      console.error('Error setting active deck:', err);
      res.status(500).json({ error: err.message || 'Failed to set active deck' });
    }
  });

  // 5. DELETE /api/decks/:id (Auth required) - Delete a deck
  router.delete('/:id', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const deckId = String(req.params.id);

      const result = await deleteUserDeck(user.discordId, deckId);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }

      res.json({ success: true, message: 'Deck deleted successfully' });
    } catch (err: any) {
      console.error('Error deleting deck:', err);
      res.status(500).json({ error: err.message || 'Failed to delete deck' });
    }
  });

  app.use('/api/decks', router);
}
