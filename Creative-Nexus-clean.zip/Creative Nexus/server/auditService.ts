import express from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  query, 
  orderBy, 
  limit, 
  where 
} from 'firebase/firestore';
import { AuditLogEntry, AuditLogStats, AuditLogFilterOptions } from '../src/types/auditLog';

// In-memory ring buffer of most recent events for instant low-latency serving
const MAX_BUFFER_SIZE = 2500;
const memoryAuditBuffer: AuditLogEntry[] = [];
let firestoreInitialized = false;

function getFirestoreInstance() {
  try {
    const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
    if (!fs.existsSync(configPath)) {
      return null;
    }
    const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    const firebaseApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
    return getFirestore(firebaseApp, firebaseConfig.firestoreDatabaseId);
  } catch (err) {
    console.warn('AuditService: Firestore init warning:', err);
    return null;
  }
}

/**
 * Load historic logs from Firestore into memory on first access
 */
async function preloadRecentAuditLogs(): Promise<void> {
  if (firestoreInitialized) return;
  firestoreInitialized = true;
  try {
    const db = getFirestoreInstance();
    if (!db) return;

    const q = query(
      collection(db, 'audit_logs'),
      orderBy('timestampMs', 'desc'),
      limit(500)
    );
    const snap = await getDocs(q);
    
    // Add to buffer if not already present
    const existingIds = new Set(memoryAuditBuffer.map(item => item.id));
    for (const docSnap of snap.docs) {
      const data = docSnap.data() as AuditLogEntry;
      if (data && data.id && !existingIds.has(data.id)) {
        memoryAuditBuffer.push(data);
        existingIds.add(data.id);
      }
    }
    // Re-sort descending
    memoryAuditBuffer.sort((a, b) => b.timestampMs - a.timestampMs);
  } catch (err) {
    console.warn('AuditService: Note on preload audit logs:', err);
  }
}

/**
 * Extract client IP from Express request safely
 */
export function extractClientIp(req?: express.Request): string {
  if (!req) return '127.0.0.1';
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded) {
    const ips = Array.isArray(forwarded) ? forwarded[0] : forwarded.split(',')[0];
    return ips.trim();
  }
  return req.socket?.remoteAddress || req.ip || 'Unknown IP';
}

/**
 * Recursively remove undefined values from an object before saving to Firestore.
 * Firestore setDoc/updateDoc strictly rejects undefined field values.
 */
function sanitizeForFirestore(val: any): any {
  if (val === undefined) return undefined;
  if (val === null) return null;
  if (Array.isArray(val)) {
    return val.map(sanitizeForFirestore).filter(v => v !== undefined);
  }
  if (typeof val === 'object' && !(val instanceof Date)) {
    const clean: Record<string, any> = {};
    for (const [k, v] of Object.entries(val)) {
      const sanitized = sanitizeForFirestore(v);
      if (sanitized !== undefined) {
        clean[k] = sanitized;
      }
    }
    return clean;
  }
  return val;
}

/**
 * Log an audit event (Login, Click, Navigation, Admin action, etc.)
 */
export async function recordAuditEvent(
  entry: Partial<AuditLogEntry>,
  req?: express.Request
): Promise<AuditLogEntry> {
  const now = new Date();
  const timestamp = now.toISOString();
  const timestampMs = now.getTime();
  const id = `audit_${timestampMs}_${crypto.randomBytes(4).toString('hex')}`;

  // Derive user identity
  let userId = entry.userId;
  let username = entry.username;
  let displayName = entry.displayName;
  let avatarUrl = entry.avatarUrl;
  let role: AuditLogEntry['role'] = entry.role || 'GUEST';
  let isGuest = entry.isGuest ?? true;

  if (req?.authUser) {
    const u = req.authUser;
    userId = u.discordId || String(u.id);
    username = u.username || 'Discord User';
    displayName = u.displayName || u.username || 'Discord User';
    avatarUrl = u.avatarUrl || avatarUrl;
    role = (u.role as AuditLogEntry['role']) || 'MEMBER';
    isGuest = false;
  } else if (!userId) {
    // Guest identification
    const guestCookie = req?.cookies?.cn_visitor_id;
    const bodyVisitorId = req?.body?.visitorId;
    const visitorId = bodyVisitorId || guestCookie || crypto.randomBytes(4).toString('hex');
    userId = `guest_${visitorId.slice(0, 12)}`;
    username = username || `Guest (${visitorId.slice(0, 6)})`;
    displayName = displayName || `Guest Visitor`;
    role = 'GUEST';
    isGuest = true;
  }

  const cleanEntry: AuditLogEntry = {
    id,
    timestamp,
    timestampMs,
    eventType: entry.eventType || 'INTERACTION',
    action: String(entry.action || 'Unknown interaction').slice(0, 500),
    category: entry.category || 'GENERAL',
    details: entry.details,
    userId: String(userId).slice(0, 128),
    username: String(username || 'Anonymous').slice(0, 128),
    displayName: String(displayName || username || 'Anonymous').slice(0, 128),
    avatarUrl: avatarUrl ? String(avatarUrl).slice(0, 1024) : undefined,
    role,
    isGuest,
    path: String(entry.path || (req ? req.path : '/')).slice(0, 256),
    targetElement: entry.targetElement ? String(entry.targetElement).slice(0, 256) : undefined,
    ip: entry.ip || extractClientIp(req),
    userAgent: entry.userAgent || (req ? (req.headers['user-agent'] as string) : undefined)
  };

  // 1. Prepend to in-memory buffer
  memoryAuditBuffer.unshift(cleanEntry);
  if (memoryAuditBuffer.length > MAX_BUFFER_SIZE) {
    memoryAuditBuffer.length = MAX_BUFFER_SIZE;
  }

  // 2. Persist to Firestore asynchronously without blocking
  try {
    const db = getFirestoreInstance();
    if (db) {
      const firestorePayload = sanitizeForFirestore(cleanEntry);
      // Fire-and-forget save to Firestore collection 'audit_logs'
      setDoc(doc(db, 'audit_logs', cleanEntry.id), firestorePayload).catch(err => {
        console.warn('AuditService: Firestore background log error:', err?.message);
      });
    }
  } catch (err: any) {
    console.warn('AuditService: Error writing audit log:', err?.message);
  }

  return cleanEntry;
}

/**
 * Retrieve audit logs with filtering and compute real-time statistics
 */
export async function getAuditLogs(
  options: AuditLogFilterOptions = {}
): Promise<{ logs: AuditLogEntry[]; stats: AuditLogStats }> {
  // Ensure preload has run
  await preloadRecentAuditLogs();

  let filtered = [...memoryAuditBuffer];

  // Event type filter
  if (options.eventType && options.eventType !== 'ALL') {
    filtered = filtered.filter(log => log.eventType === options.eventType);
  }

  // Category filter
  if (options.category && options.category !== 'ALL') {
    filtered = filtered.filter(log => log.category === options.category);
  }

  // User type filter (all, authenticated, guests)
  if (options.userType === 'authenticated') {
    filtered = filtered.filter(log => !log.isGuest);
  } else if (options.userType === 'guests') {
    filtered = filtered.filter(log => log.isGuest);
  }

  // Search query filter (searches username, displayName, action, path, targetElement, or userId)
  if (options.searchQuery && options.searchQuery.trim()) {
    const q = options.searchQuery.toLowerCase().trim();
    filtered = filtered.filter(log => 
      log.username.toLowerCase().includes(q) ||
      log.displayName.toLowerCase().includes(q) ||
      log.action.toLowerCase().includes(q) ||
      log.userId.toLowerCase().includes(q) ||
      (log.path && log.path.toLowerCase().includes(q)) ||
      (log.targetElement && log.targetElement.toLowerCase().includes(q))
    );
  }

  // Compute stats across full in-memory buffer
  const uniqueUsersSet = new Set<string>();
  const uniqueGuestsSet = new Set<string>();
  let totalLogins = 0;
  let totalPageViews = 0;
  let totalInteractions = 0;
  let totalAdminActions = 0;

  for (const log of memoryAuditBuffer) {
    if (log.isGuest) {
      uniqueGuestsSet.add(log.userId);
    } else {
      uniqueUsersSet.add(log.userId);
    }

    if (log.eventType === 'AUTH_LOGIN') totalLogins++;
    else if (log.eventType === 'PAGE_VIEW') totalPageViews++;
    else if (log.eventType === 'ADMIN_ACTION') totalAdminActions++;
    else totalInteractions++;
  }

  const limitCount = options.limit ? Math.min(options.limit, 1000) : 250;
  const slicedLogs = filtered.slice(0, limitCount);

  const stats: AuditLogStats = {
    totalEvents: memoryAuditBuffer.length,
    totalLogins,
    totalPageViews,
    totalInteractions,
    totalAdminActions,
    uniqueUsers: uniqueUsersSet.size,
    uniqueGuests: uniqueGuestsSet.size,
    lastActiveTime: memoryAuditBuffer.length > 0 ? memoryAuditBuffer[0].timestamp : undefined
  };

  return {
    logs: slicedLogs,
    stats
  };
}

/**
 * Clear audit logs (Strictly for Owner maintenance)
 */
export async function clearAuditLogs(): Promise<{ success: boolean; clearedCount: number }> {
  const count = memoryAuditBuffer.length;
  memoryAuditBuffer.length = 0;
  return { success: true, clearedCount: count };
}
