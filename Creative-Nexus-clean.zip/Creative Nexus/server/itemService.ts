import fs from 'fs';
import path from 'path';
import { doc, getDoc, setDoc, deleteDoc, collection, getDocs } from 'firebase/firestore';
import { getFirestoreInstance } from './discordStaffSync';
import {
  UnifiedItemDefinition,
  UserItemOwnership,
  DuplicateCardRewardConfig,
  DuplicateRewardAwarded,
  DEFAULT_DUPLICATE_REWARD_CONFIG
} from '../src/types/items';
import { DEFAULT_UNIFIED_ITEMS } from '../src/data/defaultItems';
import { CardRarity } from '../src/types/cards';

const STORAGE_FILE = path.join(process.cwd(), 'server', 'items-state.json');

const deletedItemIds = new Set<string>();
let isAllDeletedState = false;

// In-memory catalog of unified game items
let itemsCatalog: UnifiedItemDefinition[] = [];
let hasLoadedItems = false;

// In-memory duplicate config cache
let duplicateConfigCache: DuplicateCardRewardConfig = { ...DEFAULT_DUPLICATE_REWARD_CONFIG };
let hasLoadedDuplicateConfig = false;

// In-memory user inventory cache: discordId -> Record<itemId, UserItemOwnership>
const userInventoriesCache = new Map<string, Record<string, UserItemOwnership>>();

// All default item IDs to ensure they never resurrect if deleted
const ALL_DEFAULT_ITEM_IDS = [
  ...DEFAULT_UNIFIED_ITEMS.map(i => i.id),
  'item_date_honey',
  'item_celestial_rose',
  'item_lapis_pendant',
  'item_temporal_hourglass',
  'item_sovereign_ring',
  'item_nano_repair_patch',
  'item_hyperion_energy_flask',
  'item_aegis_kinetic_shield',
  'item_overdrive_combat_stim',
  'item_celestial_ambrosia',
  'item_shard_common',
  'item_shard_uncommon',
  'item_shard_rare',
  'item_shard_epic',
  'item_shard_legendary',
  'item_shard_universal'
];

/**
 * Save in-memory items and deletion blacklist to local disk file
 */
function saveStateToDisk() {
  try {
    const dir = path.dirname(STORAGE_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const payload = {
      isAllDeleted: isAllDeletedState,
      deletedItemIds: Array.from(deletedItemIds),
      items: itemsCatalog,
      updatedAt: new Date().toISOString()
    };
    fs.writeFileSync(STORAGE_FILE, JSON.stringify(payload, null, 2), 'utf-8');
  } catch (err: any) {
    console.warn('ItemService: Notice saving state to disk:', err?.message);
  }
}

/**
 * Load items state from local disk file if exists
 */
function loadStateFromDisk(): boolean {
  try {
    if (fs.existsSync(STORAGE_FILE)) {
      const content = fs.readFileSync(STORAGE_FILE, 'utf-8');
      const parsed = JSON.parse(content);
      if (parsed) {
        if (parsed.isAllDeleted === true) {
          isAllDeletedState = true;
        }
        if (Array.isArray(parsed.deletedItemIds)) {
          parsed.deletedItemIds.forEach((id: string) => deletedItemIds.add(String(id).trim()));
        }
        if (Array.isArray(parsed.items)) {
          itemsCatalog = parsed.items.filter((i: UnifiedItemDefinition) => !deletedItemIds.has(i.id));
        }
        return true;
      }
    }
  } catch (err: any) {
    console.warn('ItemService: Notice reading state from disk:', err?.message);
  }
  return false;
}

/**
 * Get all unified items (Battle consumables, Companion gifts, Upgrade materials, Special)
 */
export async function getAllUnifiedItems(forceRefresh = false): Promise<UnifiedItemDefinition[]> {
  // Always load latest disk state first
  loadStateFromDisk();

  // If owner wiped all items, strictly return empty catalog immediately!
  if (isAllDeletedState) {
    itemsCatalog = [];
    hasLoadedItems = true;
    return [];
  }

  if (hasLoadedItems && !forceRefresh) {
    return itemsCatalog.filter(i => !deletedItemIds.has(i.id));
  }

  try {
    const db = getFirestoreInstance();
    if (db) {
      // 0. Load deleted items blacklist
      try {
        const deletedSnap = await getDoc(doc(db, 'system_meta', 'deleted_items'));
        if (deletedSnap.exists()) {
          const data = deletedSnap.data();
          if (data?.isAllDeleted === true) {
            isAllDeletedState = true;
            itemsCatalog = [];
            hasLoadedItems = true;
            saveStateToDisk();
            return [];
          }
          const ids = data?.ids;
          if (Array.isArray(ids)) {
            ids.forEach(id => deletedItemIds.add(String(id).trim()));
          }
        }
      } catch {}

      if (isAllDeletedState) {
        itemsCatalog = [];
        hasLoadedItems = true;
        saveStateToDisk();
        return [];
      }

      // 1. Try 'game_items' collection
      const snap = await getDocs(collection(db, 'game_items'));
      const customMap = new Map<string, UnifiedItemDefinition>();

      if (!snap.empty) {
        snap.docs.forEach(d => {
          if (deletedItemIds.has(d.id)) return;
          const data = d.data() as UnifiedItemDefinition;
          if (data.isActive !== false) {
            customMap.set(d.id, {
              ...data,
              id: d.id,
              category: data.category || 'COMPANION',
              isActive: true
            });
          }
        });
      } else {
        // Fallback: check legacy 'character_love_items' collection for backward compatibility
        const legacySnap = await getDocs(collection(db, 'character_love_items'));
        if (!legacySnap.empty) {
          legacySnap.docs.forEach(d => {
            if (deletedItemIds.has(d.id)) return;
            const data = d.data() as any;
            if (data.isActive !== false) {
              customMap.set(d.id, {
                ...data,
                id: d.id,
                category: data.category || 'COMPANION',
                isActive: true
              });
            }
          });
        }
      }

      // If user wiped all items, do NOT re-seed defaults!
      if (isAllDeletedState || (customMap.size === 0 && deletedItemIds.size > 0)) {
        itemsCatalog = [];
        hasLoadedItems = true;
        saveStateToDisk();
        return [];
      }

      // Merge defaults with custom items (skipping any deleted items)
      const merged: UnifiedItemDefinition[] = [];
      if (!isAllDeletedState && deletedItemIds.size === 0) {
        for (const def of DEFAULT_UNIFIED_ITEMS) {
          if (deletedItemIds.has(def.id)) continue;
          if (customMap.has(def.id)) {
            merged.push(customMap.get(def.id)!);
            customMap.delete(def.id);
          } else {
            merged.push(def);
          }
        }
      }

      for (const remaining of customMap.values()) {
        if (!deletedItemIds.has(remaining.id)) {
          merged.push(remaining);
        }
      }

      itemsCatalog = merged;
      hasLoadedItems = true;
      saveStateToDisk();
      return itemsCatalog;
    }
  } catch (err: any) {
    console.warn('ItemService: Warning loading items from Firestore:', err?.message);
  }

  // Fallback if Firestore not reachable
  if (isAllDeletedState) {
    itemsCatalog = [];
  } else if (deletedItemIds.size === 0 && itemsCatalog.length === 0) {
    itemsCatalog = DEFAULT_UNIFIED_ITEMS.filter(i => !deletedItemIds.has(i.id));
  } else {
    itemsCatalog = itemsCatalog.filter(i => !deletedItemIds.has(i.id));
  }

  hasLoadedItems = true;
  saveStateToDisk();
  return itemsCatalog;
}

/**
 * Get an item definition by ID
 */
export async function getUnifiedItemById(itemId: string): Promise<UnifiedItemDefinition | null> {
  const cleanId = String(itemId).trim();
  if (deletedItemIds.has(cleanId)) return null;
  const all = await getAllUnifiedItems();
  return all.find(i => i.id === cleanId && !deletedItemIds.has(i.id)) || null;
}

/**
 * Save / Create / Update a unified item (Owner only)
 */
export async function saveUnifiedItem(itemData: Partial<UnifiedItemDefinition>, ownerDiscordId: string): Promise<UnifiedItemDefinition> {
  const now = new Date().toISOString();
  const id = itemData.id?.trim() || `item_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  
  if (deletedItemIds.has(id)) {
    deletedItemIds.delete(id);
  }

  // Normalize packages array to ensure exact uppercase matches for pack rolls
  const rawPackages = Array.isArray(itemData.packages) && itemData.packages.length > 0
    ? itemData.packages
    : ['COMMON', 'UNCOMMON', 'RARE', 'EPIC', 'LEGENDARY'];
  const packages = rawPackages.map(p => String(p).trim().toUpperCase()) as CardRarity[];

  const item: UnifiedItemDefinition = {
    id,
    name: itemData.name?.trim() || 'Unnamed Item',
    nameAr: itemData.nameAr?.trim() || itemData.name?.trim() || 'عنصر جديد',
    description: itemData.description?.trim() || '',
    descriptionAr: itemData.descriptionAr?.trim() || itemData.description?.trim() || '',
    imageUrl: itemData.imageUrl?.trim() || 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=400&q=80',
    rarity: itemData.rarity || 'COMMON',
    category: itemData.category || 'UPGRADE_MATERIAL',
    maxStack: itemData.maxStack || 99,
    targetCharacterId: itemData.targetCharacterId || 'ANY',
    lovePoints: typeof itemData.lovePoints === 'number' ? Math.max(1, itemData.lovePoints) : 30,
    battleEffect: itemData.battleEffect || (itemData.category === 'BATTLE' ? {
      type: 'HEAL_HP',
      value: 35,
      durationTurns: 0,
      consumesTurn: false,
      maxUsesPerBattle: 2
    } : undefined),
    packages,
    dropWeight: typeof itemData.dropWeight === 'number' && itemData.dropWeight > 0 ? itemData.dropWeight : 40,
    isActive: itemData.isActive !== false,
    isCustom: true,
    createdBy: ownerDiscordId,
    createdAt: itemData.createdAt || now,
    updatedAt: now
  };

  // Update in-memory catalog
  isAllDeletedState = false;
  const existingIndex = itemsCatalog.findIndex(i => i.id === id);
  if (existingIndex >= 0) {
    itemsCatalog[existingIndex] = item;
  } else {
    itemsCatalog.push(item);
  }
  hasLoadedItems = true;
  saveStateToDisk();

  // Persist to Firestore
  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'game_items', id), item, { merge: true });
      // Keep legacy collection in sync if companion gift
      if (item.category === 'COMPANION') {
        await setDoc(doc(db, 'character_love_items', id), item, { merge: true });
      }
      // Also unblock from deleted_items registry in Firestore
      await setDoc(doc(db, 'system_meta', 'deleted_items'), {
        isAllDeleted: false,
        ids: Array.from(deletedItemIds),
        updatedAt: now
      }, { merge: true });
    }
  } catch (err: any) {
    console.error('ItemService: Error saving item to Firestore:', err);
  }

  return item;
}

/**
 * Delete a unified item (Owner only)
 */
export async function deleteUnifiedItem(itemId: string): Promise<boolean> {
  const cleanId = String(itemId).trim();
  if (!cleanId) return true;

  deletedItemIds.add(cleanId);
  itemsCatalog = itemsCatalog.filter(i => i.id !== cleanId);
  saveStateToDisk();

  try {
    const db = getFirestoreInstance();
    if (db) {
      try {
        await deleteDoc(doc(db, 'game_items', cleanId));
      } catch (err: any) {
        console.warn('ItemService: Notice deleting game_items doc:', err?.message);
      }
      try {
        await deleteDoc(doc(db, 'character_love_items', cleanId));
      } catch (err: any) {
        console.warn('ItemService: Notice deleting character_love_items doc:', err?.message);
      }
      try {
        await setDoc(doc(db, 'system_meta', 'deleted_items'), {
          ids: Array.from(deletedItemIds),
          updatedAt: new Date().toISOString()
        }, { merge: true });
      } catch (err: any) {
        console.warn('ItemService: Notice updating deleted_items registry:', err?.message);
      }
    }
  } catch (err: any) {
    console.warn('ItemService: Error during deleteUnifiedItem Firestore sync:', err?.message);
  }
  return true;
}

/**
 * Delete all unified items (Owner only) - ensures 100% eradication so no items drop in packages
 */
export async function deleteAllUnifiedItems(): Promise<number> {
  const allCurrent = await getAllUnifiedItems(true);
  const count = allCurrent.length;
  
  // Mark all deleted state
  isAllDeletedState = true;

  // Add all current and default items to deleted blacklist
  allCurrent.forEach(item => {
    deletedItemIds.add(item.id);
  });
  ALL_DEFAULT_ITEM_IDS.forEach(id => {
    deletedItemIds.add(id);
  });

  itemsCatalog = [];
  hasLoadedItems = true;
  saveStateToDisk();

  try {
    const db = getFirestoreInstance();
    if (db) {
      for (const item of allCurrent) {
        try {
          await deleteDoc(doc(db, 'game_items', item.id));
        } catch {}
        try {
          await deleteDoc(doc(db, 'character_love_items', item.id));
        } catch {}
      }
      for (const defId of ALL_DEFAULT_ITEM_IDS) {
        try {
          await deleteDoc(doc(db, 'game_items', defId));
        } catch {}
        try {
          await deleteDoc(doc(db, 'character_love_items', defId));
        } catch {}
      }
      try {
        await setDoc(doc(db, 'system_meta', 'deleted_items'), {
          isAllDeleted: true,
          ids: Array.from(deletedItemIds),
          updatedAt: new Date().toISOString()
        }, { merge: true });
      } catch {}
    }
  } catch (err: any) {
    console.warn('ItemService: Error during deleteAllUnifiedItems Firestore sync:', err?.message);
  }

  return count;
}


/**
 * Get User Unified Inventory with Hydrated Items
 */
export async function getUserInventory(discordId: string): Promise<Record<string, UserItemOwnership>> {
  const cleanId = String(discordId).trim();
  if (userInventoriesCache.has(cleanId)) {
    return userInventoriesCache.get(cleanId)!;
  }

  let inventory: Record<string, UserItemOwnership> = {};

  try {
    const db = getFirestoreInstance();
    if (db) {
      // 1. Try 'user_inventories'
      const snap = await getDoc(doc(db, 'user_inventories', cleanId));
      if (snap.exists() && snap.data()?.items) {
        inventory = snap.data().items as Record<string, UserItemOwnership>;
      } else {
        // Fallback to legacy 'character_love_inventories'
        const legacySnap = await getDoc(doc(db, 'character_love_inventories', cleanId));
        if (legacySnap.exists() && legacySnap.data()?.items) {
          inventory = legacySnap.data().items as Record<string, UserItemOwnership>;
        }
      }
    }
  } catch (err: any) {
    console.warn('ItemService: Warning loading user inventory from Firestore:', err?.message);
  }

  userInventoriesCache.set(cleanId, inventory);
  return inventory;
}

/**
 * Save User Unified Inventory
 */
export async function saveUserInventory(discordId: string, inventory: Record<string, UserItemOwnership>): Promise<void> {
  const cleanId = String(discordId).trim();
  userInventoriesCache.set(cleanId, inventory);

  try {
    const db = getFirestoreInstance();
    if (db) {
      const payload = {
        discordId: cleanId,
        items: inventory,
        updatedAt: new Date().toISOString()
      };
      await setDoc(doc(db, 'user_inventories', cleanId), payload, { merge: true });
      // Keep legacy character_love_inventories in sync
      await setDoc(doc(db, 'character_love_inventories', cleanId), payload, { merge: true });
    }
  } catch (err: any) {
    console.error('ItemService: Error saving inventory to Firestore:', err);
  }
}

/**
 * Add items to a user's inventory
 */
export async function addItemsToInventory(discordId: string, itemId: string, quantity = 1): Promise<UserItemOwnership> {
  const inventory = await getUserInventory(discordId);
  const now = new Date().toISOString();
  const existing = inventory[itemId];

  if (existing) {
    existing.count += quantity;
    existing.lastAcquiredAt = now;
  } else {
    inventory[itemId] = {
      itemId,
      count: quantity,
      firstAcquiredAt: now,
      lastAcquiredAt: now
    };
  }

  await saveUserInventory(discordId, inventory);
  return inventory[itemId];
}

/**
 * Use a consumable battle item in combat
 */
export async function useBattleItem(
  discordId: string,
  itemId: string
): Promise<{ success: boolean; item: UnifiedItemDefinition; remainingCount: number; message: string }> {
  const cleanId = String(discordId).trim();
  const item = await getUnifiedItemById(itemId);

  if (!item) {
    throw new Error(`Battle item with ID '${itemId}' not found.`);
  }

  if (item.category !== 'BATTLE' || !item.battleEffect) {
    throw new Error(`Item '${item.name}' is not a usable battle consumable.`);
  }

  const inventory = await getUserInventory(cleanId);
  const ownership = inventory[itemId];

  if (!ownership || ownership.count < 1) {
    throw new Error(`You do not have any '${item.name}' in your inventory.`);
  }

  // Deduct 1 item
  ownership.count -= 1;
  const remainingCount = ownership.count;
  if (ownership.count <= 0) {
    delete inventory[itemId];
  }

  await saveUserInventory(cleanId, inventory);

  return {
    success: true,
    item,
    remainingCount,
    message: `Used ${item.name} in battle!`
  };
}

// ----------------------------------------------------
// DUPLICATE CARDS REWARDS CONFIGURATION & EVALUATION
// ----------------------------------------------------

/**
 * Get Duplicate Card Reward Configuration
 */
export async function getDuplicateCardConfig(forceRefresh = false): Promise<DuplicateCardRewardConfig> {
  if (hasLoadedDuplicateConfig && !forceRefresh) {
    return duplicateConfigCache;
  }

  try {
    const db = getFirestoreInstance();
    if (db) {
      const snap = await getDoc(doc(db, 'settings', 'duplicate_rewards'));
      if (snap.exists()) {
        const data = snap.data() as Partial<DuplicateCardRewardConfig>;
        duplicateConfigCache = {
          enabled: data.enabled !== false,
          mode: data.mode || DEFAULT_DUPLICATE_REWARD_CONFIG.mode,
          coinsByRarity: {
            ...DEFAULT_DUPLICATE_REWARD_CONFIG.coinsByRarity,
            ...(data.coinsByRarity || {})
          },
          materialsByRarity: {
            ...DEFAULT_DUPLICATE_REWARD_CONFIG.materialsByRarity,
            ...(data.materialsByRarity || {})
          },
          updatedAt: data.updatedAt || new Date().toISOString(),
          updatedBy: data.updatedBy
        };
        hasLoadedDuplicateConfig = true;
        return duplicateConfigCache;
      }
    }
  } catch (err: any) {
    console.warn('ItemService: Warning loading duplicate config from Firestore:', err?.message);
  }

  hasLoadedDuplicateConfig = true;
  return duplicateConfigCache;
}

/**
 * Save Duplicate Card Reward Configuration (Owner only)
 */
export async function saveDuplicateCardConfig(
  config: Partial<DuplicateCardRewardConfig>,
  updatedBy: string
): Promise<DuplicateCardRewardConfig> {
  const current = await getDuplicateCardConfig();
  const updated: DuplicateCardRewardConfig = {
    enabled: config.enabled !== undefined ? config.enabled : current.enabled,
    mode: config.mode || current.mode,
    coinsByRarity: {
      ...current.coinsByRarity,
      ...(config.coinsByRarity || {})
    },
    materialsByRarity: {
      ...current.materialsByRarity,
      ...(config.materialsByRarity || {})
    },
    updatedAt: new Date().toISOString(),
    updatedBy
  };

  duplicateConfigCache = updated;

  try {
    const db = getFirestoreInstance();
    if (db) {
      await setDoc(doc(db, 'settings', 'duplicate_rewards'), updated, { merge: true });
    }
  } catch (err: any) {
    console.error('ItemService: Error saving duplicate config to Firestore:', err);
  }

  return updated;
}

/**
 * Evaluate and award duplicate card reward to a user
 */
export async function evaluateDuplicateReward(
  discordId: string,
  rarity: CardRarity
): Promise<DuplicateRewardAwarded | null> {
  if (isAllDeletedState) return null;
  const allCurrent = await getAllUnifiedItems();
  if (allCurrent.length === 0) return null;

  const config = await getDuplicateCardConfig();
  if (!config.enabled) return null;

  // Duplicate cards NEVER award coins per explicit requirement
  const coinsAwarded = 0;
  const materialsAwarded: {
    itemId: string;
    name: string;
    nameAr?: string;
    count: number;
    imageUrl?: string;
    rarity: CardRarity;
  }[] = [];

  const matConfig = config.materialsByRarity[rarity] ?? DEFAULT_DUPLICATE_REWARD_CONFIG.materialsByRarity[rarity];
  if (matConfig && matConfig.itemId && matConfig.count > 0) {
    const cleanItemId = String(matConfig.itemId).trim();
    // Strictly verify that the item is NOT deleted and is currently active in the catalog
    if (!deletedItemIds.has(cleanItemId)) {
      const itemDef = await getUnifiedItemById(cleanItemId);
      if (itemDef && !deletedItemIds.has(itemDef.id) && itemDef.isActive !== false) {
        await addItemsToInventory(discordId, itemDef.id, matConfig.count);
        materialsAwarded.push({
          itemId: itemDef.id,
          name: itemDef.name,
          nameAr: itemDef.nameAr,
          count: matConfig.count,
          imageUrl: itemDef.imageUrl,
          rarity: itemDef.rarity
        });
      }
    }
  }

  // If no materials were awarded (e.g. items were deleted), do NOT return any duplicate item reward
  if (materialsAwarded.length === 0) {
    return null;
  }

  const matStr = materialsAwarded.map(m => `+${m.count} ${m.name}`).join(', ');
  const matStrAr = materialsAwarded.map(m => `+${m.count} ${m.nameAr || m.name}`).join('، ');

  return {
    mode: config.mode,
    coinsAwarded,
    materialsAwarded,
    message: `Duplicate Card: Rewarded ${matStr}!`,
    messageAr: `بطاقة مكررة: كافأتك بـ ${matStrAr}!`
  };
}

/**
 * Roll an item drop from a booster pack across all categories (Battle consumables, Companion gifts, Upgrade materials)
 */
export async function rollUnifiedItemForPack(
  discordId: string,
  packType: CardRarity
): Promise<UnifiedItemDefinition | null> {
  if (isAllDeletedState) {
    return null;
  }

  const items = await getAllUnifiedItems();
  if (items.length === 0) {
    return null;
  }

  const targetPack = String(packType).trim().toUpperCase();

  // Strictly filter items: must be active, not deleted, and explicitly assigned to this pack type
  const eligibleItems = items.filter(
    i => i.isActive !== false &&
         !deletedItemIds.has(i.id) &&
         Array.isArray(i.packages) &&
         i.packages.some(p => String(p).trim().toUpperCase() === targetPack)
  );

  if (eligibleItems.length === 0) {
    return null;
  }

  // When owner assigns items to a pack, guarantee drop so item creation syncs directly with pack openings!
  // Weighted random selection from eligible items
  const totalWeight = eligibleItems.reduce((acc, it) => acc + (it.dropWeight || 20), 0);
  let random = Math.random() * totalWeight;
  let picked: UnifiedItemDefinition = eligibleItems[0];

  for (const it of eligibleItems) {
    const weight = it.dropWeight || 20;
    if (random <= weight) {
      picked = it;
      break;
    }
    random -= weight;
  }

  // Double check that chosen item is valid and not deleted
  if (!picked || deletedItemIds.has(picked.id)) {
    return null;
  }

  // Add 1 copy to user's unified inventory
  try {
    await addItemsToInventory(discordId, picked.id, 1);
  } catch (err) {
    console.warn('ItemService: Warning granting dropped pack item:', err);
  }

  return picked;
}

