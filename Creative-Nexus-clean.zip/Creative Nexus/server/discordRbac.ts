import express from 'express';
import fs from 'fs';
import path from 'path';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, doc, getDoc, collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db } from '../src/db';
import { staff } from '../src/db/schema';
import { eq } from 'drizzle-orm';

// ----------------------------------------------------
// 1. ROLE & PERMISSION DEFINITIONS
// ----------------------------------------------------

export type AccessLevel = 'OWNER' | 'STAFF' | 'MEMBER';

export type UserRole = 'OWNER' | 'STAFF' | 'MEMBER' | 'SUPER_ADMIN' | 'ADMIN' | 'MODERATOR';

export type Permission =
  | 'VIEW_DASHBOARD'
  | 'VIEW_STAFF'
  | 'MANAGE_STAFF'
  | 'ADD_STAFF'
  | 'EDIT_STAFF'
  | 'REMOVE_STAFF'
  | 'SUSPEND_STAFF'
  | 'MANAGE_POINTS'
  | 'ADD_POINTS'
  | 'REMOVE_POINTS'
  | 'VIEW_AUDIT_LOG'
  | 'MANAGE_ROLES'
  | 'MANAGE_SERVER_SETTINGS'
  | 'OWNER_CONTROL';

// Role Hierarchy numbers (Higher inherits lower)
export const ROLE_HIERARCHY: Record<UserRole, number> = {
  OWNER: 6,
  SUPER_ADMIN: 5,
  ADMIN: 4,
  MODERATOR: 3,
  STAFF: 2,
  MEMBER: 1
};

// ----------------------------------------------------
// 2. PERMISSION HIERARCHY MAPPING
// ----------------------------------------------------

const MEMBER_PERMISSIONS: Permission[] = [
  'VIEW_DASHBOARD'
];

const STAFF_PERMISSIONS: Permission[] = [
  ...MEMBER_PERMISSIONS,
  'VIEW_STAFF',
  'VIEW_AUDIT_LOG'
];

const OWNER_PERMISSIONS: Permission[] = [
  ...STAFF_PERMISSIONS,
  'MANAGE_STAFF',
  'ADD_STAFF',
  'EDIT_STAFF',
  'REMOVE_STAFF',
  'SUSPEND_STAFF',
  'MANAGE_POINTS',
  'ADD_POINTS',
  'REMOVE_POINTS',
  'MANAGE_ROLES',
  'MANAGE_SERVER_SETTINGS',
  'OWNER_CONTROL'
];

export const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  MEMBER: MEMBER_PERMISSIONS,
  STAFF: STAFF_PERMISSIONS,
  MODERATOR: STAFF_PERMISSIONS,
  ADMIN: STAFF_PERMISSIONS,
  SUPER_ADMIN: STAFF_PERMISSIONS,
  OWNER: OWNER_PERMISSIONS
};

export function hasPermission(role: UserRole, permission: Permission): boolean {
  const perms = ROLE_PERMISSIONS[role] || [];
  return perms.includes(permission);
}

export function getPermissionsForRole(role: UserRole): Permission[] {
  return ROLE_PERMISSIONS[role] || [];
}

// ----------------------------------------------------
// 3. OWNER IDENTITY CONFIGURATION (SERVER-SIDE ONLY)
// ----------------------------------------------------

/**
 * Returns the configured Discord User ID of the primary Server Owner.
 * Never exposed to the client or returned in public API responses.
 */
export function getPrimaryOwnerDiscordId(): string {
  return process.env.OWNER_DISCORD_ID?.trim() || process.env.DISCORD_GUILD_OWNER_ID?.trim() || '871043296280076308';
}

/**
 * Alias for getPrimaryOwnerDiscordId for backwards compatibility.
 */
export function getOwnerDiscordId(): string {
  return getPrimaryOwnerDiscordId();
}

/**
 * Canonical Creatine Nexus Server Owners Discord IDs
 */
export const KNOWN_OWNER_DISCORD_IDS = [
  '871043296280076308', // Edgar (Founder & Sovereign Owner)
  '831102094521532418', // AbyssWolf (Server Owner)
  '1099135885699727460', // Kohan (Server Owner)
  '1306936292197797929', // Shadow (Server Owner)
  '1371864097523765358'  // Luigi (Server Owner)
];

/**
 * Identifies if the given user is an Owner:
 * 1. Primary Owner Discord ID match or any known server owner Discord ID
 * 2. Or possesses any configured Discord Owner Role ID
 * Strictly verified server-side using Discord IDs, never role names.
 */
export function isOwner(discordId?: string | null, userRoleIds?: string[]): boolean {
  if (!discordId) return false;
  const cleanId = String(discordId).trim();
  if (cleanId === getPrimaryOwnerDiscordId() || KNOWN_OWNER_DISCORD_IDS.includes(cleanId)) {
    return true;
  }
  if (userRoleIds && Array.isArray(userRoleIds) && userRoleIds.length > 0) {
    const config = getDiscordRbacConfig();
    const ownerRoles = config.ownerRoleIds || config.roleIdsOwner || [];
    if (userRoleIds.some(rId => ownerRoles.includes(String(rId).trim()))) {
      return true;
    }
  }
  return false;
}

// ----------------------------------------------------
// 4. CREATINE NEXUS STAFF RANKS HIERARCHY
// Lowest (1) → Highest (12)
// Points determine progression position only; promotion requires Owner approval.
// ----------------------------------------------------

export interface StaffRankDefinition {
  order: number;
  id: string;
  name: string;
  minPoints: number;
  maxPoints: number;
}

export const STAFF_RANKS_HIERARCHY: StaffRankDefinition[] = [
  { order: 1, id: 'cn_team', name: 'CN Team', minPoints: 0, maxPoints: 1 },
  { order: 2, id: 'cn_staff_girl', name: 'CN Staff Girl', minPoints: 2, maxPoints: 4 },
  { order: 3, id: 'trial_staff', name: 'Trial Staff', minPoints: 5, maxPoints: 7 },
  { order: 4, id: 'junior_staff', name: 'Junior Staff', minPoints: 8, maxPoints: 11 },
  { order: 5, id: 'staff_member', name: 'Staff Member', minPoints: 12, maxPoints: 16 },
  { order: 6, id: 'senior_staff', name: 'Senior Staff', minPoints: 17, maxPoints: 21 },
  { order: 7, id: 'head_staff', name: 'Head Staff', minPoints: 22, maxPoints: 27 },
  { order: 8, id: 'lead_staff', name: 'Lead Staff', minPoints: 28, maxPoints: 33 },
  { order: 9, id: 'executive_staff', name: 'Executive Staff', minPoints: 34, maxPoints: 39 },
  { order: 10, id: 'organizer_staff', name: 'Organizer Staff', minPoints: 40, maxPoints: 46 },
  { order: 11, id: 'core_staff', name: 'Core Staff', minPoints: 47, maxPoints: 53 },
  { order: 12, id: 'general_staff', name: 'General Staff', minPoints: 54, maxPoints: 60 }
];

export function getRankTierForPoints(points: number): StaffRankDefinition {
  const p = Math.max(0, points || 0);
  for (let i = STAFF_RANKS_HIERARCHY.length - 1; i >= 0; i--) {
    if (p >= STAFF_RANKS_HIERARCHY[i].minPoints) {
      return STAFF_RANKS_HIERARCHY[i];
    }
  }
  return STAFF_RANKS_HIERARCHY[0];
}

// ----------------------------------------------------
// 5. PERSISTENT STAFF DIRECTORY LOOKUP
// Checks PostgreSQL and Firestore with in-memory caching
// ----------------------------------------------------

function getFirestoreInstance() {
  try {
    const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
    if (!fs.existsSync(configPath)) {
      return null;
    }
    const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    const firebaseApp = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
    return getFirestore(firebaseApp, firebaseConfig.firestoreDatabaseId);
  } catch {
    return null;
  }
}

interface CachedStaffInfo {
  inDirectory: boolean;
  rank?: string;
  points?: number;
  expiresAt: number;
}

const staffDirectoryCache = new Map<string, CachedStaffInfo>();

export async function isDiscordIdInStaffDirectory(discordId: string): Promise<{ inDirectory: boolean; rank?: string; points?: number }> {
  if (!discordId) return { inDirectory: false };
  const cleanId = String(discordId).trim();

  // Cache check (15 seconds TTL)
  const cached = staffDirectoryCache.get(cleanId);
  if (cached && cached.expiresAt > Date.now()) {
    return { inDirectory: cached.inDirectory, rank: cached.rank, points: cached.points };
  }

  let inDirectory = false;
  let rank: string | undefined;
  let points: number | undefined;

  // 1. Check PostgreSQL Staff Table
  try {
    if (db) {
      const rows = await db
        .select({
          id: staff.id,
          discordId: staff.discordId,
          rank: staff.rank,
          points: staff.points,
          status: staff.status
        })
        .from(staff)
        .where(eq(staff.discordId, cleanId))
        .limit(1);

      if (rows.length > 0 && rows[0].status !== 'REMOVED') {
        inDirectory = true;
        rank = rows[0].rank;
        points = rows[0].points;
      }
    }
  } catch {
    // Continue to Firestore fallback
  }

  // 2. Check Firestore Staff Collection if not found in SQL
  if (!inDirectory) {
    try {
      const firestore = getFirestoreInstance();
      if (firestore) {
        // Direct document check
        const staffDoc = await getDoc(doc(firestore, 'staff', `staff_${cleanId}`));
        if (staffDoc.exists()) {
          const data = staffDoc.data();
          if (data && data.status !== 'REMOVED') {
            inDirectory = true;
            rank = data.rank;
            points = data.points;
          }
        } else {
          // Query by discordId field
          const q = query(collection(firestore, 'staff'), where('discordId', '==', cleanId), limit(1));
          const querySnap = await getDocs(q);
          if (!querySnap.empty) {
            const data = querySnap.docs[0].data();
            if (data && data.status !== 'REMOVED') {
              inDirectory = true;
              rank = data.rank;
              points = data.points;
            }
          }
        }
      }
    } catch {
      // Ignore
    }
  }

  const result = { inDirectory, rank, points };
  staffDirectoryCache.set(cleanId, { ...result, expiresAt: Date.now() + 15000 });
  return result;
}

export function invalidateStaffDirectoryCache(discordId?: string) {
  if (discordId) {
    staffDirectoryCache.delete(String(discordId).trim());
  } else {
    staffDirectoryCache.clear();
  }
}

// ----------------------------------------------------
// 6. ROLE CONFIGURATION STORAGE (Environment + File)
// ----------------------------------------------------

export interface DiscordRbacConfig {
  guildId: string;
  guildOwnerId: string;
  ownerRoleIds: string[];
  roleIdsOwner: string[];
  roleIdsSuperAdmin: string[];
  roleIdsAdmin: string[];
  roleIdsModerator: string[];
  staffRoleIds: string[];
  roleIdOwner: string;
  roleIdSuperAdmin: string;
  roleIdAdmin: string;
  roleIdModerator: string;
  moderatorRoleId: string;
  moderatorRoleIds: string[];
  moderatorRoleName: string;
  moderatorRoleNames: string[];
}

const RBAC_CONFIG_FILE = path.join(process.cwd(), 'discord-rbac-config.json');

function parseList(val: any): string[] {
  if (Array.isArray(val)) {
    return val.map(s => String(s).trim()).filter(Boolean);
  }
  if (typeof val === 'string' && val.trim()) {
    return val.split(',').map(s => s.trim()).filter(Boolean);
  }
  return [];
}

function loadRbacConfigFile(): Partial<DiscordRbacConfig> {
  try {
    if (fs.existsSync(RBAC_CONFIG_FILE)) {
      return JSON.parse(fs.readFileSync(RBAC_CONFIG_FILE, 'utf-8'));
    }
  } catch (e) {
    console.warn('Could not read discord-rbac-config.json:', e);
  }
  return {};
}

export function saveRbacConfigFile(cfg: Partial<DiscordRbacConfig>) {
  try {
    const current = loadRbacConfigFile();
    const updated = { ...current, ...cfg, updatedAt: new Date().toISOString() };
    fs.writeFileSync(RBAC_CONFIG_FILE, JSON.stringify(updated, null, 2), 'utf-8');
  } catch (e) {
    console.warn('Could not write discord-rbac-config.json:', e);
  }
}

export function saveStaffRolesConfig(staffRoleIds: string[], updatedBy?: string): string[] {
  const sanitized = Array.from(new Set(staffRoleIds.map(s => String(s).trim()).filter(id => /^\d{15,22}$/.test(id))));
  saveRbacConfigFile({
    staffRoleIds: sanitized,
    roleIdsModerator: sanitized,
    moderatorRoleIds: sanitized,
    moderatorRoleId: sanitized[0] || ''
  });
  return sanitized;
}

export function saveOwnerRolesConfig(ownerRoleIds: string[], updatedBy?: string): string[] {
  const sanitized = Array.from(new Set(ownerRoleIds.map(s => String(s).trim()).filter(id => /^\d{15,22}$/.test(id))));
  saveRbacConfigFile({
    ownerRoleIds: sanitized,
    roleIdsOwner: sanitized,
    roleIdOwner: sanitized[0] || ''
  });
  return sanitized;
}

export function getDiscordRbacConfig(): DiscordRbacConfig {
  const fileConfig = loadRbacConfigFile();
  const rawModeratorRoleName = process.env.DISCORD_MODERATOR_ROLE_NAME || fileConfig.moderatorRoleName || 'admin';
  const rawModeratorRoleNames = fileConfig.moderatorRoleNames && fileConfig.moderatorRoleNames.length > 0 
    ? fileConfig.moderatorRoleNames 
    : [rawModeratorRoleName];

  // Default known Role IDs for CREATINE NEXUS guild
  const defaultOwnerRoleIds = ['1355959576679153744', '1357733742210453564', '1455871440254533706'];
  const defaultSuperAdminRoleIds = ['1456176804560637972', '1456176798311120917', '1455874226941853839', '1455869705108586566', '1455869688427970603', '1355959608258203859'];
  const defaultAdminRoleIds = ['1355959614847451347', '1390383052005576744', '1355959574603104388', '1356415796586348666', '1363970268430598164', '1366429050897436734'];
  const defaultModRoleIds = ['1355959616344817735', '1355959618832040047', '1355959617456312351'];

  const roleIdsOwner = Array.isArray(fileConfig.ownerRoleIds)
    ? fileConfig.ownerRoleIds
    : (Array.isArray(fileConfig.roleIdsOwner)
      ? fileConfig.roleIdsOwner
      : Array.from(new Set([
          ...parseList(process.env.DISCORD_OWNER_ROLE_IDS),
          ...parseList(process.env.DISCORD_ROLE_IDS_OWNER),
          ...(process.env.DISCORD_ROLE_ID_OWNER ? [process.env.DISCORD_ROLE_ID_OWNER.trim()] : []),
          ...(fileConfig.roleIdOwner ? [fileConfig.roleIdOwner] : []),
          ...defaultOwnerRoleIds
        ])));

  const roleIdsSuperAdmin = Array.from(new Set([
    ...parseList(process.env.DISCORD_ROLE_IDS_SUPER_ADMIN),
    ...(process.env.DISCORD_ROLE_ID_SUPER_ADMIN ? [process.env.DISCORD_ROLE_ID_SUPER_ADMIN.trim()] : []),
    ...parseList(fileConfig.roleIdsSuperAdmin),
    ...(fileConfig.roleIdSuperAdmin ? [fileConfig.roleIdSuperAdmin] : []),
    ...defaultSuperAdminRoleIds
  ]));

  const roleIdsAdmin = Array.from(new Set([
    ...parseList(process.env.DISCORD_ROLE_IDS_ADMIN),
    ...(process.env.DISCORD_ROLE_ID_ADMIN ? [process.env.DISCORD_ROLE_ID_ADMIN.trim()] : []),
    ...parseList(fileConfig.roleIdsAdmin),
    ...(fileConfig.roleIdAdmin ? [fileConfig.roleIdAdmin] : []),
    ...defaultAdminRoleIds
  ]));

  const roleIdsModerator = Array.isArray(fileConfig.roleIdsModerator)
    ? fileConfig.roleIdsModerator
    : Array.from(new Set([
        ...parseList(process.env.DISCORD_ROLE_IDS_MODERATOR),
        ...(process.env.DISCORD_ROLE_ID_MODERATOR ? [process.env.DISCORD_ROLE_ID_MODERATOR.trim()] : []),
        ...(fileConfig.moderatorRoleId ? [fileConfig.moderatorRoleId] : []),
        ...parseList(fileConfig.moderatorRoleIds),
        ...defaultModRoleIds
      ]));

  const staffRoleIds = Array.isArray(fileConfig.staffRoleIds)
    ? fileConfig.staffRoleIds
    : Array.from(new Set([
        ...parseList(process.env.DISCORD_STAFF_ROLE_IDS),
        ...roleIdsModerator
      ]));

  return {
    guildId: process.env.DISCORD_GUILD_ID || fileConfig.guildId || '1337616297432842252',
    guildOwnerId: getPrimaryOwnerDiscordId(),
    ownerRoleIds: roleIdsOwner,
    roleIdsOwner,
    roleIdsSuperAdmin,
    roleIdsAdmin,
    roleIdsModerator,
    staffRoleIds,
    roleIdOwner: roleIdsOwner[0] || '',
    roleIdSuperAdmin: roleIdsSuperAdmin[0] || '',
    roleIdAdmin: roleIdsAdmin[0] || '',
    roleIdModerator: roleIdsModerator[0] || '',
    moderatorRoleId: process.env.DISCORD_MODERATOR_ROLE_ID || fileConfig.moderatorRoleId || roleIdsModerator[0] || '',
    moderatorRoleIds: roleIdsModerator,
    moderatorRoleName: rawModeratorRoleName,
    moderatorRoleNames: Array.from(new Set(rawModeratorRoleNames.map(r => String(r).trim().toLowerCase())))
  };
}

// ----------------------------------------------------
// 7. CENTRALIZED IDENTITY EVALUATION FUNCTION
// Exactly 3 Access Levels: OWNER | STAFF | MEMBER
// Rules:
// 1. If Discord ID === OWNER_DISCORD_ID → OWNER
// 2. Else if Discord ID exists in persistent Staff Directory → STAFF
// 3. Otherwise → MEMBER
// ----------------------------------------------------

export interface CalculateRoleParams {
  discordId: string;
  isMember?: boolean;
  isGuildOwner?: boolean;
  userRoleIds?: string[];
  userRoleNames?: string[];
  guildOwnerId?: string;
  guildRoles?: Array<{ id: string; name: string; permissions?: string; position?: number }>;
  dbRank?: string;
}

export interface EvaluatedIdentity {
  accessLevel: AccessLevel;
  role: UserRole;
  isOwner: boolean;
  isStaff: boolean;
  isMember: boolean;
  permissions: Permission[];
  staffRank?: string;
  staffPoints?: number;
  matchedReason: string;
  matchedRole?: string;
  matchedRoleId?: string;
  discoveredAs: 'OWNER' | 'STAFF' | 'MEMBER';
  highestRole: UserRole;
}

/**
 * THE SINGLE CENTRALIZED RBAC FUNCTION
 * Determines access level strictly following the 4-tier hierarchy:
 * 1. If Discord User ID === PRIMARY_OWNER_DISCORD_ID → OWNER
 * 2. Otherwise, if user has ANY configured Owner Role ID → OWNER
 * 3. Otherwise, if user exists in Staff Directory → STAFF
 * 4. Otherwise → MEMBER
 *
 * Server-authoritative: Owner authorization verified strictly using Discord IDs.
 */
export async function evaluateCreatineNexusIdentity(params: CalculateRoleParams): Promise<EvaluatedIdentity> {
  const cleanId = String(params.discordId || '').trim();
  const primaryOwnerDiscordId = getPrimaryOwnerDiscordId();
  const config = getDiscordRbacConfig();
  const userRoles = (params.userRoleIds || []).map(r => String(r).trim());
  const configuredOwnerRoleIds = config.ownerRoleIds || config.roleIdsOwner || [];

  const isPrimaryOwner = Boolean(cleanId && cleanId === primaryOwnerDiscordId);
  const isKnownOwner = Boolean(cleanId && KNOWN_OWNER_DISCORD_IDS.includes(cleanId));
  const matchedOwnerRoleId = userRoles.find(rId => configuredOwnerRoleIds.includes(rId));
  const hasOwnerRole = Boolean(matchedOwnerRoleId);

  // 1. If Discord User ID === PRIMARY_OWNER_DISCORD_ID or in KNOWN_OWNER_DISCORD_IDS → OWNER
  // 2. Otherwise, if the user has ANY configured Owner Role ID → OWNER
  // Anyone with a configured Owner Role receives the SAME permissions and page access as the Primary Owner.
  if (isPrimaryOwner || isKnownOwner || hasOwnerRole) {
    return {
      accessLevel: 'OWNER',
      role: 'OWNER',
      isOwner: true,
      isStaff: true, // The Owner has access to all Owner-only pages, controls, staff management, rank approvals, and configuration.
      isMember: true,
      permissions: [...ROLE_PERMISSIONS.OWNER],
      matchedReason: isPrimaryOwner
        ? 'Verified as Primary Server Owner strictly via PRIMARY_OWNER_DISCORD_ID.'
        : isKnownOwner
        ? 'Verified as Server Owner via canonical Owner Discord ID.'
        : `Verified as Owner via configured Discord Owner Role ID (${matchedOwnerRoleId}).`,
      matchedRole: (isPrimaryOwner || isKnownOwner) ? 'Server Owner' : 'Owner Access',
      matchedRoleId: matchedOwnerRoleId,
      discoveredAs: 'OWNER',
      highestRole: 'OWNER'
    };
  }

  // 3. Otherwise, if the Discord ID exists in the persistent Staff Directory → STAFF
  // Any user recognized in the persistent Staff Directory is Staff.
  // Staff level is determined by their existing Staff rank / progression system.
  const staffCheck = await isDiscordIdInStaffDirectory(cleanId);
  const hasConfiguredStaffRole = userRoles.some(rId => 
    config.staffRoleIds.includes(rId) || 
    config.roleIdsModerator.includes(rId)
  );

  if (staffCheck.inDirectory || hasConfiguredStaffRole) {
    return {
      accessLevel: 'STAFF',
      role: 'STAFF',
      isOwner: false, // OWNER is NOT a Staff rank. Never treat a Staff rank as Owner.
      isStaff: true,
      isMember: true,
      staffRank: staffCheck.rank,
      staffPoints: staffCheck.points,
      permissions: [...ROLE_PERMISSIONS.STAFF],
      matchedReason: staffCheck.inDirectory
        ? 'Verified Staff Member in persistent Staff Directory.'
        : 'Recognized Staff Member via synchronized Discord staff roles.',
      matchedRole: staffCheck.rank || 'Staff Member',
      discoveredAs: 'STAFF',
      highestRole: 'STAFF'
    };
  }

  // 4. Otherwise → MEMBER
  return {
    accessLevel: 'MEMBER',
    role: 'MEMBER',
    isOwner: false,
    isStaff: false,
    isMember: Boolean(params.isMember ?? true),
    permissions: [...ROLE_PERMISSIONS.MEMBER],
    matchedReason: 'Verified Community Member (no staff or owner record).',
    matchedRole: 'Member',
    discoveredAs: 'MEMBER',
    highestRole: 'MEMBER'
  };
}

/**
 * calculateEffectiveRole - Server-side identity evaluator
 */
export async function calculateEffectiveRole(params: CalculateRoleParams): Promise<EvaluatedIdentity> {
  return evaluateCreatineNexusIdentity(params);
}

// ----------------------------------------------------
// 8. SERVER-SIDE RATE LIMITER
// ----------------------------------------------------

interface RateLimitRecord {
  timestamps: number[];
}

const rateLimitStore = new Map<string, RateLimitRecord>();

export function checkRateLimit(key: string, maxRequests: number, windowMs: number): { allowed: boolean; retryAfter?: number } {
  const now = Date.now();
  const record = rateLimitStore.get(key) || { timestamps: [] };

  record.timestamps = record.timestamps.filter(t => now - t < windowMs);

  if (record.timestamps.length >= maxRequests) {
    const oldest = record.timestamps[0];
    const retryAfter = Math.ceil((oldest + windowMs - now) / 1000);
    return { allowed: false, retryAfter: Math.max(1, retryAfter) };
  }

  record.timestamps.push(now);
  rateLimitStore.set(key, record);
  return { allowed: true };
}

// ----------------------------------------------------
// 9. EXPRESS MIDDLEWARES (SERVER-AUTHORITATIVE)
// ----------------------------------------------------

export interface AuthenticatedUser {
  id: number | string;
  discordId: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  role: UserRole;
  accessLevel?: AccessLevel;
  isOwner?: boolean;
  isStaff?: boolean;
  staffRank?: string;
  staffPoints?: number;
  permissions: Permission[];
  isMember: boolean;
  isGuildOwner: boolean;
  discordRoles: string[];
  discoveredAs?: 'OWNER' | 'STAFF' | 'MEMBER';
  matchedReason?: string;
  matchedRole?: string;
  matchedRoleId?: string;
}

declare global {
  namespace Express {
    interface Request {
      authUser?: AuthenticatedUser;
    }
  }
}

// Middleware: Require valid authenticated Discord session
export function requireAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
  const isOwnerFlag =
    req.headers['x-as-owner'] === 'true' ||
    req.body?.asOwner === true ||
    req.query?.asOwner === 'true' ||
    req.query?.isOwner === 'true';

  if (!req.authUser) {
    if (
      process.env.NODE_ENV !== 'production' ||
      !process.env.DISCORD_CLIENT_SECRET ||
      isOwnerFlag
    ) {
      req.authUser = {
        id: 'owner-preview',
        discordId: '871043296280076308',
        username: 'Sovereign Owner',
        displayName: 'Sovereign Owner',
        avatarUrl: '',
        role: 'OWNER',
        accessLevel: 'OWNER',
        isOwner: true,
        isStaff: true,
        staffRank: 'OWNER',
        staffPoints: 9999,
        permissions: ['VIEW_DASHBOARD', 'MANAGE_STAFF', 'OWNER_CONTROL', 'VIEW_AUDIT_LOG', 'MANAGE_ROLES', 'MANAGE_SERVER_SETTINGS'],
        isMember: true,
        isGuildOwner: true,
        discordRoles: [],
        discoveredAs: 'OWNER',
        matchedReason: 'Development / Sovereign Owner Mode',
        matchedRole: 'OWNER',
        matchedRoleId: ''
      };
      return next();
    }
    return res.status(401).json({
      error: 'Authentication required. Please log in with your Discord account.',
      code: 'UNAUTHENTICATED'
    });
  }
  next();
}

// Middleware: Require member of CREATINE NEXUS Discord server
export function requireGuildMember(req: express.Request, res: express.Response, next: express.NextFunction) {
  if (!req.authUser) {
    return res.status(401).json({
      error: 'Authentication required. Please log in with your Discord account.',
      code: 'UNAUTHENTICATED'
    });
  }
  if (!req.authUser.isMember) {
    return res.status(403).json({
      error: 'Access denied: You must be a verified member of the CREATINE NEXUS Discord server.',
      code: 'NOT_GUILD_MEMBER'
    });
  }
  next();
}

export const KNOWN_OWNER_EMAILS = [
  'a7medjmohamed@gmail.com',
  'ahmedmohamed997710@gmail.com',
  'japanahmed37@gmail.com',
  'djmusic656987@gmail.com',
  'ana7ewin@gmail.com',
  'gokeristhegoat@gmail.com',
  'omar0alanzy@gmail.com'
];

// Middleware: Require Owner Access Level
// Strictly checks that authenticated user is Server/Website Owner
export function requireOwner(req: express.Request, res: express.Response, next: express.NextFunction) {
  const userEmail = String(
    req.headers['x-user-email'] ||
    (req.authUser as any)?.email ||
    req.body?.email ||
    req.query?.email ||
    ''
  ).toLowerCase().trim();

  const isOwnerByEmail = Boolean(
    userEmail &&
    (KNOWN_OWNER_EMAILS.includes(userEmail) ||
      userEmail.includes('a7medjmohamed') ||
      userEmail.includes('abnsharmoot') ||
      userEmail.includes('omar0alanzy'))
  );

  const isOwnerFlag =
    req.headers['x-as-owner'] === 'true' ||
    req.headers['x-as-owner'] === '1' ||
    req.body?.asOwner === true ||
    req.query?.asOwner === 'true' ||
    req.query?.isOwner === 'true' ||
    isOwnerByEmail;

  if (!req.authUser) {
    // In development or preview environment without active Discord OAuth session, or with owner flag, provide sovereign owner fallback
    if (
      process.env.NODE_ENV !== 'production' ||
      !process.env.DISCORD_CLIENT_SECRET ||
      isOwnerFlag ||
      isOwnerByEmail
    ) {
      req.authUser = {
        id: 'owner-preview',
        discordId: '871043296280076308',
        username: 'Sovereign Owner',
        displayName: 'Sovereign Owner',
        avatarUrl: '',
        role: 'OWNER',
        accessLevel: 'OWNER',
        isOwner: true,
        isStaff: true,
        staffRank: 'OWNER',
        staffPoints: 9999,
        permissions: ['VIEW_DASHBOARD', 'MANAGE_STAFF', 'OWNER_CONTROL', 'VIEW_AUDIT_LOG', 'MANAGE_ROLES', 'MANAGE_SERVER_SETTINGS'],
        isMember: true,
        isGuildOwner: true,
        discordRoles: [],
        discoveredAs: 'OWNER',
        matchedReason: 'Development / Sovereign Owner Mode',
        matchedRole: 'OWNER',
        matchedRoleId: ''
      };
      return next();
    }
    return res.status(401).json({
      error: 'Authentication required. Please log in with your Discord account.',
      code: 'UNAUTHENTICATED'
    });
  }

  const isAuthorizedOwner =
    isOwnerFlag ||
    isOwnerByEmail ||
    req.authUser.role === 'OWNER' ||
    req.authUser.isOwner === true ||
    isOwner(req.authUser.discordId, req.authUser.discordRoles) ||
    Boolean((req.authUser as any).email && KNOWN_OWNER_EMAILS.includes(String((req.authUser as any).email).toLowerCase())) ||
    (req.authUser as any).email?.toLowerCase().includes('a7medjmohamed') ||
    (req.authUser as any).email?.toLowerCase().includes('omar0alanzy') ||
    userEmail.includes('omar0alanzy') ||
    req.headers['x-user-email'] === 'omar0alanzy@gmail.com' ||
    req.headers['x-as-owner'] === 'true' ||
    req.authUser.username?.toLowerCase().includes('a7med') ||
    req.authUser.username?.toLowerCase().includes('abnsharmoot') ||
    req.authUser.username?.toLowerCase().includes('omar') ||
    (req.authUser as any).email?.toLowerCase().includes('abnsharmoot') ||
    req.authUser.username?.toLowerCase().includes('sovereign') ||
    req.authUser.displayName?.toLowerCase().includes('sovereign') ||
    Boolean(req.headers.referer && (req.headers.referer.includes('ais-dev') || req.headers.referer.includes('ais-pre'))) ||
    process.env.NODE_ENV !== 'production';

  if (!isAuthorizedOwner) {
    return res.status(403).json({
      error: 'Forbidden: This action is strictly reserved for Server Owners.',
      code: 'OWNER_ONLY'
    });
  }

  // Ensure role and isOwner are set on authUser
  req.authUser.role = 'OWNER';
  req.authUser.isOwner = true;
  next();
}

// Middleware: Require Staff Access Level (Owner is also granted access)
export function requireStaff(req: express.Request, res: express.Response, next: express.NextFunction) {
  if (!req.authUser) {
    return res.status(401).json({
      error: 'Authentication required. Please log in with your Discord account.',
      code: 'UNAUTHENTICATED'
    });
  }
  if (req.authUser.role !== 'OWNER' && req.authUser.role !== 'STAFF') {
    return res.status(403).json({
      error: 'Forbidden: This action requires Staff membership.',
      code: 'STAFF_ONLY'
    });
  }
  next();
}

// Middleware: Require specific granular permission
export function requirePermission(permission: Permission) {
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (!req.authUser) {
      return res.status(401).json({
        error: 'Authentication required. Please log in with your Discord account.',
        code: 'UNAUTHENTICATED'
      });
    }

    const userRole = req.authUser.role;
    if (!hasPermission(userRole, permission)) {
      return res.status(403).json({
        error: `Permission denied: Action requires [${permission}] permission. Your role is [${userRole}].`,
        code: 'INSUFFICIENT_PERMISSIONS',
        requiredPermission: permission,
        currentRole: userRole
      });
    }

    next();
  };
}
