import express from 'express';
import { requireAuth, requireOwner } from './discordRbac';
import { 
  getUserStoryProgress, 
  recordStoryBattleCompletion,
  getAllStoryChapters,
  saveStoryBattle,
  deleteStoryBattle,
  saveStoryChapter,
  deleteStoryChapter
} from './storyService';
import { loadCustomCardsFromFirestore } from './cardService';
import { CollectibleCardData } from '../src/types/cards';
import { recordAuditEvent } from './auditService';

export function setupStoryRoutes(app: express.Express) {
  const router = express.Router();

  // 1. GET /api/story/chapters (Public/Auth) - List of story chapters, battles, and enemy decks
  router.get('/chapters', async (req, res) => {
    try {
      const catalog = await loadCustomCardsFromFirestore(true);
      const chapters = await getAllStoryChapters();

      // Populate enemy deck card definitions
      const chaptersWithCards = chapters.map(chapter => ({
        ...chapter,
        battles: chapter.battles.map(battle => {
          const enemyCards: CollectibleCardData[] = battle.enemyDeckCardIds
            .map(cid => catalog.find(c => c.id === cid))
            .filter((c): c is CollectibleCardData => Boolean(c));

          return {
            ...battle,
            enemyCards
          };
        })
      }));

      res.json({ success: true, chapters: chaptersWithCards });
    } catch (err: any) {
      console.error('Error fetching story chapters:', err);
      res.status(500).json({ error: 'Failed to load story chapters' });
    }
  });

  // 2. POST /api/story/chapters (Owner only) - Create or update a chapter
  router.post('/chapters', requireOwner, async (req, res) => {
    try {
      const chapterData = req.body;
      if (!chapterData.title) {
        return res.status(400).json({ error: 'Chapter title is required' });
      }

      const result = await saveStoryChapter(chapterData);
      if (!result.success) {
        return res.status(400).json({ error: result.error || 'Failed to save story chapter' });
      }

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'ADMIN',
        action: `Owner saved story chapter "${result.chapter.title}" (ID: ${result.chapter.id})`,
        path: '/api/story/chapters',
        userId: req.authUser?.discordId
      }, req);

      res.json({ success: true, chapter: result.chapter });
    } catch (err: any) {
      console.error('Error saving story chapter:', err);
      res.status(500).json({ error: err.message || 'Failed to save story chapter' });
    }
  });

  // 3. DELETE /api/story/chapters/:id (Owner only) - Delete a chapter
  router.delete('/chapters/:id', requireOwner, async (req, res) => {
    try {
      const chapterId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
      if (!chapterId) {
        return res.status(400).json({ error: 'Chapter ID is required' });
      }

      const result = await deleteStoryChapter(chapterId);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'ADMIN',
        action: `Owner deleted story chapter "${chapterId}"`,
        path: `/api/story/chapters/${chapterId}`,
        userId: req.authUser?.discordId
      }, req);

      res.json(result);
    } catch (err: any) {
      console.error('Error deleting story chapter:', err);
      res.status(500).json({ error: err.message || 'Failed to delete story chapter' });
    }
  });

  // 4. GET /api/story/progress (Auth required) - Get user story progress
  router.get('/progress', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const progress = await getUserStoryProgress(user.discordId);
      res.json({ success: true, progress });
    } catch (err: any) {
      console.error('Error fetching story progress:', err);
      res.status(500).json({ error: 'Failed to load story progress' });
    }
  });

  // 5. POST /api/story/battles (Owner only) - Add or update a story battle
  router.post('/battles', requireOwner, async (req, res) => {
    try {
      const battleData = req.body;
      if (!battleData.name || !battleData.enemyCommanderName) {
        return res.status(400).json({ error: 'Battle name and enemy commander name are required' });
      }

      const result = await saveStoryBattle(battleData);
      if (!result.success) {
        return res.status(400).json({ error: result.error || 'Failed to save story battle' });
      }

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'ADMIN',
        action: `Owner saved story battle "${result.battle.name}" (Commander: ${result.battle.enemyCommanderName}, Cards: ${result.battle.enemyDeckCardIds.length})`,
        path: '/api/story/battles',
        userId: req.authUser?.discordId
      }, req);

      res.json({ success: true, battle: result.battle });
    } catch (err: any) {
      console.error('Error saving story battle:', err);
      res.status(500).json({ error: err.message || 'Failed to save story battle' });
    }
  });

  // 6. DELETE /api/story/battles/:id (Owner only) - Delete a story battle
  router.delete('/battles/:id', requireOwner, async (req, res) => {
    try {
      const battleId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
      if (!battleId) {
        return res.status(400).json({ error: 'Battle ID is required' });
      }

      const result = await deleteStoryBattle(battleId);

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'ADMIN',
        action: `Owner deleted story battle "${battleId}"`,
        path: `/api/story/battles/${battleId}`,
        userId: req.authUser?.discordId
      }, req);

      res.json(result);
    } catch (err: any) {
      console.error('Error deleting story battle:', err);
      res.status(500).json({ error: err.message || 'Failed to delete story battle' });
    }
  });

  // 7. POST /api/story/complete-battle (Auth required) - Server-authoritative victory/defeat & reward claim
  router.post('/complete-battle', requireAuth, async (req, res) => {
    try {
      const user = req.authUser!;
      const { battleId, outcome } = req.body;

      if (!battleId || (outcome !== 'VICTORY' && outcome !== 'DEFEAT')) {
        return res.status(400).json({ error: 'battleId and outcome (VICTORY|DEFEAT) are required' });
      }

      const result = await recordStoryBattleCompletion(user.discordId, battleId, outcome);
      res.json(result);
    } catch (err: any) {
      console.error('Error completing story battle:', err);
      res.status(400).json({ error: err.message || 'Failed to record battle completion' });
    }
  });

  app.use('/api/story', router);
}
