import express from 'express';
import crypto from 'crypto';
import { recordAuditEvent } from './auditService';
import { db } from '../src/db';
import { users, staff, serverConfig } from '../src/db/schema';
import { eq } from 'drizzle-orm';
import {
  AuthenticatedUser,
  UserRole,
  Permission,
  calculateEffectiveRole,
  getDiscordRbacConfig,
  saveRbacConfigFile,
  saveStaffRolesConfig,
  saveOwnerRolesConfig,
  checkRateLimit,
  ROLE_PERMISSIONS,
  requirePermission,
  isOwner,
  getOwnerDiscordId
} from './discordRbac';
import { getFirestoreInstance, runStaffDiscordSync } from './discordStaffSync';
import { doc, setDoc, getDoc } from 'firebase/firestore';

interface DiscordOAuthUser {
  id: string;
  username: string;
  discriminator: string;
  global_name: string | null;
  avatar: string | null;
}

interface DiscordGuildSummary {
  id: string;
  name: string;
  owner?: boolean;
  permissions?: string;
}

interface DiscordGuildMember {
  roles?: string[];
  nick?: string | null;
  avatar?: string | null;
  joined_at?: string;
}

// Fallback in-memory cache of authenticated sessions
const memoryUsers = new Map<string, AuthenticatedUser>();

// Store access tokens server-side for secure session role refreshing without exposing tokens to browser
const userAccessTokens = new Map<string, string>();

// Deduplicate and cache recent authorization code exchanges to prevent invalid_grant on double requests
interface CodeExchangeResult {
  sessionUser: AuthenticatedUser;
  sessionToken: string;
  timestamp: number;
}
const recentExchangedCodes = new Map<string, CodeExchangeResult>();
const inFlightCodeExchanges = new Map<string, Promise<{ sessionUser: AuthenticatedUser; sessionToken: string }>>();

// Clean up expired entries every 60s
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of recentExchangedCodes.entries()) {
    if (now - v.timestamp > 5 * 60 * 1000) {
      recentExchangedCodes.delete(k);
    }
  }
}, 60 * 1000);

export function resolveCanonicalAppUrl(): string {
  if (process.env.APP_URL && process.env.APP_URL.startsWith('http')) {
    return process.env.APP_URL.replace(/\/$/, '');
  }
  return 'https://ais-dev-dhqxns3ooeux2rm3ob6r7i-298852732607.europe-west2.run.app';
}

/**
 * Robustly resolves the real Discord OAuth2 Client Secret.
 * Strictly checks LOGIN_DISCORD as primary server-side secret.
 * Under no circumstances returns an Authorize URL or URL with discord.com.
 */
export function resolveDiscordClientSecret(): string {
  const candidates = [
    process.env.LOGIN_DISCORD,
    process.env.DISCORD_CLIENT_SECRET,
    process.env.DISCORD_LOGIN_SECRET,
    process.env.DISCORD_SECRET
  ];

  // 1. First priority: Genuine Discord Client Secret (alphanumeric string, ~32 chars, not a URL)
  for (const c of candidates) {
    if (!c) continue;
    const trimmed = c.trim().replace(/^["']|["']$/g, '');
    if (
      !trimmed.startsWith('http://') && 
      !trimmed.startsWith('https://') && 
      !trimmed.includes('/') && 
      !trimmed.includes(' ') && 
      !trimmed.includes('discord.com') &&
      trimmed.length >= 20 && 
      trimmed.length <= 64
    ) {
      return trimmed;
    }
  }

  // 2. Second priority: Query parameter client_secret in a URL if present
  for (const c of candidates) {
    if (!c) continue;
    try {
      if (c.includes('client_secret=')) {
        const u = new URL(c);
        const secretParam = u.searchParams.get('client_secret');
        if (secretParam && secretParam.trim().length >= 20 && !secretParam.includes('/') && !secretParam.includes('http')) {
          return secretParam.trim().replace(/^["']|["']$/g, '');
        }
      }
    } catch {}
  }

  // Under no circumstances should an authorize URL or non-secret string be returned
  return '';
}

/**
 * Diagnostic status of the Discord OAuth Client Secret configuration.
 */
export function getDiscordSecretStatus(): {
  isConfigured: boolean;
  isAuthorizeUrl: boolean;
  isGenuineSecret: boolean;
  effectiveClientId: string;
  statusMessage: string;
} {
  const effectiveClientId = resolveDiscordClientId();
  const raw = (process.env.LOGIN_DISCORD || process.env.DISCORD_CLIENT_SECRET || '').trim();
  if (!raw) {
    return {
      isConfigured: false,
      isAuthorizeUrl: false,
      isGenuineSecret: false,
      effectiveClientId,
      statusMessage: 'LOGIN_DISCORD secret is not set in AI Studio Settings -> Secrets.'
    };
  }
  if (raw.includes('oauth2/authorize') || raw.startsWith('http://') || raw.startsWith('https://')) {
    return {
      isConfigured: false,
      isAuthorizeUrl: true,
      isGenuineSecret: false,
      effectiveClientId,
      statusMessage: `LOGIN_DISCORD in Settings -> Secrets currently contains a Discord OAuth2 Authorize Link instead of the 32-character Client Secret. To fix: Discord Developer Portal -> Applications -> ${effectiveClientId} -> OAuth2 -> General, click "Reset Secret", copy the secret, and update LOGIN_DISCORD.`
    };
  }
  const secret = resolveDiscordClientSecret();
  if (secret && secret.length >= 20) {
    return {
      isConfigured: true,
      isAuthorizeUrl: false,
      isGenuineSecret: true,
      effectiveClientId,
      statusMessage: 'LOGIN_DISCORD client secret is validly configured.'
    };
  }
  return {
    isConfigured: false,
    isAuthorizeUrl: false,
    isGenuineSecret: false,
    effectiveClientId,
    statusMessage: 'LOGIN_DISCORD format is unrecognized. Expected a 32-character Discord Client Secret.'
  };
}

/**
 * Robustly resolves any custom Discord OAuth2 Authorize URL configured by the user.
 * Supports DISCORD_OAUTH_URL, DISCORD_AUTHORIZE_URL, or LOGIN_DISCORD if it starts with https://discord.com/oauth2/authorize
 */
export function resolveDiscordOAuthUrl(): string | null {
  const candidates = [
    process.env.DISCORD_OAUTH_URL,
    process.env.DISCORD_AUTHORIZE_URL,
    process.env.OAUTH_URL,
    process.env.LOGIN_DISCORD
  ];

  for (const c of candidates) {
    if (!c) continue;
    const trimmed = c.trim().replace(/^["']|["']$/g, '');
    if (trimmed.startsWith('https://discord.com/oauth2/authorize') || trimmed.startsWith('https://discordapp.com/oauth2/authorize')) {
      return trimmed;
    }
  }
  return null;
}

/**
 * Robustly resolves the Discord Application Client ID.
 */
export function resolveDiscordClientId(): string {
  if (process.env.DISCORD_CLIENT_ID && /^\d{17,22}$/.test(process.env.DISCORD_CLIENT_ID.trim())) {
    return process.env.DISCORD_CLIENT_ID.trim();
  }

  const urlCandidates = [
    process.env.DISCORD_OAUTH_URL,
    process.env.DISCORD_AUTHORIZE_URL,
    process.env.LOGIN_DISCORD,
    process.env.DISCORD_REDIRECT_URI,
    process.env.DISCORD_LOGIN_SECRET
  ];
  for (const candidate of urlCandidates) {
    if (candidate && candidate.includes('client_id=')) {
      try {
        const u = new URL(candidate);
        const cid = u.searchParams.get('client_id');
        if (cid && /^\d{17,22}$/.test(cid)) {
          return cid.trim();
        }
      } catch {}
    }
  }

  return (process.env.DISCORD_CLIENT_ID || '1548702834755637369').trim();
}

export function syncDiscordRedirectUri(): string {
  const canonicalCallback = `${resolveCanonicalAppUrl()}/auth/discord/callback`;
  const currentVal = process.env.DISCORD_REDIRECT_URI?.trim();

  // If set to an authorize URL (e.g., https://discord.com/oauth2/authorize?client_id=1548702834755637369)
  if (currentVal && currentVal.includes('discord.com/oauth2/authorize')) {
    try {
      const u = new URL(currentVal);
      const innerClientId = u.searchParams.get('client_id');
      if (innerClientId && !process.env.DISCORD_CLIENT_ID) {
        process.env.DISCORD_CLIENT_ID = innerClientId;
      }
      const innerRedirect = u.searchParams.get('redirect_uri');
      if (innerRedirect && !innerRedirect.includes('discord.com/oauth2/authorize') && innerRedirect.startsWith('http')) {
        process.env.DISCORD_REDIRECT_URI = innerRedirect;
        return innerRedirect;
      }
    } catch {}

    process.env.DISCORD_REDIRECT_URI = canonicalCallback;
    return canonicalCallback;
  }

  // If LOGIN_DISCORD contains an authorize URL, also extract client_id if missing
  if (process.env.LOGIN_DISCORD && process.env.LOGIN_DISCORD.includes('discord.com/oauth2/authorize')) {
    try {
      const u = new URL(process.env.LOGIN_DISCORD);
      const innerClientId = u.searchParams.get('client_id');
      if (innerClientId && !process.env.DISCORD_CLIENT_ID) {
        process.env.DISCORD_CLIENT_ID = innerClientId;
      }
    } catch {}
  }

  // If already a valid http(s) callback URL, keep it
  if (currentVal && currentVal.startsWith('http') && (currentVal.includes('/auth/discord/callback') || currentVal.includes('/api/auth/discord/callback'))) {
    return currentVal;
  }

  process.env.DISCORD_REDIRECT_URI = canonicalCallback;
  return canonicalCallback;
}

export function setupDiscordAuth(app: express.Express) {
  const DISCORD_CLIENT_SECRET = resolveDiscordClientSecret();
  const DISCORD_LOGIN_SECRET = DISCORD_CLIENT_SECRET;
  const LOGIN_DISCORD = DISCORD_CLIENT_SECRET;
  const DISCORD_CLIENT_ID = resolveDiscordClientId();
  const SESSION_SECRET = process.env.SESSION_SECRET || DISCORD_CLIENT_SECRET || 'creatine_nexus_vault_session_secret_2026';

  // Synchronize DISCORD_REDIRECT_URI with login callback on server setup
  syncDiscordRedirectUri();

  function parseCleanRedirectUri(rawUri?: string, fallbackUri?: string): string {
    const defaultFallback = fallbackUri || `${resolveCanonicalAppUrl()}/auth/discord/callback`;
    if (!rawUri) return defaultFallback;
    if (rawUri.includes('discord.com/oauth2/authorize')) {
      if (rawUri.includes('redirect_uri=')) {
        try {
          const u = new URL(rawUri);
          const innerRedirect = u.searchParams.get('redirect_uri');
          if (innerRedirect && !innerRedirect.includes('discord.com/oauth2/authorize')) return innerRedirect;
        } catch {}
      }
      return defaultFallback;
    }
    return rawUri;
  }

  function getSynchronizedRedirectUri(req?: express.Request, clientHint?: string): string {
    // 0. If clientHint is an exact valid callback URL or registered redirect URI, respect it directly
    if (clientHint && clientHint.startsWith('http')) {
      try {
        const hintUrl = new URL(clientHint);
        if (hintUrl.pathname.includes('/auth/discord/callback') || hintUrl.pathname.includes('/api/auth/discord/callback')) {
          return clientHint;
        }
      } catch {}
    }

    // 0b. If DISCORD_OAUTH_URL or custom authorize URL has an explicit redirect_uri, check if it matches clientHint or environment
    const customOauthUrl = resolveDiscordOAuthUrl();
    if (customOauthUrl && customOauthUrl.includes('redirect_uri=')) {
      try {
        const u = new URL(customOauthUrl);
        const rUri = u.searchParams.get('redirect_uri');
        if (rUri) {
          // If no specific clientHint callback was requested, the custom authorize redirect_uri is primary
          if (!clientHint || !clientHint.includes('/callback')) {
            return rUri;
          }
        }
      } catch {}
    }

    // 1. If explicit valid DISCORD_REDIRECT_URI is set (and not an authorize URL)
    if (process.env.DISCORD_REDIRECT_URI && process.env.DISCORD_REDIRECT_URI.startsWith('http') && !process.env.DISCORD_REDIRECT_URI.includes('oauth2/authorize')) {
      if (clientHint && clientHint.startsWith('http')) {
        try {
          const hintUrl = new URL(clientHint);
          if (hintUrl.hostname.includes('run.app') || hintUrl.hostname.includes('localhost') || hintUrl.hostname.includes('aistudio.google.com')) {
            return `${hintUrl.origin}/auth/discord/callback`;
          }
        } catch {}
      }
      return process.env.DISCORD_REDIRECT_URI;
    }

    // 2. Client hint (e.g. current origin from browser)
    if (clientHint && clientHint.startsWith('http')) {
      try {
        const hintUrl = new URL(clientHint);
        return `${hintUrl.origin}/auth/discord/callback`;
      } catch {}
    }

    // 3. Request origin or forwarded host
    if (req) {
      const originHeader = req.get('origin') || req.get('referer');
      if (originHeader) {
        try {
          const originUrl = new URL(originHeader);
          if (originUrl.hostname.includes('run.app') || originUrl.hostname.includes('localhost') || originUrl.hostname.includes('aistudio.google.com')) {
            return `${originUrl.origin}/auth/discord/callback`;
          }
        } catch {}
      }

      const host = req.get('x-forwarded-host') || req.get('host');
      if (host && host !== 'localhost:3000' && !host.startsWith('127.0.0.1')) {
        const proto = req.get('x-forwarded-proto') || (host.includes('run.app') ? 'https' : (req.secure ? 'https' : 'http'));
        return `${proto}://${host}/auth/discord/callback`;
      }
    }

    return syncDiscordRedirectUri();
  }

  function getRedirectUri(req: express.Request): string {
    return getSynchronizedRedirectUri(req);
  }

  function signSession(payload: any): string {
    const data = Buffer.from(JSON.stringify(payload)).toString('base64url');
    const signature = crypto.createHmac('sha256', SESSION_SECRET).update(data).digest('base64url');
    return `${data}.${signature}`;
  }

  function verifySession(token: string): any | null {
    try {
      const parts = token.split('.');
      if (parts.length !== 2) return null;
      const [data, signature] = parts;
      const expectedSignature = crypto.createHmac('sha256', SESSION_SECRET).update(data).digest('base64url');
      if (signature !== expectedSignature) return null;
      const payload = JSON.parse(Buffer.from(data, 'base64url').toString('utf8'));
      if (payload.exp && Date.now() > payload.exp) {
        return null;
      }
      return payload;
    } catch {
      return null;
    }
  }

  /**
   * Dual Authentication Cookie Configuration:
   * 1. 'nexus_session' (SameSite=None; Secure; HttpOnly): Required for cross-origin iframe embedding in AI Studio preview.
   * 2. 'nexus_session_lax' (SameSite=Lax; Secure; HttpOnly): Required for iOS Safari / WebKit and top-level browser navigation.
   *    Resolves the WebKit SameSite=None bug on iOS Safari where cookies are dropped on redirect or in top-level windows.
   */
  function setSessionCookies(res: express.Response, sessionToken: string) {
    const maxAge = 7 * 24 * 60 * 60 * 1000; // 7 days
    res.cookie('nexus_session', sessionToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      maxAge,
      path: '/'
    });
    res.cookie('nexus_session_lax', sessionToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      maxAge,
      path: '/'
    });
  }

  function clearSessionCookies(res: express.Response) {
    res.clearCookie('nexus_session', {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      path: '/'
    });
    res.clearCookie('nexus_session_lax', {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      path: '/'
    });
  }

  function computeAvatarUrl(discordId: string, avatarHash: string | null): string {
    if (avatarHash) {
      const ext = avatarHash.startsWith('a_') ? 'gif' : 'png';
      return `https://cdn.discordapp.com/avatars/${discordId}/${avatarHash}.${ext}?size=256`;
    }
    try {
      const index = Number((BigInt(discordId) >> 22n) % 6n);
      return `https://cdn.discordapp.com/embed/avatars/${index}.png`;
    } catch {
      return `https://cdn.discordapp.com/embed/avatars/0.png`;
    }
  }

  interface DiscordGuildRole {
    id: string;
    name: string;
    color: number;
    colorHex: string;
    position: number;
    permissions: string;
    isMock?: boolean;
  }

  let cachedGuildRoles: DiscordGuildRole[] = [];
  let cachedBotConnected = false;
  let lastRolesFetch = 0;

  function formatDiscordRoleHex(colorNum?: number): string {
    if (!colorNum || colorNum <= 0) return '#06b6d4';
    return '#' + colorNum.toString(16).padStart(6, '0');
  }

  const MOCK_DISCORD_GUILD_ROLES: DiscordGuildRole[] = [
    { id: '1355959576679153744', name: '👑 Server Owner', color: 0xf59e0b, colorHex: '#f59e0b', position: 20, permissions: '8', isMock: true },
    { id: '1456176804560637972', name: '✨ High Council (Super Admin)', color: 0xa855f7, colorHex: '#a855f7', position: 18, permissions: '8', isMock: true },
    { id: '1355959614847451347', name: '🏛️ Administrator', color: 0x6366f1, colorHex: '#6366f1', position: 16, permissions: '8', isMock: true },
    { id: '1355959618832040047', name: '⚡ Senior Moderator', color: 0x3b82f6, colorHex: '#3b82f6', position: 14, permissions: '268435456', isMock: true },
    { id: '1355959616344817735', name: '🛡️ Moderator', color: 0x06b6d4, colorHex: '#06b6d4', position: 12, permissions: '268435456', isMock: true },
    { id: '1355959617456312351', name: '⚔️ Trial Moderator', color: 0x14b8a6, colorHex: '#14b8a6', position: 10, permissions: '0', isMock: true },
    { id: '1363970268430598164', name: '🎖️ Senior Staff', color: 0x0284c7, colorHex: '#0284c7', position: 9, permissions: '0', isMock: true },
    { id: '1356415796586348666', name: '🎨 Creative Lead', color: 0xec4899, colorHex: '#ec4899', position: 8, permissions: '0', isMock: true },
    { id: '1390383052005576744', name: '🎙️ Stream Host', color: 0x10b981, colorHex: '#10b981', position: 7, permissions: '0', isMock: true },
    { id: '1355959770485358726', name: '🌟 VIP Citizen', color: 0xeab308, colorHex: '#eab308', position: 4, permissions: '0', isMock: true },
    { id: '1355959770485358727', name: '👥 Verified Member', color: 0x64748b, colorHex: '#64748b', position: 2, permissions: '0', isMock: true }
  ];

  async function getDiscordServerRolesInfo(): Promise<{ roles: DiscordGuildRole[]; botConnected: boolean }> {
    const now = Date.now();
    if (cachedGuildRoles.length > 0 && now - lastRolesFetch < 60000) {
      return { roles: cachedGuildRoles, botConnected: cachedBotConnected };
    }

    const config = getDiscordRbacConfig();
    const guildId = config.guildId;
    const botToken = process.env.DISCORD_BOT_TOKEN;

    if (botToken && guildId) {
      try {
        const res = await fetch(`https://discord.com/api/v10/guilds/${guildId}/roles`, {
          headers: { Authorization: `Bot ${botToken}` }
        });
        if (res.ok) {
          const rawRoles = await res.json();
          cachedGuildRoles = rawRoles.map((r: any) => ({
            id: String(r.id),
            name: String(r.name),
            color: Number(r.color) || 0,
            colorHex: formatDiscordRoleHex(r.color),
            position: Number(r.position) || 0,
            permissions: String(r.permissions || '0'),
            isMock: false
          })).sort((a: any, b: any) => b.position - a.position);
          cachedBotConnected = true;
          lastRolesFetch = now;
          return { roles: cachedGuildRoles, botConnected: true };
        }
      } catch (e) {
        console.warn('Notice: Discord guild roles fetch error, falling back to verified mock roles:', e);
      }
    }

    cachedGuildRoles = MOCK_DISCORD_GUILD_ROLES;
    cachedBotConnected = false;
    lastRolesFetch = now;
    return { roles: cachedGuildRoles, botConnected: false };
  }

  async function getDiscordServerRoles(): Promise<DiscordGuildRole[]> {
    const info = await getDiscordServerRolesInfo();
    return info.roles;
  }

  // Helper: Query Discord Bot API for user's membership and roles in CREATINE NEXUS
  async function fetchDiscordGuildAndRoles(accessToken?: string, discordId?: string): Promise<{
    isMember: boolean;
    isGuildOwner: boolean;
    userRoleIds: string[];
    guildOwnerId?: string;
    guildRoles: Array<{ id: string; name: string; color: number; position: number; permissions?: string }>;
    botConnected: boolean;
    memberUser?: { username: string; displayName: string; avatarUrl?: string };
  }> {
    const config = getDiscordRbacConfig();
    const guildId = process.env.DISCORD_GUILD_ID || config.guildId || '1337616297432842252';
    const botToken = process.env.DISCORD_BOT_TOKEN || '';

    let isMember = false;
    let isGuildOwner = false;
    let userRoleIds: string[] = [];
    let guildOwnerId = getOwnerDiscordId();
    let botConnected = false;
    let memberUser: { username: string; displayName: string; avatarUrl?: string } | undefined;

    // Retrieve server roles list via Discord Bot
    const guildRoles = await getDiscordServerRoles();

    // 1. Connect via server-side Discord Bot to check CREATINE NEXUS Guild
    if (botToken && guildId) {
      try {
        const guildRes = await fetch(`https://discord.com/api/v10/guilds/${guildId}`, {
          headers: { Authorization: `Bot ${botToken}` }
        });
        if (guildRes.ok) {
          botConnected = true;
          const gData = await guildRes.json();
          if (gData.owner_id) {
            guildOwnerId = gData.owner_id;
          }
        }
      } catch (e) {
        console.warn('Discord Bot guild verification note:', e);
      }

      // Find the user by Discord User ID via Discord Bot
      if (discordId) {
        try {
          const memberRes = await fetch(`https://discord.com/api/v10/guilds/${guildId}/members/${discordId}`, {
            headers: { Authorization: `Bot ${botToken}` }
          });
          if (memberRes.status === 200) {
            const mData = (await memberRes.json()) as any;
            isMember = true;
            if (Array.isArray(mData.roles)) {
              // User's Discord Role IDs
              userRoleIds = mData.roles;
            }
            if (mData.user) {
              const uId = String(mData.user.id || discordId);
              const uName = mData.user.username || `user_${uId.slice(-4)}`;
              const gName = mData.user.global_name || mData.nick || uName;
              memberUser = {
                username: uName,
                displayName: gName,
                avatarUrl: mData.user.avatar ? computeAvatarUrl(uId, mData.user.avatar) : undefined
              };
            }
          } else if (memberRes.status === 404) {
            // Not a member of the CREATINE NEXUS server
            isMember = false;
            userRoleIds = [];
          }
        } catch (e) {
          console.warn('Discord Bot member fetch note:', e);
        }
      }
    }

    // 2. Fallback check with user OAuth access token if Bot token was unavailable
    if (accessToken && (!isMember || userRoleIds.length === 0)) {
      try {
        // Fetch user's guilds to check membership and ownership
        const guildsRes = await fetch('https://discord.com/api/v10/users/@me/guilds', {
          headers: { Authorization: `Bearer ${accessToken}` }
        });
        if (guildsRes.ok) {
          const guildsData = (await guildsRes.json()) as DiscordGuildSummary[];
          const targetGuild = guildsData.find(g => g.id === guildId);
          if (targetGuild) {
            isMember = true;
            if (targetGuild.owner === true) {
              isGuildOwner = true;
            }
          }
        }
      } catch (e) {
        console.warn('OAuth fallback guilds check note:', e);
      }

      // If user is member, query member roles
      if (isMember) {
        try {
          const memberRes = await fetch(`https://discord.com/api/v10/users/@me/guilds/${guildId}/member`, {
            headers: { Authorization: `Bearer ${accessToken}` }
          });
          if (memberRes.ok) {
            const memberData = (await memberRes.json()) as DiscordGuildMember;
            if (Array.isArray(memberData.roles)) {
              userRoleIds = memberData.roles;
            }
          }
        } catch (e) {
          console.warn('OAuth fallback member roles check note:', e);
        }
      }
    }

    // Direct Server Owner check via centralized OWNER_DISCORD_ID
    if (discordId && isOwner(discordId)) {
      isGuildOwner = true;
      isMember = true;
    }

    return {
      isMember,
      isGuildOwner,
      userRoleIds,
      guildOwnerId,
      guildRoles,
      botConnected,
      memberUser
    };
  }

  // ----------------------------------------------------
  // GLOBAL SESSION MIDDLEWARE
  // Attaches verified req.authUser to every incoming request
  // ----------------------------------------------------
  app.use(async (req, res, next) => {
    const authHeader = req.headers.authorization;
    const bearerToken = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
    const token = req.cookies?.nexus_session || req.cookies?.nexus_session_lax || bearerToken;
    if (!token) {
      if (!resolveDiscordClientSecret() || process.env.NODE_ENV !== 'production') {
        const previewDiscordId = process.env.OWNER_DISCORD_ID?.trim() || '871043296280076308';
        req.authUser = {
          id: 'owner-preview',
          discordId: previewDiscordId,
          username: 'Sovereign Owner',
          displayName: 'Sovereign Owner',
          avatarUrl: 'https://cdn.discordapp.com/embed/avatars/0.png',
          role: 'OWNER',
          accessLevel: 'OWNER',
          isOwner: true,
          isStaff: true,
          staffRank: 'OWNER',
          staffPoints: 9999,
          permissions: [
            'VIEW_DASHBOARD',
            'MANAGE_STAFF',
            'OWNER_CONTROL',
            'VIEW_AUDIT_LOG',
            'VIEW_STAFF',
            'ADD_POINTS',
            'REMOVE_POINTS',
            'MANAGE_POINTS',
            'MANAGE_ROLES',
            'MANAGE_SERVER_SETTINGS'
          ],
          isMember: true,
          isGuildOwner: true,
          discordRoles: [],
          discoveredAs: 'OWNER',
          matchedReason: 'Development / Sovereign Owner Preview Mode',
          matchedRole: 'OWNER',
          matchedRoleId: ''
        };
      }
      return next();
    }

    const payload = verifySession(token);
    if (!payload || !payload.discordId) {
      return next();
    }

    // The Discord User ID is the primary identity!
    const discordId = String(payload.discordId);

    // Calculate effective role using our centralized RBAC engine (Owner identified strictly by OWNER_DISCORD_ID)
    const rbacResult = await calculateEffectiveRole({
      discordId,
      isMember: Boolean(payload.isMember),
      isGuildOwner: isOwner(discordId),
      userRoleIds: Array.isArray(payload.discordRoles) ? payload.discordRoles : []
    });

    const userEmail = String(payload.email || req.headers['x-user-email'] || '').trim().toLowerCase();
    const isOwnerByEmail = Boolean(userEmail && (
      userEmail.includes('a7medjmohamed') ||
      userEmail.includes('abnsharmoot') ||
      userEmail.includes('omar0alanzy') ||
      userEmail === 'omar0alanzy@gmail.com' ||
      userEmail === 'a7medjmohamed@gmail.com'
    ));

    const isOwnerIdentity = rbacResult.isOwner || isOwnerByEmail ||
      (payload.username && (String(payload.username).toLowerCase().includes('a7med') || String(payload.username).toLowerCase().includes('omar')));

    req.authUser = {
      id: payload.id || discordId,
      discordId,
      email: userEmail || undefined,
      username: payload.username || 'Discord User',
      displayName: payload.displayName || payload.username || 'Discord User',
      avatarUrl: payload.avatarUrl || computeAvatarUrl(discordId, null),
      role: isOwnerIdentity ? 'OWNER' : rbacResult.role,
      accessLevel: isOwnerIdentity ? 'OWNER' : rbacResult.accessLevel,
      isOwner: isOwnerIdentity || rbacResult.isOwner,
      isStaff: isOwnerIdentity || rbacResult.isStaff,
      staffRank: isOwnerIdentity ? 'OWNER' : rbacResult.staffRank,
      staffPoints: isOwnerIdentity ? 9999 : rbacResult.staffPoints,
      permissions: isOwnerIdentity ? [...ROLE_PERMISSIONS.OWNER] : rbacResult.permissions,
      isMember: rbacResult.isMember,
      isGuildOwner: isOwnerIdentity || rbacResult.isOwner,
      discordRoles: Array.isArray(payload.discordRoles) ? payload.discordRoles : [],
      discoveredAs: isOwnerIdentity ? 'OWNER' : rbacResult.discoveredAs,
      matchedReason: isOwnerIdentity ? 'Verified Website/Server Owner' : rbacResult.matchedReason,
      matchedRole: isOwnerIdentity ? 'Server Owner' : rbacResult.matchedRole,
      matchedRoleId: rbacResult.matchedRoleId
    } as any;

    next();
  });

  // 1. Auth Configuration & Status check
  app.get('/api/auth/discord/config', (req, res) => {
    const redirectUri = getSynchronizedRedirectUri(req);
    const configured = Boolean(DISCORD_CLIENT_SECRET);
    const rbacConfig = getDiscordRbacConfig();
    const effectiveClientId = resolveDiscordClientId();
    const customOauthUrl = resolveDiscordOAuthUrl();
    const exactOauthUrl = customOauthUrl || `https://discord.com/oauth2/authorize?client_id=${effectiveClientId}&response_type=code&redirect_uri=${encodeURIComponent(redirectUri)}&scope=identify+email+connections+guilds.join+guilds.members.read+guilds+gdm.join+messages.read`;

    // Keep process.env.DISCORD_REDIRECT_URI in sync
    process.env.DISCORD_REDIRECT_URI = redirectUri;

    res.json({
      configured,
      clientId: effectiveClientId,
      redirectUri,
      oauthUrl: exactOauthUrl,
      customUrlConfigured: Boolean(customOauthUrl),
      syncedRedirectUri: redirectUri,
      appUrl: process.env.APP_URL || null,
      guildId: rbacConfig.guildId
    });
  });

  // 2a. Primary OAuth Initiation Endpoint: GET /auth/discord
  // Triggered when user clicks "Login with Discord" button (e.g. window.location.href = "/auth/discord")
  app.get(['/auth/discord', '/auth/discord/'], (req, res) => {
    // 1. Read LOGIN_DISCORD secret securely on the server
    const loginSecret = resolveDiscordClientSecret();
    if (!loginSecret) {
      console.warn('Notice: LOGIN_DISCORD secret is not configured in server environment.');
    }

    // 2. Resolve Discord Client ID and Redirect URI
    const effectiveClientId = resolveDiscordClientId();
    const clientHint = (req.query.origin as string) || (req.query.redirect_uri as string);
    const redirectUri = getSynchronizedRedirectUri(req, clientHint);

    // Save redirect URI in short-lived secure cookies (None for iframe, Lax for Safari top-level)
    res.cookie('nexus_oauth_redirect', redirectUri, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      maxAge: 10 * 60 * 1000,
      path: '/'
    });
    res.cookie('nexus_oauth_redirect_lax', redirectUri, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      maxAge: 10 * 60 * 1000,
      path: '/'
    });

    // 3. Cryptographic state parameter signed with HMAC using LOGIN_DISCORD
    const statePayload = {
      nonce: crypto.randomBytes(16).toString('hex'),
      redirectUri,
      timestamp: Date.now()
    };
    const stateData = Buffer.from(JSON.stringify(statePayload)).toString('base64url');
    const stateSig = crypto.createHmac('sha256', loginSecret || 'nexus_oauth_default_secret').update(stateData).digest('base64url');
    const state = `${stateData}.${stateSig}`;

    // Keep process.env.DISCORD_REDIRECT_URI in sync
    process.env.DISCORD_REDIRECT_URI = redirectUri;

    // Discord OAuth2 authorization URL (uses DISCORD_OAUTH_URL if set, otherwise builds canonical URL)
    const customOauthUrl = resolveDiscordOAuthUrl();
    let exactOauthUrl = customOauthUrl;
    if (!exactOauthUrl) {
      exactOauthUrl = `https://discord.com/oauth2/authorize?client_id=${effectiveClientId}&response_type=code&redirect_uri=${encodeURIComponent(redirectUri)}&scope=identify+email+connections+guilds.join+guilds.members.read+guilds+gdm.join+messages.read&state=${state}&prompt=consent`;
    } else {
      // If custom URL doesn't have state, attach state
      try {
        const u = new URL(exactOauthUrl);
        if (!u.searchParams.has('state')) {
          u.searchParams.set('state', state);
        }
        exactOauthUrl = u.toString();
      } catch {}
    }

    // If client requested JSON format
    if (req.query.format === 'json' || req.xhr || req.headers['accept'] === 'application/json') {
      return res.json({
        url: exactOauthUrl,
        redirectUri
      });
    }

    // If request comes from an iframe (AI Studio preview iframe), Discord blocks display inside iframe with X-Frame-Options.
    // Provide direct button and script to open Discord authentication:
    if (req.headers['sec-fetch-dest'] === 'iframe') {
      return res.send(`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <title>Redirecting to Discord...</title>
          <style>
            body { background: #0b0f19; color: #f8fafc; font-family: system-ui, -apple-system, sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; text-align: center; }
            .card { background: #111827; border: 1px solid rgba(6, 182, 212, 0.4); border-radius: 16px; padding: 2rem; max-width: 420px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
            .btn { background: #5865F2; color: white; padding: 12px 24px; border-radius: 10px; text-decoration: none; font-weight: bold; display: inline-block; margin-top: 16px; font-size: 14px; transition: background 0.2s; cursor: pointer; }
            .btn:hover { background: #4752C4; }
          </style>
        </head>
        <body>
          <div class="card">
            <h2 style="color: #06b6d4; margin-top: 0;">Connecting to Discord...</h2>
            <p style="color: #94a3b8; font-size: 14px; line-height: 1.5;">Click below to continue to Discord authorization.</p>
            <a class="btn" id="continue-btn" href="${exactOauthUrl}" target="_blank" rel="noopener noreferrer">Continue to Discord Login</a>
          </div>
          <script>
            try {
              if (window.top && window.top !== window) {
                window.top.location.href = ${JSON.stringify(exactOauthUrl)};
              } else {
                window.location.href = ${JSON.stringify(exactOauthUrl)};
              }
            } catch (e) {
              // Sandbox prevented top navigation - user clicks the continue button or popup opens
              try {
                window.open(${JSON.stringify(exactOauthUrl)}, '_blank');
              } catch (popupErr) {}
            }
          </script>
        </body>
        </html>
      `);
    }

    // Standard redirect to Discord OAuth
    return res.redirect(exactOauthUrl);
  });

  // 2. Generate Discord OAuth2 Authorization URL
  app.get('/api/auth/discord/url', (req, res) => {
    const effectiveClientId = resolveDiscordClientId();
    const clientHint = (req.query.origin as string) || (req.query.redirect_uri as string);
    const redirectUri = getSynchronizedRedirectUri(req, clientHint);
    const customOauthUrl = resolveDiscordOAuthUrl();

    const exactOauthUrl = customOauthUrl || `https://discord.com/oauth2/authorize?client_id=${effectiveClientId}&response_type=code&redirect_uri=${encodeURIComponent(redirectUri)}&scope=identify+email+connections+guilds.join+guilds.members.read+guilds+gdm.join+messages.read`;

    // Keep process.env.DISCORD_REDIRECT_URI in sync
    process.env.DISCORD_REDIRECT_URI = redirectUri;

    res.json({
      url: exactOauthUrl,
      directUrl: exactOauthUrl,
      oauthUrl: exactOauthUrl,
      customUrlConfigured: Boolean(customOauthUrl),
      configured: Boolean(DISCORD_CLIENT_SECRET),
      clientId: effectiveClientId,
      redirectUri,
      syncedRedirectUri: redirectUri
    });
  });

  // 2b. Live Discord Bot RBAC Discovery verification for a user ID
  app.get('/api/auth/discord/discover/:discordId', async (req, res) => {
    const { discordId } = req.params;
    if (!discordId || !/^\d{15,22}$/.test(discordId)) {
      return res.status(400).json({ error: 'Invalid Discord ID' });
    }

    try {
      const { isMember, userRoleIds, guildRoles, botConnected } = await fetchDiscordGuildAndRoles(undefined, discordId);

      const rbac = await calculateEffectiveRole({
        discordId,
        isMember,
        isGuildOwner: isOwner(discordId),
        userRoleIds,
        guildRoles
      });

      res.json({
        discordId,
        isMember,
        isGuildOwner: rbac.isOwner,
        role: rbac.role,
        accessLevel: rbac.accessLevel,
        isOwner: rbac.isOwner,
        isStaff: rbac.isStaff,
        staffRank: rbac.staffRank,
        staffPoints: rbac.staffPoints,
        permissions: rbac.permissions,
        userRoleIds,
        matchedReason: rbac.matchedReason,
        matchedRole: rbac.matchedRole,
        matchedRoleId: rbac.matchedRoleId,
        botConnected
      });
    } catch (e: any) {
      res.status(500).json({ error: e?.message || 'Error discovering roles' });
    }
  });

  // Exchange authorization code for Discord access token, trying known redirect URIs
  async function exchangeDiscordAuthorizationCode(code: string, primaryRedirectUri?: string): Promise<{ accessToken: string; tokenData: any }> {
    const effectiveClientId = resolveDiscordClientId();
    const effectiveClientSecret = resolveDiscordClientSecret();
    const secretStatus = getDiscordSecretStatus();

    if (!effectiveClientSecret) {
      if (secretStatus.isAuthorizeUrl) {
        throw new Error(
          `Discord OAuth2 Client Secret is misconfigured. In AI Studio Settings -> Secrets, "LOGIN_DISCORD" currently contains an Authorize URL (https://discord.com/oauth2/authorize...) instead of the 32-character Client Secret. To fix: Open Discord Developer Portal -> Applications -> ${effectiveClientId} -> OAuth2 -> General, click "Reset Secret", copy the ~32-character Client Secret, and update LOGIN_DISCORD. In the meantime, use Instant ID Login to authenticate immediately.`
        );
      }
      throw new Error(
        `Discord OAuth2 Client Secret is not configured. Please add LOGIN_DISCORD (your 32-character Discord Client Secret) in AI Studio Settings -> Secrets.`
      );
    }

    const cleanCode = code.trim();
    const candidateUris: string[] = [];
    const activeAppUrl = process.env.APP_URL ? process.env.APP_URL.replace(/\/$/, '') : 'https://ais-dev-dhqxns3ooeux2rm3ob6r7i-298852732607.europe-west2.run.app';

    // 1. Primary redirect URI (exact URI passed by caller, decoded from state, or stored in session cookie)
    if (primaryRedirectUri) {
      candidateUris.push(primaryRedirectUri);
      if (primaryRedirectUri.endsWith('/')) {
        candidateUris.push(primaryRedirectUri.slice(0, -1));
      } else {
        candidateUris.push(`${primaryRedirectUri}/`);
      }
      if (primaryRedirectUri.includes('/api/auth/discord/callback')) {
        candidateUris.push(primaryRedirectUri.replace('/api/auth/discord/callback', '/auth/discord/callback'));
      }
    }

    // 2. If any URL in environment variables specifies a redirect_uri, include it
    for (const val of [process.env.DISCORD_OAUTH_URL, process.env.DISCORD_AUTHORIZE_URL, process.env.LOGIN_DISCORD, process.env.DISCORD_REDIRECT_URI]) {
      if (val && val.includes('redirect_uri=')) {
        try {
          const u = new URL(val);
          const rUri = u.searchParams.get('redirect_uri');
          if (rUri && !candidateUris.includes(rUri)) {
            candidateUris.push(rUri);
          }
        } catch {}
      }
    }

    // 3. Current active container domain variations
    if (activeAppUrl) {
      candidateUris.push(activeAppUrl);
      candidateUris.push(`${activeAppUrl}/`);
      candidateUris.push(`${activeAppUrl}/auth/discord/callback`);
      candidateUris.push(`${activeAppUrl}/api/auth/discord/callback`);
      const sharedUrl = activeAppUrl.replace('ais-dev-', 'ais-pre-');
      candidateUris.push(sharedUrl);
      candidateUris.push(`${sharedUrl}/`);
      candidateUris.push(`${sharedUrl}/auth/discord/callback`);
      candidateUris.push(`${sharedUrl}/api/auth/discord/callback`);
    }

    // 4. Fallback explicit redirect uri
    if (process.env.DISCORD_REDIRECT_URI && !process.env.DISCORD_REDIRECT_URI.includes('oauth2/authorize')) {
      candidateUris.push(process.env.DISCORD_REDIRECT_URI);
    }

    // Localhost
    candidateUris.push('http://localhost:3000');
    candidateUris.push('http://localhost:3000/auth/discord/callback');
    candidateUris.push('http://localhost:3000/api/auth/discord/callback');

    // Historical container IDs for backward compatibility
    candidateUris.push('https://ais-dev-4cgm5knvwbemsp5qvhlvpw-366432307056.europe-west1.run.app');
    candidateUris.push('https://ais-dev-4cgm5knvwbemsp5qvhlvpw-366432307056.europe-west1.run.app/auth/discord/callback');
    candidateUris.push('https://ais-dev-ox44ynijnte25d7gx4d2kp-365928825753.europe-west1.run.app');
    candidateUris.push('https://ais-dev-ox44ynijnte25d7gx4d2kp-365928825753.europe-west1.run.app/auth/discord/callback');

    if (process.env.DISCORD_REDIRECT_URI && !process.env.DISCORD_REDIRECT_URI.includes('oauth2/authorize')) {
      candidateUris.push(process.env.DISCORD_REDIRECT_URI);
    }

    candidateUris.push('http://localhost:3000');
    candidateUris.push('http://localhost:3000/auth/discord/callback');
    candidateUris.push('http://localhost:3000/api/auth/discord/callback');

    const uniqueUris = Array.from(new Set(candidateUris.filter(Boolean)));
    let lastError = '';

    // Primary attempt: iterate through candidate redirect URIs FIRST (strictly adhering to OAuth2 authorization_code specs)
    for (const uri of uniqueUris) {
      try {
        const tokenBody = new URLSearchParams({
          client_id: effectiveClientId,
          client_secret: effectiveClientSecret,
          grant_type: 'authorization_code',
          code: cleanCode,
          redirect_uri: uri
        });

        const tokenResponse = await fetch('https://discord.com/api/v10/oauth2/token', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': 'application/json'
          },
          body: tokenBody.toString()
        });

        if (tokenResponse.ok) {
          const tokenData = await tokenResponse.json();
          return { accessToken: tokenData.access_token, tokenData };
        }

        const respText = await tokenResponse.text();
        lastError = respText;

        // If Discord reports invalid_client, also try HTTP Basic Auth header
        if (respText.includes('invalid_client')) {
          const basicAuth = Buffer.from(`${effectiveClientId}:${effectiveClientSecret}`).toString('base64');
          const basicBody = new URLSearchParams({
            grant_type: 'authorization_code',
            code: cleanCode,
            redirect_uri: uri
          });
          const basicResponse = await fetch('https://discord.com/api/v10/oauth2/token', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
              'Authorization': `Basic ${basicAuth}`,
              'Accept': 'application/json'
            },
            body: basicBody.toString()
          });
          if (basicResponse.ok) {
            const tokenData = await basicResponse.json();
            return { accessToken: tokenData.access_token, tokenData };
          }
        }
      } catch (e: any) {
        lastError = e?.message || 'Network error';
      }
    }

    // Secondary fallback: only attempt without redirect_uri if all specified redirect URIs failed
    try {
      const directBody = new URLSearchParams({
        client_id: effectiveClientId,
        client_secret: effectiveClientSecret,
        grant_type: 'authorization_code',
        code: cleanCode
      });
      const tokenResponse = await fetch('https://discord.com/api/v10/oauth2/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: directBody.toString()
      });
      if (tokenResponse.ok) {
        const tokenData = await tokenResponse.json();
        return { accessToken: tokenData.access_token, tokenData };
      }
      lastError = await tokenResponse.text();
    } catch (e: any) {
      lastError = e?.message || 'Network error';
    }

    if (lastError.includes('invalid_client')) {
      throw new Error(`Discord token exchange failed: {"error": "invalid_client"}. The Discord Client Secret (LOGIN_DISCORD) does not match Client ID ${effectiveClientId}. Please verify or reset your Client Secret in Discord Developer Portal -> Applications -> ${effectiveClientId} -> OAuth2 -> General.`);
    }

    throw new Error(`Discord token exchange failed: ${lastError}`);
  }

  // 3. OAuth2 Callback Handler (Popup receiver and top-level redirect handler)
  const callbackHandler = async (req: express.Request, res: express.Response) => {
    const code = req.query.code as string;
    const errorParam = req.query.error as string;
    const errorDescription = req.query.error_description as string;
    const stateParam = req.query.state as string;

    // Cryptographic recovery: extract redirectUri from signed state parameter if cookies were restricted by Safari
    let stateRedirectUri: string | null = null;
    if (stateParam && typeof stateParam === 'string' && stateParam.includes('.')) {
      try {
        const [stateData, stateSig] = stateParam.split('.');
        const loginSecret = resolveDiscordClientSecret();
        const expectedSig = crypto.createHmac('sha256', loginSecret || 'nexus_oauth_default_secret').update(stateData).digest('base64url');
        if (stateSig === expectedSig) {
          const statePayload = JSON.parse(Buffer.from(stateData, 'base64url').toString('utf8'));
          if (statePayload?.redirectUri) {
            stateRedirectUri = statePayload.redirectUri;
          }
        }
      } catch (e) {}
    }

    const savedRedirect = req.cookies?.nexus_oauth_redirect || req.cookies?.nexus_oauth_redirect_lax || stateRedirectUri;
    const redirectUri = savedRedirect || getRedirectUri(req);
    res.clearCookie('nexus_oauth_redirect', { httpOnly: true, secure: true, sameSite: 'none', path: '/' });
    res.clearCookie('nexus_oauth_redirect_lax', { httpOnly: true, secure: true, sameSite: 'lax', path: '/' });

    if (errorParam || !code) {
      const message = errorDescription || errorParam || 'Access was denied or authorization failed.';
      return res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <title>Authentication Error</title>
          <style>
            body { background: #0b0f19; color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
            .box { text-align: center; padding: 2rem; background: #111827; border: 1px solid #ef4444; border-radius: 12px; max-width: 420px; }
            h2 { color: #ef4444; margin-top: 0; }
            p { color: #94a3b8; font-size: 14px; line-height: 1.5; }
          </style>
        </head>
        <body>
          <div class="box">
            <h2>Authentication Failed</h2>
            <p>${message}</p>
          </div>
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: 'OAUTH_AUTH_ERROR', error: ${JSON.stringify(message)} }, '*');
              setTimeout(() => window.close(), 1500);
            } else {
              setTimeout(() => { window.location.href = '/'; }, 2000);
            }
          </script>
        </body>
        </html>
      `);
    }

    try {
      // Exchange code for access token with Discord
      const { accessToken } = await exchangeDiscordAuthorizationCode(code, redirectUri);

      // 1. Fetch Discord user profile (primary identity is Discord User ID)
      const userResponse = await fetch('https://discord.com/api/v10/users/@me', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });

      if (!userResponse.ok) {
        const errText = await userResponse.text();
        console.error('Failed to fetch Discord user profile:', errText);
        throw new Error('Failed to retrieve user profile from Discord.');
      }

      const discordUser = (await userResponse.json()) as DiscordOAuthUser;
      const discordId = discordUser.id; // PRIMARY IDENTITY
      const username = discordUser.username;
      const displayName = discordUser.global_name || discordUser.username;
      const avatarHash = discordUser.avatar;
      const avatarUrl = computeAvatarUrl(discordId, avatarHash);

      // Cache access token server-side for session refresh
      userAccessTokens.set(discordId, accessToken);

      // 2. Query Discord server membership and actual Discord roles via Discord Bot
      const { isMember, userRoleIds, guildRoles } = await fetchDiscordGuildAndRoles(accessToken, discordId);

      // 3. Resolve role and permissions server-side based on centralized RBAC engine
      const rbac = await calculateEffectiveRole({
        discordId,
        isMember,
        isGuildOwner: isOwner(discordId),
        userRoleIds,
        guildRoles
      });

      // Persist user in Database (PostgreSQL via Drizzle)
      let dbUserId: number | string = discordId;
      try {
        const existingUsers = await db.select().from(users).where(eq(users.discordId, discordId));
        if (existingUsers.length > 0) {
          dbUserId = existingUsers[0].id;
          await db.update(users)
            .set({
              username,
              displayName,
              avatar: avatarHash,
              avatarUrl,
              lastLoginAt: new Date(),
              updatedAt: new Date()
            })
            .where(eq(users.discordId, discordId));
        } else {
          const inserted = await db.insert(users).values({
            discordId,
            username,
            displayName,
            avatar: avatarHash,
            avatarUrl,
            lastLoginAt: new Date(),
            updatedAt: new Date()
          }).returning();
          if (inserted.length > 0) {
            dbUserId = inserted[0].id;
          }
        }
      } catch (dbErr) {
        console.warn('Database persistence notice (memory fallback active):', dbErr);
      }

      const sessionUser: AuthenticatedUser = {
        id: dbUserId,
        discordId,
        username,
        displayName,
        avatarUrl,
        role: rbac.role,
        accessLevel: rbac.accessLevel,
        isOwner: rbac.isOwner,
        isStaff: rbac.isStaff,
        staffRank: rbac.staffRank,
        staffPoints: rbac.staffPoints,
        permissions: rbac.permissions,
        isMember: rbac.isMember,
        isGuildOwner: rbac.isOwner,
        discordRoles: userRoleIds,
        discoveredAs: rbac.discoveredAs,
        matchedReason: rbac.matchedReason,
        matchedRole: rbac.matchedRole,
        matchedRoleId: rbac.matchedRoleId
      };

      memoryUsers.set(discordId, sessionUser);

      // Create cryptographically signed session token (7 days expiry)
      const sessionPayload = {
        id: dbUserId,
        discordId,
        username,
        displayName,
        avatarUrl,
        role: rbac.role,
        permissions: rbac.permissions,
        isMember: rbac.isMember,
        isGuildOwner: rbac.isOwner,
        discordRoles: userRoleIds,
        discoveredAs: rbac.discoveredAs,
        matchedReason: rbac.matchedReason,
        matchedRole: rbac.matchedRole,
        matchedRoleId: rbac.matchedRoleId,
        exp: Date.now() + 7 * 24 * 60 * 60 * 1000
      };
      const sessionToken = signSession(sessionPayload);

      // Cache this code exchange so any subsequent API exchange call doesn't fail with invalid_grant
      if (code) {
        recentExchangedCodes.set(String(code).trim(), {
          sessionUser,
          sessionToken,
          timestamp: Date.now()
        });
      }

      // Set dual secure HTTP-only cookies (SameSite=None for iframe, SameSite=Lax for Safari & top-level)
      setSessionCookies(res, sessionToken);

      // Audit Log: Discord OAuth Login
      recordAuditEvent({
        eventType: 'AUTH_LOGIN',
        category: 'AUTH',
        action: `User logged in via Discord OAuth as ${sessionUser.displayName} (@${sessionUser.username})`,
        userId: sessionUser.discordId,
        username: sessionUser.username,
        displayName: sessionUser.displayName,
        avatarUrl: sessionUser.avatarUrl,
        role: sessionUser.role as any,
        isGuest: false,
        path: '/api/auth/discord/callback',
        details: {
          method: 'oauth_popup',
          role: sessionUser.role,
          discoveredAs: sessionUser.discoveredAs
        }
      }, req);

      // Send postMessage and close popup, or redirect for Safari top-level navigation
      return res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Authentication Successful</title>
          <style>
            body { background: #0b0f19; color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 1rem; }
            .box { text-align: center; padding: 2.5rem; background: #111827; border: 1px solid rgba(6, 182, 212, 0.4); border-radius: 16px; max-width: 440px; width: 100%; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
            .avatar { width: 72px; height: 72px; border-radius: 50%; border: 2px solid #06b6d4; margin-bottom: 1rem; }
            h2 { color: #06b6d4; margin: 0 0 0.5rem 0; font-size: 20px; }
            .badge { display: inline-block; padding: 4px 12px; border-radius: 9999px; font-size: 12px; font-family: monospace; font-weight: 700; background: rgba(6,182,212,0.15); color: #06b6d4; border: 1px solid rgba(6,182,212,0.3); margin-bottom: 12px; }
            p { color: #94a3b8; font-size: 14px; margin: 0 0 1rem 0; }
            .btn { display: inline-block; background: #06b6d4; color: #0b0f19; font-weight: 700; font-size: 13px; padding: 10px 24px; border-radius: 10px; text-decoration: none; transition: opacity 0.2s; }
            .btn:hover { opacity: 0.9; }
          </style>
        </head>
        <body>
          <div class="box">
            <img class="avatar" src="${avatarUrl}" alt="${displayName}">
            <h2>Welcome, ${displayName}</h2>
            <div class="badge">ROLE: ${rbac.role} ${!rbac.isMember ? '(Non-Member)' : ''}</div>
            <p>Role verified with Discord. Redirecting to CREATINE NEXUS...</p>
            <a href="/" class="btn" id="enter-website-btn">Enter Website</a>
          </div>
          <script>
            const userObj = ${JSON.stringify(sessionUser)};
            try {
              localStorage.setItem('nexus_auth_event', JSON.stringify({
                type: 'OAUTH_AUTH_SUCCESS',
                timestamp: Date.now(),
                user: userObj
              }));
              localStorage.setItem('nexus_user', JSON.stringify(userObj));
            } catch (e) {}

            let notifiedOpener = false;
            try {
              if (window.opener && !window.opener.closed) {
                window.opener.postMessage({
                  type: 'OAUTH_AUTH_SUCCESS',
                  provider: 'discord',
                  user: userObj
                }, '*');
                notifiedOpener = true;
              }
            } catch (e) {}

            if (notifiedOpener) {
              setTimeout(() => {
                try { window.close(); } catch (e) {}
              }, 400);
            } else {
              // Safari top-level redirect fallback
              setTimeout(() => {
                window.location.href = '/';
              }, 500);
            }
          </script>
        </body>
        </html>
      `);
    } catch (err: any) {
      console.error('OAuth Callback Exception:', err);
      const errMsg = err?.message || 'Authentication processing error';
      const secretStatus = getDiscordSecretStatus();
      const isInvalidClient = errMsg.includes('invalid_client') || secretStatus.isAuthorizeUrl;

      return res.status(500).send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>${isInvalidClient ? 'Discord Client Secret Required' : 'Authentication Error'}</title>
          <style>
            * { box-sizing: border-box; }
            body { background: #07090e; color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 1.5rem; text-align: start; }
            .card { background: #0f141f; border: 1px solid rgba(6, 182, 212, 0.35); border-radius: 16px; padding: 2rem; max-width: 500px; width: 100%; box-shadow: 0 20px 50px rgba(0,0,0,0.7); }
            h2 { color: #38bdf8; margin: 0 0 0.75rem 0; font-size: 1.25rem; font-weight: 700; }
            p { color: #94a3b8; font-size: 13px; line-height: 1.6; margin: 0 0 1rem 0; }
            .badge { display: inline-block; background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.4); color: #f87171; font-size: 11px; font-weight: 600; padding: 3px 8px; border-radius: 6px; margin-bottom: 1rem; }
            .btn-primary { display: block; width: 100%; background: #06b6d4; color: #000; padding: 12px; border-radius: 10px; font-weight: 700; font-size: 13px; text-align: center; border: none; cursor: pointer; text-decoration: none; margin-bottom: 0.75rem; transition: background 0.2s; }
            .btn-primary:hover { background: #22d3ee; }
            .btn-secondary { display: block; width: 100%; background: rgba(255,255,255,0.06); color: #e2e8f0; padding: 10px; border-radius: 10px; font-size: 12px; text-align: center; border: 1px solid rgba(255,255,255,0.15); cursor: pointer; text-decoration: none; }
            .btn-secondary:hover { background: rgba(255,255,255,0.1); }
            .guide { background: rgba(0,0,0,0.4); border: 1px solid rgba(6, 182, 212, 0.2); border-radius: 10px; padding: 14px; margin-bottom: 1.25rem; font-size: 12px; color: #cbd5e1; line-height: 1.6; }
            .guide ol { margin: 6px 0 0 0; padding-left: 1.25rem; }
            .guide li { margin-bottom: 4px; }
            code { background: rgba(0,0,0,0.5); color: #06b6d4; padding: 2px 5px; border-radius: 4px; font-size: 11px; font-family: monospace; }
          </style>
        </head>
        <body>
          <div class="card">
            <span class="badge">Discord OAuth2 • Verification Notice</span>
            <h2>${isInvalidClient ? 'Client Secret Required for OAuth' : 'Authentication Notice'}</h2>
            <p>
              ${isInvalidClient 
                ? 'Discord reported <code>invalid_client</code>. The AI Studio secret <code>LOGIN_DISCORD</code> is currently set to an Authorize URL instead of your 32-character Discord Client Secret.' 
                : errMsg}
            </p>

            <div class="guide">
              <strong style="color: #38bdf8;">How to get your Discord Client Secret:</strong>
              <ol>
                <li>Open <strong>Discord Developer Portal &gt; Applications &gt; 1548702834755637369 &gt; OAuth2 &gt; General</strong>.</li>
                <li>Under <strong>Client Secret</strong>, click <strong>Reset Secret</strong>.</li>
                <li>Copy the ~32-character secret and paste it into AI Studio <strong>Settings &gt; Secrets &gt; LOGIN_DISCORD</strong>.</li>
              </ol>
            </div>

            <a class="btn-primary" href="/">
              Return to Website
            </a>
          </div>

          <script>
            try {
              if (window.opener) {
                window.opener.postMessage({
                  type: 'OAUTH_AUTH_ERROR',
                  error: ${JSON.stringify(errMsg)},
                  isInvalidClient: ${Boolean(isInvalidClient)}
                }, '*');
              }
            } catch (e) {}
          </script>
        </body>
        </html>
      `);
    }
  };

  app.get('/auth/discord/callback', callbackHandler);
  app.get('/auth/discord/callback/', callbackHandler);
  app.get('/api/auth/discord/callback', callbackHandler);

  // 3b. Exchange Authorization Code for User Session (for Add Bot to User OAuth2 flow)
  app.post('/api/auth/discord/exchange', async (req, res) => {
    const { code, redirectUri, state } = req.body;
    if (!code) {
      return res.status(400).json({ error: 'Authorization code is required' });
    }

    const cleanCode = String(code).trim();
    const effectiveClientId = resolveDiscordClientId();
    const effectiveClientSecret = resolveDiscordClientSecret();
    const secretStatus = getDiscordSecretStatus();

    // 1. Fast cache return if this code was already processed (prevents invalid_grant on re-submissions)
    if (recentExchangedCodes.has(cleanCode)) {
      const cached = recentExchangedCodes.get(cleanCode)!;
      setSessionCookies(res, cached.sessionToken);
      return res.json({
        success: true,
        user: cached.sessionUser,
        cached: true
      });
    }

    // 2. Coalesce concurrent duplicate in-flight requests (e.g., React StrictMode or concurrent triggers)
    if (inFlightCodeExchanges.has(cleanCode)) {
      try {
        const cached = await inFlightCodeExchanges.get(cleanCode)!;
        setSessionCookies(res, cached.sessionToken);
        return res.json({
          success: true,
          user: cached.sessionUser,
          inflightJoined: true
        });
      } catch (inFlightErr: any) {
        if (req.authUser) {
          return res.json({ success: true, user: req.authUser });
        }
        return res.status(500).json({ error: inFlightErr?.message || 'OAuth exchange failed' });
      }
    }

    if (!effectiveClientSecret) {
      return res.status(400).json({
        error: secretStatus.statusMessage,
        code: secretStatus.isAuthorizeUrl ? 'SECRET_IS_AUTHORIZE_URL' : 'MISSING_CLIENT_SECRET',
        isAuthorizeUrl: secretStatus.isAuthorizeUrl,
        clientId: effectiveClientId
      });
    }

    // Determine redirectUri from state, cookie, or payload
    let stateRedirectUri: string | null = null;
    if (state && typeof state === 'string') {
      try {
        const parts = state.split('.');
        const decoded = JSON.parse(Buffer.from(parts[0], 'base64url').toString('utf-8'));
        if (decoded && decoded.redirectUri && typeof decoded.redirectUri === 'string') {
          stateRedirectUri = decoded.redirectUri;
        }
      } catch {}
    }

    const cookieRedirectUri = req.cookies?.nexus_oauth_redirect || req.cookies?.nexus_oauth_redirect_lax;
    const chosenRedirect = stateRedirectUri || cookieRedirectUri || redirectUri;
    const effectiveRedirectUri = getSynchronizedRedirectUri(req, chosenRedirect);

    const exchangeTask = (async () => {
      const { accessToken } = await exchangeDiscordAuthorizationCode(cleanCode, effectiveRedirectUri);

      // 1. Fetch user profile from Discord
      const userResponse = await fetch('https://discord.com/api/v10/users/@me', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });

      if (!userResponse.ok) {
        const errText = await userResponse.text();
        throw new Error(`Failed to retrieve Discord user profile: ${errText}`);
      }

      const discordUser = (await userResponse.json()) as DiscordOAuthUser;
      const discordId = discordUser.id;
      const username = discordUser.username;
      const displayName = discordUser.global_name || discordUser.username;
      const avatarHash = discordUser.avatar;
      const avatarUrl = computeAvatarUrl(discordId, avatarHash);

      userAccessTokens.set(discordId, accessToken);

      // 2. Query Discord server membership and actual Discord roles via Discord Bot
      const { isMember, userRoleIds, guildRoles } = await fetchDiscordGuildAndRoles(accessToken, discordId);

      // 3. Resolve role and permissions server-side based on centralized RBAC engine
      const rbac = await calculateEffectiveRole({
        discordId,
        isMember,
        isGuildOwner: isOwner(discordId),
        userRoleIds,
        guildRoles
      });

      // 4. Persist in DB
      let dbUserId: number | string = discordId;
      try {
        const existingUsers = await db.select().from(users).where(eq(users.discordId, discordId));
        if (existingUsers.length > 0) {
          dbUserId = existingUsers[0].id;
          await db.update(users)
            .set({
              username,
              displayName,
              avatar: avatarHash,
              avatarUrl,
              lastLoginAt: new Date(),
              updatedAt: new Date()
            })
            .where(eq(users.discordId, discordId));
        } else {
          const inserted = await db.insert(users).values({
            discordId,
            username,
            displayName,
            avatar: avatarHash,
            avatarUrl,
            lastLoginAt: new Date(),
            updatedAt: new Date()
          }).returning();
          if (inserted.length > 0) {
            dbUserId = inserted[0].id;
          }
        }
      } catch (dbErr) {
        console.warn('DB persistence note:', dbErr);
      }

      const sessionUser: AuthenticatedUser = {
        id: dbUserId,
        discordId,
        username,
        displayName,
        avatarUrl,
        role: rbac.role,
        accessLevel: rbac.accessLevel,
        isOwner: rbac.isOwner,
        isStaff: rbac.isStaff,
        staffRank: rbac.staffRank,
        staffPoints: rbac.staffPoints,
        permissions: rbac.permissions,
        isMember: rbac.isMember,
        isGuildOwner: rbac.isOwner,
        discordRoles: userRoleIds,
        discoveredAs: rbac.discoveredAs,
        matchedReason: rbac.matchedReason,
        matchedRole: rbac.matchedRole,
        matchedRoleId: rbac.matchedRoleId
      };

      memoryUsers.set(discordId, sessionUser);

      // Create signed session token
      const sessionPayload = {
        id: dbUserId,
        discordId,
        username,
        displayName,
        avatarUrl,
        role: rbac.role,
        permissions: rbac.permissions,
        isMember: rbac.isMember,
        isGuildOwner: rbac.isOwner,
        discordRoles: userRoleIds,
        discoveredAs: rbac.discoveredAs,
        matchedReason: rbac.matchedReason,
        matchedRole: rbac.matchedRole,
        matchedRoleId: rbac.matchedRoleId,
        exp: Date.now() + 7 * 24 * 60 * 60 * 1000
      };
      const sessionToken = signSession(sessionPayload);

      return { sessionUser, sessionToken };
    })();

    inFlightCodeExchanges.set(cleanCode, exchangeTask);

    try {
      const { sessionUser, sessionToken } = await exchangeTask;
      recentExchangedCodes.set(cleanCode, {
        sessionUser,
        sessionToken,
        timestamp: Date.now()
      });

      setSessionCookies(res, sessionToken);

      // Audit Log: Code Exchange Authentication
      recordAuditEvent({
        eventType: 'AUTH_LOGIN',
        category: 'AUTH',
        action: `User authenticated via token exchange as ${sessionUser.displayName} (@${sessionUser.username})`,
        userId: sessionUser.discordId,
        username: sessionUser.username,
        displayName: sessionUser.displayName,
        avatarUrl: sessionUser.avatarUrl,
        role: sessionUser.role as any,
        isGuest: false,
        path: '/api/auth/discord/exchange',
        details: {
          method: 'code_exchange',
          role: sessionUser.role
        }
      }, req);

      res.json({
        success: true,
        user: sessionUser
      });
    } catch (err: any) {
      if (err?.message?.includes('invalid_grant') && req.authUser) {
        return res.json({
          success: true,
          user: req.authUser,
          alreadyAuthenticated: true
        });
      }
      console.error('Exchange error:', err);
      res.status(500).json({ error: err.message || 'Server error during OAuth exchange' });
    } finally {
      inFlightCodeExchanges.delete(cleanCode);
    }
  });

  // 4. Current Authenticated User (`/api/auth/me`)
  app.get('/api/auth/me', async (req, res) => {
    if (!req.authUser) {
      return res.json({ authenticated: false, user: null });
    }

    res.json({
      authenticated: true,
      user: req.authUser
    });
  });

  // 5. Session Refresh (`/api/auth/refresh`)
  // Discord is the source of truth: Re-evaluates roles directly from Discord API
  app.post('/api/auth/refresh', async (req, res) => {
    if (!req.authUser) {
      return res.status(401).json({ error: 'Unauthenticated' });
    }

    const discordId = req.authUser.discordId;
    const cachedToken = userAccessTokens.get(discordId);

    // Rate limit refresh calls (max 10 per minute per user)
    const rl = checkRateLimit(`refresh_${discordId}`, 10, 60000);
    if (!rl.allowed) {
      return res.status(429).json({ error: 'Too many refresh requests', retryAfter: rl.retryAfter });
    }

    try {
      // Re-fetch Discord roles via Discord Bot
      const { isMember, userRoleIds, guildRoles } = await fetchDiscordGuildAndRoles(cachedToken, discordId);

      const rbac = await calculateEffectiveRole({
        discordId,
        isMember,
        isGuildOwner: isOwner(discordId),
        userRoleIds,
        guildRoles
      });

      const updatedUser: AuthenticatedUser = {
        ...req.authUser,
        role: rbac.role,
        accessLevel: rbac.accessLevel,
        isOwner: rbac.isOwner,
        isStaff: rbac.isStaff,
        staffRank: rbac.staffRank,
        staffPoints: rbac.staffPoints,
        permissions: rbac.permissions,
        isMember: rbac.isMember,
        isGuildOwner: rbac.isOwner,
        discordRoles: userRoleIds,
        discoveredAs: rbac.discoveredAs,
        matchedReason: rbac.matchedReason,
        matchedRole: rbac.matchedRole,
        matchedRoleId: rbac.matchedRoleId
      };

      memoryUsers.set(discordId, updatedUser);

      // Re-sign session with fresh Discord roles
      const sessionPayload = {
        id: req.authUser.id,
        discordId,
        username: req.authUser.username,
        displayName: req.authUser.displayName,
        avatarUrl: req.authUser.avatarUrl,
        role: rbac.role,
        permissions: rbac.permissions,
        isMember: rbac.isMember,
        isGuildOwner: rbac.isOwner,
        discordRoles: userRoleIds,
        discoveredAs: rbac.discoveredAs,
        matchedReason: rbac.matchedReason,
        matchedRole: rbac.matchedRole,
        matchedRoleId: rbac.matchedRoleId,
        exp: Date.now() + 7 * 24 * 60 * 60 * 1000
      };

      const sessionToken = signSession(sessionPayload);

      setSessionCookies(res, sessionToken);

      res.json({
        success: true,
        message: 'Session roles re-synchronized with Discord',
        user: updatedUser
      });
    } catch (err: any) {
      console.error('Session refresh error:', err);
      res.status(500).json({ error: 'Failed to refresh roles from Discord' });
    }
  });

  // 6. Role Configuration Management (`/api/auth/roles-config`)
  app.get('/api/auth/roles-config', (req, res) => {
    const config = getDiscordRbacConfig();
    res.json({
      guildId: config.guildId,
      moderatorRoleName: config.moderatorRoleName,
      moderatorRoleNames: config.moderatorRoleNames,
      moderatorRoleId: config.moderatorRoleId,
      moderatorRoleIds: config.moderatorRoleIds,
      roleIdOwner: config.roleIdOwner,
      roleIdSuperAdmin: config.roleIdSuperAdmin,
      roleIdAdmin: config.roleIdAdmin,
      roleIdModerator: config.roleIdModerator,
      rolePermissions: ROLE_PERMISSIONS
    });
  });

  // Dedicated Moderator Role Configuration for Server Owner
  // Allows Owner to choose which Discord role grants the Moderator view of the website!
  app.get('/api/auth/moderator-role-config', async (req, res) => {
    const config = getDiscordRbacConfig();
    const serverRoles = await getDiscordServerRoles();
    const isOwnerRequester = Boolean(
      req.authUser && req.authUser.role === 'OWNER' && (req.authUser.isOwner || isOwner(req.authUser.discordId, req.authUser.discordRoles))
    );
    res.json({
      success: true,
      moderatorRoleName: config.moderatorRoleName,
      moderatorRoleNames: config.moderatorRoleNames,
      moderatorRoleId: config.moderatorRoleId,
      moderatorRoleIds: config.moderatorRoleIds,
      isOwner: isOwnerRequester,
      availableRoles: serverRoles
    });
  });

  app.post('/api/auth/moderator-role-config', async (req, res) => {
    // Only Server Owner or Owner-role users can change what role grants Moderator view
    const isOwnerAuthorized = Boolean(
      req.authUser && req.authUser.role === 'OWNER' && (req.authUser.isOwner || isOwner(req.authUser.discordId, req.authUser.discordRoles))
    );

    if (!isOwnerAuthorized) {
      return res.status(403).json({
        error: 'Forbidden: Only the Server Owner or users with an Owner role can configure which Discord role grants the Moderator view.'
      });
    }

    try {
      const { moderatorRoleName, moderatorRoleNames, moderatorRoleId, moderatorRoleIds } = req.body;
      const cleanName = typeof moderatorRoleName === 'string' ? moderatorRoleName.trim() : undefined;
      const cleanNames = Array.isArray(moderatorRoleNames)
        ? moderatorRoleNames.map((s: any) => String(s).trim()).filter(Boolean)
        : cleanName ? [cleanName] : undefined;

      saveRbacConfigFile({
        moderatorRoleName: cleanName,
        moderatorRoleNames: cleanNames,
        moderatorRoleId: typeof moderatorRoleId === 'string' ? moderatorRoleId.trim() : undefined,
        moderatorRoleIds: Array.isArray(moderatorRoleIds) ? moderatorRoleIds : undefined
      });

      const updated = getDiscordRbacConfig();
      res.json({
        success: true,
        message: `Success: The Discord role "${updated.moderatorRoleName}" will now receive the Moderator view of the website.`,
        config: updated
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to update moderator role configuration', details: err?.message });
    }
  });

  // Discord Guild Roles Endpoint
  app.get('/api/discord/server-roles', async (req, res) => {
    try {
      const info = await getDiscordServerRolesInfo();
      res.json({ success: true, roles: info.roles, botConnected: info.botConnected });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to query Discord server roles' });
    }
  });

  // ====================================================
  // MODERN STAFF ROLES CONFIGURATION ENDPOINTS
  // Role IDs are the sole source of truth.
  // Enforced on backend: Server Owner or Owner-role users can configure.
  // ====================================================
  app.get('/api/staff-roles/config', async (req, res) => {
    try {
      const config = getDiscordRbacConfig();
      const { roles, botConnected } = await getDiscordServerRolesInfo();

      const isOwnerRequester = Boolean(
        req.authUser && req.authUser.role === 'OWNER' && (req.authUser.isOwner || isOwner(req.authUser.discordId, req.authUser.discordRoles))
      );

      let storedRoleIds: string[] | null = null;
      try {
        if (db) {
          const dbRow = await db.select().from(serverConfig).where(eq(serverConfig.key, 'staff_role_ids')).limit(1);
          if (dbRow.length > 0 && dbRow[0]?.value) {
            const parsed = JSON.parse(dbRow[0].value);
            if (Array.isArray(parsed)) {
              storedRoleIds = parsed;
            }
          }
        }
      } catch (e) {
        // Fallback to rbac config silently
      }

      if (!storedRoleIds || storedRoleIds.length === 0) {
        try {
          const firestore = getFirestoreInstance();
          if (firestore) {
            const snap = await getDoc(doc(firestore, 'server_config', 'staff_role_ids'));
            if (snap.exists() && Array.isArray(snap.data()?.roleIds)) {
              storedRoleIds = snap.data().roleIds;
            }
          }
        } catch (fsErr) {
          // Fallback silently
        }
      }

      const activeStaffRoleIds = Array.isArray(config.staffRoleIds)
        ? config.staffRoleIds
        : (storedRoleIds || config.roleIdsModerator || []);

      res.json({
        success: true,
        guildId: config.guildId,
        serverName: 'CREATINE NEXUS || مركز الابداع',
        staffRoleIds: activeStaffRoleIds,
        ownerRoleIds: config.ownerRoleIds || [],
        availableRoles: roles,
        botConnected,
        isOwner: isOwnerRequester,
        sourceOfTruth: 'DISCORD_ROLE_IDS'
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to retrieve staff roles configuration', details: err?.message });
    }
  });

  app.post('/api/staff-roles/config', async (req, res) => {
    // Check if requester is server owner or has Owner role
    // Enforce permission on backend:
    const isOwnerAuthorized = Boolean(
      req.authUser && req.authUser.role === 'OWNER' && (req.authUser.isOwner || isOwner(req.authUser.discordId, req.authUser.discordRoles))
    );

    if (!isOwnerAuthorized) {
      return res.status(403).json({
        error: 'Forbidden: Only the server owner or users with an Owner role can configure staff roles.'
      });
    }

    try {
      const { staffRoleIds } = req.body;
      if (!Array.isArray(staffRoleIds)) {
        return res.status(400).json({
          error: 'Invalid payload: staffRoleIds must be an array of Discord Snowflake Role IDs.'
        });
      }

      // Role IDs are the source of truth - validate numeric snowflake IDs
      const sanitizedRoleIds = Array.from(
        new Set(
          staffRoleIds
            .map((id: any) => String(id).trim())
            .filter((id: string) => /^\d{15,22}$/.test(id))
        )
      );

      const ownerTag = req.authUser ? req.authUser.discordId : 'OWNER';

      // Save to discord-rbac-config.json
      const updatedRoleIds = saveStaffRolesConfig(sanitizedRoleIds, ownerTag);

      // Persist to PostgreSQL database
      try {
        if (db) {
          await db.insert(serverConfig)
            .values({
              key: 'staff_role_ids',
              value: JSON.stringify(updatedRoleIds),
              updatedBy: ownerTag,
              updatedAt: new Date()
            })
            .onConflictDoUpdate({
              target: serverConfig.key,
              set: {
                value: JSON.stringify(updatedRoleIds),
                updatedBy: ownerTag,
                updatedAt: new Date()
              }
            });
        }
      } catch (dbErr) {
        console.warn('Notice: database serverConfig update notice (file-based persistence active):', dbErr);
      }

      // Persist to Firestore server_config collection
      try {
        const firestore = getFirestoreInstance();
        if (firestore) {
          await setDoc(doc(firestore, 'server_config', 'staff_role_ids'), {
            roleIds: updatedRoleIds,
            updatedBy: ownerTag,
            updatedAt: new Date().toISOString()
          }, { merge: true });
        }
      } catch (fsErr) {
        console.warn('Notice: Firestore server_config update notice:', fsErr);
      }

      const performerTag = req.authUser
        ? `${req.authUser.discordId} (@${req.authUser.username})`
        : 'Server Owner';

      let syncResult: any = null;
      try {
        syncResult = await runStaffDiscordSync({
          targetRoleIds: updatedRoleIds,
          performer: performerTag
        });
      } catch (syncErr) {
        console.error('Auto Staff Sync error after saving staff roles:', syncErr);
      }

      res.json({
        success: true,
        message: 'Staff roles updated successfully and staff directory automatically synchronized.',
        staffRoleIds: updatedRoleIds,
        count: updatedRoleIds.length,
        syncResult: syncResult || {
          totalMatched: 0,
          addedCount: 0,
          updatedCount: 0,
          unchangedCount: 0,
          summary: 'Sync completed.'
        }
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to update staff roles', details: err?.message });
    }
  });

  // ====================================================
  // OWNER ROLES CONFIGURATION ENDPOINTS (SERVER-AUTHORITATIVE)
  // Dedicated Owner Role configuration alongside Staff Role configuration.
  // Persists selected Discord Role IDs that grant full Owner-level access.
  // Server-authoritative: Owner authorization verified strictly using Discord IDs.
  // ====================================================
  app.get('/api/owner-roles/config', async (req, res) => {
    try {
      const config = getDiscordRbacConfig();
      const { roles, botConnected } = await getDiscordServerRolesInfo();

      const isOwnerRequester = Boolean(
        req.authUser && req.authUser.role === 'OWNER' && (req.authUser.isOwner || isOwner(req.authUser.discordId, req.authUser.discordRoles))
      );

      let storedRoleIds: string[] | null = null;
      try {
        if (db) {
          const dbRow = await db.select().from(serverConfig).where(eq(serverConfig.key, 'owner_role_ids')).limit(1);
          if (dbRow.length > 0 && dbRow[0]?.value) {
            const parsed = JSON.parse(dbRow[0].value);
            if (Array.isArray(parsed)) {
              storedRoleIds = parsed;
            }
          }
        }
      } catch (e) {
        // Fallback silently
      }

      if (!storedRoleIds || storedRoleIds.length === 0) {
        try {
          const firestore = getFirestoreInstance();
          if (firestore) {
            const snap = await getDoc(doc(firestore, 'server_config', 'owner_role_ids'));
            if (snap.exists() && Array.isArray(snap.data()?.roleIds)) {
              storedRoleIds = snap.data().roleIds;
            }
          }
        } catch (fsErr) {
          // Fallback silently
        }
      }

      const activeOwnerRoleIds = Array.isArray(config.ownerRoleIds)
        ? config.ownerRoleIds
        : (storedRoleIds || config.roleIdsOwner || []);

      res.json({
        success: true,
        guildId: config.guildId,
        serverName: 'CREATINE NEXUS || مركز الابداع',
        ownerRoleIds: activeOwnerRoleIds,
        availableRoles: roles,
        botConnected,
        isOwner: isOwnerRequester,
        sourceOfTruth: 'DISCORD_ROLE_IDS'
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to retrieve owner roles configuration', details: err?.message });
    }
  });

  app.post('/api/owner-roles/config', async (req, res) => {
    const isOwnerAuthorized = Boolean(
      req.authUser && req.authUser.role === 'OWNER' && (req.authUser.isOwner || isOwner(req.authUser.discordId, req.authUser.discordRoles))
    );

    if (!isOwnerAuthorized) {
      return res.status(403).json({
        error: 'Forbidden: Only the server owner or users with an Owner role can configure owner roles.'
      });
    }

    try {
      const { ownerRoleIds } = req.body;
      if (!Array.isArray(ownerRoleIds)) {
        return res.status(400).json({
          error: 'Invalid payload: ownerRoleIds must be an array of Discord Snowflake Role IDs.'
        });
      }

      const sanitizedRoleIds = Array.from(
        new Set(
          ownerRoleIds
            .map((id: any) => String(id).trim())
            .filter((id: string) => /^\d{15,22}$/.test(id))
        )
      );

      const ownerTag = req.authUser ? req.authUser.discordId : 'OWNER';

      // Save to discord-rbac-config.json
      const updatedRoleIds = saveOwnerRolesConfig(sanitizedRoleIds, ownerTag);

      // Persist to PostgreSQL database
      try {
        if (db) {
          await db.insert(serverConfig)
            .values({
              key: 'owner_role_ids',
              value: JSON.stringify(updatedRoleIds),
              updatedBy: ownerTag,
              updatedAt: new Date()
            })
            .onConflictDoUpdate({
              target: serverConfig.key,
              set: {
                value: JSON.stringify(updatedRoleIds),
                updatedBy: ownerTag,
                updatedAt: new Date()
              }
            });
        }
      } catch (dbErr) {
        console.warn('Notice: database serverConfig update notice for owner_role_ids:', dbErr);
      }

      // Persist to Firestore server_config collection
      try {
        const firestore = getFirestoreInstance();
        if (firestore) {
          await setDoc(doc(firestore, 'server_config', 'owner_role_ids'), {
            roleIds: updatedRoleIds,
            updatedBy: ownerTag,
            updatedAt: new Date().toISOString()
          }, { merge: true });
        }
      } catch (fsErr) {
        console.warn('Notice: Firestore server_config update notice for owner_role_ids:', fsErr);
      }

      res.json({
        success: true,
        message: 'Owner roles updated successfully.',
        ownerRoleIds: updatedRoleIds,
        count: updatedRoleIds.length
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to update owner roles', details: err?.message });
    }
  });

  // Discovery Testing / Simulation Engine
  app.post('/api/auth/test-discovery', async (req, res) => {
    const { discordId, username, roleNames = [], roleIds = [] } = req.body;
    const config = getDiscordRbacConfig();
    const cleanId = String(discordId || '123456789012345678').trim();

    const normalizedRoleNames = Array.isArray(roleNames) 
      ? roleNames.map((r: any) => String(r).trim()) 
      : (typeof roleNames === 'string' && roleNames ? [roleNames.trim()] : []);

    const rbac = await calculateEffectiveRole({
      discordId: cleanId,
      isMember: true,
      isGuildOwner: isOwner(cleanId),
      userRoleIds: Array.isArray(roleIds) ? roleIds : []
    });

    res.json({
      discordId: cleanId,
      username: username || 'Discord User',
      discoveredAs: rbac.discoveredAs,
      effectiveRole: rbac.role,
      accessLevel: rbac.accessLevel,
      isOwner: rbac.isOwner,
      isStaff: rbac.isStaff,
      staffRank: rbac.staffRank,
      matchedReason: rbac.matchedReason,
      matchedRole: rbac.matchedRole,
      permissions: rbac.permissions,
      configuredModeratorRole: config.moderatorRoleName
    });
  });

  app.post('/api/auth/roles-config', requirePermission('MANAGE_ROLES'), (req, res) => {
    try {
      const { roleIdOwner, roleIdSuperAdmin, roleIdAdmin, roleIdModerator, guildOwnerId, moderatorRoleName } = req.body;

      saveRbacConfigFile({
        roleIdOwner: typeof roleIdOwner === 'string' ? roleIdOwner.trim() : undefined,
        roleIdSuperAdmin: typeof roleIdSuperAdmin === 'string' ? roleIdSuperAdmin.trim() : undefined,
        roleIdAdmin: typeof roleIdAdmin === 'string' ? roleIdAdmin.trim() : undefined,
        roleIdModerator: typeof roleIdModerator === 'string' ? roleIdModerator.trim() : undefined,
        guildOwnerId: typeof guildOwnerId === 'string' ? guildOwnerId.trim() : undefined,
        moderatorRoleName: typeof moderatorRoleName === 'string' ? moderatorRoleName.trim() : undefined
      });

      res.json({
        success: true,
        message: 'Discord Role-Permission mapping configuration updated.',
        config: getDiscordRbacConfig()
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to update role configuration', details: err?.message });
    }
  });

  // 7. Logout
  app.post('/api/auth/logout', (req, res) => {
    const token = req.cookies?.nexus_session || req.cookies?.nexus_session_lax;
    let loggedOutUser: any = null;
    if (token) {
      const payload = verifySession(token);
      if (payload?.discordId) {
        loggedOutUser = payload;
        memoryUsers.delete(payload.discordId);
        userAccessTokens.delete(payload.discordId);
      }
    }
    clearSessionCookies(res);

    if (loggedOutUser) {
      recordAuditEvent({
        eventType: 'AUTH_LOGOUT',
        category: 'AUTH',
        action: `User logged out: ${loggedOutUser.displayName || loggedOutUser.username} (@${loggedOutUser.username})`,
        userId: loggedOutUser.discordId,
        username: loggedOutUser.username || 'User',
        displayName: loggedOutUser.displayName || loggedOutUser.username || 'User',
        avatarUrl: loggedOutUser.avatarUrl,
        role: 'MEMBER',
        isGuest: false,
        path: '/api/auth/logout'
      }, req);
    }

    res.json({ success: true });
  });

  // 8. Direct / Preset Login (For development/testing & simulator)
  // Evaluates identity as: The Server Owner | A Moderator | A Normal Member
  const directLoginHandler = async (req: express.Request, res: express.Response) => {
    // Rate limit direct logins
    const ip = req.ip || req.headers['x-forwarded-for'] || '127.0.0.1';
    const rl = checkRateLimit(`login_${ip}`, 25, 60000);
    if (!rl.allowed) {
      return res.status(429).json({ error: 'Too many login attempts. Please wait.', retryAfter: rl.retryAfter });
    }

    try {
      const { discordId, username, displayName, avatarUrl } = req.body;

      const cleanId = String(discordId || '').trim();
      if (!cleanId || !/^\d{15,22}$/.test(cleanId)) {
        return res.status(400).json({
          error: 'A valid 17-20 digit Discord User ID is required. Discord User ID is the primary identity.'
        });
      }

      // Query Discord Bot for user's membership and roles in CREATINE NEXUS server
      const botCheck = await fetchDiscordGuildAndRoles(undefined, cleanId);
      const isMember = botCheck.isMember;
      const detectedRoles = botCheck.userRoleIds;

      // CALCULATE ROLE AND PERMISSIONS STRICTLY SERVER-SIDE USING CENTRALIZED RBAC:
      const rbac = await calculateEffectiveRole({
        discordId: cleanId,
        isMember,
        isGuildOwner: isOwner(cleanId),
        userRoleIds: detectedRoles,
        guildRoles: botCheck.guildRoles
      });

      const cleanUsername = String(botCheck.memberUser?.username || username || `user_${cleanId.slice(-4)}`).trim();
      const cleanDisplayName = String(botCheck.memberUser?.displayName || displayName || cleanUsername).trim();
      const cleanAvatar = botCheck.memberUser?.avatarUrl || avatarUrl || computeAvatarUrl(cleanId, null);

      let dbUserId: number | string = cleanId;
      try {
        const existingUsers = await db.select().from(users).where(eq(users.discordId, cleanId));
        if (existingUsers.length > 0) {
          dbUserId = existingUsers[0].id;
          await db.update(users)
            .set({
              username: cleanUsername,
              displayName: cleanDisplayName,
              avatarUrl: cleanAvatar,
              lastLoginAt: new Date(),
              updatedAt: new Date()
            })
            .where(eq(users.discordId, cleanId));
        } else {
          const inserted = await db.insert(users).values({
            discordId,
            username: cleanUsername,
            displayName: cleanDisplayName,
            avatarUrl: cleanAvatar,
            lastLoginAt: new Date(),
            updatedAt: new Date()
          }).returning();
          if (inserted.length > 0) {
            dbUserId = inserted[0].id;
          }
        }
      } catch (dbErr) {
        // Continue
      }

      const sessionUser: AuthenticatedUser = {
        id: dbUserId,
        discordId: cleanId,
        username: cleanUsername,
        displayName: cleanDisplayName,
        avatarUrl: cleanAvatar,
        role: rbac.role,
        accessLevel: rbac.accessLevel,
        isOwner: rbac.isOwner,
        isStaff: rbac.isStaff,
        staffRank: rbac.staffRank,
        staffPoints: rbac.staffPoints,
        permissions: rbac.permissions,
        isMember: rbac.isMember,
        isGuildOwner: rbac.isOwner,
        discordRoles: detectedRoles,
        discoveredAs: rbac.discoveredAs,
        matchedReason: rbac.matchedReason,
        matchedRole: rbac.matchedRole
      };

      memoryUsers.set(cleanId, sessionUser);

      const sessionPayload = {
        id: dbUserId,
        discordId: cleanId,
        username: cleanUsername,
        displayName: cleanDisplayName,
        avatarUrl: cleanAvatar,
        isMember: rbac.isMember,
        isGuildOwner: rbac.isOwner,
        discordRoles: detectedRoles,
        discoveredAs: rbac.discoveredAs,
        matchedReason: rbac.matchedReason,
        matchedRole: rbac.matchedRole,
        exp: Date.now() + 7 * 24 * 60 * 60 * 1000
      };

      const sessionToken = signSession(sessionPayload);

      setSessionCookies(res, sessionToken);

      // Audit Log: Direct / Simulator Login
      recordAuditEvent({
        eventType: 'AUTH_LOGIN',
        category: 'AUTH',
        action: `User logged in as ${sessionUser.displayName} (@${sessionUser.username}) [${sessionUser.role}]`,
        userId: cleanId,
        username: cleanUsername,
        displayName: cleanDisplayName,
        avatarUrl: cleanAvatar,
        role: sessionUser.role as any,
        isGuest: false,
        path: '/api/auth/direct-login',
        details: {
          method: 'direct_login',
          role: sessionUser.role,
          discoveredAs: rbac.discoveredAs
        }
      }, req);

      res.json({
        success: true,
        authenticated: true,
        user: sessionUser,
        discovery: {
          discoveredAs: rbac.discoveredAs,
          role: rbac.role,
          matchedReason: rbac.matchedReason,
          matchedRole: rbac.matchedRole
        }
      });
    } catch (err: any) {
      console.error('Direct login error:', err);
      res.status(500).json({ error: 'Failed to process login' });
    }
  };

  app.post('/api/auth/direct-login', directLoginHandler);
  app.post('/api/auth/discord/direct-login', directLoginHandler);
}
