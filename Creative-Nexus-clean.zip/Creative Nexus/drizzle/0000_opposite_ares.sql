CREATE TYPE "public"."history_action" AS ENUM('STAFF_ADDED', 'STAFF_EDITED', 'PROMOTED', 'DEMOTED', 'SUSPENDED', 'REACTIVATED', 'REMOVED', 'POINTS_CHANGED');--> statement-breakpoint
CREATE TYPE "public"."point_transaction_type" AS ENUM('ADD', 'REMOVE');--> statement-breakpoint
CREATE TYPE "public"."staff_rank" AS ENUM('MODERATOR', 'SENIOR_MODERATOR', 'ADMINISTRATOR', 'SENIOR_ADMINISTRATOR', 'SUPER_ADMIN');--> statement-breakpoint
CREATE TYPE "public"."staff_status" AS ENUM('ACTIVE', 'SUSPENDED', 'REMOVED');--> statement-breakpoint
CREATE TABLE "staff" (
	"id" serial PRIMARY KEY NOT NULL,
	"discord_id" varchar(255) NOT NULL,
	"username" varchar(255) NOT NULL,
	"display_name" varchar(255) NOT NULL,
	"avatar_url" text NOT NULL,
	"rank" "staff_rank" DEFAULT 'MODERATOR' NOT NULL,
	"points" integer DEFAULT 0 NOT NULL,
	"status" "staff_status" DEFAULT 'ACTIVE' NOT NULL,
	"notes" text,
	"joined_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "staff_discord_id_unique" UNIQUE("discord_id")
);
--> statement-breakpoint
CREATE TABLE "staff_history" (
	"id" serial PRIMARY KEY NOT NULL,
	"staff_id" integer NOT NULL,
	"action" "history_action" NOT NULL,
	"description" text NOT NULL,
	"performed_by" varchar(255) DEFAULT 'SYSTEM' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "staff_point_transaction" (
	"id" serial PRIMARY KEY NOT NULL,
	"staff_id" integer NOT NULL,
	"amount" integer NOT NULL,
	"type" "point_transaction_type" NOT NULL,
	"reason" text NOT NULL,
	"note" text,
	"performed_by" varchar(255) DEFAULT 'SYSTEM' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "staff_history" ADD CONSTRAINT "staff_history_staff_id_staff_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."staff"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "staff_point_transaction" ADD CONSTRAINT "staff_point_transaction_staff_id_staff_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."staff"("id") ON DELETE no action ON UPDATE no action;