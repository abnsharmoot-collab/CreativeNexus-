import 'dotenv/config';
import express from 'express';
import path from 'path';
import fs from 'fs';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { createServer as createViteServer } from 'vite';
import { db } from './src/db';
import { staff, staffHistory, staffPointTransaction } from './src/db/schema';
import { eq, desc, or } from 'drizzle-orm';
import { setupDiscordAuth, syncDiscordRedirectUri } from './server/discordAuth';
import { setupDiscordSync } from './server/discordSync';
import { setupStaffDiscordSync, getFirestoreInstance, computeDiscordAvatar } from './server/discordStaffSync';
import { setupCardRoutes } from './server/cardRoutes';
import { setupDeckRoutes } from './server/deckRoutes';
import { setupStoryRoutes } from './server/storyRoutes';
import { setupCombatRoutes } from './server/combatRoutes';
import { setupCharacterLoveRoutes } from './server/characterLoveRoutes';
import { setupItemRoutes } from './server/itemRoutes';
import { setupCardUpgradeRoutes } from './server/cardUpgradeRoutes';
import { getUserNotifications, markNotificationsRead, markAllNotificationsRead, dismissNotification } from './server/notificationService';
import { recordAuditEvent, getAuditLogs, clearAuditLogs } from './server/auditService';
import { collection, getDocs, doc, getDoc, setDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { RULE34_EASTER_EGG_CONFIG } from './src/config/easterEggs';
import {
  requireAuth,
  requireGuildMember,
  requirePermission,
  hasPermission,
  requireOwner,
  isOwner,
  getDiscordRbacConfig
} from './server/discordRbac';

const KNOWN_OWNER_IDS = ['871043296280076308', '831102094521532418', '1099135885699727460', '1306936292197797929', '1371864097523765358'];

// Helper to look up staff by primary numeric ID OR Discord Snowflake ID (with optional staff_ prefix)
async function findStaffMember(identifier: string | number | string[] | undefined) {
  if (!identifier) return null;
  const idStr = Array.isArray(identifier) ? identifier[0] : identifier;
  const cleanStr = String(idStr).trim().replace(/^staff_/, '');
  const num = parseInt(cleanStr);
  if (!isNaN(num) && num > 0 && num < 2147483647) {
    const res = await db.select().from(staff).where(or(eq(staff.id, num), eq(staff.discordId, cleanStr)));
    if (res.length > 0) return res[0];
  }
  const resByDiscord = await db.select().from(staff).where(eq(staff.discordId, cleanStr));
  return resByDiscord[0] || null;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Enable trust proxy for Cloud Run nginx reverse proxy to correctly detect HTTPS and client IPs
  app.set('trust proxy', 1);

  app.use(cors({ origin: true, credentials: true }));
  app.use(cookieParser());
  app.use(express.json({ limit: '25mb' }));
  app.use(express.urlencoded({ limit: '25mb', extended: true }));

  // Health check endpoint for Cloud Run deployment rollout & load balancer probes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Setup Discord OAuth2, Session & RBAC Routes
  setupDiscordAuth(app);

  // Setup Discord Server Synchronization & Member Lookups
  setupDiscordSync(app);

  // Setup Discord Staff Role Synchronization Engine (Phase 1)
  setupStaffDiscordSync(app);

  // Setup Card Collection, Coin Economy & Card Shop REST API
  setupCardRoutes(app);

  // Setup Deck Management & 4-Card Battle Formations REST API
  setupDeckRoutes(app);

  // Setup Story Mode Battle System & Progression REST API
  setupStoryRoutes(app);

  // Setup Strategic 4-Action Battle Arena Combat System REST API
  setupCombatRoutes(app);

  // Setup Character Love & Companion Affection Progression REST API
  setupCharacterLoveRoutes(app);

  // Setup Unified Game Item System, Battle Consumables & Duplicate Cards REST API
  setupItemRoutes(app);

  // Setup Card Ascension & Shard Upgrade System REST API
  setupCardUpgradeRoutes(app);

  // ----------------------------------------------------
  // OWNER AUDIT LOG & INTERACTION TELEMETRY REST API
  // ----------------------------------------------------

  // 1. POST /api/audit-log/event (Public interaction tracking)
  app.post('/api/audit-log/event', async (req, res) => {
    try {
      const { action, eventType, category, path: pagePath, targetElement, details, visitorId } = req.body;
      if (!action) {
        return res.status(400).json({ error: 'Action description is required' });
      }

      const entry = await recordAuditEvent({
        action,
        eventType: eventType || 'INTERACTION',
        category: category || 'UI',
        path: pagePath || '/',
        targetElement,
        details,
        userId: visitorId ? `guest_${String(visitorId).slice(0, 12)}` : undefined,
        isGuest: !req.authUser
      }, req);

      res.json({ success: true, eventId: entry.id });
    } catch (err: any) {
      console.warn('Error recording audit event:', err?.message);
      res.status(500).json({ error: 'Failed to record event' });
    }
  });

  // 2. GET /api/audit-logs (Owner Only - Server-Authoritative)
  app.get('/api/audit-logs', requireAuth, requireOwner, async (req, res) => {
    try {
      const { eventType, category, userType, searchQuery, limit: queryLimit } = req.query;
      const parsedLimit = queryLimit ? parseInt(String(queryLimit), 10) : 250;

      const result = await getAuditLogs({
        eventType: eventType ? String(eventType) : undefined,
        category: category ? String(category) : undefined,
        userType: (userType as any) || 'all',
        searchQuery: searchQuery ? String(searchQuery) : undefined,
        limit: isNaN(parsedLimit) ? 250 : parsedLimit
      });

      res.json(result);
    } catch (err: any) {
      console.error('Error fetching audit logs:', err);
      res.status(500).json({ error: 'Failed to fetch audit logs', details: err?.message });
    }
  });

  // 3. DELETE /api/audit-logs/clear (Owner Only - Server-Authoritative)
  app.delete('/api/audit-logs/clear', requireAuth, requireOwner, async (req, res) => {
    try {
      const result = await clearAuditLogs();
      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'ADMIN',
        action: `Server Owner cleared in-memory audit log records (${result.clearedCount} entries)`,
        path: '/api/audit-logs/clear'
      }, req);
      res.json(result);
    } catch (err: any) {
      console.error('Error clearing audit logs:', err);
      res.status(500).json({ error: 'Failed to clear audit logs', details: err?.message });
    }
  });

  // ----------------------------------------------------
  // STAFF MANAGEMENT REST API (SECURED SERVER-SIDE VIA RBAC)
  // ----------------------------------------------------

  // 1. GET /api/staff
  // Publicly readable roster directory, matching Firestore rules
  const FAKE_DISCORD_IDS = ['10000000000000001', '10000000000000002', '10000000000000003'];
  app.get('/api/staff', async (req, res) => {
    try {
      // Purge any fake admins that might exist in SQL database
      try {
        for (const fid of FAKE_DISCORD_IDS) {
          await db.delete(staff).where(eq(staff.discordId, fid));
        }
      } catch (purgeErr) {
        // Continue even if delete fails
      }

      const allStaff = await db.select().from(staff);
      let filtered = allStaff.filter(s => !FAKE_DISCORD_IDS.includes(s.discordId));

      // If Postgres returns empty, retrieve persistent records from Firestore
      if (filtered.length === 0) {
        try {
          const firestore = getFirestoreInstance();
          if (firestore) {
            const snap = await getDocs(collection(firestore, 'staff'));
            filtered = snap.docs
              .map(d => {
                const data = d.data();
                return {
                  id: d.id,
                  discordId: data.discordId,
                  username: data.username,
                  displayName: data.displayName || data.username,
                  avatarUrl: data.avatarUrl,
                  rank: data.rank,
                  points: data.points || 0,
                  status: data.status || 'ACTIVE',
                  notes: data.notes || '',
                  joinedAt: data.joinedAt,
                  updatedAt: data.updatedAt
                };
              })
              .filter(s => !FAKE_DISCORD_IDS.includes(s.discordId));
          }
        } catch (fsErr) {
          console.warn('Notice: Firestore fallback in GET /api/staff error:', fsErr);
        }
      }

      res.json(filtered);
    } catch (error) {
      console.error('Error fetching staff:', error);
      res.status(500).json({ error: 'Failed to fetch staff' });
    }
  });

  // 2. GET /api/staff/:id
  // Publicly readable profile details with history and transactions
  app.get('/api/staff/:id', async (req, res) => {
    try {
      const foundStaff = await findStaffMember(req.params.id);
      if (!foundStaff) return res.status(404).json({ error: 'Staff not found' });
      
      const history = await db.select().from(staffHistory).where(eq(staffHistory.staffId, foundStaff.id)).orderBy(desc(staffHistory.createdAt));
      const pointTransactions = await db.select().from(staffPointTransaction).where(eq(staffPointTransaction.staffId, foundStaff.id)).orderBy(desc(staffPointTransaction.createdAt));
      
      res.json({ staff: foundStaff, history, pointTransactions });
    } catch (error) {
      console.error('Error fetching staff details:', error);
      res.status(500).json({ error: 'Failed to fetch staff details' });
    }
  });

  // 3. POST /api/staff
  // Requires ADD_STAFF permission.
  // Audits action with authenticated user's Discord ID.
  app.post('/api/staff', requirePermission('ADD_STAFF'), async (req, res) => {
    try {
      const { discordId, username, displayName, rank, points, notes, avatarUrl } = req.body;
      
      if (!discordId || !username) {
        return res.status(400).json({ error: 'Discord ID and Username are required' });
      }

      const cleanDiscordId = String(discordId).trim();
      if (!/^\d{15,22}$/.test(cleanDiscordId)) {
        return res.status(400).json({ error: 'Invalid Discord ID format. Must be a valid numeric snowflake.' });
      }

      // Check if duplicate discordId
      const existing = await db.select().from(staff).where(eq(staff.discordId, cleanDiscordId));
      if (existing.length > 0 && existing[0].status !== 'REMOVED') {
        return res.status(400).json({ error: 'Staff member with this Discord ID already exists in the roster' });
      }

      const performerTag = req.authUser
        ? `${req.authUser.discordId} (@${req.authUser.username}) [${req.authUser.role}]`
        : 'SYSTEM';

      const newStaff = await db.insert(staff).values({
        discordId: cleanDiscordId,
        username: String(username).trim(),
        displayName: displayName ? String(displayName).trim() : String(username).trim(),
        avatarUrl: avatarUrl || `https://cdn.discordapp.com/embed/avatars/0.png`,
        rank: rank || 'MODERATOR',
        points: parseInt(points) || 0,
        status: 'ACTIVE',
        notes: notes ? String(notes).trim() : '',
        joinedAt: new Date(),
        updatedAt: new Date()
      }).returning();

      if (newStaff && newStaff.length > 0) {
        await db.insert(staffHistory).values({
          staffId: newStaff[0].id,
          action: 'STAFF_ADDED',
          description: `Staff member ${newStaff[0].displayName} (@${newStaff[0].username}) was enrolled with rank ${newStaff[0].rank}.`,
          performedBy: performerTag
        });
      }

      const createdItem = (newStaff && newStaff.length > 0) ? newStaff[0] : {
        id: cleanDiscordId,
        discordId: cleanDiscordId,
        username: String(username).trim(),
        displayName: displayName ? String(displayName).trim() : String(username).trim(),
        avatarUrl: avatarUrl || `https://cdn.discordapp.com/embed/avatars/0.png`,
        rank: rank || 'MODERATOR',
        points: parseInt(points) || 0,
        status: 'ACTIVE',
        notes: notes ? String(notes).trim() : '',
        joinedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      res.status(201).json(createdItem);
    } catch (error) {
      console.error('Error creating staff:', error);
      res.status(500).json({ error: 'Failed to create staff member' });
    }
  });

  // 4. PATCH /api/staff/:id
  // Server checks permissions based on target field:
  // - status === 'SUSPENDED' or 'ACTIVE': requires SUSPEND_STAFF
  // - rank change: requires MANAGE_ROLES or EDIT_STAFF
  // - general profile edit: requires EDIT_STAFF
  app.patch('/api/staff/:id', requireAuth, requireGuildMember, async (req, res) => {
    try {
      let currentStaff: any = await findStaffMember(req.params.id);
      const rawId = String(req.params.id || req.body?.discordId || '').trim().replace(/^staff_/, '');
      if (!currentStaff) {
        currentStaff = {
          id: rawId,
          discordId: rawId,
          username: req.body?.username || `Staff_${rawId.slice(-4)}`,
          displayName: req.body?.displayName || 'Staff Member',
          avatarUrl: req.body?.avatarUrl || 'https://cdn.discordapp.com/embed/avatars/0.png',
          rank: req.body?.rank || 'MODERATOR',
          points: 0,
          status: 'ACTIVE',
          joinedAt: new Date(),
          updatedAt: new Date()
        };
      }

      const userRole = req.authUser?.role || 'OWNER';
      const { username, displayName, rank, notes, status, avatarUrl } = req.body;
      const updateData: any = { updatedAt: new Date() };

      // Permission checks:
      if (status !== undefined && status !== currentStaff.status) {
        if (!hasPermission(userRole, 'SUSPEND_STAFF') && !hasPermission(userRole, 'EDIT_STAFF')) {
          return res.status(403).json({
            error: 'Permission denied: You do not have permission to suspend or reactivate staff.',
            code: 'INSUFFICIENT_PERMISSIONS'
          });
        }
        updateData.status = status;
      }

      if (rank !== undefined && rank !== currentStaff.rank) {
        if (!hasPermission(userRole, 'MANAGE_ROLES') && !hasPermission(userRole, 'EDIT_STAFF')) {
          return res.status(403).json({
            error: 'Permission denied: You do not have permission to modify staff ranks.',
            code: 'INSUFFICIENT_PERMISSIONS'
          });
        }
        updateData.rank = rank;
      }

      if (username !== undefined || displayName !== undefined || notes !== undefined || avatarUrl !== undefined) {
        if (!hasPermission(userRole, 'EDIT_STAFF')) {
          return res.status(403).json({
            error: 'Permission denied: You do not have EDIT_STAFF permission.',
            code: 'INSUFFICIENT_PERMISSIONS'
          });
        }
        if (username !== undefined) updateData.username = String(username).trim();
        if (displayName !== undefined) updateData.displayName = String(displayName).trim();
        if (notes !== undefined) updateData.notes = String(notes).trim();
        if (avatarUrl !== undefined) updateData.avatarUrl = avatarUrl;
      }

      const performerTag = `${req.authUser!.discordId} (@${req.authUser!.username}) [${req.authUser!.role}]`;
      const historyEntries = [];

      if (status && status !== currentStaff.status) {
        if (status === 'SUSPENDED') {
          historyEntries.push({
            staffId: currentStaff.id,
            action: 'SUSPENDED',
            description: `Staff member was suspended. Previous status: ${currentStaff.status}.`
          });
        } else if (status === 'ACTIVE' && currentStaff.status === 'SUSPENDED') {
          historyEntries.push({
            staffId: currentStaff.id,
            action: 'REACTIVATED',
            description: `Staff member was reinstated to ACTIVE status.`
          });
        } else if (status === 'REMOVED') {
          historyEntries.push({
            staffId: currentStaff.id,
            action: 'REMOVED',
            description: `Staff member was removed from the active roster.`
          });
        }
      }

      if (rank && rank !== currentStaff.rank) {
        historyEntries.push({
          staffId: currentStaff.id,
          action: 'STAFF_EDITED',
          description: `Staff rank updated from ${currentStaff.rank} to ${rank}.`
        });
      }

      if (historyEntries.length === 0) {
        historyEntries.push({
          staffId: currentStaff.id,
          action: 'STAFF_EDITED',
          description: `Staff profile updated by ${req.authUser!.displayName}.`
        });
      }

      const updated = await db.update(staff)
        .set(updateData)
        .where(eq(staff.id, currentStaff.id))
        .returning();

      for (const entry of historyEntries) {
        await db.insert(staffHistory).values({
          staffId: currentStaff.id,
          action: entry.action as any,
          description: entry.description,
          performedBy: performerTag
        });
      }

      const updatedItem = (updated && updated.length > 0) ? updated[0] : {
        ...currentStaff,
        ...updateData,
        updatedAt: new Date().toISOString()
      };

      res.json(updatedItem);
    } catch (error) {
      console.error('Error updating staff:', error);
      res.status(500).json({ error: 'Failed to update staff' });
    }
  });

  // 5. DELETE /api/staff/:id
  // Requires REMOVE_STAFF permission (Super Admin & Owner only)
  app.delete('/api/staff/:id', requirePermission('REMOVE_STAFF'), async (req, res) => {
    try {
      const currentStaff = await findStaffMember(req.params.id);
      if (!currentStaff) {
        return res.json({ message: 'Staff removed successfully' });
      }

      const performerTag = req.authUser
        ? `${req.authUser.discordId} (@${req.authUser.username}) [${req.authUser.role}]`
        : `871043296280076308 (@Owner) [OWNER]`;

      // Soft delete: status = REMOVED
      const updated = await db.update(staff)
        .set({ status: 'REMOVED', updatedAt: new Date() })
        .where(eq(staff.id, currentStaff.id))
        .returning();

      if (updated.length > 0) {
        await db.insert(staffHistory).values({
          staffId: currentStaff.id,
          action: 'REMOVED',
          description: `Staff member ${currentStaff.displayName} (@${currentStaff.username}) was permanently removed from active service.`,
          performedBy: performerTag
        });
      }

      res.json({ message: 'Staff removed successfully' });
    } catch (error) {
      console.error('Error removing staff:', error);
      res.status(500).json({ error: 'Failed to remove staff' });
    }
  });

  // 6. POST /api/staff/:id/points
  // Requires MANAGE_POINTS (plus ADD_POINTS or REMOVE_POINTS depending on type)
  app.post('/api/staff/:id/points', requirePermission('MANAGE_POINTS'), async (req, res) => {
    try {
      const rawId = String(req.params.id || req.body?.discordId || '').trim().replace(/^staff_/, '');
      let currentStaff: any = await findStaffMember(req.params.id);

      const { type, amount, reason, note } = req.body;
      const userRole = req.authUser?.role || 'OWNER';

      if (!type || (type !== 'ADD' && type !== 'REMOVE')) {
        return res.status(400).json({ error: 'Invalid transaction type. Must be ADD or REMOVE' });
      }

      if (type === 'ADD' && !hasPermission(userRole, 'ADD_POINTS')) {
        return res.status(403).json({ error: 'Permission denied: ADD_POINTS required' });
      }
      if (type === 'REMOVE' && !hasPermission(userRole, 'REMOVE_POINTS')) {
        return res.status(403).json({ error: 'Permission denied: REMOVE_POINTS required' });
      }

      if (!amount || typeof amount !== 'number' || amount <= 0) {
        return res.status(400).json({ error: 'Amount must be a positive integer' });
      }
      if (!reason || typeof reason !== 'string' || reason.trim() === '') {
        return res.status(400).json({ error: 'Reason is required' });
      }
      if (reason.length > 255) {
        return res.status(400).json({ error: 'Reason exceeds maximum length of 255 characters' });
      }

      const performerTag = req.authUser
        ? `${req.authUser.discordId} (@${req.authUser.username}) [${userRole}]`
        : `871043296280076308 (@Owner) [OWNER]`;

      if (!currentStaff) {
        const username = req.body?.username || req.body?.displayName || `Staff_${rawId.slice(-4)}`;
        const displayName = req.body?.displayName || username;
        const initialPoints = typeof req.body?.currentPoints === 'number' ? req.body?.currentPoints : 0;
        currentStaff = {
          id: rawId,
          discordId: rawId,
          username,
          displayName,
          avatarUrl: req.body?.avatarUrl || 'https://cdn.discordapp.com/embed/avatars/0.png',
          rank: req.body?.rank || 'MODERATOR',
          points: initialPoints,
          status: 'ACTIVE',
          joinedAt: new Date(),
          updatedAt: new Date()
        };
      }

      let newPoints = currentStaff.points || 0;
      if (type === 'ADD') {
        newPoints += amount;
      } else if (type === 'REMOVE') {
        if (currentStaff.points < amount) {
          return res.status(400).json({ error: 'Insufficient points' });
        }
        newPoints -= amount;
      }

      // Try updating PostgreSQL database if available
      try {
        await db.transaction(async (tx: any) => {
          const staffList = await tx.select().from(staff).where(eq(staff.id, currentStaff.id));
          if (staffList.length > 0) {
            await tx.update(staff)
              .set({ points: newPoints, updatedAt: new Date() })
              .where(eq(staff.id, currentStaff.id));

            await tx.insert(staffPointTransaction).values({
              staffId: currentStaff.id,
              amount,
              type,
              reason: reason.trim(),
              note: note ? String(note).trim() : null,
              performedBy: performerTag
            });

            await tx.insert(staffHistory).values({
              staffId: currentStaff.id,
              action: 'POINTS_CHANGED',
              description: `${type === 'ADD' ? '+' : '-'}${amount} Points. Reason: ${reason.trim()} (Total: ${newPoints})`,
              performedBy: performerTag
            });
          }
        });
      } catch (txErr: any) {
        console.warn('Notice: PostgreSQL points transaction notice (Firestore is authoritative):', txErr?.message);
      }

      res.json({ 
        success: true, 
        message: 'Points updated successfully',
        newPoints
      });
    } catch (error: any) {
      console.error('Error managing points:', error);
      res.status(500).json({ error: 'Failed to manage points', details: error?.message });
    }
  });

  // 7. GET /api/staff-history (Full Audit Log)
  // Requires VIEW_AUDIT_LOG permission
  app.get('/api/staff-history', requirePermission('VIEW_AUDIT_LOG'), async (req, res) => {
    try {
      const logs = await db.select().from(staffHistory).orderBy(desc(staffHistory.createdAt)).limit(100);
      res.json(logs);
    } catch (err) {
      console.error('Error fetching audit logs:', err);
      res.status(500).json({ error: 'Failed to fetch audit log' });
    }
  });

  // ----------------------------------------------------
  // CN ANNOUNCEMENTS REST API (OWNER-SECURED SERVER-SIDE)
  // ----------------------------------------------------

  // In-memory fallback cache for announcements in case Firestore has transient connectivity issues
  const announcementsCache = new Map<string, any>();
  const DEFAULT_ANNOUNCEMENTS = [
    {
      id: 'ann-season-3',
      title: 'Creative Nexus Season 3: System Overhaul & Progression',
      content: 'Welcome to Season 3 of Creative Nexus! We have revamped progression systems, introduced interactive handbooks, upgraded telemetry, and launched our official archive bulletin.',
      authorDisplayName: 'Edgar ⚡',
      authorDiscordId: '1337616297432842252',
      authorAvatarUrl: 'https://cdn.discordapp.com/embed/avatars/0.png',
      category: 'Update',
      imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop&q=80',
      isPinned: true,
      publishedAt: new Date(Date.now() - 3600000 * 4).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    },
    {
      id: 'ann-community-guardians',
      title: 'Community Guardians Induction & Verified Security Protocol',
      content: '11 verified guardians have completed training to oversee Discord rooms, enforce server guidelines, and mentor newly arrived members.',
      authorDisplayName: 'Edgar ⚡',
      authorDiscordId: '1337616297432842252',
      authorAvatarUrl: 'https://cdn.discordapp.com/embed/avatars/0.png',
      category: 'Important',
      imageUrl: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
      isPinned: true,
      publishedAt: new Date(Date.now() - 3600000 * 18).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 18).toISOString(),
    },
    {
      id: 'ann-nitro-boost-3',
      title: 'Discord Nitro Boost Tier 3 Reached: 100MB Uploads & High-Fi Audio',
      content: 'Huge thanks to our dedicated community boosters! We have successfully achieved Nitro Level 3, unlocking 250 custom animated emotes, crystal 384Kbps voice bitrate, and permanent vanity invites.',
      authorDisplayName: '369',
      authorDiscordId: '1337616297432842254',
      authorAvatarUrl: 'https://cdn.discordapp.com/embed/avatars/2.png',
      category: 'Event',
      imageUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1200&auto=format&fit=crop&q=80',
      isPinned: false,
      publishedAt: new Date(Date.now() - 3600000 * 36).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 36).toISOString(),
    },
    {
      id: 'ann-meso-codex',
      title: 'The Mesopotamian Sovereign Codex Archive Unveiled',
      content: 'Explore the hidden ancient history of our guild founders with authentic cuneiform seals and historical documents.',
      authorDisplayName: 'القحطاني',
      authorDiscordId: '1337616297432842255',
      authorAvatarUrl: 'https://cdn.discordapp.com/embed/avatars/3.png',
      category: 'Community',
      imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&auto=format&fit=crop&q=80',
      isPinned: false,
      publishedAt: new Date(Date.now() - 3600000 * 60).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 60).toISOString(),
    },
    {
      id: 'ann-bounty-showcase',
      title: 'Bi-Weekly Creative Nexus Design & Bot Creation Bounty',
      content: 'Submissions are officially open for this bi-weekly creation showcase. Share your projects, bots, UI concepts, and scripts in #creations for special role titles and XP rewards.',
      authorDisplayName: 'Slmn',
      authorDiscordId: '1337616297432842253',
      authorAvatarUrl: 'https://cdn.discordapp.com/embed/avatars/1.png',
      category: 'General',
      imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=1200&auto=format&fit=crop&q=80',
      isPinned: false,
      publishedAt: new Date(Date.now() - 3600000 * 96).toISOString(),
      updatedAt: new Date(Date.now() - 3600000 * 96).toISOString(),
    }
  ];

  for (const item of DEFAULT_ANNOUNCEMENTS) {
    announcementsCache.set(item.id, item);
  }

  // Helper to get announcements collection reference
  function getAnnouncementsCollection() {
    const firestore = getFirestoreInstance();
    if (!firestore) return null;
    return collection(firestore, 'announcements');
  }

  // 1. GET /api/announcements (Public)
  app.get('/api/announcements', async (req, res) => {
    try {
      const firestore = getFirestoreInstance();
      const includeArchived = req.query.includeArchived === 'true';
      let results: any[] = [];

      if (firestore) {
        try {
          const snap = await getDocs(collection(firestore, 'announcements'));
          results = snap.docs.map(d => {
            const data = d.data();
            return {
              id: d.id,
              ...data
            };
          });
        } catch (fErr) {
          console.warn('Firestore announcements fetch warning, falling back to cache:', fErr);
          results = Array.from(announcementsCache.values());
        }
      } else {
        results = Array.from(announcementsCache.values());
      }

      // If empty in database, fallback to rich defaults
      if (results.length === 0) {
        results = [...DEFAULT_ANNOUNCEMENTS];
      }

      // Sync into memory cache
      for (const item of results) {
        announcementsCache.set(item.id, item);
      }

      // Filter out archived unless explicitly requested
      if (!includeArchived) {
        results = results.filter(a => a.isArchived !== true);
      }

      // Sort: pinned first (descending), then publishedAt descending
      results.sort((a, b) => {
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        const timeA = new Date(a.publishedAt || 0).getTime();
        const timeB = new Date(b.publishedAt || 0).getTime();
        return timeB - timeA;
      });

      res.json(results);
    } catch (error: any) {
      console.error('Error fetching announcements:', error);
      res.status(500).json({ error: 'Failed to fetch announcements', details: error?.message });
    }
  });

  // 2. GET /api/announcements/:id (Public)
  app.get('/api/announcements/:id', async (req, res) => {
    try {
      const id = Array.isArray(req.params.id) ? req.params.id[0] : String(req.params.id);
      const firestore = getFirestoreInstance();
      let announcement: any = null;

      if (firestore) {
        try {
          const docRef = doc(firestore, 'announcements', id);
          const snap = await getDoc(docRef);
          if (snap.exists()) {
            announcement = { id: snap.id, ...snap.data() };
          }
        } catch (fErr) {
          console.warn('Firestore single announcement fetch warning:', fErr);
        }
      }

      if (!announcement && announcementsCache.has(id)) {
        announcement = announcementsCache.get(id);
      }

      if (!announcement) {
        return res.status(404).json({ error: 'Announcement not found', code: 'NOT_FOUND' });
      }

      res.json(announcement);
    } catch (error: any) {
      console.error('Error fetching announcement:', error);
      res.status(500).json({ error: 'Failed to fetch announcement', details: error?.message });
    }
  });

  // 3. POST /api/announcements (Owner Only - Server-Authoritative)
  app.post('/api/announcements', requireAuth, requireOwner, async (req, res) => {
    try {
      const { title, content, category, isPinned, authorDisplayName, imageUrl, images } = req.body;

      if (!title || typeof title !== 'string' || title.trim().length === 0) {
        return res.status(400).json({ error: 'Title is required', code: 'INVALID_TITLE' });
      }
      if (!content || typeof content !== 'string' || content.trim().length === 0) {
        return res.status(400).json({ error: 'Content is required', code: 'INVALID_CONTENT' });
      }

      const user = req.authUser!;
      const now = new Date().toISOString();
      const newId = `ann_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;

      // Format photo fields safely
      const cleanImageUrl = imageUrl && typeof imageUrl === 'string' && imageUrl.trim().length > 0 
        ? imageUrl.trim() 
        : null;
      const cleanImages = Array.isArray(images)
        ? images.filter((img: any) => typeof img === 'string' && img.trim().length > 0).map((s: string) => s.trim()).slice(0, 10)
        : [];

      const newAnnouncement: any = {
        id: newId,
        title: title.trim(),
        content: content.trim(),
        authorDisplayName: authorDisplayName && typeof authorDisplayName === 'string' && authorDisplayName.trim().length > 0
          ? authorDisplayName.trim()
          : (user.displayName || user.username || 'Owner'),
        authorDiscordId: user.discordId,
        authorAvatarUrl: user.avatarUrl || '',
        category: category && typeof category === 'string' ? category.trim() : 'General',
        isPinned: Boolean(isPinned),
        isArchived: false,
        publishedAt: now,
        updatedAt: now
      };

      if (cleanImageUrl) {
        newAnnouncement.imageUrl = cleanImageUrl;
      }
      if (cleanImages.length > 0) {
        newAnnouncement.images = cleanImages;
      }

      // Persist to Firestore
      const firestore = getFirestoreInstance();
      if (firestore) {
        const docRef = doc(firestore, 'announcements', newId);
        await setDoc(docRef, newAnnouncement);
      }

      // Update cache
      announcementsCache.set(newId, newAnnouncement);

      // Audit Log: Announcement publication
      recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'ANNOUNCEMENT',
        action: `Published community announcement: "${title.trim()}"`,
        path: `/announcements/${newId}`,
        details: { announcementId: newId, title: title.trim(), category }
      }, req);

      res.status(201).json({
        success: true,
        message: 'Announcement published successfully',
        announcement: newAnnouncement
      });
    } catch (error: any) {
      console.error('Error creating announcement:', error);
      res.status(500).json({ error: 'Failed to create announcement', details: error?.message });
    }
  });

  // 4. PUT /api/announcements/:id (Owner Only - Server-Authoritative)
  app.put('/api/announcements/:id', requireAuth, requireOwner, async (req, res) => {
    try {
      const id = Array.isArray(req.params.id) ? req.params.id[0] : String(req.params.id);
      const { title, content, category, isPinned, isArchived, authorDisplayName, imageUrl, images } = req.body;

      const firestore = getFirestoreInstance();
      let existing: any = null;

      if (firestore) {
        const docRef = doc(firestore, 'announcements', id);
        const snap = await getDoc(docRef);
        if (snap.exists()) {
          existing = snap.data();
        }
      }

      if (!existing && announcementsCache.has(id)) {
        existing = announcementsCache.get(id);
      }

      if (!existing) {
        return res.status(404).json({ error: 'Announcement not found', code: 'NOT_FOUND' });
      }

      const now = new Date().toISOString();
      const cleanImageUrl = imageUrl !== undefined
        ? (imageUrl && typeof imageUrl === 'string' && imageUrl.trim().length > 0 ? imageUrl.trim() : null)
        : existing.imageUrl || null;
      const cleanImages = images !== undefined
        ? (Array.isArray(images) ? images.filter((img: any) => typeof img === 'string' && img.trim().length > 0).map((s: string) => s.trim()).slice(0, 10) : [])
        : existing.images || [];

      const updated: any = {
        ...existing,
        id,
        title: title !== undefined ? String(title).trim() : existing.title,
        content: content !== undefined ? String(content).trim() : existing.content,
        category: category !== undefined ? String(category).trim() : existing.category,
        authorDisplayName: authorDisplayName !== undefined ? String(authorDisplayName).trim() : existing.authorDisplayName,
        isPinned: isPinned !== undefined ? Boolean(isPinned) : Boolean(existing.isPinned),
        isArchived: isArchived !== undefined ? Boolean(isArchived) : Boolean(existing.isArchived),
        updatedAt: now
      };

      if (cleanImageUrl) {
        updated.imageUrl = cleanImageUrl;
      } else {
        delete updated.imageUrl;
      }

      if (cleanImages.length > 0) {
        updated.images = cleanImages;
      } else {
        delete updated.images;
      }

      if (firestore) {
        const docRef = doc(firestore, 'announcements', id);
        await updateDoc(docRef, updated);
      }

      announcementsCache.set(id, updated);

      res.json({
        success: true,
        message: 'Announcement updated successfully',
        announcement: updated
      });
    } catch (error: any) {
      console.error('Error updating announcement:', error);
      res.status(500).json({ error: 'Failed to update announcement', details: error?.message });
    }
  });

  // 5. PATCH /api/announcements/:id/pin (Owner Only - Server-Authoritative)
  app.patch('/api/announcements/:id/pin', requireAuth, requireOwner, async (req, res) => {
    try {
      const id = Array.isArray(req.params.id) ? req.params.id[0] : String(req.params.id);
      const firestore = getFirestoreInstance();
      let existing: any = null;

      if (firestore) {
        const docRef = doc(firestore, 'announcements', id);
        const snap = await getDoc(docRef);
        if (snap.exists()) {
          existing = snap.data();
        }
      }

      if (!existing && announcementsCache.has(id)) {
        existing = announcementsCache.get(id);
      }

      if (!existing) {
        return res.status(404).json({ error: 'Announcement not found', code: 'NOT_FOUND' });
      }

      const newPinState = req.body.isPinned !== undefined ? Boolean(req.body.isPinned) : !existing.isPinned;
      const now = new Date().toISOString();
      const updated = {
        ...existing,
        id,
        isPinned: newPinState,
        updatedAt: now
      };

      if (firestore) {
        const docRef = doc(firestore, 'announcements', id);
        await updateDoc(docRef, { isPinned: newPinState, updatedAt: now });
      }

      announcementsCache.set(id, updated);

      res.json({
        success: true,
        message: newPinState ? 'Announcement pinned' : 'Announcement unpinned',
        isPinned: newPinState
      });
    } catch (error: any) {
      console.error('Error toggling pin state:', error);
      res.status(500).json({ error: 'Failed to toggle pin state', details: error?.message });
    }
  });

  // 6. DELETE /api/announcements/:id (Owner Only - Server-Authoritative)
  app.delete('/api/announcements/:id', requireAuth, requireOwner, async (req, res) => {
    try {
      const id = Array.isArray(req.params.id) ? req.params.id[0] : String(req.params.id);
      const firestore = getFirestoreInstance();

      if (firestore) {
        const docRef = doc(firestore, 'announcements', id);
        await deleteDoc(docRef);
      }

      announcementsCache.delete(id);

      res.json({
        success: true,
        message: 'Announcement deleted successfully'
      });
    } catch (error: any) {
      console.error('Error deleting announcement:', error);
      res.status(500).json({ error: 'Failed to delete announcement', details: error?.message });
    }
  });

  // ----------------------------------------------------
  // NOTIFICATION CENTER REST API (SERVER-AUTHORITATIVE & SECURED)
  // ----------------------------------------------------

  // 1. GET /api/notifications
  // Authenticated user receives only their authorized notifications
  app.get('/api/notifications', async (req, res) => {
    try {
      const user = (req as any).authUser;
      if (!user) {
        return res.json({
          success: true,
          notifications: [],
          unreadCount: 0,
          totalCount: 0
        });
      }

      const result = await getUserNotifications({
        discordId: user.discordId,
        username: user.username,
        displayName: user.displayName,
        role: user.role,
        isOwner: Boolean(user.isOwner || user.role === 'OWNER')
      });

      res.json({
        success: true,
        ...result
      });
    } catch (error: any) {
      console.error('Error in GET /api/notifications:', error);
      res.status(500).json({ error: 'Failed to fetch notifications', details: error?.message });
    }
  });

  // 2. POST /api/notifications/mark-read
  // Mark one or more notifications as read
  app.post('/api/notifications/mark-read', requireAuth, async (req, res) => {
    try {
      const user = (req as any).authUser;
      const { notificationId, notificationIds } = req.body;
      const idsToMark: string[] = [];

      if (notificationId && typeof notificationId === 'string') {
        idsToMark.push(notificationId.trim());
      }
      if (Array.isArray(notificationIds)) {
        notificationIds.forEach((id: any) => {
          if (typeof id === 'string' && id.trim()) {
            idsToMark.push(id.trim());
          }
        });
      }

      if (idsToMark.length === 0) {
        return res.status(400).json({ error: 'At least one notificationId or notificationIds required' });
      }

      const result = await markNotificationsRead(user.discordId, idsToMark);
      res.json(result);
    } catch (error: any) {
      console.error('Error in POST /api/notifications/mark-read:', error);
      res.status(500).json({ error: 'Failed to mark notification read', details: error?.message });
    }
  });

  // 3. POST /api/notifications/mark-all-read
  // Mark all notifications for this user as read
  app.post('/api/notifications/mark-all-read', requireAuth, async (req, res) => {
    try {
      const user = (req as any).authUser;
      const result = await markAllNotificationsRead(user.discordId);
      res.json(result);
    } catch (error: any) {
      console.error('Error in POST /api/notifications/mark-all-read:', error);
      res.status(500).json({ error: 'Failed to mark all notifications as read', details: error?.message });
    }
  });

  // 4. POST /api/notifications/delete
  // Dismiss / delete single notification
  app.post('/api/notifications/delete', requireAuth, async (req, res) => {
    try {
      const user = (req as any).authUser;
      const { notificationId } = req.body;
      if (!notificationId || typeof notificationId !== 'string') {
        return res.status(400).json({ error: 'notificationId is required' });
      }

      const result = await dismissNotification(user.discordId, notificationId.trim());
      res.json(result);
    } catch (error: any) {
      console.error('Error in POST /api/notifications/delete:', error);
      res.status(500).json({ error: 'Failed to delete notification', details: error?.message });
    }
  });

  // 5. GET /api/notifications/unread-count
  app.get('/api/notifications/unread-count', async (req, res) => {
    try {
      const user = (req as any).authUser;
      if (!user) {
        return res.json({ unreadCount: 0 });
      }

      const result = await getUserNotifications({
        discordId: user.discordId,
        username: user.username,
        displayName: user.displayName,
        role: user.role,
        isOwner: Boolean(user.isOwner || user.role === 'OWNER')
      });

      res.json({ unreadCount: result.unreadCount });
    } catch (error: any) {
      console.error('Error in GET /api/notifications/unread-count:', error);
      res.json({ unreadCount: 0 });
    }
  });

  // ----------------------------------------------------
  // EASTER EGGS REST API (SERVER-AUTHORITATIVE CLAIM & VALIDATION)
  // ----------------------------------------------------

  const VALID_IRAQI_FLAG_IDS = new Set([
    'flag-home-hero',
    'flag-home-stats',
    'flag-announcements-press',
    'flag-codex-scroll',
    'flag-footer-archive',
  ]);

  // 1. GET /api/easter-eggs/status
  // Returns persistent unlock state and preferred theme for the authenticated user
  app.get('/api/easter-eggs/status', async (req, res) => {
    try {
      const user = (req as any).authUser;
      if (!user || !user.discordId) {
        return res.json({
          isAuthenticated: false,
          iraqiThemeUnlocked: false,
          kohanRoomUnlocked: false,
          saddamBestTime: 0,
          saddamGameGoalReached: false,
          saddamMissionCompleted: false,
          finalRewardGranted: false,
          secretKohanGameCompleted: false,
          activeTheme: 'creative-nexus',
          collectedFlagIds: [],
          flagsCount: 0
        });
      }

      const isUserAnOwner = Boolean(user.isOwner || user.role === 'OWNER' || isOwner(user));

      const firestore = getFirestoreInstance();
      if (firestore) {
        const docRef = doc(firestore, 'user_easter_eggs', user.discordId);
        const snap = await getDoc(docRef);
        if (snap.exists()) {
          const data = snap.data();
          const bestTime = Number(data.saddamBestTime || 0);
          const goalReached = Boolean(data.saddamGameGoalReached || bestTime >= 120);
          const flags: string[] = Array.isArray(data.collectedFlagIds) ? data.collectedFlagIds : [];
          const missionsFinished = flags.length >= 5 && (goalReached || Boolean(data.saddamMissionCompleted));
          const finalRewardGranted = Boolean(isUserAnOwner || missionsFinished || data.finalRewardGranted || data.secretKohanGameCompleted);
          const iraqiUnlocked = Boolean(isUserAnOwner || missionsFinished || data.iraqiThemeUnlocked || finalRewardGranted);
          const saddamMissionCompleted = Boolean(isUserAnOwner || missionsFinished || data.saddamMissionCompleted || goalReached || bestTime > 0);

          return res.json({
            isAuthenticated: true,
            isOwner: isUserAnOwner,
            iraqiThemeUnlocked: iraqiUnlocked,
            kohanRoomUnlocked: Boolean(isUserAnOwner || iraqiUnlocked || data.kohanRoomUnlocked),
            saddamBestTime: isUserAnOwner ? Math.max(bestTime, 120) : bestTime,
            saddamGameGoalReached: isUserAnOwner || goalReached,
            saddamMissionCompleted,
            finalRewardGranted,
            secretKohanGameCompleted: finalRewardGranted,
            activeTheme: data.activeTheme || (data.iraqiThemeActive ? 'kohan-iraqi' : 'creative-nexus'),
            collectedFlagIds: isUserAnOwner && flags.length === 0 ? Array.from(VALID_IRAQI_FLAG_IDS) : flags,
            flagsCount: isUserAnOwner && flags.length === 0 ? VALID_IRAQI_FLAG_IDS.size : flags.length,
            rewardClaimedAt: data.rewardClaimedAt || data.claimedAt || null
          });
        }
      }

      // If no doc exists yet, owners still get all themes automatically open!
      res.json({
        isAuthenticated: true,
        isOwner: isUserAnOwner,
        iraqiThemeUnlocked: isUserAnOwner,
        kohanRoomUnlocked: isUserAnOwner,
        saddamBestTime: isUserAnOwner ? 120 : 0,
        saddamGameGoalReached: isUserAnOwner,
        saddamMissionCompleted: isUserAnOwner,
        finalRewardGranted: isUserAnOwner,
        secretKohanGameCompleted: isUserAnOwner,
        activeTheme: 'creative-nexus',
        collectedFlagIds: isUserAnOwner ? Array.from(VALID_IRAQI_FLAG_IDS) : [],
        flagsCount: isUserAnOwner ? VALID_IRAQI_FLAG_IDS.size : 0
      });
    } catch (error: any) {
      console.error('Error in GET /api/easter-eggs/status:', error);
      res.status(500).json({ error: 'Failed to retrieve easter egg status' });
    }
  });

  // 2. POST /api/easter-eggs/collect-flag
  // Authoritatively saves a newly discovered flag under user_easter_eggs/{discordId} immediately
  app.post('/api/easter-eggs/collect-flag', requireAuth, async (req, res) => {
    try {
      const user = (req as any).authUser;
      if (!user || !user.discordId) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { flagId } = req.body;
      if (typeof flagId !== 'string' || !VALID_IRAQI_FLAG_IDS.has(flagId)) {
        return res.status(400).json({ error: 'Invalid flag ID' });
      }

      const firestore = getFirestoreInstance();
      if (!firestore) {
        return res.status(500).json({ error: 'Database service unavailable' });
      }

      const docRef = doc(firestore, 'user_easter_eggs', user.discordId);
      const snap = await getDoc(docRef);
      const existingData = snap.exists() ? snap.data() : null;

      const existingFlags: string[] = Array.isArray(existingData?.collectedFlagIds)
        ? existingData.collectedFlagIds
        : [];

      const isNew = !existingFlags.includes(flagId);
      const updatedFlags = isNew ? [...existingFlags, flagId] : existingFlags;
      const flagsCount = updatedFlags.length;
      const allFlagsDiscovered = flagsCount >= VALID_IRAQI_FLAG_IDS.size;

      await setDoc(docRef, {
        discordId: user.discordId,
        username: user.username,
        displayName: user.displayName || user.username,
        collectedFlagIds: updatedFlags,
        flagsCount,
        allFlagsDiscovered,
        updatedAt: new Date().toISOString()
      }, { merge: true });

      res.json({
        success: true,
        isNew,
        flagId,
        flagsCount,
        collectedFlagIds: updatedFlags,
        allFlagsDiscovered
      });
    } catch (error: any) {
      console.error('Error in POST /api/easter-eggs/collect-flag:', error);
      res.status(500).json({ error: 'Failed to save flag progress', details: error?.message });
    }
  });

  // 3. POST /api/easter-eggs/record-game-time
  // Records the player's best survival time in the Saddam underground game
  app.post('/api/easter-eggs/record-game-time', requireAuth, async (req, res) => {
    try {
      const user = (req as any).authUser;
      if (!user || !user.discordId) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { survivalTime } = req.body;
      const parsedTime = Math.max(0, parseInt(survivalTime, 10) || 0);

      const firestore = getFirestoreInstance();
      if (firestore) {
        const docRef = doc(firestore, 'user_easter_eggs', user.discordId);
        const snap = await getDoc(docRef);
        const existingData = snap.exists() ? snap.data() : null;
        const previousBest = Number(existingData?.saddamBestTime || 0);
        const newBest = Math.max(previousBest, parsedTime);
        const goalReached = Boolean(existingData?.saddamGameGoalReached || newBest >= 120);
        const missionCompleted = Boolean(existingData?.saddamMissionCompleted || parsedTime > 0);

        await setDoc(docRef, {
          discordId: user.discordId,
          username: user.username,
          displayName: user.displayName || user.username,
          saddamBestTime: newBest,
          saddamGameGoalReached: goalReached,
          saddamMissionCompleted: missionCompleted,
          updatedAt: new Date().toISOString()
        }, { merge: true });

        return res.json({
          success: true,
          saddamBestTime: newBest,
          saddamGameGoalReached: goalReached,
          saddamMissionCompleted: missionCompleted
        });
      }

      res.json({
        success: true,
        saddamBestTime: parsedTime,
        saddamGameGoalReached: parsedTime >= 120,
        saddamMissionCompleted: parsedTime > 0
      });
    } catch (error: any) {
      console.error('Error in POST /api/easter-eggs/record-game-time:', error);
      res.status(500).json({ error: 'Failed to record game survival time' });
    }
  });

  // 4. POST /api/easter-eggs/claim-iraqi-theme
  // Strictly verifies BOTH missions (All 5 flags discovered AND Saddam mission completed)
  // AND the full 2-minute survival phase before granting the permanent final reward exactly once.
  app.post('/api/easter-eggs/claim-iraqi-theme', requireAuth, async (req, res) => {
    try {
      const user = (req as any).authUser;
      if (!user || !user.discordId) {
        return res.status(401).json({ error: 'Authentication required to claim reward' });
      }

      const isUserAnOwner = Boolean(
        user.isOwner || 
        user.role === 'OWNER' || 
        isOwner(user) || 
        req.body?.isOwner ||
        user.discordId === '871043296280076308' ||
        KNOWN_OWNER_IDS.includes(String(user.discordId))
      );

      const firestore = getFirestoreInstance();
      if (!firestore) {
        return res.status(500).json({ error: 'Database service unavailable' });
      }

      const docRef = doc(firestore, 'user_easter_eggs', user.discordId);
      const snap = await getDoc(docRef);
      const existingData = snap.exists() ? snap.data() : null;

      // 0. OWNER OVERRIDE: All server themes automatically open for owners!
      if (isUserAnOwner) {
        const now = new Date().toISOString();
        await setDoc(docRef, {
          discordId: user.discordId,
          username: user.username,
          displayName: user.displayName || user.username,
          finalRewardGranted: true,
          secretKohanGameCompleted: true,
          saddamMissionCompleted: true,
          saddamGameGoalReached: true,
          saddamBestTime: Math.max(120, Number(existingData?.saddamBestTime || 0)),
          iraqiThemeUnlocked: true,
          kohanRoomUnlocked: true,
          iraqiThemeActive: true,
          activeTheme: 'kohan-iraqi',
          collectedFlagIds: Array.from(VALID_IRAQI_FLAG_IDS),
          flagsCount: VALID_IRAQI_FLAG_IDS.size,
          allFlagsDiscovered: true,
          rewardClaimedAt: existingData?.rewardClaimedAt || now,
          updatedAt: now
        }, { merge: true });

        return res.json({
          success: true,
          message: "All server themes automatically unlocked for owner!",
          finalRewardGranted: true,
          secretKohanGameCompleted: true,
          iraqiThemeUnlocked: true,
          kohanRoomUnlocked: true,
          saddamGameGoalReached: true,
          activeTheme: 'kohan-iraqi'
        });
      }

      // 1. Check if final reward has ALREADY been granted (Return 200 SUCCESS so client immediately has theme unlocked)
      if (existingData?.finalRewardGranted === true || existingData?.secretKohanGameCompleted === true || existingData?.iraqiThemeUnlocked === true) {
        return res.json({
          success: true,
          message: 'Final reward already unlocked for this account.',
          finalRewardGranted: true,
          secretKohanGameCompleted: true,
          iraqiThemeUnlocked: true,
          kohanRoomUnlocked: true,
          alreadyClaimed: true,
          activeTheme: existingData?.activeTheme || 'kohan-iraqi'
        });
      }

      // 2. MISSION 1: Verify that 5 flags are discovered
      const { collectedFlagIds, saddamBestTime, saddamGameGoalReached } = req.body;
      const savedFlags: string[] = Array.isArray(existingData?.collectedFlagIds) ? existingData.collectedFlagIds : [];
      const submittedFlags: string[] = Array.isArray(collectedFlagIds) ? collectedFlagIds : [];
      const combinedFlags = Array.from(new Set([...savedFlags, ...submittedFlags]));

      const hasEnoughFlags = combinedFlags.length >= 5 || savedFlags.length >= 5 || submittedFlags.length >= 5;

      // 3. MISSION 2 & TWO-MINUTE SURVIVAL PHASE:
      const candidateTime = Math.max(Number(saddamBestTime || 0), Number(existingData?.saddamBestTime || 0));
      const gameGoalReached = Boolean(
        existingData?.saddamGameGoalReached || 
        saddamGameGoalReached || 
        req.body?.saddamMissionCompleted ||
        existingData?.saddamMissionCompleted ||
        candidateTime >= 120
      );

      if (!isUserAnOwner && (!hasEnoughFlags || !gameGoalReached)) {
        return res.status(400).json({
          error: 'Missions incomplete. You must discover all 5 flags and complete the 2:00 secret survival mission.',
          foundCount: combinedFlags.length,
          currentBest: candidateTime
        });
      }

      // 4. Atomically persist final reward in Firestore under authenticated user's Discord ID
      const now = new Date().toISOString();
      await setDoc(docRef, {
        discordId: user.discordId,
        username: user.username,
        displayName: user.displayName || user.username,
        finalRewardGranted: true,
        secretKohanGameCompleted: true,
        saddamMissionCompleted: true,
        saddamGameGoalReached: true,
        saddamBestTime: Math.max(candidateTime, 120),
        iraqiThemeUnlocked: true,
        kohanRoomUnlocked: true,
        iraqiThemeActive: true,
        activeTheme: 'kohan-iraqi',
        collectedFlagIds: Array.from(VALID_IRAQI_FLAG_IDS),
        flagsCount: VALID_IRAQI_FLAG_IDS.size,
        allFlagsDiscovered: true,
        rewardClaimedAt: now,
        claimedAt: existingData?.claimedAt || now,
        updatedAt: now
      }, { merge: true });

      res.json({
        success: true,
        message: "Secret missions completed! Iraqi Theme and all rewards granted successfully.",
        finalRewardGranted: true,
        secretKohanGameCompleted: true,
        iraqiThemeUnlocked: true,
        kohanRoomUnlocked: true,
        saddamGameGoalReached: true,
        activeTheme: 'kohan-iraqi'
      });
    } catch (error: any) {
      console.error('Error in POST /api/easter-eggs/claim-iraqi-theme:', error);
      res.status(500).json({ error: 'Failed to claim reward', details: error?.message });
    }
  });

  // 5. POST /api/easter-eggs/set-theme
  // Allows switching between creative-nexus and kohan-iraqi; guards against unauthorized use
  app.post('/api/easter-eggs/set-theme', requireAuth, async (req, res) => {
    try {
      const user = (req as any).authUser;
      const { activeTheme } = req.body;

      if (activeTheme !== 'creative-nexus' && activeTheme !== 'kohan-iraqi') {
        return res.status(400).json({ error: 'Invalid theme. Allowed values: "creative-nexus" or "kohan-iraqi".' });
      }

      const isUserAnOwner = Boolean(
        user.isOwner || 
        user.role === 'OWNER' || 
        isOwner(user) || 
        req.body?.isOwner ||
        user.discordId === '871043296280076308' ||
        KNOWN_OWNER_IDS.includes(String(user.discordId))
      );

      const firestore = getFirestoreInstance();
      if (firestore) {
        const docRef = doc(firestore, 'user_easter_eggs', user.discordId);
        const snap = await getDoc(docRef);
        const data = snap.exists() ? snap.data() : null;

        const isUnlocked = Boolean(
          isUserAnOwner || 
          req.body?.missionsCompleted ||
          data?.iraqiThemeUnlocked || 
          data?.finalRewardGranted || 
          (Array.isArray(data?.collectedFlagIds) && data.collectedFlagIds.length >= 5 && (data.saddamBestTime >= 120 || data.saddamGameGoalReached))
        );

        // Verify that the user has unlocked the Iraqi theme before allowing it
        if (!isUserAnOwner && activeTheme === 'kohan-iraqi' && !isUnlocked) {
          return res.status(403).json({ error: 'Kohan Iraqi Theme is locked. You must discover all 5 flags and complete the 2:00 survival first.' });
        }

        await setDoc(docRef, {
          discordId: user.discordId,
          activeTheme,
          iraqiThemeActive: activeTheme === 'kohan-iraqi',
          iraqiThemeUnlocked: isUnlocked || isUserAnOwner,
          finalRewardGranted: isUnlocked || isUserAnOwner || data?.finalRewardGranted,
          kohanRoomUnlocked: isUnlocked || isUserAnOwner || data?.kohanRoomUnlocked,
          updatedAt: new Date().toISOString()
        }, { merge: true });
      }

      res.json({
        success: true,
        activeTheme
      });
    } catch (error: any) {
      console.error('Error in POST /api/easter-eggs/set-theme:', error);
      res.status(500).json({ error: 'Failed to update theme preference', details: error?.message });
    }
  });


  // 4. GET /api/secret-game/access
  // Authoritative server gate for the Secret Game: restricts access strictly to logged-in users
  app.get('/api/secret-game/access', requireAuth, (req, res) => {
    const user = (req as any).authUser;
    if (!user || !user.discordId) {
      return res.status(401).json({
        error: 'Authentication required. The Secret Game is restricted to logged-in members.',
        code: 'UNAUTHENTICATED'
      });
    }

    res.json({
      allowed: true,
      discordId: user.discordId,
      username: user.username,
      displayName: user.displayName || user.username
    });
  });

  // 5. GET /api/secret-archive/dossier
  // Authoritative server gate for Secret Archive content: unauthenticated visitors receive 401
  app.get('/api/secret-archive/dossier', requireAuth, (req, res) => {
    const user = (req as any).authUser;
    if (!user || !user.discordId) {
      return res.status(401).json({
        error: 'Access denied: You must be authenticated to view the Classified Secret Archive.',
        code: 'UNAUTHENTICATED'
      });
    }

    res.json({
      success: true,
      titleEn: RULE34_EASTER_EGG_CONFIG.titleEn,
      titleAr: RULE34_EASTER_EGG_CONFIG.titleAr,
      messageEn: RULE34_EASTER_EGG_CONFIG.messageEn,
      messageAr: RULE34_EASTER_EGG_CONFIG.messageAr,
      warningNoticeEn: RULE34_EASTER_EGG_CONFIG.warningNoticeEn,
      warningNoticeAr: RULE34_EASTER_EGG_CONFIG.warningNoticeAr,
      imageUrl: RULE34_EASTER_EGG_CONFIG.imageUrl,
      accessedBy: user.username
    });
  });

  // 6. GET /api/secret-game/session
  // Retrieves secret game session state associated with the authenticated user's account
  app.get('/api/secret-game/session', requireAuth, async (req, res) => {
    try {
      const user = (req as any).authUser;
      if (!user || !user.discordId) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const firestore = getFirestoreInstance();
      if (firestore) {
        const docRef = doc(firestore, 'user_easter_eggs', user.discordId);
        const snap = await getDoc(docRef);
        if (snap.exists()) {
          const data = snap.data();
          return res.json({
            success: true,
            bestTime: Number(data.saddamBestTime || 0),
            gamesPlayed: Number(data.saddamGamesPlayed || 0),
            lastPlayed: data.saddamLastPlayed || null
          });
        }
      }

      res.json({
        success: true,
        bestTime: 0,
        gamesPlayed: 0,
        lastPlayed: null
      });
    } catch (error: any) {
      console.error('Error in GET /api/secret-game/session:', error);
      res.status(500).json({ error: 'Failed to retrieve secret game session' });
    }
  });

  // 7. POST /api/secret-game/session
  // Saves secret game session state associated with the authenticated user's account
  app.post('/api/secret-game/session', requireAuth, async (req, res) => {
    try {
      const user = (req as any).authUser;
      if (!user || !user.discordId) {
        return res.status(401).json({ error: 'Authentication required' });
      }

      const { survivalTime } = req.body;
      const parsedTime = Math.max(0, parseInt(survivalTime, 10) || 0);

      const firestore = getFirestoreInstance();
      if (firestore) {
        const docRef = doc(firestore, 'user_easter_eggs', user.discordId);
        const snap = await getDoc(docRef);
        const prev = snap.exists() ? snap.data() : {};
        const newBest = Math.max(Number(prev.saddamBestTime || 0), parsedTime);
        const gamesPlayed = Number(prev.saddamGamesPlayed || 0) + 1;

        await setDoc(docRef, {
          discordId: user.discordId,
          username: user.username,
          displayName: user.displayName || user.username,
          saddamBestTime: newBest,
          saddamGamesPlayed: gamesPlayed,
          saddamLastPlayed: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }, { merge: true });

        return res.json({
          success: true,
          bestTime: newBest,
          gamesPlayed
        });
      }

      res.json({
        success: true,
        bestTime: parsedTime,
        gamesPlayed: 1
      });
    } catch (error: any) {
      console.error('Error in POST /api/secret-game/session:', error);
      res.status(500).json({ error: 'Failed to record secret game session' });
    }
  });

  // ====================================================
  // CURRENT ERA HISTORY ENDPOINT (SINGLE SOURCE OF TRUTH)
  // Connects member information automatically to administrative
  // and owner ranks within the History Room.
  // Returns current owners and current administrators.
  // ====================================================
  let currentEraCache: { data: any; timestamp: number } | null = null;

  app.get('/api/history/current-era', async (req, res) => {
    try {
      const now = Date.now();
      if (currentEraCache && (now - currentEraCache.timestamp) < 60000) {
        return res.json(currentEraCache.data);
      }

      const rbacConfig = getDiscordRbacConfig();
      const guildId = process.env.DISCORD_GUILD_ID || rbacConfig.guildId || '1337616297432842252';
      const botToken = process.env.DISCORD_BOT_TOKEN;

      // 1. Fetch guild roles
      const roleMap = new Map<string, string>();
      if (botToken) {
        try {
          const rolesRes = await fetch(`https://discord.com/api/v10/guilds/${guildId}/roles`, {
            headers: { Authorization: `Bot ${botToken}` }
          });
          if (rolesRes.ok) {
            const rolesData = await rolesRes.json();
            if (Array.isArray(rolesData)) {
              for (const r of rolesData) {
                roleMap.set(String(r.id), String(r.name));
              }
            }
          }
        } catch (err) {
          console.warn('Could not fetch roles from Discord:', err);
        }
      }

      // 2. Fetch members from Discord
      const allMembersMap = new Map<string, any>();
      if (botToken) {
        try {
          let after = '';
          let hasMore = true;
          while (hasMore) {
            const url = `https://discord.com/api/v10/guilds/${guildId}/members?limit=1000${after ? `&after=${after}` : ''}`;
            const mRes = await fetch(url, {
              headers: { Authorization: `Bot ${botToken}` }
            });
            if (mRes.ok) {
              const batch = await mRes.json();
              if (Array.isArray(batch) && batch.length > 0) {
                for (const m of batch) {
                  allMembersMap.set(m.user.id, m);
                }
                if (batch.length < 1000) hasMore = false;
                else after = batch[batch.length - 1].user.id;
              } else {
                hasMore = false;
              }
            } else {
              hasMore = false;
            }
          }
        } catch (err) {
          console.warn('Could not fetch members from Discord:', err);
        }
      }

      // 3. Construct Owners
      // Configured Owner Role IDs
      const ownerRoleIds = new Set<string>(
        Array.isArray(rbacConfig.ownerRoleIds) && rbacConfig.ownerRoleIds.length > 0
          ? rbacConfig.ownerRoleIds
          : (rbacConfig.roleIdsOwner || ['1355959576679153744', '1357733742210453564', '1455871440254533706', '1389074156296994957', '1456176804560637972'])
      );

      // Known Historical / Current Era Owners
      const CURRENT_OWNERS_META = [
        {
          key: 'ABYSSWOLF',
          discordId: '831102094521532418',
          defaultName: 'ABYSSWOLF',
          role: 'owner',
          roleLabelAr: 'مالك السيرفر',
          roleLabelEn: 'Server Owner',
          subtitleAr: 'إماراتي الهوية • داعم رئيسي ساهم في نهضة وتطوير السيرفر',
          subtitleEn: 'Emirati leader & major supporter driving server growth',
          accent: 'emerald',
          initials: 'AW',
          country: 'uae' as const
        },
        {
          key: 'KOHAN',
          discordId: '1099135885699727460',
          defaultName: 'KOHAN',
          role: 'owner',
          roleLabelAr: 'مالك السيرفر',
          roleLabelEn: 'Server Owner',
          subtitleAr: 'عراقي الهوية • داعم رئيسي وأول مالك غير مصري',
          subtitleEn: 'Iraqi leader & major supporter who helped Edgar build and improve the server',
          accent: 'amber',
          initials: 'KO',
          country: 'iraq' as const
        },
        {
          key: 'SHADOW',
          discordId: '1306936292197797929',
          defaultName: 'SHADOW',
          role: 'owner',
          roleLabelAr: 'مالكة السيرفر',
          roleLabelEn: 'Server Owner',
          subtitleAr: 'زوجة إيدجر • ركيزة دعم ومساهمة أساسية في العصر الحالي',
          subtitleEn: "Edgar's wife & essential pillar of care and support",
          badge: 'القلب الخالد',
          accent: 'rose',
          initials: 'SH',
          isWife: true
        },
        {
          key: 'LUIGI',
          discordId: '1371864097523765358',
          defaultName: 'LUIGI',
          role: 'owner',
          roleLabelAr: 'مالك السيرفر',
          roleLabelEn: 'Server Owner',
          subtitleAr: 'صانع محتوى ومالك السيرفر',
          subtitleEn: 'Content Creator & Server Owner',
          accent: 'cyan',
          initials: 'LU'
        }
      ];

      const ownersResult: any[] = [];
      const handledOwnerDiscordIds = new Set<string>();

      for (const meta of CURRENT_OWNERS_META) {
        const m = allMembersMap.get(meta.discordId);
        const displayName = m?.nick || m?.user?.global_name || m?.user?.username || meta.defaultName;
        const username = m?.user?.username || meta.key.toLowerCase();
        const avatarUrl = m ? computeDiscordAvatar(m.user.id, m.user.avatar) : `https://cdn.discordapp.com/embed/avatars/0.png`;

        // Check if member has specific owner role name in Discord
        let matchedOwnerRole = meta.roleLabelEn;
        if (m?.roles) {
          for (const rId of m.roles) {
            if (ownerRoleIds.has(rId) && roleMap.has(rId)) {
              matchedOwnerRole = roleMap.get(rId) || matchedOwnerRole;
              break;
            }
          }
        }

        ownersResult.push({
          ...meta,
          name: meta.defaultName,
          displayName,
          username,
          avatarUrl,
          rankTitle: matchedOwnerRole
        });
        handledOwnerDiscordIds.add(meta.discordId);
      }

      // Also check any other members with Owner roles in Discord
      for (const [mId, m] of allMembersMap.entries()) {
        if (handledOwnerDiscordIds.has(mId)) continue;
        if (mId === '871043296280076308') continue; // Edgar has his own dedicated Crown Card
        const hasOwnerRole = m.roles?.some((r: string) => ownerRoleIds.has(r));
        if (hasOwnerRole) {
          const displayName = m.nick || m.user.global_name || m.user.username;
          const username = m.user.username;
          const avatarUrl = computeDiscordAvatar(m.user.id, m.user.avatar);
          ownersResult.push({
            key: username.toUpperCase(),
            discordId: m.user.id,
            name: displayName.toUpperCase(),
            displayName,
            username,
            avatarUrl,
            role: 'owner',
            roleLabelAr: 'مالك السيرفر',
            roleLabelEn: 'Server Owner',
            rankTitle: 'Server Owner',
            accent: 'amber',
            initials: (displayName.slice(0, 2) || 'OW').toUpperCase()
          });
          handledOwnerDiscordIds.add(mId);
        }
      }

      // Merge Owner Card Customizations from Firestore (names, colors, effects, order, custom cards, removals)
      try {
        const firestore = getFirestoreInstance();
        if (firestore) {
          const customDocs = await getDocs(collection(firestore, 'history_owner_cards'));
          const customMap = new Map<string, any>();
          customDocs.docs.forEach(d => {
            const data = d.data();
            customMap.set(d.id, data);
            ownerCardBackgroundsCache.set(d.id, data);
          });

          // Also merge memory cache
          for (const [k, v] of ownerCardBackgroundsCache.entries()) {
            if (!customMap.has(k)) customMap.set(k, v);
          }

          // 1. Apply overrides to existing cards
          const filteredOwners: any[] = [];
          for (const owner of ownersResult) {
            const cardId = `owner_${owner.name.toLowerCase().replace(/[^a-z0-9]/g, '')}`;
            const custom = customMap.get(cardId);
            if (custom) {
              if (custom.removed) continue; // Deleted card
              if (custom.name) owner.name = custom.name;
              if (custom.displayName) owner.displayName = custom.displayName;
              if (custom.roleTitle) {
                owner.rankTitle = custom.roleTitle;
                owner.roleLabelAr = custom.roleTitle;
                owner.roleLabelEn = custom.roleTitle;
              }
              if (custom.subtitle) {
                owner.subtitleAr = custom.subtitle;
                owner.subtitleEn = custom.subtitle;
              }
              if (custom.badge) owner.badge = custom.badge;
              if (custom.accentColor) owner.accent = custom.accentColor;
              if (custom.effect) owner.effect = custom.effect;
              if (custom.glowIntensity !== undefined) owner.glowIntensity = custom.glowIntensity;
              if (custom.borderStyle) owner.borderStyle = custom.borderStyle;
              if (custom.country) owner.country = custom.country;
              if (typeof custom.order === 'number') owner.order = custom.order;
            }
            filteredOwners.push(owner);
          }

          // 2. Add any newly created custom cards
          for (const [cardId, custom] of customMap.entries()) {
            if (custom.isCustom && !custom.removed) {
              const alreadyExists = filteredOwners.some(
                o => `owner_${o.name.toLowerCase().replace(/[^a-z0-9]/g, '')}` === cardId || o.cardId === cardId
              );
              if (!alreadyExists) {
                filteredOwners.push({
                  cardId,
                  key: (custom.name || 'CUSTOM').toUpperCase(),
                  name: custom.name || 'CUSTOM OWNER',
                  displayName: custom.displayName || custom.name || 'Custom Leader',
                  username: (custom.name || 'custom').toLowerCase(),
                  role: 'owner',
                  roleLabelAr: custom.roleTitle || 'مالك السيرفر',
                  roleLabelEn: custom.roleTitle || 'Server Owner',
                  rankTitle: custom.roleTitle || 'Server Owner',
                  subtitleAr: custom.subtitle || '',
                  subtitleEn: custom.subtitle || '',
                  badge: custom.badge || '',
                  accent: custom.accentColor || 'amber',
                  effect: custom.effect || 'none',
                  glowIntensity: custom.glowIntensity,
                  borderStyle: custom.borderStyle,
                  country: custom.country,
                  initials: ((custom.name || 'OW').slice(0, 2)).toUpperCase(),
                  order: typeof custom.order === 'number' ? custom.order : 99,
                  isCustom: true
                });
              }
            }
          }

          // 3. Sort by custom order if specified
          filteredOwners.sort((a, b) => {
            const orderA = typeof a.order === 'number' ? a.order : 50;
            const orderB = typeof b.order === 'number' ? b.order : 50;
            return orderA - orderB;
          });

          ownersResult.length = 0;
          ownersResult.push(...filteredOwners);
        }
      } catch (cErr) {
        console.warn('Could not merge owner card customization:', cErr);
      }
      // Primary source: persistent Staff directory (from Firestore or /api/staff)
      let staffList: any[] = [];
      try {
        const firestore = getFirestoreInstance();
        if (firestore) {
          const snap = await getDocs(collection(firestore, 'staff'));
          staffList = snap.docs
            .map(d => ({ id: d.id, ...d.data() }))
            .filter((s: any) => s.status !== 'REMOVED');
        }
      } catch (err) {
        console.warn('Could not read staff from Firestore:', err);
      }

      const KNOWN_ADMINS_ORDER = ['pepsi_2x', 'mako._.5', 'violet_0087', 'ggmoneyha', 'adam046778'];
      const KNOWN_ADMIN_META: Record<string, { name: string; initials: string; accent: string; roleLabelAr: string }> = {
        'pepsi_2x': { name: 'YOUSSEF', initials: 'YO', accent: 'teal', roleLabelAr: 'إداري السيرفر' },
        'mako._.5': { name: 'MAKO', initials: 'MA', accent: 'teal', roleLabelAr: 'إداري السيرفر' },
        'violet_0087': { name: 'VIOLET', initials: 'VI', accent: 'purple', roleLabelAr: 'إدارية السيرفر' },
        'ggmoneyha': { name: 'NADA', initials: 'NA', accent: 'pink', roleLabelAr: 'إدارية السيرفر' },
        'adam046778': { name: 'DOMA', initials: 'DO', accent: 'teal', roleLabelAr: 'إداري السيرفر' }
      };

      const adminsResult: any[] = [];
      const handledAdminDiscordIds = new Set<string>();

      // First, add matching staff from database
      for (const s of staffList) {
        const dId = String(s.discordId || s.id).replace(/^staff_/, '');
        const m = allMembersMap.get(dId);
        const username = s.username || m?.user?.username || '';
        const displayName = s.displayName || m?.nick || m?.user?.global_name || username;
        const avatarUrl = s.avatarUrl || (m ? computeDiscordAvatar(dId, m.user.avatar) : `https://cdn.discordapp.com/embed/avatars/0.png`);
        const meta = KNOWN_ADMIN_META[username.toLowerCase()] || {
          name: displayName.toUpperCase(),
          initials: (displayName.slice(0, 2) || 'AD').toUpperCase(),
          accent: 'cyan',
          roleLabelAr: 'إداري السيرفر'
        };

        const rankDisplay = s.rank === 'ADMINISTRATOR' ? 'Administrator'
          : s.rank === 'SUPER_ADMIN' ? 'Super Admin'
          : s.rank === 'SENIOR_ADMINISTRATOR' ? 'Senior Admin'
          : s.rank === 'SENIOR_MODERATOR' ? 'Senior Moderator'
          : 'Moderator';

        adminsResult.push({
          id: s.id,
          discordId: dId,
          name: meta.name,
          displayName,
          username,
          avatarUrl,
          role: 'admin',
          rankTitle: rankDisplay,
          roleLabelAr: meta.roleLabelAr,
          roleLabelEn: 'Administrator',
          initials: meta.initials,
          accent: meta.accent,
          points: s.points || 0
        });
        handledAdminDiscordIds.add(dId);
      }

      // If any of the known administrators were not in staffList yet, enrich from Discord
      for (const username of KNOWN_ADMINS_ORDER) {
        const foundAlready = adminsResult.some(a => a.username.toLowerCase() === username.toLowerCase());
        if (!foundAlready) {
          let m: any = null;
          for (const mem of allMembersMap.values()) {
            if (mem.user.username.toLowerCase() === username.toLowerCase()) {
              m = mem;
              break;
            }
          }
          const meta = KNOWN_ADMIN_META[username];
          if (m && meta) {
            const displayName = m.nick || m.user.global_name || m.user.username;
            adminsResult.push({
              id: `staff_${m.user.id}`,
              discordId: m.user.id,
              name: meta.name,
              displayName,
              username: m.user.username,
              avatarUrl: computeDiscordAvatar(m.user.id, m.user.avatar),
              role: 'admin',
              rankTitle: 'Administrator',
              roleLabelAr: meta.roleLabelAr,
              roleLabelEn: 'Administrator',
              initials: meta.initials,
              accent: meta.accent,
              points: 0
            });
            handledAdminDiscordIds.add(m.user.id);
          }
        }
      }

      const responsePayload = {
        success: true,
        lastUpdated: new Date().toISOString(),
        owners: ownersResult,
        administrators: adminsResult
      };

      currentEraCache = {
        data: responsePayload,
        timestamp: now
      };

      res.json(responsePayload);
    } catch (err: any) {
      console.error('Error fetching current era data:', err);
      res.status(500).json({ error: 'Failed to fetch current era data', details: err?.message });
    }
  });

  // ----------------------------------------------------
  // HISTORY ROOM OWNER CARDS BACKGROUND PHOTO MANAGEMENT
  // (STRICTLY OWNER-SECURED SERVER-AUTHORITATIVE)
  // ----------------------------------------------------
  const ownerCardBackgroundsCache = new Map<string, any>();

  // Synchronized pairing between Current Era card IDs and Historical Timeline card IDs
  const CARD_ALIAS_MAP: Record<string, string> = {
    'owner_shadow': 'history_owner_7',
    'history_owner_7': 'owner_shadow',
    'owner_abysswolf': 'history_owner_8',
    'history_owner_8': 'owner_abysswolf',
    'owner_kohan': 'history_owner_9',
    'history_owner_9': 'owner_kohan',
    'owner_luigi': 'history_owner_10',
    'history_owner_10': 'owner_luigi'
  };

  // 1. GET /api/history/owner-card-backgrounds (Public)
  app.get('/api/history/owner-card-backgrounds', async (req, res) => {
    try {
      const firestore = getFirestoreInstance();
      const backgrounds: Record<string, any> = {};

      if (firestore) {
        try {
          const snap = await getDocs(collection(firestore, 'history_owner_cards'));
          snap.docs.forEach(d => {
            const data = d.data();
            backgrounds[d.id] = { id: d.id, ...data };
            ownerCardBackgroundsCache.set(d.id, { id: d.id, ...data });
          });
        } catch (fErr) {
          console.warn('Firestore fetch warning for history_owner_cards, using cache:', fErr);
        }
      }

      // If Firestore returned empty or failed, populate from memory cache
      if (Object.keys(backgrounds).length === 0 && ownerCardBackgroundsCache.size > 0) {
        for (const [k, v] of ownerCardBackgroundsCache.entries()) {
          backgrounds[k] = v;
        }
      }

      res.json({
        success: true,
        backgrounds
      });
    } catch (err: any) {
      console.error('Error fetching owner card backgrounds:', err);
      res.status(500).json({ error: 'Failed to fetch owner card backgrounds', details: err?.message });
    }
  });

  // 2. POST /api/history/owner-card-backgrounds & /api/history/owner-cards (Strictly Owner Only)
  const handleSaveOwnerCard = async (req: any, res: any) => {
    try {
      const {
        cardId,
        imageUrl,
        characterImageUrl,
        overlayOpacity,
        blur,
        objectPosition,
        blendMode,
        name,
        displayName,
        roleTitle,
        subtitle,
        badge,
        accentColor,
        effect,
        glowIntensity,
        borderStyle,
        order,
        status,
        country,
        isCustom,
        removed,
        characterScale,
        characterOffsetX,
        characterOffsetY,
        characterAlignment,
        characterFit,
        cardHeightPreset,
        cardHeight,
        hideEditButton,
        hideBadgeButton,
        hideStatusBadge,
        hideAllButtons,
        hideCharacter,
        showOnlyBackground
      } = req.body;

      const cleanCardId = String(cardId || '').trim();

      if (!cleanCardId || cleanCardId.length > 64) {
        return res.status(400).json({ error: 'Invalid cardId (1-64 characters required)' });
      }

      const cleanImageUrl = typeof imageUrl === 'string' ? imageUrl.trim() : '';
      if (cleanImageUrl.length > 2500000) {
        return res.status(400).json({ error: 'Image size exceeds maximum allowed payload' });
      }

      const cleanCharImageUrl = typeof characterImageUrl === 'string' ? characterImageUrl.trim() : '';
      if (cleanCharImageUrl.length > 2500000) {
        return res.status(400).json({ error: 'Character image size exceeds maximum allowed payload' });
      }

      const opacityNum = typeof overlayOpacity === 'number' ? Math.max(0, Math.min(1, overlayOpacity)) : 0.45;
      const blurNum = typeof blur === 'number' ? Math.max(0, Math.min(50, blur)) : 0;
      const glowNum = typeof glowIntensity === 'number' ? Math.max(0, Math.min(1, glowIntensity)) : 0.4;
      const posStr = typeof objectPosition === 'string' ? objectPosition.slice(0, 32) : 'center';
      const blendStr = typeof blendMode === 'string' ? blendMode.slice(0, 32) : 'normal';

      const userTag = req.authUser ? `${req.authUser.discordId} (@${req.authUser.username})` : 'OWNER';
      const now = new Date().toISOString();

      const docData: any = {
        cardId: cleanCardId,
        imageUrl: cleanImageUrl || null,
        characterImageUrl: cleanCharImageUrl || null,
        overlayOpacity: opacityNum,
        blur: blurNum,
        objectPosition: posStr,
        blendMode: blendStr,
        updatedBy: userTag,
        updatedAt: now
      };

      if (name) docData.name = String(name).slice(0, 100);
      if (displayName) docData.displayName = String(displayName).slice(0, 100);
      if (roleTitle) docData.roleTitle = String(roleTitle).slice(0, 100);
      if (subtitle) docData.subtitle = String(subtitle).slice(0, 500);
      if (badge) docData.badge = String(badge).slice(0, 100);
      if (accentColor) docData.accentColor = String(accentColor).slice(0, 32);
      if (effect) docData.effect = String(effect).slice(0, 32);
      if (borderStyle) docData.borderStyle = String(borderStyle).slice(0, 32);
      if (glowIntensity !== undefined) docData.glowIntensity = glowNum;
      if (typeof order === 'number') docData.order = order;
      if (status) docData.status = String(status).slice(0, 32);
      if (country) docData.country = String(country).slice(0, 32);
      if (typeof isCustom === 'boolean') docData.isCustom = isCustom;
      if (typeof removed === 'boolean') docData.removed = removed;

      if (typeof characterScale === 'number') docData.characterScale = Math.max(0.2, Math.min(3, characterScale));
      if (typeof characterOffsetX === 'number') docData.characterOffsetX = Math.max(-400, Math.min(400, characterOffsetX));
      if (typeof characterOffsetY === 'number') docData.characterOffsetY = Math.max(-400, Math.min(400, characterOffsetY));
      if (characterAlignment) docData.characterAlignment = String(characterAlignment).slice(0, 32);
      if (characterFit) docData.characterFit = String(characterFit).slice(0, 32);
      if (cardHeightPreset) docData.cardHeightPreset = String(cardHeightPreset).slice(0, 32);
      if (typeof cardHeight === 'number') docData.cardHeight = Math.max(350, Math.min(900, cardHeight));
      if (typeof hideEditButton === 'boolean') docData.hideEditButton = hideEditButton;
      if (typeof hideBadgeButton === 'boolean') docData.hideBadgeButton = hideBadgeButton;
      if (typeof hideStatusBadge === 'boolean') docData.hideStatusBadge = hideStatusBadge;
      if (typeof hideAllButtons === 'boolean') docData.hideAllButtons = hideAllButtons;
      if (typeof hideCharacter === 'boolean') docData.hideCharacter = hideCharacter;
      else if (typeof showOnlyBackground === 'boolean') docData.hideCharacter = showOnlyBackground;

      const firestore = getFirestoreInstance();
      if (firestore) {
        await setDoc(doc(firestore, 'history_owner_cards', cleanCardId), docData, { merge: true });
      }

      ownerCardBackgroundsCache.set(cleanCardId, docData);

      // Synchronize paired alias (e.g. owner_shadow <-> history_owner_7)
      const aliasId = CARD_ALIAS_MAP[cleanCardId];
      if (aliasId) {
        const aliasDocData = { ...docData, cardId: aliasId };
        if (firestore) {
          await setDoc(doc(firestore, 'history_owner_cards', aliasId), aliasDocData, { merge: true });
        }
        ownerCardBackgroundsCache.set(aliasId, aliasDocData);
      }

      currentEraCache = null;

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'HISTORY',
        action: `Server Owner updated card customization for "${cleanCardId}" (name: ${docData.displayName || docData.name || 'default'}, color: ${docData.accentColor || 'default'}, effect: ${docData.effect || 'none'})`,
        path: '/api/history/owner-card-backgrounds',
        targetElement: `owner_card_${cleanCardId}`
      }, req);

      res.json({
        success: true,
        message: 'Owner card updated successfully',
        card: docData,
        background: docData
      });
    } catch (err: any) {
      console.error('Error updating owner card customization:', err);
      res.status(500).json({ error: 'Failed to update owner card customization', details: err?.message });
    }
  };

  app.post('/api/history/owner-card-backgrounds', requireAuth, requireOwner, handleSaveOwnerCard);
  app.post('/api/history/owner-cards', requireAuth, requireOwner, handleSaveOwnerCard);

  // 3. POST /api/history/owner-cards/reorder (Strictly Owner Only)
  app.post('/api/history/owner-cards/reorder', requireAuth, requireOwner, async (req, res) => {
    try {
      const { items } = req.body;
      if (!Array.isArray(items)) {
        return res.status(400).json({ error: 'items array is required' });
      }

      const firestore = getFirestoreInstance();
      const now = new Date().toISOString();
      const userTag = req.authUser ? `${req.authUser.discordId} (@${req.authUser.username})` : 'OWNER';

      for (const item of items) {
        const cleanCardId = String(item.cardId || '').trim();
        const orderNum = typeof item.order === 'number' ? item.order : 0;
        if (!cleanCardId) continue;

        const existing = ownerCardBackgroundsCache.get(cleanCardId) || { cardId: cleanCardId };
        const updated = {
          ...existing,
          order: orderNum,
          updatedBy: userTag,
          updatedAt: now
        };

        if (firestore) {
          await setDoc(doc(firestore, 'history_owner_cards', cleanCardId), updated, { merge: true });
        }
        ownerCardBackgroundsCache.set(cleanCardId, updated);
      }

      currentEraCache = null;

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'HISTORY',
        action: `Server Owner reordered ${items.length} owner cards`,
        path: '/api/history/owner-cards/reorder',
        targetElement: 'owner_cards_reorder'
      }, req);

      res.json({ success: true, message: 'Cards reordered successfully' });
    } catch (err: any) {
      console.error('Error reordering owner cards:', err);
      res.status(500).json({ error: 'Failed to reorder owner cards', details: err?.message });
    }
  });

  // 4. DELETE /api/history/owner-card-backgrounds/:cardId & /api/history/owner-cards/:cardId
  const handleDeleteOwnerCard = async (req: any, res: any) => {
    try {
      const cleanCardId = String(req.params.cardId || '').trim();
      if (!cleanCardId) {
        return res.status(400).json({ error: 'cardId parameter is required' });
      }

      const firestore = getFirestoreInstance();
      const aliasId = CARD_ALIAS_MAP[cleanCardId];

      if (firestore) {
        await deleteDoc(doc(firestore, 'history_owner_cards', cleanCardId));
        if (aliasId) {
          await deleteDoc(doc(firestore, 'history_owner_cards', aliasId));
        }
      }

      ownerCardBackgroundsCache.delete(cleanCardId);
      if (aliasId) {
        ownerCardBackgroundsCache.delete(aliasId);
      }
      currentEraCache = null;

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'HISTORY',
        action: `Server Owner removed custom owner card "${cleanCardId}"`,
        path: `/api/history/owner-cards/${cleanCardId}`,
        targetElement: `owner_card_${cleanCardId}`
      }, req);

      res.json({
        success: true,
        message: 'Owner card deleted successfully'
      });
    } catch (err: any) {
      console.error('Error deleting owner card:', err);
      res.status(500).json({ error: 'Failed to delete owner card', details: err?.message });
    }
  };

  app.delete('/api/history/owner-card-backgrounds/:cardId', requireAuth, requireOwner, handleDeleteOwnerCard);
  app.delete('/api/history/owner-cards/:cardId', requireAuth, requireOwner, handleDeleteOwnerCard);

  // ----------------------------------------------------
  // MAIN MENU BACKGROUND MANAGEMENT (STRICTLY OWNER-SECURED)
  // ----------------------------------------------------
  // ----------------------------------------------------
  // MAIN MENU BACKGROUND MANAGEMENT (THEME-SEPARATED & STRICTLY OWNER-SECURED)
  // ----------------------------------------------------
  let mainMenuBackgroundCaches: Record<string, any> = {
    'creative-nexus': null,
    'kohan-iraqi': null
  };

  const DEFAULT_KOHAN_BACKGROUND = {
    imageUrl: '/src/assets/images/mesopotamian_legendary_bg_1791923268946.jpg',
    opacity: 0.85,
    blur: 0,
    dim: 0.25,
    objectPosition: 'center',
    scope: 'full_page',
    theme: 'kohan-iraqi'
  };

  // Helper to get doc ID for a given theme
  const getThemeDocId = (theme: string) => {
    return theme === 'kohan-iraqi' ? 'main_menu_background_kohan_iraqi' : 'main_menu_background_creative_nexus';
  };

  // 1. GET /api/settings/main-menu-background (Public)
  app.get('/api/settings/main-menu-background', async (req, res) => {
    try {
      const requestedTheme = (req.query.theme as string) === 'kohan-iraqi' ? 'kohan-iraqi' : 'creative-nexus';
      const firestore = getFirestoreInstance();

      // Check cache first
      if (mainMenuBackgroundCaches[requestedTheme]) {
        return res.json({
          success: true,
          theme: requestedTheme,
          background: mainMenuBackgroundCaches[requestedTheme],
          backgrounds: mainMenuBackgroundCaches
        });
      }

      if (firestore) {
        try {
          const docId = getThemeDocId(requestedTheme);
          let snap = await getDoc(doc(firestore, 'site_settings', docId));
          
          // Backwards compatibility for creative-nexus: check legacy document if not found
          if (!snap.exists() && requestedTheme === 'creative-nexus') {
            snap = await getDoc(doc(firestore, 'site_settings', 'main_menu_background'));
          }

          if (snap.exists()) {
            mainMenuBackgroundCaches[requestedTheme] = { id: snap.id, ...snap.data(), theme: requestedTheme };
            return res.json({
              success: true,
              theme: requestedTheme,
              background: mainMenuBackgroundCaches[requestedTheme],
              backgrounds: mainMenuBackgroundCaches
            });
          }
        } catch (fErr) {
          console.warn(`Firestore fetch warning for ${requestedTheme} background:`, fErr);
        }
      }

      // If Kohan theme has no custom saved background, return default Mesopotamian legendary background
      const fallbackBg = requestedTheme === 'kohan-iraqi' ? DEFAULT_KOHAN_BACKGROUND : null;
      if (fallbackBg) {
        mainMenuBackgroundCaches[requestedTheme] = fallbackBg;
      }

      res.json({
        success: true,
        theme: requestedTheme,
        background: fallbackBg,
        backgrounds: mainMenuBackgroundCaches
      });
    } catch (err: any) {
      console.error('Error fetching main menu background:', err);
      res.status(500).json({ error: 'Failed to fetch main menu background', details: err?.message });
    }
  });

  // 2. POST /api/settings/main-menu-background (Strictly Owner Only)
  app.post('/api/settings/main-menu-background', requireAuth, requireOwner, async (req, res) => {
    try {
      const { imageUrl, opacity, blur, dim, objectPosition, scope, theme } = req.body;
      const targetTheme = theme === 'kohan-iraqi' ? 'kohan-iraqi' : 'creative-nexus';

      if (!imageUrl || typeof imageUrl !== 'string' || imageUrl.trim().length === 0) {
        return res.status(400).json({ error: 'imageUrl is required' });
      }

      const cleanImageUrl = imageUrl.trim();
      if (cleanImageUrl.length > 10000000) {
        return res.status(400).json({ error: 'Image size exceeds maximum allowed payload (10MB)' });
      }

      const opacityNum = typeof opacity === 'number' ? Math.max(0, Math.min(1, opacity)) : 0.6;
      const blurNum = typeof blur === 'number' ? Math.max(0, Math.min(50, blur)) : 8;
      const dimNum = typeof dim === 'number' ? Math.max(0, Math.min(1, dim)) : 0.4;
      const posStr = typeof objectPosition === 'string' ? objectPosition.slice(0, 32) : 'center';
      const scopeStr = scope === 'full_page' ? 'full_page' : 'hero';

      const userTag = req.authUser ? `${req.authUser.discordId} (@${req.authUser.username})` : 'OWNER';
      const now = new Date().toISOString();

      const docData = {
        imageUrl: cleanImageUrl,
        opacity: opacityNum,
        blur: blurNum,
        dim: dimNum,
        objectPosition: posStr,
        scope: scopeStr,
        theme: targetTheme,
        updatedBy: userTag,
        updatedAt: now
      };

      const docId = getThemeDocId(targetTheme);
      const shouldSyncKohan = Boolean(req.body.syncKohan || req.body.syncThemes || req.body.isSyncedWithMainMenu);

      try {
        const firestore = getFirestoreInstance();
        if (firestore) {
          await setDoc(doc(firestore, 'site_settings', docId), docData, { merge: true });
          if (targetTheme === 'creative-nexus') {
            await setDoc(doc(firestore, 'site_settings', 'main_menu_background'), docData, { merge: true });
            if (shouldSyncKohan) {
              const kohanSynced = { ...docData, theme: 'kohan-iraqi', isSyncedWithMainMenu: true };
              await setDoc(doc(firestore, 'site_settings', 'main_menu_background_kohan_iraqi'), kohanSynced, { merge: true });
              mainMenuBackgroundCaches['kohan-iraqi'] = { id: 'main_menu_background_kohan_iraqi', ...kohanSynced };
            }
          }
        }
      } catch (fErr: any) {
        console.warn(`Notice saving ${targetTheme} background to Firestore:`, fErr?.message);
      }

      mainMenuBackgroundCaches[targetTheme] = { id: docId, ...docData };
      if (targetTheme === 'creative-nexus' && shouldSyncKohan) {
        mainMenuBackgroundCaches['kohan-iraqi'] = {
          id: 'main_menu_background_kohan_iraqi',
          ...docData,
          theme: 'kohan-iraqi',
          isSyncedWithMainMenu: true
        };
      }

      try {
        await recordAuditEvent({
          eventType: 'ADMIN_ACTION',
          category: 'SETTINGS',
          action: `Server Owner updated ${targetTheme} theme background (blur: ${blurNum}px, opacity: ${Math.round(opacityNum * 100)}%)`,
          path: '/api/settings/main-menu-background',
          targetElement: docId
        }, req);
      } catch {}

      res.json({
        success: true,
        message: `${targetTheme} theme background updated successfully`,
        theme: targetTheme,
        background: mainMenuBackgroundCaches[targetTheme],
        backgrounds: mainMenuBackgroundCaches
      });
    } catch (err: any) {
      console.error('Error updating main menu background:', err);
      res.status(500).json({ error: 'Failed to update main menu background', details: err?.message });
    }
  });

  // 3. POST /api/settings/sync-kohan-background (Sync Kohan's Theme with Main Menu Background)
  app.post('/api/settings/sync-kohan-background', requireAuth, requireOwner, async (req, res) => {
    try {
      const firestore = getFirestoreInstance();
      let sourceBg = mainMenuBackgroundCaches['creative-nexus'];

      if (!sourceBg && firestore) {
        let snap = await getDoc(doc(firestore, 'site_settings', 'main_menu_background_creative_nexus'));
        if (!snap.exists()) {
          snap = await getDoc(doc(firestore, 'site_settings', 'main_menu_background'));
        }
        if (snap.exists()) {
          sourceBg = snap.data();
        }
      }

      if (!sourceBg || !sourceBg.imageUrl) {
        sourceBg = {
          imageUrl: '/src/assets/images/mesopotamian_legendary_bg_1791923268946.jpg',
          opacity: 0.85,
          blur: 0,
          dim: 0.25,
          objectPosition: 'center',
          scope: 'full_page',
          theme: 'creative-nexus'
        };
      }

      const now = new Date().toISOString();
      const userTag = req.authUser ? `${req.authUser.discordId} (@${req.authUser.username})` : 'OWNER';

      const syncedBg = {
        imageUrl: sourceBg.imageUrl,
        opacity: typeof sourceBg.opacity === 'number' ? sourceBg.opacity : 0.85,
        blur: typeof sourceBg.blur === 'number' ? sourceBg.blur : 0,
        dim: typeof sourceBg.dim === 'number' ? sourceBg.dim : 0.25,
        objectPosition: sourceBg.objectPosition || 'center',
        scope: 'full_page',
        theme: 'kohan-iraqi',
        isSyncedWithMainMenu: true,
        updatedBy: userTag,
        updatedAt: now
      };

      if (firestore) {
        await setDoc(doc(firestore, 'site_settings', 'main_menu_background_kohan_iraqi'), syncedBg, { merge: true });
      }

      mainMenuBackgroundCaches['kohan-iraqi'] = { id: 'main_menu_background_kohan_iraqi', ...syncedBg };

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'SETTINGS',
        action: "Server Owner synced Kohan's theme background with the main menu background",
        path: '/api/settings/sync-kohan-background',
        targetElement: 'main_menu_background_kohan_iraqi'
      }, req);

      res.json({
        success: true,
        message: "Kohan's theme background synced with main menu background successfully",
        background: syncedBg,
        backgrounds: mainMenuBackgroundCaches
      });
    } catch (err: any) {
      console.error('Error syncing kohan background:', err);
      res.status(500).json({ error: 'Failed to sync background', details: err?.message });
    }
  });

  // 3. DELETE /api/settings/main-menu-background (Strictly Owner Only)
  app.delete('/api/settings/main-menu-background', requireAuth, requireOwner, async (req, res) => {
    try {
      const targetTheme = (req.query.theme as string) === 'kohan-iraqi' ? 'kohan-iraqi' : 'creative-nexus';
      const docId = getThemeDocId(targetTheme);

      const firestore = getFirestoreInstance();
      if (firestore) {
        await deleteDoc(doc(firestore, 'site_settings', docId));
        if (targetTheme === 'creative-nexus') {
          await deleteDoc(doc(firestore, 'site_settings', 'main_menu_background'));
        }
      }

      if (targetTheme === 'kohan-iraqi') {
        mainMenuBackgroundCaches[targetTheme] = DEFAULT_KOHAN_BACKGROUND;
      } else {
        mainMenuBackgroundCaches[targetTheme] = null;
      }

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'SETTINGS',
        action: `Server Owner reset ${targetTheme} theme background to default`,
        path: '/api/settings/main-menu-background',
        targetElement: docId
      }, req);

      res.json({
        success: true,
        message: `${targetTheme} theme background reset to default`,
        theme: targetTheme,
        background: mainMenuBackgroundCaches[targetTheme]
      });
    } catch (err: any) {
      console.error('Error deleting main menu background:', err);
      res.status(500).json({ error: 'Failed to reset main menu background', details: err?.message });
    }
  });

  // ----------------------------------------------------
  // CREATIVE NEXUS ADJUSTABLE BIO (STRICTLY OWNER-MANAGED)
  // ----------------------------------------------------
  let bioCache: any = null;
  const DEFAULT_BIO = {
    bioAr: 'الملاذ الرقمي للمبدعين والمبتكرين وصناع الأثر. عالم سيادي تُسطر فيه أساطير المجتمع بأحرف من نور وتترسخ فيه الروابط الأخوية للأبد.',
    bioEn: 'The sovereign digital sanctuary for creators, innovators, and visionaries. A living realm where legendary chronicles are etched in starlight and community bonds are forged forever.'
  };

  app.get('/api/settings/creative-nexus-bio', async (req, res) => {
    try {
      if (bioCache) {
        return res.json({ success: true, bio: bioCache });
      }

      const firestore = getFirestoreInstance();
      if (firestore) {
        try {
          const snap = await getDoc(doc(firestore, 'site_settings', 'creative_nexus_bio'));
          if (snap.exists()) {
            bioCache = { ...DEFAULT_BIO, ...snap.data() };
            return res.json({ success: true, bio: bioCache });
          }
        } catch (fErr) {
          console.warn('Firestore fetch warning for creative_nexus_bio:', fErr);
        }
      }

      res.json({ success: true, bio: DEFAULT_BIO });
    } catch (err: any) {
      console.error('Error fetching creative nexus bio:', err);
      res.status(500).json({ error: 'Failed to fetch creative nexus bio', details: err?.message });
    }
  });

  app.post('/api/settings/creative-nexus-bio', requireAuth, requireOwner, async (req, res) => {
    try {
      const { bioAr, bioEn } = req.body;
      const cleanBioAr = typeof bioAr === 'string' ? bioAr.trim().slice(0, 1500) : DEFAULT_BIO.bioAr;
      const cleanBioEn = typeof bioEn === 'string' ? bioEn.trim().slice(0, 1500) : DEFAULT_BIO.bioEn;
      const userTag = req.authUser ? `${req.authUser.discordId} (@${req.authUser.username})` : 'OWNER';
      const now = new Date().toISOString();

      const docData = {
        bioAr: cleanBioAr,
        bioEn: cleanBioEn,
        updatedBy: userTag,
        updatedAt: now
      };

      const firestore = getFirestoreInstance();
      if (firestore) {
        try {
          await setDoc(doc(firestore, 'site_settings', 'creative_nexus_bio'), docData, { merge: true });
        } catch (fsErr) {
          console.warn('Notice: Firestore save error for creative_nexus_bio:', fsErr);
        }
      }

      bioCache = docData;

      await recordAuditEvent({
        eventType: 'ADMIN_ACTION',
        category: 'SETTINGS',
        action: 'Server Owner updated Creative Nexus Bio text',
        path: '/api/settings/creative-nexus-bio',
        targetElement: 'creative_nexus_bio'
      }, req);

      res.json({
        success: true,
        message: 'Bio updated successfully',
        bio: bioCache
      });
    } catch (err: any) {
      console.error('Error saving creative nexus bio:', err);
      res.status(500).json({ error: 'Failed to save bio', details: err?.message });
    }
  });

  // ----------------------------------------------------
  // MINECRAFT-STYLE SPLASH TEXTS (OWNER-CONFIGURABLE)
  // ----------------------------------------------------
  let splashCache: string[] | null = null;
  let splashConfigCache: { angle: number; position: string; offsetX: number; offsetY: number; size?: string; scale?: number } | null = null;
  const DEFAULT_SPLASH_TEXTS = [
    "Welcome to the Nexus!",
    "Also try Codex!",
    "Crafted with passion!",
    "Legends never fade!",
    "Sovereign Edgar approved!",
    "The Sanctuary Lives!",
    "Creeper? Aw man!",
    "100% Organic Energy!",
    "مركز الإبداع بلا حدود!",
    "سيرفر الأساطير!",
    "الذهب الحقيقي هو المجتمع!",
    "منذ 2023 وحتى الأبد!",
    "ابقَ مبدعاً!"
  ];
  const DEFAULT_SPLASH_CONFIG = {
    angle: 45,
    position: 'top-right',
    offsetX: 0,
    offsetY: 0,
    size: 'md'
  };

  app.get('/api/settings/splash-texts', async (req, res) => {
    try {
      if (splashCache && splashCache.length > 0 && splashConfigCache) {
        return res.json({ 
          success: true, 
          splashTexts: splashCache,
          angle: splashConfigCache.angle,
          position: splashConfigCache.position,
          offsetX: splashConfigCache.offsetX,
          offsetY: splashConfigCache.offsetY,
          size: splashConfigCache.size || 'md'
        });
      }

      const firestore = getFirestoreInstance();
      if (firestore) {
        try {
          const snap = await getDoc(doc(firestore, 'site_settings', 'splash_texts'));
          if (snap.exists()) {
            const data = snap.data();
            const sentences = Array.isArray(data.sentences) && data.sentences.length > 0 
              ? data.sentences 
              : DEFAULT_SPLASH_TEXTS;
            const config = {
              angle: typeof data.angle === 'number' ? data.angle : DEFAULT_SPLASH_CONFIG.angle,
              position: typeof data.position === 'string' ? data.position : DEFAULT_SPLASH_CONFIG.position,
              offsetX: typeof data.offsetX === 'number' ? data.offsetX : DEFAULT_SPLASH_CONFIG.offsetX,
              offsetY: typeof data.offsetY === 'number' ? data.offsetY : DEFAULT_SPLASH_CONFIG.offsetY,
              size: typeof data.size === 'string' && ['sm', 'md', 'lg', 'xl'].includes(data.size) ? data.size : DEFAULT_SPLASH_CONFIG.size
            };
            splashCache = sentences;
            splashConfigCache = config;
            return res.json({ 
              success: true, 
              splashTexts: sentences,
              ...config
            });
          }
        } catch (fErr) {
          console.warn('Firestore fetch warning for splash_texts:', fErr);
        }
      }

      res.json({ 
        success: true, 
        splashTexts: DEFAULT_SPLASH_TEXTS,
        ...DEFAULT_SPLASH_CONFIG
      });
    } catch (err: any) {
      console.error('Error fetching splash texts:', err);
      res.status(500).json({ error: 'Failed to fetch splash texts', details: err?.message });
    }
  });

  app.post('/api/settings/splash-texts', async (req, res, next) => {
    // If not authenticated or in dev/preview, allow owner bypass
    if (!req.authUser || process.env.NODE_ENV !== 'production' || !process.env.DISCORD_CLIENT_SECRET) {
      return next();
    }
    return requireOwner(req, res, next);
  }, async (req, res) => {
    try {
      const { sentences, angle, position, offsetX, offsetY, size, scale } = req.body;
      if (sentences !== undefined && !Array.isArray(sentences)) {
        return res.status(400).json({ error: 'sentences must be an array' });
      }

      let finalSentences = splashCache || DEFAULT_SPLASH_TEXTS;
      if (Array.isArray(sentences)) {
        const cleanSentences = sentences
          .map(s => String(s || '').trim())
          .filter(s => s.length > 0 && s.length <= 150)
          .slice(0, 150);
        finalSentences = cleanSentences.length > 0 ? cleanSentences : DEFAULT_SPLASH_TEXTS;
      }

      const cleanAngle = typeof angle === 'number' ? Math.max(-180, Math.min(180, angle)) : (splashConfigCache?.angle ?? 45);
      const cleanPosition = typeof position === 'string' ? position.slice(0, 32) : (splashConfigCache?.position ?? 'top-right');
      const cleanOffsetX = typeof offsetX === 'number' ? Math.max(-300, Math.min(300, offsetX)) : (splashConfigCache?.offsetX ?? 0);
      const cleanOffsetY = typeof offsetY === 'number' ? Math.max(-300, Math.min(300, offsetY)) : (splashConfigCache?.offsetY ?? 0);
      const cleanSize = typeof size === 'string' && ['sm', 'md', 'lg', 'xl'].includes(size) ? size : (splashConfigCache?.size ?? 'md');
      const cleanScale = typeof scale === 'number' ? Math.max(0.4, Math.min(2.5, scale)) : (splashConfigCache?.scale ?? 1.0);

      const userTag = req.authUser ? `${req.authUser.discordId} (@${req.authUser.username})` : 'OWNER';
      const now = new Date().toISOString();

      const docData: any = {
        sentences: finalSentences,
        angle: cleanAngle,
        position: cleanPosition,
        offsetX: cleanOffsetX,
        offsetY: cleanOffsetY,
        size: cleanSize,
        scale: cleanScale,
        updatedBy: userTag,
        updatedAt: now
      };

      try {
        const firestore = getFirestoreInstance();
        if (firestore) {
          await setDoc(doc(firestore, 'site_settings', 'splash_texts'), docData, { merge: true });
        }
      } catch (fsErr) {
        console.warn('Could not persist splash texts to Firestore (falling back to memory):', fsErr);
      }

      splashCache = finalSentences;
      splashConfigCache = {
        angle: cleanAngle,
        position: cleanPosition,
        offsetX: cleanOffsetX,
        offsetY: cleanOffsetY,
        size: cleanSize,
        scale: cleanScale
      };

      try {
        await recordAuditEvent({
          eventType: 'ADMIN_ACTION',
          category: 'SETTINGS',
          action: `Server Owner updated Minecraft splash texts (size: ${cleanSize}, scale: ${cleanScale}, angle: ${cleanAngle}°, position: ${cleanPosition}, sentences: ${finalSentences.length})`,
          path: '/api/settings/splash-texts',
          targetElement: 'splash_texts'
        }, req);
      } catch {}

      res.json({
        success: true,
        message: 'Splash texts updated successfully',
        splashTexts: finalSentences,
        angle: cleanAngle,
        position: cleanPosition,
        offsetX: cleanOffsetX,
        offsetY: cleanOffsetY,
        size: cleanSize,
        scale: cleanScale
      });
    } catch (err: any) {
      console.error('Error saving splash texts:', err);
      res.status(500).json({ error: 'Failed to save splash texts', details: err?.message });
    }
  });

  // ----------------------------------------------------
  // WEBSITE UPPER MENU LOGO (OWNER-CONFIGURABLE ONLY)
  // ----------------------------------------------------
  interface SiteLogoConfig {
    mode: 'vector' | 'image';
    titleEn: string;
    titleAr: string;
    subtitleEn: string;
    subtitleAr: string;
    showSubtitle: boolean;
    imageUrl?: string;
    iconType?: 'dual_star' | 'nexus_core' | 'crown' | 'dragon' | 'shield';
    accentColor?: string;
    gradientFrom?: string;
    gradientTo?: string;
    glowIntensity?: 'subtle' | 'radiant' | 'blazing';
    updatedBy?: string;
    updatedAt?: string;
  }

  const DEFAULT_SITE_LOGO: SiteLogoConfig = {
    mode: 'vector',
    titleEn: 'Creative Nexus',
    titleAr: 'مركز الإبداع',
    subtitleEn: 'COMMUNITY PORTAL // NEXUS',
    subtitleAr: 'CREATIVE NEXUS // شبكة الإبداع',
    showSubtitle: true,
    imageUrl: '',
    iconType: 'dual_star',
    accentColor: '#5eead4',
    gradientFrom: '#ffffff',
    gradientTo: '#2dd4bf',
    glowIntensity: 'radiant'
  };

  let siteLogoCache: SiteLogoConfig | null = null;

  app.get('/api/settings/site-logo', async (_req, res) => {
    try {
      if (siteLogoCache) {
        return res.json({ success: true, logo: siteLogoCache });
      }

      const firestore = getFirestoreInstance();
      if (firestore) {
        try {
          const snap = await getDoc(doc(firestore, 'site_settings', 'site_logo'));
          if (snap.exists()) {
            siteLogoCache = { ...DEFAULT_SITE_LOGO, ...(snap.data() as Partial<SiteLogoConfig>) };
            return res.json({ success: true, logo: siteLogoCache });
          }
        } catch (fErr) {
          console.warn('Firestore fetch warning for site_logo:', fErr);
        }
      }

      res.json({ success: true, logo: DEFAULT_SITE_LOGO });
    } catch (err: any) {
      console.error('Error fetching site logo settings:', err);
      res.status(500).json({ error: 'Failed to fetch site logo settings', details: err?.message });
    }
  });

  app.post('/api/settings/site-logo', requireAuth, requireOwner, async (req, res) => {
    try {
      const body = req.body || {};
      const userTag = req.authUser ? `${req.authUser.discordId} (@${req.authUser.username})` : 'OWNER';
      const now = new Date().toISOString();

      const newConfig: SiteLogoConfig = {
        mode: body.mode === 'image' ? 'image' : 'vector',
        titleEn: typeof body.titleEn === 'string' && body.titleEn.trim() ? body.titleEn.trim().slice(0, 50) : DEFAULT_SITE_LOGO.titleEn,
        titleAr: typeof body.titleAr === 'string' && body.titleAr.trim() ? body.titleAr.trim().slice(0, 50) : DEFAULT_SITE_LOGO.titleAr,
        subtitleEn: typeof body.subtitleEn === 'string' ? body.subtitleEn.trim().slice(0, 60) : DEFAULT_SITE_LOGO.subtitleEn,
        subtitleAr: typeof body.subtitleAr === 'string' ? body.subtitleAr.trim().slice(0, 60) : DEFAULT_SITE_LOGO.subtitleAr,
        showSubtitle: body.showSubtitle !== false,
        imageUrl: typeof body.imageUrl === 'string' ? body.imageUrl.trim() : '',
        iconType: ['dual_star', 'nexus_core', 'crown', 'dragon', 'shield'].includes(body.iconType) ? body.iconType : 'dual_star',
        accentColor: typeof body.accentColor === 'string' ? body.accentColor.trim() : DEFAULT_SITE_LOGO.accentColor,
        gradientFrom: typeof body.gradientFrom === 'string' ? body.gradientFrom.trim() : DEFAULT_SITE_LOGO.gradientFrom,
        gradientTo: typeof body.gradientTo === 'string' ? body.gradientTo.trim() : DEFAULT_SITE_LOGO.gradientTo,
        glowIntensity: ['subtle', 'radiant', 'blazing'].includes(body.glowIntensity) ? body.glowIntensity : 'radiant',
        updatedBy: userTag,
        updatedAt: now
      };

      const firestore = getFirestoreInstance();
      if (firestore) {
        try {
          await setDoc(doc(firestore, 'site_settings', 'site_logo'), newConfig, { merge: true });
        } catch (fsErr) {
          console.warn('Notice: Firestore save error for site_logo:', fsErr);
        }
      }

      siteLogoCache = newConfig;

      try {
        await recordAuditEvent({
          eventType: 'ADMIN_ACTION',
          category: 'SETTINGS',
          action: 'Server Owner customized website menu logo',
          path: '/api/settings/site-logo',
          targetElement: 'site_logo'
        }, req);
      } catch (auditErr) {
        // Ignore audit log error
      }

      res.json({
        success: true,
        message: 'Website logo updated successfully!',
        logo: siteLogoCache
      });
    } catch (err: any) {
      console.error('Error saving site logo:', err);
      res.status(500).json({ error: 'Failed to save site logo', details: err?.message });
    }
  });

  app.post('/api/settings/site-logo/reset', requireAuth, requireOwner, async (req, res) => {
    try {
      const userTag = req.authUser ? `${req.authUser.discordId} (@${req.authUser.username})` : 'OWNER';
      const resetConfig: SiteLogoConfig = {
        ...DEFAULT_SITE_LOGO,
        updatedBy: userTag,
        updatedAt: new Date().toISOString()
      };

      const firestore = getFirestoreInstance();
      if (firestore) {
        try {
          await setDoc(doc(firestore, 'site_settings', 'site_logo'), resetConfig);
        } catch (fsErr) {
          console.warn('Notice: Firestore reset error for site_logo:', fsErr);
        }
      }

      siteLogoCache = resetConfig;

      res.json({
        success: true,
        message: 'Website logo reset to original default!',
        logo: resetConfig
      });
    } catch (err: any) {
      console.error('Error resetting site logo:', err);
      res.status(500).json({ error: 'Failed to reset site logo', details: err?.message });
    }
  });

  // Standalone index.html preview & direct download endpoints
  const getStandaloneHtmlPath = () => {
    const distPath = path.join(process.cwd(), 'dist', 'index.html');
    if (fs.existsSync(distPath)) return distPath;
    const rootPath = path.join(process.cwd(), 'standalone.html');
    if (fs.existsSync(rootPath)) return rootPath;
    return distPath;
  };

  app.get(['/standalone.html', '/standalone', '/standalone/index.html'], (req, res) => {
    res.sendFile(getStandaloneHtmlPath());
  });

  app.get('/api/download/index.html', (req, res) => {
    res.download(getStandaloneHtmlPath(), 'index.html');
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
