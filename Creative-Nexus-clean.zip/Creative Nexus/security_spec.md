# Firestore Security Specification

## 1. Data Invariants
- **Staff Collection (`/staff/{staffId}`)**:
  - Only authorized administrators or users can write staff profiles.
  - Required fields on creation: `discordId`, `username`, `displayName`, `rank`, `points`, `status`, `joinedAt`, `updatedAt`.
  - Ranks are strictly limited to `['MODERATOR', 'SENIOR_MODERATOR', 'ADMINISTRATOR', 'SENIOR_ADMINISTRATOR', 'SUPER_ADMIN']`.
  - Status is strictly limited to `['ACTIVE', 'SUSPENDED', 'REMOVED']`.
  - Points must be a non-negative integer or valid number.
  - Immutability: `discordId` and `joinedAt` cannot be modified once set.
  - Strict string length boundaries (e.g. `discordId <= 32`, `username <= 64`, `displayName <= 64`, `notes <= 1000`).

- **History Subcollection (`/staff/{staffId}/history/{historyId}`)**:
  - Belongs strictly to an existing `/staff/{staffId}` document.
  - Records must be immutable once created.
  - Action must be one of the enum values: `['STAFF_ADDED', 'STAFF_EDITED', 'PROMOTED', 'DEMOTED', 'SUSPENDED', 'REACTIVATED', 'REMOVED', 'POINTS_CHANGED']`.
  - `description <= 500`, `performedBy <= 64`.

- **Point Transactions Subcollection (`/staff/{staffId}/pointTransactions/{transactionId}`)**:
  - Belongs strictly to an existing `/staff/{staffId}` document.
  - Records must be immutable once created.
  - `amount` must be a positive integer/number (`amount > 0`).
  - `type` must be `'ADD'` or `'REMOVE'`.
  - `reason` length `<= 255`.

## 2. The "Dirty Dozen" Payloads

1. **Payload 1 (Shadow Field Injection in Staff creation)**:
   Adding `role: 'SUPER_ADMIN_ROOT'` or `isAdmin: true` into the staff document.
2. **Payload 2 (Invalid Rank Enumeration)**:
   Attempting to set `rank: 'GOD_MODE'`.
3. **Payload 3 (Negative Points on Creation)**:
   Attempting to set `points: -500`.
4. **Payload 4 (Oversized Payload / Denial of Wallet)**:
   Attempting to set `username` to a 20KB string.
5. **Payload 5 (Immutable Field Tampering)**:
   Attempting to update `discordId` to a different Discord snowflake.
6. **Payload 6 (Terminal Status Bypass)**:
   Modifying fields of a deleted/purged staff member without restoring status first.
7. **Payload 7 (Invalid Transaction Type)**:
   Creating a point transaction with `type: 'STEAL'`.
8. **Payload 8 (Negative Transaction Amount)**:
   Creating a point transaction with `amount: -100`.
9. **Payload 9 (Zero Transaction Amount)**:
   Creating a point transaction with `amount: 0`.
10. **Payload 10 (Orphaned Point Transaction)**:
    Creating a transaction under a nonexistent `staffId`.
11. **Payload 11 (Tampering with Historical Audit Log)**:
    Attempting to update or overwrite an existing history document.
12. **Payload 12 (Invalid Document ID)**:
    Injecting a 500-character malicious path ID with forbidden characters.

## 3. Test Runner
Included in `firestore.rules.test.ts` to assert that all dirty payloads return `PERMISSION_DENIED`.
