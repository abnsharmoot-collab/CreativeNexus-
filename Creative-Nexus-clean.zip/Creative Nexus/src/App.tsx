import React, { useEffect } from 'react';
import { BrowserRouter, HashRouter, Routes, Route, useLocation, Navigate } from 'react-router-dom';

export const isFileOrStandalone = typeof window !== 'undefined' && (
  window.location.protocol === 'file:' ||
  window.location.hostname === '' ||
  window.location.pathname.endsWith('.html') ||
  window.location.pathname.includes('/standalone') ||
  window.location.search.includes('standalone=true') ||
  window.location.hash.startsWith('#/')
);

const AppRouter: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  if (isFileOrStandalone) {
    return <HashRouter>{children}</HashRouter>;
  }
  return <BrowserRouter>{children}</BrowserRouter>;
};
import { LanguageProvider } from './context/LanguageContext';
import { AuthProvider } from './context/AuthContext';
import { StaffProvider } from './context/StaffContext';
import { DiscordServerProvider } from './context/DiscordServerContext';
import { RankApplicationProvider } from './context/RankApplicationContext';
import { AchievementProvider } from './context/AchievementContext';
import { AnnouncementProvider } from './context/AnnouncementContext';
import { NotificationProvider } from './context/NotificationContext';
import { EasterEggProvider } from './context/EasterEggContext';
import { OwnerCardBackgroundsProvider } from './context/OwnerCardBackgroundsContext';
import { OwnerCardBackgroundModal } from './components/history/OwnerCardBackgroundModal';
import { MainMenuBackgroundProvider } from './context/MainMenuBackgroundContext';
import { MainMenuBackgroundModal } from './components/home/MainMenuBackgroundModal';
import { SiteLogoProvider } from './context/SiteLogoContext';
import { DownloadHtmlProvider } from './context/DownloadHtmlContext';
import { DownloadHtmlModal } from './components/export/DownloadHtmlModal';
import { Navbar } from './components/organisms/Navbar';
import { Footer } from './components/organisms/Footer';
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import { OAuthConfigModal } from './components/auth/OAuthConfigModal';
import { LoginModal } from './components/auth/LoginModal';
import { KohanSecretRoomModal } from './components/easterEggs/KohanSecretRoomModal';
import { FlagFoundOverlay } from './components/easterEggs/FlagFoundOverlay';
import { SecretProgressModal } from './components/easterEggs/SecretProgressModal';
import { ThemeUnlockedOverlay } from './components/easterEggs/ThemeUnlockedOverlay';
import { Home } from './pages/Home';
import { History } from './pages/History';
import { OwnerProfile } from './pages/OwnerProfile';
import { StaffManagement } from './pages/StaffManagement';
import { StaffProfile } from './pages/StaffProfile';
import { ServerDashboard } from './pages/ServerDashboard';
import { RankPoints } from './pages/RankPoints';
import { Achievements } from './pages/Achievements';
import { Codex } from './pages/Codex';
import { Announcements } from './pages/Announcements';
import { AnnouncementDetail } from './pages/AnnouncementDetail';
import { Notifications } from './pages/Notifications';
import { ClassifiedSecretArchive } from './pages/ClassifiedSecretArchive';
import { Settings } from './pages/Settings';
import { OwnerAuditLog } from './pages/OwnerAuditLog';
import { CardVault } from './pages/CardVault';
import { PlayerProfile } from './pages/PlayerProfile';
import { Decks } from './pages/Decks';
import { StoryMode } from './pages/StoryMode';
import { CharacterLovePage } from './pages/CharacterLovePage';
import { CardUpgradePage } from './pages/CardUpgradePage';
import { CardProvider } from './context/CardContext';
import { ItemProvider } from './context/ItemContext';
import { CardUpgradeProvider } from './context/CardUpgradeContext';
import { DeckProvider } from './context/DeckContext';
import { StoryProvider } from './context/StoryContext';
import { CombatProvider } from './context/CombatContext';
import { CharacterLoveProvider } from './context/CharacterLoveContext';
import { ArchivalBackground } from './components/atoms/ArchivalBackground';
import { useEasterEggs } from './context/EasterEggContext';
import { initGlobalClickTracker, trackPageView } from './utils/auditTracker';

function AppShell() {
  const location = useLocation();
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  // Initialize global click & interaction tracker once
  useEffect(() => {
    const cleanup = initGlobalClickTracker();
    return cleanup;
  }, []);

  // Track route transitions for owner audit telemetry
  useEffect(() => {
    trackPageView(location.pathname);
  }, [location.pathname]);

  // Subtle interactive cursor spotlight and top scroll progress
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      document.documentElement.style.setProperty('--mouse-x', `${e.clientX}px`);
      document.documentElement.style.setProperty('--mouse-y', `${e.clientY}px`);
    };
    const handleScroll = () => {
      const h = document.documentElement;
      const st = h.scrollTop || document.body.scrollTop;
      const sh = h.scrollHeight - h.clientHeight;
      const pct = sh > 0 ? Math.min(1, Math.max(0, st / sh)) : 0;
      const line = document.getElementById('top-scroll-progress');
      if (line) {
        line.style.transform = `scaleX(${pct})`;
      }
    };
    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div
      className={`relative min-h-screen overflow-hidden ${
        isMesopotamian
          ? 'bg-transparent text-amber-100 selection:bg-amber-500/30 selection:text-amber-100'
          : 'bg-[#031211] text-[#eafffa] selection:bg-[#5eead4]/30 selection:text-[#eafffa]'
      }`}
    >
      {/* Scroll Progress Line & Cursor Spotlight */}
      <div id="top-scroll-progress" className="scroll-progress-line" style={{ transform: 'scaleX(0)' }} />
      <div className="cursor-spotlight hidden sm:block" />

      {/* Deep Cinematic Archival Atmosphere */}
      <ArchivalBackground />

      <div className="relative z-10 flex flex-col min-h-screen w-full max-w-full overflow-x-hidden min-w-0">
        <Navbar />

        {/* Content wrapper reserving responsive header vertical space */}
        <div id="page-content" className="flex-1 w-full flex flex-col min-w-0">
          <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/announcements" element={<Announcements />} />
          <Route path="/announcements/:id" element={<AnnouncementDetail />} />
          <Route path="/history" element={<History />} />
          <Route path="/owner/:ownerId" element={<OwnerProfile />} />
          <Route path="/owners/:ownerId" element={<OwnerProfile />} />
          <Route path="/owner" element={<Navigate to="/history" replace />} />
          <Route path="/codex" element={<Codex />} />
          <Route path="/codex/:bookId" element={<Codex />} />
          <Route path="/handbook" element={<Codex />} />
          <Route path="/handbook/:bookId" element={<Codex />} />
          <Route path="/guidebook" element={<Codex />} />
          <Route path="/guidebook/:bookId" element={<Codex />} />
          <Route path="/server-dashboard" element={<ServerDashboard />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/profile" element={<PlayerProfile />} />
          <Route path="/profile/:discordId" element={<PlayerProfile />} />
          <Route path="/player-profile" element={<Navigate to="/profile" replace />} />
          <Route path="/player-profile/:discordId" element={<PlayerProfile />} />
          <Route path="/cards" element={<CardVault />} />
          <Route path="/cards/shop" element={<CardVault />} />
          <Route path="/cards/collection" element={<CardVault />} />
          <Route path="/cards/showcase" element={<CardVault />} />
          <Route path="/card-shop" element={<Navigate to="/cards" replace />} />
          <Route path="/card-upgrade" element={<CardUpgradePage />} />
          <Route path="/upgrade" element={<Navigate to="/card-upgrade" replace />} />
          <Route path="/cards/upgrade" element={<Navigate to="/card-upgrade" replace />} />
          <Route path="/decks" element={<Decks />} />
          <Route path="/deck-builder" element={<Navigate to="/decks" replace />} />
          <Route path="/story" element={<StoryMode />} />
          <Route path="/story-mode" element={<Navigate to="/story" replace />} />
          <Route path="/battle" element={<Navigate to="/story" replace />} />
          <Route path="/characters" element={<CharacterLovePage />} />
          <Route path="/character-love" element={<CharacterLovePage />} />
          <Route path="/companions" element={<CharacterLovePage />} />
          <Route path="/love" element={<CharacterLovePage />} />
          <Route
            path="/cards/management"
            element={
              <ProtectedRoute requireOwner>
                <CardVault initialTab="management" />
              </ProtectedRoute>
            }
          />
          <Route
            path="/card-management"
            element={
              <ProtectedRoute requireOwner>
                <CardVault initialTab="management" />
              </ProtectedRoute>
            }
          />
          <Route path="/cards/manage" element={<Navigate to="/cards/management" replace />} />
          <Route path="/classified-archive" element={<ClassifiedSecretArchive />} />
          <Route
            path="/staff-management"
            element={
              <ProtectedRoute>
                <StaffManagement />
              </ProtectedRoute>
            }
          />
          <Route
            path="/staff-management/:id"
            element={
              <ProtectedRoute>
                <StaffProfile />
              </ProtectedRoute>
            }
          />
          <Route
            path="/rank-points"
            element={
              <ProtectedRoute>
                <RankPoints />
              </ProtectedRoute>
            }
          />
          <Route path="/achievements" element={<Achievements />} />
          <Route
            path="/audit-log"
            element={
              <ProtectedRoute>
                <OwnerAuditLog />
              </ProtectedRoute>
            }
          />
          <Route
            path="/audit-logs"
            element={
              <ProtectedRoute>
                <OwnerAuditLog />
              </ProtectedRoute>
            }
          />
        </Routes>
        </div>

        <Footer />
        <OAuthConfigModal />
        <LoginModal />
        <KohanSecretRoomModal />
        <FlagFoundOverlay />
        <SecretProgressModal />
        <ThemeUnlockedOverlay />
        <OwnerCardBackgroundModal />
        <MainMenuBackgroundModal />
        <DownloadHtmlModal />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <SiteLogoProvider>
          <ItemProvider>
            <CardProvider>
              <CardUpgradeProvider>
              <DeckProvider>
              <StoryProvider>
                <CombatProvider>
                  <CharacterLoveProvider>
                    <MainMenuBackgroundProvider>
                    <OwnerCardBackgroundsProvider>
                      <StaffProvider>
                        <DiscordServerProvider>
                          <RankApplicationProvider>
                            <AchievementProvider>
                              <AnnouncementProvider>
                                <NotificationProvider>
                                  <EasterEggProvider>
                                    <DownloadHtmlProvider>
                                      <AppRouter>
                                        <AppShell />
                                      </AppRouter>
                                    </DownloadHtmlProvider>
                                  </EasterEggProvider>
                                </NotificationProvider>
                              </AnnouncementProvider>
                            </AchievementProvider>
                          </RankApplicationProvider>
                        </DiscordServerProvider>
                      </StaffProvider>
                    </OwnerCardBackgroundsProvider>
                  </MainMenuBackgroundProvider>
                </CharacterLoveProvider>
              </CombatProvider>
            </StoryProvider>
            </DeckProvider>
            </CardUpgradeProvider>
          </CardProvider>
          </ItemProvider>
        </SiteLogoProvider>
      </AuthProvider>
    </LanguageProvider>
  );
}

