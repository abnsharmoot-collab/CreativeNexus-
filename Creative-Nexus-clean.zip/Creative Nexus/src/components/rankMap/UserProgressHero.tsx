import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Sparkles, 
  Award, 
  ArrowRight, 
  ArrowLeft, 
  AlertCircle, 
  CheckCircle2, 
  ShieldCheck, 
  Crown,
  ChevronRight,
  Clock,
  Send,
  BookOpen
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { StaffMember } from '../../types/staff';
import { getNextTierInfo, RankTier, getTierForPoints } from '../../types/rankMap';
import { DiscordUser } from '../../types/auth';
import { useRankApplications } from '../../context/RankApplicationContext';

interface UserProgressHeroProps {
  user: DiscordUser | null;
  staffMember?: StaffMember;
  isOwner: boolean;
  isAr?: boolean;
}

export const UserProgressHero: React.FC<UserProgressHeroProps> = ({
  user,
  staffMember,
  isOwner,
  isAr = false
}) => {
  const { getStatusForMember, applyForRank, getApplicationForMember } = useRankApplications();
  const [applying, setApplying] = useState(false);

  const currentPoints = staffMember ? staffMember.points || 0 : 0;
  const { currentTier, nextTier, remainingPoints, progressPercent, isMaxTier } = getNextTierInfo(currentPoints);
  const eligibleTier = getTierForPoints(currentPoints);

  const status = staffMember ? getStatusForMember(staffMember.discordId, staffMember, eligibleTier.id) : 'NOT_APPLIED';
  const application = staffMember ? getApplicationForMember(staffMember.discordId, eligibleTier.id) : undefined;

  const handleApply = async () => {
    if (!staffMember) return;
    setApplying(true);
    await applyForRank(staffMember, eligibleTier.id);
    setApplying(false);
  };

  return (
    <div className="w-full rounded-2xl border border-slate-700/70 bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 p-5 sm:p-7 shadow-xl shadow-black/40 relative overflow-hidden">
      {/* Ambient soft glow */}
      <div className="absolute top-0 right-0 w-96 h-48 bg-gradient-to-bl from-cyan-500/10 via-purple-500/5 to-transparent pointer-events-none rounded-full blur-3xl" />

      <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        {/* Left: User Identity & Current Tier */}
        <div className="flex items-start sm:items-center gap-4">
          <div className="relative shrink-0">
            <div className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl overflow-hidden border-2 p-0.5 bg-slate-950 shadow-md ${
              status === 'NOT_APPLIED'
                ? 'border-slate-700 grayscale contrast-125'
                : status === 'PENDING'
                ? 'border-amber-400 ring-2 ring-amber-500/20 shadow-amber-950/60'
                : 'border-cyan-400/80 shadow-cyan-950/60'
            }`}>
              {user?.avatarUrl ? (
                <img 
                  src={user.avatarUrl} 
                  alt={user.displayName} 
                  className={`w-full h-full object-cover rounded-[14px] ${status === 'NOT_APPLIED' ? 'grayscale contrast-125' : ''}`}
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full rounded-[14px] bg-slate-800 flex items-center justify-center font-bold text-white text-xl">
                  {(user?.displayName || 'U').charAt(0)}
                </div>
              )}
            </div>

            <span className="absolute -bottom-1 -right-1 bg-gradient-to-r from-cyan-500 to-teal-400 text-slate-950 text-[10px] font-black px-1.5 py-0.5 rounded-full shadow-sm flex items-center gap-0.5 z-10">
              <Sparkles size={9} />
              {isAr ? 'أنت' : 'YOU'}
            </span>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl sm:text-2xl font-bold text-white font-display tracking-wide">
                {user?.displayName || user?.username || 'Staff Member'}
              </h2>
              {isOwner && (
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                  <Crown size={12} className="text-amber-400" />
                  {isAr ? 'مالك السيرفر' : 'Owner'}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-300 flex-wrap">
              <span>{isAr ? 'الموقع الحالي على الخريطة:' : 'Map Position:'}</span>
              <span className="font-bold text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded-md border border-cyan-800/60">
                {isAr ? currentTier.nameAr : currentTier.name} ({currentTier.pointsLabel})
              </span>
              <span className="text-slate-400">•</span>
              <span className="font-mono font-bold text-slate-200">
                {currentPoints} {isAr ? 'نقطة حالية' : 'current pts'}
              </span>
            </div>

            {/* Application Status Badge with Apply Trigger */}
            <div className="flex items-center gap-2 pt-1 flex-wrap">
              <span className="text-xs text-slate-400">
                {isAr ? 'حالة التقديم للرتبة:' : 'Rank Application Status:'}
              </span>

              {status === 'NOT_APPLIED' && (
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-slate-400 bg-slate-800/90 border border-slate-700 px-2 py-0.5 rounded-md">
                    {isAr ? 'لم يقدّم (Not Applied)' : 'Not Applied'}
                  </span>
                  {staffMember && (
                    <button
                      type="button"
                      onClick={handleApply}
                      disabled={applying}
                      className="px-2.5 py-0.5 rounded-md bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1 shadow-sm transition-all disabled:opacity-50"
                    >
                      <Send size={11} />
                      <span>{isAr ? 'تقديم طلب ترقية' : 'Apply for Rank'}</span>
                    </button>
                  )}
                </div>
              )}

              {status === 'PENDING' && (
                <span className="text-xs font-bold text-amber-300 bg-amber-500/15 border border-amber-500/40 px-2 py-0.5 rounded-md flex items-center gap-1">
                  <Clock size={12} className="text-amber-400 animate-pulse" />
                  <span>{isAr ? 'قيد مراجعة المالك (Pending Approval)' : 'Pending Owner Approval'}</span>
                </span>
              )}

              {status === 'APPROVED' && (
                <span className="text-xs font-bold text-emerald-300 bg-emerald-500/15 border border-emerald-500/40 px-2 py-0.5 rounded-md flex items-center gap-1">
                  <CheckCircle2 size={12} className="text-emerald-400" />
                  <span>{isAr ? 'رتبة معتمدة من المالك (Rank Approved)' : 'Rank Approved by Owner'}</span>
                </span>
              )}

              <Link
                to="/codex/guide-applications"
                className="text-[11px] text-cyan-400/80 hover:text-cyan-300 inline-flex items-center gap-1 transition-colors ms-auto sm:ms-0"
              >
                <BookOpen size={12} />
                <span>{isAr ? 'دليل تقديم الطلبات' : 'Applications Guide'}</span>
              </Link>
            </div>
          </div>
        </div>

        {/* Right: Next Rank Milestone & Progress Meter */}
        <div className="lg:max-w-md w-full flex flex-col gap-2.5 bg-slate-950/60 rounded-xl p-4 border border-slate-800/80">
          <div className="flex items-center justify-between text-xs sm:text-sm">
            <span className="text-slate-400 font-medium">
              {isMaxTier 
                ? (isAr ? 'القمة الإدارية القصوى' : 'Highest Rank Achieved')
                : (isAr ? 'الرتبة القادمة المستهدفة:' : 'Next Milestone Rank:')}
            </span>

            {nextTier ? (
              <span className="font-bold text-teal-300 flex items-center gap-1">
                <span>{isAr ? nextTier.nameAr : nextTier.name}</span>
                <span className="text-xs text-slate-400 font-mono">({nextTier.minPoints} pts)</span>
              </span>
            ) : (
              <span className="font-bold text-white flex items-center gap-1">
                <Crown size={14} className="text-amber-300" />
                <span>{isAr ? 'مدير المجلس الأعلى (القمة)' : 'High Council Manager (Summit)'}</span>
              </span>
            )}
          </div>

          {/* Progress Bar */}
          {!isMaxTier && (
            <div className="space-y-1.5">
              <div className="w-full bg-slate-800/90 h-2.5 rounded-full overflow-hidden p-0.5 border border-slate-700/50">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.max(8, progressPercent)}%` }}
                  transition={{ duration: 0.8, ease: 'easeOut' }}
                  className="h-full bg-gradient-to-r from-cyan-500 via-teal-400 to-purple-500 rounded-full"
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span>
                  {isAr 
                    ? `متبقي ${remainingPoints} نقطة للوصول إلى العتبة التالية` 
                    : `${remainingPoints} pts remaining to reach threshold`}
                </span>
                <span className="font-mono font-semibold text-cyan-300">
                  {progressPercent}%
                </span>
              </div>
            </div>
          )}

          {/* Promotion Eligibility Notice (MANDATORY RULE) */}
          <div className="pt-2 border-t border-slate-800/60">
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <AlertCircle size={14} className="shrink-0 text-cyan-400" />
              <span>
                {isAr 
                  ? 'الوصول إلى النقاط لا يمنح الرتبة تلقائياً — يلزم تقديم طلب واعتماد المالك.' 
                  : 'Reaching points never auto-promotes; requires rank application and Owner approval.'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
