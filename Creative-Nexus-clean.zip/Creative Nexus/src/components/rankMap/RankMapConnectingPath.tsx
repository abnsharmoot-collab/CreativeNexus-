import React from 'react';
import { motion } from 'motion/react';

interface RankMapConnectingPathProps {
  isAr?: boolean;
}

export const RankMapConnectingPath: React.FC<RankMapConnectingPathProps> = ({ isAr = false }) => {
  return (
    <div 
      className="absolute top-4 bottom-4 left-1/2 -translate-x-1/2 w-8 pointer-events-none z-0 flex flex-col items-center justify-between"
      aria-hidden="true"
    >
      {/* Background spine track flowing through all 4 section colors */}
      <div className="absolute inset-y-0 w-1 bg-gradient-to-b from-cyan-500/40 via-amber-500/40 via-purple-500/40 to-slate-200/50 rounded-full" />
      
      {/* Subtle outer glow track */}
      <div className="absolute inset-y-0 w-4 bg-gradient-to-b from-cyan-500/15 via-amber-500/15 via-purple-500/15 to-white/20 blur-sm rounded-full" />

      {/* Downward Traveling Energy Pulse (from Lowest rank at top to Highest rank at bottom) */}
      <motion.div
        animate={{
          y: ['-100%', '900%'],
          opacity: [0, 1, 1, 0]
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: 'linear'
        }}
        className="absolute w-2 h-36 bg-gradient-to-b from-transparent via-cyan-300 via-amber-300 via-purple-300 to-white rounded-full shadow-[0_0_20px_rgba(255,255,255,0.7)]"
      />

      {/* Secondary softer wave traveling along the progression */}
      <motion.div
        animate={{
          y: ['-50%', '800%'],
          opacity: [0, 0.7, 0.7, 0]
        }}
        transition={{
          duration: 7.5,
          delay: 2.5,
          repeat: Infinity,
          ease: 'linear'
        }}
        className="absolute w-1.5 h-24 bg-gradient-to-b from-transparent via-teal-300 via-purple-300 to-white rounded-full shadow-[0_0_12px_rgba(168,85,247,0.7)]"
      />
    </div>
  );
};
