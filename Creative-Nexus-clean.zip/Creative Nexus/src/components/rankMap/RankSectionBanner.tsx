import React from 'react';
import { motion } from 'motion/react';
import { Lock, Unlock, Shield, Sparkles, ChevronDown } from 'lucide-react';
import { RankSectionInfo } from '../../types/rankMap';

interface RankSectionBannerProps {
  section: RankSectionInfo;
  isUnlocked: boolean;
  currentUserPoints: number;
  isOwner?: boolean;
  isAr?: boolean;
}

export const RankSectionBanner: React.FC<RankSectionBannerProps> = ({
  section,
  isUnlocked,
  currentUserPoints,
  isOwner = false,
  isAr = false
}) => {
  const getThemeStyles = () => {
    switch (section.theme) {
      case 'white':
        return {
          wrapperBorder: isUnlocked ? 'border-white/50 ring-1 ring-white/30' : 'border-slate-800',
          wrapperBg: isUnlocked 
            ? 'bg-gradient-to-r from-slate-900 via-slate-800 to-slate-950 shadow-[0_0_30px_rgba(255,255,255,0.12)]' 
            : 'bg-slate-950/80 border-dashed',
          badgeBg: 'bg-white/15 text-white border-white/40',
          titleColor: 'text-white',
          glowGradient: 'from-white/20 via-slate-300/10 to-transparent',
          accentColor: 'text-white'
        };
      case 'purple':
        return {
          wrapperBorder: isUnlocked ? 'border-purple-500/50 ring-1 ring-purple-500/20' : 'border-slate-800',
          wrapperBg: isUnlocked 
            ? 'bg-gradient-to-r from-purple-950/40 via-slate-900 to-slate-950 shadow-purple-950/40' 
            : 'bg-slate-950/80 border-dashed',
          badgeBg: 'bg-purple-500/15 text-purple-300 border-purple-500/40',
          titleColor: 'text-purple-200',
          glowGradient: 'from-purple-500/20 via-fuchsia-600/10 to-transparent',
          accentColor: 'text-purple-400'
        };
      case 'yellow':
        return {
          wrapperBorder: isUnlocked ? 'border-amber-500/50 ring-1 ring-amber-500/20' : 'border-slate-800',
          wrapperBg: isUnlocked 
            ? 'bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 shadow-amber-950/40' 
            : 'bg-slate-950/80 border-dashed',
          badgeBg: 'bg-amber-500/15 text-amber-300 border-amber-500/40',
          titleColor: 'text-amber-200',
          glowGradient: 'from-amber-500/20 via-yellow-600/10 to-transparent',
          accentColor: 'text-amber-400'
        };
      default:
        return {
          wrapperBorder: 'border-cyan-500/40 ring-1 ring-cyan-500/20',
          wrapperBg: 'bg-gradient-to-r from-cyan-950/40 via-slate-900 to-slate-950 shadow-cyan-950/40',
          badgeBg: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/40',
          titleColor: 'text-cyan-200',
          glowGradient: 'from-cyan-500/20 via-teal-600/10 to-transparent',
          accentColor: 'text-cyan-400'
        };
    }
  };

  const styles = getThemeStyles();
  const remainingToUnlock = Math.max(0, section.unlockThreshold - currentUserPoints);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.5 }}
      id={`section-banner-${section.id}`}
      className={`relative w-full max-w-4xl mx-auto my-12 rounded-2xl border p-5 sm:p-6 backdrop-blur-md overflow-hidden transition-all duration-300 ${styles.wrapperBorder} ${styles.wrapperBg}`}
    >
      {/* Ambient background glow */}
      <div className={`absolute inset-0 bg-gradient-to-r ${styles.glowGradient} opacity-30 pointer-events-none rounded-2xl`} />

      <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Left: Section Identity */}
        <div className="space-y-2">
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className={`text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-lg border ${styles.badgeBg}`}>
              {isAr ? section.badgeAr : section.badgeEn}
            </span>

            <span className="text-xs font-mono font-bold text-slate-400 px-2 py-0.5 rounded-md bg-slate-900 border border-slate-800">
              {section.pointRange}
            </span>

            {/* Unlocked / Locked Status Badge */}
            {isUnlocked ? (
              <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <Unlock size={11} className="text-emerald-400" />
                <span>{isAr ? 'مرحلة مفتوحة' : 'UNLOCKED'}</span>
              </span>
            ) : (
              <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg bg-slate-800 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                <Lock size={11} className="text-amber-400" />
                <span>{isAr ? 'مرحلة مقفلة' : 'LOCKED'}</span>
              </span>
            )}

            {isOwner && (
              <span className="text-[9px] text-slate-400 font-sans italic">
                ({isAr ? 'وصول إداري للمالك' : 'Owner bypass active'})
              </span>
            )}
          </div>

          <h3 className={`text-xl sm:text-2xl font-display font-bold tracking-tight ${styles.titleColor}`}>
            {isAr ? section.nameAr : section.name}
          </h3>

          <p className="text-xs sm:text-sm text-slate-400 max-w-xl font-sans leading-relaxed">
            {isAr ? section.descriptionAr : section.descriptionEn}
          </p>
        </div>

        {/* Right: Unlock Status Callout */}
        <div className="shrink-0 self-start md:self-center">
          {isUnlocked ? (
            <div className="flex items-center gap-2 text-xs text-emerald-300 bg-emerald-950/40 border border-emerald-500/30 px-3.5 py-2 rounded-xl">
              <Sparkles size={14} className="text-emerald-400 shrink-0" />
              <span className="font-semibold">
                {isAr ? 'المسار متاح للمعاينة والتأهل' : 'Progression path active'}
              </span>
            </div>
          ) : (
            <div className="space-y-1.5 text-xs text-slate-300 bg-slate-900/90 border border-slate-800 px-4 py-2.5 rounded-xl">
              <div className="flex items-center gap-1.5 text-amber-300 font-semibold">
                <Lock size={13} className="text-amber-400" />
                <span>{isAr ? 'شرط فتح المرحلة' : 'Unlock Requirement'}</span>
              </div>
              <p className="text-slate-400 text-[11px]">
                {isAr ? section.unlockRequirementAr : section.unlockRequirementEn}
              </p>
              {remainingToUnlock > 0 && (
                <div className="pt-1 flex items-center gap-1 text-[11px] text-cyan-300 font-mono">
                  <span>{isAr ? `متبقي لك:` : `Points needed:`}</span>
                  <span className="font-bold">{remainingToUnlock} PTS</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};
