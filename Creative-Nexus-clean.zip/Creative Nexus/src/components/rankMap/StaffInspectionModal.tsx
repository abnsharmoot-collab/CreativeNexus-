import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Award, 
  Shield, 
  Sparkles, 
  Calendar, 
  AlertCircle, 
  ExternalLink,
  ChevronRight,
  TrendingUp,
  UserCheck,
  Clock,
  CheckCircle2,
  XCircle,
  Send
} from 'lucide-react';
import { StaffMember } from '../../types/staff';
import { getNextTierInfo, RankTier, getTierForPoints } from '../../types/rankMap';
import { useRankApplications } from '../../context/RankApplicationContext';
import { Link } from 'react-router-dom';

interface StaffInspectionModalProps {
  member: StaffMember | null;
  isOpen: boolean;
  onClose: () => void;
  canManageStaff?: boolean;
  isOwner?: boolean;
  currentUserId?: string;
  isAr?: boolean;
}

export const StaffInspectionModal: React.FC<StaffInspectionModalProps> = ({
  member,
  isOpen,
  onClose,
  canManageStaff = false,
  isOwner = false,
  currentUserId,
  isAr = false
}) => {
  const { getApplicationForMember, getStatusForMember, applyForRank, approveApplication, rejectApplication, quickApproveMember } = useRankApplications();
  const [actionLoading, setActionLoading] = useState(false);
  const [reviewNote, setReviewNote] = useState('');

  if (!isOpen || !member) return null;

  const points = member.points || 0;
  const { currentTier, nextTier, remainingPoints, progressPercent, isMaxTier } = getNextTierInfo(points);
  const eligibleTier = getTierForPoints(points);
  const isEligible = points >= eligibleTier.minPoints;
  const application = getApplicationForMember(member.discordId, eligibleTier.id);
  const status = getStatusForMember(member.discordId, member, eligibleTier.id);
  const isSelf = member.discordId === currentUserId;

  const handleApply = async () => {
    setActionLoading(true);
    await applyForRank(member, eligibleTier.id);
    setActionLoading(false);
  };

  const handleApprove = async () => {
    setActionLoading(true);
    if (application) {
      await approveApplication(application.id, 'Owner Edgar', reviewNote);
    } else {
      await quickApproveMember(member, 'Owner Edgar', eligibleTier.id);
    }
    setActionLoading(false);
  };

  const handleReject = async () => {
    if (!application) return;
    setActionLoading(true);
    await rejectApplication(application.id, 'Owner Edgar', reviewNote);
    setActionLoading(false);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto" dir={isAr ? 'rtl' : 'ltr'}>
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          className="relative w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700/80 shadow-2xl p-5 sm:p-7 overflow-hidden z-10 space-y-6"
        >
          {/* Subtle gradient background */}
          <div className="absolute top-0 right-0 w-64 h-32 bg-cyan-500/10 blur-3xl pointer-events-none rounded-full" />

          {/* Modal Header & Close Button */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Sparkles size={16} className="text-cyan-400" />
              <h3 className="font-display font-bold text-lg text-white">
                {isAr ? 'تفاصيل ترقيات الإداري' : 'Staff Rank Progression'}
              </h3>
            </div>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
              aria-label="Close"
            >
              <X size={16} />
            </button>
          </div>

          {/* Member Card - Display name and avatar only, NO Discord ID */}
          <div className="flex items-center gap-4 bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
            <div className="relative shrink-0">
              <div className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-all ${
                status === 'NOT_APPLIED' 
                  ? 'border-slate-700 grayscale contrast-125' 
                  : status === 'PENDING'
                  ? 'border-amber-400/80 ring-2 ring-amber-500/20 shadow-md shadow-amber-950/40'
                  : 'border-cyan-400 shadow-md shadow-cyan-950/60'
              }`}>
                {member.avatarUrl ? (
                  <img 
                    src={member.avatarUrl} 
                    alt={member.displayName || member.username} 
                    className={`w-full h-full object-cover transition-all ${status === 'NOT_APPLIED' ? 'grayscale contrast-125' : ''}`}
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-full h-full bg-slate-800 flex items-center justify-center text-white font-bold text-xl">
                    {(member.displayName || member.username || '?').charAt(0)}
                  </div>
                )}
              </div>

              {/* Status Badge Tag */}
              {status === 'NOT_APPLIED' && (
                <span className="absolute -bottom-1.5 -right-1.5 bg-slate-800 text-slate-400 text-[9px] font-bold px-1.5 py-0.5 rounded-full border border-slate-700">
                  {isAr ? 'لم يقدّم' : 'Not Applied'}
                </span>
              )}
              {status === 'PENDING' && (
                <span className="absolute -bottom-1.5 -right-1.5 bg-amber-500/90 text-slate-950 text-[9px] font-bold px-1.5 py-0.5 rounded-full shadow-sm flex items-center gap-0.5">
                  <Clock size={8} />
                  {isAr ? 'قيد المراجعة' : 'Pending'}
                </span>
              )}
              {status === 'APPROVED' && (
                <span className="absolute -bottom-1.5 -right-1.5 bg-cyan-500 text-slate-950 text-[9px] font-bold px-1.5 py-0.5 rounded-full shadow-sm flex items-center gap-0.5">
                  <CheckCircle2 size={8} />
                  {isAr ? 'معتمد' : 'Approved'}
                </span>
              )}
            </div>

            <div className="min-w-0 flex-1 space-y-1">
              <h4 className="text-lg font-bold text-white truncate">
                {member.displayName || member.username}
              </h4>
              <p className="text-xs text-slate-400 font-sans truncate">
                @{member.username}
              </p>
              <div className="flex items-center gap-2 pt-0.5 flex-wrap">
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700">
                  {member.rank?.replace(/_/g, ' ') || 'STAFF'}
                </span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-800/60">
                  {points} {isAr ? 'نقطة' : 'pts'}
                </span>
              </div>
            </div>
          </div>

          {/* Application Status Banner */}
          <div className="p-3.5 rounded-xl border flex items-center justify-between gap-3 text-xs font-sans ${
            status === 'NOT_APPLIED'
              ? 'bg-slate-950/60 border-slate-800 text-slate-400'
              : status === 'PENDING'
              ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
              : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
          }">
            <div className="flex items-center gap-2">
              {status === 'NOT_APPLIED' && <Clock size={16} className="text-slate-400 shrink-0" />}
              {status === 'PENDING' && <Clock size={16} className="text-amber-400 shrink-0 animate-pulse" />}
              {status === 'APPROVED' && <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />}
              
              <div>
                <p className="font-bold text-slate-200">
                  {isAr ? 'حالة التقديم:' : 'Application Status:'}{' '}
                  <span className={
                    status === 'NOT_APPLIED' ? 'text-slate-400 font-normal' :
                    status === 'PENDING' ? 'text-amber-300' : 'text-emerald-300 font-bold'
                  }>
                    {status === 'NOT_APPLIED' ? (isAr ? 'لم يقدّم (Not Applied)' : 'Not Applied') :
                     status === 'PENDING' ? (isAr ? 'قيد المراجعة (Pending Approval)' : 'Pending Approval') :
                     (isAr ? 'رتبة معتمدة (Rank Approved)' : 'Rank Approved')}
                  </span>
                </p>
                {application?.reviewedBy && (
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    {isAr ? `تمت المراجعة بواسطة ${application.reviewedBy}` : `Reviewed by ${application.reviewedBy}`}
                  </p>
                )}
              </div>
            </div>

            {/* Quick action for member applying */}
            {isSelf && status === 'NOT_APPLIED' && (
              <button
                type="button"
                onClick={handleApply}
                disabled={actionLoading}
                className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors shrink-0 disabled:opacity-50"
              >
                <Send size={12} />
                <span>{isAr ? 'تقديم طلب' : 'Apply'}</span>
              </button>
            )}
          </div>

          {/* Position on Progression Map */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 font-medium">
                {isAr ? 'الرتبة الحالية حسب النقاط:' : 'Current Map Checkpoint:'}
              </span>
              <span className="font-bold text-cyan-300">
                {isAr ? currentTier.nameAr : currentTier.name} ({currentTier.pointsLabel})
              </span>
            </div>

            {!isMaxTier && nextTier && (
              <div className="space-y-1.5 bg-slate-950/40 p-3 rounded-xl border border-slate-800/60">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">
                    {isAr ? 'المستوى القادم المستهدف:' : 'Next Milestone Tier:'}
                  </span>
                  <span className="font-semibold text-teal-300">
                    {isAr ? nextTier.nameAr : nextTier.name} ({nextTier.minPoints} pts)
                  </span>
                </div>

                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-cyan-500 to-teal-400 rounded-full"
                    style={{ width: `${Math.max(5, progressPercent)}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>
                    {isAr 
                      ? `يحتاج ${remainingPoints} نقطة إضافية` 
                      : `Needs ${remainingPoints} more points`}
                  </span>
                  <span className="font-mono text-cyan-400 font-semibold">{progressPercent}%</span>
                </div>
              </div>
            )}
          </div>

          {/* Promotion / Approval Notice */}
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-slate-400 text-xs flex items-center gap-2">
            <AlertCircle size={14} className="shrink-0 text-slate-400" />
            <span>
              {isAr ? 'الترقية تتطلب موافقة المالك.' : 'Promotion requires Owner approval.'}
            </span>
          </div>

          {/* Owner Decision Controls */}
          {isOwner && (
            <div className="pt-3 border-t border-slate-800/80 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                  {isAr ? 'إجراءات مالك السيرفر' : 'Owner Decision'}
                </span>
                <span className="text-[11px] text-slate-400">
                  {eligibleTier.name} ({eligibleTier.pointsLabel})
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleApprove}
                  disabled={actionLoading || status === 'APPROVED'}
                  className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                    status === 'APPROVED'
                      ? 'bg-emerald-950/50 text-emerald-400 border border-emerald-800/50 cursor-default'
                      : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md shadow-emerald-950/40'
                  }`}
                >
                  <CheckCircle2 size={14} />
                  <span>{status === 'APPROVED' ? (isAr ? 'معتمد بالفعل' : 'Rank Approved') : (isAr ? 'اعتماد الرتبة' : 'Approve Rank')}</span>
                </button>

                <button
                  type="button"
                  onClick={handleReject}
                  disabled={actionLoading || status === 'NOT_APPLIED'}
                  className="py-2 px-3 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 font-bold text-xs flex items-center gap-1.5 transition-all disabled:opacity-50"
                >
                  <XCircle size={14} />
                  <span>{isAr ? 'رفض / إلغاء' : 'Reject'}</span>
                </button>
              </div>
            </div>
          )}

          {/* Footer Actions */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-800 gap-3">
            {canManageStaff ? (
              <Link
                to={`/staff-management/${member.id || member.discordId}`}
                className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 py-2 px-3 rounded-lg hover:bg-slate-800 transition-colors"
              >
                <span>{isAr ? 'فتح ملف الإداري بالتفصيل' : 'View in Staff Directory'}</span>
                <ExternalLink size={13} />
              </Link>
            ) : (
              <div />
            )}

            <button
              type="button"
              onClick={onClose}
              className="text-xs font-semibold px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white transition-colors"
            >
              {isAr ? 'إغلاق' : 'Close'}
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

