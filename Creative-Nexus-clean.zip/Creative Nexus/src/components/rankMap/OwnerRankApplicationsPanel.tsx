import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Crown, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Search, 
  Filter, 
  Award, 
  Eye, 
  Sparkles,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  UserCheck
} from 'lucide-react';
import { StaffMember } from '../../types/staff';
import { RankTier, getTierForPoints, RANK_TIERS, ApplicationStatus } from '../../types/rankMap';
import { useRankApplications } from '../../context/RankApplicationContext';

interface OwnerRankApplicationsPanelProps {
  staffList: StaffMember[];
  onSelectMember: (member: StaffMember) => void;
  isAr?: boolean;
}

export const OwnerRankApplicationsPanel: React.FC<OwnerRankApplicationsPanelProps> = ({
  staffList,
  onSelectMember,
  isAr = false
}) => {
  const { 
    applications, 
    getStatusForMember, 
    getApplicationForMember, 
    approveApplication, 
    rejectApplication, 
    quickApproveMember 
  } = useRankApplications();

  const [activeTab, setActiveTab] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'NOT_APPLIED'>('PENDING');
  const [searchQuery, setSearchQuery] = useState('');
  const [isExpanded, setIsExpanded] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);

  // Eligible staff members (active staff with points >= 0)
  const eligibleStaff = useMemo(() => {
    return staffList
      .filter(m => m.status !== 'REMOVED')
      .map(member => {
        const points = member.points || 0;
        const currentTier = getTierForPoints(points);
        const application = getApplicationForMember(member.discordId, currentTier.id);
        const status = getStatusForMember(member.discordId, member, currentTier.id);

        return {
          member,
          points,
          currentTier,
          targetTier: currentTier,
          application,
          status
        };
      })
      .sort((a, b) => {
        // Pending first, then approved, then not applied; secondary sort by points desc
        const statusWeight: Record<ApplicationStatus, number> = {
          PENDING: 3,
          NOT_APPLIED: 2,
          APPROVED: 1,
          REJECTED: 0
        };
        const wDiff = statusWeight[b.status] - statusWeight[a.status];
        if (wDiff !== 0) return wDiff;
        return b.points - a.points;
      });
  }, [staffList, getApplicationForMember, getStatusForMember]);

  // Counts
  const counts = useMemo(() => {
    return {
      all: eligibleStaff.length,
      pending: eligibleStaff.filter(s => s.status === 'PENDING').length,
      approved: eligibleStaff.filter(s => s.status === 'APPROVED').length,
      notApplied: eligibleStaff.filter(s => s.status === 'NOT_APPLIED').length
    };
  }, [eligibleStaff]);

  // Filtered staff list
  const filteredStaff = useMemo(() => {
    return eligibleStaff.filter(item => {
      // Tab filter
      if (activeTab === 'PENDING' && item.status !== 'PENDING') return false;
      if (activeTab === 'APPROVED' && item.status !== 'APPROVED') return false;
      if (activeTab === 'NOT_APPLIED' && item.status !== 'NOT_APPLIED') return false;

      // Search query - searches DISPLAY NAME or username ONLY, never Discord ID
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const nameMatch = (item.member.displayName || '').toLowerCase().includes(q) ||
                          (item.member.username || '').toLowerCase().includes(q);
        const tierMatch = (item.currentTier.name || '').toLowerCase().includes(q) ||
                          (item.currentTier.nameAr || '').toLowerCase().includes(q);
        if (!nameMatch && !tierMatch) return false;
      }

      return true;
    });
  }, [eligibleStaff, activeTab, searchQuery]);

  const handleApprove = async (item: typeof eligibleStaff[0]) => {
    setProcessingId(item.member.discordId);
    try {
      if (item.application) {
        await approveApplication(item.application.id, 'Owner Edgar');
      } else {
        await quickApproveMember(item.member, 'Owner Edgar', item.targetTier.id);
      }
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async (item: typeof eligibleStaff[0]) => {
    if (!item.application) return;
    setProcessingId(item.member.discordId);
    try {
      await rejectApplication(item.application.id, 'Owner Edgar');
    } finally {
      setProcessingId(null);
    }
  };

  return (
    <section 
      id="owner-rank-applications-panel"
      className="w-full rounded-2xl border border-amber-500/40 bg-gradient-to-br from-slate-900/95 via-slate-950 to-slate-900 shadow-2xl p-5 sm:p-7 relative overflow-hidden backdrop-blur-md"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* Ambient warm amber glow */}
      <div className="absolute top-0 right-1/4 w-96 h-36 bg-amber-500/10 blur-3xl pointer-events-none rounded-full" />

      {/* Header bar */}
      <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-500/20 to-amber-600/30 border border-amber-500/50 flex items-center justify-center shrink-0 shadow-inner">
            <Crown size={22} className="text-amber-400" />
          </div>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="font-display font-bold text-lg sm:text-xl text-white tracking-wide">
                {isAr ? 'منطقة تحكم المالك — طلبات واعتمادات الرتب' : 'Owner Control — Rank Applications'}
              </h2>
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                <span>{isAr ? 'صلاحية المالك' : 'Owner Authorization Only'}</span>
              </span>
            </div>

            <p className="text-xs text-slate-400 mt-0.5 leading-relaxed font-sans">
              {isAr 
                ? 'مراجعة واعتماد رتب الإداريين المؤهلين. الوصول إلى النقاط لا يمنح الرتبة تلقائياً — يلزم اعتماد المالك.' 
                : 'Review and approve eligible staff promotions. Reaching required points never auto-promotes — Owner approval required.'}
            </p>
          </div>
        </div>

        {/* Toggle collapse */}
        <div className="flex items-center gap-2 self-start md:self-center">
          <button
            type="button"
            onClick={() => setIsExpanded(prev => !prev)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-xs font-semibold text-slate-300 transition-colors border border-slate-700/60"
          >
            <span>{isExpanded ? (isAr ? 'طي القسم' : 'Collapse') : (isAr ? 'عرض الطلبات' : 'Expand Panel')}</span>
            {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="relative z-10 pt-5 space-y-4"
          >
            {/* Filter Tabs & Search Bar */}
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
              {/* Status Tabs */}
              <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-950/80 border border-slate-800 overflow-x-auto">
                <button
                  type="button"
                  onClick={() => setActiveTab('PENDING')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    activeTab === 'PENDING'
                      ? 'bg-amber-500 text-slate-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Clock size={13} className={activeTab === 'PENDING' ? '' : 'text-amber-400'} />
                  <span>{isAr ? 'قيد المراجعة' : 'Pending Approval'}</span>
                  <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                    activeTab === 'PENDING' ? 'bg-slate-900/30 text-slate-950' : 'bg-slate-800 text-amber-300'
                  }`}>
                    {counts.pending}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('ALL')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    activeTab === 'ALL'
                      ? 'bg-cyan-500 text-slate-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span>{isAr ? 'جميع المؤهلين' : 'All Eligible'}</span>
                  <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                    activeTab === 'ALL' ? 'bg-slate-900/30 text-slate-950' : 'bg-slate-800 text-cyan-300'
                  }`}>
                    {counts.all}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('APPROVED')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    activeTab === 'APPROVED'
                      ? 'bg-emerald-500 text-slate-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <CheckCircle2 size={13} className={activeTab === 'APPROVED' ? '' : 'text-emerald-400'} />
                  <span>{isAr ? 'رتب معتمدة' : 'Rank Approved'}</span>
                  <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                    activeTab === 'APPROVED' ? 'bg-slate-900/30 text-slate-950' : 'bg-slate-800 text-emerald-300'
                  }`}>
                    {counts.approved}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('NOT_APPLIED')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    activeTab === 'NOT_APPLIED'
                      ? 'bg-slate-700 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span>{isAr ? 'لم يقدّم' : 'Not Applied'}</span>
                  <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                    activeTab === 'NOT_APPLIED' ? 'bg-slate-900/40 text-white' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {counts.notApplied}
                  </span>
                </button>
              </div>

              {/* Search by Display Name */}
              <div className="relative min-w-[240px]">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={isAr ? 'بحث بالاسم المعروض...' : 'Search by display name...'}
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500 font-sans"
                />
              </div>
            </div>

            {/* Applications List */}
            {filteredStaff.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3.5 pt-2">
                {filteredStaff.map(({ member, points, currentTier, targetTier, status, application }) => {
                  const isProcessing = processingId === member.discordId;

                  return (
                    <motion.div
                      key={member.discordId}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className={`relative rounded-xl p-4 border transition-all ${
                        status === 'PENDING'
                          ? 'bg-gradient-to-b from-amber-950/20 to-slate-900/90 border-amber-500/40 ring-1 ring-amber-500/20'
                          : status === 'APPROVED'
                          ? 'bg-slate-900/80 border-emerald-500/30'
                          : 'bg-slate-900/60 border-slate-800'
                      }`}
                    >
                      {/* Top: Staff Member Info (Display Name + Avatar only, NO Discord ID) */}
                      <div className="flex items-start gap-3">
                        {/* Avatar obeying visual status */}
                        <div className="relative shrink-0">
                          <div className={`w-12 h-12 rounded-xl overflow-hidden border-2 transition-all ${
                            status === 'NOT_APPLIED'
                              ? 'border-slate-700 grayscale contrast-125 brightness-90'
                              : status === 'PENDING'
                              ? 'border-amber-400 shadow-md shadow-amber-950/60'
                              : 'border-cyan-400 shadow-md shadow-cyan-950/60'
                          }`}>
                            {member.avatarUrl ? (
                              <img
                                src={member.avatarUrl}
                                alt={member.displayName || member.username}
                                className={`w-full h-full object-cover ${status === 'NOT_APPLIED' ? 'grayscale contrast-125' : ''}`}
                                referrerPolicy="no-referrer"
                                loading="lazy"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = `https://cdn.discordapp.com/embed/avatars/${parseInt(member.discordId.slice(-1) || '0', 10) % 5}.png`;
                                }}
                              />
                            ) : (
                              <div className="w-full h-full bg-slate-800 flex items-center justify-center font-bold text-slate-300">
                                {(member.displayName || member.username || '?').charAt(0).toUpperCase()}
                              </div>
                            )}
                          </div>

                          {/* Pulsing indicator for pending */}
                          {status === 'PENDING' && (
                            <span className="absolute -top-1 -right-1 flex h-3 w-3">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500 border border-slate-900"></span>
                            </span>
                          )}
                        </div>

                        {/* Display Name & Points */}
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-1">
                            <h4 className="font-bold text-sm text-white truncate font-sans">
                              {member.displayName || member.username}
                            </h4>

                            {/* Points badge */}
                            <span className="shrink-0 text-[11px] font-bold px-2 py-0.5 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-800/60">
                              {points} {isAr ? 'نقطة' : 'pts'}
                            </span>
                          </div>

                          {/* Map position & Target rank */}
                          <div className="mt-1 space-y-0.5 text-[11px]">
                            <p className="text-slate-400 flex items-center gap-1 truncate">
                              <span className="text-slate-400">{isAr ? 'الموقع على الخريطة:' : 'Map Position:'}</span>
                              <span className="font-semibold text-slate-200">{currentTier.name} ({currentTier.pointsLabel})</span>
                            </p>
                            <p className="text-slate-400 flex items-center gap-1 truncate">
                              <span className="text-slate-400">{isAr ? 'الرتبة المستهدفة:' : 'Target Rank:'}</span>
                              <span className="font-semibold text-amber-300">{targetTier.name} ({targetTier.minPoints} pts req)</span>
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Status row */}
                      <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between gap-2">
                        {/* Status Label (MANDATORY REQUIREMENT) */}
                        <div className="flex items-center gap-1.5">
                          {status === 'NOT_APPLIED' && (
                            <span className="text-xs font-semibold text-slate-400 bg-slate-800/90 border border-slate-700/60 px-2 py-0.5 rounded-md flex items-center gap-1">
                              <span>{isAr ? 'لم يقدّم (Not Applied)' : 'Not Applied'}</span>
                            </span>
                          )}
                          {status === 'PENDING' && (
                            <span className="text-xs font-bold text-amber-300 bg-amber-500/15 border border-amber-500/40 px-2 py-0.5 rounded-md flex items-center gap-1">
                              <Clock size={11} className="text-amber-400 animate-pulse" />
                              <span>{isAr ? 'قيد المراجعة (Pending)' : 'Pending Approval'}</span>
                            </span>
                          )}
                          {status === 'APPROVED' && (
                            <span className="text-xs font-bold text-emerald-300 bg-emerald-500/15 border border-emerald-500/40 px-2 py-0.5 rounded-md flex items-center gap-1">
                              <CheckCircle2 size={11} className="text-emerald-400" />
                              <span>{isAr ? 'رتبة معتمدة (Approved)' : 'Rank Approved'}</span>
                            </span>
                          )}
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-1.5">
                          {/* Review Button */}
                          <button
                            type="button"
                            onClick={() => onSelectMember(member)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                            title={isAr ? 'مراجعة تفاصيل الإداري' : 'Review Details'}
                          >
                            <Eye size={14} />
                          </button>

                          {/* Approve Button */}
                          {status !== 'APPROVED' ? (
                            <button
                              type="button"
                              onClick={() => handleApprove({ member, points, currentTier, targetTier, status, application })}
                              disabled={isProcessing}
                              className="px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1 shadow-sm transition-all disabled:opacity-50"
                            >
                              <CheckCircle2 size={13} />
                              <span>{isAr ? 'اعتماد' : 'Approve'}</span>
                            </button>
                          ) : (
                            <span className="text-[11px] font-semibold text-emerald-400/90 px-2 py-0.5 rounded-md bg-emerald-950/60 border border-emerald-800/40">
                              {isAr ? 'معتمد' : 'Approved'}
                            </span>
                          )}

                          {/* Reject Button (if pending or applied) */}
                          {status === 'PENDING' && (
                            <button
                              type="button"
                              onClick={() => handleReject({ member, points, currentTier, targetTier, status, application })}
                              disabled={isProcessing}
                              className="p-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 transition-colors disabled:opacity-50"
                              title={isAr ? 'رفض الطلب' : 'Reject Application'}
                            >
                              <XCircle size={14} />
                            </button>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            ) : (
              <div className="rounded-xl border border-dashed border-slate-800 py-8 px-4 text-center bg-slate-950/40">
                <AlertCircle size={24} className="text-slate-400 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-300">
                  {isAr ? 'لا توجد طلبات تطابق هذا التصنيف' : 'No rank applications found for this filter'}
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  {isAr ? 'يمكنك تغيير تبويب الفرز أو مسح عبارة البحث' : 'Try selecting another tab or clearing your search'}
                </p>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};
