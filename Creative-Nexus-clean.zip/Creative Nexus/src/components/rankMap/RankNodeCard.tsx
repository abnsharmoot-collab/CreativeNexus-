import React from 'react';
import { motion } from 'motion/react';
import { 
  Award, 
  Users, 
  Sparkles, 
  CheckCircle2, 
  Layers,
  Crown,
  Lock,
  ShieldAlert
} from 'lucide-react';
import { RankTier } from '../../types/rankMap';
import { StaffMember } from '../../types/staff';
import { StaffAvatarBadge } from './StaffAvatarBadge';

interface RankNodeCardProps {
  tier: RankTier;
  stepNumber: number; // 1 (lowest) to 35 (highest)
  totalSteps?: number;
  members: StaffMember[];
  currentUserId?: string;
  isLocked?: boolean;
  unlockThreshold?: number;
  onSelectMember: (member: StaffMember) => void;
  isAr?: boolean;
}

// Progressive sizing from lowest rank (compact rectangular) to highest rank (grand rectangular)
const getPyramidWidthClass = (step: number, totalSteps: number = 35): string => {
  const ratio = Math.min(1, Math.max(0, (step - 1) / Math.max(1, totalSteps - 1)));
  if (ratio < 0.10) return 'max-w-[420px]';
  if (ratio < 0.20) return 'max-w-[460px]';
  if (ratio < 0.30) return 'max-w-[500px]';
  if (ratio < 0.40) return 'max-w-[550px]';
  if (ratio < 0.50) return 'max-w-[610px]';
  if (ratio < 0.60) return 'max-w-[670px]';
  if (ratio < 0.70) return 'max-w-[730px]';
  if (ratio < 0.80) return 'max-w-[790px]';
  if (ratio < 0.92) return 'max-w-[850px]';
  return 'max-w-[890px]'; // Zenith
};

export const RankNodeCard: React.FC<RankNodeCardProps> = ({
  tier,
  stepNumber,
  totalSteps = 35,
  members,
  currentUserId,
  isLocked = false,
  unlockThreshold,
  onSelectMember,
  isAr = false
}) => {
  const hasMembers = members.length > 0;
  const containsCurrentUser = members.some(m => m.discordId === currentUserId);
  const isZenith = stepNumber === totalSteps;
  const isHighCouncil = tier.section === 'high_council';
  const isGuard = tier.section === 'guard';
  const isGrandStaff = tier.section === 'grand_staff';
  const isLowestTier = stepNumber <= 2;

  const widthClass = getPyramidWidthClass(stepNumber, totalSteps);

  // Determine section styling themes
  const getSectionBadgeClass = () => {
    switch (tier.section) {
      case 'high_council':
        return 'border-white/40 bg-white/15 text-white shadow-white/10';
      case 'guard':
        return 'border-purple-500/40 bg-purple-500/15 text-purple-300 shadow-purple-500/15';
      case 'grand_staff':
        return 'border-amber-500/40 bg-amber-500/15 text-amber-300 shadow-amber-500/15';
      default:
        return 'border-cyan-500/40 bg-cyan-500/15 text-cyan-300 shadow-cyan-500/15';
    }
  };

  return (
    <motion.div
      id={`rank-platform-${tier.id}`}
      initial={{ opacity: 0, y: 30, scale: 0.96 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, amount: 0.1 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
      className={`relative w-full ${widthClass} mx-auto z-10 my-6 transition-all duration-300 ${
        isLocked ? 'opacity-85 hover:opacity-100' : ''
      }`}
    >
      {/* Central Spine Piercing Node / Dock */}
      <div className="absolute left-1/2 -translate-x-1/2 -top-4 z-20 flex flex-col items-center">
        <div className={`rounded-xl flex items-center justify-center font-display font-black shadow-lg transition-transform duration-300 border backdrop-blur-md ${
          isZenith 
            ? 'w-11 h-11 text-sm bg-gradient-to-br from-white via-slate-100 to-amber-200 text-slate-950 border-white ring-4 ring-white/30 shadow-[0_0_25px_rgba(255,255,255,0.4)]' 
            : isHighCouncil
            ? 'w-10 h-10 text-xs bg-slate-900/90 text-white border-white/60 shadow-white/20'
            : isGuard
            ? 'w-9 h-9 text-xs bg-purple-950/90 text-purple-200 border-purple-500/60 shadow-purple-900/40'
            : isGrandStaff
            ? 'w-9 h-9 text-xs bg-amber-950/90 text-amber-200 border-amber-500/60 shadow-amber-900/40'
            : containsCurrentUser
            ? 'w-10 h-10 text-xs bg-gradient-to-br from-cyan-400 to-teal-500 text-slate-950 border-cyan-300 ring-4 ring-cyan-500/30 shadow-cyan-500/50 scale-105'
            : isLowestTier
            ? 'w-8 h-8 text-[11px] bg-slate-800 text-slate-300 border-slate-700 shadow-black/80'
            : 'w-9 h-9 text-xs ' + tier.colorScheme.iconBg + ' ' + tier.colorScheme.iconColor + ' border-slate-700/80 shadow-black/80'
        }`}>
          {isZenith ? (
            <Crown size={18} className="fill-slate-950 text-slate-950" />
          ) : isLocked ? (
            <Lock size={13} className="text-slate-400" />
          ) : isHighCouncil ? (
            <Sparkles size={14} className="text-white" />
          ) : (
            <span>{String(stepNumber).padStart(2, '0')}</span>
          )}
        </div>
      </div>

      {/* Rectangular Card Body (Pyramid scale: smaller rectangle at lower ranks expanding down to larger grand rectangle) */}
      <div 
        className={`w-full rounded-2xl transition-all duration-300 border backdrop-blur-md shadow-2xl relative overflow-hidden ${
          isLowestTier
            ? 'p-4 sm:p-5 pt-6'
            : stepNumber >= 28
            ? 'p-5 sm:p-7 pt-7'
            : 'p-4 sm:p-6 pt-6'
        } ${
          isZenith
            ? 'border-white/80 bg-gradient-to-b from-slate-800/90 via-slate-900/95 to-slate-950 ring-2 ring-white/30 shadow-[0_0_35px_rgba(255,255,255,0.25)]'
            : containsCurrentUser
            ? 'border-cyan-500/80 bg-gradient-to-b from-cyan-950/40 via-slate-900/95 to-slate-950 ring-2 ring-cyan-500/30 shadow-cyan-950/60'
            : isHighCouncil
            ? 'border-slate-300/40 bg-gradient-to-b from-slate-900/95 via-slate-950/90 to-black hover:border-slate-200/60'
            : isGuard
            ? 'border-purple-500/35 bg-gradient-to-b from-purple-950/30 via-slate-900/90 to-slate-950 hover:border-purple-400/50'
            : isGrandStaff
            ? 'border-amber-500/35 bg-gradient-to-b from-amber-950/30 via-slate-900/90 to-slate-950 hover:border-amber-400/50'
            : 'border-slate-800/90 bg-gradient-to-b from-slate-900/90 via-slate-900/80 to-slate-950/95 hover:border-slate-700/90'
        }`}
      >
        {/* Ambient subtle color wash */}
        <div 
          className={`absolute inset-0 bg-gradient-to-r ${tier.colorScheme.gradient} opacity-20 pointer-events-none rounded-2xl`} 
        />

        {/* Card Header: Level Indicator, Rank Title, Point Range, Staff Counter */}
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 pb-4 border-b border-slate-800/80">
          <div className="space-y-1.5 flex-1 min-w-0">
            {/* Tier Level & Position Highlight */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`font-mono uppercase tracking-widest px-2 py-0.5 rounded-md border text-[9px] ${
                isZenith
                  ? 'font-bold bg-white/20 text-white border-white/50'
                  : isHighCouncil
                  ? 'text-slate-100 bg-slate-800/90 border-slate-600/80'
                  : isGuard
                  ? 'text-purple-300 bg-purple-950/60 border-purple-700/60'
                  : isGrandStaff
                  ? 'text-amber-300 bg-amber-950/60 border-amber-700/60'
                  : 'text-slate-400 bg-slate-800/80 border-slate-700/60'
              }`}>
                {isAr ? `المستوى ${stepNumber}` : `TIER ${stepNumber}`}
              </span>

              {/* Section Identity Badge */}
              <span className={`text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md border ${getSectionBadgeClass()}`}>
                {tier.section === 'high_council' ? (isAr ? '⚪ المجلس الأعلى' : '⚪ HIGH COUNCIL') :
                 tier.section === 'guard' ? (isAr ? '🟣 الحرس' : '🟣 CN GUARD') :
                 tier.section === 'grand_staff' ? (isAr ? '🟡 جراند ستاف' : '🟡 GRAND STAFF') :
                 (isAr ? 'طاقم الإدارة' : 'STAFF')}
              </span>

              {tier.track === 'girl' && (
                <span className="text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md bg-pink-500/20 text-pink-300 border border-pink-500/30">
                  {isAr ? 'طاقم الفتيات' : 'Girls Wing'}
                </span>
              )}

              {containsCurrentUser && (
                <span className="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center gap-1">
                  <CheckCircle2 size={10} className="text-cyan-400" />
                  <span>{isAr ? 'موقعك الحالي' : 'YOUR POSITION'}</span>
                </span>
              )}

              {isLocked && (
                <span className="text-[9px] font-semibold tracking-wider px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 border border-slate-700 flex items-center gap-1">
                  <Lock size={10} className="text-slate-400" />
                  <span>{isAr ? 'مرحلة مقفلة' : 'LOCKED SECTION'}</span>
                </span>
              )}
            </div>

            {/* Rank Titles */}
            <div className="flex items-baseline gap-2 flex-wrap">
              <h3 className={`font-display font-bold text-white tracking-wide ${
                isZenith
                  ? 'text-xl sm:text-2xl text-white'
                  : isHighCouncil
                  ? 'text-lg sm:text-xl text-slate-100'
                  : isGuard
                  ? 'text-lg sm:text-xl text-purple-100'
                  : isGrandStaff
                  ? 'text-lg sm:text-xl text-amber-100'
                  : 'text-base sm:text-lg'
              }`}>
                {isAr ? tier.nameAr : tier.name}
              </h3>
              <span className="text-xs text-slate-400 font-sans">
                ({isAr ? tier.name : tier.nameAr})
              </span>
            </div>

            {/* Description / Lore */}
            <p className="text-xs text-slate-400 leading-relaxed font-sans line-clamp-2">
              {isAr ? tier.descriptionAr : tier.description}
            </p>

            {/* Lock requirement hint if locked */}
            {isLocked && unlockThreshold && (
              <div className="flex items-center gap-1.5 text-[11px] text-amber-400/90 pt-0.5 font-sans">
                <Lock size={11} className="shrink-0 text-amber-400" />
                <span>
                  {isAr 
                    ? `يتطلب فتح قفل هذه المرحلة إكمال المرحلة السابقة (${unlockThreshold} نقطة)` 
                    : `Complete the previous section (${unlockThreshold} PTS) to unlock`}
                </span>
              </div>
            )}
          </div>

          {/* Right/Top: Point Range Requirement & Stationed Count */}
          <div className="flex items-center sm:flex-col sm:items-end gap-2 self-start shrink-0">
            {/* Point Range Pill */}
            <div className={`px-3 py-1 rounded-xl border ${tier.colorScheme.border} ${tier.colorScheme.badgeBg} ${tier.colorScheme.badgeText} flex items-center gap-1.5 shadow-sm font-sans font-bold text-xs tracking-wide shrink-0`}>
              <Award size={13} className="shrink-0" />
              <span>{tier.pointsLabel}</span>
            </div>

            {/* Stationed Count Pill */}
            <div className="flex items-center gap-1 text-[11px] text-slate-300 bg-slate-800/90 px-2 py-0.5 rounded-lg border border-slate-700/70 font-sans">
              <Users size={12} className="text-slate-400 shrink-0" />
              <span className="font-semibold">{members.length}</span>
              <span className="text-slate-400">{isAr ? 'إداري' : 'staff'}</span>
            </div>
          </div>
        </div>

        {/* Card Lower Deck: Staff Member Cards Around Platform */}
        <div className="relative z-10 pt-4">
          <div className="flex items-center justify-between mb-2.5 text-xs">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Layers size={12} className="text-slate-400" />
              <span>{isAr ? 'الإداريون المتواجدون' : 'Staff Members'}</span>
              <span className="text-slate-400 font-mono text-[10px]">({members.length})</span>
            </span>

            <span className="text-[10px] text-slate-400">
              {isAr ? 'انقر للمراجعة' : 'Click to inspect'}
            </span>
          </div>

          {hasMembers ? (
            /* Staff member cards arranged neatly inside rectangular platform */
            <div className="flex flex-wrap items-center gap-2.5 sm:gap-3">
              {members.map((member) => (
                <StaffAvatarBadge
                  key={member.discordId || String(member.id)}
                  member={member}
                  tier={tier}
                  isCurrentUser={member.discordId === currentUserId}
                  onSelect={onSelectMember}
                  isAr={isAr}
                />
              ))}
            </div>
          ) : (
            /* Empty State */
            <div className="rounded-xl border border-dashed border-slate-800/80 py-3 px-4 text-center bg-slate-950/40">
              <p className="text-[11px] text-slate-400 font-sans">
                {isAr 
                  ? 'لا يوجد إداريون متواجدون في هذا المستوى حالياً' 
                  : 'No staff members currently at this rank threshold'}
              </p>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};
