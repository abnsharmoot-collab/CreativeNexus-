import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Award, Clock, CheckCircle2, AlertCircle } from 'lucide-react';
import { StaffMember } from '../../types/staff';
import { RankTier } from '../../types/rankMap';
import { useRankApplications } from '../../context/RankApplicationContext';

interface StaffAvatarBadgeProps {
  member: StaffMember;
  isCurrentUser: boolean;
  tier: RankTier;
  onSelect: (member: StaffMember) => void;
  isAr?: boolean;
}

export const StaffAvatarBadge: React.FC<StaffAvatarBadgeProps> = ({
  member,
  isCurrentUser,
  tier,
  onSelect,
  isAr = false
}) => {
  const { getStatusForMember } = useRankApplications();
  const points = member.points || 0;
  const status = getStatusForMember(member.discordId, member, tier.id);

  return (
    <motion.button
      type="button"
      id={`staff-avatar-badge-${member.discordId}`}
      onClick={() => onSelect(member)}
      whileHover={{ y: -3, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={`relative group text-left transition-all rounded-xl p-2 sm:p-2.5 flex items-center gap-2.5 bg-slate-900/90 hover:bg-slate-800/95 border backdrop-blur-md flex-1 min-w-[140px] max-w-[260px] shadow-sm ${
        isCurrentUser 
          ? 'border-cyan-400/90 ring-2 ring-cyan-500/30 bg-cyan-950/40 shadow-md shadow-cyan-950/60'
          : status === 'APPROVED'
          ? 'border-emerald-500/40 hover:border-emerald-500/70'
          : status === 'PENDING'
          ? 'border-amber-500/40 hover:border-amber-500/70'
          : 'border-slate-800 hover:border-slate-700'
      }`}
      aria-label={`View ${member.displayName || member.username}`}
    >
      {/* Avatar with visual status indicator */}
      <div className="relative shrink-0">
        <div className={`w-11 h-11 sm:w-12 sm:h-12 rounded-xl overflow-hidden border-2 transition-all duration-200 ${
          status === 'NOT_APPLIED'
            ? 'border-slate-700 grayscale contrast-125 brightness-90'
            : status === 'PENDING'
            ? 'border-amber-400/90 ring-2 ring-amber-500/30 shadow-sm shadow-amber-950/60'
            : 'border-cyan-400 shadow-sm shadow-cyan-500/40'
        }`}>
          {member.avatarUrl ? (
            <img 
              src={member.avatarUrl} 
              alt={member.displayName || member.username} 
              className={`w-full h-full object-cover transition-all ${status === 'NOT_APPLIED' ? 'grayscale contrast-125' : ''}`}
              referrerPolicy="no-referrer"
              loading="lazy"
              onError={(e) => {
                (e.target as HTMLImageElement).src = `https://cdn.discordapp.com/embed/avatars/${parseInt(member.discordId.slice(-1) || '0', 10) % 5}.png`;
              }}
            />
          ) : (
            <div className="w-full h-full bg-slate-800 flex items-center justify-center text-slate-400 font-bold text-base">
              {(member.displayName || member.username || '?').charAt(0).toUpperCase()}
            </div>
          )}
        </div>

        {/* Current User "YOU" Badge */}
        {isCurrentUser && (
          <span 
            className="absolute -top-1.5 -right-1.5 bg-gradient-to-r from-cyan-500 to-teal-400 text-slate-950 text-[9px] font-black px-1.5 py-0.5 rounded-full shadow-sm tracking-wider uppercase flex items-center gap-0.5 z-10"
            title={isAr ? 'أنت (حسابك الحالي)' : 'You (Current User)'}
          >
            <Sparkles size={8} className="fill-slate-950" />
            {isAr ? 'أنت' : 'YOU'}
          </span>
        )}

        {/* Subtle Pending Pulsing Dot */}
        {status === 'PENDING' && (
          <span className="absolute -top-1 -left-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500 border border-slate-900"></span>
          </span>
        )}
      </div>

      {/* Member Details - DISPLAY NAME ONLY, NEVER Discord ID */}
      <div className="min-w-0 flex-1 flex flex-col justify-center">
        <div className="flex items-center gap-1.5">
          <span className="font-semibold text-xs sm:text-sm text-slate-100 truncate group-hover:text-cyan-300 transition-colors">
            {member.displayName || member.username}
          </span>
        </div>

        {/* Points & Application Visual Status */}
        <div className="flex items-center gap-1.5 mt-1 flex-wrap">
          {/* Points Pill */}
          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-cyan-400 bg-cyan-950/60 border border-cyan-800/60 px-1.5 py-0.5 rounded-md">
            <Award size={10} className="text-cyan-400 shrink-0" />
            <span>{points} {isAr ? 'ن' : 'pts'}</span>
          </span>

          {/* Visual Status Label (MANDATORY REQUIREMENT) */}
          {status === 'NOT_APPLIED' && (
            <span className="inline-flex items-center gap-0.5 text-[9px] font-medium text-slate-400 bg-slate-800/90 border border-slate-700/60 px-1.5 py-0.5 rounded-md">
              <span>{isAr ? 'لم يقدّم' : 'Not Applied'}</span>
            </span>
          )}

          {status === 'PENDING' && (
            <span className="inline-flex items-center gap-1 text-[9px] font-bold text-amber-300 bg-amber-500/15 border border-amber-500/40 px-1.5 py-0.5 rounded-md">
              <Clock size={9} className="text-amber-400 animate-pulse" />
              <span>{isAr ? 'قيد المراجعة' : 'Pending Approval'}</span>
            </span>
          )}

          {status === 'APPROVED' && (
            <span className="inline-flex items-center gap-1 text-[9px] font-bold text-emerald-300 bg-emerald-500/15 border border-emerald-500/40 px-1.5 py-0.5 rounded-md">
              <CheckCircle2 size={9} className="text-emerald-400" />
              <span>{isAr ? 'رتبة معتمدة' : 'Rank Approved'}</span>
            </span>
          )}
        </div>
      </div>
    </motion.button>
  );
};
