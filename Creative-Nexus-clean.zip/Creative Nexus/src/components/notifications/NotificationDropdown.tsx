import React, { useRef, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCheck, Bell, ChevronRight, ChevronLeft, ArrowRight, ArrowLeft, X } from 'lucide-react';
import { useNotifications } from '../../context/NotificationContext';
import { NotificationItemCard } from './NotificationItemCard';
import { useLanguage } from '../../context/LanguageContext';

interface NotificationDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  triggerRef?: React.RefObject<HTMLButtonElement | null>;
}

export const NotificationDropdown: React.FC<NotificationDropdownProps> = ({
  isOpen,
  onClose,
  triggerRef
}) => {
  const dropdownRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { language, t } = useLanguage();
  const isAr = language === 'ar';
  const {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    loading
  } = useNotifications();

  const [activeTab, setActiveTab] = useState<'ALL' | 'UNREAD'>('ALL');

  // Close when clicking or tapping outside, ignoring clicks on trigger bell button
  useEffect(() => {
    if (!isOpen) return;

    const handlePointerOutside = (event: MouseEvent | TouchEvent) => {
      const target = event.target as Node;
      if (triggerRef?.current && triggerRef.current.contains(target)) {
        return;
      }
      if (dropdownRef.current && !dropdownRef.current.contains(target)) {
        onClose();
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('mousedown', handlePointerOutside);
    document.addEventListener('touchstart', handlePointerOutside, { passive: true });
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('mousedown', handlePointerOutside);
      document.removeEventListener('touchstart', handlePointerOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose, triggerRef]);

  if (!isOpen) return null;

  const displayList = activeTab === 'UNREAD'
    ? notifications.filter((n) => !n.read)
    : notifications;

  const previewItems = displayList.slice(0, 8);

  const handleViewAll = () => {
    onClose();
    navigate('/notifications');
  };

  return (
    <>
      {/* Mobile Dim Backdrop */}
      <div 
        onClick={onClose}
        className="fixed inset-0 bg-black/70 backdrop-blur-xs sm:hidden z-40 animate-fade-in"
      />

      <div
        ref={dropdownRef}
        id="notification-dropdown-menu"
        className={`fixed left-2 right-2 xs:left-3 xs:right-3 top-[76px] xs:top-[86px] max-h-[76vh] max-w-[calc(100vw-1rem)] mx-auto flex flex-col sm:absolute sm:inset-x-auto sm:top-full sm:mt-2.5 sm:w-[410px] sm:max-h-none rounded-2xl bg-[#061817]/98 sm:bg-[#0b0f17]/95 backdrop-blur-2xl border border-[rgba(158,255,230,0.22)] sm:border-white/10 shadow-[0_20px_60px_rgba(0,0,0,0.9)] z-50 overflow-hidden transition-all duration-200 box-border ${
          isAr ? 'sm:right-0 sm:left-auto' : 'sm:right-0 sm:left-auto'
        }`}
      >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3.5 border-b border-white/5 bg-white/[0.02]">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-archive-cyan/10 text-archive-cyan flex items-center justify-center border border-archive-cyan/20">
            <Bell size={16} />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white tracking-tight leading-none">
              {t('notifications.title')}
            </h3>
            <p className="text-[11px] text-white/40 mt-1">
              {unreadCount > 0
                ? `${unreadCount} ${t('notifications.unread').toLowerCase()}`
                : t('notifications.emptyUnread')}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {unreadCount > 0 && (
            <button
              id="btn-dropdown-mark-all-read"
              type="button"
              onClick={() => markAllAsRead()}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium text-archive-cyan hover:text-white bg-archive-cyan/10 hover:bg-archive-cyan/20 border border-archive-cyan/20 transition-all cursor-pointer"
              title={t('notifications.markAllRead')}
            >
              <CheckCheck size={13} />
              <span className="hidden xs:inline">{t('notifications.markAllRead')}</span>
            </button>
          )}

          <button
            id="btn-dropdown-close-mobile"
            type="button"
            onClick={onClose}
            className="sm:hidden p-1.5 rounded-lg text-white/40 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Close"
          >
            <X size={16} />
          </button>
        </div>
      </div>

      {/* Tabs & Mobile Swipe Hint */}
      <div className="flex items-center justify-between px-3 py-2 bg-white/[0.01] border-b border-white/5 text-xs">
        <div className="flex items-center gap-1">
          <button
            id="tab-dropdown-all"
            type="button"
            onClick={() => setActiveTab('ALL')}
            className={`px-3 py-1 rounded-lg font-medium transition-all ${
              activeTab === 'ALL'
                ? 'bg-white/10 text-white font-semibold shadow-sm'
                : 'text-white/50 hover:text-white hover:bg-white/5'
            }`}
          >
            {t('notifications.filterAll')}
            <span className="text-[10px] text-white/40 ml-1">({notifications.length})</span>
          </button>

          <button
            id="tab-dropdown-unread"
            type="button"
            onClick={() => setActiveTab('UNREAD')}
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg font-medium transition-all ${
              activeTab === 'UNREAD'
                ? 'bg-archive-cyan/15 text-archive-cyan border border-archive-cyan/25 font-semibold shadow-sm'
                : 'text-white/50 hover:text-white hover:bg-white/5'
            }`}
          >
            <span>{t('notifications.unread')}</span>
            {unreadCount > 0 && (
              <span className="w-1.5 h-1.5 rounded-full bg-archive-cyan animate-pulse" />
            )}
            <span className="text-[10px] text-white/50">({unreadCount})</span>
          </button>
        </div>

        {/* Swipe Hint for Mobile */}
        <span className="hidden xs:inline-block text-[10px] text-archive-cyan/60 italic tracking-tight">
          {t('notifications.swipeHint')}
        </span>
      </div>

      {/* List */}
      <div className="max-h-[min(380px,50vh)] overflow-y-auto p-2 sm:p-2.5 space-y-2 overscroll-contain">
        {loading ? (
          <div className="py-8 text-center text-xs text-white/40">
            <div className="w-5 h-5 border-2 border-archive-cyan/30 border-t-archive-cyan rounded-full animate-spin mx-auto mb-2" />
            Loading notifications...
          </div>
        ) : previewItems.length === 0 ? (
          <div className="py-8 px-4 text-center">
            <div className="w-10 h-10 rounded-full bg-white/5 text-white/40 flex items-center justify-center mx-auto mb-2.5">
              <Bell size={18} />
            </div>
            <p className="text-xs font-medium text-white/70">
              {activeTab === 'UNREAD'
                ? t('notifications.emptyUnread')
                : t('notifications.empty')}
            </p>
            <p className="text-[11px] text-white/40 mt-1 max-w-[220px] mx-auto">
              {t('notifications.emptyDesc')}
            </p>
          </div>
        ) : (
          previewItems.map((item) => (
            <NotificationItemCard
              key={item.id}
              notification={item}
              onMarkAsRead={markAsRead}
              onDelete={deleteNotification}
              onNavigate={onClose}
              compact
            />
          ))
        )}
      </div>

      {/* Footer */}
      <div className="p-2 border-t border-white/5 bg-white/[0.02]">
        <button
          id="btn-dropdown-view-all"
          type="button"
          onClick={handleViewAll}
          className="w-full py-2 px-3 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] text-archive-paper hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-all border border-white/5 hover:border-white/10"
        >
          <span>{t('notifications.viewAll')}</span>
          {isAr ? <ArrowLeft size={13} /> : <ArrowRight size={13} />}
        </button>
      </div>
      </div>
    </>
  );
};
