import React, { useState, useRef } from 'react';
import { Bell } from 'lucide-react';
import { useNotifications } from '../../context/NotificationContext';
import { NotificationDropdown } from './NotificationDropdown';
import { useLanguage } from '../../context/LanguageContext';

interface NotificationBellProps {
  className?: string;
}

export const NotificationBell: React.FC<NotificationBellProps> = ({ className = '' }) => {
  const [isOpen, setIsOpen] = useState(false);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const { unreadCount } = useNotifications();
  const { t } = useLanguage();

  const toggleDropdown = () => {
    setIsOpen(prev => !prev);
  };

  return (
    <div className={`relative inline-block ${className}`}>
      <button
        ref={buttonRef}
        id="navbar-notification-bell-btn"
        type="button"
        onClick={toggleDropdown}
        aria-label={t('notifications.title')}
        aria-expanded={isOpen}
        className={`relative w-7.5 h-7.5 sm:w-8 sm:h-8 flex items-center justify-center rounded-lg sm:rounded-xl transition-all duration-300 border cursor-pointer active:scale-95 shrink-0 ${
          isOpen
            ? 'bg-gradient-to-br from-[#5eead4]/25 via-teal-500/20 to-[#5eead4]/15 text-[#5eead4] border-[#5eead4]/70 shadow-[0_0_16px_rgba(94,234,212,0.4),inset_0_1px_0_rgba(255,255,255,0.2)]'
            : unreadCount > 0
            ? 'bg-gradient-to-b from-[#06242c]/95 to-[#031518]/95 hover:from-[#093540] hover:to-[#052127] text-teal-200 hover:text-[#5eead4] border-[#5eead4]/45 hover:border-[#5eead4]/80 shadow-[0_2px_10px_rgba(0,0,0,0.5),0_0_12px_rgba(94,234,212,0.25),inset_0_1px_0_rgba(94,234,212,0.2)]'
            : 'bg-gradient-to-b from-[#051c22]/95 to-[#021216]/95 hover:from-[#082a33] hover:to-[#041a1f] text-teal-300/80 hover:text-[#5eead4] border-[#5eead4]/30 hover:border-[#5eead4]/70 shadow-[0_2px_8px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(94,234,212,0.15)] hover:shadow-[0_0_14px_rgba(94,234,212,0.3)]'
        }`}
      >
        <Bell size={15} className={`transition-transform duration-200 ${isOpen ? 'rotate-12 scale-110' : 'group-hover:scale-105'}`} />

        {unreadCount > 0 && (
          <span
            id="navbar-notification-unread-badge"
            className="absolute -top-1 -end-1 min-w-[15px] h-[15px] px-1 rounded-full bg-gradient-to-r from-[#5eead4] via-teal-300 to-emerald-300 text-stone-950 text-[8.5px] font-extrabold flex items-center justify-center shadow-[0_0_8px_rgba(94,234,212,0.85)] tabular-nums"
          >
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
      </button>

      <NotificationDropdown
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        triggerRef={buttonRef}
      />
    </div>
  );
};
