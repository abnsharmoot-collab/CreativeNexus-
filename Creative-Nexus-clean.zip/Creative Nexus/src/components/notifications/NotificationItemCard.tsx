import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, ArrowRight, ArrowLeft, Trash2, CheckCheck } from 'lucide-react';
import { AppNotification } from '../../types/notification';
import { NotificationIcon } from './NotificationIcon';
import { useLanguage } from '../../context/LanguageContext';

interface NotificationItemCardProps {
  notification: AppNotification;
  onMarkAsRead: (id: string) => void;
  onDelete?: (id: string) => void;
  onNavigate?: () => void;
  compact?: boolean;
}

export const NotificationItemCard: React.FC<NotificationItemCardProps> = ({
  notification,
  onMarkAsRead,
  onDelete,
  onNavigate,
  compact = false
}) => {
  const navigate = useNavigate();
  const { language, t } = useLanguage();
  const isAr = language === 'ar';

  // Touch Swipe Gesture State
  const [offsetX, setOffsetX] = useState(0);
  const [isSwiping, setIsSwiping] = useState(false);
  const touchStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const isTrackingRef = useRef(false);
  const isHorizSwipeRef = useRef(false);

  const formatRelativeTime = (isoString: string) => {
    try {
      const now = new Date().getTime();
      const past = new Date(isoString).getTime();
      const diffMs = Math.max(0, now - past);
      const diffSecs = Math.floor(diffMs / 1000);
      const diffMins = Math.floor(diffSecs / 60);
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffSecs < 60) return t('notifications.justNow');
      if (diffMins < 60) return `${diffMins} ${t('notifications.minsAgo')}`;
      if (diffHours < 24) return `${diffHours} ${t('notifications.hoursAgo')}`;
      return `${diffDays} ${t('notifications.daysAgo')}`;
    } catch {
      return '';
    }
  };

  // Touch event handlers for swipe gesture
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartRef.current = {
      x: e.touches[0].clientX,
      y: e.touches[0].clientY
    };
    isTrackingRef.current = true;
    isHorizSwipeRef.current = false;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isTrackingRef.current) return;

    const dx = e.touches[0].clientX - touchStartRef.current.x;
    const dy = e.touches[0].clientY - touchStartRef.current.y;

    // Detect dominant direction
    if (!isHorizSwipeRef.current) {
      // If vertical movement exceeds horizontal, allow native page scroll and stop tracking
      if (Math.abs(dy) > 10 && Math.abs(dy) > Math.abs(dx)) {
        isTrackingRef.current = false;
        return;
      }
      // If swiping left, lock into horizontal swipe
      if (dx < -8 && Math.abs(dx) > Math.abs(dy)) {
        isHorizSwipeRef.current = true;
        setIsSwiping(true);
      }
    }

    if (isHorizSwipeRef.current) {
      // Limit swipe distance between -130px and 0px
      const clamped = Math.max(-130, Math.min(0, dx));
      setOffsetX(clamped);
    }
  };

  const handleTouchEnd = () => {
    if (isHorizSwipeRef.current) {
      if (offsetX <= -105) {
        // Deep swipe left: auto-trigger mark as read or delete
        if (!notification.read) {
          onMarkAsRead(notification.id);
        } else if (onDelete) {
          onDelete(notification.id);
        }
        setOffsetX(0);
      } else if (offsetX <= -45) {
        // Snap open to reveal action tray (-96px)
        setOffsetX(-96);
      } else {
        // Snap closed
        setOffsetX(0);
      }
    }

    isTrackingRef.current = false;
    isHorizSwipeRef.current = false;
    setIsSwiping(false);
  };

  const handleClick = () => {
    // If the card is currently swiped open, click closes it
    if (offsetX !== 0) {
      setOffsetX(0);
      return;
    }

    if (!notification.read) {
      onMarkAsRead(notification.id);
    }
    if (notification.link) {
      navigate(notification.link);
      if (onNavigate) onNavigate();
    }
  };

  const handleMarkReadClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onMarkAsRead(notification.id);
    setOffsetX(0);
  };

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onDelete) {
      onDelete(notification.id);
    }
    setOffsetX(0);
  };

  return (
    <div
      id={`notification-card-container-${notification.id}`}
      className="relative overflow-hidden rounded-xl touch-pan-y select-none"
    >
      {/* Background Swipe Action Tray (Revealed on Swipe Left) */}
      <div
        className="absolute inset-y-0 right-0 w-[105px] flex items-center justify-end gap-1.5 px-2 bg-gradient-to-l from-archive-dark via-archive-dark/95 to-transparent z-0 pointer-events-auto"
        aria-hidden={offsetX === 0}
      >
        {/* Quick Mark Read Action */}
        {!notification.read && (
          <button
            type="button"
            onClick={handleMarkReadClick}
            aria-label={t('notifications.markRead')}
            title={t('notifications.markRead')}
            className="flex flex-col items-center justify-center w-11 h-11 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-500/30 transition-all active:scale-95 cursor-pointer shadow-md"
          >
            <Check size={16} />
            <span className="text-[8px] font-bold mt-0.5 tracking-tight">Read</span>
          </button>
        )}

        {/* Quick Delete Action */}
        {onDelete && (
          <button
            type="button"
            onClick={handleDeleteClick}
            aria-label={t('notifications.delete')}
            title={t('notifications.delete')}
            className="flex flex-col items-center justify-center w-11 h-11 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/40 hover:bg-rose-500/30 transition-all active:scale-95 cursor-pointer shadow-md"
          >
            <Trash2 size={16} />
            <span className="text-[8px] font-bold mt-0.5 tracking-tight">Delete</span>
          </button>
        )}
      </div>

      {/* Foreground Sliding Card Surface */}
      <div
        id={`notification-card-${notification.id}`}
        onClick={handleClick}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onTouchCancel={handleTouchEnd}
        style={{
          transform: `translateX(${offsetX}px)`,
          transition: isSwiping ? 'none' : 'transform 0.22s cubic-bezier(0.16, 1, 0.3, 1)'
        }}
        className={`group relative z-10 rounded-xl cursor-pointer border ${
          notification.read
            ? 'bg-[#0f141d]/90 border-white/5 hover:bg-[#121924] hover:border-white/10 opacity-80 hover:opacity-100'
            : 'bg-[#101722] border-archive-cyan/20 hover:bg-[#131d2b] hover:border-archive-cyan/35'
        } ${compact ? 'p-3' : 'p-4 sm:p-5'}`}
      >
        <div className="flex items-start gap-3">
          {/* Type Icon */}
          <div className="shrink-0 mt-0.5">
            <NotificationIcon type={notification.type} size={compact ? 16 : 18} />
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2 mb-1">
              <h4
                className={`font-medium tracking-tight truncate ${
                  compact ? 'text-xs sm:text-sm' : 'text-sm sm:text-base'
                } ${notification.read ? 'text-archive-paper/85' : 'text-white font-semibold'}`}
              >
                {notification.title}
              </h4>

              {/* Time & Read indicator */}
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[10px] text-white/40 tabular-nums">
                  {formatRelativeTime(notification.createdAt)}
                </span>
                {!notification.read && (
                  <span
                    title={t('notifications.unread')}
                    className="w-2 h-2 rounded-full bg-archive-cyan animate-pulse shadow-sm shadow-archive-cyan/50"
                  />
                )}
              </div>
            </div>

            <p
              className={`text-white/60 leading-relaxed break-words ${
                compact ? 'text-xs line-clamp-2' : 'text-xs sm:text-sm'
              }`}
            >
              {notification.description}
            </p>

            {/* Footer Actions */}
            <div className="mt-2.5 flex items-center justify-between gap-2 pt-1">
              {notification.link ? (
                <span className="inline-flex items-center gap-1 text-[11px] font-medium text-archive-cyan hover:text-archive-cyan/80 transition-colors">
                  {t('notifications.openTarget')}
                  {isAr ? <ArrowLeft size={12} /> : <ArrowRight size={12} />}
                </span>
              ) : (
                <span />
              )}

              <div className="flex items-center gap-1.5">
                {/* Mark as read button */}
                {!notification.read && (
                  <button
                    id={`btn-mark-read-${notification.id}`}
                    type="button"
                    onClick={handleMarkReadClick}
                    className="inline-flex items-center gap-1 text-[11px] font-medium text-white/60 hover:text-white px-2 py-0.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                    title={t('notifications.markRead')}
                  >
                    <Check size={12} className="text-emerald-400" />
                    <span className="hidden sm:inline">{t('notifications.markRead')}</span>
                  </button>
                )}

                {/* Delete / dismiss button (desktop hover & mobile option) */}
                {onDelete && (
                  <button
                    id={`btn-delete-${notification.id}`}
                    type="button"
                    onClick={handleDeleteClick}
                    className="inline-flex items-center gap-1 text-[11px] font-medium text-white/40 hover:text-rose-400 px-1.5 py-0.5 rounded-lg hover:bg-rose-500/10 transition-colors"
                    title={t('notifications.delete')}
                  >
                    <Trash2 size={12} />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
