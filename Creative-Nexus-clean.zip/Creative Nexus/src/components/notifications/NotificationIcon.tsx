import React from 'react';
import { 
  Coins, 
  TrendingDown, 
  FileText, 
  CheckCircle2, 
  XCircle, 
  Trophy, 
  Shield, 
  Megaphone, 
  Bell,
  Palette
} from 'lucide-react';
import { NotificationType } from '../../types/notification';

interface NotificationIconProps {
  type: NotificationType;
  className?: string;
  size?: number;
}

export const NotificationIcon: React.FC<NotificationIconProps> = ({ 
  type, 
  className = '', 
  size = 18 
}) => {
  switch (type) {
    case 'POINTS_ADDED':
      return (
        <div className={`p-2 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 ${className}`}>
          <Coins size={size} />
        </div>
      );
    case 'POINTS_REMOVED':
      return (
        <div className={`p-2 rounded-xl bg-rose-500/15 text-rose-400 border border-rose-500/20 ${className}`}>
          <TrendingDown size={size} />
        </div>
      );
    case 'RANK_APPLICATION_SUBMITTED':
      return (
        <div className={`p-2 rounded-xl bg-cyan-500/15 text-cyan-400 border border-cyan-500/20 ${className}`}>
          <FileText size={size} />
        </div>
      );
    case 'RANK_APPLICATION_APPROVED':
      return (
        <div className={`p-2 rounded-xl bg-teal-500/15 text-teal-400 border border-teal-500/20 ${className}`}>
          <CheckCircle2 size={size} />
        </div>
      );
    case 'RANK_APPLICATION_REJECTED':
      return (
        <div className={`p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/20 ${className}`}>
          <XCircle size={size} />
        </div>
      );
    case 'ACHIEVEMENT_EARNED':
      return (
        <div className={`p-2 rounded-xl bg-yellow-500/15 text-yellow-400 border border-yellow-500/20 ${className}`}>
          <Trophy size={size} />
        </div>
      );
    case 'STAFF_STATUS_CHANGED':
      return (
        <div className={`p-2 rounded-xl bg-purple-500/15 text-purple-400 border border-purple-500/20 ${className}`}>
          <Shield size={size} />
        </div>
      );
    case 'ANNOUNCEMENT':
      return (
        <div className={`p-2 rounded-xl bg-sky-500/15 text-sky-400 border border-sky-500/20 ${className}`}>
          <Megaphone size={size} />
        </div>
      );
    case 'THEME_UNLOCKED':
      return (
        <div className={`p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 ${className}`}>
          <Palette size={size} />
        </div>
      );
    default:
      return (
        <div className={`p-2 rounded-xl bg-white/10 text-white/70 border border-white/10 ${className}`}>
          <Bell size={size} />
        </div>
      );
  }
};
