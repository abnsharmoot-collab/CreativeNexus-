import React from 'react';
import { motion } from 'motion/react';
import { BattleCardEntity } from '../../types/story';
import { CollectibleCardData } from '../../types/cards';
import { getRarityConfig, RarityVisualConfig } from '../../config/rarityConfig';
import { canCardUseSkill } from '../../config/combatActions';
import { Shield, Skull, Zap, Swords, Flame, Sparkles } from 'lucide-react';

export type RarityCardVariant = 'table' | 'hand' | 'inspector' | 'deck' | 'preview';

export interface RarityCardProps {
  card: BattleCardEntity | CollectibleCardData;
  isEnemy?: boolean;
  variant?: RarityCardVariant;
  isSelected?: boolean;
  isHovered?: boolean;
  isDead?: boolean;
  onClick?: () => void;
  className?: string;
  isAr?: boolean;
}

/**
 * Unified RarityCard Component
 * Shared single component for BOTH Player and Enemy cards across Battlefield, Hand, and Inspector.
 * Guarantees visual consistency of the 5-rarity system:
 * - COMMON: Muted gray (#777777), desaturated, dark frame, minimal glow
 * - UNCOMMON: Green (#35C759), green border, subtle green glow, soft shimmer
 * - RARE: Blue (#3B82F6), blue border, blue accent lighting, subtle glow
 * - EPIC: Purple (#A855F7), purple border, ambient purple glow, elaborate energy
 * - LEGENDARY: Gold (#F59E0B / #FFD700), golden gradient, strong elegant glow, floating gold particles
 */
export const RarityCard: React.FC<RarityCardProps> = ({
  card,
  isEnemy = false,
  variant = 'hand',
  isSelected = false,
  isHovered = false,
  isDead = false,
  onClick,
  className = '',
  isAr = false
}) => {
  // Extract core card data safely regardless of BattleCardEntity vs CollectibleCardData
  const rawData: CollectibleCardData = ('card' in card && card.card) ? card.card : (card as CollectibleCardData);
  const cardName = rawData.name || 'Fighter';
  const imageUrl = rawData.imageUrl;
  const attack = ('attack' in card ? card.attack : rawData.attack) ?? 25;
  const defense = ('defense' in card ? card.defense : rawData.defense) ?? 20;
  const currentHp = ('currentHp' in card ? card.currentHp : rawData.hp) ?? 100;
  const maxHp = ('maxHp' in card ? card.maxHp : rawData.hp) ?? 100;
  const shield = ('shield' in card ? card.shield : 0) ?? 0;
  const currentStamina = ('currentStamina' in card ? card.currentStamina : 100) ?? 100;
  const skill = ('skill' in card ? card.skill : null);
  const hasSkill = canCardUseSkill(card as any);

  const rarityConf: RarityVisualConfig = getRarityConfig(rawData.rarity);
  const isCommon = rarityConf.id === 'COMMON';
  const isLegendary = rarityConf.id === 'LEGENDARY';
  const isEpic = rarityConf.id === 'EPIC';
  const isUncommon = rarityConf.id === 'UNCOMMON';

  // =========================================================================
  // 1. VARIANT: TABLE (Battlefield active zone card)
  // Clean, tactile slab with rarity frame, top name, and small rarity badge.
  // Zero overlapping stats numbers covering the face.
  // =========================================================================
  if (variant === 'table') {
    return (
      <div
        onClick={onClick}
        className={`w-full h-full rounded-xl sm:rounded-2xl overflow-hidden border-2 flex flex-col justify-between relative select-none transition-all duration-300 ${
          isDead ? 'opacity-40 grayscale' : ''
        } ${className}`}
        style={{
          background: rarityConf.bgGradient,
          borderColor: rarityConf.borderColor,
          boxShadow: `${rarityConf.depthShadow}, 0 0 16px ${rarityConf.glowColor}`
        }}
      >
        {/* Rarity-specific Ambient Lighting */}
        <div 
          className="absolute inset-0 pointer-events-none opacity-30 mix-blend-screen"
          style={{
            background: `radial-gradient(circle at 50% 25%, ${rarityConf.glowColor} 0%, transparent 75%)`
          }}
        />

        {/* Specular Top Rim */}
        <div 
          className="absolute top-0 inset-x-0 h-[2px] opacity-95 pointer-events-none z-20"
          style={{
            background: `linear-gradient(to right, transparent, ${rarityConf.accentColor}, transparent)`
          }}
        />

        {/* Subtle Animated Shimmer for Rare/Epic/Legendary */}
        {(isLegendary || isEpic) && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden z-15">
            <span className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-amber-300/60 animate-ping" />
          </div>
        )}

        {/* Card Artwork */}
        <img 
          src={imageUrl} 
          alt={cardName} 
          className={`absolute inset-0 w-full h-full object-cover pointer-events-none ${rarityConf.saturationClass}`}
        />

        {/* Shading Gradient for High Contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/95 via-transparent to-slate-950/50 pointer-events-none" />

        {/* Top Header: Card Name ONLY + Small Rarity Badge (clean, zero numbers covering face) */}
        <div className="relative z-20 px-2 py-1 flex items-center justify-between pointer-events-none w-full">
          <span 
            className="text-[8.5px] xs:text-[9.5px] sm:text-[11px] font-black font-sans text-white truncate drop-shadow-[0_1px_3px_rgba(0,0,0,1)] tracking-wide flex-1 mr-1"
            style={{
              color: isLegendary ? '#fef08a' : isEpic ? '#f3e8ff' : '#ffffff'
            }}
          >
            {cardName}
          </span>

          <span 
            className="w-2 h-2 rounded-full shrink-0 shadow-xs"
            style={{ backgroundColor: rarityConf.accentColor, boxShadow: `0 0 6px ${rarityConf.glowColor}` }}
          />
        </div>

        {/* Defeated Skull Overlay */}
        {isDead && (
          <div className="absolute inset-0 z-30 bg-black/85 flex items-center justify-center pointer-events-none backdrop-blur-xs">
            <Skull size={22} className="text-slate-400" />
          </div>
        )}
      </div>
    );
  }

  // =========================================================================
  // 2. VARIANT: HAND (Player or Enemy Tray Card)
  // Structured layout: Rarity frame, artwork, name plate, bottom stats & badge.
  // =========================================================================
  return (
    <div
      onClick={onClick}
      className={`group relative w-full aspect-[5/7] rounded-xl sm:rounded-2xl overflow-hidden border-2 transition-all duration-300 flex flex-col justify-between select-none ${
        isDead 
          ? 'border-slate-800 bg-slate-950 opacity-40 grayscale cursor-not-allowed'
          : isSelected
            ? 'ring-4 shadow-2xl scale-[1.03]'
            : isHovered
              ? 'ring-2 shadow-xl scale-[1.02]'
              : 'shadow-md'
      } ${className}`}
      style={{
        background: rarityConf.bgGradient,
        borderColor: isSelected 
          ? rarityConf.accentColor 
          : isHovered 
            ? rarityConf.primaryColor 
            : `${rarityConf.borderColor}aa`,
        boxShadow: isHovered
          ? `${rarityConf.depthShadow}, 0 0 18px ${rarityConf.glowColor}`
          : rarityConf.depthShadow
      }}
    >
      {/* Rarity-specific Ambient Lighting */}
      <div 
        className={`absolute inset-0 pointer-events-none transition-opacity duration-300 ${
          isHovered ? 'opacity-40' : 'opacity-20'
        }`}
        style={{
          background: `radial-gradient(circle at 50% 20%, ${rarityConf.glowColor} 0%, transparent 75%)`
        }}
      />

      {/* Glossy Top Edge Highlight */}
      <div 
        className="absolute top-0 inset-x-0 h-[2px] opacity-90 pointer-events-none z-20" 
        style={{
          background: `linear-gradient(to right, transparent, ${rarityConf.accentColor}, transparent)`
        }}
      />

      {/* Card Illustration with Rarity Profile */}
      <img 
        src={imageUrl} 
        alt={cardName} 
        className={`absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 pointer-events-none ${rarityConf.saturationClass}`}
      />

      {/* Shading Gradients for Depth */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/92 via-transparent to-black/60 pointer-events-none" />

      {/* Shimmer for Higher Rarities */}
      {!isCommon && (isHovered || isSelected) && (
        <motion.div 
          initial={{ x: '-100%' }}
          animate={{ x: '200%' }}
          transition={{ duration: isLegendary ? 0.9 : 1.2, repeat: Infinity, repeatDelay: 0.6, ease: 'linear' }}
          className="absolute inset-y-0 w-1/2 bg-gradient-to-r from-transparent via-white/18 to-transparent skew-x-12 pointer-events-none z-15"
        />
      )}

      {/* Floating Micro-Particles for Legendary & Epic */}
      {(isLegendary || isEpic) && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-15">
          <span className="absolute top-2 right-2 w-1 h-1 rounded-full bg-amber-300/80 animate-ping" />
          <span className="absolute bottom-6 left-2 w-1 h-1 rounded-full bg-yellow-200/60 animate-pulse" />
        </div>
      )}

      {/* Top Bar: Card Name & Optional Shield */}
      <div className="relative z-10 px-1 py-0.5 flex items-center justify-between pointer-events-none">
        <span 
          className="text-[7.5px] xs:text-[8.5px] sm:text-[10px] font-black font-sans text-white truncate drop-shadow-[0_1px_3px_rgba(0,0,0,1)] tracking-wide"
          style={{
            color: isLegendary ? '#fef08a' : isEpic ? '#f3e8ff' : '#ffffff'
          }}
        >
          {cardName}
        </span>
        {shield > 0 && (
          <span className="px-1 py-0.2 rounded-md bg-blue-500/40 border border-blue-400 text-blue-200 text-[6px] sm:text-[7px] font-mono font-black flex items-center gap-0.5 shadow-sm">
            <Shield size={7} />
            +{shield}
          </span>
        )}
      </div>

      {/* Skull if Dead */}
      {isDead && (
        <div className="absolute inset-0 z-20 bg-black/85 flex items-center justify-center pointer-events-none">
          <Skull size={18} className="text-slate-500" />
        </div>
      )}

      {/* Bottom Bar: Jewel Dot + ATK/DEF Stats (No rarity text) */}
      <div className="relative z-10 px-1 pb-0.5 pt-0.5 flex items-center justify-between pointer-events-none">
        <span 
          className="w-1.5 h-1.5 rounded-full shrink-0"
          style={{ backgroundColor: rarityConf.accentColor, boxShadow: `0 0 6px ${rarityConf.glowColor}` }}
        />

        <div className="flex items-center gap-1 text-[6.5px] sm:text-[7.5px] font-mono font-black text-slate-200 drop-shadow">
          <span className="text-cyan-300 drop-shadow-[0_1px_2px_rgba(0,0,0,1)]">{attack}</span>
          <span className="text-amber-300 drop-shadow-[0_1px_2px_rgba(0,0,0,1)]">{defense}</span>
        </div>
      </div>
    </div>
  );
};
