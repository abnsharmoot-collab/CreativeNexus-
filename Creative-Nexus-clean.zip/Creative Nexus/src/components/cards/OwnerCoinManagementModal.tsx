import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useCards } from '../../context/CardContext';
import { CoinTransaction } from '../../types/cards';
import {
  X, Coins, UserCheck, ShieldAlert, ArrowRight,
  History, Search, CheckCircle2, AlertCircle
} from 'lucide-react';
import { MesopotamianCornerBrackets } from '../atoms/MesopotamianCornerBrackets';

interface OwnerCoinManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface KnownUser {
  discordId: string;
  username: string;
  displayName: string;
  avatarUrl?: string;
}

export const OwnerCoinManagementModal: React.FC<OwnerCoinManagementModalProps> = ({
  isOpen,
  onClose
}) => {
  const { isOwner, user } = useAuth();
  const { ownerGiveCoins } = useCards();

  const [users, setUsers] = useState<KnownUser[]>([]);
  const [selectedUser, setSelectedUser] = useState<string>('');
  const [customDiscordId, setCustomDiscordId] = useState<string>('');
  const [amount, setAmount] = useState<string>('100');
  const [reason, setReason] = useState<string>('Event reward');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [transactions, setTransactions] = useState<CoinTransaction[]>([]);
  const [loadingTx, setLoadingTx] = useState<boolean>(false);

  // Load known users and transactions when open
  useEffect(() => {
    if (isOpen && isOwner) {
      loadUsers();
      loadTransactions();
    }
  }, [isOpen, isOwner]);

  const loadUsers = async () => {
    try {
      const res = await fetch('/api/cards/owner/users', { credentials: 'include' });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.users)) {
          setUsers(data.users);
          if (data.users.length > 0 && !selectedUser) {
            setSelectedUser(data.users[0].discordId);
          }
        }
      }
    } catch (err) {
      console.warn('Could not load users for owner management:', err);
    }
  };

  const loadTransactions = async () => {
    setLoadingTx(true);
    try {
      const res = await fetch('/api/cards/transactions', { credentials: 'include' });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.transactions)) {
          setTransactions(data.transactions);
        }
      }
    } catch (err) {
      console.warn('Could not load transactions:', err);
    } finally {
      setLoadingTx(false);
    }
  };

  if (!isOpen) return null;

  if (!isOwner) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <div className="bg-[#0f0c08] border border-red-500/40 rounded-2xl p-6 max-w-md text-center">
          <ShieldAlert size={48} className="text-red-400 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-amber-100 font-serif">Access Denied</h3>
          <p className="text-xs text-stone-300 mt-2">
            This management interface is strictly reserved for Creatine Nexus Server Owners.
          </p>
          <button
            onClick={onClose}
            className="mt-5 px-5 py-2 bg-stone-800 text-stone-200 rounded-xl text-xs font-bold"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  const filteredUsers = users.filter(u =>
    u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.discordId.includes(searchQuery)
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMessage(null);
    setErrorMessage(null);

    const targetId = customDiscordId.trim() || selectedUser;
    if (!targetId) {
      setErrorMessage('Please select or specify a target user Discord ID.');
      return;
    }

    const parsedAmount = parseInt(amount, 10);
    if (isNaN(parsedAmount) || parsedAmount === 0) {
      setErrorMessage('Amount must be a non-zero number.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await ownerGiveCoins(targetId, parsedAmount, reason.trim() || 'Owner grant');
      setSuccessMessage(`Successfully granted ${parsedAmount} coins to ${res.targetUser}! New balance: ${res.newBalance} 🪙`);
      loadTransactions();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to grant coins');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-4xl bg-[#0d0905] border border-amber-900/60 rounded-3xl p-5 sm:p-8 shadow-2xl shadow-black overflow-hidden my-auto max-h-[92dvh] flex flex-col"
      >
        <MesopotamianCornerBrackets className="opacity-80" />

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-950/80 border border-amber-500/50 flex items-center justify-center text-amber-300">
              <Coins size={22} />
            </div>
            <div>
              <span className="text-[10px] font-mono tracking-widest text-amber-400 uppercase">
                OWNER CONTROL PANEL
              </span>
              <h2 className="text-xl sm:text-2xl font-black font-serif text-amber-100">
                COIN MANAGEMENT
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="p-2 rounded-xl text-stone-400 hover:text-white bg-black/40 hover:bg-black border border-white/10 transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Feedback Messages */}
        {successMessage && (
          <div className="my-3 p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2 shrink-0">
            <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}
        {errorMessage && (
          <div className="my-3 p-3 rounded-xl bg-rose-950/80 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2 shrink-0">
            <AlertCircle size={16} className="text-rose-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Scrollable Content Body */}
        <div className="overflow-y-auto space-y-6 pt-4 pr-1">
          {/* Form */}
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 rounded-2xl bg-black/40 border border-amber-900/30">
            {/* Target User */}
            <div className="flex flex-col gap-1.5 md:col-span-1">
              <label className="text-[11px] font-mono uppercase tracking-wider text-amber-300 font-bold">
                USER
              </label>

              {/* User Dropdown / Selection */}
              <div className="relative">
                <input
                  type="text"
                  placeholder="Filter users..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full mb-1.5 px-3 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-xs text-amber-100 placeholder-stone-500 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <select
                value={selectedUser}
                onChange={(e) => {
                  setSelectedUser(e.target.value);
                  setCustomDiscordId('');
                }}
                className="w-full px-3 py-2 rounded-xl bg-stone-900/90 border border-amber-900/40 text-xs text-amber-100 font-sans focus:outline-hidden focus:border-amber-500"
              >
                {filteredUsers.map(u => (
                  <option key={u.discordId} value={u.discordId}>
                    {u.displayName} ({u.username})
                  </option>
                ))}
              </select>

              <span className="text-[10px] text-stone-500 mt-1">Or direct Discord ID:</span>
              <input
                type="text"
                placeholder="Custom Discord Snowflake ID"
                value={customDiscordId}
                onChange={(e) => setCustomDiscordId(e.target.value)}
                className="w-full px-3 py-1.5 rounded-lg bg-stone-900/80 border border-stone-800 text-xs text-amber-100 font-mono placeholder-stone-600 focus:outline-hidden focus:border-amber-500"
              />
            </div>

            {/* Amount & Reason */}
            <div className="flex flex-col gap-3 md:col-span-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[11px] font-mono uppercase tracking-wider text-amber-300 font-bold">
                    AMOUNT
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="e.g. 500"
                      className="w-full px-3 py-2 ps-8 rounded-xl bg-stone-900/90 border border-amber-900/40 text-sm font-mono font-bold text-amber-200 focus:outline-hidden focus:border-amber-500"
                    />
                    <span className="absolute start-2.5 top-2.5 text-xs">🪙</span>
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-[11px] font-mono uppercase tracking-wider text-amber-300 font-bold">
                    REASON
                  </label>
                  <input
                    type="text"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    placeholder="e.g. Event reward"
                    className="w-full px-3 py-2 rounded-xl bg-stone-900/90 border border-amber-900/40 text-xs text-amber-100 focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 rounded-xl font-bold font-serif text-xs tracking-wider uppercase bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-stone-950 flex items-center gap-2 shadow-lg shadow-amber-900/30 transition-transform active:scale-98 cursor-pointer disabled:opacity-50"
                >
                  <Coins size={14} />
                  <span>{isSubmitting ? 'Granting...' : 'GIVE COINS'}</span>
                </button>
              </div>
            </div>
          </form>

          {/* Transactions Log Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <History size={16} className="text-amber-400" />
                <h3 className="text-sm font-bold font-serif text-amber-200 uppercase tracking-wide">
                  TRANSACTION HISTORY AUDIT LOG
                </h3>
              </div>
              <button
                type="button"
                onClick={loadTransactions}
                className="text-[11px] text-stone-400 hover:text-amber-300 underline font-mono cursor-pointer"
              >
                Refresh Log
              </button>
            </div>

            {loadingTx ? (
              <div className="p-8 text-center text-xs text-stone-400">Loading ledger...</div>
            ) : transactions.length === 0 ? (
              <div className="p-8 text-center text-xs text-stone-500 bg-black/30 rounded-xl border border-white/5">
                No coin transactions recorded yet.
              </div>
            ) : (
              <div className="rounded-xl border border-amber-900/30 overflow-hidden bg-black/40">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-sans">
                    <thead className="bg-stone-900/80 text-[10px] uppercase font-mono tracking-wider text-amber-400 border-b border-amber-900/30">
                      <tr>
                        <th className="py-2.5 px-3">Timestamp</th>
                        <th className="py-2.5 px-3">Type</th>
                        <th className="py-2.5 px-3">Admin / Performed By</th>
                        <th className="py-2.5 px-3">Target User</th>
                        <th className="py-2.5 px-3">Amount</th>
                        <th className="py-2.5 px-3">Reason</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {transactions.map(tx => (
                        <tr key={tx.id} className="hover:bg-white/5 transition-colors">
                          <td className="py-2 px-3 text-stone-400 font-mono text-[11px] whitespace-nowrap">
                            {new Date(tx.createdAt).toLocaleString()}
                          </td>
                          <td className="py-2 px-3 whitespace-nowrap">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                              tx.type === 'OWNER_GRANT'
                                ? 'bg-amber-950 text-amber-300 border border-amber-500/40'
                                : tx.type === 'DAILY_CLAIM'
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                                : 'bg-stone-900 text-stone-300 border border-stone-800'
                            }`}>
                              {tx.type}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-amber-200/90 font-mono text-[11px] whitespace-nowrap">
                            {tx.performedBy}
                          </td>
                          <td className="py-2 px-3 text-stone-200 whitespace-nowrap">
                            {tx.username} <span className="text-[10px] text-stone-500 font-mono">({tx.userId.slice(-6)})</span>
                          </td>
                          <td className="py-2 px-3 font-mono font-bold whitespace-nowrap">
                            <span className={tx.amount > 0 ? 'text-emerald-400' : 'text-rose-400'}>
                              {tx.amount > 0 ? `+${tx.amount}` : tx.amount} 🪙
                            </span>
                          </td>
                          <td className="py-2 px-3 text-stone-300 text-xs max-w-[200px] truncate" title={tx.reason}>
                            {tx.reason || '—'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
