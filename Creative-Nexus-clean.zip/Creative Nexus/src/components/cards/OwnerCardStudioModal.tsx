import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CollectibleCardData,
  CardRarity,
  CardElement,
  CardFrameStyle,
  CardGlowIntensity,
  CardFoilStyle,
  HolographicBehavior,
  FoilIntensity,
  CardBackgroundTheme,
  CardStatItem,
  CardAbility,
  AbilityCategory,
  CardStateItem,
  CardStateType,
  CARD_STATE_PRESETS,
  DEFAULT_CARD_STATS,
  getDefaultCardStats,
  getUnifiedCardStats,
  calculateCardOverallRating,
} from '../../types/cards';
import { useCards } from '../../context/CardContext';
import { useItems } from '../../context/ItemContext';
import { useAuth } from '../../context/AuthContext';
import { CollectibleCard } from './CollectibleCard';
import {
  X, Sparkles, Check, RotateCcw, Palette, Layers, Sliders,
  Shield, Zap, Swords, Heart, Crown, Eye, Trash2, Plus, Film,
  Image as ImageIcon, PlayCircle, ShieldCheck, Activity, Upload,
  Flame, Star, Target, SlidersHorizontal, BookmarkCheck, ArrowRight,
  Download, FileDown, FileUp, Save, Database, HardDrive, Share2, Music
} from 'lucide-react';
import { MODERN_CARD_ASSETS } from '../../assets/modernCardAssets';
import { MESOPOTAMIAN_ASSETS } from '../../assets/mesopotamianAssets';
import { parseUniversalVideoUrl } from '../../utils/videoHelpers';
import { compressImageFile } from '../../utils/imageCompressor';
import { getRarityMaterialConfig } from '../../config/cardMaterialConfig';
import { LegendaryCombatAudioSection } from './LegendaryCombatAudioSection';
import { OwnerUnifiedItemManagerModal } from '../items/OwnerUnifiedItemManagerModal';

interface OwnerCardStudioModalProps {
  card: CollectibleCardData | null;
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'ovr' | 'visuals' | 'identity' | 'stats' | 'abilities' | 'media' | 'sfx';
}

const LUXURY_PALETTES = [
  { name: 'Imperial Gold', hex: '#f59e0b' },
  { name: 'Sovereign Solar', hex: '#d97706' },
  { name: 'Cosmic Amethyst', hex: '#a855f7' },
  { name: 'Astral Magenta', hex: '#d946ef' },
  { name: 'Lapis Azure', hex: '#06b6d4' },
  { name: 'Sapphire Chrono', hex: '#3b82f6' },
  { name: 'Emerald Jade', hex: '#10b981' },
  { name: 'Verdigris Forest', hex: '#059669' },
  { name: 'Blood Crimson', hex: '#ef4444' },
  { name: 'Rose Gold', hex: '#fb7185' },
  { name: 'Cyber Neon', hex: '#22d3ee' },
  { name: 'Silver Platinum', hex: '#e2e8f0' },
  { name: 'Obsidian Slate', hex: '#64748b' },
  { name: '🎃 Pumpkin Flame', hex: '#ff5e00' },
  { name: '🎃 Witchfire Violet', hex: '#b026ff' },
];

const FOIL_COLOR_PRESETS = [
  { name: 'Celestial Gold', hex: '#f59e0b' },
  { name: 'Cyber Neon Cyan', hex: '#06b6d4' },
  { name: 'Prismatic Rainbow', hex: '#d946ef' },
  { name: 'Royal Amethyst', hex: '#a855f7' },
  { name: 'Emerald Borealis', hex: '#10b981' },
  { name: 'Blood Ruby', hex: '#ef4444' },
  { name: 'Rose Gold Shimmer', hex: '#fb7185' },
  { name: 'Liquid Chrome', hex: '#e2e8f0' },
  { name: 'Void Obsidian', hex: '#475569' },
  { name: '🎃 Pumpkin Flame', hex: '#ff5e00' },
  { name: '🎃 Witchfire Specter', hex: '#b026ff' },
];

const PRESET_ARTWORKS = [
  { label: 'Lord Sovereign Prime', url: MODERN_CARD_ASSETS.cardApexSovereign },
  { label: 'Valkyrie Aegis', url: MODERN_CARD_ASSETS.cardAegisValkyrie },
  { label: 'Chrono Master', url: MODERN_CARD_ASSETS.cardChronoArchitect },
  { label: 'Empress Selene Astral', url: MODERN_CARD_ASSETS.cardAstralEmpress },
  { label: 'Phantom Blade Zero', url: MODERN_CARD_ASSETS.cardShadowOperative },
  { label: 'Ancient Lamassu Relief', url: MESOPOTAMIAN_ASSETS.lamassuRelief },
  { label: 'Sovereign King Relief', url: MESOPOTAMIAN_ASSETS.kingRelief },
];

const PRESET_VIDEOS = [
  { label: 'Celestial Starflare', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4' },
  { label: 'Astral Supernova', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4' },
];

const CARD_TYPES = [
  'Warrior',
  'Relic',
  'Archon',
  'Spell',
  'Entity',
  'Commander',
  'Titan',
  'Mystic',
  'Guardian',
  'Sovereign',
];

const STAT_ICON_OPTIONS = [
  { id: 'swords', label: 'Swords (Offense)', icon: Swords },
  { id: 'shield', label: 'Shield (Defense)', icon: Shield },
  { id: 'heart', label: 'Heart (Vitality)', icon: Heart },
  { id: 'zap', label: 'Zap (Agility / Speed)', icon: Zap },
  { id: 'sparkles', label: 'Sparkles (Wisdom / Mana)', icon: Sparkles },
  { id: 'flame', label: 'Flame (Power / Fury)', icon: Flame },
  { id: 'crown', label: 'Crown (Authority / Leadership)', icon: Crown },
  { id: 'star', label: 'Star (Faith / Divinity)', icon: Star },
  { id: 'target', label: 'Target (Accuracy / Critical)', icon: Target },
  { id: 'activity', label: 'Activity (Endurance)', icon: Activity },
];

const ABILITY_CATEGORIES: { type: AbilityCategory; label: string; color: string }[] = [
  { type: 'PASSIVE', label: 'Passive', color: 'text-blue-400 border-blue-500/40 bg-blue-950/40' },
  { type: 'ACTIVE', label: 'Active', color: 'text-amber-400 border-amber-500/40 bg-amber-950/40' },
  { type: 'TRIGGERED', label: 'Triggered', color: 'text-purple-400 border-purple-500/40 bg-purple-950/40' },
  { type: 'OFFENSIVE', label: 'Offensive', color: 'text-rose-400 border-rose-500/40 bg-rose-950/40' },
  { type: 'DEFENSIVE', label: 'Defensive', color: 'text-emerald-400 border-emerald-500/40 bg-emerald-950/40' },
  { type: 'UTILITY', label: 'Utility', color: 'text-cyan-400 border-cyan-500/40 bg-cyan-950/40' },
  { type: 'ULTIMATE', label: 'Ultimate', color: 'text-yellow-300 border-yellow-500/40 bg-yellow-950/40' },
];

export const OwnerCardStudioModal: React.FC<OwnerCardStudioModalProps> = ({
  card,
  isOpen,
  onClose,
  initialTab = 'ovr'
}) => {
  const { isOwner } = useAuth();
  const {
    ownerSaveCard,
    ownerImportCards,
    ownerDeleteCard,
    catalog,
    cards,
    globalRatingSettings,
    ownerSaveGlobalRatingSettings
  } = useCards();
  const { items: allUnifiedItems, importOwnerItems } = useItems();
  const allCards = Array.isArray(catalog) ? catalog : (Array.isArray(cards) ? cards : []);

  const [activeTab, setActiveTab] = useState<'ovr' | 'visuals' | 'identity' | 'stats' | 'abilities' | 'media' | 'sfx'>(initialTab || 'ovr');
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [showBackupModal, setShowBackupModal] = useState(false);
  const [isItemManagerOpen, setIsItemManagerOpen] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [mobileView, setMobileView] = useState<'controls' | 'preview'>('controls');
  const [showMobileTools, setShowMobileTools] = useState(false);

  // File Upload Refs & Status
  const photoInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const importInputRef = useRef<HTMLInputElement>(null);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [isUploadingVideo, setIsUploadingVideo] = useState(false);
  const controlsScrollRef = useRef<HTMLDivElement>(null);
  const controlsSectionRef = useRef<HTMLDivElement>(null);

  // Auto-apply rating settings globally to all cards
  const handleRatingSettingChange = async (newSize: number, newX: number, newY: number) => {
    setRatingFontSize(newSize);
    setRatingOffsetX(newX);
    setRatingOffsetY(newY);

    try {
      await ownerSaveGlobalRatingSettings({
        fontSize: newSize,
        offsetX: newX,
        offsetY: newY,
      });
      setFeedback('OVR rating settings applied to all cards in collection!');
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      console.warn('Could not auto-apply rating settings globally:', err);
    }
  };

  // Visual Customization States
  const [borderColor, setBorderColor] = useState('#f59e0b');
  const [nameColor, setNameColor] = useState('#f59e0b');
  const [isNameColorSynced, setIsNameColorSynced] = useState(true);
  const [glowColor, setGlowColor] = useState('#f59e0b');
  const [glowIntensity, setGlowIntensity] = useState<CardGlowIntensity>('radiant');
  const [frameStyle, setFrameStyle] = useState<CardFrameStyle>('auto');
  const [foilStyle, setFoilStyle] = useState<CardFoilStyle>('standard');
  const [foilColor, setFoilColor] = useState('#f59e0b');
  const [foilIntensity, setFoilIntensity] = useState<FoilIntensity>('medium');
  const [holographicBehavior, setHolographicBehavior] = useState<HolographicBehavior>('diagonal_sweep');
  const [reflectionSpeed, setReflectionSpeed] = useState<number>(1.0);
  const [backgroundTheme, setBackgroundTheme] = useState<CardBackgroundTheme>('auto');

  // Upper-Right Rating Number Place & Size States
  const [ratingFontSize, setRatingFontSize] = useState<number>(24);
  const [ratingOffsetX, setRatingOffsetX] = useState<number>(16);
  const [ratingOffsetY, setRatingOffsetY] = useState<number>(14);

  // Identity & Lore States
  const [name, setName] = useState('');
  const [title, setTitle] = useState('');
  const [series, setSeries] = useState('Apex Sovereigns');
  const [cardType, setCardType] = useState('Relic');
  const [rarity, setRarity] = useState<CardRarity>('COMMON');
  const [element, setElement] = useState<CardElement>('STONE');
  const [isActive, setIsActive] = useState<boolean>(true);
  const [description, setDescription] = useState('');
  const [lore, setLore] = useState('');

  // UNIFIED CUSTOMIZABLE STATS (Merged 1 Single Source of Truth)
  const [unifiedStats, setUnifiedStats] = useState<CardStatItem[]>([]);

  // Abilities & Gameplay States
  const [abilities, setAbilities] = useState<CardAbility[]>([]);
  const [cardStates, setCardStates] = useState<CardStateItem[]>([]);

  // Media
  const [imageUrl, setImageUrl] = useState('');
  const [revealVideoUrl, setRevealVideoUrl] = useState('');

  // Ability creation temporary state
  const [newAbilityName, setNewAbilityName] = useState('');
  const [newAbilityDesc, setNewAbilityDesc] = useState('');
  const [newAbilityType, setNewAbilityType] = useState<AbilityCategory>('ACTIVE');
  const [newAbilityCooldown, setNewAbilityCooldown] = useState(1);
  const [newAbilityCost, setNewAbilityCost] = useState(25);

  // Initialize or reset when card changes or modal opens
  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab, isOpen]);

  useEffect(() => {
    if (card) {
      const initialPrimary = card.borderColor || card.accentColor || '#f59e0b';
      const initialName = card.nameColor || initialPrimary;
      setBorderColor(initialPrimary);
      setNameColor(initialName);
      setIsNameColorSynced(!card.nameColor || card.nameColor === initialPrimary);
      setGlowColor(card.glowColor || initialPrimary);
      setGlowIntensity(card.glowIntensity || (card.rarity === 'LEGENDARY' ? 'blazing' : 'radiant'));
      setFrameStyle(card.frameStyle || 'auto');
      setFoilStyle(card.foilStyle || 'standard');
      setFoilColor(card.foilColor || initialPrimary);
      setFoilIntensity(card.foilIntensity || 'medium');
      setHolographicBehavior(card.holographicBehavior || 'diagonal_sweep');
      setReflectionSpeed(card.reflectionSpeed || 1.0);
      setBackgroundTheme(card.backgroundTheme || 'auto');

      setName(card.name || '');
      setTitle(card.title || '');
      setSeries(card.series || 'Apex Sovereigns');
      setCardType(card.cardType || 'Relic');
      setRarity(card.rarity || 'COMMON');
      setElement(card.element || 'STONE');
      setIsActive(card.isActive !== false);
      setDescription(card.description || '');
      setLore(card.lore || '');

      // Load unified stats
      setUnifiedStats(getUnifiedCardStats(card));

      // Load rating place and size (fallback to global settings)
      setRatingFontSize(typeof card.ratingFontSize === 'number' ? card.ratingFontSize : (globalRatingSettings?.fontSize || 24));
      setRatingOffsetX(typeof card.ratingOffsetX === 'number' ? card.ratingOffsetX : (globalRatingSettings?.offsetX ?? 16));
      setRatingOffsetY(typeof card.ratingOffsetY === 'number' ? card.ratingOffsetY : (globalRatingSettings?.offsetY ?? 14));

      setAbilities(Array.isArray(card.abilities) ? card.abilities : []);
      setCardStates(Array.isArray(card.cardStates) ? card.cardStates : []);

      setImageUrl(card.imageUrl || MODERN_CARD_ASSETS.cardApexSovereign);
      setRevealVideoUrl(card.revealVideoUrl || '');
      setFeedback(null);
    } else {
      // Create new card mode
      const defaultColor = '#f59e0b';
      setBorderColor(defaultColor);
      setNameColor(defaultColor);
      setIsNameColorSynced(true);
      setGlowColor(defaultColor);
      setGlowIntensity('radiant');
      setFrameStyle('auto');
      setFoilStyle('standard');
      setFoilColor(defaultColor);
      setFoilIntensity('medium');
      setHolographicBehavior('diagonal_sweep');
      setReflectionSpeed(1.0);
      setBackgroundTheme('auto');

      setRatingFontSize(globalRatingSettings?.fontSize || 24);
      setRatingOffsetX(globalRatingSettings?.offsetX ?? 16);
      setRatingOffsetY(globalRatingSettings?.offsetY ?? 14);

      setName('New Sovereign Relic');
      setTitle('Archon of the Cosmic Flame');
      setSeries('Apex Sovereigns');
      setCardType('Relic');
      setRarity('COMMON');
      setElement('STONE');
      setIsActive(true);
      setDescription('Forged within the celestial firmament, channeling unyielding astral energy.');
      setLore('Inscribed upon the primeval tablets before the dawn of mortal empires.');

      // Check if owner saved a global stats blueprint in localStorage
      let initialBlueprint: CardStatItem[] = getDefaultCardStats();
      try {
        const stored = localStorage.getItem('nexus_global_card_stats_blueprint');
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed) && parsed.length > 0) {
            initialBlueprint = parsed;
          }
        }
      } catch {}

      setUnifiedStats(initialBlueprint);
      setAbilities([
        {
          id: 'ab-default-1',
          name: 'Solar Resonator',
          type: 'PASSIVE',
          description: 'Passively restores kinetic barriers at the start of each round.',
          cooldown: 0,
          cost: 0,
        }
      ]);
      setCardStates([]);
      setImageUrl(MODERN_CARD_ASSETS.cardApexSovereign);
      setRevealVideoUrl('');
      setFeedback(null);
    }
  }, [card, isOpen]);

  // Handle Primary Color Changer (updates border, glow, foil color, and optionally name color)
  const handlePrimaryColorChange = (newHex: string) => {
    setBorderColor(newHex);
    setGlowColor(newHex);
    setFoilColor(newHex);
    if (isNameColorSynced) {
      setNameColor(newHex);
    }
  };

  // Reusable Rarity Material Changer (automatically updates base material properties)
  const handleRarityChange = (newRarity: CardRarity) => {
    setRarity(newRarity);
    const newMat = getRarityMaterialConfig(newRarity);
    setBorderColor(newMat.primaryColor);
    if (isNameColorSynced) {
      setNameColor(newMat.primaryColor);
    }
    setGlowColor(newMat.primaryColor);
    setFoilColor(newMat.primaryColor);
    setFoilIntensity(newMat.defaultFoilIntensity);
    setHolographicBehavior(newMat.defaultBehavior);
  };

  // Dynamic Overall Rating (OVR) calculation
  const computedOvr = useMemo(() => {
    return calculateCardOverallRating(unifiedStats, rarity);
  }, [unifiedStats, rarity]);

  // Real-time live card preview object
  const previewCard: CollectibleCardData = useMemo(() => {
    // Derive primary attack, defense, hp for backwards compatibility
    const atkStat = unifiedStats.find(s => s.id === 'attack' || s.name.toLowerCase().includes('attack'));
    const defStat = unifiedStats.find(s => s.id === 'defense' || s.name.toLowerCase().includes('defense'));
    const hpStat = unifiedStats.find(s => s.id === 'hp' || s.name.toLowerCase().includes('vitality') || s.name.toLowerCase().includes('health'));

    const isTopTier = rarity === 'LEGENDARY' || rarity === 'HALLOWEEN_2026';
    const rarityMat = getRarityMaterialConfig(rarity);
    const effectiveBorderColor = isTopTier ? borderColor : rarityMat.primaryColor;
    const effectiveGlowColor = isTopTier ? glowColor : rarityMat.primaryColor;
    const effectiveFoilColor = isTopTier ? foilColor : rarityMat.primaryColor;
    const effectiveNameColor = isTopTier ? (isNameColorSynced ? borderColor : nameColor) : rarityMat.primaryColor;

    return {
      id: card?.id || 'preview-card',
      name: name || 'Unnamed Relic',
      title: title || 'Artifact of Power',
      rarity,
      packType: rarity,
      cardType,
      element,
      description: description || 'Card description preview.',
      lore: lore || 'Archival lore inscription preview.',
      imageUrl: imageUrl || MODERN_CARD_ASSETS.cardApexSovereign,
      attack: atkStat ? atkStat.value : 75,
      defense: defStat ? defStat.value : 70,
      hp: hpStat ? hpStat.value : 80,
      power: computedOvr,
      powerRating: computedOvr,
      overallRating: computedOvr,
      stats: unifiedStats,
      customStats: unifiedStats,
      series: series || 'Apex Sovereigns',
      cardNumber: card?.cardNumber || allCards.length + 1,
      accentColor: effectiveBorderColor,
      borderColor: effectiveBorderColor,
      nameColor: effectiveNameColor,
      glowColor: effectiveGlowColor,
      glowIntensity,
      frameStyle,
      foilStyle,
      foilColor: effectiveFoilColor,
      foilIntensity,
      holographicBehavior,
      reflectionSpeed,
      backgroundTheme,
      abilities,
      cardStates,
      isActive,
      revealVideoUrl: revealVideoUrl || undefined,
      ratingFontSize,
      ratingOffsetX,
      ratingOffsetY,
      isCustom: true,
    };
  }, [
    card,
    allCards.length,
    name,
    title,
    rarity,
    cardType,
    element,
    description,
    lore,
    imageUrl,
    unifiedStats,
    computedOvr,
    series,
    borderColor,
    nameColor,
    isNameColorSynced,
    glowColor,
    glowIntensity,
    frameStyle,
    foilStyle,
    foilColor,
    foilIntensity,
    holographicBehavior,
    reflectionSpeed,
    backgroundTheme,
    abilities,
    cardStates,
    isActive,
    revealVideoUrl,
    ratingFontSize,
    ratingOffsetX,
    ratingOffsetY,
  ]);

  if (!isOpen) return null;

  // Handle Device Photo Upload
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setIsUploadingPhoto(true);
      const compressed = await compressImageFile(file, 1400, 0.82);
      setImageUrl(compressed.dataUrl);
      setFeedback(`Photo "${file.name}" uploaded from device!`);
      setTimeout(() => setFeedback(null), 3000);
    } catch (err: any) {
      setFeedback(`Error uploading photo: ${err?.message || 'Failed'}`);
    } finally {
      setIsUploadingPhoto(false);
      if (e.target) e.target.value = '';
    }
  };

  // Handle Device Video Upload
  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setIsUploadingVideo(true);
      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUrl = event.target?.result as string;
        setRevealVideoUrl(dataUrl);
        setFeedback(`Video "${file.name}" loaded from device for cinematic reveal!`);
        setIsUploadingVideo(false);
        setTimeout(() => setFeedback(null), 3000);
      };
      reader.onerror = () => {
        setFeedback('Error reading video file from device.');
        setIsUploadingVideo(false);
      };
      reader.readAsDataURL(file);
    } catch (err: any) {
      setFeedback(`Error reading video: ${err?.message || 'Failed'}`);
      setIsUploadingVideo(false);
    } finally {
      if (e.target) e.target.value = '';
    }
  };

  // Stat Management Handlers
  const handleAddCustomStat = () => {
    const id = `stat-${Date.now()}`;
    const newStat: CardStatItem = {
      id,
      name: 'Wisdom',
      value: 75,
      maxValue: 100,
      icon: 'sparkles',
      color: '#a855f7'
    };
    setUnifiedStats([...unifiedStats, newStat]);
  };

  const handleUpdateStat = (idx: number, updates: Partial<CardStatItem>) => {
    const next = [...unifiedStats];
    next[idx] = { ...next[idx], ...updates };
    setUnifiedStats(next);
  };

  const handleRemoveStat = (idx: number) => {
    setUnifiedStats(unifiedStats.filter((_, i) => i !== idx));
  };

  // Save Stats as Global Blueprint
  const handleSaveAsGlobalBlueprint = () => {
    try {
      localStorage.setItem('nexus_global_card_stats_blueprint', JSON.stringify(unifiedStats));
      setFeedback('Current stats saved as Global Blueprint for all cards!');
      setTimeout(() => setFeedback(null), 3000);
    } catch {
      setFeedback('Error saving blueprint to storage.');
    }
  };

  // Reset to Global Blueprint
  const handleResetToGlobalBlueprint = () => {
    try {
      const stored = localStorage.getItem('nexus_global_card_stats_blueprint');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setUnifiedStats(parsed);
          setFeedback('Restored stats from Global Blueprint!');
          setTimeout(() => setFeedback(null), 2500);
          return;
        }
      }
    } catch {}
    setUnifiedStats(getDefaultCardStats());
    setFeedback('Restored default starter stats matrix.');
    setTimeout(() => setFeedback(null), 2500);
  };

  // Save Card Handler
  const handleSaveCard = async () => {
    if (!name.trim()) {
      setFeedback('Error: Card name is required.');
      setActiveTab('identity');
      return;
    }

    setIsSaving(true);
    setFeedback(null);

    // Derive primary attack, defense, hp
    const atkStat = unifiedStats.find(s => s.id === 'attack' || s.name.toLowerCase().includes('attack'));
    const defStat = unifiedStats.find(s => s.id === 'defense' || s.name.toLowerCase().includes('defense'));
    const hpStat = unifiedStats.find(s => s.id === 'hp' || s.name.toLowerCase().includes('vitality') || s.name.toLowerCase().includes('health'));

    const isTopTier = rarity === 'LEGENDARY' || rarity === 'HALLOWEEN_2026';
    const rarityMat = getRarityMaterialConfig(rarity);
    const effectiveBorderColor = isTopTier ? borderColor : rarityMat.primaryColor;
    const effectiveGlowColor = isTopTier ? glowColor : rarityMat.primaryColor;
    const effectiveFoilColor = isTopTier ? foilColor : rarityMat.primaryColor;
    const effectiveNameColor = isTopTier ? (isNameColorSynced ? borderColor : nameColor) : rarityMat.primaryColor;

    const payload: CollectibleCardData = {
      id: card?.id || `card-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      name: name.trim(),
      title: title.trim(),
      series: series.trim() || 'Apex Sovereigns',
      cardType: cardType.trim() || 'Relic',
      rarity,
      packType: rarity,
      element,
      description: description.trim(),
      lore: lore.trim(),
      imageUrl: imageUrl.trim() || MODERN_CARD_ASSETS.cardApexSovereign,
      attack: atkStat ? atkStat.value : 75,
      defense: defStat ? defStat.value : 70,
      hp: hpStat ? hpStat.value : 80,
      power: computedOvr,
      powerRating: computedOvr,
      overallRating: computedOvr,
      stats: unifiedStats,
      customStats: unifiedStats,
      abilities,
      cardStates,
      cardNumber: card?.cardNumber || allCards.length + 1,
      accentColor: effectiveBorderColor,
      borderColor: effectiveBorderColor,
      nameColor: effectiveNameColor,
      glowColor: effectiveGlowColor,
      glowIntensity,
      frameStyle: frameStyle === 'auto' ? undefined : frameStyle,
      foilStyle,
      foilColor: effectiveFoilColor,
      foilIntensity,
      holographicBehavior,
      reflectionSpeed,
      backgroundTheme: backgroundTheme === 'auto' ? undefined : backgroundTheme,
      ratingFontSize,
      ratingOffsetX,
      ratingOffsetY,
      isActive,
      revealVideoUrl: revealVideoUrl.trim() || undefined,
      isCustom: true,
      updatedAt: new Date().toISOString(),
    };

    try {
      await ownerSaveCard(payload);
      try {
        await ownerSaveGlobalRatingSettings({
          fontSize: ratingFontSize,
          offsetX: ratingOffsetX,
          offsetY: ratingOffsetY,
        });
      } catch {}

      // Automatically sync saved card to local auto-backup file repository
      try {
        updateAutoBackup(payload as CollectibleCardData);
      } catch {}

      setFeedback('Artifact forged and saved successfully to card catalog!');
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: any) {
      setFeedback(`Error saving card: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  // Auto-backup repository helper to ensure newly created cards are always preserved
  const getAutoBackupCards = (): CollectibleCardData[] => {
    try {
      const stored = localStorage.getItem('nexus_auto_cards_backup');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return [];
  };

  const updateAutoBackup = (newCard?: CollectibleCardData) => {
    try {
      let list = getAutoBackupCards();
      if (newCard) {
        const idx = list.findIndex(c => c.id === newCard.id);
        if (idx >= 0) list[idx] = newCard;
        else list.push(newCard);
      }
      for (const catCard of allCards) {
        if (catCard.isCustom && !list.some(c => c.id === catCard.id)) {
          list.push(catCard);
        }
      }
      localStorage.setItem('nexus_auto_cards_backup', JSON.stringify(list));
    } catch {}
  };

  // Export current card as JSON file
  const handleExportCurrentCard = () => {
    setShowExportMenu(false);
    const cardData = previewCard;
    const jsonStr = JSON.stringify(cardData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const safeName = (cardData.name || 'card').toLowerCase().replace(/[^a-z0-9]/g, '_');
    link.href = url;
    link.download = `card-${safeName}-${Date.now()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setFeedback(`Card "${cardData.name}" exported to file successfully!`);
    setTimeout(() => setFeedback(null), 3000);
  };

  // Export all cards & items (full custom catalog) as automatic backup file
  const handleExportAllCards = () => {
    setShowExportMenu(false);
    const cardsToExport = allCards.length > 0 ? allCards : [];
    const itemsToExport = Array.isArray(allUnifiedItems) && allUnifiedItems.length > 0 ? allUnifiedItems : [];
    const exportPayload = {
      app: 'Creative Nexus Sovereign Card Studio',
      version: 2,
      backupType: 'full_catalog_backup',
      exportedAt: new Date().toISOString(),
      count: cardsToExport.length,
      cards: cardsToExport,
      items: itemsToExport,
      itemsCount: itemsToExport.length
    };
    const jsonStr = JSON.stringify(exportPayload, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `nexus-all-cards-items-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setFeedback(
      itemsToExport.length > 0
        ? `Successfully exported all ${cardsToExport.length} cards and ${itemsToExport.length} items to backup file!`
        : `Successfully exported all ${cardsToExport.length} cards to backup file! Keep this file to restore anytime.`
    );
    setTimeout(() => setFeedback(null), 4000);
  };

  // Import cards from selected JSON file
  const handleImportFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    try {
      const text = await file.text();
      let parsed: any;
      try {
        parsed = JSON.parse(text);
      } catch {
        throw new Error('Invalid JSON file format. Please upload a valid JSON backup file.');
      }

      let cardsToImport: any[] = [];
      let itemsToImport: any[] = [];

      // Extract items if present
      if (Array.isArray(parsed?.items)) {
        itemsToImport = parsed.items;
      } else if (Array.isArray(parsed?.gameItems)) {
        itemsToImport = parsed.gameItems;
      }

      if (Array.isArray(parsed)) {
        cardsToImport = parsed;
      } else if (parsed && typeof parsed === 'object') {
        if (Array.isArray(parsed.cards)) {
          cardsToImport = parsed.cards;
        } else if (Array.isArray(parsed.catalog)) {
          cardsToImport = parsed.catalog;
        } else if (Array.isArray(parsed.data)) {
          cardsToImport = parsed.data;
        } else if (Array.isArray(parsed.items) && !parsed.cards) {
          itemsToImport = parsed.items;
        } else if (Array.isArray(parsed.cardList)) {
          cardsToImport = parsed.cardList;
        } else if (Array.isArray(parsed.customCards)) {
          cardsToImport = parsed.customCards;
        } else if (Array.isArray(parsed.cardsToExport)) {
          cardsToImport = parsed.cardsToExport;
        } else if (Array.isArray(parsed.allCards)) {
          cardsToImport = parsed.allCards;
        } else if (parsed.backup && typeof parsed.backup === 'object' && Array.isArray(parsed.backup.cards)) {
          cardsToImport = parsed.backup.cards;
        } else if (parsed.name && typeof parsed.name === 'string') {
          cardsToImport = [parsed];
        } else {
          // Check for dictionary object e.g. { "card_1": {...}, "card_2": {...} }
          const values = Object.values(parsed);
          const cardLike = values.filter((v: any) => v && typeof v === 'object' && (v.name || v.id || v.title));
          if (cardLike.length > 0) {
            cardsToImport = cardLike;
          }
        }
      }

      // Import items if present in backup file
      let importedItemsCount = 0;
      if (itemsToImport.length > 0) {
        try {
          const itemRes = await importOwnerItems(itemsToImport);
          importedItemsCount = itemRes?.count || itemsToImport.length;
        } catch (itemErr: any) {
          console.warn('Notice importing items from backup:', itemErr);
        }
      }

      if (cardsToImport.length > 0) {
        // Import via backend API
        const result = await ownerImportCards(cardsToImport);

        // Also persist to local auto-backup repository
        for (const c of cardsToImport) {
          updateAutoBackup(c);
        }

        const count = result?.count ?? cardsToImport.length;
        setFeedback(
          importedItemsCount > 0
            ? `Successfully imported ${count} cards and ${importedItemsCount} items into catalog!`
            : `Successfully imported ${count} cards from file into catalog!`
        );
      } else if (importedItemsCount > 0) {
        setFeedback(`Successfully imported ${importedItemsCount} items into catalog!`);
      } else {
        throw new Error('No readable card or item definitions found in this file. Please verify the JSON structure.');
      }

      // If single card was imported, populate current studio editor so owner sees it live
      if (cardsToImport.length === 1) {
        const single = cardsToImport[0];
        setName(single.name || 'Imported Card');
        setTitle(single.title || '');
        setSeries(single.series || 'Custom Collection');
        setCardType(single.cardType || 'Relic');
        setRarity(single.rarity || 'COMMON');
        setElement(single.element || 'STONE');
        setIsActive(single.isActive !== false);
        setDescription(single.description || '');
        setLore(single.lore || '');
        if (single.borderColor) setBorderColor(single.borderColor);
        if (single.nameColor) setNameColor(single.nameColor);
        if (single.glowColor) setGlowColor(single.glowColor);
        if (single.foilColor) setFoilColor(single.foilColor);
        if (single.foilStyle) setFoilStyle(single.foilStyle);
        if (single.foilIntensity) setFoilIntensity(single.foilIntensity);
        if (single.imageUrl) setImageUrl(single.imageUrl);
        if (single.revealVideoUrl) setRevealVideoUrl(single.revealVideoUrl);
        if (Array.isArray(single.abilities)) setAbilities(single.abilities);
        if (Array.isArray(single.cardStates)) setCardStates(single.cardStates);
        if (Array.isArray(single.stats) || Array.isArray(single.customStats)) {
          setUnifiedStats(getUnifiedCardStats(single));
        }
      }

      if (cardsToImport.length > 0 || importedItemsCount > 0) {
        setTimeout(() => setFeedback(null), 5000);
      }
    } catch (err: any) {
      setFeedback(`Error importing cards: ${err.message || 'Unknown error'}`);
    } finally {
      setIsImporting(false);
      if (importInputRef.current) {
        importInputRef.current.value = '';
      }
    }
  };

  // Restore all from Auto-Backup with 1 click
  const handleRestoreFromAutoBackup = async () => {
    setShowBackupModal(false);
    const list = getAutoBackupCards();
    if (list.length === 0) {
      alert('No auto-backup cards found on this browser yet. Try exporting your cards first or importing a saved JSON file.');
      return;
    }
    if (!window.confirm(`Restore ${list.length} saved card(s) from your auto-backup repository?`)) {
      return;
    }

    setIsImporting(true);
    try {
      const result = await ownerImportCards(list);
      setFeedback(`⚡ Successfully restored ${result.count || list.length} cards from auto-backup! They are active now.`);
      setTimeout(() => setFeedback(null), 5000);
    } catch (err: any) {
      setFeedback(`Error restoring cards: ${err.message}`);
    } finally {
      setIsImporting(false);
    }
  };

  // Delete Card Handler
  const handleDeleteCard = async () => {
    if (!card) return;
    if (!window.confirm(`Are you sure you want to permanently delete "${card.name}" from the catalog?`)) {
      return;
    }

    setIsDeleting(true);
    try {
      await ownerDeleteCard(card.id);
      onClose();
    } catch (err: any) {
      alert(`Failed to delete card: ${err.message}`);
    } finally {
      setIsDeleting(false);
    }
  };

  // Reset to Defaults
  const handleResetDefaults = () => {
    const defaultColor = '#f59e0b';
    setBorderColor(defaultColor);
    setNameColor(defaultColor);
    setIsNameColorSynced(true);
    setGlowColor(defaultColor);
    setGlowIntensity('radiant');
    setFrameStyle('auto');
    setFoilStyle('standard');
    setFoilColor(defaultColor);
    setFoilIntensity('medium');
    setHolographicBehavior('diagonal_sweep');
    setReflectionSpeed(1.0);
    setBackgroundTheme('auto');
    setRatingFontSize(24);
    setRatingOffsetX(16);
    setRatingOffsetY(14);
    setUnifiedStats(getDefaultCardStats());
    setFeedback('Reset visual styling and stats to defaults.');
    setTimeout(() => setFeedback(null), 2500);
  };

  // Ability Management
  const handleAddAbility = () => {
    if (!newAbilityName.trim()) return;
    const newAb: CardAbility = {
      id: `ab-${Date.now()}`,
      name: newAbilityName.trim(),
      description: newAbilityDesc.trim() || 'No ability details provided.',
      type: newAbilityType,
      cooldown: newAbilityCooldown,
      cost: newAbilityCost,
    };
    setAbilities([...abilities, newAb]);
    setNewAbilityName('');
    setNewAbilityDesc('');
    setNewAbilityCooldown(1);
    setNewAbilityCost(25);
  };

  const handleRemoveAbility = (id: string) => {
    setAbilities(abilities.filter(a => a.id !== id));
  };

  // Temporary State Management
  const handleToggleState = (stateType: CardStateType) => {
    const exists = cardStates.some(s => s.name === stateType);
    if (exists) {
      setCardStates(cardStates.filter(s => s.name !== stateType));
    } else {
      const preset = CARD_STATE_PRESETS.find(p => p.type === stateType);
      const newState: CardStateItem = {
        id: `state-${Date.now()}-${stateType}`,
        name: stateType,
        duration: 3,
        effect: preset?.defaultEffect || 'State effect.',
        active: true,
      };
      setCardStates([...cardStates, newState]);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/85 backdrop-blur-xl overflow-y-auto studio-scrollbar"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-6xl max-h-[95vh] lg:h-[92vh] bg-gradient-to-b from-[#071318]/98 via-[#040c10]/98 to-[#020608]/98 border border-[rgba(158,255,230,0.25)] rounded-3xl p-3.5 sm:p-5 md:p-6 shadow-[0_25px_80px_rgba(0,0,0,0.95)] flex flex-col overflow-hidden box-border my-auto"
      >
        {/* Hidden File Inputs for Device Upload */}
        <input
          type="file"
          ref={photoInputRef}
          accept="image/*"
          className="hidden"
          onChange={handlePhotoUpload}
        />
        <input
          type="file"
          ref={videoInputRef}
          accept="video/*"
          className="hidden"
          onChange={handleVideoUpload}
        />
        <input
          type="file"
          ref={importInputRef}
          accept=".json,application/json"
          className="hidden"
          onChange={handleImportFileChange}
        />

        {/* Top Hairline Metallic Bevel */}
        <div
          className="absolute top-0 inset-x-0 h-[2px] pointer-events-none transition-all duration-300"
          style={{
            background: `linear-gradient(90deg, transparent 0%, ${borderColor} 50%, transparent 100%)`,
            boxShadow: `0 0 14px ${borderColor}`
          }}
        />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-white/10 shrink-0 gap-3">
          <div className="min-w-0">
            <h2
              className="text-base sm:text-lg font-black font-serif truncate transition-colors duration-200"
              style={{ color: isNameColorSynced ? borderColor : nameColor }}
            >
              {name || 'New Sovereign Relic'}
            </h2>
          </div>

          <div className="flex items-center gap-1 sm:gap-2 shrink-0 flex-wrap justify-end">
            {/* Open Items Manager */}
            <button
              type="button"
              onClick={() => setIsItemManagerOpen(true)}
              className="px-2 sm:px-3 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 border border-purple-500/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
              title="Open Items Manager (Battle Items, Upgrade Shards, Duplicate Rewards)"
            >
              <Layers size={13} className="text-purple-400" />
              <span className="hidden sm:inline">Items</span>
              <span className="sm:hidden text-[10px]">Items</span>
            </button>

            {/* 1. Import All Cards Button */}
            <button
              type="button"
              disabled={isImporting}
              onClick={() => importInputRef.current?.click()}
              className="px-2 sm:px-3 py-1.5 rounded-xl bg-teal-500/15 hover:bg-teal-500/25 text-[#5eead4] border border-[#5eead4]/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95 disabled:opacity-50"
              title="Import all cards at once from JSON backup file (.json)"
            >
              <FileUp size={13} className={isImporting ? 'animate-bounce' : ''} />
              <span className="hidden sm:inline">{isImporting ? 'Importing All...' : 'Import All Cards'}</span>
              <span className="sm:hidden text-[10px]">{isImporting ? '...' : 'Import'}</span>
            </button>

            {/* 2. Export All Cards (Direct 1-Click Backup) */}
            <button
              type="button"
              onClick={handleExportAllCards}
              className="px-2 sm:px-3 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
              title="Export all cards at once into a single JSON backup file (.json)"
            >
              <HardDrive size={13} />
              <span className="hidden sm:inline">Export All Cards</span>
              <span className="sm:hidden text-[10px]">Export</span>
            </button>

            {/* 3. Auto-Backup 1-Click Restore */}
            <button
              type="button"
              onClick={handleRestoreFromAutoBackup}
              className="px-2 sm:px-2.5 py-1.5 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 text-purple-300 border border-purple-500/30 text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
              title="Restore all cards automatically from browser backup storage"
            >
              <RotateCcw size={12} />
              <span className="hidden md:inline">Auto-Restore</span>
              <span className="md:hidden text-[10px]">Restore</span>
            </button>

            {/* Reset */}
            <button
              type="button"
              onClick={handleResetDefaults}
              className="px-2 sm:px-2.5 py-1.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-400 hover:text-stone-200 text-xs font-mono border border-white/10 flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Reset styling and combat stats to defaults"
            >
              <RotateCcw size={12} />
              <span className="hidden md:inline">Reset</span>
            </button>

            {/* Close */}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close"
              className="p-1.5 rounded-xl text-stone-400 hover:text-white bg-black/40 hover:bg-black border border-white/10 transition-colors cursor-pointer"
            >
              <X size={17} />
            </button>
          </div>
        </div>

        {/* Feedback Banner */}
        {feedback && (
          <div
            className={`my-2 p-2.5 rounded-xl text-xs flex items-center gap-2 shrink-0 ${
              feedback.startsWith('Error')
                ? 'bg-rose-950/80 border border-rose-500/40 text-rose-200'
                : 'bg-emerald-950/80 border border-emerald-500/40 text-emerald-200'
            }`}
          >
            <Sparkles size={14} />
            <span>{feedback}</span>
          </div>
        )}

        {/* Mobile View Segmented Switcher (Simple & Organized for Small Screens) */}
        <div className="flex lg:hidden items-center p-1 rounded-2xl bg-black/70 border border-white/10 my-2 shrink-0">
          <button
            type="button"
            onClick={() => setMobileView('controls')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-mono font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
              mobileView === 'controls'
                ? 'bg-gradient-to-r from-[#5eead4] to-[#2dd4bf] text-black shadow-md shadow-teal-500/25'
                : 'text-stone-400 hover:text-white'
            }`}
          >
            <Sliders size={13} />
            <span>Forge Controls</span>
          </button>
          <button
            type="button"
            onClick={() => setMobileView('preview')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-mono font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
              mobileView === 'preview'
                ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-black shadow-md shadow-amber-500/25'
                : 'text-stone-400 hover:text-white'
            }`}
          >
            <Eye size={13} />
            <span>Live 3D Preview</span>
          </button>
        </div>

        {/* Main Studio Body: Live Preview & Studio Controls on the SAME page */}
        <div className="flex-1 min-h-0 overflow-y-auto lg:overflow-hidden flex flex-col lg:flex-row gap-4 sm:gap-5 pt-1 studio-scrollbar pr-0.5">
          {/* ------------------------------------------------------------------ */}
          {/* LEFT / TOP: LIVE 3D INTERACTIVE CARD PREVIEW                       */}
          {/* ------------------------------------------------------------------ */}
          <div className={`w-full lg:w-[340px] xl:w-[360px] shrink-0 ${mobileView === 'controls' ? 'hidden lg:flex' : 'flex'} flex-col items-center justify-start p-3 sm:p-4 rounded-3xl bg-black/50 border border-white/10 space-y-3 lg:sticky lg:top-0 self-start`}>
            {/* The Live Interactive Preview Card - Matching Card Profile generous width */}
            <div className="w-full max-w-[270px] sm:max-w-[300px] lg:max-w-[320px] mx-auto">
              <CollectibleCard
                card={previewCard}
                isOwned={true}
                duplicateCount={1}
                size="standard"
                disableScrollTilt={true}
              />
            </div>

            <p className="text-[10px] text-stone-400 font-mono flex items-center gap-1.5 text-center">
              <Eye size={12} className="text-[#5eead4] shrink-0" />
              <span>3D Card Preview • Press, hover & tilt freely</span>
            </p>

            {/* Quick Live Preview Badges */}
            <div className="w-full pt-2.5 border-t border-white/10 flex items-center justify-between text-xs font-mono text-stone-300">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-amber-300 font-bold bg-amber-950/70 px-2 py-0.5 rounded border border-amber-500/40">
                  Rating {computedOvr}
                </span>
                <span className="text-white/20">·</span>
                <span className="text-stone-300 text-[11px]">
                  {unifiedStats.length} Stats
                </span>
              </div>

              <div>
                {isActive ? (
                  <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span>In Packs</span>
                  </span>
                ) : (
                  <span className="text-[10px] font-mono text-stone-500">Vaulted</span>
                )}
              </div>
            </div>
          </div>

          {/* ------------------------------------------------------------------ */}
          {/* RIGHT / BOTTOM: COMPREHENSIVE STUDIO CONTROLS                      */}
          {/* ------------------------------------------------------------------ */}
          <div ref={controlsSectionRef} className={`flex-1 min-h-0 ${mobileView === 'preview' ? 'hidden lg:flex' : 'flex'} flex-col space-y-3 overflow-visible lg:overflow-hidden`}>
            {/* Studio Tabs Navigation */}
            <div className="flex items-center gap-1.5 pb-2 border-b border-white/10 overflow-x-auto shrink-0 studio-scrollbar">
              <button
                type="button"
                onClick={() => setActiveTab('ovr')}
                className={`px-3 sm:px-3.5 py-1.5 rounded-full text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                  activeTab === 'ovr'
                    ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-stone-950 shadow-md font-black'
                    : 'text-stone-400 hover:text-amber-200 bg-stone-900/60 hover:bg-stone-800'
                }`}
              >
                <SlidersHorizontal size={13} />
                <span>OVR Rating</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('visuals')}
                className={`px-3 sm:px-3.5 py-1.5 rounded-full text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                  activeTab === 'visuals'
                    ? 'bg-gradient-to-r from-[#5eead4] to-[#2dd4bf] text-stone-950 shadow-md font-black'
                    : 'text-stone-400 hover:text-[#5eead4] bg-stone-900/60 hover:bg-stone-800'
                }`}
              >
                <Palette size={13} />
                <span>Visuals & Foil</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('identity')}
                className={`px-3 sm:px-3.5 py-1.5 rounded-full text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                  activeTab === 'identity'
                    ? 'bg-gradient-to-r from-[#5eead4] to-[#2dd4bf] text-stone-950 shadow-md font-black'
                    : 'text-stone-400 hover:text-[#5eead4] bg-stone-900/60 hover:bg-stone-800'
                }`}
              >
                <Sliders size={13} />
                <span>Identity & Lore</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('stats')}
                className={`px-3 sm:px-3.5 py-1.5 rounded-full text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                  activeTab === 'stats'
                    ? 'bg-gradient-to-r from-[#5eead4] to-[#2dd4bf] text-stone-950 shadow-md font-black'
                    : 'text-stone-400 hover:text-[#5eead4] bg-stone-900/60 hover:bg-stone-800'
                }`}
              >
                <Zap size={13} />
                <span>Combat Stats</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('abilities')}
                className={`px-3 sm:px-3.5 py-1.5 rounded-full text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                  activeTab === 'abilities'
                    ? 'bg-gradient-to-r from-[#5eead4] to-[#2dd4bf] text-stone-950 shadow-md font-black'
                    : 'text-stone-400 hover:text-[#5eead4] bg-stone-900/60 hover:bg-stone-800'
                }`}
              >
                <Shield size={13} />
                <span>Abilities</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('media')}
                className={`px-3 sm:px-3.5 py-1.5 rounded-full text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                  activeTab === 'media'
                    ? 'bg-gradient-to-r from-[#5eead4] to-[#2dd4bf] text-stone-950 shadow-md font-black'
                    : 'text-stone-400 hover:text-[#5eead4] bg-stone-900/60 hover:bg-stone-800'
                }`}
              >
                <Film size={13} />
                <span>Artwork & Upload</span>
              </button>

              {/* Legendary Combat SFX Customization Tab */}
              {rarity === 'LEGENDARY' && (
                <button
                  type="button"
                  onClick={() => setActiveTab('sfx')}
                  className={`px-3 sm:px-3.5 py-1.5 rounded-full text-xs font-mono font-black uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                    activeTab === 'sfx'
                      ? 'bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-stone-950 shadow-md font-black shadow-amber-500/30'
                      : 'text-amber-300 hover:text-amber-100 bg-amber-950/40 hover:bg-amber-900/60 border border-amber-500/30'
                  }`}
                >
                  <Music size={13} className="text-amber-400" />
                  <span>Legendary SFX</span>
                  <span className="text-[9px] font-mono font-black px-1.5 py-0.2 rounded-full bg-amber-400 text-stone-950">
                    SFX
                  </span>
                </button>
              )}

              {/* Items & Upgrades Manager Tab */}
              <button
                type="button"
                onClick={() => setIsItemManagerOpen(true)}
                className="px-3 sm:px-3.5 py-1.5 rounded-full text-xs font-mono font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap text-purple-300 hover:text-purple-100 bg-purple-950/40 hover:bg-purple-900/60 border border-purple-500/30"
                title="Manage Battle Items, Upgrade Shards & Duplicate Rewards"
              >
                <Layers size={13} className="text-purple-400" />
                <span>Items</span>
              </button>
            </div>

            {/* TAB PANELS WRAPPER: Dedicated smooth scroll on PC, unified stream on mobile */}
            <div ref={controlsScrollRef} className="flex-1 min-h-0 overflow-visible lg:overflow-y-auto studio-scrollbar pr-1 pb-10 lg:pb-20">
              {/* TAB 0: OVR RATING NUMBER (SIZE & POSITION CUSTOMIZER) */}
              {activeTab === 'ovr' && (
                <div className="space-y-4 text-xs">
                  {/* Status Banner */}
                  <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-amber-950/60 via-stone-900/80 to-amber-950/60 border border-amber-500/30 space-y-2">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <SlidersHorizontal size={15} className="text-amber-400 shrink-0" />
                        <h4 className="font-serif font-black text-amber-200 text-sm">
                          OVR Rating Number Customizer (Place & Size)
                        </h4>
                      </div>
                      <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/70 px-2.5 py-0.5 rounded-full border border-emerald-500/40 flex items-center gap-1">
                        <Check size={11} className="stroke-[3]" />
                        <span>Applied to All Cards</span>
                      </span>
                    </div>
                    <p className="text-stone-300 text-xs leading-relaxed">
                      Customizes the rating number displayed on the upper right corner of all cards.
                      Any adjustment made here applies immediately to the live preview and across every card in your collection!
                    </p>
                  </div>

                  {/* Size Customizer */}
                  <div className="p-3.5 sm:p-4 rounded-2xl bg-black/40 border border-white/5 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Rating Number Size (حجم الرقم)
                      </label>
                      <span className="text-xs font-mono font-bold text-amber-300 bg-amber-950/70 px-2.5 py-0.5 rounded-lg border border-amber-500/30">
                        {ratingFontSize}px
                      </span>
                    </div>

                    <div className="space-y-2.5">
                      <input
                        type="range"
                        min={12}
                        max={48}
                        step={1}
                        value={ratingFontSize}
                        onChange={(e) => handleRatingSettingChange(Number(e.target.value), ratingOffsetX, ratingOffsetY)}
                        className="w-full accent-amber-400 cursor-pointer h-2 bg-stone-800 rounded-lg"
                      />
                      <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                        {[
                          { label: 'S (18px)', size: 18 },
                          { label: 'M (24px)', size: 24 },
                          { label: 'L (30px)', size: 30 },
                          { label: 'XL (38px)', size: 38 },
                        ].map((p) => (
                          <button
                            key={p.size}
                            type="button"
                            onClick={() => handleRatingSettingChange(p.size, ratingOffsetX, ratingOffsetY)}
                            className={`px-3 py-1.5 rounded-xl text-[10px] font-mono border transition-all cursor-pointer ${
                              ratingFontSize === p.size
                                ? 'bg-amber-500 text-stone-950 font-bold border-amber-400 shadow-sm'
                                : 'bg-stone-900 border-white/10 text-stone-400 hover:text-white hover:border-white/20'
                            }`}
                          >
                            {p.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Position Presets & Sliders */}
                  <div className="p-3.5 sm:p-4 rounded-2xl bg-black/40 border border-white/5 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Position On Upper Right (مكان الرقم)
                      </label>
                      <span className="text-[10px] font-mono text-stone-400">
                        Top: {ratingOffsetY}px · Right: {ratingOffsetX}px
                      </span>
                    </div>

                    {/* Presets */}
                    <div className="space-y-1.5">
                      <span className="text-[10px] font-mono text-stone-400">Placement Presets:</span>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {[
                          { label: 'Standard Corner', y: 14, x: 16 },
                          { label: 'Tight Corner', y: 8, x: 10 },
                          { label: 'Upper Inset', y: 22, x: 22 },
                          { label: 'Deep Floating', y: 36, x: 18 },
                        ].map((pos) => (
                          <button
                            key={pos.label}
                            type="button"
                            onClick={() => handleRatingSettingChange(ratingFontSize, pos.x, pos.y)}
                            className={`py-2 px-2.5 rounded-xl text-[10px] font-mono border text-center transition-all cursor-pointer truncate ${
                              ratingOffsetY === pos.y && ratingOffsetX === pos.x
                                ? 'bg-amber-500 text-stone-950 font-bold border-amber-400 shadow-sm'
                                : 'bg-stone-900 border-white/10 text-stone-400 hover:text-white hover:border-white/20'
                            }`}
                          >
                            {pos.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Fine-Tuning Sliders */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-white/10">
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-[10.5px] font-mono text-stone-300">
                          <span>Top Offset (من الأعلى Y):</span>
                          <span className="text-amber-300 font-bold">{ratingOffsetY}px</span>
                        </div>
                        <input
                          type="range"
                          min={4}
                          max={60}
                          step={1}
                          value={ratingOffsetY}
                          onChange={(e) => handleRatingSettingChange(ratingFontSize, ratingOffsetX, Number(e.target.value))}
                          className="w-full accent-amber-400 cursor-pointer h-2 bg-stone-800 rounded-lg"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-[10.5px] font-mono text-stone-300">
                          <span>Right Offset (من اليمين X):</span>
                          <span className="text-amber-300 font-bold">{ratingOffsetX}px</span>
                        </div>
                        <input
                          type="range"
                          min={4}
                          max={60}
                          step={1}
                          value={ratingOffsetX}
                          onChange={(e) => handleRatingSettingChange(ratingFontSize, Number(e.target.value), ratingOffsetY)}
                          className="w-full accent-amber-400 cursor-pointer h-2 bg-stone-800 rounded-lg"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Apply to All Cards Confirm Button */}
                  <div className="p-3.5 rounded-2xl bg-black/50 border border-amber-500/20 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <Check size={16} className="text-emerald-400 shrink-0" />
                      <div className="text-[11px] text-stone-300">
                        <span className="font-bold text-white">Universal Sync:</span> Current size ({ratingFontSize}px) and position (Y:{ratingOffsetY}px, X:{ratingOffsetX}px) are live and active for all cards.
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRatingSettingChange(ratingFontSize, ratingOffsetX, ratingOffsetY)}
                      className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-stone-950 font-bold font-mono text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer whitespace-nowrap"
                    >
                      <Check size={13} className="stroke-[3]" />
                      <span>Apply to All Cards</span>
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 1: VISUALS & FOIL COLOR */}
              {activeTab === 'visuals' && (
                <div className="space-y-4 text-xs">
                  {/* Halloween 2026 Quick Mythic Preset Banner */}
                  <div className="p-3.5 rounded-2xl bg-gradient-to-r from-orange-950/70 via-purple-950/60 to-stone-950 border border-orange-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="text-base">🎃</span>
                        <h4 className="font-bold text-white text-xs">Halloween 2026 Mythic Effects</h4>
                        <span className="px-1.5 py-0.5 text-[9px] font-mono font-bold bg-orange-500/20 text-orange-300 border border-orange-500/40 rounded">
                          Better than Legendary
                        </span>
                      </div>
                      <p className="text-[10px] text-stone-300">
                        Quickly applies Halloween 2026 Rarity, Witchfire Specter Foil, Bat Arch Spectral Frame & Flame Glow
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        handleRarityChange('HALLOWEEN_2026');
                        setFrameStyle('halloween_spectral');
                        setFoilStyle('halloween_specter');
                        setBorderColor('#ff5e00');
                        setGlowColor('#ff5e00');
                        setFoilColor('#b026ff');
                        setFoilIntensity('ultra');
                        setHolographicBehavior('prismatic_shift');
                      }}
                      className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-orange-500 to-purple-600 hover:from-orange-400 hover:to-purple-500 text-white font-bold text-xs shrink-0 shadow-sm cursor-pointer"
                    >
                      Apply 🎃 Preset
                    </button>
                  </div>

                  {/* Primary Color Changer — Available for LEGENDARY and HALLOWEEN_2026 */}
                  {(rarity === 'LEGENDARY' || rarity === 'HALLOWEEN_2026') ? (
                    <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                          Primary Color Changer {rarity === 'HALLOWEEN_2026' ? '(Halloween Mythic Exclusive)' : '(Legendary Exclusive)'}
                        </label>
                        <span className="text-[10px] font-mono text-emerald-400">
                          Changes Card Name Color
                        </span>
                      </div>

                      <div className="flex items-center gap-3">
                        <input
                          type="color"
                          value={borderColor}
                          onChange={(e) => handlePrimaryColorChange(e.target.value)}
                          className="w-10 h-10 rounded-xl bg-transparent border border-white/20 cursor-pointer p-0.5"
                        />
                        <input
                          type="text"
                          value={borderColor}
                          onChange={(e) => handlePrimaryColorChange(e.target.value)}
                          className="px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 font-mono text-xs grow focus:outline-hidden focus:border-amber-500"
                          placeholder="#f59e0b"
                        />
                      </div>

                      {/* Curated Luxury Color Palettes */}
                      <div className="space-y-1.5 pt-1">
                        <span className="text-[10px] text-stone-400 font-mono">Curated Color Palettes:</span>
                        <div className="flex flex-wrap gap-2">
                          {LUXURY_PALETTES.map((pal) => (
                            <button
                              key={pal.name}
                              type="button"
                              onClick={() => handlePrimaryColorChange(pal.hex)}
                              className={`px-2 py-1 rounded-lg text-[10px] font-sans font-medium flex items-center gap-1.5 border transition-all cursor-pointer ${
                                borderColor.toLowerCase() === pal.hex.toLowerCase()
                                  ? 'bg-white/15 border-white text-white shadow-sm'
                                  : 'bg-stone-950/70 border-white/10 text-stone-300 hover:border-white/30'
                              }`}
                            >
                              <span className="w-2.5 h-2.5 rounded-full shrink-0 shadow-xs" style={{ backgroundColor: pal.hex }} />
                              <span>{pal.name}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between gap-3">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <label className="text-[11px] font-mono uppercase text-stone-300 font-bold">
                            Color Identity ({rarity})
                          </label>
                          <span className="text-[9px] font-mono px-2 py-0.5 rounded-md bg-stone-900 border border-white/10 text-stone-400">
                            Locked to Rarity Tier
                          </span>
                        </div>
                        <p className="text-[10.5px] text-stone-400">
                          Color customization is available for Legendary cards only. Non-legendary cards automatically use their physical rarity tier colors.
                        </p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0 px-3 py-1.5 rounded-xl bg-stone-900 border border-white/10">
                        <span
                          className="w-3.5 h-3.5 rounded-full shrink-0 shadow-xs"
                          style={{ backgroundColor: getRarityMaterialConfig(rarity).primaryColor }}
                        />
                        <span className="text-xs font-mono font-bold text-stone-200">
                          {getRarityMaterialConfig(rarity).primaryColor}
                        </span>
                      </div>
                    </div>
                  )}

                  {/* Upgraded Holographic / Foil Visual Finish & Custom Foil Color */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold flex items-center gap-1.5">
                        <Sparkles size={13} className="text-[#5eead4]" />
                        <span>Upgraded Holographic / Foil Finish & Color</span>
                      </label>
                      <span className="text-[10px] font-mono text-[#5eead4]">Interactive Specular Physics</span>
                    </div>

                    {/* Foil Style Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {[
                        { id: 'standard', name: 'Standard (Matte)', desc: 'Natural archival surface' },
                        { id: 'holographic', name: 'Ultra Holo Prism', desc: 'Spectral chromatic diffraction' },
                        { id: 'cosmic', name: 'Cosmic Starlight', desc: 'Nebula galaxy supernova' },
                        { id: 'gold_embossed', name: '24K Golden Leaf', desc: 'Bullion embossed luster' },
                        { id: 'prismatic_crystal', name: 'Prismatic Crystal', desc: 'Diamond facet refraction' },
                        { id: 'cyber_matrix', name: 'Cyber Hologram', desc: 'Neon scanline grid' },
                        { id: 'astral_supernova', name: 'Liquid Chrome', desc: 'Fluid mirror sheen' },
                        { id: 'aurora_emerald', name: 'Aurora Emerald', desc: 'Borealis wave shimmer' },
                        { id: 'crimson_inferno', name: 'Crimson Magma', desc: 'Molten radiant inferno' },
                        { id: 'obsidian_mirror', name: 'Obsidian Mirror', desc: 'Dark metallic facet' },
                        { id: 'halloween_specter', name: '🎃 Witchfire Specter', desc: 'Pumpkin fire & cursed embers' },
                      ].map((f) => (
                        <button
                          key={f.id}
                          type="button"
                          onClick={() => setFoilStyle(f.id as CardFoilStyle)}
                          className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                            foilStyle === f.id
                              ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-sm'
                              : 'bg-stone-950/60 border-white/10 text-stone-400 hover:border-white/25 hover:text-stone-200'
                          }`}
                        >
                          <div className="font-serif font-bold text-xs truncate">{f.name}</div>
                          <div className="text-[9px] text-stone-400 truncate mt-0.5">{f.desc}</div>
                        </button>
                      ))}
                    </div>

                    {/* Choose Foil Color / Sheen Tint */}
                    {rarity === 'LEGENDARY' ? (
                      <div className="pt-2 border-t border-white/10 space-y-2">
                        <div className="flex items-center justify-between">
                          <label className="text-[10.5px] font-mono uppercase text-stone-300 font-bold block">
                            Choose Foil Sheen Color (لون لمعة الفويل)
                          </label>
                          <span className="text-[10px] font-mono text-amber-300">{foilColor}</span>
                        </div>

                        <div className="flex items-center gap-3">
                          <input
                            type="color"
                            value={foilColor}
                            onChange={(e) => setFoilColor(e.target.value)}
                            className="w-8 h-8 rounded-xl bg-transparent border border-white/20 cursor-pointer p-0.5"
                          />
                          <div className="flex flex-wrap gap-1.5">
                            {FOIL_COLOR_PRESETS.map((fc) => (
                              <button
                                key={fc.name}
                                type="button"
                                onClick={() => setFoilColor(fc.hex)}
                                className={`px-2 py-1 rounded-lg text-[9px] font-mono flex items-center gap-1 border transition-all cursor-pointer ${
                                  foilColor.toLowerCase() === fc.hex.toLowerCase()
                                    ? 'bg-white/20 border-white text-white font-bold'
                                    : 'bg-black/60 border-white/10 text-stone-300 hover:border-white/30'
                                }`}
                              >
                                <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: fc.hex }} />
                                <span>{fc.name}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="pt-2 border-t border-white/10 flex items-center justify-between gap-3">
                        <div className="space-y-0.5">
                          <label className="text-[10.5px] font-mono uppercase text-stone-400 font-bold block">
                            Foil Sheen Hue ({rarity})
                          </label>
                          <p className="text-[10px] text-stone-500">
                            Foil sheen color is locked to rarity. Only Legendary cards can customize foil tint.
                          </p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0 px-2.5 py-1 rounded-lg bg-stone-900 border border-white/10">
                          <span
                            className="w-3 h-3 rounded-full shrink-0 shadow-xs"
                            style={{ backgroundColor: getRarityMaterialConfig(rarity).primaryColor }}
                          />
                          <span className="text-[11px] font-mono font-bold text-stone-300">
                            {getRarityMaterialConfig(rarity).primaryColor}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Continuous Idle Holographic Behavior (All 10 behaviors) */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Continuous Holographic Behavior (حركة الهولوجرام المستمرة)
                      </label>
                      <span className="text-[10px] font-mono text-cyan-300">Live Idle Loop</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {[
                        { id: 'none', label: '1. None', desc: 'Static rarity metallic material only' },
                        { id: 'diagonal_sweep', label: '2. Diagonal Sweep', desc: 'Soft reflective band travelling diagonally' },
                        { id: 'horizontal_sweep', label: '3. Horizontal Sweep', desc: 'Metallic reflection travels left to right' },
                        { id: 'vertical_sweep', label: '4. Vertical Sweep', desc: 'Reflection travels top to bottom' },
                        { id: 'prismatic_shift', label: '5. Prismatic Shift', desc: 'Controlled spectral chromatic refraction' },
                        { id: 'iridescent_flow', label: '6. Iridescent Flow', desc: 'Slow pearlescent oil-on-water movement' },
                        { id: 'radial_gleam', label: '7. Radial Gleam', desc: 'Concentrated gemstone orbital luster' },
                        { id: 'edge_shimmer', label: '8. Edge Shimmer', desc: 'Highlight travelling around card perimeter' },
                        { id: 'holographic_wave', label: '9. Holographic Wave', desc: 'Multiple undulating interference waves' },
                        { id: 'full_foil', label: '10. Full Foil', desc: 'Metallic reflection, holo, iridescence & edge shimmer' },
                      ].map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setHolographicBehavior(item.id as HolographicBehavior)}
                          className={`p-2.5 rounded-xl text-start border transition-all cursor-pointer ${
                            holographicBehavior === item.id
                              ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-sm'
                              : 'bg-stone-900/60 border-stone-800 text-stone-300 hover:border-stone-700'
                          }`}
                        >
                          <div className="font-serif font-bold text-xs">{item.label}</div>
                          <div className="text-[10px] text-stone-400">{item.desc}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Foil Intensity & Reflection Speed */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Foil Intensity */}
                    <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Foil Intensity (قوة لمعان الفويل)
                      </label>
                      <div className="grid grid-cols-2 gap-1.5">
                        {[
                          { id: 'low', label: 'Low', desc: 'Subtle' },
                          { id: 'medium', label: 'Medium', desc: 'Balanced' },
                          { id: 'high', label: 'High', desc: 'Strong' },
                          { id: 'ultra', label: 'Ultra', desc: 'Max Depth' },
                        ].map((int) => (
                          <button
                            key={int.id}
                            type="button"
                            onClick={() => setFoilIntensity(int.id as FoilIntensity)}
                            className={`p-2 rounded-xl text-center border transition-all cursor-pointer ${
                              foilIntensity === int.id
                                ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                                : 'bg-stone-900/60 border-stone-800 text-stone-400 hover:text-stone-200'
                            }`}
                          >
                            <div className="font-bold text-xs">{int.label}</div>
                            <div className="text-[9px] text-stone-500">{int.desc}</div>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Reflection Speed */}
                    <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Reflection Speed (سرعة الحركة)
                      </label>
                      <div className="grid grid-cols-3 gap-1.5">
                        {[
                          { val: 0.7, label: 'Serene' },
                          { val: 1.0, label: 'Normal' },
                          { val: 1.4, label: 'Dynamic' },
                        ].map((sp) => (
                          <button
                            key={sp.label}
                            type="button"
                            onClick={() => setReflectionSpeed(sp.val)}
                            className={`p-2 rounded-xl text-center border transition-all cursor-pointer ${
                              reflectionSpeed === sp.val
                                ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                                : 'bg-stone-900/60 border-stone-800 text-stone-400 hover:text-stone-200'
                            }`}
                          >
                            <div className="font-bold text-xs">{sp.label}</div>
                            <div className="text-[9px] text-stone-500">{sp.val}x</div>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Card Name Color Customizer (Sync or Custom) */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Card Name Color
                      </label>
                      <label className="flex items-center gap-1.5 text-[10px] font-mono text-stone-300 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={isNameColorSynced}
                          onChange={(e) => {
                            const synced = e.target.checked;
                            setIsNameColorSynced(synced);
                            if (synced) {
                              setNameColor(borderColor);
                            }
                          }}
                          className="rounded border-stone-700 text-amber-500 focus:ring-0 cursor-pointer"
                        />
                        <span>Sync with Primary Color</span>
                      </label>
                    </div>

                    {!isNameColorSynced && (
                      <div className="flex items-center gap-3 pt-1">
                        <input
                          type="color"
                          value={nameColor}
                          onChange={(e) => setNameColor(e.target.value)}
                          className="w-8 h-8 rounded-lg bg-transparent border border-white/20 cursor-pointer p-0.5"
                        />
                        <input
                          type="text"
                          value={nameColor}
                          onChange={(e) => setNameColor(e.target.value)}
                          className="px-3 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 font-mono text-xs grow focus:outline-hidden focus:border-amber-500"
                          placeholder="#f59e0b"
                        />
                      </div>
                    )}
                    <p className="text-[10px] text-stone-400 font-mono">
                      Controls the glowing typography color of "{name || 'Card Name'}" on the card face.
                    </p>
                  </div>

                  {/* Aura & Glow Intensity */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2.5">
                    <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                      Aura & Glow Intensity
                    </label>
                    <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                      {(['none', 'subtle', 'radiant', 'blazing', 'celestial'] as CardGlowIntensity[]).map((intensity) => (
                        <button
                          key={intensity}
                          type="button"
                          onClick={() => setGlowIntensity(intensity)}
                          className={`py-2 px-2 rounded-xl text-[11px] font-mono capitalize border transition-all cursor-pointer text-center ${
                            glowIntensity === intensity
                              ? 'bg-amber-500/25 border-amber-400 text-amber-200 shadow-sm font-bold'
                              : 'bg-stone-950/60 border-white/10 text-stone-400 hover:border-white/25'
                          }`}
                        >
                          {intensity}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Architectural Border Style */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Architectural Border Architecture
                      </label>
                      <span className="text-[10px] font-mono text-stone-400">Rarity Dynamic</span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {[
                        { id: 'auto', name: 'Auto (By Rarity)', desc: 'Changes by card rarity' },
                        { id: 'ornate_legendary', name: 'Gilded Sovereign', desc: 'Double-bezel gold pillars' },
                        { id: 'crystal_epic', name: 'Crystal Epic', desc: 'Prismatic starburst frame' },
                        { id: 'runic_rare', name: 'Runic Rare', desc: 'Dual-line compass matrix' },
                        { id: 'cyber_sleek', name: 'Cyber Sleek', desc: 'Chamfered tech chassis' },
                        { id: 'minimalist', name: 'Minimalist Line', desc: 'Clean architectural hairline' },
                        { id: 'halloween_spectral', name: '🎃 Halloween Spectral', desc: 'Bat arch & cursed flame' },
                      ].map((f) => (
                        <button
                          key={f.id}
                          type="button"
                          onClick={() => setFrameStyle(f.id as CardFrameStyle)}
                          className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                            frameStyle === f.id
                              ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-sm'
                              : 'bg-stone-950/60 border-white/10 text-stone-400 hover:border-white/25 hover:text-stone-200'
                          }`}
                        >
                          <div className="font-serif font-bold text-xs truncate">{f.name}</div>
                          <div className="text-[9px] text-stone-400 truncate mt-0.5">{f.desc}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Background Theme */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2.5">
                    <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                      Card Canvas & Background Theme
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {[
                        { id: 'auto', name: 'Auto (Rarity Theme)', color: 'from-amber-950/80 to-stone-950' },
                        { id: 'dark_slate', name: 'Dark Slate Matrix', color: 'from-slate-900 to-black' },
                        { id: 'deep_obsidian', name: 'Deep Obsidian Void', color: 'from-[#050508] to-black' },
                        { id: 'void_nebula', name: 'Void Nebula', color: 'from-purple-950 to-stone-950' },
                        { id: 'ancient_gold', name: 'Ancient Bullion Gold', color: 'from-amber-900 to-stone-950' },
                        { id: 'emerald_marble', name: 'Emerald Jade', color: 'from-emerald-950 to-stone-950' },
                      ].map((bg) => (
                        <button
                          key={bg.id}
                          type="button"
                          onClick={() => setBackgroundTheme(bg.id as CardBackgroundTheme)}
                          className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                            backgroundTheme === bg.id
                              ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-sm'
                              : 'bg-stone-950/60 border-white/10 text-stone-400 hover:border-white/25 hover:text-stone-200'
                          }`}
                        >
                          <div className="font-serif font-bold text-xs truncate">{bg.name}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: IDENTITY & LORE */}
              {activeTab === 'identity' && (
                <div className="space-y-4 text-xs">
                  {/* Name & Title */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-2xl bg-black/40 border border-white/5">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Card Name *
                      </label>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Lord Sovereign Prime"
                        className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 font-serif font-bold text-sm focus:outline-hidden focus:border-amber-500"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Subtitle / Epithet
                      </label>
                      <input
                        type="text"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        placeholder="e.g. Archon of the Cosmic Flame"
                        className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 text-xs focus:outline-hidden focus:border-amber-500"
                      />
                    </div>
                  </div>

                  {/* Series & Card Type */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-2xl bg-black/40 border border-white/5">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Card Type / Class
                      </label>
                      <select
                        value={cardType}
                        onChange={(e) => setCardType(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 text-xs focus:outline-hidden focus:border-amber-500 cursor-pointer"
                      >
                        {CARD_TYPES.map((t) => (
                          <option key={t} value={t}>{t}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Series / Collection
                      </label>
                      <input
                        type="text"
                        value={series}
                        onChange={(e) => setSeries(e.target.value)}
                        placeholder="e.g. Apex Sovereigns"
                        className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 text-xs focus:outline-hidden focus:border-amber-500"
                      />
                    </div>
                  </div>

                  {/* Rarity & Element & Status */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 rounded-2xl bg-black/40 border border-white/5">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Rarity Tier
                      </label>
                      <select
                        value={rarity}
                        onChange={(e) => handleRarityChange(e.target.value as CardRarity)}
                        className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-200 font-bold text-xs focus:outline-hidden focus:border-amber-500 cursor-pointer"
                      >
                        <option value="COMMON">COMMON</option>
                        <option value="UNCOMMON">UNCOMMON</option>
                        <option value="RARE">RARE</option>
                        <option value="EPIC">EPIC</option>
                        <option value="LEGENDARY">LEGENDARY</option>
                        <option value="HALLOWEEN_2026">🎃 HALLOWEEN 2026 (Limited Mythic)</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Element Affinity
                      </label>
                      <select
                        value={element}
                        onChange={(e) => setElement(e.target.value as CardElement)}
                        className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 text-xs focus:outline-hidden focus:border-amber-500 cursor-pointer"
                      >
                        <option value="ASTRAL">ASTRAL</option>
                        <option value="STONE">STONE</option>
                        <option value="STORM">STORM</option>
                        <option value="FIRE">FIRE</option>
                        <option value="WATER">WATER</option>
                      </select>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Booster Pack Drops
                      </label>
                      <button
                        type="button"
                        onClick={() => setIsActive(!isActive)}
                        className={`w-full py-2 px-3 rounded-xl border text-xs font-mono font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                          isActive
                            ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300'
                            : 'bg-stone-900 border-stone-700 text-stone-400'
                        }`}
                      >
                        <span className={`w-2 h-2 rounded-full ${isActive ? 'bg-emerald-400 animate-pulse' : 'bg-stone-500'}`} />
                        <span>{isActive ? 'Active in Packs' : 'Vaulted (Off)'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Lore & Description */}
                  <div className="space-y-3 p-3.5 rounded-2xl bg-black/40 border border-white/5">
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Card Lore / Inscription
                      </label>
                      <textarea
                        rows={2}
                        value={lore}
                        onChange={(e) => setLore(e.target.value)}
                        placeholder="Mythological, historical, or cosmological narrative text..."
                        className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 text-xs focus:outline-hidden focus:border-amber-500 italic font-serif"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Card Summary / Tactical Description
                      </label>
                      <textarea
                        rows={2}
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder="Brief combat or relic overview..."
                        className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 text-xs focus:outline-hidden focus:border-amber-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: CUSTOM STATS & RATING NUMBER */}
              {activeTab === 'stats' && (
                <div className="space-y-4 text-xs">
                  {/* Top Stats Banner: Overall Rating Master Display */}
                  <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/60 via-stone-900 to-amber-950/60 border border-amber-500/40 flex items-center justify-between flex-wrap gap-3 shadow-lg">
                    <div>
                      <span className="text-[10px] font-mono uppercase text-amber-300 font-bold block tracking-wider">
                        Dynamic Overall Rating (Upper Right Number)
                      </span>
                      <div className="flex items-baseline gap-2 mt-0.5">
                        <span className="text-3xl font-black font-mono text-amber-200 tracking-tight">
                          {computedOvr}
                        </span>
                        <span className="text-xs font-mono text-stone-400">/ 100 Overall</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        type="button"
                        onClick={handleSaveAsGlobalBlueprint}
                        className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/50 text-[11px] font-mono font-bold flex items-center gap-1.5 cursor-pointer transition-all"
                        title="Save these customized stats as the Global Blueprint for all cards"
                      >
                        <BookmarkCheck size={13} className="text-amber-400" />
                        <span>Save as Global Blueprint</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleResetToGlobalBlueprint}
                        className="px-2.5 py-1.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-300 border border-white/10 text-[11px] font-mono flex items-center gap-1 cursor-pointer transition-all"
                        title="Restore stats from the global blueprint"
                      >
                        <RotateCcw size={12} />
                        <span>Reset to Blueprint</span>
                      </button>
                    </div>
                  </div>

                  {/* Dedicated OVR Rating Customizer Banner Shortcut */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <SlidersHorizontal size={15} className="text-amber-400 shrink-0" />
                      <div>
                        <div className="text-xs font-mono font-bold text-amber-200">
                          OVR Rating Number: {ratingFontSize}px • Y:{ratingOffsetY}px • X:{ratingOffsetX}px
                        </div>
                        <div className="text-[10px] text-stone-400 font-mono">
                          Universal position & size settings (Applied to all cards)
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveTab('ovr')}
                      className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-mono font-bold border border-amber-500/30 transition-all cursor-pointer whitespace-nowrap"
                    >
                      Open OVR Settings
                    </button>
                  </div>

                  {/* Archetype Quick Presets */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                    <span className="text-[10px] text-stone-400 font-mono">Quick Stat Archetypes:</span>
                    <div className="flex flex-wrap gap-2">
                      {[
                        { name: 'Balanced Vanguard', atk: 75, def: 75, vit: 80, agi: 70, wis: 65 },
                        { name: 'Heavy Fortress', atk: 55, def: 95, vit: 95, agi: 45, wis: 60 },
                        { name: 'Glass Cannon', atk: 95, def: 40, vit: 60, agi: 90, wis: 75 },
                        { name: 'Boss Sovereign', atk: 94, def: 92, vit: 96, agi: 85, wis: 90 },
                        { name: 'Swift Assassin', atk: 90, def: 50, vit: 65, agi: 95, wis: 70 },
                        { name: 'Archon Mystic', atk: 70, def: 65, vit: 75, agi: 75, wis: 98 },
                      ].map((arch) => (
                        <button
                          key={arch.name}
                          type="button"
                          onClick={() => {
                            setUnifiedStats([
                              { id: 'attack', name: 'Attack', value: arch.atk, maxValue: 100, icon: 'swords', color: '#f43f5e' },
                              { id: 'defense', name: 'Defense', value: arch.def, maxValue: 100, icon: 'shield', color: '#06b6d4' },
                              { id: 'hp', name: 'Vitality', value: arch.vit, maxValue: 100, icon: 'heart', color: '#10b981' },
                              { id: 'speed', name: 'Agility', value: arch.agi, maxValue: 100, icon: 'zap', color: '#f59e0b' },
                              { id: 'intelligence', name: 'Wisdom', value: arch.wis, maxValue: 100, icon: 'sparkles', color: '#a855f7' },
                            ]);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-stone-900 hover:bg-stone-800 border border-white/10 text-stone-300 hover:text-white text-[10px] font-mono cursor-pointer transition-colors"
                        >
                          {arch.name}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Unified Stats Customizer List */}
                  <div className="space-y-3 p-3.5 rounded-2xl bg-black/40 border border-white/5">
                    <div className="flex items-center justify-between pb-1 border-b border-white/10">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        All Card Stats ({unifiedStats.length}) — Fully Customizable
                      </label>

                      <button
                        type="button"
                        onClick={handleAddCustomStat}
                        className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:brightness-110 text-stone-950 font-serif font-bold text-xs flex items-center gap-1.5 shadow cursor-pointer transition-all active:scale-95"
                      >
                        <Plus size={13} />
                        <span>Add Custom Stat</span>
                      </button>
                    </div>

                    {unifiedStats.length === 0 ? (
                      <div className="p-6 text-center text-stone-500 space-y-2">
                        <p>No stats defined yet.</p>
                        <button
                          type="button"
                          onClick={() => setUnifiedStats(getDefaultCardStats())}
                          className="px-3 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-mono"
                        >
                          Restore Standard Stats
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {unifiedStats.map((st, idx) => {
                          const IconComp = STAT_ICON_OPTIONS.find(o => o.id === st.icon)?.icon || Zap;
                          return (
                            <div
                              key={st.id || idx}
                              className="p-3 rounded-2xl bg-stone-950/70 border border-white/10 space-y-2.5 transition-colors hover:border-white/20"
                            >
                              {/* Top row: Name, Icon, Color, Value, Delete */}
                              <div className="flex items-center gap-2.5 flex-wrap">
                                {/* Stat Icon */}
                                <div
                                  className="w-8 h-8 rounded-xl border flex items-center justify-center shrink-0 shadow-sm"
                                  style={{
                                    backgroundColor: `${st.color || '#f59e0b'}20`,
                                    borderColor: `${st.color || '#f59e0b'}50`,
                                    color: st.color || '#f59e0b',
                                  }}
                                >
                                  <IconComp size={15} />
                                </div>

                                {/* Stat Name Input */}
                                <input
                                  type="text"
                                  value={st.name}
                                  onChange={(e) => handleUpdateStat(idx, { name: e.target.value })}
                                  placeholder="Stat Name (e.g. Critical, Mana, Armor)"
                                  className="px-3 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 font-mono text-xs w-36 sm:w-44 focus:outline-hidden focus:border-amber-500"
                                />

                                {/* Icon selector */}
                                <select
                                  value={st.icon || 'zap'}
                                  onChange={(e) => handleUpdateStat(idx, { icon: e.target.value })}
                                  className="px-2 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-300 text-xs font-mono cursor-pointer"
                                >
                                  {STAT_ICON_OPTIONS.map(opt => (
                                    <option key={opt.id} value={opt.id}>{opt.label}</option>
                                  ))}
                                </select>

                                {/* Color Picker */}
                                <div className="flex items-center gap-1.5">
                                  <input
                                    type="color"
                                    value={st.color || '#f59e0b'}
                                    onChange={(e) => handleUpdateStat(idx, { color: e.target.value })}
                                    className="w-7 h-7 rounded-lg bg-transparent border border-white/20 cursor-pointer p-0.5 shrink-0"
                                    title="Stat Badge Color"
                                  />
                                </div>

                                {/* Numeric value badge */}
                                <div className="ms-auto flex items-center gap-2">
                                  <input
                                    type="number"
                                    min="0"
                                    max="100"
                                    value={st.value}
                                    onChange={(e) => handleUpdateStat(idx, { value: Math.min(100, Math.max(0, Number(e.target.value))) })}
                                    className="w-16 px-2 py-1 rounded-xl bg-stone-900 border border-stone-800 text-amber-200 font-mono font-bold text-xs text-center focus:outline-hidden focus:border-amber-500"
                                  />
                                  <span className="text-[10px] font-mono text-stone-500">/ 100</span>

                                  {/* Delete stat */}
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveStat(idx)}
                                    className="p-1.5 rounded-lg text-stone-500 hover:text-rose-400 hover:bg-rose-950/40 cursor-pointer transition-colors"
                                    title="Delete this stat"
                                  >
                                    <Trash2 size={14} />
                                  </button>
                                </div>
                              </div>

                              {/* Slider */}
                              <div className="pt-1 flex items-center gap-3">
                                <input
                                  type="range"
                                  min="0"
                                  max="100"
                                  value={st.value}
                                  onChange={(e) => handleUpdateStat(idx, { value: Number(e.target.value) })}
                                  className="w-full cursor-pointer h-1.5 bg-stone-800 rounded-lg accent-amber-500"
                                  style={{
                                    accentColor: st.color || '#f59e0b'
                                  }}
                                />
                                <span
                                  className="font-mono font-bold text-xs w-8 text-end"
                                  style={{ color: st.color || '#f59e0b' }}
                                >
                                  {st.value}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 4: ABILITIES & GAMEPLAY STATES */}
              {activeTab === 'abilities' && (
                <div className="space-y-4 text-xs">
                  {/* Abilities List */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Card Abilities ({abilities.length})
                      </label>
                    </div>

                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {abilities.length === 0 ? (
                        <p className="text-stone-500 text-xs italic py-2">No active abilities added yet.</p>
                      ) : (
                        abilities.map((ab) => (
                          <div key={ab.id} className="p-2.5 rounded-xl bg-stone-900/80 border border-white/10 flex items-start justify-between gap-3">
                            <div className="min-w-0 space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="font-serif font-bold text-amber-200 text-xs truncate">{ab.name}</span>
                                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/60 border border-white/10 text-stone-300 uppercase">
                                  {ab.type}
                                </span>
                                {ab.cooldown ? (
                                  <span className="text-[9px] font-mono text-cyan-300">CD: {ab.cooldown}r</span>
                                ) : null}
                              </div>
                              <p className="text-[11px] text-stone-300 leading-snug">{ab.description}</p>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleRemoveAbility(ab.id)}
                              className="p-1 text-stone-500 hover:text-rose-400 cursor-pointer shrink-0"
                              title="Remove ability"
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        ))
                      )}
                    </div>

                    {/* Add New Ability Form */}
                    <div className="pt-2 border-t border-white/10 space-y-2">
                      <span className="text-[10px] text-stone-400 font-mono">Create New Ability:</span>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <input
                          type="text"
                          placeholder="Ability Name"
                          value={newAbilityName}
                          onChange={(e) => setNewAbilityName(e.target.value)}
                          className="px-2.5 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 text-xs"
                        />
                        <select
                          value={newAbilityType}
                          onChange={(e) => setNewAbilityType(e.target.value as AbilityCategory)}
                          className="px-2.5 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 text-xs cursor-pointer"
                        >
                          {ABILITY_CATEGORIES.map(cat => (
                            <option key={cat.type} value={cat.type}>{cat.label}</option>
                          ))}
                        </select>
                        <button
                          type="button"
                          onClick={handleAddAbility}
                          className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-serif font-bold text-xs flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Plus size={13} /> <span>Add Ability</span>
                        </button>
                      </div>
                      <textarea
                        rows={2}
                        placeholder="Ability effect description..."
                        value={newAbilityDesc}
                        onChange={(e) => setNewAbilityDesc(e.target.value)}
                        className="w-full px-2.5 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 text-xs"
                      />
                    </div>
                  </div>

                  {/* Structured Temporary States */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2.5">
                    <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                      Temporary Gameplay States Preset
                    </label>
                    <p className="text-[10px] text-stone-400">Toggle states to simulate status effects in live battles:</p>
                    <div className="flex flex-wrap gap-2 pt-1">
                      {CARD_STATE_PRESETS.map((pst) => {
                        const isActiveState = cardStates.some(s => s.name === pst.type);
                        return (
                          <button
                            key={pst.type}
                            type="button"
                            onClick={() => handleToggleState(pst.type)}
                            className={`px-2.5 py-1 rounded-xl text-[10px] font-mono border transition-all cursor-pointer ${
                              isActiveState
                                ? 'bg-amber-500/25 border-amber-400 text-amber-300 font-bold shadow-xs'
                                : 'bg-stone-950/60 border-white/10 text-stone-400 hover:border-white/20'
                            }`}
                          >
                            {pst.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: ARTWORK & DEVICE UPLOAD */}
              {activeTab === 'media' && (
                <div className="space-y-4 text-xs">
                  {/* Device Upload Master Banner */}
                  <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-stone-900 to-cyan-950/60 border border-[rgba(158,255,230,0.3)] space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <h4 className="text-xs font-serif font-black uppercase text-[#5eead4] flex items-center gap-1.5">
                          <Upload size={14} />
                          <span>Direct Device Media Upload // رفع من جهازك</span>
                        </h4>
                        <p className="text-[10px] text-stone-300">
                          Select high-resolution photos and videos directly from your computer or phone.
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      {/* Photo from Device Button */}
                      <button
                        type="button"
                        disabled={isUploadingPhoto}
                        onClick={() => photoInputRef.current?.click()}
                        className="py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500/20 via-teal-500/20 to-amber-500/20 hover:from-amber-500/35 hover:to-teal-500/35 border border-amber-500/50 text-stone-100 font-serif font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 shadow-md disabled:opacity-50"
                      >
                        <ImageIcon size={16} className="text-amber-400 shrink-0" />
                        <span>{isUploadingPhoto ? 'Processing Photo...' : 'Upload Photo from Device (صورة من جهازك)'}</span>
                      </button>

                      {/* Video from Device Button */}
                      <button
                        type="button"
                        disabled={isUploadingVideo}
                        onClick={() => videoInputRef.current?.click()}
                        className="py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-cyan-500/20 hover:from-cyan-500/35 hover:to-purple-500/35 border border-cyan-500/50 text-stone-100 font-serif font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 shadow-md disabled:opacity-50"
                      >
                        <Film size={16} className="text-cyan-400 shrink-0" />
                        <span>{isUploadingVideo ? 'Reading Video...' : 'Upload Video from Device (فيديو من جهازك)'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Artwork URL & Presets */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold flex items-center gap-1.5">
                        <ImageIcon size={13} /> <span>Card Artwork URL or Presets</span>
                      </label>
                    </div>

                    <div className="space-y-1.5">
                      <input
                        type="url"
                        value={imageUrl}
                        onChange={(e) => setImageUrl(e.target.value)}
                        placeholder="https://... image URL (PNG, JPG, WebP) or uploaded from device above"
                        className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 text-xs focus:outline-hidden focus:border-amber-500"
                      />
                    </div>

                    {/* Preset Artwork Chips */}
                    <div className="space-y-1.5">
                      <span className="text-[10px] text-stone-400 font-mono">Curated High-Res Artworks:</span>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {PRESET_ARTWORKS.map((art) => (
                          <button
                            key={art.label}
                            type="button"
                            onClick={() => setImageUrl(art.url)}
                            className={`p-1.5 rounded-xl border text-left flex items-center gap-2 transition-all cursor-pointer ${
                              imageUrl === art.url
                                ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                                : 'bg-stone-950/60 border-white/10 text-stone-400 hover:border-white/25 hover:text-stone-200'
                            }`}
                          >
                            <img src={art.url} alt="" className="w-8 h-8 rounded-lg object-cover border border-white/10 shrink-0" />
                            <span className="text-[10px] font-sans truncate">{art.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Cinematic Pack Opening Reveal Video */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold flex items-center gap-1.5">
                        <Film size={13} /> <span>Cinematic Reveal Video (Optional MP4 / Device Upload)</span>
                      </label>
                      {revealVideoUrl && (
                        <button
                          type="button"
                          onClick={() => setRevealVideoUrl('')}
                          className="text-[10px] font-mono text-rose-400 hover:underline cursor-pointer"
                        >
                          Remove Video
                        </button>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <input
                        type="url"
                        value={revealVideoUrl}
                        onChange={(e) => setRevealVideoUrl(e.target.value)}
                        placeholder="https://... video URL for legendary reveal animation"
                        className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 text-xs focus:outline-hidden focus:border-amber-500"
                      />
                    </div>

                    {/* Preset Videos */}
                    <div className="space-y-1.5">
                      <span className="text-[10px] text-stone-400 font-mono">Sample Reveal Videos:</span>
                      <div className="flex flex-wrap gap-2">
                        {PRESET_VIDEOS.map((vid) => (
                          <button
                            key={vid.label}
                            type="button"
                            onClick={() => setRevealVideoUrl(vid.url)}
                            className={`px-2.5 py-1.5 rounded-xl border text-[10px] font-mono flex items-center gap-1.5 cursor-pointer transition-all ${
                              revealVideoUrl === vid.url
                                ? 'bg-cyan-950/80 border-cyan-400 text-cyan-200'
                                : 'bg-stone-950/60 border-white/10 text-stone-400 hover:border-white/25'
                            }`}
                          >
                            <PlayCircle size={12} />
                            <span>{vid.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Video Test Player */}
                    {revealVideoUrl && (
                      <div className="mt-2 rounded-xl overflow-hidden border border-white/10 bg-black aspect-video max-w-sm mx-auto">
                        <video
                          src={parseUniversalVideoUrl(revealVideoUrl)}
                          controls
                          muted
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 7: LEGENDARY COMBAT SOUND EFFECTS CUSTOMIZATION */}
              {activeTab === 'sfx' && rarity === 'LEGENDARY' && (
                <div className="space-y-4 pt-1">
                  <LegendaryCombatAudioSection
                    targetCard={previewCard}
                    legendaryCards={allCards.filter(c => c.rarity === 'LEGENDARY')}
                    embedded={true}
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer Actions - Always cleanly accessible */}
        <div className="pt-3 mt-2 border-t border-white/10 flex items-center justify-between shrink-0 gap-2 sm:gap-3 bg-[#040c10]/95 backdrop-blur-md z-30">
          <div>
            {card && (
              <button
                type="button"
                disabled={isDeleting || isSaving}
                onClick={handleDeleteCard}
                className="px-3 sm:px-4 py-2 rounded-full bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-500/40 text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50 active:scale-95"
              >
                <Trash2 size={13} />
                <span>{isDeleting ? 'Deleting...' : 'Delete'}</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 sm:gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-full bg-stone-900 hover:bg-stone-800 text-stone-300 text-xs font-mono font-bold uppercase tracking-wider transition-colors cursor-pointer active:scale-95"
            >
              Cancel
            </button>

            <button
              type="button"
              disabled={isSaving || isDeleting}
              onClick={handleSaveCard}
              className="px-5 sm:px-6 py-2.5 rounded-full bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 hover:brightness-110 text-stone-950 font-mono font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-amber-500/25 transition-all cursor-pointer disabled:opacity-50 active:scale-95"
            >
              <Sparkles size={14} className={isSaving ? 'animate-spin' : ''} />
              <span>{isSaving ? 'Saving...' : card ? 'Save Changes' : 'Forge Card'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Embedded Items & Upgrade Shards Manager */}
      {isItemManagerOpen && (
        <OwnerUnifiedItemManagerModal
          isOpen={isItemManagerOpen}
          onClose={() => setIsItemManagerOpen(false)}
        />
      )}
    </div>
  );
};
