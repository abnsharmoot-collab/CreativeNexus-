import React, { useRef, useState, useEffect } from 'react';
import { CinematicStage } from './CinematicStage';
import { motion, AnimatePresence } from 'motion/react';
import {
  CollectibleCardData,
  CardOwnership,
  getUnifiedCardStats,
  calculateCardOverallRating,
  CardStatItem,
  CardRarity,
} from '../../types/cards';
import { useCards } from '../../context/CardContext';
import { useAuth } from '../../context/AuthContext';
import { RARITY_THEMES } from './CollectibleCard';
import { CardBorderElements } from './CardBorderElements';
import { CardFoilOverlay } from './CardFoilOverlay';
import { parseUniversalVideoUrl } from '../../utils/videoHelpers';
import { LegendaryCombatAudioModal } from './LegendaryCombatAudioModal';
import {
  X, Star, Shield, BookOpen, Layers, Check, Share2, Zap, Film,
  Sparkles, Flame, Edit, ArrowUpRight, Music, ArrowRight, AlertTriangle, Trophy, Crown
} from 'lucide-react';
import { useCardUpgrade } from '../../context/CardUpgradeContext';
import { useItems } from '../../context/ItemContext';
import { BrawlStarsItemDisplay } from '../items/BrawlStarsItemDisplay';
import { getNextRarityTier } from '../../types/cardUpgrade';
import { playBattleSound } from '../../utils/battleAudio';

interface CardDetailModalProps {
  card: CollectibleCardData | null;
  onClose: () => void;
  onEditInStudio?: (card: CollectibleCardData) => void;
}

export const CardDetailModal: React.FC<CardDetailModalProps> = ({ card, onClose, onEditInStudio }) => {
  const { isOwner } = useAuth();
  const { toggleShowcase, isCardShowcased, getCardOwnership, globalRatingSettings, allCards } = useCards();
  const { upgradeConfig, attemptUpgradeCard } = useCardUpgrade();
  const { inventoryMap, items } = useItems();
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [glarePos, setGlarePos] = useState({ x: 50, y: 30 });
  const [isHovered, setIsHovered] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [clickCount, setClickCount] = useState(0);
  const [clickShine, setClickShine] = useState(false);
  const [isAudioModalOpen, setIsAudioModalOpen] = useState(false);

  // Active detail modal tab: clean and simple
  const [activeTab, setActiveTab] = useState<'stats' | 'upgrade' | 'lore' | 'abilities' | 'video'>('stats');
  const [isUpgrading, setIsUpgrading] = useState(false);
  const [upgradeOutcome, setUpgradeOutcome] = useState<any | null>(null);
  const [upgradeError, setUpgradeError] = useState<string | null>(null);

  if (!card) return null;

  const ownership: CardOwnership | undefined = getCardOwnership(card.id);
  const isShowcased = isCardShowcased(card.id);

  // Dynamic effective rarity from upgrade status
  const effectiveRarity: CardRarity = upgradeOutcome?.newRarity || ownership?.upgradedRarity || card.rarity;
  const isLegendary = effectiveRarity === 'LEGENDARY';
  const theme = RARITY_THEMES[effectiveRarity] || RARITY_THEMES.COMMON;
  const cardAccent = isLegendary ? (card.borderColor || card.accentColor || theme.accent) : theme.accent;
  const cardNameColor = isLegendary ? (card.nameColor || card.borderColor || card.accentColor || '#f59e0b') : theme.accent;

  // Unified Stats & OVR (Overall) Rating
  const unifiedStats: CardStatItem[] = upgradeOutcome?.updatedCard?.stats || ownership?.upgradedStats || getUnifiedCardStats(card);
  const displayOvr = Math.min(100, Math.max(10, calculateCardOverallRating(unifiedStats, effectiveRarity)));
  const primaryStats = unifiedStats.slice(0, 3);

  // Upgrade calculations
  const nextRarity = getNextRarityTier(effectiveRarity);
  const transitionKey = nextRarity ? `${effectiveRarity}_TO_${nextRarity}` : null;
  const upgradeRule = transitionKey ? upgradeConfig.transitions[transitionKey] : null;

  const requiredShardItemId = upgradeRule?.requiredShardItemId || 'item_shard_common';
  const requiredShardItem = items.find(i => i.id === requiredShardItemId) || {
    id: requiredShardItemId,
    name: 'Upgrade Shard',
    rarity: effectiveRarity,
    category: 'UPGRADE_MATERIAL' as const,
    imageUrl: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=400&q=80'
  };

  const primaryShardCount = inventoryMap[requiredShardItemId]?.count || 0;
  const universalShardCount = upgradeConfig.allowUniversalShards && upgradeConfig.universalShardItemId
    ? (inventoryMap[upgradeConfig.universalShardItemId]?.count || 0)
    : 0;
  const totalUsableShards = primaryShardCount + universalShardCount;
  const requiredCount = upgradeRule?.requiredShardCount || 1;
  const hasEnoughShards = totalUsableShards >= requiredCount;
  const isMaxRarity = nextRarity === null;

  const handleUpgradeAttempt = async () => {
    if (!card || isUpgrading || !hasEnoughShards || isMaxRarity) return;
    setIsUpgrading(true);
    setUpgradeError(null);
    setUpgradeOutcome(null);

    try {
      playBattleSound('FORMATION_SUMMON', 1.0);
      const res = await attemptUpgradeCard(card.id);
      setUpgradeOutcome(res);
      if (res.success) {
        playBattleSound('VICTORY_FANFARE', 1.0);
      } else {
        playBattleSound('DEFEAT_CHORD', 0.85);
      }
    } catch (err: any) {
      setUpgradeError(err.message || 'Upgrade failed');
      playBattleSound('DEFEAT_CHORD', 0.85);
    } finally {
      setIsUpgrading(false);
    }
  };

  // Cinematic: tilt with phone gyroscope when not hovering/touching
  useEffect(() => {
    const clamp = (v: number, m: number) => Math.max(-m, Math.min(m, v));
    const onOrient = (e: DeviceOrientationEvent) => {
      if (isHovered || e.beta == null || e.gamma == null) return;
      const rx = clamp((e.beta - 50) * -0.35, 14);
      const ry = clamp(e.gamma * 0.35, 14);
      setRotateX(rx);
      setRotateY(ry);
      setGlarePos({ x: Math.round(50 + ry * 3), y: Math.round(35 - rx * 3) });
    };
    window.addEventListener('deviceorientation', onOrient);
    return () => window.removeEventListener('deviceorientation', onOrient);
  }, [isHovered]);

  const requestGyro = () => {
    const D: any = (window as any).DeviceOrientationEvent;
    if (D && typeof D.requestPermission === 'function') D.requestPermission().catch(() => {});
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!cardRef.current || !e.touches[0]) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.touches[0].clientX - rect.left;
    const y = e.touches[0].clientY - rect.top;
    const rx = ((y - rect.height / 2) / (rect.height / 2)) * -14;
    const ry = ((x - rect.width / 2) / (rect.width / 2)) * 14;
    setIsHovered(true);
    setRotateX(rx);
    setRotateY(ry);
    setGlarePos({ x: Math.round((x / rect.width) * 100), y: Math.round((y / rect.height) * 100) });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotX = ((y - centerY) / centerY) * -12;
    const rotY = ((x - centerX) / centerX) * 12;
    setRotateX(rotX);
    setRotateY(rotY);
    setGlarePos({ x: Math.round((x / rect.width) * 100), y: Math.round((y / rect.height) * 100) });
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotateX(0);
    setRotateY(0);
    setGlarePos({ x: 50, y: 30 });
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(`${window.location.origin}/cards?card=${card.id}`);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  const handleCardClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setClickCount(prev => prev + 1);
    setClickShine(true);
    setTimeout(() => setClickShine(false), 500);
  };

  const handleOpenStudio = () => {
    if (onEditInStudio) {
      onEditInStudio(card);
    }
  };

  return (
    <AnimatePresence>
      <div
        className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-5 md:p-6 bg-black/92 backdrop-blur-2xl overflow-y-auto studio-scrollbar"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-4xl max-h-[92vh] bg-gradient-to-b from-[#071318]/98 via-[#040c10]/98 to-[#020608]/98 border border-[rgba(158,255,230,0.25)] rounded-3xl p-4 sm:p-6 shadow-[0_25px_80px_rgba(0,0,0,0.95)] overflow-hidden my-auto flex flex-col"
        >
          {/* Top Hairline Metallic Bevel */}
          <div
            className="absolute top-0 inset-x-0 h-[2px] pointer-events-none transition-all duration-300"
            style={{
              background: `linear-gradient(90deg, transparent 0%, ${cardAccent} 50%, transparent 100%)`,
              boxShadow: `0 0 14px ${cardAccent}`
            }}
          />

          {/* Close button */}
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="absolute top-4 end-4 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-900/80 hover:bg-slate-800 border border-white/10 transition-colors z-20 cursor-pointer"
          >
            <X size={18} />
          </button>

          {/* Master Body Grid: 2 Columns */}
          <div className="flex-1 min-h-0 overflow-y-auto lg:overflow-hidden flex flex-col lg:flex-row gap-6 pt-1 studio-scrollbar">
            {/* ------------------------------------------------------------- */}
            {/* LEFT: 3D ENHANCED OWNER-STYLE CARD WITH INTERACTIVE FOIL & TILT */}
            {/* ------------------------------------------------------------- */}
            <div className="relative isolate overflow-hidden w-full lg:w-[320px] xl:w-[340px] shrink-0 flex flex-col items-center justify-start p-3 sm:p-4 rounded-3xl bg-black/60 border border-white/10 space-y-3">
              <CinematicStage accent={cardAccent} intense={isLegendary} />
              <div
                ref={cardRef}
                onMouseMove={handleMouseMove}
                onMouseEnter={handleMouseEnter}
                onMouseLeave={handleMouseLeave}
                onTouchStart={requestGyro}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleMouseLeave}
                onClick={handleCardClick}
                className={`relative w-full max-w-[270px] sm:max-w-[300px] aspect-[1/1.48] rounded-[2rem] sm:rounded-[2.2rem] overflow-hidden shadow-2xl transition-transform duration-75 select-none ${theme.faceGradient} border-0 flex flex-col justify-between cursor-pointer active:scale-[0.99]`}
                style={{
                  perspective: '1200px',
                  transform: `perspective(1200px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`,
                  transformStyle: 'preserve-3d',
                  boxShadow: `0 30px 70px rgba(0,0,0,0.95), 0 0 ${isLegendary ? '45px' : '28px'} ${cardAccent}${isLegendary ? '88' : '45'}`,
                }}
              >
                {/* Tactile Click Shine Wave (Never navigates) */}
                {clickShine && (
                  <div
                    className="absolute inset-0 z-40 pointer-events-none rounded-[inherit] transition-opacity duration-300 animate-pulse"
                    style={{
                      background: `radial-gradient(circle at ${glarePos.x}% ${glarePos.y}%, rgba(255,255,255,0.45) 0%, ${cardAccent}55 40%, transparent 70%)`,
                      mixBlendMode: 'screen',
                    }}
                  />
                )}
                {/* Card Ambient Backlight Aura */}
                <div
                  className="absolute inset-0 rounded-[2.2rem] opacity-50 blur-2xl pointer-events-none -z-10"
                  style={{
                    background: `radial-gradient(circle at ${glarePos.x}% ${glarePos.y}%, ${cardAccent}70, transparent 70%)`
                  }}
                />

                {/* Top Metallic Bevel Highlight */}
                <div
                  className="absolute top-0 inset-x-0 h-[2px] pointer-events-none z-30"
                  style={{
                    background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.95) 50%, transparent 100%)',
                    boxShadow: '0 0 14px rgba(255,255,255,0.7)'
                  }}
                />

                {/* Specular Glare */}
                <div
                  className="absolute inset-0 pointer-events-none z-25 mix-blend-overlay"
                  style={{
                    background: `radial-gradient(circle at ${glarePos.x}% ${glarePos.y}%, rgba(255,255,255,0.7) 0%, transparent 60%)`
                  }}
                />

                {/* Foil Finish Layer */}
                <CardFoilOverlay
                  rarity={card.rarity}
                  foilStyle={card.foilStyle}
                  foilColor={card.foilColor}
                  holographicBehavior={card.holographicBehavior}
                  foilIntensity={card.foilIntensity}
                  foilOpacity={card.foilOpacity}
                  reflectionStrength={card.reflectionStrength}
                  reflectionSpeed={card.reflectionSpeed}
                  reflectionWidth={card.reflectionWidth}
                  reflectionAngle={card.reflectionAngle}
                  surfaceShine={card.surfaceShine}
                  metallicStrength={card.metallicStrength}
                  edgeReflection={card.edgeReflection}
                  iridescence={card.iridescence}
                  isHovered={isHovered}
                  glareX={glarePos.x}
                  glareY={glarePos.y}
                  cardAccent={cardAccent}
                />

                {/* Dynamic Rarity Border Elements */}
                <CardBorderElements
                  rarity={card.rarity}
                  accentColor={cardAccent}
                  borderColor={card.borderColor}
                  glowColor={card.glowColor}
                  frameStyle={card.frameStyle}
                  isHovered={isHovered}
                />

                {/* Full-Height Background Artwork Canvas */}
                <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none rounded-[inherit]">
                  <img
                    src={card.imageUrl}
                    alt={card.name}
                    className="w-full h-full object-cover object-center filter brightness-100 contrast-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/25 to-transparent pointer-events-none" />
                </div>

                {/* Upper-Right Sovereign Rating Number (Pure number, fully customizable size and position) */}
                <div
                  className="absolute z-35 select-none font-display font-black leading-none tracking-tight flex items-center justify-center pointer-events-none"
                  style={{
                    top: `${typeof card.ratingOffsetY === 'number' ? card.ratingOffsetY : (globalRatingSettings?.offsetY ?? 14)}px`,
                    right: `${typeof card.ratingOffsetX === 'number' ? card.ratingOffsetX : (globalRatingSettings?.offsetX ?? 16)}px`,
                    fontSize: `${typeof card.ratingFontSize === 'number' ? card.ratingFontSize : (globalRatingSettings?.fontSize || 24)}px`,
                    color: card.nameColor || cardAccent || '#f59e0b',
                    textShadow: `0 0 16px ${cardAccent}99, 0 2px 6px rgba(0,0,0,0.95)`,
                    transform: 'translateZ(24px)',
                  }}
                >
                  <span className="tabular-nums drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]">
                    {displayOvr}
                  </span>
                </div>

                {/* Top Floating Bar: Card # */}
                <div
                  className="relative z-20 p-4 pb-2 flex items-center justify-between"
                  style={{ transform: 'translateZ(14px)' }}
                >
                  <span className="text-[10px] font-mono tracking-widest text-slate-300 font-bold px-2.5 py-0.5 rounded-lg bg-black/60 border border-white/10 backdrop-blur-md">
                    #{String(card.cardNumber).padStart(3, '0')}
                  </span>

                  {card.cardType && (
                    <span className="text-[9px] font-mono uppercase tracking-wider text-slate-400 px-2 py-0.5 rounded-lg bg-black/40 border border-white/5 backdrop-blur-md me-10">
                      {card.cardType}
                    </span>
                  )}
                </div>

                {/* Middle Spacer */}
                <div className="relative z-10 flex-1 min-h-[170px]" />

                {/* Bottom Card Face: Enhanced Owner Cards Style */}
                <div
                  className="relative z-20 pt-4 pb-4 px-4 sm:px-5 bg-gradient-to-t from-slate-950 via-slate-950/92 to-transparent border-t border-white/[0.04] backdrop-blur-[2px]"
                  style={{
                    transform: 'translateZ(18px)',
                  }}
                >
                  {/* Card Display Name with Royal Glowing Typography */}
                  <div className="text-center mb-1">
                    <h4
                      className="font-display font-black text-base sm:text-lg md:text-xl tracking-wide break-words max-w-full leading-snug drop-shadow-[0_2px_10px_rgba(0,0,0,0.85)] transition-colors duration-200"
                      style={{
                        color: cardNameColor,
                        textShadow: `0 0 16px ${cardNameColor}66, 0 2px 6px rgba(0,0,0,0.95)`,
                      }}
                    >
                      {card.name}
                    </h4>
                  </div>

                  {/* Clean Royal Hairline Divider */}
                  <div
                    className="my-1.5 mx-auto w-2/3 h-[1px] pointer-events-none opacity-60"
                    style={{
                      background: `linear-gradient(90deg, transparent 0%, ${cardAccent} 50%, transparent 100%)`,
                    }}
                  />

                  {/* Subtitle & Narrative Bio */}
                  {(card.title || card.lore || card.description) && (
                    <div className="space-y-0.5 mb-2.5 text-center">
                      {card.title && (
                        <p className="font-sans text-[10px] sm:text-[11px] font-medium text-amber-200/90 tracking-wide uppercase line-clamp-1">
                          {card.title}
                        </p>
                      )}
                      {(card.lore || card.description) && (
                        <p className="font-sans text-slate-300/85 leading-relaxed font-normal text-[10.5px] sm:text-[11px] px-1 drop-shadow-sm line-clamp-2">
                          {card.lore || card.description}
                        </p>
                      )}
                    </div>
                  )}

                  {/* Bottom Bar: Unified Stats HUD (Clean, No OVR) */}
                  <div className="pt-2 border-t border-white/[0.08] flex items-center justify-between text-xs text-slate-400">
                    <div className="flex items-center gap-1.5 sm:gap-2 font-mono flex-wrap">
                      {primaryStats.map((st, idx) => (
                        <React.Fragment key={st.id}>
                          {idx > 0 && <span className="text-white/20">·</span>}
                          <span
                            className="text-[10px] sm:text-[11px] font-bold flex items-center gap-1"
                            style={{ color: st.color || '#38bdf8' }}
                          >
                            <span className="truncate max-w-[40px] uppercase">{st.name.slice(0, 3)}</span>
                            <span className="tabular-nums font-black">{st.value}</span>
                          </span>
                        </React.Fragment>
                      ))}
                    </div>

                    {theme.romanNumeral && (
                      <span className="font-serif font-bold text-sm sm:text-base text-white/30 select-none pointer-events-none tracking-widest ms-auto shrink-0">
                        {theme.romanNumeral}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="w-full flex items-center justify-between text-[11px] text-stone-400 font-mono px-1 flex-wrap gap-2">
                <span className="flex items-center gap-1">
                  <Sparkles size={11} className="text-[#5eead4]" /> Click & tilt freely {clickCount > 0 ? `(${clickCount}×)` : ''}
                </span>
                
                <div className="flex items-center gap-2">
                  {isOwner && onEditInStudio && (
                    <button
                      type="button"
                      onClick={handleOpenStudio}
                      className="text-amber-300 hover:text-amber-100 flex items-center gap-1 cursor-pointer font-bold transition-colors"
                    >
                      <Edit size={11} />
                      <span>Studio</span>
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* ------------------------------------------------------------- */}
            {/* RIGHT: READ-ONLY SHOWCASE DOSSIER (LORE, STATS, ABILITIES)     */}
            {/* ------------------------------------------------------------- */}
            <div className="flex-1 min-h-0 flex flex-col justify-between space-y-4">
              <div className="space-y-3.5">
                {/* Top Badge Ribbon */}
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-2.5 py-1 rounded-xl text-[10px] font-mono uppercase bg-slate-900 text-slate-300 border border-slate-700">
                      {card.series}
                    </span>
                    {card.cardType && (
                      <span className="px-2.5 py-1 rounded-xl text-[10px] font-mono uppercase bg-amber-950/60 text-amber-200 border border-amber-500/30 font-bold">
                        {card.cardType}
                      </span>
                    )}
                    <span className="px-2.5 py-1 rounded-xl text-[10px] font-bold uppercase bg-stone-900 text-cyan-300 border border-cyan-500/30">
                      {card.element}
                    </span>
                  </div>

                  {/* Master OVR Crest */}
                  <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-gradient-to-r from-amber-500/20 via-yellow-500/25 to-amber-500/20 border border-amber-500/50 shadow-md">
                    <Zap size={14} className="text-amber-400 fill-amber-400/50" />
                    <span className="text-xs font-mono font-bold text-stone-300">OVR</span>
                    <span className="text-base font-black font-mono text-amber-200">{displayOvr}</span>
                  </div>
                </div>

                {/* Card Title & Epithet */}
                <div>
                  <h3
                    className="text-2xl sm:text-3xl font-black font-display tracking-wide"
                    style={{ color: cardNameColor }}
                  >
                    {card.name}
                  </h3>
                  {card.title && (
                    <p className="text-xs sm:text-sm text-stone-300 font-medium italic mt-0.5">
                      {card.title}
                    </p>
                  )}
                </div>

                {/* Profile Navigation Tabs (Simple, Clean, Minimal) */}
                <div className="flex items-center gap-1.5 pb-2 border-b border-white/10 overflow-x-auto studio-scrollbar">
                  <button
                    type="button"
                    onClick={() => setActiveTab('stats')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-serif font-bold uppercase transition-colors cursor-pointer flex items-center gap-1.5 ${
                      activeTab === 'stats'
                        ? 'bg-amber-500 text-stone-950 shadow-sm font-black'
                        : 'text-stone-400 hover:text-white bg-black/40'
                    }`}
                  >
                    <Zap size={13} />
                    <span>Stats ({unifiedStats.length})</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('lore')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-serif font-bold uppercase transition-colors cursor-pointer flex items-center gap-1.5 ${
                      activeTab === 'lore'
                        ? 'bg-amber-500 text-stone-950 shadow-sm font-black'
                        : 'text-stone-400 hover:text-white bg-black/40'
                    }`}
                  >
                    <BookOpen size={13} />
                    <span>Lore</span>
                  </button>

                  {Array.isArray(card.abilities) && card.abilities.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setActiveTab('abilities')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-serif font-bold uppercase transition-colors cursor-pointer flex items-center gap-1.5 ${
                        activeTab === 'abilities'
                          ? 'bg-amber-500 text-stone-950 shadow-sm font-black'
                          : 'text-stone-400 hover:text-white bg-black/40'
                      }`}
                    >
                      <Shield size={13} />
                      <span>Abilities ({card.abilities.length})</span>
                    </button>
                  )}

                  {ownership && (ownership.count || 0) > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        setActiveTab('upgrade');
                        setUpgradeError(null);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-serif font-bold uppercase transition-colors cursor-pointer flex items-center gap-1.5 ${
                        activeTab === 'upgrade'
                          ? 'bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-stone-950 shadow-md font-black'
                          : 'text-amber-300 hover:text-white bg-amber-950/40 border border-amber-500/30'
                      }`}
                    >
                      <Sparkles size={13} className="text-amber-400" />
                      <span>Ascend Tier</span>
                    </button>
                  )}

                  {card.revealVideoUrl && (
                    <button
                      type="button"
                      onClick={() => setActiveTab('video')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-serif font-bold uppercase transition-colors cursor-pointer flex items-center gap-1.5 ${
                        activeTab === 'video'
                          ? 'bg-cyan-500 text-stone-950 shadow-sm font-black'
                          : 'text-cyan-300 hover:text-white bg-cyan-950/40'
                      }`}
                    >
                      <Film size={13} />
                      <span>Cinematic</span>
                    </button>
                  )}
                </div>

                {/* TAB: UPGRADE CARD (ASCENSION) */}
                {activeTab === 'upgrade' && (
                  <div className="space-y-3 max-h-[42vh] overflow-y-auto studio-scrollbar pr-1 text-xs">
                    {/* 1. Rarity Progression Header */}
                    <div className="p-3.5 rounded-2xl bg-black/60 border border-amber-500/30 flex items-center justify-between gap-3 shadow-inner">
                      <div className="flex items-center gap-2">
                        <span className={`px-2.5 py-1 rounded-xl text-xs font-mono font-black uppercase ${
                          RARITY_THEMES[effectiveRarity]?.badge || 'bg-slate-800 text-white'
                        }`}>
                          {effectiveRarity}
                        </span>
                        {!isMaxRarity && (
                          <>
                            <ArrowRight size={14} className="text-amber-400 animate-pulse" />
                            <span className={`px-2.5 py-1 rounded-xl text-xs font-mono font-black uppercase ${
                              nextRarity ? (RARITY_THEMES[nextRarity]?.badge || 'bg-amber-500 text-slate-950') : ''
                            }`}>
                              {nextRarity}
                            </span>
                          </>
                        )}
                      </div>

                      {isMaxRarity ? (
                        <div className="flex items-center gap-1.5 text-amber-300 font-mono font-bold text-[11px]">
                          <Trophy size={14} className="text-yellow-400" />
                          <span>MAX RARITY REACHED</span>
                        </div>
                      ) : (
                        <div className="text-[11px] font-mono text-emerald-400 font-bold bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-lg">
                          +{Math.round(((upgradeRule?.statMultiplier || 1.2) - 1) * 100)}% Power Boost
                        </div>
                      )}
                    </div>

                    {isMaxRarity ? (
                      <div className="p-6 rounded-2xl bg-gradient-to-b from-amber-950/40 via-yellow-950/20 to-black border border-amber-500/40 text-center space-y-2">
                        <div className="w-12 h-12 rounded-2xl bg-amber-400/20 border border-amber-400/50 mx-auto flex items-center justify-center text-amber-300 shadow-[0_0_20px_rgba(245,158,11,0.4)]">
                          <Crown size={24} />
                        </div>
                        <h4 className="font-display font-black text-amber-200 text-base">Pinnacle Ascension Achieved</h4>
                        <p className="text-stone-300 text-xs leading-relaxed max-w-sm mx-auto">
                          This relic has attained sovereign power. It cannot be upgraded further and commands supreme status on the battlefield.
                        </p>
                      </div>
                    ) : (
                      <>
                        {/* 2. Required Shard Presentation using BrawlStarsItemDisplay */}
                        <div className="p-3.5 rounded-2xl bg-black/50 border border-white/10 space-y-2">
                          <div className="flex items-center justify-between text-xs font-mono">
                            <span className="text-stone-300 font-bold flex items-center gap-1.5">
                              <Sparkles size={13} className="text-amber-400" />
                              <span>Required Ascension Shard</span>
                            </span>
                            <span className={`font-black ${hasEnoughShards ? 'text-emerald-400' : 'text-rose-400'}`}>
                              Owned: {totalUsableShards} / {requiredCount}
                            </span>
                          </div>

                          <div className="flex items-center gap-3 pt-1">
                            <BrawlStarsItemDisplay
                              item={requiredShardItem}
                              count={primaryShardCount}
                              size="compact"
                              isHoverable={false}
                              showDetails={false}
                            />

                            <div className="flex-1 space-y-2 text-xs">
                              <div className="p-2 rounded-xl bg-slate-900/80 border border-white/5 space-y-1">
                                <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wide">Success Rate</div>
                                <div className="flex items-center gap-2">
                                  <div className="flex-1 h-2 rounded-full bg-slate-950 border border-white/10 overflow-hidden">
                                    <div
                                      className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full"
                                      style={{ width: `${upgradeRule?.successRatePercent || 50}%` }}
                                    />
                                  </div>
                                  <span className="font-mono font-black text-emerald-300 text-xs">
                                    {upgradeRule?.successRatePercent || 50}%
                                  </span>
                                </div>
                              </div>

                              <div className="p-2 rounded-xl bg-slate-900/80 border border-white/5 text-[10.5px] font-mono text-stone-300 space-y-0.5">
                                <div className="text-amber-300 font-bold">Consequence on Failure:</div>
                                <div className="text-stone-400 text-[10px]">
                                  {upgradeRule?.consumeShardsOnFailure
                                    ? '• Shards consumed. Card remains 100% safe.'
                                    : '• Shards preserved on failure. Card safe.'}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* 3. Projected Stat Elevation */}
                        <div className="p-3 rounded-2xl bg-black/50 border border-white/10 space-y-1.5">
                          <span className="text-[10px] font-mono uppercase text-amber-300 font-bold block">
                            Projected Combat Upgrades upon Success
                          </span>
                          <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono">
                            <div className="p-2 rounded-xl bg-slate-900 border border-white/5">
                              <div className="text-[10px] text-slate-400">ATK</div>
                              <div className="text-rose-400 font-black">+{upgradeRule?.flatAttackBoost || 10}</div>
                            </div>
                            <div className="p-2 rounded-xl bg-slate-900 border border-white/5">
                              <div className="text-[10px] text-slate-400">DEF</div>
                              <div className="text-cyan-400 font-black">+{upgradeRule?.flatDefenseBoost || 8}</div>
                            </div>
                            <div className="p-2 rounded-xl bg-slate-900 border border-white/5">
                              <div className="text-[10px] text-slate-400">HP</div>
                              <div className="text-emerald-400 font-black">+{upgradeRule?.flatHpBoost || 12}</div>
                            </div>
                          </div>
                        </div>

                        {/* Outcome & Error Feedback */}
                        {upgradeOutcome && (
                          <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className={`p-3 rounded-2xl border text-xs font-mono font-bold ${
                              upgradeOutcome.success
                                ? 'bg-emerald-950/80 border-emerald-500/60 text-emerald-200'
                                : 'bg-rose-950/80 border-rose-500/60 text-rose-200'
                            }`}
                          >
                            <div className="flex items-center gap-1.5 mb-0.5">
                              {upgradeOutcome.success ? <Check size={14} /> : <AlertTriangle size={14} />}
                              <span>{upgradeOutcome.success ? 'ASCENSION SUCCESSFUL!' : 'UPGRADE ATTEMPT FAILED'}</span>
                            </div>
                            <p className="text-[11px] font-normal leading-relaxed text-stone-200">
                              {upgradeOutcome.message}
                            </p>
                          </motion.div>
                        )}

                        {upgradeError && (
                          <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs font-mono">
                            {upgradeError}
                          </div>
                        )}

                        {/* 4. Action Button */}
                        <div className="pt-1">
                          <button
                            type="button"
                            disabled={isUpgrading || !hasEnoughShards}
                            onClick={handleUpgradeAttempt}
                            className={`w-full py-2.5 rounded-xl font-serif font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer ${
                              hasEnoughShards && !isUpgrading
                                ? 'bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-stone-950 hover:brightness-110 active:scale-95 shadow-amber-500/25'
                                : 'bg-slate-800 text-slate-500 border border-white/5 cursor-not-allowed'
                            }`}
                          >
                            <Sparkles size={14} className={isUpgrading ? 'animate-spin' : ''} />
                            <span>
                              {isUpgrading
                                ? 'Synthesizing Relic...'
                                : hasEnoughShards
                                ? `Ascend to ${nextRarity}`
                                : `Need ${requiredCount}x ${requiredShardItem.name}`}
                            </span>
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                )}

                {/* TAB 1: UNIFIED STATS */}
                {activeTab === 'stats' && (
                  <div className="space-y-3 max-h-[38vh] overflow-y-auto studio-scrollbar pr-1">
                    <div className="p-3.5 rounded-2xl bg-black/50 border border-white/10 space-y-2.5">
                      <div className="flex items-center justify-between text-xs font-mono font-bold text-amber-200">
                        <span className="flex items-center gap-1.5">
                          <Flame size={13} className="text-amber-400" />
                          <span>Combat Attributes</span>
                        </span>
                        <span className="text-amber-400">OVR {displayOvr}</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                        {unifiedStats.map(stat => (
                          <div
                            key={stat.id}
                            className="p-2.5 rounded-xl bg-slate-900/70 border border-white/5 space-y-1.5 transition-colors hover:border-white/15"
                          >
                            <div className="flex justify-between items-center text-[11px] font-mono">
                              <span className="text-slate-300 font-semibold">{stat.name}</span>
                              <span
                                className="font-bold font-mono"
                                style={{ color: stat.color || '#f59e0b' }}
                              >
                                {stat.value} / {stat.maxValue || 100}
                              </span>
                            </div>
                            <div className="w-full bg-stone-900 rounded-full h-1.5 overflow-hidden">
                              <div
                                className="h-1.5 rounded-full transition-all duration-500"
                                style={{
                                  backgroundColor: stat.color || '#f59e0b',
                                  width: `${Math.min(100, Math.round(((stat.value || 0) / (stat.maxValue || 100)) * 100))}%`
                                }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB 2: CHRONICLE LORE & STORY */}
                {activeTab === 'lore' && (
                  <div className="space-y-3 max-h-[38vh] overflow-y-auto studio-scrollbar pr-1 text-xs">
                    {card.description && (
                      <div className="p-3.5 rounded-2xl bg-black/50 border border-white/10 space-y-1.5">
                        <span className="text-[10px] font-mono uppercase text-amber-300 font-bold block">
                          Overview
                        </span>
                        <p className="text-stone-300 leading-relaxed font-sans">
                          {card.description}
                        </p>
                      </div>
                    )}

                    {card.lore ? (
                      <div className="p-3.5 rounded-2xl bg-black/50 border border-white/10 space-y-1.5">
                        <span className="text-[10px] font-mono uppercase text-amber-300 font-bold block">
                          Chronicle Inscription
                        </span>
                        <p className="text-amber-100/90 leading-relaxed font-serif italic text-[12.5px] border-s-2 border-amber-500/50 ps-3">
                          "{card.lore}"
                        </p>
                      </div>
                    ) : (
                      <div className="p-4 text-center text-stone-500 text-xs italic">
                        No chronicle inscription recorded for this relic.
                      </div>
                    )}
                  </div>
                )}

                {/* TAB 3: ABILITIES */}
                {activeTab === 'abilities' && Array.isArray(card.abilities) && (
                  <div className="space-y-2.5 max-h-[38vh] overflow-y-auto studio-scrollbar pr-1">
                    {card.abilities.map(ab => (
                      <div
                        key={ab.id}
                        className="p-3 rounded-2xl bg-black/50 border border-white/10 space-y-1.5"
                      >
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-amber-200 font-serif">{ab.name}</span>
                          <span className="px-2 py-0.5 rounded-md text-[9px] font-mono uppercase bg-amber-950/60 border border-amber-500/30 text-amber-300">
                            {ab.type}
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-300 leading-relaxed">
                          {ab.description}
                        </p>
                      </div>
                    ))}
                  </div>
                )}

                {/* TAB 4: CINEMATIC REVEAL VIDEO */}
                {activeTab === 'video' && card.revealVideoUrl && (
                  <div className="p-3 rounded-2xl bg-black/60 border border-cyan-500/30 space-y-2">
                    <div className="rounded-xl overflow-hidden aspect-video bg-black border border-white/10">
                      <video
                        src={parseUniversalVideoUrl(card.revealVideoUrl)}
                        controls
                        autoPlay
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Action Bar Footer (Simple, Premium, Less Words) */}
              <div className="flex items-center justify-between gap-3 pt-3 border-t border-white/10 flex-wrap">
                <div className="flex items-center gap-2 text-xs font-mono text-stone-400">
                  <Layers size={14} className="text-amber-400" />
                  <span>Copies: <strong className="text-white">{ownership ? ownership.count : 0}</strong></span>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {/* Prominent Edit in Card Studio button for owners */}
                  {isOwner && onEditInStudio && (
                    <button
                      type="button"
                      onClick={handleOpenStudio}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:brightness-110 text-stone-950 font-serif font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md shadow-amber-950/60 cursor-pointer transition-all active:scale-95"
                    >
                      <Edit size={13} />
                      <span>Edit in Card Studio</span>
                      <ArrowUpRight size={13} />
                    </button>
                  )}

                  {isLegendary && (
                    <button
                      type="button"
                      onClick={() => setIsAudioModalOpen(true)}
                      className="py-2 px-3.5 rounded-xl font-serif font-black text-xs uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer bg-gradient-to-r from-amber-500/25 via-yellow-500/20 to-amber-600/25 text-amber-300 border border-amber-400/50 hover:bg-amber-500/35 shadow-[0_0_14px_rgba(245,158,11,0.25)] active:scale-95"
                      title="Customize Battle Action Sounds"
                    >
                      <Music size={13} className="text-amber-400" />
                      <span>Battle SFX</span>
                    </button>
                  )}

                  {ownership && (
                    <button
                      type="button"
                      onClick={() => toggleShowcase(card.id)}
                      className={`py-2 px-3 rounded-xl font-serif font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer ${
                        isShowcased
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                          : 'bg-slate-900 text-slate-300 border border-white/10 hover:bg-slate-800'
                      }`}
                    >
                      <Star size={13} className={isShowcased ? 'fill-current text-amber-400' : ''} />
                      <span>{isShowcased ? 'Pinned' : 'Pin to Showcase'}</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={handleShare}
                    className="py-2 px-3 rounded-xl font-mono text-xs text-slate-300 bg-slate-900 hover:bg-slate-800 border border-white/10 flex items-center gap-1.5 transition-colors cursor-pointer"
                    title="Copy Card Link"
                  >
                    {isCopied ? <Check size={13} className="text-emerald-400" /> : <Share2 size={13} />}
                    <span>{isCopied ? 'Copied' : 'Share'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Customizable Legendary Battle Sound Effects Modal */}
        {isAudioModalOpen && (
          <LegendaryCombatAudioModal
            isOpen={isAudioModalOpen}
            onClose={() => setIsAudioModalOpen(false)}
            targetCard={card}
            legendaryCards={allCards?.filter(c => c.rarity === 'LEGENDARY') || []}
          />
        )}
      </div>
    </AnimatePresence>
  );
};
