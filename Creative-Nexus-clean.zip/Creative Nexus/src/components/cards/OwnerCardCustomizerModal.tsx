import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CollectibleCardData,
  CardFrameStyle,
  CardCornerStyle,
  CardGlowIntensity,
  CardFoilStyle,
  CardBackgroundTheme,
  HolographicBehavior,
  FoilIntensity,
} from '../../types/cards';
import { useCards } from '../../context/CardContext';
import { useAuth } from '../../context/AuthContext';
import { CollectibleCard } from './CollectibleCard';
import { getRarityMaterialConfig } from '../../config/cardMaterialConfig';
import { LegendaryCombatAudioSection } from './LegendaryCombatAudioSection';
import {
  X, Sparkles, Check, RotateCcw, Palette, Layers,
  Sliders, Shield, Zap, Swords, Heart, Crown, Eye, Lock, Music
} from 'lucide-react';

interface OwnerCardCustomizerModalProps {
  card: CollectibleCardData | null;
  isOpen: boolean;
  onClose: () => void;
}

const LUXURY_PALETTES = [
  { name: 'Imperial Gold', hex: '#f59e0b', ring: 'ring-amber-500' },
  { name: 'Sovereign Solar', hex: '#d97706', ring: 'ring-amber-600' },
  { name: 'Cosmic Amethyst', hex: '#a855f7', ring: 'ring-purple-500' },
  { name: 'Astral Magenta', hex: '#d946ef', ring: 'ring-fuchsia-500' },
  { name: 'Lapis Azure', hex: '#06b6d4', ring: 'ring-cyan-500' },
  { name: 'Sapphire Chrono', hex: '#3b82f6', ring: 'ring-blue-500' },
  { name: 'Emerald Jade', hex: '#10b981', ring: 'ring-emerald-500' },
  { name: 'Verdigris Forest', hex: '#059669', ring: 'ring-emerald-600' },
  { name: 'Blood Crimson', hex: '#ef4444', ring: 'ring-rose-500' },
  { name: 'Rose Gold', hex: '#fb7185', ring: 'ring-rose-400' },
  { name: 'Cyber Neon', hex: '#22d3ee', ring: 'ring-cyan-400' },
  { name: 'Obsidian Slate', hex: '#64748b', ring: 'ring-slate-500' },
];

export const OwnerCardCustomizerModal: React.FC<OwnerCardCustomizerModalProps> = ({
  card,
  isOpen,
  onClose,
}) => {
  const { isOwner } = useAuth();
  const { ownerSaveCard } = useCards();

  const [activeTab, setActiveTab] = useState<'colors' | 'frame' | 'foil' | 'text' | 'stats' | 'sfx'>('colors');
  const [isSaving, setIsSaving] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Editable Card Appearance State
  const [borderColor, setBorderColor] = useState('#f59e0b');
  const [glowColor, setGlowColor] = useState('#f59e0b');
  const [glowIntensity, setGlowIntensity] = useState<CardGlowIntensity>('radiant');
  const [frameStyle, setFrameStyle] = useState<CardFrameStyle>('auto');
  const [cornerStyle, setCornerStyle] = useState<CardCornerStyle>('auto');
  const [foilStyle, setFoilStyle] = useState<CardFoilStyle>('standard');
  const [foilColor, setFoilColor] = useState('#f59e0b');
  const [foilIntensity, setFoilIntensity] = useState<FoilIntensity>('medium');
  const [holographicBehavior, setHolographicBehavior] = useState<HolographicBehavior>('diagonal_sweep');
  const [reflectionSpeed, setReflectionSpeed] = useState<number>(1.0);
  const [backgroundTheme, setBackgroundTheme] = useState<CardBackgroundTheme>('auto');

  // Editable Text Attributes
  const [name, setName] = useState('');
  const [title, setTitle] = useState('');
  const [series, setSeries] = useState('');
  const [lore, setLore] = useState('');
  const [description, setDescription] = useState('');

  // Editable Combat Stats
  const [attack, setAttack] = useState(75);
  const [defense, setDefense] = useState(70);
  const [hp, setHp] = useState(80);

  // Initialize from card
  useEffect(() => {
    if (card) {
      const isLeg = card.rarity === 'LEGENDARY';
      const rMat = getRarityMaterialConfig(card.rarity);
      const defaultColor = isLeg
        ? (card.borderColor || card.accentColor || '#f59e0b')
        : rMat.primaryColor;

      setBorderColor(defaultColor);
      setGlowColor(isLeg ? (card.glowColor || defaultColor) : rMat.primaryColor);
      setGlowIntensity(card.glowIntensity || (isLeg ? 'blazing' : 'radiant'));
      setFrameStyle(card.frameStyle || 'auto');
      setCornerStyle(card.cornerStyle || 'auto');
      setFoilStyle(card.foilStyle || 'standard');
      setFoilColor(isLeg ? (card.foilColor || defaultColor) : rMat.primaryColor);
      setFoilIntensity(card.foilIntensity || 'medium');
      setHolographicBehavior(card.holographicBehavior || 'diagonal_sweep');
      setReflectionSpeed(card.reflectionSpeed || 1.0);
      setBackgroundTheme(card.backgroundTheme || 'auto');

      setName(card.name || '');
      setTitle(card.title || '');
      setSeries(card.series || '');
      setLore(card.lore || '');
      setDescription(card.description || '');

      setAttack(card.attack > 100 ? Math.round(card.attack / 10) : card.attack || 75);
      setDefense(card.defense > 100 ? Math.round(card.defense / 10) : card.defense || 70);
      setHp(card.hp > 100 ? Math.round(card.hp / 10) : card.hp || 80);
      setFeedback(null);
    }
  }, [card, isOpen]);

  const isLegendary = card?.rarity === 'LEGENDARY';
  const rarityMaterial = getRarityMaterialConfig(card?.rarity);
  const effectiveBorderColor = isLegendary ? borderColor : rarityMaterial.primaryColor;
  const effectiveGlowColor = isLegendary ? glowColor : rarityMaterial.primaryColor;
  const effectiveFoilColor = isLegendary ? foilColor : rarityMaterial.primaryColor;

  // Real-time live card preview object
  const previewCard: CollectibleCardData | null = useMemo(() => {
    if (!card) return null;
    return {
      ...card,
      name: name || card.name,
      title: title || card.title,
      series: series || card.series,
      lore: lore || card.lore,
      description: description || card.description,
      borderColor: effectiveBorderColor,
      accentColor: effectiveBorderColor,
      glowColor: effectiveGlowColor,
      glowIntensity,
      frameStyle,
      cornerStyle,
      foilStyle,
      foilColor: effectiveFoilColor,
      foilIntensity,
      holographicBehavior,
      reflectionSpeed,
      backgroundTheme,
      attack,
      defense,
      hp,
    };
  }, [
    card,
    name,
    title,
    series,
    lore,
    description,
    effectiveBorderColor,
    effectiveGlowColor,
    glowIntensity,
    frameStyle,
    cornerStyle,
    foilStyle,
    effectiveFoilColor,
    foilIntensity,
    holographicBehavior,
    reflectionSpeed,
    backgroundTheme,
    attack,
    defense,
    hp,
  ]);

  if (!isOpen || !card || !isOwner || !previewCard) return null;

  const handleSaveCustomization = async () => {
    setIsSaving(true);
    setFeedback(null);
    try {
      await ownerSaveCard({
        ...card,
        name: name.trim() || card.name,
        title: title.trim() || card.title,
        series: series.trim() || card.series,
        lore: lore.trim() || card.lore,
        description: description.trim() || card.description,
        borderColor: effectiveBorderColor,
        accentColor: effectiveBorderColor,
        glowColor: effectiveGlowColor,
        glowIntensity,
        frameStyle: frameStyle === 'auto' ? undefined : frameStyle,
        cornerStyle: cornerStyle === 'auto' ? undefined : cornerStyle,
        foilStyle,
        foilColor: effectiveFoilColor,
        foilIntensity,
        holographicBehavior,
        reflectionSpeed,
        backgroundTheme: backgroundTheme === 'auto' ? undefined : backgroundTheme,
        attack,
        defense,
        hp,
      });

      setFeedback('✨ Card styling saved & synchronized live!');
      setTimeout(() => {
        setFeedback(null);
        onClose();
      }, 1200);
    } catch (err: any) {
      setFeedback(`Error: ${err.message || 'Failed to save styling'}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetDefaults = () => {
    const isLeg = card?.rarity === 'LEGENDARY';
    const rMat = getRarityMaterialConfig(card?.rarity);
    if (isLeg) {
      setBorderColor(card?.accentColor || '#f59e0b');
      setGlowColor(card?.accentColor || '#f59e0b');
      setFoilColor(card?.accentColor || '#f59e0b');
    } else {
      setBorderColor(rMat.primaryColor);
      setGlowColor(rMat.primaryColor);
      setFoilColor(rMat.primaryColor);
    }
    setGlowIntensity('radiant');
    setFrameStyle('auto');
    setCornerStyle('auto');
    setFoilStyle('standard');
    setBackgroundTheme('auto');
  };

  return (
    <AnimatePresence>
      <div
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 md:p-6 bg-black/92 backdrop-blur-2xl overflow-y-auto"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 15 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-5xl bg-[#031513] border border-[rgba(158,255,230,0.22)] rounded-3xl p-4 sm:p-6 shadow-2xl shadow-black overflow-hidden my-auto max-h-[94vh] flex flex-col box-border"
        >
          {/* Top Hairline Metallic Bevel */}
          <div
            className="absolute top-0 inset-x-0 h-[2px] pointer-events-none"
            style={{
              background: `linear-gradient(90deg, transparent 0%, ${effectiveBorderColor} 50%, transparent 100%)`,
              boxShadow: `0 0 12px ${effectiveBorderColor}`
            }}
          />

          {/* Modal Header */}
          <div className="flex items-center justify-between pb-3.5 border-b border-white/10 shrink-0 gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className="w-10 h-10 rounded-2xl border flex items-center justify-center shadow-lg shrink-0"
                style={{
                  background: `radial-gradient(circle, ${effectiveBorderColor}30, #000)`,
                  borderColor: `${effectiveBorderColor}60`,
                  color: effectiveBorderColor
                }}
              >
                <Palette size={20} />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono tracking-widest text-[#5eead4] uppercase font-bold">
                    OWNER CUSTOMIZATION STUDIO
                  </span>
                </div>
                <h2 className="text-base sm:text-lg font-black font-serif text-amber-100 truncate">
                  Customize Card Appearance: {card.name}
                </h2>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleResetDefaults}
                className="px-2.5 py-1.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-400 hover:text-stone-200 text-xs font-mono border border-white/10 flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Reset to default card colors"
              >
                <RotateCcw size={12} />
                <span className="hidden sm:inline">Reset</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                aria-label="Close"
                className="p-1.5 rounded-xl text-stone-400 hover:text-white bg-black/40 hover:bg-black border border-white/10 transition-colors cursor-pointer"
              >
                <X size={17} />
              </button>
            </div>
          </div>

          {/* Feedback banner */}
          {feedback && (
            <div
              className={`my-2 p-2.5 rounded-xl text-xs flex items-center gap-2 shrink-0 ${
                feedback.startsWith('Error')
                  ? 'bg-rose-950/80 border border-rose-500/40 text-rose-200'
                  : 'bg-emerald-950/80 border border-emerald-500/40 text-emerald-200'
              }`}
            >
              <Sparkles size={14} />
              <span>{feedback}</span>
            </div>
          )}

          {/* Main Studio Body: 2 Columns (Left: 3D Live Card, Right: Studio Controls) */}
          <div className="flex-1 min-h-0 overflow-y-auto studio-scrollbar grid grid-cols-1 lg:grid-cols-12 gap-5 pt-3 items-start pr-1 pb-16 lg:pb-24">
            {/* ------------------------------------------------------------------ */}
            {/* LEFT: LIVE INTERACTIVE 3D CARD PREVIEW (5 cols)                    */}
            {/* ------------------------------------------------------------------ */}
            <div className="lg:col-span-5 flex flex-col items-center justify-center p-3 rounded-3xl bg-black/40 border border-white/5 space-y-2 lg:sticky lg:top-0">
              <div className="w-full max-w-[240px] sm:max-w-[270px] lg:max-w-[290px]">
                <CollectibleCard
                  card={previewCard}
                  isOwned={true}
                  duplicateCount={1}
                  size="compact"
                  disableScrollTilt={true}
                />
              </div>
              <p className="text-[10px] text-stone-400 font-mono flex items-center gap-1 text-center">
                <Eye size={11} className="text-[#5eead4] shrink-0" /> Live interactive preview
              </p>
            </div>

            {/* ------------------------------------------------------------------ */}
            {/* RIGHT: STUDIO CONTROLS (7 cols)                                    */}
            {/* ------------------------------------------------------------------ */}
            <div className="lg:col-span-7 flex flex-col space-y-4">
              {/* Studio Tabs */}
              <div className="flex items-center gap-1.5 pb-1 border-b border-white/10 overflow-x-auto shrink-0">
                <button
                  type="button"
                  onClick={() => setActiveTab('colors')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-serif font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                    activeTab === 'colors'
                      ? 'bg-amber-500 text-stone-950 shadow-md'
                      : 'text-stone-400 hover:text-amber-200 bg-stone-900/60'
                  }`}
                >
                  <Palette size={13} />
                  <span>Colors & Glow</span>
                  {!isLegendary && (
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/40 text-stone-300 border border-white/10 flex items-center gap-1">
                      <Lock size={9} />
                      <span>Tier</span>
                    </span>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('frame')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-serif font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                    activeTab === 'frame'
                      ? 'bg-amber-500 text-stone-950 shadow-md'
                      : 'text-stone-400 hover:text-amber-200 bg-stone-900/60'
                  }`}
                >
                  <Crown size={13} />
                  <span>Borders & Corners</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('foil')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-serif font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                    activeTab === 'foil'
                      ? 'bg-amber-500 text-stone-950 shadow-md'
                      : 'text-stone-400 hover:text-amber-200 bg-stone-900/60'
                  }`}
                >
                  <Sparkles size={13} />
                  <span>Foil & Canvas</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('text')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-serif font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                    activeTab === 'text'
                      ? 'bg-amber-500 text-stone-950 shadow-md'
                      : 'text-stone-400 hover:text-amber-200 bg-stone-900/60'
                  }`}
                >
                  <Sliders size={13} />
                  <span>Text & Lore</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('stats')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-serif font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                    activeTab === 'stats'
                      ? 'bg-amber-500 text-stone-950 shadow-md'
                      : 'text-stone-400 hover:text-amber-200 bg-stone-900/60'
                  }`}
                >
                  <Zap size={13} />
                  <span>Combat Stats</span>
                </button>

                {isLegendary && (
                  <button
                    type="button"
                    onClick={() => setActiveTab('sfx')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-serif font-black uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                      activeTab === 'sfx'
                        ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-stone-950 shadow-md font-black shadow-amber-500/30'
                        : 'text-amber-300 hover:text-amber-100 bg-amber-950/40 border border-amber-500/30'
                    }`}
                  >
                    <Music size={13} className="text-amber-400" />
                    <span>Legendary SFX</span>
                  </button>
                )}
              </div>

              {/* TAB 1: COLORS & GLOW */}
              {activeTab === 'colors' && (
                <div className="space-y-4 text-xs">
                  {isLegendary ? (
                    <>
                      {/* Primary Border & Accent Color */}
                      <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2.5">
                        <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                          Primary Frame & Border Color
                        </label>
                        <div className="flex items-center gap-3">
                          <input
                            type="color"
                            value={borderColor}
                            onChange={(e) => {
                              setBorderColor(e.target.value);
                              setGlowColor(e.target.value);
                            }}
                            className="w-10 h-10 rounded-xl bg-transparent border border-white/20 cursor-pointer p-0.5"
                          />
                          <input
                            type="text"
                            value={borderColor}
                            onChange={(e) => setBorderColor(e.target.value)}
                            className="px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 font-mono text-xs grow focus:outline-hidden focus:border-amber-500"
                            placeholder="#f59e0b"
                          />
                        </div>

                        {/* Quick Luxury Color Palette Chips */}
                        <div className="space-y-1.5 pt-1">
                          <span className="text-[10px] text-stone-400 font-mono">Curated Color Palettes:</span>
                          <div className="flex flex-wrap gap-2">
                            {LUXURY_PALETTES.map((pal) => (
                              <button
                                key={pal.name}
                                type="button"
                                onClick={() => {
                                  setBorderColor(pal.hex);
                                  setGlowColor(pal.hex);
                                }}
                                className={`px-2 py-1 rounded-lg text-[10px] font-sans font-medium flex items-center gap-1.5 border transition-all cursor-pointer ${
                                  borderColor.toLowerCase() === pal.hex.toLowerCase()
                                    ? 'bg-white/15 border-white text-white shadow-sm'
                                    : 'bg-stone-950/70 border-white/10 text-stone-300 hover:border-white/30'
                                }`}
                              >
                                <span className="w-2.5 h-2.5 rounded-full shrink-0 shadow-xs" style={{ backgroundColor: pal.hex }} />
                                <span>{pal.name}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Aura & Glow Intensity */}
                      <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2.5">
                        <div className="flex items-center justify-between">
                          <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                            Aura & Ambient Glow Intensity
                          </label>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] text-stone-400 font-mono">Glow Color:</span>
                            <input
                              type="color"
                              value={glowColor}
                              onChange={(e) => setGlowColor(e.target.value)}
                              className="w-6 h-6 rounded-md bg-transparent border border-white/20 cursor-pointer"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                          {(['none', 'subtle', 'radiant', 'blazing', 'celestial'] as CardGlowIntensity[]).map((intensity) => (
                            <button
                              key={intensity}
                              type="button"
                              onClick={() => setGlowIntensity(intensity)}
                              className={`py-2 px-2.5 rounded-xl text-center text-xs font-mono font-bold uppercase transition-all cursor-pointer border ${
                                glowIntensity === intensity
                                  ? 'bg-amber-500/20 text-amber-200 border-amber-400 shadow-md shadow-amber-500/20'
                                  : 'bg-stone-900/60 text-stone-400 border-stone-800 hover:text-stone-200'
                              }`}
                            >
                              {intensity}
                            </button>
                          ))}
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      {/* Non-Legendary Color System: Locked to Rarity Tier */}
                      <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3">
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <Crown size={15} className="text-[#5eead4] shrink-0" />
                            <h4 className="font-serif font-black text-stone-200 text-sm">
                              Color Scheme Decided by Rarity ({card.rarity})
                            </h4>
                          </div>
                          <span className="text-[9px] font-mono uppercase px-2 py-0.5 rounded-md bg-stone-900 border border-white/10 text-stone-400">
                            Locked to Rarity Tier
                          </span>
                        </div>

                        <p className="text-stone-400 text-xs leading-relaxed">
                          Color customization is available for <strong className="text-amber-300 font-serif">Legendary</strong> cards only. All other cards (Epic, Rare, Uncommon, or Common) have their colors, edge specular highlights, and foil reflections strictly decided by their physical rarity material tier.
                        </p>

                        <div className="flex items-center justify-between p-3 rounded-xl bg-stone-950/70 border border-white/10">
                          <div className="flex items-center gap-2.5">
                            <span
                              className="w-5 h-5 rounded-full shrink-0 shadow-xs border border-white/20"
                              style={{ backgroundColor: rarityMaterial.primaryColor }}
                            />
                            <div>
                              <div className="text-xs font-serif font-bold text-stone-200 flex items-center gap-1.5">
                                <span>{rarityMaterial.label} Tier Hue</span>
                                <span className="text-stone-500 text-[10px]">({rarityMaterial.nameAr})</span>
                              </div>
                              <span className="text-[10.5px] font-mono text-stone-400">{rarityMaterial.primaryColor}</span>
                            </div>
                          </div>

                          <div className="text-[10px] font-mono text-stone-400 px-2.5 py-1 rounded-lg bg-stone-900 border border-white/10">
                            Physical Specification
                          </div>
                        </div>
                      </div>

                      {/* Aura & Glow Intensity (Intensity customizable, color locked to rarity) */}
                      <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2.5">
                        <div className="flex items-center justify-between">
                          <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                            Aura & Ambient Glow Intensity
                          </label>
                          <div className="flex items-center gap-1.5 text-[10px] font-mono text-stone-400">
                            <span>Glow Hue:</span>
                            <span
                              className="w-2.5 h-2.5 rounded-full shrink-0 inline-block"
                              style={{ backgroundColor: rarityMaterial.primaryColor }}
                            />
                            <span className="text-stone-300">{rarityMaterial.primaryColor}</span>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                          {(['none', 'subtle', 'radiant', 'blazing', 'celestial'] as CardGlowIntensity[]).map((intensity) => (
                            <button
                              key={intensity}
                              type="button"
                              onClick={() => setGlowIntensity(intensity)}
                              className={`py-2 px-2.5 rounded-xl text-center text-xs font-mono font-bold uppercase transition-all cursor-pointer border ${
                                glowIntensity === intensity
                                  ? 'bg-amber-500/20 text-amber-200 border-amber-400 shadow-md shadow-amber-500/20'
                                  : 'bg-stone-900/60 text-stone-400 border-stone-800 hover:text-stone-200'
                              }`}
                            >
                              {intensity}
                            </button>
                          ))}
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}

              {/* TAB 2: FRAME & CORNERS */}
              {activeTab === 'frame' && (
                <div className="space-y-4 text-xs">
                  {/* Frame Architecture Selector */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                    <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                      Frame Architecture & Centerpiece Arch
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {[
                        { id: 'auto', label: 'Auto (Matches Rarity Tier)', desc: 'Natural rarity frame style' },
                        { id: 'ornate_legendary', label: 'Ornate Gilded Sovereign', desc: 'Double filigree, crown & laurels' },
                        { id: 'crystal_epic', label: 'Amethyst Crystal Inlays', desc: 'Faceted prism starburst & laser frame' },
                        { id: 'runic_rare', label: 'Chrono Brass Astrolabe', desc: 'Precision mechanical tick marks' },
                        { id: 'cyber_sleek', label: 'Cyber Minimalist Neon', desc: 'Clean modern luminous borders' },
                        { id: 'mesopotamian_gold', label: 'Ancient Mesopotamian Winged', desc: 'Winged sun disc & stele relief' },
                      ].map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setFrameStyle(item.id as CardFrameStyle)}
                          className={`p-2.5 rounded-xl text-start border transition-all cursor-pointer ${
                            frameStyle === item.id
                              ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-sm'
                              : 'bg-stone-900/60 border-stone-800 text-stone-300 hover:border-stone-700'
                          }`}
                        >
                          <div className="font-serif font-bold text-xs">{item.label}</div>
                          <div className="text-[10px] text-stone-400">{item.desc}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Corner Ornaments */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                    <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                      Corner Ornaments & Gemstones
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {[
                        { id: 'auto', label: 'Auto (Rarity Tier)' },
                        { id: 'wings', label: 'Winged Filigree & Rubies' },
                        { id: 'gems', label: 'Prismatic Crystal Nodes' },
                        { id: 'runes', label: 'Chrono Runic Chevrons' },
                        { id: 'mesopotamian', label: 'Cuneiform Brackets' },
                        { id: 'minimal', label: 'Clean Hairline Clips' },
                        { id: 'none', label: 'None (Borderless)' },
                      ].map((c) => (
                        <button
                          key={c.id}
                          type="button"
                          onClick={() => setCornerStyle(c.id as CardCornerStyle)}
                          className={`p-2 rounded-xl text-center text-xs font-serif font-medium border transition-all cursor-pointer ${
                            cornerStyle === c.id
                              ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                              : 'bg-stone-900/60 border-stone-800 text-stone-400 hover:text-stone-200'
                          }`}
                        >
                          {c.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: FOIL & HOLOGRAPHIC BEHAVIORS */}
              {activeTab === 'foil' && (
                <div className="space-y-4 text-xs">
                  {/* Continuous Idle Holographic Behavior (All 10 behaviors) */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Continuous Holographic Behavior (حركة الهولوجرام المستمرة)
                      </label>
                      <span className="text-[10px] font-mono text-cyan-300">Live Idle Loop</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {[
                        { id: 'none', label: '1. None', desc: 'Static rarity metallic material only' },
                        { id: 'diagonal_sweep', label: '2. Diagonal Sweep', desc: 'Soft reflective band travelling diagonally' },
                        { id: 'horizontal_sweep', label: '3. Horizontal Sweep', desc: 'Metallic reflection travels left to right' },
                        { id: 'vertical_sweep', label: '4. Vertical Sweep', desc: 'Reflection travels top to bottom' },
                        { id: 'prismatic_shift', label: '5. Prismatic Shift', desc: 'Controlled spectral chromatic refraction' },
                        { id: 'iridescent_flow', label: '6. Iridescent Flow', desc: 'Slow pearlescent oil-on-water movement' },
                        { id: 'radial_gleam', label: '7. Radial Gleam', desc: 'Concentrated gemstone orbital luster' },
                        { id: 'edge_shimmer', label: '8. Edge Shimmer', desc: 'Highlight travelling around card perimeter' },
                        { id: 'holographic_wave', label: '9. Holographic Wave', desc: 'Multiple undulating interference waves' },
                        { id: 'full_foil', label: '10. Full Foil', desc: 'Metallic reflection, holo, iridescence & edge shimmer' },
                      ].map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setHolographicBehavior(item.id as HolographicBehavior)}
                          className={`p-2.5 rounded-xl text-start border transition-all cursor-pointer ${
                            holographicBehavior === item.id
                              ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-sm'
                              : 'bg-stone-900/60 border-stone-800 text-stone-300 hover:border-stone-700'
                          }`}
                        >
                          <div className="font-serif font-bold text-xs">{item.label}</div>
                          <div className="text-[10px] text-stone-400">{item.desc}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Foil Intensity & Reflection Speed */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Foil Intensity */}
                    <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Foil Intensity (قوة لمعان الفويل)
                      </label>
                      <div className="grid grid-cols-2 gap-1.5">
                        {[
                          { id: 'low', label: 'Low', desc: 'Subtle' },
                          { id: 'medium', label: 'Medium', desc: 'Balanced' },
                          { id: 'high', label: 'High', desc: 'Strong' },
                          { id: 'ultra', label: 'Ultra', desc: 'Max Depth' },
                        ].map((int) => (
                          <button
                            key={int.id}
                            type="button"
                            onClick={() => setFoilIntensity(int.id as FoilIntensity)}
                            className={`p-2 rounded-xl text-center border transition-all cursor-pointer ${
                              foilIntensity === int.id
                                ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                                : 'bg-stone-900/60 border-stone-800 text-stone-400 hover:text-stone-200'
                            }`}
                          >
                            <div className="font-bold text-xs">{int.label}</div>
                            <div className="text-[9px] text-stone-500">{int.desc}</div>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Reflection Speed */}
                    <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                        Reflection Speed (سرعة الحركة)
                      </label>
                      <div className="grid grid-cols-3 gap-1.5">
                        {[
                          { val: 0.7, label: 'Serene' },
                          { val: 1.0, label: 'Normal' },
                          { val: 1.4, label: 'Dynamic' },
                        ].map((sp) => (
                          <button
                            key={sp.label}
                            type="button"
                            onClick={() => setReflectionSpeed(sp.val)}
                            className={`p-2 rounded-xl text-center border transition-all cursor-pointer ${
                              reflectionSpeed === sp.val
                                ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                                : 'bg-stone-900/60 border-stone-800 text-stone-400 hover:text-stone-200'
                            }`}
                          >
                            <div className="font-bold text-xs">{sp.label}</div>
                            <div className="text-[9px] text-stone-500">{sp.val}x</div>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Foil Sheen Color */}
                  {isLegendary ? (
                    <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                          Foil Sheen Color (لون لمعة الفويل)
                        </label>
                        <span className="text-[10px] font-mono text-amber-300">{foilColor}</span>
                      </div>
                      <div className="flex items-center gap-2.5 flex-wrap">
                        <input
                          type="color"
                          value={foilColor}
                          onChange={(e) => setFoilColor(e.target.value)}
                          className="w-8 h-8 rounded-xl bg-transparent border border-white/20 cursor-pointer p-0.5"
                        />
                        {[
                          { name: 'Gold', hex: '#f59e0b' },
                          { name: 'Silver', hex: '#9ca3af' },
                          { name: 'Emerald', hex: '#10b981' },
                          { name: 'Sapphire', hex: '#0ea5e9' },
                          { name: 'Amethyst', hex: '#a855f7' },
                          { name: 'Rose Gold', hex: '#fb7185' },
                          { name: 'White', hex: '#ffffff' },
                        ].map((fc) => (
                          <button
                            key={fc.name}
                            type="button"
                            onClick={() => setFoilColor(fc.hex)}
                            className={`px-2 py-1 rounded-lg text-[10px] font-mono flex items-center gap-1 border transition-all cursor-pointer ${
                              foilColor.toLowerCase() === fc.hex.toLowerCase()
                                ? 'bg-white/20 border-white text-white font-bold'
                                : 'bg-black/60 border-white/10 text-stone-300 hover:border-white/30'
                            }`}
                          >
                            <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: fc.hex }} />
                            <span>{fc.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between gap-3">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <label className="text-[11px] font-mono uppercase text-stone-300 font-bold">
                            Foil Sheen Hue ({card.rarity})
                          </label>
                          <span className="text-[9px] font-mono px-2 py-0.5 rounded-md bg-stone-900 border border-white/10 text-stone-400">
                            Locked to Rarity Tier
                          </span>
                        </div>
                        <p className="text-[10px] text-stone-400">
                          Custom foil tint is available for Legendary cards only. Non-legendary cards automatically use their physical rarity tier foil colors.
                        </p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0 px-3 py-1.5 rounded-xl bg-stone-900 border border-white/10">
                        <span
                          className="w-3.5 h-3.5 rounded-full shrink-0 shadow-xs"
                          style={{ backgroundColor: rarityMaterial.primaryColor }}
                        />
                        <span className="text-xs font-mono font-bold text-stone-200">
                          {rarityMaterial.primaryColor}
                        </span>
                      </div>
                    </div>
                  )}

                  {/* Holographic Foil Finish Texture */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                    <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                      Foil Surface Material Texture
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {[
                        { id: 'standard', label: 'Standard Matte Finish', desc: 'No special iridescent reflections' },
                        { id: 'holographic', label: 'Prismatic Hologram', desc: 'Spectacular rainbow color-dodge shimmer' },
                        { id: 'cosmic', label: 'Cosmic Starlight', desc: 'Pulsating deep violet nebula sheen' },
                        { id: 'gold_embossed', label: '24k Gold Inscribed Relief', desc: 'Reflective metallic golden luster' },
                        { id: 'prismatic_crystal', label: 'Diamond Prismatic Sheen', desc: 'Faceted crystalline light diffraction' },
                        { id: 'cyber_matrix', label: 'Cyber Matrix Scanlines', desc: 'High-tech neon grid reflections' },
                      ].map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setFoilStyle(item.id as CardFoilStyle)}
                          className={`p-2.5 rounded-xl text-start border transition-all cursor-pointer ${
                            foilStyle === item.id
                              ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-sm'
                              : 'bg-stone-900/60 border-stone-800 text-stone-300 hover:border-stone-700'
                          }`}
                        >
                          <div className="font-serif font-bold text-xs">{item.label}</div>
                          <div className="text-[10px] text-stone-400">{item.desc}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Card Background Canvas Theme */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                    <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                      Card Canvas & Background Shade
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {[
                        { id: 'auto', label: 'Default Tier Theme' },
                        { id: 'deep_obsidian', label: 'Deep Obsidian Void' },
                        { id: 'dark_slate', label: 'Ancient Dark Slate' },
                        { id: 'emerald_marble', label: 'Emerald Marble' },
                        { id: 'ancient_gold', label: 'Gilded Amber Stone' },
                        { id: 'void_nebula', label: 'Astral Midnight' },
                      ].map((bg) => (
                        <button
                          key={bg.id}
                          type="button"
                          onClick={() => setBackgroundTheme(bg.id as CardBackgroundTheme)}
                          className={`p-2 rounded-xl text-center text-xs font-serif font-medium border transition-all cursor-pointer ${
                            backgroundTheme === bg.id
                              ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                              : 'bg-stone-900/60 border-stone-800 text-stone-400 hover:text-stone-200'
                          }`}
                        >
                          {bg.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: TEXT & LORE */}
              {activeTab === 'text' && (
                <div className="space-y-3 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                        Card Name
                      </label>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 font-serif focus:outline-hidden focus:border-amber-500"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                        Honorific Title
                      </label>
                      <input
                        type="text"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 focus:outline-hidden focus:border-amber-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                      Series / Collection
                    </label>
                    <input
                      type="text"
                      value={series}
                      onChange={(e) => setSeries(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 focus:outline-hidden focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                      Lore Inscription
                    </label>
                    <textarea
                      rows={2}
                      value={lore}
                      onChange={(e) => setLore(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 italic focus:outline-hidden focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                      Gameplay Description
                    </label>
                    <textarea
                      rows={2}
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 focus:outline-hidden focus:border-amber-500"
                    />
                  </div>
                </div>
              )}

              {/* TAB 5: COMBAT STATS */}
              {activeTab === 'stats' && (
                <div className="space-y-4 text-xs">
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-3">
                    <span className="text-[11px] font-mono uppercase text-amber-300 font-bold block">
                      Normalized Combat Ratings (0 - 100 Scale)
                    </span>

                    {/* Attack Slider */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="flex items-center gap-1.5 text-rose-300 font-bold">
                          <Swords size={13} />
                          <span>Attack Rating</span>
                        </span>
                        <span className="font-mono text-rose-300 font-bold">{attack}</span>
                      </div>
                      <input
                        type="range"
                        min="10"
                        max="100"
                        value={attack}
                        onChange={(e) => setAttack(parseInt(e.target.value, 10))}
                        className="w-full accent-rose-500 cursor-pointer"
                      />
                    </div>

                    {/* Defense Slider */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="flex items-center gap-1.5 text-cyan-300 font-bold">
                          <Shield size={13} />
                          <span>Defense Rating</span>
                        </span>
                        <span className="font-mono text-cyan-300 font-bold">{defense}</span>
                      </div>
                      <input
                        type="range"
                        min="10"
                        max="100"
                        value={defense}
                        onChange={(e) => setDefense(parseInt(e.target.value, 10))}
                        className="w-full accent-cyan-500 cursor-pointer"
                      />
                    </div>

                    {/* HP Slider */}
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="flex items-center gap-1.5 text-emerald-300 font-bold">
                          <Heart size={13} />
                          <span>Health Points (HP)</span>
                        </span>
                        <span className="font-mono text-emerald-300 font-bold">{hp}</span>
                      </div>
                      <input
                        type="range"
                        min="10"
                        max="100"
                        value={hp}
                        onChange={(e) => setHp(parseInt(e.target.value, 10))}
                        className="w-full accent-emerald-500 cursor-pointer"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 6: LEGENDARY COMBAT SOUND EFFECTS */}
              {activeTab === 'sfx' && isLegendary && (
                <div className="space-y-4 pt-1">
                  <LegendaryCombatAudioSection
                    targetCard={previewCard}
                    legendaryCards={[]}
                    embedded={true}
                  />
                </div>
              )}
            </div>
          </div>

          {/* Modal Footer Action Buttons */}
          <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-3 shrink-0 mt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-stone-900 text-stone-400 hover:text-white font-serif font-bold text-xs uppercase cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="button"
              disabled={isSaving}
              onClick={handleSaveCustomization}
              className="px-6 py-2.5 rounded-xl font-bold font-serif text-xs uppercase bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:brightness-110 text-stone-950 flex items-center gap-2 shadow-lg shadow-amber-500/20 cursor-pointer disabled:opacity-50 transition-all active:scale-95"
            >
              <Sparkles size={14} />
              <span>{isSaving ? 'Synchronizing Customization...' : 'Save Customization'}</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
