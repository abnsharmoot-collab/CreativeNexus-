import React from 'react';
import { CardRarity, CardFrameStyle } from '../../types/cards';
import { getRarityMaterialConfig } from '../../config/cardMaterialConfig';

interface CardBorderElementsProps {
  rarity: CardRarity;
  accentColor: string;
  borderColor?: string;
  glowColor?: string;
  frameStyle?: CardFrameStyle;
  isHovered?: boolean;
}

export const CardBorderElements: React.FC<CardBorderElementsProps> = ({
  rarity,
  accentColor,
  borderColor,
  frameStyle = 'auto',
  isHovered = false,
}) => {
  const rarityConfig = getRarityMaterialConfig(rarity);

  // Resolve effective frame style based on rarity unless explicitly overridden
  let effectiveFrame: CardFrameStyle = 'minimalist';
  if (frameStyle && frameStyle !== 'auto') {
    effectiveFrame = frameStyle as CardFrameStyle;
  } else {
    effectiveFrame = rarityConfig.defaultFrameStyle;
  }

  const isTopTier = rarity === 'LEGENDARY' || rarity === 'HALLOWEEN_2026';
  const primaryColor = isTopTier ? (borderColor || accentColor || rarityConfig.primaryColor) : rarityConfig.primaryColor;
  const secondaryColor = rarity === 'HALLOWEEN_2026' ? '#b026ff' : '#ffd700';

  return (
    <div className="absolute inset-0 pointer-events-none rounded-[inherit] overflow-hidden z-20">
      {/* ------------------------------------------------------------------ */}
      {/* 0. HALLOWEEN 2026 SPECTRAL FRAME (Limited Mythic Pumpkin / Bat Arch) */}
      {/* ------------------------------------------------------------------ */}
      {effectiveFrame === 'halloween_spectral' && (
        <>
          {/* Cursed Pumpkin Flame Outer Bezel */}
          <div
            className="absolute inset-[3px] rounded-[1.85rem] sm:rounded-[2.05rem] border-2 transition-all duration-300 pointer-events-none"
            style={{
              borderColor: `${primaryColor}e6`,
              boxShadow: isHovered
                ? `inset 0 0 28px ${primaryColor}99, 0 0 24px ${primaryColor}cc, 0 0 14px ${secondaryColor}88`
                : `inset 0 0 16px ${primaryColor}66, 0 0 14px ${primaryColor}88, 0 0 8px ${secondaryColor}66`,
            }}
          />
          {/* Inner Spectral Witchfire Purple Bezel */}
          <div
            className="absolute inset-[6px] rounded-[1.7rem] sm:rounded-[1.9rem] border pointer-events-none"
            style={{
              borderColor: `${secondaryColor}99`,
              boxShadow: `inset 0 0 10px ${secondaryColor}44`,
            }}
          />

          {/* Running Flame Glint Bar at the top */}
          <div
            className="absolute top-0 inset-x-0 h-[2.5px] pointer-events-none opacity-95 transition-opacity duration-300"
            style={{
              background: `linear-gradient(90deg, transparent 0%, ${primaryColor} 25%, #ffedd5 50%, ${secondaryColor} 75%, transparent 100%)`,
              boxShadow: `0 0 16px #ff5e00, 0 0 26px ${secondaryColor}`,
            }}
          />

          {/* Top Bat Wings & Pumpkin Crest Arch */}
          <div className="absolute top-1 inset-x-0 flex items-center justify-center pointer-events-none z-30">
            <svg
              viewBox="0 0 220 28"
              className="w-40 sm:w-48 h-7 filter drop-shadow-[0_2px_10px_rgba(0,0,0,0.95)]"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Bat Wing filigree arches */}
              <path
                d="M110 3C116 10 126 12 138 9C132 16 142 22 152 18C140 23 126 21 116 25L110 27L104 25C94 21 80 23 68 18C78 22 88 16 82 9C94 12 104 10 110 3Z"
                fill="url(#halloweenFlameGrad)"
                stroke={primaryColor}
                strokeWidth="1.2"
              />
              {/* Jack-o'-Lantern center emblem */}
              <circle cx="110" cy="15" r="5" fill="#ff5e00" stroke="#b026ff" strokeWidth="1" />
              <path d="M108 14L109 16L111 16L112 14" stroke="#120117" strokeWidth="0.8" strokeLinecap="round" />
              <defs>
                <linearGradient id="halloweenFlameGrad" x1="68" y1="3" x2="152" y2="27" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#ffedd5" />
                  <stop offset="0.4" stopColor="#ff5e00" />
                  <stop offset="1" stopColor="#b026ff" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* 1. ORNATE LEGENDARY BORDER ARCHITECTURE (No Corner Gems/Ornaments) */}
      {/* ------------------------------------------------------------------ */}
      {effectiveFrame === 'ornate_legendary' && (
        <>
          {/* Outer Gilded Inset Border with double hairline */}
          <div
            className="absolute inset-[3px] rounded-[1.85rem] sm:rounded-[2.05rem] border-2 transition-all duration-300 pointer-events-none"
            style={{
              borderColor: `${primaryColor}cc`,
              boxShadow: isHovered
                ? `inset 0 0 22px ${primaryColor}77, 0 0 16px ${primaryColor}99`
                : `inset 0 0 12px ${primaryColor}44, 0 0 8px ${primaryColor}66`,
            }}
          />
          {/* Inner Refined Micro-Bezel */}
          <div
            className="absolute inset-[6px] rounded-[1.7rem] sm:rounded-[1.9rem] border border-dashed opacity-60 pointer-events-none"
            style={{
              borderColor: `${primaryColor}88`,
            }}
          />

          {/* Running Golden Edge Glint Bar */}
          <div
            className="absolute top-0 inset-x-0 h-[2px] pointer-events-none opacity-90 transition-opacity duration-300"
            style={{
              background: `linear-gradient(90deg, transparent 0%, ${primaryColor} 20%, #fff 50%, ${primaryColor} 80%, transparent 100%)`,
              boxShadow: `0 0 14px #fff, 0 0 24px ${primaryColor}`,
            }}
          />

          {/* Top Crown Sovereign Arch (Pure architectural geometry, no gemstones) */}
          <div className="absolute top-1.5 inset-x-0 flex items-center justify-center pointer-events-none z-30">
            <svg
              viewBox="0 0 200 24"
              className="w-36 sm:w-44 h-6 filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M100 2L106 12L116 5L111 17H89L84 5L94 12L100 2Z"
                fill={`url(#goldGrad-${primaryColor.replace('#', '')})`}
                stroke={primaryColor}
                strokeWidth="1.2"
              />
              <path
                d="M40 14C60 12 75 11 86 16M160 14C140 12 125 11 114 16"
                stroke={primaryColor}
                strokeWidth="1.5"
                strokeLinecap="round"
              />
              <defs>
                <linearGradient
                  id={`goldGrad-${primaryColor.replace('#', '')}`}
                  x1="84"
                  y1="2"
                  x2="116"
                  y2="17"
                  gradientUnits="userSpaceOnUse"
                >
                  <stop stopColor="#fef08a" />
                  <stop offset="0.5" stopColor={primaryColor} />
                  <stop offset="1" stopColor="#b45309" />
                </linearGradient>
              </defs>
            </svg>
          </div>

          {/* Left and Right Side Luminous Pillar Rails */}
          <div
            className="absolute top-1/4 bottom-1/4 start-1.5 w-[2px] rounded-full pointer-events-none opacity-80"
            style={{
              background: `linear-gradient(to bottom, transparent, ${primaryColor}, transparent)`,
              boxShadow: `0 0 8px ${primaryColor}`,
            }}
          />
          <div
            className="absolute top-1/4 bottom-1/4 end-1.5 w-[2px] rounded-full pointer-events-none opacity-80"
            style={{
              background: `linear-gradient(to bottom, transparent, ${primaryColor}, transparent)`,
              boxShadow: `0 0 8px ${primaryColor}`,
            }}
          />
        </>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* 2. CRYSTAL EPIC FRAME ARCHITECTURE                                  */}
      {/* ------------------------------------------------------------------ */}
      {effectiveFrame === 'crystal_epic' && (
        <>
          <div
            className="absolute inset-[3px] rounded-[1.85rem] sm:rounded-[2.05rem] border-2 transition-all duration-300 pointer-events-none"
            style={{
              borderColor: `${primaryColor}bb`,
              boxShadow: isHovered
                ? `inset 0 0 20px ${primaryColor}77, 0 0 16px ${primaryColor}99`
                : `inset 0 0 10px ${primaryColor}33, 0 0 8px ${primaryColor}55`,
            }}
          />
          <div
            className="absolute inset-[7px] rounded-[1.7rem] sm:rounded-[1.9rem] border pointer-events-none"
            style={{
              borderColor: `${primaryColor}44`,
            }}
          />

          {/* Top Starburst Centerpiece */}
          <div className="absolute top-2 inset-x-0 flex items-center justify-center pointer-events-none z-30">
            <svg
              viewBox="0 0 160 20"
              className="w-32 h-5 filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M80 2L84 9L92 10L84 11L80 18L76 11L68 10L76 9L80 2Z"
                fill={primaryColor}
                stroke="#fff"
                strokeWidth="0.8"
              />
              <path d="M40 10L66 10M120 10L94 10" stroke={primaryColor} strokeWidth="1.5" strokeLinecap="round" />
            </svg>
          </div>

          {/* Side Purple Rails */}
          <div
            className="absolute top-1/3 bottom-1/3 start-1.5 w-[1.5px] rounded-full pointer-events-none opacity-70"
            style={{
              background: `linear-gradient(to bottom, transparent, ${primaryColor}, transparent)`,
            }}
          />
          <div
            className="absolute top-1/3 bottom-1/3 end-1.5 w-[1.5px] rounded-full pointer-events-none opacity-70"
            style={{
              background: `linear-gradient(to bottom, transparent, ${primaryColor}, transparent)`,
            }}
          />
        </>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* 3. RUNIC RARE FRAME ARCHITECTURE                                    */}
      {/* ------------------------------------------------------------------ */}
      {effectiveFrame === 'runic_rare' && (
        <>
          <div
            className="absolute inset-[3px] rounded-[1.85rem] sm:rounded-[2.05rem] border transition-all duration-300 pointer-events-none"
            style={{
              borderColor: `${primaryColor}aa`,
              boxShadow: isHovered
                ? `inset 0 0 16px ${primaryColor}66, 0 0 14px ${primaryColor}77`
                : `inset 0 0 8px ${primaryColor}33, 0 0 6px ${primaryColor}44`,
            }}
          />
          <div
            className="absolute inset-[6px] rounded-[1.7rem] sm:rounded-[1.9rem] border border-dotted opacity-60 pointer-events-none"
            style={{ borderColor: primaryColor }}
          />

          {/* Top Chrono Compass Centerpiece */}
          <div className="absolute top-2 inset-x-0 flex items-center justify-center pointer-events-none z-30">
            <svg
              viewBox="0 0 120 18"
              className="w-28 h-4 filter drop-shadow-[0_2px_6px_rgba(0,0,0,0.8)]"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <circle cx="60" cy="9" r="4.5" stroke={primaryColor} strokeWidth="1.2" />
              <path d="M60 4V14M55 9H65" stroke={primaryColor} strokeWidth="1" />
              <path d="M30 9H48M72 9H90" stroke={primaryColor} strokeWidth="1.2" strokeLinecap="round" />
            </svg>
          </div>
        </>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* 4. CYBER SLEEK MODERN FRAME (UNCOMMON)                              */}
      {/* ------------------------------------------------------------------ */}
      {effectiveFrame === 'cyber_sleek' && (
        <>
          <div
            className="absolute inset-[3px] rounded-[1.85rem] sm:rounded-[2.05rem] border transition-all duration-300 pointer-events-none"
            style={{
              borderColor: `${primaryColor}88`,
              boxShadow: isHovered ? `inset 0 0 10px ${primaryColor}44, 0 0 12px ${primaryColor}55` : `inset 0 0 6px ${primaryColor}22`,
            }}
          />
          {/* Subtle green perimeter edge glint */}
          <div
            className="absolute top-0 inset-x-6 h-[1.5px] pointer-events-none opacity-70"
            style={{
              background: `linear-gradient(90deg, transparent 0%, ${primaryColor} 50%, transparent 100%)`,
            }}
          />
        </>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* 5. MESOPOTAMIAN WINGED SUN FRAME                                    */}
      {/* ------------------------------------------------------------------ */}
      {effectiveFrame === 'mesopotamian_gold' && (
        <>
          <div
            className="absolute inset-[3px] rounded-[1.85rem] sm:rounded-[2.05rem] border-2 transition-all duration-300 pointer-events-none"
            style={{
              borderColor: `${primaryColor}cc`,
              boxShadow: `inset 0 0 16px ${primaryColor}44, 0 0 10px ${primaryColor}66`,
            }}
          />
          <div className="absolute top-1.5 inset-x-0 flex items-center justify-center pointer-events-none z-30">
            <svg viewBox="0 0 140 20" className="w-32 h-5" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="70" cy="10" r="3.5" fill={primaryColor} stroke="#fef08a" strokeWidth="1" />
              <path
                d="M70 10C55 6 40 8 25 12M70 10C85 6 100 8 115 12"
                stroke={primaryColor}
                strokeWidth="1.5"
                strokeLinecap="round"
              />
            </svg>
          </div>
        </>
      )}

      {/* ------------------------------------------------------------------ */}
      {/* 6. MINIMALIST HAIRLINE FRAME (COMMON)                               */}
      {/* ------------------------------------------------------------------ */}
      {effectiveFrame === 'minimalist' && (
        <>
          <div
            className="absolute inset-[3px] rounded-[1.85rem] sm:rounded-[2.05rem] border transition-all duration-300 pointer-events-none"
            style={{
              borderColor: `${primaryColor}40`,
              boxShadow: isHovered
                ? `inset 0 0 8px ${primaryColor}22`
                : 'none',
            }}
          />
          {/* Subtle silver top highlight glint */}
          <div
            className="absolute top-0 inset-x-8 h-[1px] pointer-events-none opacity-40"
            style={{
              background: `linear-gradient(90deg, transparent 0%, ${primaryColor} 50%, transparent 100%)`,
            }}
          />
        </>
      )}
    </div>
  );
};
