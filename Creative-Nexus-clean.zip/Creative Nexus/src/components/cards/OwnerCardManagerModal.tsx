import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useCards } from '../../context/CardContext';
import {
  CollectibleCardData,
  CardRarity,
  CardElement,
  CardAbility,
  AbilityCategory,
  CardStatItem,
  CardStateItem,
  CardStateType,
  DEFAULT_CARD_STATS,
  getDefaultCardStats,
  calculateCardPowerRating,
  CARD_STATE_PRESETS
} from '../../types/cards';
import {
  X, Plus, Sparkles, CheckCircle2, AlertCircle, Film,
  Trash2, Upload, Video, ShieldCheck, Zap, Flame, Eye, Image as ImageIcon,
  Sliders, Activity, Shield, Award, Layers, Swords, Clock, Target, PlayCircle
} from 'lucide-react';
import { MODERN_CARD_ASSETS } from '../../assets/modernCardAssets';
import { MESOPOTAMIAN_ASSETS } from '../../assets/mesopotamianAssets';
import { parseUniversalVideoUrl } from '../../utils/videoHelpers';
import { getRarityMaterialConfig } from '../../config/cardMaterialConfig';

interface OwnerCardManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  cardToEdit?: CollectibleCardData | null;
}

const PRESET_ARTWORKS = [
  { label: 'Lord Sovereign Prime', url: MODERN_CARD_ASSETS.cardApexSovereign },
  { label: 'Valkyrie Aegis', url: MODERN_CARD_ASSETS.cardAegisValkyrie },
  { label: 'Chrono Master', url: MODERN_CARD_ASSETS.cardChronoArchitect },
  { label: 'Empress Selene Astral', url: MODERN_CARD_ASSETS.cardAstralEmpress },
  { label: 'Phantom Blade Zero', url: MODERN_CARD_ASSETS.cardShadowOperative },
  { label: 'Ancient Lamassu Relief', url: MESOPOTAMIAN_ASSETS.lamassuRelief },
  { label: 'Sovereign King Relief', url: MESOPOTAMIAN_ASSETS.kingRelief }
];

const PRESET_VIDEOS = [
  { label: 'Celestial Starflare', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4' },
  { label: 'Astral Supernova', url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4' }
];

const CARD_TYPES = [
  'Warrior',
  'Relic',
  'Archon',
  'Spell',
  'Entity',
  'Commander',
  'Titan',
  'Mystic',
  'Guardian',
  'Sovereign'
];

const ABILITY_CATEGORIES: { type: AbilityCategory; label: string; color: string }[] = [
  { type: 'PASSIVE', label: 'Passive', color: 'text-blue-400 border-blue-500/40 bg-blue-950/40' },
  { type: 'ACTIVE', label: 'Active', color: 'text-amber-400 border-amber-500/40 bg-amber-950/40' },
  { type: 'TRIGGERED', label: 'Triggered', color: 'text-purple-400 border-purple-500/40 bg-purple-950/40' },
  { type: 'OFFENSIVE', label: 'Offensive', color: 'text-rose-400 border-rose-500/40 bg-rose-950/40' },
  { type: 'DEFENSIVE', label: 'Defensive', color: 'text-emerald-400 border-emerald-500/40 bg-emerald-950/40' },
  { type: 'UTILITY', label: 'Utility', color: 'text-cyan-400 border-cyan-500/40 bg-cyan-950/40' },
  { type: 'ULTIMATE', label: 'Ultimate', color: 'text-yellow-300 border-yellow-500/40 bg-yellow-950/40' }
];

export const OwnerCardManagerModal: React.FC<OwnerCardManagerModalProps> = ({
  isOpen,
  onClose,
  cardToEdit
}) => {
  const { isOwner } = useAuth();
  const { ownerSaveCard, ownerDeleteCard } = useCards();
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDeleteThisCard = async () => {
    if (!cardToEdit) return;
    if (!window.confirm(`Are you sure you want to delete or deactivate card "${cardToEdit.name}"?`)) {
      return;
    }
    setIsDeleting(true);
    try {
      await ownerDeleteCard(cardToEdit.id);
      onClose();
    } catch (err: any) {
      alert(`Failed to delete card: ${err.message}`);
    } finally {
      setIsDeleting(false);
    }
  };

  // Basic Card Data
  const [name, setName] = useState('');
  const [title, setTitle] = useState('');
  const [rarity, setRarity] = useState<CardRarity>('COMMON');
  const [cardType, setCardType] = useState('Relic');
  const [element, setElement] = useState<CardElement>('STONE');
  const [description, setDescription] = useState('');
  const [lore, setLore] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [series, setSeries] = useState('Apex Sovereigns');
  const [accentColor, setAccentColor] = useState('#f59e0b');
  const [borderColor, setBorderColor] = useState('#f59e0b');
  const [glowColor, setGlowColor] = useState('#f59e0b');
  const [glowIntensity, setGlowIntensity] = useState<any>('radiant');
  const [frameStyle, setFrameStyle] = useState<any>('auto');
  const [cornerStyle, setCornerStyle] = useState<any>('auto');
  const [backgroundTheme, setBackgroundTheme] = useState<any>('auto');
  const [foilStyle, setFoilStyle] = useState<any>('standard');
  const [isActive, setIsActive] = useState<boolean>(true);
  const [revealVideoUrl, setRevealVideoUrl] = useState<string>('');

  // Structured Numerical Stats
  const [customStats, setCustomStats] = useState<CardStatItem[]>([]);

  // Structured Abilities
  const [abilities, setAbilities] = useState<CardAbility[]>([]);

  // Structured Temporary Card States (Gameplay Architecture)
  const [cardStates, setCardStates] = useState<CardStateItem[]>([]);

  // Legacy combat stats (kept in sync for backward compatibility)
  const [attack, setAttack] = useState('500');
  const [defense, setDefense] = useState('500');
  const [hp, setHp] = useState('600');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'details' | 'stats' | 'abilities' | 'states' | 'media'>('details');

  // Load existing card or reset
  useEffect(() => {
    if (cardToEdit) {
      setName(cardToEdit.name || '');
      setTitle(cardToEdit.title || '');
      setRarity(cardToEdit.rarity || 'COMMON');
      setCardType(cardToEdit.cardType || 'Relic');
      setElement(cardToEdit.element || 'STONE');
      setDescription(cardToEdit.description || '');
      setLore(cardToEdit.lore || '');
      setImageUrl(cardToEdit.imageUrl || MODERN_CARD_ASSETS.cardApexSovereign);
      setAttack(cardToEdit.attack ? String(cardToEdit.attack) : '500');
      setDefense(cardToEdit.defense ? String(cardToEdit.defense) : '500');
      setHp(cardToEdit.hp ? String(cardToEdit.hp) : '600');
      setSeries(cardToEdit.series || 'Apex Sovereigns');
      setAccentColor(cardToEdit.accentColor || '#f59e0b');
      setBorderColor(cardToEdit.borderColor || cardToEdit.accentColor || '#f59e0b');
      setGlowColor(cardToEdit.glowColor || cardToEdit.borderColor || cardToEdit.accentColor || '#f59e0b');
      setGlowIntensity(cardToEdit.glowIntensity || 'radiant');
      setFrameStyle(cardToEdit.frameStyle || 'auto');
      setCornerStyle(cardToEdit.cornerStyle || 'auto');
      setBackgroundTheme(cardToEdit.backgroundTheme || 'auto');
      setFoilStyle(cardToEdit.foilStyle || 'standard');
      setIsActive(cardToEdit.isActive !== false);
      setRevealVideoUrl(cardToEdit.revealVideoUrl || '');

      // Load custom stats or default
      if (Array.isArray(cardToEdit.customStats) && cardToEdit.customStats.length > 0) {
        setCustomStats(cardToEdit.customStats.map(s => ({ ...s })));
      } else {
        setCustomStats(getDefaultCardStats(cardToEdit.attack ?? 500, cardToEdit.defense ?? 500));
      }

      // Load abilities
      setAbilities(Array.isArray(cardToEdit.abilities) ? cardToEdit.abilities.map(a => ({ ...a })) : []);

      // Load card states
      setCardStates(Array.isArray(cardToEdit.cardStates) ? cardToEdit.cardStates.map(s => ({ ...s })) : []);
    } else {
      setName('');
      setTitle('Sovereign Archon');
      setRarity('COMMON');
      setCardType('Relic');
      setElement('STONE');
      setDescription('');
      setLore('');
      setImageUrl(MODERN_CARD_ASSETS.cardApexSovereign);
      setAttack('75');
      setDefense('70');
      setHp('80');
      setSeries('Apex Sovereigns');
      setAccentColor('#f59e0b');
      setFoilStyle('standard');
      setIsActive(true);
      setRevealVideoUrl('');
      setCustomStats(DEFAULT_CARD_STATS.map(s => ({ ...s })));
      setAbilities([]);
      setCardStates([]);
    }
    setStatusMessage(null);
  }, [cardToEdit, isOpen]);

  // Dynamic calculated Power Rating (max 100)
  const powerRating = useMemo(() => {
    const activeAbilitiesCount = abilities.filter(a => a.enabled !== false).length;
    return Math.min(100, calculateCardPowerRating(customStats, rarity, activeAbilitiesCount));
  }, [customStats, rarity, abilities]);

  if (!isOpen || !isOwner) return null;

  // ----------------------------------------------------
  // STATS MANAGEMENT
  // ----------------------------------------------------
  const handleAddStat = () => {
    const newStat: CardStatItem = {
      id: `stat_${Date.now()}`,
      name: 'Influence',
      value: 60,
      maxValue: 100
    };
    setCustomStats([...customStats, newStat]);
  };

  const handleUpdateStat = (index: number, field: keyof CardStatItem, value: any) => {
    const updated = [...customStats];
    const cleanValue = field === 'value' ? Math.min(100, Math.max(0, parseInt(value, 10) || 0)) : value;
    updated[index] = { ...updated[index], [field]: cleanValue };
    setCustomStats(updated);

    // Keep legacy attack/defense in sync if changed (0-100 scale)
    if (updated[index].id === 'power' || updated[index].name.toLowerCase() === 'power') {
      setAttack(String(Math.min(100, updated[index].value)));
    }
    if (updated[index].id === 'defense' || updated[index].name.toLowerCase() === 'defense') {
      setDefense(String(Math.min(100, updated[index].value)));
    }
  };

  const handleRemoveStat = (index: number) => {
    setCustomStats(customStats.filter((_, i) => i !== index));
  };

  const handleResetDefaultStats = () => {
    setCustomStats(DEFAULT_CARD_STATS.map(s => ({ ...s })));
  };

  // ----------------------------------------------------
  // ABILITIES MANAGEMENT
  // ----------------------------------------------------
  const handleAddAbility = () => {
    const newAbility: CardAbility = {
      id: `ab_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: 'Divine Inscription',
      description: 'Increases card performance and defensive shielding during battle encounters.',
      type: 'ACTIVE',
      value: 120,
      duration: 2,
      cooldown: 3,
      trigger: 'On Summon',
      target: 'Self',
      enabled: true,
      cost: 15,
      powerValue: 120
    };
    setAbilities([...abilities, newAbility]);
  };

  const handleUpdateAbility = (index: number, field: keyof CardAbility, value: any) => {
    const updated = [...abilities];
    updated[index] = { ...updated[index], [field]: value };
    setAbilities(updated);
  };

  const handleToggleAbility = (index: number) => {
    const updated = [...abilities];
    updated[index] = { ...updated[index], enabled: updated[index].enabled === false ? true : false };
    setAbilities(updated);
  };

  const handleRemoveAbility = (index: number) => {
    setAbilities(abilities.filter((_, i) => i !== index));
  };

  // ----------------------------------------------------
  // CARD STATES MANAGEMENT (GAMEPLAY ARCHITECTURE)
  // ----------------------------------------------------
  const handleAddState = (presetType: CardStateType = 'NORMAL') => {
    const preset = CARD_STATE_PRESETS.find(p => p.type === presetType) || CARD_STATE_PRESETS[0];
    const newState: CardStateItem = {
      id: `st_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: preset.type,
      duration: preset.type === 'NORMAL' ? 0 : 2,
      effect: preset.defaultEffect,
      value: preset.type === 'BUFFED' ? 25 : preset.type === 'DEBUFFED' ? -20 : undefined,
      source: 'Relic Aura',
      active: true
    };
    setCardStates([...cardStates, newState]);
  };

  const handleUpdateState = (index: number, field: keyof CardStateItem, value: any) => {
    const updated = [...cardStates];
    updated[index] = { ...updated[index], [field]: value };
    setCardStates(updated);
  };

  const handleToggleState = (index: number) => {
    const updated = [...cardStates];
    updated[index] = { ...updated[index], active: !updated[index].active };
    setCardStates(updated);
  };

  const handleRemoveState = (index: number) => {
    setCardStates(cardStates.filter((_, i) => i !== index));
  };

  // ----------------------------------------------------
  // FILE UPLOADS
  // ----------------------------------------------------
  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2.5 * 1024 * 1024) {
      alert('Image file exceeds 2.5MB. Please choose a smaller image.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (evt) => {
      if (typeof evt.target?.result === 'string') {
        setImageUrl(evt.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleVideoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 4.5 * 1024 * 1024) {
      alert('Video file exceeds 4.5MB. Please choose a short MP4 clip or provide an external URL.');
      return;
    }
    const reader = new FileReader();
    reader.onload = (evt) => {
      if (typeof evt.target?.result === 'string') {
        setRevealVideoUrl(evt.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  // ----------------------------------------------------
  // SUBMIT HANDLER
  // ----------------------------------------------------
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setStatusMessage('Error: Card name is required');
      return;
    }

    setIsSubmitting(true);
    setStatusMessage(null);
    try {
      const rawAtk = parseInt(attack, 10) || 75;
      const rawDef = parseInt(defense, 10) || 70;
      const rawHp = parseInt(hp, 10) || 80;
      const atkNum = Math.min(100, Math.max(1, rawAtk > 100 ? Math.round(rawAtk / 10) : rawAtk));
      const defNum = Math.min(100, Math.max(1, rawDef > 100 ? Math.round(rawDef / 10) : rawDef));
      const hpNum = Math.min(100, Math.max(1, rawHp > 100 ? Math.round(rawHp / 10) : rawHp));

      await ownerSaveCard({
        id: cardToEdit?.id,
        name: name.trim(),
        title: title.trim() || 'Relic of Antiquity',
        rarity,
        packType: rarity,
        cardType: cardType.trim() || 'Relic',
        description: description.trim() || 'Ancient Mesopotamian collectible relic.',
        lore: lore.trim() || '"Echoes of forgotten kings resonate in the stars."',
        imageUrl: imageUrl.trim() || MESOPOTAMIAN_ASSETS.lamassuRelief,
        attack: atkNum,
        defense: defNum,
        hp: hpNum,
        power: powerRating,
        powerRating,
        element,
        series: series.trim() || 'Antiquities of Sumer',
        accentColor: rarity === 'LEGENDARY' ? accentColor : getRarityMaterialConfig(rarity).primaryColor,
        borderColor: rarity === 'LEGENDARY' ? borderColor : getRarityMaterialConfig(rarity).primaryColor,
        glowColor: rarity === 'LEGENDARY' ? glowColor : getRarityMaterialConfig(rarity).primaryColor,
        glowIntensity,
        frameStyle: frameStyle === 'auto' ? undefined : frameStyle,
        cornerStyle: cornerStyle === 'auto' ? undefined : cornerStyle,
        backgroundTheme: backgroundTheme === 'auto' ? undefined : backgroundTheme,
        foilStyle,
        isActive,
        revealVideoUrl: revealVideoUrl.trim() || undefined,
        customStats: customStats.filter(s => s.name.trim().length > 0),
        abilities: abilities.filter(a => a.name.trim().length > 0),
        cardStates: cardStates.filter(s => String(s.name).trim().length > 0),
        isCustom: cardToEdit ? cardToEdit.isCustom : true
      });

      setStatusMessage('✨ Card forged & synchronized to global vault!');
      setTimeout(() => {
        onClose();
      }, 1000);
    } catch (err: any) {
      setStatusMessage(`Error: ${err.message || 'Failed to save card'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/90 backdrop-blur-xl overflow-y-auto"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-3xl bg-[#031110] border border-emerald-900/50 rounded-3xl p-4 sm:p-6 shadow-2xl shadow-black overflow-hidden my-auto max-h-[94dvh] flex flex-col box-border"
      >
        {/* Top Metallic Bevel Highlight */}
        <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-amber-400/50 to-transparent pointer-events-none" />

        {/* Header with Live Power Rating */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0 gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-950/60 border border-amber-500/40 flex items-center justify-center text-amber-300 shadow-md shrink-0">
              <Sliders size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono tracking-widest text-amber-400 uppercase font-bold">
                  CARD MANAGEMENT // نظام إدارة وتعديل الكروت
                </span>
                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  OWNER ONLY
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-black font-serif text-amber-100 truncate">
                {cardToEdit ? `EDIT CARD: ${cardToEdit.name}` : 'CREATE NEW COLLECTIBLE CARD'}
              </h2>
            </div>
          </div>

          {/* Real-Time Calculated Overall Rating Display */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex flex-col items-end px-3 py-1.5 rounded-xl bg-black/60 border border-amber-500/30">
              <span className="text-[9px] font-mono uppercase tracking-widest text-stone-400">Overall Rating</span>
              <div className="flex items-baseline gap-1">
                <span className="text-base font-black font-mono text-amber-300">{powerRating}</span>
                <span className="text-[10px] text-amber-400 font-bold">OVR</span>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="Close"
              className="p-1.5 rounded-xl text-stone-400 hover:text-white bg-black/40 hover:bg-black border border-white/10 transition-colors cursor-pointer"
            >
              <X size={17} />
            </button>
          </div>
        </div>

        {/* Status Notification */}
        {statusMessage && (
          <div
            className={`my-2 p-2.5 rounded-xl text-xs flex items-center gap-2 shrink-0 ${
              statusMessage.startsWith('Error')
                ? 'bg-rose-950/80 border border-rose-500/40 text-rose-200'
                : 'bg-emerald-950/80 border border-emerald-500/40 text-emerald-200'
            }`}
          >
            {statusMessage.startsWith('Error') ? <AlertCircle size={15} /> : <CheckCircle2 size={15} />}
            <span>{statusMessage}</span>
          </div>
        )}

        {/* Tab Controls */}
        <div className="flex items-center gap-1.5 pt-2 pb-1 border-b border-white/5 shrink-0 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('details')}
            className={`px-3 py-1.5 rounded-lg text-xs font-serif font-bold uppercase tracking-wider transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'details'
                ? 'bg-amber-500 text-stone-950 shadow-md'
                : 'text-stone-400 hover:text-amber-200 bg-stone-900/40'
            }`}
          >
            1. Core Data
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('stats')}
            className={`px-3 py-1.5 rounded-lg text-xs font-serif font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'stats'
                ? 'bg-amber-500 text-stone-950 shadow-md'
                : 'text-stone-400 hover:text-amber-200 bg-stone-900/40'
            }`}
          >
            <Flame size={13} />
            <span>2. Stats & Power ({customStats.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('abilities')}
            className={`px-3 py-1.5 rounded-lg text-xs font-serif font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'abilities'
                ? 'bg-amber-500 text-stone-950 shadow-md'
                : 'text-stone-400 hover:text-amber-200 bg-stone-900/40'
            }`}
          >
            <Zap size={13} />
            <span>3. Abilities ({abilities.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('states')}
            className={`px-3 py-1.5 rounded-lg text-xs font-serif font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'states'
                ? 'bg-amber-500 text-stone-950 shadow-md'
                : 'text-stone-400 hover:text-amber-200 bg-stone-900/40'
            }`}
          >
            <Activity size={13} />
            <span>4. States ({cardStates.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('media')}
            className={`px-3 py-1.5 rounded-lg text-xs font-serif font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'media'
                ? 'bg-amber-500 text-stone-950 shadow-md'
                : 'text-stone-400 hover:text-amber-200 bg-stone-900/40'
            }`}
          >
            <Film size={13} />
            <span>5. Art & Video</span>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto space-y-4 pt-3 pr-1 text-xs grow">
          {/* ============================================================ */}
          {/* TAB 1: BASIC CARD DATA                                       */}
          {/* ============================================================ */}
          {activeTab === 'details' && (
            <div className="space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                    Card Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Master Lamassu of Babylon"
                    className="w-full px-3 py-2 rounded-xl bg-stone-900/90 border border-stone-800 text-amber-100 font-serif focus:outline-hidden focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                    Honorific Title / Role
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Sovereign Protector of the Vault"
                    className="w-full px-3 py-2 rounded-xl bg-stone-900/90 border border-stone-800 text-amber-100 focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                {/* Rarity */}
                <div>
                  <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                    Rarity Tier
                  </label>
                  <select
                    value={rarity}
                    onChange={(e) => setRarity(e.target.value as CardRarity)}
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 font-mono font-bold focus:outline-hidden focus:border-amber-500"
                  >
                    <option value="COMMON">COMMON (Standard Gray)</option>
                    <option value="UNCOMMON">UNCOMMON (Emerald Jade)</option>
                    <option value="RARE">RARE (Lapis Lazuli)</option>
                    <option value="EPIC">EPIC (Amethyst Void)</option>
                    <option value="LEGENDARY">LEGENDARY (Imperial Gold)</option>
                  </select>
                </div>

                {/* Card Type */}
                <div>
                  <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                    Card Type
                  </label>
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      value={cardType}
                      onChange={(e) => setCardType(e.target.value)}
                      placeholder="e.g. Relic"
                      className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 font-mono focus:outline-hidden focus:border-amber-500"
                    />
                  </div>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {CARD_TYPES.slice(0, 4).map(ct => (
                      <button
                        key={ct}
                        type="button"
                        onClick={() => setCardType(ct)}
                        className={`text-[9px] font-mono px-1.5 py-0.5 rounded ${
                          cardType === ct ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'text-stone-500 hover:text-stone-300'
                        }`}
                      >
                        {ct}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Element */}
                <div>
                  <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                    Element Affinity
                  </label>
                  <select
                    value={element}
                    onChange={(e) => setElement(e.target.value as CardElement)}
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 focus:outline-hidden focus:border-amber-500"
                  >
                    <option value="STONE">Stone (Earth)</option>
                    <option value="FIRE">Fire (Sun)</option>
                    <option value="STORM">Storm (Wind)</option>
                    <option value="ASTRAL">Astral (Stars)</option>
                    <option value="WATER">Water (Tigris & Euphrates)</option>
                  </select>
                </div>

                {/* Series */}
                <div>
                  <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                    Card Series
                  </label>
                  <input
                    type="text"
                    value={series}
                    onChange={(e) => setSeries(e.target.value)}
                    placeholder="e.g. Antiquities of Sumer"
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Card chronicle, tactical archetype, and gameplay function..."
                  className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                  Inscribed Lore Quote
                </label>
                <textarea
                  rows={2}
                  value={lore}
                  onChange={(e) => setLore(e.target.value)}
                  placeholder='"He who carved the tablet of destiny shall rule the digital ether..."'
                  className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 italic focus:outline-hidden focus:border-amber-500"
                />
              </div>

              {/* Active / Inactive Status Switch */}
              <div className="p-3 rounded-2xl bg-black/40 border border-white/5 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-amber-200 block">
                    Card Availability Status
                  </span>
                  <span className="text-[11px] text-stone-400">
                    Active cards can drop from Booster Packs. Inactive cards remain vaulted in the catalog.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsActive(!isActive)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold uppercase transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/50'
                  }`}
                >
                  {isActive ? '● Active (Droppable)' : '○ Inactive (Vaulted)'}
                </button>
              </div>
            </div>
          )}

          {/* ============================================================ */}
          {/* TAB 2: EXTENSIBLE CARD STATS & CALCULATED POWER RATING       */}
          {/* ============================================================ */}
          {activeTab === 'stats' && (
            <div className="space-y-4">
              {/* Power Rating HUD Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 via-black to-amber-950/20 border border-amber-500/40 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="space-y-1 text-center sm:text-start">
                  <div className="flex items-center justify-center sm:justify-start gap-2">
                    <Award size={16} className="text-amber-400" />
                    <span className="text-xs font-serif font-bold text-amber-200 uppercase tracking-wider">
                      Calculated Overall Rating: <span className="font-mono text-amber-300 font-black text-sm">{powerRating} OVR</span>
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-400">
                    Dynamically weighted by card rarity (<strong className="text-amber-300">{rarity}</strong>), {customStats.length} stats, and {abilities.filter(a => a.enabled !== false).length} active abilities.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleResetDefaultStats}
                    className="px-2.5 py-1 rounded-lg bg-stone-900 hover:bg-stone-800 text-[10px] font-mono text-stone-300 border border-white/10 cursor-pointer"
                  >
                    Reset Defaults
                  </button>
                  <button
                    type="button"
                    onClick={handleAddStat}
                    className="px-3 py-1 rounded-lg bg-amber-500/20 text-amber-300 hover:bg-amber-500 hover:text-stone-950 font-serif font-bold text-xs uppercase flex items-center gap-1 border border-amber-500/40 cursor-pointer transition-colors"
                  >
                    <Plus size={13} />
                    <span>Add Stat</span>
                  </button>
                </div>
              </div>

              {/* Stats List Editor */}
              <div className="space-y-2.5">
                {customStats.map((stat, idx) => {
                  const maxVal = stat.maxValue && stat.maxValue > 0 ? stat.maxValue : 100;
                  const pct = Math.min(100, Math.round(((stat.value || 0) / maxVal) * 100));

                  return (
                    <div
                      key={stat.id || idx}
                      className="p-3 rounded-2xl bg-stone-950/80 border border-white/10 hover:border-amber-500/30 transition-all space-y-2"
                    >
                      <div className="flex items-center justify-between gap-2">
                        {/* Stat Name */}
                        <div className="flex items-center gap-2 grow max-w-xs">
                          <input
                            type="text"
                            value={stat.name}
                            onChange={(e) => handleUpdateStat(idx, 'name', e.target.value)}
                            placeholder="Stat Name (e.g. Power, Speed)"
                            className="px-2.5 py-1 rounded-lg bg-stone-900 border border-stone-800 text-amber-200 font-serif font-bold text-xs w-full focus:outline-hidden focus:border-amber-500"
                          />
                        </div>

                        {/* Stat Value & Max */}
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1">
                            <span className="text-[10px] font-mono text-stone-400">VAL:</span>
                            <input
                              type="number"
                              min={0}
                              max={100}
                              value={Math.min(100, stat.value)}
                              onChange={(e) => handleUpdateStat(idx, 'value', Math.min(100, parseInt(e.target.value, 10) || 0))}
                              className="w-16 px-2 py-1 rounded-lg bg-stone-900 border border-stone-800 text-cyan-300 font-mono font-bold text-xs text-center"
                            />
                          </div>

                          <div className="flex items-center gap-1">
                            <span className="text-[10px] font-mono text-stone-400">MAX:</span>
                            <input
                              type="number"
                              min={1}
                              max={100}
                              value={Math.min(100, stat.maxValue ?? 100)}
                              onChange={(e) => handleUpdateStat(idx, 'maxValue', Math.min(100, parseInt(e.target.value, 10) || 100))}
                              className="w-16 px-2 py-1 rounded-lg bg-stone-900 border border-stone-800 text-stone-400 font-mono text-xs text-center"
                            />
                          </div>

                          <button
                            type="button"
                            onClick={() => handleRemoveStat(idx)}
                            className="p-1.5 rounded-lg text-stone-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer"
                            title="Remove Stat"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>

                      {/* Slider & Progress bar */}
                      <div className="flex items-center gap-3">
                        <input
                          type="range"
                          min={0}
                          max={maxVal}
                          value={stat.value}
                          onChange={(e) => handleUpdateStat(idx, 'value', parseInt(e.target.value, 10) || 0)}
                          className="grow accent-amber-500 h-1.5 bg-stone-900 rounded-lg cursor-pointer"
                        />
                        <span className="text-[10px] font-mono text-amber-400/80 w-10 text-end">
                          {pct}%
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Quick Preset Stat Suggestions */}
              <div className="pt-2 flex items-center gap-1.5 flex-wrap">
                <span className="text-[10px] font-mono text-stone-500">Quick add stat:</span>
                {['Power', 'Defense', 'Speed', 'Intelligence', 'Influence', 'Agility', 'Mana', 'Willpower'].map((namePreset) => {
                  const exists = customStats.some(s => s.name.toLowerCase() === namePreset.toLowerCase());
                  if (exists) return null;
                  return (
                    <button
                      key={namePreset}
                      type="button"
                      onClick={() => {
                        setCustomStats([
                          ...customStats,
                          { id: `stat_${Date.now()}_${namePreset.toLowerCase()}`, name: namePreset, value: 70, maxValue: 100 }
                        ]);
                      }}
                      className="px-2 py-0.5 rounded-md bg-stone-900 hover:bg-stone-800 border border-stone-800 text-[10px] font-mono text-stone-300 cursor-pointer"
                    >
                      + {namePreset}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* ============================================================ */}
          {/* TAB 3: STRUCTURED ABILITY SYSTEM                             */}
          {/* ============================================================ */}
          {activeTab === 'abilities' && (
            <div className="space-y-3.5">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold font-serif text-amber-200">
                    STRUCTURED ABILITY SYSTEM
                  </h4>
                  <p className="text-[11px] text-stone-400">
                    Extensible abilities with triggers, targets, duration, cooldowns, and activation states.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleAddAbility}
                  className="px-3 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500 hover:text-stone-950 font-serif font-bold text-xs uppercase flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Plus size={13} />
                  <span>Add Ability</span>
                </button>
              </div>

              {abilities.length === 0 ? (
                <div className="p-8 rounded-2xl bg-black/30 border border-dashed border-white/10 text-center space-y-2">
                  <Zap size={28} className="mx-auto text-amber-500/40" />
                  <p className="text-xs text-stone-400">
                    No structured abilities configured for this card yet.
                  </p>
                  <button
                    type="button"
                    onClick={handleAddAbility}
                    className="px-3 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-serif font-bold cursor-pointer"
                  >
                    Create First Ability
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {abilities.map((ability, idx) => {
                    const isEnabled = ability.enabled !== false;
                    return (
                      <div
                        key={ability.id || idx}
                        className={`p-3.5 rounded-2xl border transition-all space-y-2.5 ${
                          isEnabled
                            ? 'bg-stone-950/80 border-amber-900/40'
                            : 'bg-black/40 border-stone-800 opacity-60'
                        }`}
                      >
                        {/* Header Row */}
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2 grow">
                            <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-mono flex items-center justify-center font-bold shrink-0">
                              {idx + 1}
                            </span>
                            <input
                              type="text"
                              value={ability.name}
                              onChange={(e) => handleUpdateAbility(idx, 'name', e.target.value)}
                              placeholder="Ability Name"
                              className="px-2.5 py-1 rounded-lg bg-stone-900 border border-stone-800 text-amber-100 font-serif font-bold text-xs grow focus:outline-hidden focus:border-amber-500"
                            />
                          </div>

                          {/* Category Selector */}
                          <select
                            value={ability.type}
                            onChange={(e) => handleUpdateAbility(idx, 'type', e.target.value as AbilityCategory)}
                            className="px-2.5 py-1 rounded-lg bg-stone-900 border border-stone-800 text-amber-300 text-[11px] font-mono font-bold"
                          >
                            {ABILITY_CATEGORIES.map(cat => (
                              <option key={cat.type} value={cat.type}>{cat.label}</option>
                            ))}
                          </select>

                          {/* Enabled / Disabled Toggle */}
                          <button
                            type="button"
                            onClick={() => handleToggleAbility(idx)}
                            className={`px-2 py-1 rounded-lg text-[10px] font-mono font-bold cursor-pointer transition-colors ${
                              isEnabled
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : 'bg-stone-800 text-stone-500 border border-stone-700'
                            }`}
                          >
                            {isEnabled ? 'ACTIVE' : 'MUTED'}
                          </button>

                          <button
                            type="button"
                            onClick={() => handleRemoveAbility(idx)}
                            className="p-1 rounded-lg text-stone-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer"
                            title="Remove Ability"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>

                        {/* Description */}
                        <div>
                          <textarea
                            rows={2}
                            value={ability.description}
                            onChange={(e) => handleUpdateAbility(idx, 'description', e.target.value)}
                            placeholder="Detailed description of effect, battle triggers, and mechanical synergy..."
                            className="w-full px-2.5 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-stone-200 text-xs focus:outline-hidden focus:border-amber-500"
                          />
                        </div>

                        {/* Structured Properties Grid */}
                        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                          <div>
                            <label className="text-[9px] font-mono text-stone-400 uppercase block mb-0.5">Trigger</label>
                            <input
                              type="text"
                              value={ability.trigger ?? ''}
                              onChange={(e) => handleUpdateAbility(idx, 'trigger', e.target.value)}
                              placeholder="e.g. On Summon"
                              className="w-full px-2 py-1 rounded-md bg-stone-900 border border-stone-800 text-amber-300 font-mono text-[11px]"
                            />
                          </div>

                          <div>
                            <label className="text-[9px] font-mono text-stone-400 uppercase block mb-0.5">Target</label>
                            <input
                              type="text"
                              value={ability.target ?? ''}
                              onChange={(e) => handleUpdateAbility(idx, 'target', e.target.value)}
                              placeholder="e.g. Self, All Allies"
                              className="w-full px-2 py-1 rounded-md bg-stone-900 border border-stone-800 text-cyan-300 font-mono text-[11px]"
                            />
                          </div>

                          <div>
                            <label className="text-[9px] font-mono text-stone-400 uppercase block mb-0.5">Power Value</label>
                            <input
                              type="number"
                              value={ability.value ?? ability.powerValue ?? ''}
                              onChange={(e) => {
                                const val = parseInt(e.target.value, 10) || 0;
                                handleUpdateAbility(idx, 'value', val);
                                handleUpdateAbility(idx, 'powerValue', val);
                              }}
                              placeholder="120"
                              className="w-full px-2 py-1 rounded-md bg-stone-900 border border-stone-800 text-emerald-300 font-mono text-[11px]"
                            />
                          </div>

                          <div>
                            <label className="text-[9px] font-mono text-stone-400 uppercase block mb-0.5">Duration (Turns)</label>
                            <input
                              type="number"
                              value={ability.duration ?? ''}
                              onChange={(e) => handleUpdateAbility(idx, 'duration', parseInt(e.target.value, 10) || 0)}
                              placeholder="2"
                              className="w-full px-2 py-1 rounded-md bg-stone-900 border border-stone-800 text-yellow-300 font-mono text-[11px]"
                            />
                          </div>

                          <div>
                            <label className="text-[9px] font-mono text-stone-400 uppercase block mb-0.5">Cooldown (Turns)</label>
                            <input
                              type="number"
                              value={ability.cooldown ?? ''}
                              onChange={(e) => handleUpdateAbility(idx, 'cooldown', parseInt(e.target.value, 10) || 0)}
                              placeholder="3"
                              className="w-full px-2 py-1 rounded-md bg-stone-900 border border-stone-800 text-rose-300 font-mono text-[11px]"
                            />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ============================================================ */}
          {/* TAB 4: TEMPORARY CARD STATES (GAMEPLAY ARCHITECTURE)         */}
          {/* ============================================================ */}
          {activeTab === 'states' && (
            <div className="space-y-3.5">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold font-serif text-amber-200">
                    TEMPORARY CARD STATES ARCHITECTURE
                  </h4>
                  <p className="text-[11px] text-stone-400">
                    Prepare battle condition states: Normal, Buffed, Debuffed, Stunned, Protected, Exhausted, Hidden, Enraged.
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <select
                    onChange={(e) => {
                      if (e.target.value) {
                        handleAddState(e.target.value as CardStateType);
                        e.target.value = '';
                      }
                    }}
                    defaultValue=""
                    className="px-2.5 py-1.5 rounded-xl bg-stone-900 border border-stone-800 text-amber-200 text-xs font-mono cursor-pointer"
                  >
                    <option value="" disabled>+ Add State Preset...</option>
                    {CARD_STATE_PRESETS.map(p => (
                      <option key={p.type} value={p.type}>{p.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              {cardStates.length === 0 ? (
                <div className="p-8 rounded-2xl bg-black/30 border border-dashed border-white/10 text-center space-y-2">
                  <Activity size={28} className="mx-auto text-amber-500/40" />
                  <p className="text-xs text-stone-400">
                    No initial gameplay states attached. Choose a state preset from the dropdown above to add one.
                  </p>
                  <div className="flex flex-wrap justify-center gap-1.5 pt-2">
                    {CARD_STATE_PRESETS.slice(0, 4).map(p => (
                      <button
                        key={p.type}
                        type="button"
                        onClick={() => handleAddState(p.type)}
                        className="px-2 py-1 rounded-lg bg-stone-900 hover:bg-stone-800 border border-stone-800 text-[10px] font-mono text-stone-300 cursor-pointer"
                      >
                        + {p.label}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  {cardStates.map((st, idx) => (
                    <div
                      key={st.id || idx}
                      className="p-3.5 rounded-2xl bg-stone-950/80 border border-white/10 space-y-2.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] font-mono flex items-center justify-center font-bold">
                            {idx + 1}
                          </span>
                          <select
                            value={st.name}
                            onChange={(e) => handleUpdateState(idx, 'name', e.target.value)}
                            className="px-2.5 py-1 rounded-lg bg-stone-900 border border-stone-800 text-amber-200 font-mono font-bold text-xs"
                          >
                            {CARD_STATE_PRESETS.map(p => (
                              <option key={p.type} value={p.type}>{p.label}</option>
                            ))}
                          </select>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleToggleState(idx)}
                            className={`px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold cursor-pointer ${
                              st.active
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : 'bg-stone-800 text-stone-500 border border-stone-700'
                            }`}
                          >
                            {st.active ? 'ACTIVE' : 'INACTIVE'}
                          </button>

                          <button
                            type="button"
                            onClick={() => handleRemoveState(idx)}
                            className="p-1 rounded-lg text-stone-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer"
                            title="Remove State"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <div>
                          <label className="text-[9px] font-mono text-stone-400 uppercase block mb-0.5">Effect</label>
                          <input
                            type="text"
                            value={st.effect}
                            onChange={(e) => handleUpdateState(idx, 'effect', e.target.value)}
                            placeholder="State effect description..."
                            className="w-full px-2 py-1 rounded-md bg-stone-900 border border-stone-800 text-stone-200 text-xs"
                          />
                        </div>
                        <div>
                          <label className="text-[9px] font-mono text-stone-400 uppercase block mb-0.5">Duration (Turns, 0=Perm)</label>
                          <input
                            type="number"
                            value={st.duration}
                            onChange={(e) => handleUpdateState(idx, 'duration', parseInt(e.target.value, 10) || 0)}
                            className="w-full px-2 py-1 rounded-md bg-stone-900 border border-stone-800 text-yellow-300 font-mono text-xs"
                          />
                        </div>
                        <div>
                          <label className="text-[9px] font-mono text-stone-400 uppercase block mb-0.5">Value Modifier</label>
                          <input
                            type="number"
                            value={st.value ?? ''}
                            onChange={(e) => handleUpdateState(idx, 'value', parseInt(e.target.value, 10) || 0)}
                            placeholder="±25"
                            className="w-full px-2 py-1 rounded-md bg-stone-900 border border-stone-800 text-emerald-300 font-mono text-xs"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ============================================================ */}
          {/* TAB 5: MEDIA, ARTWORK, LEGENDARY VIDEO & FOIL                */}
          {/* ============================================================ */}
          {activeTab === 'media' && (
            <div className="space-y-4">
              {/* Card Face Artwork */}
              <div className="space-y-2 p-3.5 rounded-2xl bg-black/40 border border-white/5">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-mono uppercase text-amber-300 font-bold flex items-center gap-1.5">
                    <ImageIcon size={14} />
                    <span>Card Face Artwork *</span>
                  </label>
                  <label className="px-2.5 py-1 rounded-lg bg-stone-900 hover:bg-stone-800 border border-white/10 text-stone-300 text-[10px] font-serif uppercase cursor-pointer flex items-center gap-1">
                    <Upload size={11} />
                    <span>Upload Image</span>
                    <input type="file" accept="image/*" onChange={handleImageFileUpload} className="hidden" />
                  </label>
                </div>

                <input
                  type="text"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  placeholder="https://... image URL or upload file"
                  className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 font-mono text-xs focus:outline-hidden focus:border-amber-500"
                />

                {/* Presets */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[10px] text-stone-400 font-mono">Presets:</span>
                  {PRESET_ARTWORKS.map((p) => (
                    <button
                      key={p.label}
                      type="button"
                      onClick={() => setImageUrl(p.url)}
                      className="px-2 py-0.5 rounded-md bg-stone-900 hover:bg-stone-800 border border-stone-800 text-[10px] text-amber-200 cursor-pointer"
                    >
                      {p.label}
                    </button>
                  ))}
                </div>

                {imageUrl && (
                  <div className="mt-2 w-28 h-36 rounded-xl overflow-hidden border border-amber-500/40 bg-stone-950 relative">
                    <img src={imageUrl} alt="Card Preview" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>

              {/* Legendary Reveal Video */}
              <div className="space-y-2.5 p-3.5 rounded-2xl bg-amber-950/20 border border-amber-500/30">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Video size={16} className="text-amber-400" />
                    <div>
                      <span className="text-xs font-serif font-bold text-amber-100 block">
                        Legendary Reveal Animation / Video (Optional)
                      </span>
                      <span className="text-[10px] text-amber-300/80">
                        Plays a high-end cinematic animation sequence before the final Legendary card reveal.
                      </span>
                    </div>
                  </div>

                  <label className="px-2.5 py-1 rounded-lg bg-stone-900 hover:bg-stone-800 border border-amber-500/30 text-amber-200 text-[10px] font-serif uppercase cursor-pointer flex items-center gap-1">
                    <Upload size={11} />
                    <span>Upload Video</span>
                    <input type="file" accept="video/*" onChange={handleVideoFileUpload} className="hidden" />
                  </label>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={revealVideoUrl}
                    onChange={(e) => setRevealVideoUrl(e.target.value)}
                    placeholder="https://... YouTube, Vimeo, Streamable, Google Drive, MP4, WebM, MOV video URL"
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 font-mono text-xs focus:outline-hidden focus:border-amber-500"
                  />
                  {revealVideoUrl && (
                    <button
                      type="button"
                      onClick={() => setRevealVideoUrl('')}
                      className="p-2 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-500/30 cursor-pointer shrink-0"
                      title="Clear video"
                    >
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>

                {/* Preset Videos */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[10px] text-stone-400 font-mono">Sample Presets:</span>
                  {PRESET_VIDEOS.map((v) => (
                    <button
                      key={v.label}
                      type="button"
                      onClick={() => setRevealVideoUrl(v.url)}
                      className="px-2 py-0.5 rounded-md bg-amber-950/40 hover:bg-amber-900/60 border border-amber-500/30 text-[10px] text-amber-200 cursor-pointer"
                    >
                      {v.label}
                    </button>
                  ))}
                </div>

                {revealVideoUrl && (
                  <div className="mt-2 rounded-xl overflow-hidden border border-amber-500/50 bg-black aspect-video max-w-sm">
                    {(() => {
                      const parsed = parseUniversalVideoUrl(revealVideoUrl);
                      if (parsed?.isIframe) {
                        return (
                          <iframe
                            src={parsed.embedUrl}
                            title="Reveal Video Preview"
                            className="w-full h-full border-0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                          />
                        );
                      }
                      return (
                        <video
                          key={parsed?.directUrl || revealVideoUrl}
                          src={parsed?.directUrl || revealVideoUrl}
                          controls
                          playsInline
                          muted
                          className="w-full h-full object-cover"
                        />
                      );
                    })()}
                  </div>
                )}
              </div>

              {/* Foil Finish & Accent Color */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 rounded-2xl bg-black/40 border border-white/5">
                <div>
                  <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                    Visual Foil Finish
                  </label>
                  <select
                    value={foilStyle}
                    onChange={(e) => setFoilStyle(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 focus:outline-hidden focus:border-amber-500"
                  >
                    <option value="standard">Standard Matte Foil</option>
                    <option value="holographic">Prismatic Holographic Sheen</option>
                    <option value="cosmic">Cosmic Starlight Glimmer</option>
                    <option value="gold_embossed">24k Gold Inscribed Relief</option>
                  </select>
                </div>

                {rarity === 'LEGENDARY' ? (
                  <div>
                    <label className="text-[11px] font-mono uppercase text-amber-300 font-bold block mb-1">
                      Accent Color Theme
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={accentColor}
                        onChange={(e) => setAccentColor(e.target.value)}
                        className="w-9 h-9 rounded-xl bg-transparent border border-white/20 cursor-pointer p-0.5"
                      />
                      <input
                        type="text"
                        value={accentColor}
                        onChange={(e) => setAccentColor(e.target.value)}
                        className="px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-amber-100 font-mono text-xs grow"
                      />
                    </div>
                  </div>
                ) : (
                  <div>
                    <label className="text-[11px] font-mono uppercase text-stone-400 font-bold block mb-1">
                      Accent Color Theme ({rarity})
                    </label>
                    <div className="flex items-center justify-between p-2 rounded-xl bg-stone-900 border border-white/10">
                      <div className="flex items-center gap-2">
                        <span
                          className="w-4 h-4 rounded-full shrink-0 shadow-xs border border-white/20"
                          style={{ backgroundColor: getRarityMaterialConfig(rarity).primaryColor }}
                        />
                        <span className="text-xs font-mono font-bold text-stone-300">
                          {getRarityMaterialConfig(rarity).primaryColor}
                        </span>
                      </div>
                      <span className="text-[9px] font-mono text-stone-500">
                        Locked to Rarity
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Form Footer Action Buttons */}
          <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-stone-900 text-stone-400 hover:text-white font-serif font-bold text-xs uppercase cursor-pointer"
              >
                Cancel
              </button>
              {cardToEdit && (
                <button
                  type="button"
                  disabled={isDeleting || isSubmitting}
                  onClick={handleDeleteThisCard}
                  className="px-3.5 py-2 rounded-xl bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border border-rose-500/40 font-serif font-bold text-xs uppercase flex items-center gap-1.5 cursor-pointer disabled:opacity-50 transition-all active:scale-95"
                  title="Delete/deactivate this card"
                >
                  <Trash2 size={13} />
                  <span>{isDeleting ? 'Deleting...' : 'Delete Card'}</span>
                </button>
              )}
            </div>
            <button
              type="submit"
              disabled={isSubmitting || isDeleting}
              className="px-6 py-2.5 rounded-xl font-bold font-serif text-xs uppercase bg-gradient-to-r from-amber-500 to-yellow-500 hover:brightness-110 text-stone-950 flex items-center gap-2 shadow-lg shadow-amber-500/20 cursor-pointer disabled:opacity-50"
            >
              <Sparkles size={14} />
              <span>{isSubmitting ? 'Forging Relic...' : 'SAVE CARD TO CATALOG'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
