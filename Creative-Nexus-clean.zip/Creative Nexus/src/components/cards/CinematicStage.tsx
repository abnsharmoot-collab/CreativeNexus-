import React, { useMemo } from 'react';

interface CinematicStageProps {
  accent: string;
  intense?: boolean;
}

/**
 * Cinematic backdrop for a displayed card: top spotlight, rising embers,
 * floor glow, vignette and an opening light flash. Purely decorative.
 */
export const CinematicStage: React.FC<CinematicStageProps> = ({ accent, intense = false }) => {
  const embers = useMemo(
    () =>
      Array.from({ length: intense ? 22 : 14 }, (_, i) => ({
        left: Math.round(((i * 37) % 100) + (i % 3)),
        size: 2 + (i % 4),
        delay: (i * 0.7) % 6,
        dur: 5 + (i % 5),
        drift: ((i % 5) - 2) * 14,
      })),
    [intense]
  );

  return (
    <div aria-hidden="true" className="absolute inset-0 pointer-events-none overflow-hidden rounded-[inherit] cin-stage" style={{ zIndex: -1 }}>
      <style>{`
        @keyframes cinBeam{0%,100%{opacity:.55}50%{opacity:.95}}
        @keyframes cinEmber{0%{transform:translate3d(0,20px,0);opacity:0}15%{opacity:.9}100%{transform:translate3d(var(--dx),-340px,0);opacity:0}}
        @keyframes cinFlash{0%{opacity:.9}100%{opacity:0}}
        @keyframes cinFloat{0%,100%{transform:scaleX(1);opacity:.7}50%{transform:scaleX(.9);opacity:.45}}
        @media (prefers-reduced-motion: reduce){.cin-stage *{animation:none!important}}
      `}</style>

      {/* spotlight cone from above */}
      <div
        className="absolute left-1/2 -top-6 w-[130%] h-[75%] -translate-x-1/2"
        style={{
          background: `conic-gradient(from 180deg at 50% 0%, transparent 150deg, ${accent}55 172deg, ${accent}99 180deg, ${accent}55 188deg, transparent 210deg)`,
          filter: 'blur(14px)',
          mixBlendMode: 'screen',
          animation: 'cinBeam 5s ease-in-out infinite',
        }}
      />

      {/* floor glow */}
      <div
        className="absolute left-1/2 bottom-2 w-[72%] h-10 -translate-x-1/2 rounded-[50%]"
        style={{
          background: `radial-gradient(ellipse at center, ${accent}aa 0%, transparent 70%)`,
          filter: 'blur(10px)',
          animation: 'cinFloat 4s ease-in-out infinite',
        }}
      />

      {/* embers */}
      {embers.map((e, i) => (
        <span
          key={i}
          className="absolute bottom-6 rounded-full"
          style={{
            left: `${e.left}%`,
            width: e.size,
            height: e.size,
            background: accent,
            boxShadow: `0 0 ${e.size * 3}px ${accent}`,
            ['--dx' as any]: `${e.drift}px`,
            animation: `cinEmber ${e.dur}s linear ${e.delay}s infinite`,
            opacity: 0,
          }}
        />
      ))}

      {/* vignette */}
      <div
        className="absolute inset-0"
        style={{ background: 'radial-gradient(ellipse at 50% 45%, transparent 45%, rgba(0,0,0,0.75) 100%)' }}
      />

      {/* opening flash */}
      <div
        className="absolute inset-0"
        style={{
          background: `radial-gradient(circle at 50% 40%, #fff 0%, ${accent}99 35%, transparent 70%)`,
          mixBlendMode: 'screen',
          animation: 'cinFlash 0.9s ease-out forwards',
        }}
      />
    </div>
  );
};
