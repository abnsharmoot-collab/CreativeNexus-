import React, { useRef, useState, useEffect } from 'react';
import { PackDefinition } from '../../types/cards';
import { useScroll3DTilt } from '../../hooks/useScroll3DTilt';
import { Sparkles, Coins, ArrowRight, Zap } from 'lucide-react';
import { MODERN_CARD_ASSETS } from '../../assets/modernCardAssets';
import { easterEggSound } from '../../utils/easterEggAudio';

interface PackItemCardProps {
  pack: PackDefinition;
  userCoins: number;
  onOpenPack: (pack: PackDefinition) => void;
  isLoading?: boolean;
  onShowOdds?: (pack: PackDefinition) => void;
  layoutMode?: 'hero' | 'grid';
}

const PACK_LOCAL_IMAGES: Record<string, string> = {
  COMMON: MODERN_CARD_ASSETS.packCommonApex,
  UNCOMMON: MODERN_CARD_ASSETS.packUncommonPrism,
  RARE: MODERN_CARD_ASSETS.packRareAzure,
  EPIC: MODERN_CARD_ASSETS.packEpicHyperion,
  LEGENDARY: MODERN_CARD_ASSETS.packLegendarySovereign,
};

const TIER_ACCENTS: Record<string, {
  name: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  borderClass: string;
  innerBorder: string;
  cornerAccent: string;
  glowHex: string;
  titleGradient: string;
  buttonGrad: string;
  foilGrad: string;
  accentColor: string;
  editionTag: string;
  romanNumeral: string;
}> = {
  COMMON: {
    name: 'Genesis Core',
    badgeBg: 'bg-black/65',
    badgeText: 'text-zinc-300',
    badgeBorder: 'border-zinc-500/40',
    borderClass: 'border-zinc-600/35 hover:border-zinc-400/80',
    innerBorder: 'border-zinc-500/20',
    cornerAccent: 'rgba(156, 163, 175, 0.4)',
    glowHex: '#9ca3af',
    titleGradient: 'from-zinc-100 via-zinc-200 to-zinc-400',
    buttonGrad: 'from-zinc-400 via-zinc-300 to-zinc-500 text-stone-950 font-black',
    foilGrad: 'from-[#18181b]/96 via-slate-950/92 to-[#09090b]/98',
    accentColor: '#9ca3af',
    editionTag: 'STANDARD // 01',
    romanNumeral: 'I',
  },
  UNCOMMON: {
    name: 'Prism Emerald',
    badgeBg: 'bg-black/65',
    badgeText: 'text-emerald-300',
    badgeBorder: 'border-emerald-500/40',
    borderClass: 'border-emerald-600/35 hover:border-emerald-400/80',
    innerBorder: 'border-emerald-500/20',
    cornerAccent: 'rgba(16, 185, 129, 0.4)',
    glowHex: '#10b981',
    titleGradient: 'from-emerald-100 via-emerald-200 to-teal-300',
    buttonGrad: 'from-emerald-500 via-teal-400 to-emerald-600 text-stone-950 font-black',
    foilGrad: 'from-[#041a12]/96 via-slate-950/92 to-[#020e0a]/98',
    accentColor: '#10b981',
    editionTag: 'VANGUARD // 02',
    romanNumeral: 'II',
  },
  RARE: {
    name: 'Quantum Azure',
    badgeBg: 'bg-black/65',
    badgeText: 'text-[#5eead4]',
    badgeBorder: 'border-cyan-500/40',
    borderClass: 'border-cyan-600/35 hover:border-cyan-400/80',
    innerBorder: 'border-cyan-500/20',
    cornerAccent: 'rgba(6, 182, 212, 0.45)',
    glowHex: '#06b6d4',
    titleGradient: 'from-cyan-100 via-cyan-200 to-teal-200',
    buttonGrad: 'from-[#14b8a6] via-[#5eead4] to-[#0d9488] text-stone-950 font-black',
    foilGrad: 'from-[#051926]/96 via-slate-950/92 to-[#020d14]/98',
    accentColor: '#06b6d4',
    editionTag: 'CHRONO // 03',
    romanNumeral: 'III',
  },
  EPIC: {
    name: 'Hyperion Violet',
    badgeBg: 'bg-black/65',
    badgeText: 'text-purple-300',
    badgeBorder: 'border-purple-500/40',
    borderClass: 'border-purple-600/35 hover:border-purple-400/80',
    innerBorder: 'border-purple-500/25',
    cornerAccent: 'rgba(168, 85, 247, 0.5)',
    glowHex: '#a855f7',
    titleGradient: 'from-purple-100 via-fuchsia-200 to-purple-300',
    buttonGrad: 'from-purple-600 via-fuchsia-400 to-purple-700 text-white font-black',
    foilGrad: 'from-[#1a082b]/96 via-slate-950/92 to-[#0b0314]/98',
    accentColor: '#a855f7',
    editionTag: 'SINGULARITY // 04',
    romanNumeral: 'IV',
  },
  LEGENDARY: {
    name: 'Sovereign Solar',
    badgeBg: 'bg-amber-950/85',
    badgeText: 'text-amber-200',
    badgeBorder: 'border-amber-400/80 shadow-[0_0_12px_rgba(245,158,11,0.5)]',
    borderClass: 'border-amber-400/85 hover:border-yellow-300 shadow-[0_0_26px_rgba(245,158,11,0.38)]',
    innerBorder: 'border-amber-400/45',
    cornerAccent: 'rgba(251, 191, 36, 0.7)',
    glowHex: '#f59e0b',
    titleGradient: 'from-yellow-100 via-amber-200 to-amber-400',
    buttonGrad: 'from-amber-400 via-yellow-200 to-amber-500 text-stone-950 font-black shadow-lg shadow-amber-500/30',
    foilGrad: 'from-[#2a1703]/98 via-slate-950/94 to-[#0f0701]/98',
    accentColor: '#f59e0b',
    editionTag: 'SOVEREIGN // 05',
    romanNumeral: 'V',
  },
};

export const PackItemCard: React.FC<PackItemCardProps> = ({
  pack,
  userCoins,
  onOpenPack,
  isLoading = false,
  onShowOdds,
  layoutMode = 'grid',
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [hoverRotateX, setHoverRotateX] = useState(0);
  const [hoverRotateY, setHoverRotateY] = useState(0);
  const [hoverGlarePos, setHoverGlarePos] = useState({ x: 50, y: 30 });
  const [isHovered, setIsHovered] = useState(false);
  const [imageFailed, setImageFailed] = useState(false);
  const prefersReducedMotion = useRef(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
      prefersReducedMotion.current = mq.matches;
      const onChange = (e: MediaQueryListEvent) => {
        prefersReducedMotion.current = e.matches;
      };
      mq.addEventListener('change', onChange);
      return () => mq.removeEventListener('change', onChange);
    }
  }, []);

  const canAfford = userCoins >= pack.price;
  const tier = TIER_ACCENTS[pack.rarity] || TIER_ACCENTS.COMMON;
  const isLegendary = pack.rarity === 'LEGENDARY';

  // Resolve pack image
  const packImage = imageFailed
    ? (PACK_LOCAL_IMAGES[pack.rarity] || MODERN_CARD_ASSETS.packCommonApex)
    : (pack.imageUrl || PACK_LOCAL_IMAGES[pack.rarity] || MODERN_CARD_ASSETS.packCommonApex);

  const scrollTilt = useScroll3DTilt({
    cardRef,
    isHovered,
    hoverRotateX,
    hoverRotateY,
    maxTiltX: 2.8,
    maxTiltY: 1.8,
    accentColorHex: tier.accentColor,
    glowIntensity: isLegendary ? 0.8 : 0.45,
    enabled: true,
  });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (prefersReducedMotion.current || !cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotX = ((y - centerY) / centerY) * -2.8;
    const rotY = ((x - centerX) / centerX) * 2.8;
    setHoverRotateX(rotX);
    setHoverRotateY(rotY);

    const glareX = Math.round((x / rect.width) * 100);
    const glareY = Math.round((y / rect.height) * 100);
    setHoverGlarePos({ x: glareX, y: glareY });
  };

  const handleMouseEnter = () => {
    if (prefersReducedMotion.current) return;
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setHoverRotateX(0);
    setHoverRotateY(0);
    setHoverGlarePos({ x: 50, y: 30 });
  };

  const currentRotateX = isHovered ? hoverRotateX : scrollTilt.rotateX;
  const currentRotateY = isHovered ? hoverRotateY : scrollTilt.rotateY;
  const currentGlare = isHovered ? hoverGlarePos : scrollTilt.glarePos;

  const handleActionClick = () => {
    if (canAfford && !isLoading) {
      try {
        easterEggSound.playAccessGrantedSound();
      } catch {}
      onOpenPack(pack);
    }
  };

  // Dynamic box shadow reflecting Owner Card depth
  const dynamicBoxShadow = isHovered
    ? `0 30px 70px rgba(0,0,0,0.95), 0 0 ${isLegendary ? '45px' : '28px'} ${tier.glowHex}${isLegendary ? '88' : '40'}, inset 0 1px 1px rgba(255,255,255,0.25)`
    : `0 14px 35px -8px rgba(0,0,0,0.9), 0 0 18px ${tier.glowHex}25, inset 0 1px 1px rgba(255,255,255,0.12)`;

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className="relative group select-none flex flex-col w-full max-w-[320px] sm:max-w-[330px] md:max-w-[340px] mx-auto min-w-0 box-border transform-gpu min-h-[500px] sm:min-h-[530px] active:scale-[0.98]"
      style={{
        boxSizing: 'border-box',
        perspective: '1200px',
        transform: isHovered
          ? (prefersReducedMotion.current ? 'none' : `perspective(1200px) rotateX(${hoverRotateX}deg) rotateY(${hoverRotateY}deg) translateY(-4px) scale3d(1.015, 1.015, 1.015)`)
          : scrollTilt.transform,
        transformStyle: 'preserve-3d',
        transition: isHovered ? 'transform 0.1s ease-out' : 'transform 0.35s cubic-bezier(0.16, 1, 0.3, 1)',
        willChange: 'transform, filter, box-shadow',
      }}
    >
      {/* 1. Ambient Halo Glow (Matching Owner Cards) */}
      <div
        className="absolute inset-0 rounded-[2.2rem] opacity-40 group-hover:opacity-100 transition-opacity duration-500 blur-2xl pointer-events-none -z-10"
        style={{
          background: `radial-gradient(circle at ${currentGlare.x}% ${currentGlare.y}%, ${tier.glowHex}70, transparent 70%)`,
        }}
      />

      {/* 2. Booster Pack Card Shell (Luxury Glass & Foiled Reliquary Chassis) */}
      <div
        className={`relative h-full flex flex-col justify-between rounded-[2rem] sm:rounded-[2.2rem] border ${tier.borderClass} ${tier.foilGrad} overflow-hidden shadow-2xl backdrop-blur-md transition-all duration-300 w-full min-w-0 box-border owner-card-depth-surface`}
        style={{
          boxShadow: dynamicBoxShadow,
        }}
      >
        {/* Top Foil Metallic Edge Bar (Clean Crimped Foil, No Words) */}
        <div className="relative h-3.5 w-full bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-b border-white/[0.08] flex items-center justify-center gap-1.5 px-3 overflow-hidden shrink-0 z-30">
          <div className="flex items-center gap-1.5 opacity-40">
            <span className="w-1 h-1 rounded-full bg-white/60" />
            <span className="w-6 h-[1px] bg-gradient-to-r from-transparent via-white/40 to-transparent" />
            <span className="w-1.5 h-1.5 rounded-full bg-white/70" />
            <span className="w-6 h-[1px] bg-gradient-to-r from-transparent via-white/40 to-transparent" />
            <span className="w-1 h-1 rounded-full bg-white/60" />
          </div>
        </div>

        {/* Top Metallic Bevel Highlight */}
        <div
          className="absolute top-0 inset-x-0 h-[2px] pointer-events-none z-30 transition-all duration-300"
          style={{
            background: isHovered
              ? 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.9) 50%, transparent 100%)'
              : 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.45) 50%, transparent 100%)',
            boxShadow: isHovered ? '0 0 14px rgba(255,255,255,0.7)' : 'none',
          }}
          aria-hidden="true"
        />

        {/* Dynamic Prismatic Light Sweep */}
        <div
          className="absolute inset-0 pointer-events-none z-20 mix-blend-overlay transition-opacity duration-300"
          style={{
            opacity: isHovered ? 0.45 : 0.15,
            background: `radial-gradient(circle at ${currentGlare.x}% ${currentGlare.y}%, rgba(255,255,255,0.95) 0%, transparent 60%)`,
          }}
        />

        {/* Delicate Inner Archival Inset Frame (Double-Bevel Relic Chassis) */}
        <div
          className={`absolute inset-2 sm:inset-2.5 rounded-[1.6rem] sm:rounded-[1.75rem] border ${tier.innerBorder} pointer-events-none z-20 transition-all duration-300`}
          aria-hidden="true"
        />

        {/* 3. Full-Height Pack Artwork Canvas (Continuous Portrait) */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          <img
            src={packImage}
            alt={pack.name}
            onError={() => setImageFailed(true)}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center filter brightness-95 contrast-105 saturate-110 group-hover:scale-105 transition-transform duration-700 ease-out"
            loading="lazy"
          />
          {/* Cinematic Vignette */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/35 to-slate-950/55 pointer-events-none" />
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: `radial-gradient(circle at 50% 30%, transparent 35%, rgba(2, 7, 9, 0.72) 100%)`
            }}
          />
        </div>

        {/* 4. Top Floating Row: Enhanced Luxury Price Plaque */}
        <div
          className="relative z-20 p-3 sm:p-4 pb-1 flex items-center justify-end min-w-0"
          style={{
            transform: isHovered && !prefersReducedMotion.current ? 'translateZ(20px)' : 'translateZ(10px)',
            transition: 'transform 0.35s ease-out',
          }}
        >
          {/* Enhanced Luxury Golden Price Plaque */}
          <div className="relative group/price flex items-center gap-2 bg-gradient-to-r from-stone-950/90 via-[#181205]/95 to-stone-950/90 backdrop-blur-xl border border-amber-400/50 hover:border-amber-300 px-3.5 py-1.5 rounded-2xl shadow-[0_4px_20px_rgba(0,0,0,0.85),0_0_16px_rgba(245,158,11,0.22)] transition-all duration-300 shrink-0">
            {/* Ambient gold glow pill behind */}
            <div className="absolute inset-0 rounded-2xl bg-amber-500/10 group-hover/price:bg-amber-500/20 blur-xs pointer-events-none transition-all" />
            
            {/* Radiant Medallion Icon */}
            <div className="relative w-5 h-5 rounded-full bg-gradient-to-br from-yellow-300 via-amber-400 to-amber-600 flex items-center justify-center shadow-[0_0_10px_rgba(251,191,36,0.6)] border border-yellow-200/90 shrink-0">
              <span className="text-[11px] leading-none select-none drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">🪙</span>
            </div>

            {/* Price Digits */}
            <div className="relative flex items-baseline gap-1">
              <span className="font-display font-black text-sm sm:text-base tracking-tight bg-gradient-to-b from-amber-100 via-amber-300 to-yellow-500 bg-clip-text text-transparent drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                {pack.price}
              </span>
              <span className="text-[9px] font-mono font-extrabold tracking-widest text-amber-300/80 uppercase">
                COINS
              </span>
            </div>
          </div>
        </div>

        {/* Middle Spacer for artwork visibility */}
        <div className="relative z-10 flex-1 min-h-[140px] sm:min-h-[180px]" />

        {/* 5. Bottom Frosted Glass Shelf (Matches Owner Card reference) */}
        <div
          className="relative z-20 pt-6 pb-4 sm:pb-5 px-5 sm:px-6 bg-gradient-to-t from-slate-950 via-slate-950/92 to-transparent border-t border-white/[0.05] backdrop-blur-[3px] space-y-3 min-w-0"
          style={{
            transform: isHovered && !prefersReducedMotion.current ? 'translateZ(18px)' : 'translateZ(10px)',
            transition: 'transform 0.35s ease-out',
          }}
        >
          {/* Pack Title */}
          <div className="text-center mb-0.5">
            <h3 className={`font-display font-extrabold text-lg sm:text-xl text-transparent bg-clip-text bg-gradient-to-r ${tier.titleGradient} tracking-wide drop-shadow-[0_2px_12px_rgba(0,0,0,0.9)] truncate`}>
              {pack.name}
            </h3>
          </div>

          {/* Scarcity: Concise words, no verbose chatter */}
          <div className="text-center py-0.5">
            <span className={`text-[11px] sm:text-xs font-mono tracking-widest uppercase font-medium ${
              pack.rarity === 'COMMON' ? 'text-zinc-300' : 'text-amber-200/90'
            }`}>
              {pack.rarity === 'COMMON'
                ? 'Foundational Artifact'
                : pack.rarity === 'UNCOMMON'
                ? 'High-Yield Relic'
                : pack.rarity === 'RARE'
                ? 'Celestial Relic'
                : pack.rarity === 'EPIC'
                ? 'Singularity Class'
                : 'Supreme Sovereign Relic'}
            </span>
          </div>

          {/* Purchase / Unseal Button */}
          <button
            type="button"
            disabled={!canAfford || isLoading}
            onClick={handleActionClick}
            className={`w-full py-2.5 px-3 rounded-xl font-display font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md disabled:cursor-not-allowed disabled:opacity-45 ${
              canAfford
                ? `bg-gradient-to-r ${tier.buttonGrad} hover:brightness-110 active:scale-95`
                : 'bg-slate-900 text-slate-500 border border-white/5'
            }`}
          >
            {isLoading ? (
              <>
                <Sparkles size={14} className="animate-spin" />
                <span>Unsealing Reliquary...</span>
              </>
            ) : canAfford ? (
              <>
                <Zap size={14} />
                <span>Unseal Reliquary</span>
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </>
            ) : (
              <>
                <Coins size={14} />
                <span>Need {pack.price - userCoins} more coins</span>
              </>
            )}
          </button>

          {/* Secondary Actions: View Odds */}
          {onShowOdds && (
            <div className="pt-0.5">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onShowOdds(pack);
                }}
                className="w-full py-1.5 px-3 rounded-xl bg-black/40 hover:bg-black/70 text-stone-300 hover:text-[#5eead4] border border-white/10 hover:border-[#5eead4]/40 text-[11px] font-mono flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs"
                title="Inspect Drop Probabilities"
              >
                <span>Drop Rates & Chances</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};


