import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  PackDefinition,
  PackOpenResult,
  CollectibleCardData,
  CardRarity,
  calculateCardPowerRating,
  calculateCardOverallRating,
  getUnifiedCardStats,
  PackRewardItem,
} from '../../types/cards';
import { CollectibleCard } from './CollectibleCard';
import { useCards } from '../../context/CardContext';
import { useItems } from '../../context/ItemContext';
import { useLanguage } from '../../context/LanguageContext';
import { UnifiedItemDefinition } from '../../types/items';
import { BrawlStarsItemDisplay } from '../items/BrawlStarsItemDisplay';
import { ItemRevealStage } from '../items/ItemRevealStage';
import { MODERN_CARD_ASSETS } from '../../assets/modernCardAssets';
import { MESOPOTAMIAN_ASSETS } from '../../assets/mesopotamianAssets';
import {
  X,
  Eye,
  Star,
  RotateCcw,
  Check,
  FastForward,
  Volume2,
  VolumeX,
  Scissors,
  ChevronRight,
  ChevronLeft
} from 'lucide-react';
import {
  RevealSfxConfig,
  DEFAULT_SFX_CONFIG,
  playRevealSound,
  playPowerCountTick,
  playPowerLockBoom,
  playColorRollTick,
  playColorLock,
  playChargeTremor,
  playCardRevealBoom
} from '../../utils/cardRevealAudio';
import { parseUniversalVideoUrl } from '../../utils/videoHelpers';

interface PackOpeningModalProps {
  isOpen: boolean;
  pack: PackDefinition | null;
  result: PackOpenResult | null;
  userCoins: number;
  onClose: () => void;
  onOpenAnother: (pack: PackDefinition) => void;
  onInspectCard: (card: CollectibleCardData) => void;
}

// Visual stages:
// 1. STAGE_READY_TO_CUT: Pack enters and waits for interactive scissors slide
// 2. STAGE_CUT: Razor laser slices across, top cap flies off dramatically, bottom sleeve tears open, card pulls up
// 3. STAGE_COLOR_ROLL: Card color changes and rolls quickly before stopping at rarity color
// 4. STAGE_POWER_SCAN: Then power shows (standalone 0 to 100 scanner with boom, guaranteed stop)
// 5. STAGE_RARITY_REVEAL: Typographic rarity announcement (zero icons)
// 6. STAGE_VIDEO: (For Legendary with video) Plays video, visual fades out 5s before end while audio keeps playing
// 7. STAGE_SHAKE_REVEAL: (For Epic and Legendary only) Flat black card with no logo shakes hard, then BOOM!
// 8. STAGE_PRESENT: Interactive 3D tilt presentation with actions & discovery feedback
// 9. STAGE_ITEM_REVEAL: Dedicated separate reward reveal for bonus items one by one
export type PackRevealStage =
  | 'STAGE_READY_TO_CUT'
  | 'STAGE_CUT'
  | 'STAGE_COLOR_ROLL'
  | 'STAGE_POWER_SCAN'
  | 'STAGE_RARITY_REVEAL'
  | 'STAGE_VIDEO'
  | 'STAGE_SHAKE_REVEAL'
  | 'STAGE_PRESENT'
  | 'STAGE_ITEM_REVEAL';

// Dedicated unseal relic booster packs
const UNSEAL_PACK_IMAGES: Record<CardRarity, string> = {
  COMMON: MODERN_CARD_ASSETS.packCommonApex,
  UNCOMMON: MESOPOTAMIAN_ASSETS.packUncommonJade,
  RARE: MESOPOTAMIAN_ASSETS.packRareLapis,
  EPIC: MESOPOTAMIAN_ASSETS.packEpicAmethyst,
  LEGENDARY: MESOPOTAMIAN_ASSETS.packLegendaryGold,
  HALLOWEEN_2026: MESOPOTAMIAN_ASSETS.packLegendaryGold,
};

// Rarity theme palettes and styling
export interface RarityShowcaseSpec {
  name: CardRarity;
  tierLabel: string;
  subtext: string;
  accent: string;
  bright: string;
  glow: string;
  gradient: string;
  bgGlow: string;
  numeral: string;
  colorSpectrum: string[];
}

export const RARITY_SHOWCASE: Record<CardRarity, RarityShowcaseSpec> = {
  COMMON: {
    name: 'COMMON',
    tierLabel: 'TIER I',
    subtext: 'STANDARD CHRONICLE SPECIMEN',
    accent: '#9ca3af',
    bright: '#e5e7eb',
    glow: 'rgba(156, 163, 175, 0.55)',
    gradient: 'from-zinc-200 via-zinc-400 to-zinc-600',
    bgGlow: 'rgba(156, 163, 175, 0.3)',
    numeral: 'I',
    colorSpectrum: ['#4b5563', '#6b7280', '#9ca3af', '#d1d5db', '#f3f4f6']
  },
  UNCOMMON: {
    name: 'UNCOMMON',
    tierLabel: 'TIER II',
    subtext: 'EMERALD VANGUARD RELIC',
    accent: '#059669',
    bright: '#34d399',
    glow: 'rgba(5, 150, 105, 0.55)',
    gradient: 'from-emerald-200 via-emerald-400 to-teal-600',
    bgGlow: 'rgba(5, 150, 105, 0.3)',
    numeral: 'II',
    colorSpectrum: ['#047857', '#059669', '#10b981', '#34d399', '#6ee7b7']
  },
  RARE: {
    name: 'RARE',
    tierLabel: 'TIER III',
    subtext: 'AZURE CHRONO ANOMALY',
    accent: '#0284c7',
    bright: '#38bdf8',
    glow: 'rgba(2, 132, 199, 0.65)',
    gradient: 'from-sky-200 via-cyan-400 to-blue-600',
    bgGlow: 'rgba(2, 132, 199, 0.35)',
    numeral: 'III',
    colorSpectrum: ['#0369a1', '#0284c7', '#0ea5e9', '#38bdf8', '#7dd3fc']
  },
  EPIC: {
    name: 'EPIC',
    tierLabel: 'TIER IV',
    subtext: 'AMETHYST HYPERION ARTIFACT',
    accent: '#7c3aed',
    bright: '#a78bfa',
    glow: 'rgba(124, 58, 237, 0.75)',
    gradient: 'from-purple-200 via-fuchsia-400 to-indigo-600',
    bgGlow: 'rgba(124, 58, 237, 0.4)',
    numeral: 'IV',
    colorSpectrum: ['#6d28d9', '#7c3aed', '#8b5cf6', '#a78bfa', '#c4b5fd']
  },
  LEGENDARY: {
    name: 'LEGENDARY',
    tierLabel: 'TIER V',
    subtext: 'SOVEREIGN CELESTIAL CROWN',
    accent: '#eab308',
    bright: '#fde047',
    glow: 'rgba(234, 179, 8, 0.95)',
    gradient: 'from-yellow-100 via-amber-300 to-yellow-500',
    bgGlow: 'rgba(234, 179, 8, 0.55)',
    numeral: 'V',
    colorSpectrum: ['#ca8a04', '#eab308', '#facc15', '#fde047', '#fef08a']
  },
  HALLOWEEN_2026: {
    name: 'HALLOWEEN_2026',
    tierLabel: 'TIER MYTHIC',
    subtext: 'BLOOD MOON WITCHFIRE SPECTER',
    accent: '#ff5e00',
    bright: '#ff9900',
    glow: 'rgba(255, 94, 0, 0.95)',
    gradient: 'from-orange-400 via-purple-500 to-amber-600',
    bgGlow: 'rgba(168, 85, 247, 0.6)',
    numeral: 'M',
    colorSpectrum: ['#ff5e00', '#b026ff', '#f59e0b', '#7c3aed', '#ffaa00']
  }
};

interface MysteryCardBackProps {
  activeRarity: CardRarity;
  isRolling: boolean;
  isLocked: boolean;
  customBackImageUrl?: string;
}

const RARITY_FLAT_PALETTES: Record<CardRarity, {
  surface: string;
  glow: string;
  bgGlow: string;
  emblemLight: string;
  emblemBase: string;
}> = {
  COMMON: {
    surface: 'radial-gradient(circle at 50% 50%, #4b5563 0%, #374151 55%, #18181b 100%)',
    glow: 'rgba(209, 213, 219, 0.6)',
    bgGlow: 'rgba(156, 163, 175, 0.35)',
    emblemLight: '#f3f4f6',
    emblemBase: '#9ca3af',
  },
  UNCOMMON: {
    surface: 'radial-gradient(circle at 50% 50%, #059669 0%, #064e3b 55%, #022019 100%)',
    glow: 'rgba(168, 185, 129, 0.85)',
    bgGlow: 'rgba(5, 150, 105, 0.4)',
    emblemLight: '#d1fae5',
    emblemBase: '#10b981',
  },
  RARE: {
    surface: 'radial-gradient(circle at 50% 50%, #2563eb 0%, #1e40af 55%, #0b152d 100%)',
    glow: 'rgba(59, 130, 246, 0.95)',
    bgGlow: 'rgba(37, 99, 235, 0.45)',
    emblemLight: '#e0f2fe',
    emblemBase: '#3b82f6',
  },
  EPIC: {
    surface: 'radial-gradient(circle at 50% 50%, #9333ea 0%, #6b21a8 55%, #3b0764 100%)',
    glow: 'rgba(168, 85, 247, 0.95)',
    bgGlow: 'rgba(147, 51, 234, 0.5)',
    emblemLight: '#f5d0fe',
    emblemBase: '#c084fc',
  },
  LEGENDARY: {
    surface: 'radial-gradient(circle at 50% 50%, #d97706 0%, #b45309 55%, #451a03 100%)',
    glow: 'rgba(245, 158, 11, 1)',
    bgGlow: 'rgba(217, 119, 6, 0.6)',
    emblemLight: '#fef3c7',
    emblemBase: '#f59e0b',
  },
  HALLOWEEN_2026: {
    surface: 'linear-gradient(135deg, #ff5e00 0%, #e11d48 22%, #9333ea 52%, #581c87 78%, #140320 100%)',
    glow: 'rgba(255, 94, 0, 1)',
    bgGlow: 'rgba(176, 38, 255, 0.85)',
    emblemLight: '#ffe4e6',
    emblemBase: '#ff5e00',
  },
};

const MysteryCardBack: React.FC<MysteryCardBackProps> = ({
  activeRarity,
  isLocked,
  customBackImageUrl
}) => {
  const isHalloween = activeRarity === 'HALLOWEEN_2026';
  const palette = RARITY_FLAT_PALETTES[activeRarity] || RARITY_FLAT_PALETTES.COMMON;

  if (customBackImageUrl && customBackImageUrl.trim()) {
    return (
      <div
        className="relative flex items-center justify-center select-none transition-all duration-150"
        style={{
          filter: isLocked
            ? isHalloween
              ? 'drop-shadow(0 0 35px #ff5e00) drop-shadow(0 0 65px rgba(176,38,255,0.95)) drop-shadow(0 20px 45px rgba(0,0,0,0.95))'
              : `drop-shadow(0 0 35px ${palette.glow}) drop-shadow(0 0 65px ${palette.bgGlow}) drop-shadow(0 20px 45px rgba(0,0,0,0.95))`
            : `drop-shadow(0 0 25px ${palette.glow}) drop-shadow(0 15px 30px rgba(0,0,0,0.85))`
        }}
      >
        <img
          src={customBackImageUrl}
          alt="Card Back"
          className="max-h-[380px] sm:max-h-[420px] w-auto max-w-[260px] sm:max-w-[280px] object-contain select-none pointer-events-none transition-all duration-150"
          style={{
            filter: isLocked ? 'brightness(1.08)' : 'brightness(1.0)'
          }}
        />
      </div>
    );
  }

  return (
    <div
      className={`relative w-[240px] sm:w-[265px] h-[370px] sm:h-[410px] rounded-2xl flex items-center justify-center select-none overflow-hidden transition-all duration-200 ${
        isHalloween && isLocked ? 'border-2 border-orange-400/80 ring-2 ring-purple-500/50' : ''
      }`}
      style={{
        background: isHalloween && isLocked
          ? 'linear-gradient(135deg, #ff5e00 0%, #e11d48 22%, #9333ea 52%, #581c87 78%, #140320 100%)'
          : palette.surface,
        boxShadow: isLocked
          ? isHalloween
            ? '0 25px 60px -10px rgba(0,0,0,0.95), 0 0 50px rgba(255,94,0,0.9), 0 0 85px rgba(176,38,255,0.75)'
            : `0 25px 60px -10px rgba(0,0,0,0.95), 0 0 55px ${palette.glow}`
          : `0 20px 50px -10px rgba(0,0,0,0.9), 0 0 28px ${palette.bgGlow}`
      }}
    >
      <div
        className="absolute w-44 h-44 rounded-full blur-3xl pointer-events-none transition-all duration-150"
        style={{
          background: isLocked ? (isHalloween ? '#ff5e00' : palette.glow) : palette.bgGlow,
          opacity: isLocked ? 0.85 : 0.5
        }}
      />

      {/* For Halloween locked: Mythic witchfire secondary halo */}
      {isHalloween && isLocked && (
        <div
          className="absolute w-52 h-52 rounded-full blur-2xl pointer-events-none mix-blend-screen opacity-70"
          style={{ background: 'radial-gradient(circle, rgba(176,38,255,0.7) 0%, rgba(255,94,0,0.4) 60%, transparent 80%)' }}
        />
      )}

      <div className="relative z-10 w-24 h-24 sm:w-28 sm:h-28 flex items-center justify-center transition-transform duration-300">
        <svg
          viewBox="0 0 200 200"
          className="w-full h-full transition-all duration-150"
          style={{
            filter: isLocked
              ? isHalloween
                ? 'drop-shadow(0 0 24px #ffedd5) drop-shadow(0 0 45px #ff5e00) drop-shadow(0 0 65px #b026ff)'
                : `drop-shadow(0 0 24px ${palette.emblemLight}) drop-shadow(0 0 45px ${palette.glow})`
              : `drop-shadow(0 0 14px ${palette.emblemLight}) drop-shadow(0 0 28px ${palette.bgGlow})`
          }}
        >
          <defs>
            <linearGradient id="flat-card-emblem-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="45%" stopColor={isHalloween && isLocked ? '#ff9a3c' : palette.emblemLight} />
              <stop offset="75%" stopColor={isHalloween && isLocked ? '#ff5e00' : palette.emblemBase} />
              <stop offset="100%" stopColor={isHalloween && isLocked ? '#b026ff' : palette.emblemBase} />
            </linearGradient>
          </defs>
          <g fill="url(#flat-card-emblem-grad)">
            <path transform="translate(58 6) scale(1.24)" d="M50 0C53 31 69 47 100 50C69 53 53 69 50 100C47 69 31 53 0 50C31 47 47 31 50 0Z" />
            <path transform="translate(8 96) scale(.9)" d="M50 0C53 31 69 47 100 50C69 53 53 69 50 100C47 69 31 53 0 50C31 47 47 31 50 0Z" />
          </g>
        </svg>
      </div>
    </div>
  );
};

interface StandalonePowerRevealProps {
  targetPower: number;
  rarity: CardRarity;
  onComplete: () => void;
}

const StandalonePowerReveal: React.FC<StandalonePowerRevealProps> = ({
  targetPower,
  rarity,
  onComplete
}) => {
  const rawPowerNum = Number(targetPower) || 50;
  const safeTargetPower = Math.min(100, Math.max(10, Math.round(rawPowerNum > 100 ? rawPowerNum / 10 : rawPowerNum)));
  const [currentPower, setCurrentPower] = useState(0);
  const [isLocked, setIsLocked] = useState(false);
  const config = RARITY_SHOWCASE[rarity] || RARITY_SHOWCASE.COMMON;

  const [currentColor, setCurrentColor] = useState<string>(config.colorSpectrum[0]);
  const [currentGlow, setCurrentGlow] = useState<string>(config.glow);

  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  const isFinalizedRef = useRef(false);
  const frameRef = useRef<number | null>(null);
  const hardTimeoutRef = useRef<number | null>(null);
  const postTimerRef = useRef<number | null>(null);

  const finalize = useCallback(() => {
    if (isFinalizedRef.current) return;
    isFinalizedRef.current = true;

    if (frameRef.current) cancelAnimationFrame(frameRef.current);
    if (hardTimeoutRef.current) clearTimeout(hardTimeoutRef.current);

    setCurrentPower(safeTargetPower);
    setIsLocked(true);
    setCurrentColor(config.bright);
    setCurrentGlow(config.glow);

    try {
      playPowerLockBoom(rarity, 0.9);
    } catch {}

    postTimerRef.current = window.setTimeout(() => {
      onCompleteRef.current();
    }, 620);
  }, [safeTargetPower, rarity, config.bright, config.glow]);

  useEffect(() => {
    isFinalizedRef.current = false;
    const startTime = performance.now();
    const durationMs = 1350;

    hardTimeoutRef.current = window.setTimeout(() => {
      finalize();
    }, durationMs + 200);

    let lastTickVal = -1;

    const updateCounter = (currentTime: number) => {
      if (isFinalizedRef.current) return;

      const elapsed = currentTime - startTime;
      const progress = Math.min(1, Math.max(0, elapsed / durationMs));
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      const val = Math.min(safeTargetPower, Math.max(0, Math.round(easeProgress * safeTargetPower)));

      setCurrentPower(val);

      const colorIdx = Math.min(
        config.colorSpectrum.length - 1,
        Math.floor(progress * config.colorSpectrum.length)
      );
      setCurrentColor(config.colorSpectrum[colorIdx]);
      setCurrentGlow(config.glow);

      if (val !== lastTickVal && val % 2 === 0) {
        lastTickVal = val;
        try {
          playPowerCountTick(0.25, 300 + val * 6);
        } catch {}
      }

      if (progress < 1) {
        frameRef.current = requestAnimationFrame(updateCounter);
      } else {
        finalize();
      }
    };

    frameRef.current = requestAnimationFrame(updateCounter);

    return () => {
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
      if (hardTimeoutRef.current) clearTimeout(hardTimeoutRef.current);
      if (postTimerRef.current) clearTimeout(postTimerRef.current);
    };
  }, [safeTargetPower, rarity, finalize, config.colorSpectrum, config.bright, config.glow]);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.85 }}
      animate={{
        opacity: 1,
        scale: isLocked ? [1, 1.12, 1] : 1
      }}
      exit={{ opacity: 0, scale: 1.08 }}
      transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
      onClick={finalize}
      className="relative flex flex-col items-center justify-center select-none cursor-pointer"
      title="Click to lock rating"
    >
      <div
        className="absolute w-72 h-72 sm:w-96 sm:h-96 md:w-[28rem] md:h-[28rem] rounded-full blur-[85px] sm:blur-[110px] pointer-events-none transition-colors duration-150"
        style={{
          background: isLocked ? config.glow : currentGlow,
          opacity: isLocked ? 0.75 : 0.45
        }}
      />

      <div className="relative z-10 flex flex-col items-center justify-center">
        <span
          className="font-mono font-black tabular-nums tracking-tighter text-7xl sm:text-8xl md:text-9xl transition-all duration-100"
          style={{
            color: isLocked ? config.bright : currentColor,
            textShadow: isLocked
              ? `0 0 25px ${config.bright}, 0 0 50px ${config.glow}, 0 0 90px ${config.glow}`
              : `0 0 20px ${currentColor}, 0 0 40px ${currentGlow}`
          }}
        >
          {currentPower}
        </span>
      </div>
    </motion.div>
  );
};

interface GrandRarityRevealProps {
  rarity: CardRarity;
  onComplete: () => void;
}

const GrandRarityReveal: React.FC<GrandRarityRevealProps> = ({ rarity, onComplete }) => {
  const config = RARITY_SHOWCASE[rarity] || RARITY_SHOWCASE.COMMON;
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  useEffect(() => {
    const timer = setTimeout(() => {
      onCompleteRef.current();
    }, 1450);
    return () => clearTimeout(timer);
  }, [rarity]);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.88 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 1.05 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      onClick={() => onCompleteRef.current()}
      className="relative flex flex-col items-center justify-center select-none text-center px-4 w-full max-w-lg cursor-pointer"
    >
      <motion.div
        initial={{ scale: 0.6, opacity: 0 }}
        animate={{ scale: [0.6, 1.4, 1.15], opacity: [0, 0.9, 0.65] }}
        transition={{ duration: 1.2, ease: 'easeOut' }}
        className="absolute w-80 h-80 sm:w-[32rem] sm:h-[32rem] rounded-full blur-[90px] pointer-events-none"
        style={{ background: config.glow }}
      />

      <motion.div
        initial={{ scaleX: 0, opacity: 0 }}
        animate={{ scaleX: [0, 1.6, 1.2], opacity: [0, 1, 0.85] }}
        transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
        className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-[3px] pointer-events-none z-10"
        style={{
          background: `linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.95) 45%, ${config.bright} 55%, transparent 100%)`,
          boxShadow: `0 0 24px rgba(255,255,255,1), 0 0 50px ${config.accent}`
        }}
      />

      <div className="relative z-20 flex flex-col items-center space-y-3.5">
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.08 }}
          className="flex items-center justify-center gap-3"
        >
          <span className="w-8 sm:w-14 h-px" style={{ background: `linear-gradient(90deg, transparent, ${config.bright})` }} />
          <span
            className="text-xs sm:text-sm font-mono font-bold tracking-[0.4em] uppercase"
            style={{ color: config.bright }}
          >
            {config.tierLabel} · {config.numeral}
          </span>
          <span className="w-8 sm:w-14 h-px" style={{ background: `linear-gradient(270deg, transparent, ${config.bright})` }} />
        </motion.div>

        <motion.h1
          initial={{ scale: 0.75, opacity: 0, letterSpacing: '0.12em' }}
          animate={{ scale: 1, opacity: 1, letterSpacing: '0.32em' }}
          transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
          className={`text-4xl sm:text-6xl md:text-7xl font-serif font-black uppercase bg-gradient-to-r ${config.gradient} bg-clip-text text-transparent`}
          style={{
            filter: `drop-shadow(0 0 25px ${config.glow}) drop-shadow(0 0 60px ${config.bgGlow})`
          }}
        >
          {config.name === 'HALLOWEEN_2026' ? 'HALLOWEEN' : config.name}
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.18 }}
          className="text-[11px] sm:text-xs font-mono tracking-[0.35em] text-stone-300 uppercase"
        >
          {config.subtext}
        </motion.p>
      </div>
    </motion.div>
  );
};

interface BlackCardShakeRevealProps {
  card: CollectibleCardData;
  rarity: CardRarity;
  onComplete: () => void;
  isAudioContinuingFromVideo?: boolean;
}

/**
 * Pure Flat Black Card Shaking -> BOOM! Reveal Animation
 * Strictly for EPIC and LEGENDARY cards.
 * Has NO logo or anything: just a flat black card that shakes hard then BOOM!
 */
const BlackCardShakeReveal: React.FC<BlackCardShakeRevealProps> = ({
  card,
  rarity,
  onComplete,
  isAudioContinuingFromVideo = false
}) => {
  const [phase, setPhase] = useState<'anticipation' | 'shake' | 'violent' | 'boom'>('anticipation');
  const [isBoom, setIsBoom] = useState(false);
  const config = RARITY_SHOWCASE[rarity] || RARITY_SHOWCASE.COMMON;
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;
  const hasTriggeredRef = useRef(false);

  const triggerBoom = useCallback(() => {
    if (hasTriggeredRef.current) return;
    hasTriggeredRef.current = true;
    setIsBoom(true);
    setPhase('boom');

    try {
      playCardRevealBoom(rarity, isAudioContinuingFromVideo ? 0.6 : 0.85);
    } catch {}

    setTimeout(() => {
      onCompleteRef.current();
    }, 280);
  }, [rarity, isAudioContinuingFromVideo]);

  useEffect(() => {
    try {
      playChargeTremor(isAudioContinuingFromVideo ? 0.35 : 0.6);
    } catch {}

    const t1 = setTimeout(() => {
      setPhase('shake');
    }, 300);

    const t2 = setTimeout(() => {
      setPhase('violent');
    }, 850);

    const t3 = setTimeout(() => {
      triggerBoom();
    }, 1450);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [triggerBoom, isAudioContinuingFromVideo]);

  // Framer-motion shake variants: builds from intense anticipation tremor to violent erratic hard shake
  const shakeAnimation = {
    anticipation: {
      x: [0, -2, 2, -1, 1, 0],
      y: [0, 1, -1, 2, -1, 0],
      scale: 1,
      rotate: [-0.6, 0.6, -0.4, 0],
      transition: { duration: 0.18, repeat: Infinity }
    },
    shake: {
      x: [-6, 6, -7, 7, -8, 8, -6, 5, 0],
      y: [4, -5, 5, -6, 6, -5, 4, 0],
      rotate: [-2.4, 2.6, -2.8, 2.5, -2.2, 0],
      scale: [1, 1.03, 1.01, 1.04],
      transition: { duration: 0.12, repeat: Infinity, ease: 'linear' as const }
    },
    violent: {
      x: [-12, 14, -15, 16, -17, 18, -16, 15, -13, 11, -8, 0],
      y: [8, -10, 11, -12, 12, -11, 10, -8, 6, 0],
      rotate: [-5.2, 5.4, -5.8, 5.6, -4.9, 4.3, 0],
      scale: [1.04, 1.11, 1.07, 1.13, 1.1],
      transition: { duration: 0.08, repeat: Infinity, ease: 'linear' as const }
    },
    boom: {
      x: 0,
      y: 0,
      rotate: 0,
      scale: [1.15, 1.22, 1.0],
      transition: { duration: 0.45, ease: [0.16, 1, 0.3, 1] }
    }
  };

  return (
    <div
      onClick={triggerBoom}
      className="relative flex items-center justify-center select-none cursor-pointer w-full max-w-[280px] sm:max-w-[315px] perspective-[1200px]"
    >
      {/* 1. Dramatic expanding shockwave ring on BOOM */}
      <AnimatePresence>
        {isBoom && (
          <>
            <motion.div
              initial={{ scale: 0.4, opacity: 1 }}
              animate={{ scale: 3.5, opacity: 0 }}
              transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
              className="absolute w-64 h-64 sm:w-80 sm:h-80 rounded-full border-4 pointer-events-none z-40"
              style={{ borderColor: config.bright, boxShadow: `0 0 50px ${config.glow}` }}
            />
            {/* Blinding flash of light */}
            <motion.div
              initial={{ opacity: 0.95 }}
              animate={{ opacity: 0 }}
              transition={{ duration: 0.4, ease: 'easeOut' }}
              className="fixed inset-0 bg-white pointer-events-none z-50 mix-blend-screen"
            />
          </>
        )}
      </AnimatePresence>

      {/* 2. Rarity background aura that flares as shaking intensifies */}
      <motion.div
        animate={{
          scale: phase === 'violent' ? [1.15, 1.45, 1.25] : phase === 'shake' ? [1, 1.2, 1.08] : 1,
          opacity: phase === 'violent' ? [0.7, 1, 0.8] : phase === 'shake' ? 0.55 : 0.25
        }}
        transition={{ duration: 0.2, repeat: Infinity }}
        className="absolute w-72 h-96 rounded-full blur-[80px] sm:blur-[100px] pointer-events-none -z-10"
        style={{ background: config.glow }}
      />

      {/* 3. Pure Flat Black Card: ZERO LOGO, ZERO TEXT, ZERO LINES, JUST FLAT BLACK */}
      <motion.div
        animate={isBoom ? shakeAnimation.boom : shakeAnimation[phase]}
        className="relative w-full max-w-[280px] sm:max-w-[315px] aspect-[1/1.52] rounded-[2rem] sm:rounded-[2.2rem] bg-black border-0 overflow-hidden shadow-[0_25px_60px_-10px_rgba(0,0,0,0.95)]"
        style={{
          background: '#000000',
          boxShadow: phase === 'violent' || isBoom
            ? `0 0 50px ${config.glow}, 0 0 90px ${config.bgGlow}, 0 25px 60px rgba(0,0,0,0.95)`
            : `0 20px 45px rgba(0,0,0,0.9)`
        }}
      />
    </div>
  );
};

export const PackOpeningModal: React.FC<PackOpeningModalProps> = ({
  isOpen,
  pack,
  result,
  userCoins,
  onClose,
  onOpenAnother,
  onInspectCard
}) => {
  const { toggleShowcase, isCardShowcased, cardBackImageUrl } = useCards();
  const { items: activeCatalogItems } = useItems();
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const [stage, setStage] = useState<PackRevealStage>('STAGE_READY_TO_CUT');
  const [currentItemIndex, setCurrentItemIndex] = useState<number>(0);
  const [rolledRarity, setRolledRarity] = useState<CardRarity>('COMMON');
  const [isColorLocked, setIsColorLocked] = useState(false);
  const [isVideoMuted, setIsVideoMuted] = useState(false);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [isVideoVisualFading, setIsVideoVisualFading] = useState(false);
  const [isAutoplayMutedFallback, setIsAutoplayMutedFallback] = useState(false);
  const [fallbackToIframe, setFallbackToIframe] = useState(false);
  const [areVideoControlsVisible, setAreVideoControlsVisible] = useState(false);
  const hasTriggeredFadeOut = useRef(false);

  const [tilt, setTilt] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [sfxConfig, setSfxConfig] = useState<RevealSfxConfig>(DEFAULT_SFX_CONFIG);

  // Interactive slide cutting states
  const [cutProgress, setCutProgress] = useState(0); // 0 to 1
  const [isDraggingCut, setIsDraggingCut] = useState(false);
  const cutTrackRef = useRef<HTMLDivElement | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const sfxConfigRef = useRef(sfxConfig);
  sfxConfigRef.current = sfxConfig;

  const card = result?.openedCard;
  const rarity: CardRarity = card?.rarity || 'COMMON';
  const isLegendary = rarity === 'LEGENDARY';
  const isEpicOrLegendary = rarity === 'EPIC' || rarity === 'LEGENDARY' || rarity === 'HALLOWEEN_2026';
  const hasLegendaryVideo = Boolean(isLegendary && card?.revealVideoUrl);
  const isShowcased = card ? isCardShowcased(card.id) : false;

  const parsedVideo = parseUniversalVideoUrl(card?.revealVideoUrl);

  const openingPackImageUrl =
    pack?.openImageUrl ||
    (pack?.rarity ? UNSEAL_PACK_IMAGES[pack.rarity] : undefined) ||
    UNSEAL_PACK_IMAGES.COMMON;

  // Authoritative synced OVR calculation (matching CollectibleCard display)
  const cardUnifiedStats = useMemo(() => (card ? getUnifiedCardStats(card) : []), [card]);
  const overallPower = useMemo(() => {
    if (!card) return 50;
    return Math.min(100, Math.max(10, card.overallRating || calculateCardOverallRating(cardUnifiedStats, card.rarity)));
  }, [card, cardUnifiedStats]);

  const displayCard = useMemo(() => {
    if (!card) return null;
    return {
      ...card,
      overallRating: overallPower,
      power: overallPower,
      powerRating: overallPower
    };
  }, [card, overallPower]);

  // Extract separate item rewards from the package (droppedItems, droppedItem, duplicateReward.materialsAwarded)
  // Strictly validated against activeCatalogItems and deletion state
  const packageItems = useMemo<PackRewardItem[]>(() => {
    if (!result) return [];

    // If owner wiped all items or catalog is loaded and empty, strictly return NO items
    const isWiped = typeof window !== 'undefined' && localStorage.getItem('nexus_deleted_all_items') === 'true';
    if (isWiped || (Array.isArray(activeCatalogItems) && activeCatalogItems.length === 0)) {
      return [];
    }

    const activeItemMap = new Map<string, UnifiedItemDefinition>((activeCatalogItems || []).map((i: UnifiedItemDefinition) => [i.id, i]));
    const items: PackRewardItem[] = [];

    // 1. Array of dropped items if provided
    if (Array.isArray((result as any).droppedItems) && (result as any).droppedItems.length > 0) {
      for (const it of (result as any).droppedItems) {
        if (it && it.id && activeItemMap.has(it.id)) {
          const catalogItem = activeItemMap.get(it.id)!;
          items.push({
            id: it.id,
            name: catalogItem.name || it.name || 'Item',
            nameAr: catalogItem.nameAr || it.nameAr,
            description: catalogItem.description || it.description,
            descriptionAr: catalogItem.descriptionAr || it.descriptionAr,
            imageUrl: catalogItem.imageUrl || it.imageUrl || '',
            rarity: catalogItem.rarity || it.rarity || 'COMMON',
            category: catalogItem.category || it.category || 'BATTLE',
            count: it.count || 1,
            battleEffect: catalogItem.battleEffect || it.battleEffect,
            lovePoints: catalogItem.lovePoints || it.lovePoints
          });
        }
      }
    } else if (result.droppedItem && result.droppedItem.id && activeItemMap.has(result.droppedItem.id)) {
      const catalogItem = activeItemMap.get(result.droppedItem.id)!;
      items.push({
        id: result.droppedItem.id,
        name: catalogItem.name || result.droppedItem.name || 'Item',
        nameAr: catalogItem.nameAr || (result.droppedItem as any).nameAr,
        description: catalogItem.description || (result.droppedItem as any).description,
        descriptionAr: catalogItem.descriptionAr || (result.droppedItem as any).descriptionAr,
        imageUrl: catalogItem.imageUrl || result.droppedItem.imageUrl || '',
        rarity: catalogItem.rarity || (result.droppedItem.rarity as CardRarity) || 'COMMON',
        category: catalogItem.category || (result.droppedItem as any).category || 'COMPANION',
        count: (result.droppedItem as any).count || 1,
        battleEffect: catalogItem.battleEffect || (result.droppedItem as any).battleEffect,
        lovePoints: catalogItem.lovePoints || (result.droppedItem as any).lovePoints
      });
    }

    // 2. Duplicate card upgrade materials
    if (result.duplicateReward && Array.isArray(result.duplicateReward.materialsAwarded)) {
      for (const mat of result.duplicateReward.materialsAwarded) {
        if (mat && mat.count > 0 && activeItemMap.has(mat.itemId)) {
          const catalogItem = activeItemMap.get(mat.itemId)!;
          items.push({
            id: mat.itemId,
            name: catalogItem.name || mat.name,
            nameAr: catalogItem.nameAr || mat.nameAr,
            imageUrl: catalogItem.imageUrl || mat.imageUrl || '',
            rarity: catalogItem.rarity || mat.rarity || 'COMMON',
            category: 'UPGRADE_MATERIAL',
            count: mat.count
          });
        }
      }
    }

    return items;
  }, [result, activeCatalogItems]);

  // Load sound settings once when modal opens
  useEffect(() => {
    if (!isOpen) return;
    fetch('/api/cards/reveal-sfx')
      .then(r => r.json())
      .then(data => {
        if (data.success && data.sfxConfig) {
          setSfxConfig(data.sfxConfig);
        }
      })
      .catch(() => {});
  }, [isOpen]);

  // Reset to interactive slide-to-cut state when a new pack/card is opened
  useEffect(() => {
    if (!isOpen || !result || !card) return;

    setStage('STAGE_READY_TO_CUT');
    setCutProgress(0);
    setIsDraggingCut(false);
    setCurrentItemIndex(0);
    setRolledRarity('COMMON');
    setIsColorLocked(false);
    setIsVideoPlaying(false);
    setIsVideoVisualFading(false);
    setIsAutoplayMutedFallback(false);
    setFallbackToIframe(false);
    setAreVideoControlsVisible(false);
    hasTriggeredFadeOut.current = false;
    setTilt({ x: 0, y: 0 });
  }, [isOpen, result?.openedCard?.id]);

  // Trigger the dramatic pack cut
  const executeCut = useCallback(() => {
    if (stage !== 'STAGE_READY_TO_CUT') return;

    setStage('STAGE_CUT');
    setCutProgress(1);
    setIsDraggingCut(false);

    try {
      playRevealSound('cut', rarity, sfxConfigRef.current);
    } catch {}

    const pullTimer = setTimeout(() => {
      try {
        playRevealSound('pull', rarity, sfxConfigRef.current);
      } catch {}
    }, 280);

    const advanceTimer = setTimeout(() => {
      setStage('STAGE_COLOR_ROLL');
    }, 780);

    return () => {
      clearTimeout(pullTimer);
      clearTimeout(advanceTimer);
    };
  }, [stage, rarity]);

  // Touch & Pointer Drag Handlers
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (stage !== 'STAGE_READY_TO_CUT') return;
    setIsDraggingCut(true);
    (e.target as HTMLElement)?.setPointerCapture?.(e.pointerId);
    handlePointerUpdate(e.clientX);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingCut || stage !== 'STAGE_READY_TO_CUT') return;
    handlePointerUpdate(e.clientX);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingCut || stage !== 'STAGE_READY_TO_CUT') return;
    setIsDraggingCut(false);
    try {
      (e.target as HTMLElement)?.releasePointerCapture?.(e.pointerId);
    } catch {}

    if (cutProgress >= 0.55) {
      executeCut();
    } else {
      setCutProgress(0);
    }
  };

  const handlePointerUpdate = (clientX: number) => {
    if (!cutTrackRef.current) return;
    const rect = cutTrackRef.current.getBoundingClientRect();
    const progress = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    setCutProgress(progress);

    if (progress >= 0.7) {
      executeCut();
    }
  };

  // Step 3: STAGE_COLOR_ROLL
  useEffect(() => {
    if (stage !== 'STAGE_COLOR_ROLL' || !card) return;

    // Rolling cycle rarities strictly exclude HALLOWEEN_2026,
    // so Halloween card mythic color NEVER appears while rolling - only when it stops!
    const ROLLING_RARITIES: CardRarity[] = ['COMMON', 'UNCOMMON', 'RARE', 'EPIC', 'LEGENDARY'];
    let isMounted = true;
    let cycleCount = 0;
    let currentDelay = 65;
    const targetRarity = card.rarity;

    setIsColorLocked(false);

    const lockAndAdvance = () => {
      if (!isMounted) return;
      // Stop and lock firmly on target rarity (including HALLOWEEN_2026 with its mythic gradient)
      setRolledRarity(targetRarity);
      setIsColorLocked(true);
      try {
        playColorLock(targetRarity, 0.85);
      } catch {}

      setTimeout(() => {
        if (isMounted) {
          setStage('STAGE_POWER_SCAN');
        }
      }, 580);
    };

    const rollNext = () => {
      if (!isMounted) return;
      cycleCount++;

      if (cycleCount > 12) {
        currentDelay += 35;
      }

      const candidateRarity = ROLLING_RARITIES[cycleCount % ROLLING_RARITIES.length];

      // Stop condition:
      // - If target is HALLOWEEN_2026: rolls between standard colors, then stops at cycleCount >= 18 directly on Halloween!
      // - If target is any standard rarity: stops when cycleCount > 16 and candidate matches, or guaranteed cap at cycleCount >= 22
      const shouldStop =
        targetRarity === 'HALLOWEEN_2026'
          ? cycleCount >= 18
          : (cycleCount > 16 && candidateRarity === targetRarity) || cycleCount >= 22;

      if (shouldStop) {
        lockAndAdvance();
        return;
      }

      setRolledRarity(candidateRarity);
      try {
        playColorRollTick(0.32, 420 + (cycleCount % 5) * 115);
      } catch {}

      setTimeout(rollNext, currentDelay);
    };

    const timer = setTimeout(rollNext, currentDelay);

    // Guaranteed safety timeout to ensure it NEVER hangs indefinitely under any circumstance
    const hardSafetyTimer = setTimeout(() => {
      if (isMounted && !isColorLocked) {
        lockAndAdvance();
      }
    }, 4200);

    return () => {
      isMounted = false;
      clearTimeout(timer);
      clearTimeout(hardSafetyTimer);
    };
  }, [stage, card?.id, card?.rarity]);

  // Step 4 -> Step 5: After Power Scanner finishes, show Grand Rarity Reveal
  const handlePowerScanComplete = useCallback(() => {
    setStage('STAGE_RARITY_REVEAL');
    try {
      playRevealSound('rarity', rarity, sfxConfigRef.current);
    } catch {}
  }, [rarity]);

  // Step 5 -> Step 6: After Grand Rarity Reveal finishes:
  // - If Legendary with Video: play video with audio ON automatically
  // - Shaking animation ONLY for EPIC and LEGENDARY cards!
  // - For COMMON, UNCOMMON, RARE: go directly to STAGE_PRESENT!
  const handleRarityRevealComplete = useCallback(() => {
    if (hasLegendaryVideo && parsedVideo) {
      setIsVideoPlaying(true);
      setIsVideoVisualFading(false);
      setIsVideoMuted(false);
      setIsAutoplayMutedFallback(false);
      setFallbackToIframe(false);
      setAreVideoControlsVisible(false);
      hasTriggeredFadeOut.current = false;
      setStage('STAGE_VIDEO');
    } else if (isEpicOrLegendary) {
      setStage('STAGE_SHAKE_REVEAL');
    } else {
      setStage('STAGE_PRESENT');
      try {
        playRevealSound('reveal', rarity, sfxConfigRef.current);
      } catch {}
    }
  }, [hasLegendaryVideo, parsedVideo, isEpicOrLegendary, rarity]);

  // Step 7: When Black Card Shake finishes (BOOM!), advance to final interactive presentation
  const handleShakeRevealComplete = useCallback(() => {
    setStage('STAGE_PRESENT');
    if (!isVideoPlaying) {
      try {
        playRevealSound(isLegendary ? 'legendary' : 'reveal', rarity, sfxConfigRef.current);
      } catch {}
    }
  }, [isVideoPlaying, isLegendary, rarity]);

  // Video playback & audio continuation logic:
  // Controls delayed appearance: start to appear after a couple of seconds (2.5s) after video starts!
  useEffect(() => {
    if (stage !== 'STAGE_VIDEO') {
      setAreVideoControlsVisible(false);
      return;
    }

    setAreVideoControlsVisible(false);
    const controlsTimer = setTimeout(() => {
      setAreVideoControlsVisible(true);
    }, 2500);

    return () => {
      clearTimeout(controlsTimer);
    };
  }, [stage]);

  // Direct video play trigger on mounting STAGE_VIDEO: audio is ON automatically
  useEffect(() => {
    if (stage !== 'STAGE_VIDEO') return;

    if (!parsedVideo?.isIframe && !fallbackToIframe && videoRef.current) {
      const vid = videoRef.current;
      vid.currentTime = 0;
      vid.muted = isVideoMuted;
      vid.volume = 1.0;
      const playPromise = vid.play();
      if (playPromise !== undefined) {
        playPromise.catch((err) => {
          console.warn('Autoplay with audio restricted by browser policy, attempting muted fallback with auto-unmute on gesture:', err);
          vid.muted = true;
          setIsVideoMuted(true);
          setIsAutoplayMutedFallback(true);
          vid.play().catch((playErr) => {
            console.warn('Direct video playback error, falling back to iframe:', playErr);
            setFallbackToIframe(true);
          });

          // Unmute automatically on first user tap/click
          const enableAudioOnGesture = () => {
            if (videoRef.current) {
              videoRef.current.muted = false;
              videoRef.current.volume = 1.0;
              setIsVideoMuted(false);
              setIsAutoplayMutedFallback(false);
            }
            window.removeEventListener('pointerdown', enableAudioOnGesture);
            window.removeEventListener('keydown', enableAudioOnGesture);
          };
          window.addEventListener('pointerdown', enableAudioOnGesture, { once: true });
          window.addEventListener('keydown', enableAudioOnGesture, { once: true });
        });
      }
    }
  }, [stage, parsedVideo?.isIframe, fallbackToIframe, isVideoMuted]);

  // Direct video event handlers
  const handleVideoLoadedMetadata = () => {
    hasTriggeredFadeOut.current = false;
    setIsVideoVisualFading(false);
    if (videoRef.current) {
      const vid = videoRef.current;
      vid.muted = isVideoMuted;
      vid.volume = 1.0;
      const playPromise = vid.play();
      if (playPromise !== undefined) {
        playPromise.catch((err) => {
          console.warn('Autoplay restricted on loadedmetadata, attempting muted fallback:', err);
          vid.muted = true;
          setIsVideoMuted(true);
          setIsAutoplayMutedFallback(true);
          vid.play().catch(() => {});
        });
      }
    }
  };

  const handleVideoTimeUpdate = () => {
    if (!videoRef.current) return;
    const current = videoRef.current.currentTime;
    const duration = videoRef.current.duration;
    if (!duration || isNaN(duration) || duration <= 0) return;

    // 1. Visual fade starts 5 seconds before the video ends (or at 65% for shorter clips)
    const fadeStartTime = Math.max(duration * 0.65, duration - 5);
    if (current >= fadeStartTime && !hasTriggeredFadeOut.current) {
      hasTriggeredFadeOut.current = true;
      setIsVideoVisualFading(true);
      // Trigger the flat black card shake reveal underneath while audio continues!
      if (isEpicOrLegendary) {
        setStage('STAGE_SHAKE_REVEAL');
      } else {
        setStage('STAGE_PRESENT');
      }
    }

    // 2. Audio fade: automatically fade audio smoothly over the last 2.5 seconds of the video!
    const audioFadeStart = Math.max(0, duration - 2.5);
    if (current >= audioFadeStart && !isVideoMuted) {
      const remaining = Math.max(0, duration - current);
      const factor = remaining / 2.5; // from 1.0 down to 0
      const targetVol = Math.max(0, Math.min(1, Math.pow(factor, 1.25)));
      videoRef.current.volume = targetVol;
    }
  };

  const handleVideoEnded = () => {
    setIsVideoPlaying(false);
    setIsVideoVisualFading(false);
    setAreVideoControlsVisible(false);
    if (stage === 'STAGE_VIDEO') {
      if (isEpicOrLegendary) {
        setStage('STAGE_SHAKE_REVEAL');
      } else {
        setStage('STAGE_PRESENT');
      }
    }
  };

  const handleVideoError = (e: any) => {
    console.warn('Direct video playback error:', e);
    // If native video failed to decode or stream, attempt iframe fallback before giving up!
    if (!fallbackToIframe && (parsedVideo?.embedUrl || card?.revealVideoUrl)) {
      setFallbackToIframe(true);
      return;
    }

    setIsVideoPlaying(false);
    setIsVideoVisualFading(false);
    setAreVideoControlsVisible(false);
    if (stage === 'STAGE_VIDEO') {
      if (isEpicOrLegendary) {
        setStage('STAGE_SHAKE_REVEAL');
      } else {
        setStage('STAGE_PRESENT');
      }
    }
  };

  // Iframe timer for YouTube, Vimeo, Streamable, and iframe fallback embeds
  useEffect(() => {
    const isIframeMode = parsedVideo?.isIframe || fallbackToIframe;
    if (stage !== 'STAGE_VIDEO' || !isIframeMode) return;

    // Default duration for embeds without direct duration API: 20 seconds
    const embedDuration = 20;
    const fadeAt = 15; // 5 seconds before 20s end
    const audioFadeAt = 17.5; // Audio fade starts 2.5 seconds before 20s end

    const fadeTimer = setTimeout(() => {
      if (!hasTriggeredFadeOut.current) {
        hasTriggeredFadeOut.current = true;
        setIsVideoVisualFading(true);
        if (isEpicOrLegendary) {
          setStage('STAGE_SHAKE_REVEAL');
        } else {
          setStage('STAGE_PRESENT');
        }
      }
    }, fadeAt * 1000);

    // Automatic audio fade for YouTube iframe embed
    const audioFadeTimer = setTimeout(() => {
      if (iframeRef.current?.contentWindow) {
        for (let step = 1; step <= 8; step++) {
          setTimeout(() => {
            const vol = Math.max(0, Math.round(100 - step * 12.5));
            try {
              iframeRef.current?.contentWindow?.postMessage(
                JSON.stringify({ event: 'command', func: 'setVolume', args: [vol] }),
                '*'
              );
            } catch {}
          }, step * 250);
        }
      }
    }, audioFadeAt * 1000);

    const endTimer = setTimeout(() => {
      setIsVideoPlaying(false);
      setIsVideoVisualFading(false);
      setAreVideoControlsVisible(false);
    }, embedDuration * 1000);

    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(audioFadeTimer);
      clearTimeout(endTimer);
    };
  }, [stage, parsedVideo?.isIframe, fallbackToIframe, isEpicOrLegendary]);

  // Audio On / Off Toggle Handler
  const toggleVideoAudio = () => {
    const nextMuted = !isVideoMuted;
    setIsVideoMuted(nextMuted);
    setIsAutoplayMutedFallback(false);
    if (videoRef.current) {
      videoRef.current.muted = nextMuted;
      if (!nextMuted) {
        videoRef.current.volume = 1.0;
        videoRef.current.play().catch(() => {});
      }
    }
    if (iframeRef.current?.contentWindow) {
      const func = nextMuted ? 'mute' : 'unMute';
      try {
        iframeRef.current.contentWindow.postMessage(
          JSON.stringify({ event: 'command', func, args: [] }),
          '*'
        );
      } catch {}
    }
  };

  const handleSkipVideo = () => {
    if (videoRef.current) {
      try {
        let vol = videoRef.current.volume;
        const fadeInterval = setInterval(() => {
          vol = Math.max(0, vol - 0.25);
          if (videoRef.current) videoRef.current.volume = vol;
          if (vol <= 0) {
            clearInterval(fadeInterval);
            videoRef.current?.pause();
          }
        }, 30);
      } catch {
        videoRef.current.pause();
      }
    }
    setIsVideoPlaying(false);
    setIsVideoVisualFading(true);
    setAreVideoControlsVisible(false);
    setStage('STAGE_PRESENT');
    try {
      playRevealSound('legendary', rarity, sfxConfigRef.current);
    } catch {}
  };

  const handleFastForward = () => {
    if (videoRef.current) {
      try {
        videoRef.current.pause();
      } catch {}
    }
    setIsVideoPlaying(false);
    setIsVideoVisualFading(true);
    setStage('STAGE_PRESENT');
    try {
      playRevealSound(isLegendary ? 'legendary' : 'reveal', rarity, sfxConfigRef.current);
    } catch {}
  };

  const handleModalClose = () => {
    if (videoRef.current) {
      try {
        videoRef.current.pause();
      } catch {}
    }
    setIsVideoPlaying(false);
    onClose();
  };

  // 3D Perspective Physics on Hover during final card presentation
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (stage !== 'STAGE_PRESENT' || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({
      x: Math.max(-6, Math.min(6, -y * 12)),
      y: Math.max(-8, Math.min(8, x * 14))
    });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
  };

  if (!isOpen || !pack || !result || !card) {
    return null;
  }

  const canAffordAnother = userCoins >= pack.price;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 select-none bg-[#020404]">
        {/* Corner close button (hidden when video is playing) */}
        {!isVideoPlaying && stage !== 'STAGE_VIDEO' && (
          <button
            type="button"
            onClick={handleModalClose}
            aria-label="Close"
            className="absolute top-4 end-4 sm:top-6 sm:end-6 p-2.5 rounded-full text-white/50 hover:text-white bg-black/40 hover:bg-black/80 border border-white/10 backdrop-blur-md transition-all cursor-pointer z-50 active:scale-95 shadow-md"
          >
            <X size={18} />
          </button>
        )}

        {/* Skip button for preliminary stages */}
        {stage !== 'STAGE_PRESENT' && stage !== 'STAGE_ITEM_REVEAL' && stage !== 'STAGE_VIDEO' && (
          <button
            type="button"
            onClick={handleFastForward}
            className="absolute top-4 start-4 sm:top-6 sm:start-6 px-3.5 py-1.5 rounded-full text-xs font-sans text-stone-400 hover:text-white bg-black/40 hover:bg-black/80 border border-white/10 backdrop-blur-md transition-all cursor-pointer z-50 active:scale-95"
          >
            Skip
          </button>
        )}

        {/* FULLSCREEN VIDEO FOR LEGENDARY CARDS */}
        {/* Works for ANY video type: YouTube, Vimeo, Streamable, MP4, WebM, MOV, Google Drive, Loom, Dailymotion, Twitch, etc. */}
        {card.revealVideoUrl && isVideoPlaying && (parsedVideo || fallbackToIframe) && (
          <div
            className={`fixed inset-0 w-screen h-[100dvh] bg-black z-45 flex items-center justify-center overflow-hidden transition-opacity duration-1000 ${
              isVideoVisualFading ? 'opacity-0 pointer-events-none' : 'opacity-100 pointer-events-auto'
            }`}
          >
            {(parsedVideo?.isIframe || fallbackToIframe) ? (
              <iframe
                ref={iframeRef}
                src={fallbackToIframe ? (parsedVideo?.embedUrl || card.revealVideoUrl) : parsedVideo?.embedUrl}
                title="Legendary Reveal Video"
                className="w-full h-full border-0"
                allow="accelerometer; autoplay *; clipboard-write; encrypted-media *; gyroscope; picture-in-picture; web-share"
                allowFullScreen
              />
            ) : (
              <video
                ref={videoRef}
                key={parsedVideo?.directUrl || card.revealVideoUrl}
                src={parsedVideo?.directUrl || card.revealVideoUrl}
                autoPlay
                playsInline
                preload="auto"
                muted={isVideoMuted}
                onLoadedMetadata={handleVideoLoadedMetadata}
                onTimeUpdate={handleVideoTimeUpdate}
                onEnded={handleVideoEnded}
                onError={handleVideoError}
                className="w-full h-full object-cover"
              />
            )}

            {/* Top-Right Video Controls (Skip + Audio on/off toggle) */}
            {/* Starts to appear a couple of seconds after the video starts */}
            <AnimatePresence>
              {areVideoControlsVisible && !isVideoVisualFading && (
                <motion.div
                  initial={{ opacity: 0, y: -12, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -12, scale: 0.95 }}
                  transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                  className="absolute top-4 sm:top-6 end-4 sm:end-8 flex items-center gap-2.5 z-20"
                >
                  {/* Audio On / Off Toggle Button */}
                  <button
                    type="button"
                    onClick={toggleVideoAudio}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-black/75 hover:bg-black text-amber-200 border border-white/20 cursor-pointer backdrop-blur-md transition-all active:scale-95 shadow-xl"
                    title={isVideoMuted ? 'Turn Audio On' : 'Turn Audio Off'}
                  >
                    {isVideoMuted ? (
                      <>
                        <VolumeX size={16} className="text-rose-400" />
                        <span className="text-[11px] font-mono font-semibold tracking-wider text-rose-300">AUDIO OFF</span>
                      </>
                    ) : (
                      <>
                        <Volume2 size={16} className="text-emerald-400" />
                        <span className="text-[11px] font-mono font-semibold tracking-wider text-emerald-300">AUDIO ON</span>
                      </>
                    )}
                  </button>

                  {/* Skip Button */}
                  <button
                    type="button"
                    onClick={handleSkipVideo}
                    className="px-4 py-2 rounded-full bg-amber-500 hover:bg-amber-400 text-stone-950 font-serif font-black text-xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer transition-all shadow-xl active:scale-95"
                  >
                    <span>Skip</span>
                    <FastForward size={14} />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {/* MAIN CINEMATIC REVEAL STAGE CONTAINER */}
        <div
          ref={containerRef}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          className="relative w-full max-w-sm sm:max-w-md h-[100dvh] max-h-[100dvh] flex flex-col justify-between items-center py-4 sm:py-6 px-2 sm:px-4 box-border z-10"
        >
          {/* Top Breathing Space */}
          <div className="h-6 sm:h-8 shrink-0" />

          {/* CENTER ARENA */}
          <div className="relative w-full flex-1 flex items-center justify-center min-h-0 perspective-[1200px]">
            {/* ---------------------------------------------------------- */}
            {/* STAGE A: PACK READY TO CUT & DRAMATIC CUT SEPARATION       */}
            {/* ---------------------------------------------------------- */}
            {(stage === 'STAGE_READY_TO_CUT' || stage === 'STAGE_CUT' || stage === 'STAGE_COLOR_ROLL') && (
              <div className="relative w-56 sm:w-64 h-80 sm:h-92 flex flex-col items-center justify-center">
                {/* Contact Ground Shadow */}
                <div className="absolute -bottom-6 w-48 sm:w-56 h-6 rounded-full bg-black/80 blur-md pointer-events-none" />

                {/* THE CARD (FACE-DOWN): Emerges during STAGE_CUT, floats center in STAGE_COLOR_ROLL */}
                {(stage === 'STAGE_CUT' || stage === 'STAGE_COLOR_ROLL') && (
                  <motion.div
                    initial={{ y: 90, scale: 0.86, opacity: 0 }}
                    animate={{
                      y: stage === 'STAGE_COLOR_ROLL' ? 0 : [90, -35, 0],
                      scale: stage === 'STAGE_COLOR_ROLL' ? (isColorLocked ? [1, 1.05, 1] : 1) : [0.86, 1.03, 1],
                      opacity: 1
                    }}
                    transition={{
                      duration: stage === 'STAGE_COLOR_ROLL' ? 0.35 : 0.75,
                      delay: stage === 'STAGE_CUT' ? 0.12 : 0,
                      ease: [0.16, 1, 0.3, 1]
                    }}
                    className="absolute z-25 pointer-events-none flex items-center justify-center"
                    style={{ transformStyle: 'preserve-3d' }}
                  >
                    <MysteryCardBack
                      activeRarity={rolledRarity}
                      isRolling={stage === 'STAGE_COLOR_ROLL' && !isColorLocked}
                      isLocked={stage === 'STAGE_COLOR_ROLL' && isColorLocked}
                      customBackImageUrl={cardBackImageUrl}
                    />
                  </motion.div>
                )}

                {/* THE PACK IN STAGE_READY_TO_CUT: Floating, waiting for scissors slide to cut */}
                {stage === 'STAGE_READY_TO_CUT' && (
                  <motion.div
                    initial={{ y: 25, opacity: 0, scale: 0.94 }}
                    animate={{ y: 0, opacity: 1, scale: 1 }}
                    transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                    className="relative w-56 sm:w-64 h-80 sm:h-92 flex items-center justify-center z-20 drop-shadow-[0_20px_35px_rgba(0,0,0,0.85)]"
                  >
                    <img
                      src={openingPackImageUrl}
                      alt={pack.name}
                      className="w-full h-full object-contain select-none pointer-events-none drop-shadow-[0_10px_20px_rgba(0,0,0,0.7)]"
                    />

                    {/* INTERACTIVE CUT LINE (SYNCED TO TOP TEAR SEAM) */}
                    <div
                      ref={cutTrackRef}
                      onPointerDown={handlePointerDown}
                      onPointerMove={handlePointerMove}
                      onPointerUp={handlePointerUp}
                      onPointerCancel={handlePointerUp}
                      className="absolute top-[14%] inset-x-2 sm:inset-x-3 z-40 flex items-center justify-center cursor-pointer select-none touch-none py-1"
                    >
                      <div className="relative w-full h-8 flex items-center justify-center">
                        <div className="absolute inset-x-0 h-[2px] bg-white/30 border-b border-dashed border-white/60 pointer-events-none" />

                        <div
                          className="absolute start-0 h-[3px] bg-gradient-to-r from-cyan-400 via-white to-amber-300 shadow-[0_0_14px_rgba(255,255,255,1)] pointer-events-none transition-all duration-75"
                          style={{ width: `${Math.max(0, Math.min(100, cutProgress * 100))}%` }}
                        />

                        {/* Moving Slicing Blade Handle: ONLY A SCISSOR (NO CIRCLE AROUND IT) */}
                        <motion.div
                          className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 cursor-grab active:cursor-grabbing flex items-center justify-center z-30 pointer-events-auto"
                          style={{
                            left: `${Math.max(4, Math.min(96, cutProgress * 100))}%`,
                          }}
                          animate={!isDraggingCut ? { x: [0, 4, 0] } : undefined}
                          transition={{ duration: 1.2, repeat: Infinity, ease: 'easeInOut' }}
                        >
                          <Scissors
                            size={28}
                            className="text-cyan-200 drop-shadow-[0_0_12px_rgba(94,234,212,1)] drop-shadow-[0_0_24px_rgba(6,182,212,0.85)] rotate-90 filter hover:brightness-125 transition-transform"
                          />
                        </motion.div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* THE CUT ANIMATION (STAGE_CUT) */}
                {stage === 'STAGE_CUT' && (
                  <div className="relative w-56 sm:w-64 h-80 sm:h-92 flex items-center justify-center z-20 pointer-events-none">
                    <motion.div
                      initial={{ y: 0, x: 0, rotateZ: 0, rotateX: 0, opacity: 1, scale: 1 }}
                      animate={{
                        y: -80,
                        x: -35,
                        rotateZ: -20,
                        rotateX: 40,
                        scale: 0.88,
                        opacity: 0,
                      }}
                      transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
                      style={{
                        clipPath: 'polygon(0% 0%, 100% 0%, 100% 13.5%, 0% 16%)',
                      }}
                      className="absolute inset-0 z-30 drop-shadow-[0_15px_25px_rgba(0,0,0,0.9)]"
                    >
                      <img
                        src={openingPackImageUrl}
                        alt={pack.name}
                        className="w-full h-full object-contain select-none pointer-events-none"
                      />
                    </motion.div>

                    <motion.div
                      initial={{ y: 0, opacity: 1, scale: 1 }}
                      animate={{
                        y: [0, 10, 35, 110],
                        scale: [1, 1.02, 0.96, 0.88],
                        opacity: [1, 1, 0.7, 0],
                      }}
                      transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
                      style={{
                        clipPath: 'polygon(0% 16%, 100% 13.5%, 100% 100%, 0% 100%)',
                      }}
                      className="absolute inset-0 z-20 drop-shadow-[0_20px_35px_rgba(0,0,0,0.85)]"
                    >
                      <img
                        src={openingPackImageUrl}
                        alt={pack.name}
                        className="w-full h-full object-contain select-none pointer-events-none"
                      />

                      <div className="absolute top-[13%] inset-x-0 h-20 bg-gradient-to-b from-white/95 via-cyan-400/50 to-transparent blur-xs pointer-events-none" />
                    </motion.div>

                    <motion.div
                      initial={{ left: '-100%', opacity: 1 }}
                      animate={{ left: '100%', opacity: [1, 1, 0] }}
                      transition={{ duration: 0.38, ease: 'easeInOut' }}
                      className="absolute top-[14.5%] h-[3.5px] w-full bg-white shadow-[0_0_24px_rgba(255,255,255,1),0_0_35px_rgba(94,234,212,1)] z-40"
                    />

                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: [0, 1, 0], scale: [0.8, 1.2, 1] }}
                      transition={{ duration: 0.45 }}
                      className="absolute top-[13%] inset-x-0 h-8 bg-gradient-to-r from-transparent via-white to-transparent blur-xs z-35"
                    />
                  </div>
                )}
              </div>
            )}

            {/* ---------------------------------------------------------- */}
            {/* STAGE B: STANDALONE 0 TO 100 POWER SCANNER REVEAL          */}
            {/* ---------------------------------------------------------- */}
            {stage === 'STAGE_POWER_SCAN' && (
              <StandalonePowerReveal
                targetPower={overallPower}
                rarity={rarity}
                onComplete={handlePowerScanComplete}
              />
            )}

            {/* ---------------------------------------------------------- */}
            {/* STAGE C: GRAND RARITY REVEAL                               */}
            {/* ---------------------------------------------------------- */}
            {stage === 'STAGE_RARITY_REVEAL' && (
              <GrandRarityReveal
                rarity={rarity}
                onComplete={handleRarityRevealComplete}
              />
            )}

            {/* ---------------------------------------------------------- */}
            {/* STAGE D: FLAT BLACK CARD SHAKE -> BOOM REVEAL              */}
            {/* Strictly for EPIC and LEGENDARY cards only!                */}
            {/* Flat black card, no logo, shakes hard, then BOOM!          */}
            {/* ---------------------------------------------------------- */}
            {stage === 'STAGE_SHAKE_REVEAL' && (
              <BlackCardShakeReveal
                card={card}
                rarity={rarity}
                onComplete={handleShakeRevealComplete}
                isAudioContinuingFromVideo={isVideoPlaying}
              />
            )}

            {/* ---------------------------------------------------------- */}
            {/* STAGE E: THE CARD! 3D PRESENTATION                         */}
            {/* ---------------------------------------------------------- */}
            {stage === 'STAGE_PRESENT' && (
              <motion.div
                initial={{ scale: 0.85, opacity: 0, y: 15 }}
                animate={{
                  scale: [0.85, 1.04, 1],
                  opacity: 1,
                  rotateY: tilt.y,
                  rotateX: tilt.x,
                  y: 0
                }}
                transition={{ duration: 0.48, ease: [0.16, 1, 0.3, 1] }}
                style={{ transformStyle: 'preserve-3d' }}
                className="w-full max-w-[280px] sm:max-w-[315px] flex flex-col items-center relative z-20"
              >
                <CollectibleCard
                  card={displayCard || card}
                  isOwned={true}
                  duplicateCount={result.duplicateCount}
                  onClickDetail={onInspectCard}
                  size="compact"
                  containedLighting={true}
                  progressiveReveal={false}
                />
              </motion.div>
            )}

            {/* ---------------------------------------------------------- */}
            {/* STAGE F: INDEPENDENT ITEM REVEAL SEQUENCE (ONE BY ONE)    */}
            {/* ---------------------------------------------------------- */}
            {stage === 'STAGE_ITEM_REVEAL' && packageItems[currentItemIndex] && (
              <div className="w-full h-full flex items-center justify-center relative z-20">
                <ItemRevealStage
                  item={packageItems[currentItemIndex]}
                  currentIndex={currentItemIndex}
                  totalItems={packageItems.length}
                  hasNext={currentItemIndex < packageItems.length - 1}
                  onContinue={() => {
                    setCurrentItemIndex(prev => Math.min(packageItems.length - 1, prev + 1));
                  }}
                  onFinish={handleModalClose}
                  onOpenAnother={() => {
                    setStage('STAGE_READY_TO_CUT');
                    setCutProgress(0);
                    setCurrentItemIndex(0);
                    onOpenAnother(pack);
                  }}
                  onViewCard={() => {
                    setStage('STAGE_PRESENT');
                  }}
                  canAffordAnother={canAffordAnother}
                  packPrice={pack.price}
                  isAr={isAr}
                />
              </div>
            )}
          </div>

          {/* ============================================================ */}
          {/* BOTTOM CONTROLS & DISCOVERY STATE                            */}
          {/* ============================================================ */}
          <div className="w-full max-w-sm pt-2 shrink-0 z-30">
            {stage === 'STAGE_PRESENT' ? (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="space-y-2.5 text-center"
              >
                {/* Synchronized OVR and Discovery Status Badge */}
                <div className="flex items-center justify-center gap-2 flex-wrap text-center">
                  <span className={`text-xs font-mono font-black px-2.5 py-0.5 rounded-full inline-flex items-center gap-1.5 shadow-sm bg-black/75 border ${
                    rarity === 'COMMON' ? 'text-zinc-200 border-zinc-500/40' : 'text-amber-300 border-amber-500/40'
                  }`}>
                    <span className="text-[10px] text-stone-400 font-bold uppercase">OVR</span>
                    <span className={`font-extrabold ${rarity === 'COMMON' ? 'text-zinc-200' : 'text-amber-300'}`}>{overallPower}</span>
                  </span>

                  {result.isNew ? (
                    <span className="text-xs font-sans font-medium text-emerald-400 tracking-wide inline-flex items-center gap-1.5 bg-emerald-950/50 px-2 py-0.5 rounded-full border border-emerald-500/30">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span>{isAr ? 'بطاقة جديدة مكتشفة' : 'New Relic Discovered'}</span>
                    </span>
                  ) : (
                    <span className="text-xs font-sans text-stone-400 tracking-wide bg-stone-900/60 px-2 py-0.5 rounded-full border border-white/10 flex items-center gap-1.5">
                      <span>{isAr ? `نسخة مكررة (x${result.duplicateCount})` : `Duplicate (x${result.duplicateCount})`}</span>
                    </span>
                  )}
                </div>

                {/* Action Controls Row */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onInspectCard(card)}
                    className="py-2.5 px-3 rounded-xl font-sans font-medium text-xs text-stone-300 hover:text-white bg-black/50 hover:bg-black/80 border border-white/15 flex items-center justify-center gap-1.5 transition-colors cursor-pointer shrink-0"
                    title="Inspect 3D Card"
                  >
                    <Eye size={14} />
                    <span className="hidden xs:inline">{isAr ? 'معاينة' : 'Inspect'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleShowcase(card.id)}
                    className={`py-2.5 px-3 rounded-xl font-sans font-medium text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer border shrink-0 ${
                      isShowcased
                        ? 'bg-amber-950/80 text-amber-200 border-amber-500/50'
                        : 'bg-black/50 text-stone-400 hover:text-white border-white/15'
                    }`}
                    title={isShowcased ? 'Pinned in Showcase' : 'Pin to Showcase'}
                  >
                    <Star size={14} className={isShowcased ? 'fill-current' : ''} />
                    <span className="hidden xs:inline">{isShowcased ? (isAr ? 'مثبت' : 'Pinned') : (isAr ? 'تثبيت' : 'Pin')}</span>
                  </button>

                  {/* If package contains bonus items: show subtle, elegant 'Tap to Continue' button */}
                  {packageItems.length > 0 ? (
                    <button
                      type="button"
                      onClick={() => {
                        setCurrentItemIndex(0);
                        setStage('STAGE_ITEM_REVEAL');
                      }}
                      className="group relative flex-1 py-3 px-4 rounded-xl font-serif font-bold text-xs uppercase tracking-wider text-teal-100 bg-gradient-to-r from-teal-950/90 via-slate-900 to-teal-950/90 hover:from-teal-900 hover:to-slate-800 border border-teal-500/50 shadow-[0_4px_18px_rgba(20,184,166,0.25)] hover:shadow-[0_6px_24px_rgba(94,234,212,0.4)] flex items-center justify-between transition-all active:scale-98 cursor-pointer"
                    >
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-teal-400 animate-ping" />
                        <span className="tracking-widest">{isAr ? 'انقر للمتابعة' : 'Tap to Continue'}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-teal-300/80 font-mono text-[11px] font-semibold">
                        <span>+{packageItems.length} {isAr ? 'عنصر' : (packageItems.length === 1 ? 'item' : 'items')}</span>
                        {isAr ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
                      </div>
                    </button>
                  ) : canAffordAnother ? (
                    <button
                      type="button"
                      onClick={() => {
                        setStage('STAGE_READY_TO_CUT');
                        setCutProgress(0);
                        onOpenAnother(pack);
                      }}
                      className="flex-1 py-2.5 px-4 rounded-xl font-serif font-bold text-xs uppercase tracking-wider text-stone-950 bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 hover:brightness-110 shadow-lg shadow-amber-500/10 flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                    >
                      <RotateCcw size={14} />
                      <span>{isAr ? `فتح حزمة أخرى (${pack.price} 🪙)` : `Open Again (${pack.price} 🪙)`}</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleModalClose}
                      className="flex-1 py-2.5 px-4 rounded-xl font-serif font-bold text-xs uppercase tracking-wider text-stone-950 bg-gradient-to-r from-amber-400 to-amber-300 hover:brightness-110 flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-md"
                    >
                      <Check size={14} />
                      <span>{isAr ? 'استلام ومتابعة' : 'Collect & Continue'}</span>
                    </button>
                  )}
                </div>
              </motion.div>
            ) : (
              <div className="h-2 sm:h-4" />
            )}
          </div>
        </div>
      </div>
    </AnimatePresence>
  );
};
