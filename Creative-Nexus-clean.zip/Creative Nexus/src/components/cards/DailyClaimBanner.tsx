import React, { useState } from 'react';
import { useCards } from '../../context/CardContext';
import { useAuth } from '../../context/AuthContext';
import { Sparkles, Clock, CheckCircle2, ArrowRight } from 'lucide-react';

export const DailyClaimBanner: React.FC = () => {
  const { coins, canClaimDaily, nextClaimInMs, isClaimingDaily, claimDaily } = useCards();
  const { isAuthenticated, loginWithDiscord } = useAuth();
  const [feedback, setFeedback] = useState<string | null>(null);

  // Compute hours & minutes for countdown
  const hours = Math.floor(nextClaimInMs / (1000 * 60 * 60));
  const minutes = Math.floor((nextClaimInMs % (1000 * 60 * 60)) / (1000 * 60));

  const handleClaim = async () => {
    if (!isAuthenticated) {
      loginWithDiscord();
      return;
    }
    const res = await claimDaily();
    setFeedback(res.message);
    setTimeout(() => setFeedback(null), 4000);
  };

  return (
    <div className="relative rounded-xl p-[1px] bg-gradient-to-r from-amber-500/30 via-[#5eead4]/25 to-amber-500/30 shadow-md overflow-hidden">
      <div className="relative rounded-xl bg-gradient-to-r from-[#031d20]/95 via-[#021214]/95 to-[#05181c]/95 px-3.5 sm:px-5 py-2.5 sm:py-3 flex flex-col sm:flex-row items-center justify-between gap-2.5 sm:gap-4">
        {/* Ambient subtle glow */}
        <div className="absolute -top-8 -start-8 w-28 h-28 bg-[#5eead4]/10 rounded-full blur-2xl pointer-events-none" />

        {/* LEFT: Balance & Daily Reward Info */}
        <div className="flex items-center gap-3 z-10 w-full sm:w-auto">
          {/* Coin Coin Chest Icon */}
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg bg-amber-950/70 border border-amber-500/40 flex items-center justify-center text-amber-300 shadow-xs shrink-0">
            <span className="text-xl">🪙</span>
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-[10px] sm:text-[11px] font-mono font-bold tracking-wider text-[#5eead4] uppercase">
                COIN VAULT
              </span>
              <span className="text-[11px] sm:text-xs font-mono font-black text-[#f6d98a] tabular-nums">
                {coins.toLocaleString()} 🪙
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <h4 className="text-xs sm:text-sm font-serif font-bold text-[#eafffa]">
                Daily Tribute
              </h4>
              <span className="text-[10px] font-mono font-bold text-emerald-300 bg-emerald-950/70 border border-emerald-500/30 px-1.5 py-0.2 rounded">
                +20 🪙
              </span>
            </div>
          </div>
        </div>

        {/* RIGHT: Action Button / Cooldown display */}
        <div className="flex items-center gap-2 z-10 w-full sm:w-auto justify-end shrink-0">
          {feedback && (
            <span className="text-[11px] text-[#f6d98a] font-medium italic animate-in fade-in hidden md:block">
              {feedback}
            </span>
          )}

          {!isAuthenticated ? (
            <button
              type="button"
              onClick={loginWithDiscord}
              className="w-full sm:w-auto px-3.5 py-1.5 sm:py-2 rounded-lg font-bold font-serif text-[11px] sm:text-xs tracking-wider uppercase bg-[#5865F2] hover:bg-[#4752C4] text-white flex items-center justify-center gap-1.5 transition-transform active:scale-95 shadow-sm cursor-pointer whitespace-nowrap"
            >
              <span>Login to Claim</span>
              <ArrowRight size={13} />
            </button>
          ) : canClaimDaily ? (
            <button
              type="button"
              disabled={isClaimingDaily}
              onClick={handleClaim}
              className="w-full sm:w-auto px-4 sm:px-5 py-1.5 sm:py-2 rounded-lg font-black font-serif text-[11px] sm:text-xs tracking-wider uppercase bg-gradient-to-r from-amber-400 via-[#f6d98a] to-amber-500 hover:from-[#f6d98a] hover:to-amber-400 text-stone-950 flex items-center justify-center gap-1.5 transition-transform active:scale-95 shadow-md shadow-amber-500/25 cursor-pointer whitespace-nowrap"
            >
              {isClaimingDaily ? (
                <span>Claiming...</span>
              ) : (
                <>
                  <Sparkles size={13} />
                  <span>CLAIM +20 COINS</span>
                </>
              )}
            </button>
          ) : (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-black/60 border border-white/10 text-stone-300 text-xs w-full sm:w-auto justify-center">
              <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
              <div className="flex items-center gap-2 text-[11px] font-mono">
                <span className="text-emerald-400 font-bold">CLAIMED</span>
                <span className="text-stone-400 flex items-center gap-1">
                  <Clock size={11} className="text-[#f6d98a]" />
                  {hours}h {minutes}m
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
