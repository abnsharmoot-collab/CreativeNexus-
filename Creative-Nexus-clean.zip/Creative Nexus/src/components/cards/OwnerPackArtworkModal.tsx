import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useCards } from '../../context/CardContext';
import { CardRarity, PackCustomizationSettings } from '../../types/cards';
import {
  X, Image as ImageIcon, Sparkles, CheckCircle2, AlertCircle,
  Upload, RotateCcw, Save, Tag, Box, Eye
} from 'lucide-react';
import { MesopotamianCornerBrackets } from '../atoms/MesopotamianCornerBrackets';
import { MODERN_CARD_ASSETS } from '../../assets/modernCardAssets';
import { MESOPOTAMIAN_ASSETS } from '../../assets/mesopotamianAssets';

interface OwnerPackArtworkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const DEFAULT_SHOP_IMAGES: Record<CardRarity, string> = {
  COMMON: MODERN_CARD_ASSETS.packCommonApex,
  UNCOMMON: MODERN_CARD_ASSETS.packUncommonPrism,
  RARE: MODERN_CARD_ASSETS.packRareAzure,
  EPIC: MODERN_CARD_ASSETS.packEpicHyperion,
  LEGENDARY: MODERN_CARD_ASSETS.packLegendarySovereign,
  HALLOWEEN_2026: MODERN_CARD_ASSETS.packLegendarySovereign,
};

const DEFAULT_OPEN_IMAGES: Record<CardRarity, string> = {
  COMMON: MODERN_CARD_ASSETS.packCommonApex,
  UNCOMMON: MESOPOTAMIAN_ASSETS.packUncommonJade,
  RARE: MESOPOTAMIAN_ASSETS.packRareLapis,
  EPIC: MESOPOTAMIAN_ASSETS.packEpicAmethyst,
  LEGENDARY: MESOPOTAMIAN_ASSETS.packLegendaryGold,
  HALLOWEEN_2026: MESOPOTAMIAN_ASSETS.packLegendaryGold,
};

const DEFAULT_NAMES: Record<CardRarity, string> = {
  COMMON: 'Apex Common Pack',
  UNCOMMON: 'Prism Uncommon Pack',
  RARE: 'Azure Rare Pack',
  EPIC: 'Hyperion Epic Pack',
  LEGENDARY: 'Sovereign Legendary Reliquary',
  HALLOWEEN_2026: 'Halloween 2026 Reliquary',
};

const RARITY_THEMES: Record<CardRarity, { label: string; accent: string; badge: string }> = {
  COMMON: { label: 'COMMON', accent: '#9ca3af', badge: 'text-zinc-300 border-zinc-500/40 bg-zinc-900/70' },
  UNCOMMON: { label: 'UNCOMMON', accent: '#10b981', badge: 'text-emerald-300 border-emerald-500/40 bg-emerald-950/70' },
  RARE: { label: 'RARE', accent: '#06b6d4', badge: 'text-cyan-300 border-cyan-500/40 bg-cyan-950/70' },
  EPIC: { label: 'EPIC', accent: '#a855f7', badge: 'text-purple-300 border-purple-500/40 bg-purple-950/70' },
  LEGENDARY: { label: 'LEGENDARY', accent: '#fbbf24', badge: 'text-yellow-300 border-yellow-500/50 bg-amber-950/80' },
  HALLOWEEN_2026: { label: 'HALLOWEEN 2026', accent: '#ff5e00', badge: 'text-orange-300 border-orange-500/50 bg-purple-950/80' }
};

export const OwnerPackArtworkModal: React.FC<OwnerPackArtworkModalProps> = ({
  isOpen,
  onClose
}) => {
  const { isOwner } = useAuth();
  const { packs, ownerSavePackCustomizations, cardBackImageUrl, ownerSaveCardBackImage } = useCards();

  const [settings, setSettings] = useState<Record<CardRarity, PackCustomizationSettings>>({
    COMMON: {},
    UNCOMMON: {},
    RARE: {},
    EPIC: {},
    LEGENDARY: {},
    HALLOWEEN_2026: {}
  });

  const [activeTab, setActiveTab] = useState<CardRarity | 'CARD_BACK'>('LEGENDARY');
  const [customCardBackUrl, setCustomCardBackUrl] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Initialize from current active packs and card back
  useEffect(() => {
    if (isOpen && packs.length > 0) {
      const initial: Record<CardRarity, PackCustomizationSettings> = {
        COMMON: {},
        UNCOMMON: {},
        RARE: {},
        EPIC: {},
        LEGENDARY: {},
        HALLOWEEN_2026: {}
      };
      packs.forEach(p => {
        initial[p.rarity] = {
          name: p.name || DEFAULT_NAMES[p.rarity],
          imageUrl: p.imageUrl || DEFAULT_SHOP_IMAGES[p.rarity],
          openImageUrl: p.openImageUrl || DEFAULT_OPEN_IMAGES[p.rarity]
        };
      });
      setSettings(initial);
      setCustomCardBackUrl(cardBackImageUrl || '');
      setSuccessMsg(null);
      setErrorMsg(null);
    }
  }, [isOpen, packs, cardBackImageUrl]);

  if (!isOpen || !isOwner) return null;

  const handleFieldChange = (rarity: CardRarity, field: keyof PackCustomizationSettings, value: string) => {
    setSettings(prev => ({
      ...prev,
      [rarity]: {
        ...prev[rarity],
        [field]: value
      }
    }));
  };

  const handleFileUpload = (
    rarity: CardRarity,
    field: 'imageUrl' | 'openImageUrl',
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 4 * 1024 * 1024) {
      setErrorMsg('Image file size must be under 4MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        handleFieldChange(rarity, field, dataUrl);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleCardBackUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setErrorMsg('Card Back image file size must be under 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setCustomCardBackUrl(dataUrl);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleResetToDefault = (rarity: CardRarity) => {
    setSettings(prev => ({
      ...prev,
      [rarity]: {
        name: DEFAULT_NAMES[rarity],
        imageUrl: DEFAULT_SHOP_IMAGES[rarity],
        openImageUrl: DEFAULT_OPEN_IMAGES[rarity]
      }
    }));
  };

  const handleSaveAll = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSuccessMsg(null);
    setErrorMsg(null);

    try {
      await ownerSavePackCustomizations(settings);
      if (ownerSaveCardBackImage) {
        await ownerSaveCardBackImage(customCardBackUrl);
      }
      setSuccessMsg('Package and Card Back artwork successfully updated!');
      setTimeout(() => {
        onClose();
      }, 1400);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update artwork settings');
    } finally {
      setIsSaving(false);
    }
  };

  const currentSettings = activeTab !== 'CARD_BACK' ? (settings[activeTab] || {}) : {};
  const currentTheme = activeTab !== 'CARD_BACK' ? RARITY_THEMES[activeTab] : null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto select-none"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-4xl bg-gradient-to-b from-[#0f1418] via-[#090d10] to-[#040608] border border-amber-500/35 rounded-3xl p-4 sm:p-7 shadow-2xl shadow-black overflow-hidden my-auto max-h-[92dvh] flex flex-col"
      >
        <MesopotamianCornerBrackets className="opacity-70 pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-center text-amber-300 shadow-inner">
              <Box size={22} />
            </div>
            <div>
              <span className="text-[10px] font-mono tracking-widest text-amber-400 uppercase font-bold">
                OWNER STORE ARCHITECTURE
              </span>
              <h2 className="text-lg sm:text-2xl font-black font-serif text-amber-100">
                PACKAGE CUSTOMIZATION
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="p-2 rounded-xl text-stone-400 hover:text-white bg-black/40 hover:bg-black border border-white/10 transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Feedback Alerts */}
        {successMsg && (
          <div className="mt-3 p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2">
            <CheckCircle2 size={16} className="shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}
        {errorMsg && (
          <div className="mt-3 p-3 rounded-xl bg-rose-950/80 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2">
            <AlertCircle size={16} className="shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Rarity and Card Back Tabs */}
        <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto py-3 border-b border-white/10 shrink-0 no-scrollbar">
          {(['COMMON', 'UNCOMMON', 'RARE', 'EPIC', 'LEGENDARY'] as CardRarity[]).map((r) => {
            const isActive = activeTab === r;
            const theme = RARITY_THEMES[r];
            return (
              <button
                key={r}
                type="button"
                onClick={() => setActiveTab(r)}
                className={`px-3 py-2 rounded-xl text-xs font-serif font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
                  isActive
                    ? 'bg-amber-500/20 text-amber-200 border border-amber-400/80 shadow-md'
                    : 'bg-black/40 text-stone-400 hover:text-white border border-white/10'
                }`}
              >
                <span
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: theme.accent }}
                />
                <span>{theme.label}</span>
              </button>
            );
          })}

          {/* Dedicated Flat Card Back Tab */}
          <button
            type="button"
            onClick={() => setActiveTab('CARD_BACK')}
            className={`px-3.5 py-2 rounded-xl text-xs font-serif font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              activeTab === 'CARD_BACK'
                ? 'bg-amber-500/25 text-amber-200 border border-amber-400 shadow-md'
                : 'bg-black/40 text-stone-400 hover:text-white border border-white/10'
            }`}
          >
            <span>🃏</span>
            <span>Card Back (Flat PNG)</span>
          </button>
        </div>

        {/* Main Content Area */}
        <form onSubmit={handleSaveAll} className="flex-1 overflow-y-auto py-4 space-y-6">
          {activeTab === 'CARD_BACK' ? (
            /* Card Back Flat PNG Configuration */
            <div className="space-y-6">
              <div className="p-4 sm:p-5 rounded-2xl bg-black/40 border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-serif font-bold text-amber-200 flex items-center gap-2">
                    <Box size={16} className="text-amber-400" />
                    <span>Flat Card Back Artwork (Device PNG)</span>
                  </h3>
                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded border border-amber-500/40 text-amber-300 bg-amber-950/40">
                    FLAT CARD MODE
                  </span>
                </div>
                <p className="text-xs text-stone-300 leading-relaxed">
                  During pack opening, the card color roll is a flat card without any words, without elements, just the back of the card. The card's borders take the exact shape and borders of your chosen PNG image.
                </p>
                <p className="text-[11px] text-stone-400">
                  Upload any custom PNG from your device (with transparency or custom borders). If no image is uploaded, the clean server emblem will be displayed.
                </p>
              </div>

              {/* Card Back Preview & Upload Actions */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                {/* Live Preview */}
                <div className="p-4 sm:p-5 rounded-2xl bg-black/40 border border-white/10 flex flex-col items-center justify-center space-y-3 min-h-[340px]">
                  <span className="text-[10px] font-mono tracking-widest text-stone-400 uppercase">
                    COLOR ROLL FLAT PREVIEW
                  </span>

                  <div className="relative flex items-center justify-center p-4">
                    {customCardBackUrl ? (
                      <div
                        className="relative flex items-center justify-center select-none"
                        style={{
                          filter: 'drop-shadow(0 0 25px rgba(245, 158, 11, 0.75)) drop-shadow(0 15px 30px rgba(0,0,0,0.85))'
                        }}
                      >
                        <img
                          src={customCardBackUrl}
                          alt="Custom Card Back"
                          className="max-h-64 w-auto object-contain pointer-events-none select-none rounded-xl"
                        />
                      </div>
                    ) : (
                      <div
                        className="w-48 h-64 rounded-2xl flex items-center justify-center relative overflow-hidden select-none"
                        style={{
                          background: 'radial-gradient(circle at 50% 50%, #0d1a18 0%, #050b0a 65%, #020504 100%)',
                          boxShadow: '0 0 35px rgba(245, 158, 11, 0.4), 0 20px 40px rgba(0,0,0,0.9)'
                        }}
                      >
                        <div className="w-20 h-20 flex items-center justify-center text-amber-300 drop-shadow-[0_0_15px_rgba(245,158,11,0.8)]">
                          <svg viewBox="0 0 200 200" className="w-full h-full fill-amber-300">
                            <path transform="translate(58 6) scale(1.24)" d="M50 0C53 31 69 47 100 50C69 53 53 69 50 100C47 69 31 53 0 50C31 47 47 31 50 0Z" />
                            <path transform="translate(8 96) scale(.9)" d="M50 0C53 31 69 47 100 50C69 53 53 69 50 100C47 69 31 53 0 50C31 47 47 31 50 0Z" />
                          </svg>
                        </div>
                      </div>
                    )}
                  </div>

                  <span className="text-[10px] font-mono text-stone-500">
                    {customCardBackUrl ? 'Custom PNG Active (Takes Image Shape)' : 'Default Server Emblem (Flat Card)'}
                  </span>
                </div>

                {/* Upload & Controls */}
                <div className="p-4 sm:p-5 rounded-2xl bg-black/40 border border-white/10 flex flex-col justify-between space-y-4">
                  <div className="space-y-3">
                    <label className="text-xs font-serif font-bold text-amber-200 flex items-center gap-1.5">
                      <Upload size={15} className="text-amber-400" />
                      <span>Choose Card Back PNG from Device</span>
                    </label>

                    <label className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500/20 to-amber-600/15 hover:from-amber-500/30 hover:to-amber-600/25 text-amber-200 text-xs font-serif font-bold flex items-center justify-center gap-2 border border-amber-500/40 cursor-pointer transition-all shadow-md active:scale-98">
                      <Upload size={16} className="text-amber-300" />
                      <span>Upload PNG File from Device</span>
                      <input
                        type="file"
                        accept="image/png,image/webp,image/jpeg"
                        className="hidden"
                        onChange={handleCardBackUpload}
                      />
                    </label>

                    <div className="pt-2">
                      <label className="text-[11px] font-mono text-stone-400 block mb-1.5">
                        Or enter direct Image URL:
                      </label>
                      <input
                        type="text"
                        value={customCardBackUrl}
                        onChange={(e) => setCustomCardBackUrl(e.target.value)}
                        placeholder="https://..."
                        className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-amber-500/30 text-xs text-stone-200 placeholder-stone-500 focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  {customCardBackUrl && (
                    <button
                      type="button"
                      onClick={() => setCustomCardBackUrl('')}
                      className="py-2 px-3 rounded-xl text-xs font-serif text-rose-300 hover:text-white bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/30 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <RotateCcw size={13} />
                      <span>Reset to Server Logo</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ) : (
            /* Booster Pack Customization (COMMON .. LEGENDARY) */
            <>
              {/* 1. Pack Name Customization */}
              <div className="p-4 sm:p-5 rounded-2xl bg-black/40 border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-serif font-bold text-amber-200 flex items-center gap-1.5">
                    <Tag size={15} className="text-amber-400" />
                    <span>Booster Pack Name</span>
                  </label>
                  {currentTheme && (
                    <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded border ${currentTheme.badge}`}>
                      {activeTab} TIER
                    </span>
                  )}
                </div>
                <input
                  type="text"
                  value={currentSettings.name ?? (DEFAULT_NAMES[activeTab as CardRarity] || '')}
                  onChange={(e) => handleFieldChange(activeTab as CardRarity, 'name', e.target.value)}
                  placeholder={DEFAULT_NAMES[activeTab as CardRarity] || ''}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-900/90 border border-white/15 text-sm text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-400 transition-colors"
                />
                <p className="text-[11px] text-stone-400">
                  The title displayed in the Card Shop catalog and on player inventory shelves.
                </p>
              </div>

              {/* 2. Dual Image Customization: Shop Catalog Image & Card Open Image */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                {/* Catalog / Shop Image */}
                <div className="p-4 sm:p-5 rounded-2xl bg-black/40 border border-white/10 space-y-3 flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-serif font-bold text-stone-200 flex items-center gap-1.5">
                        <ImageIcon size={15} className="text-amber-400" />
                        <span>Card Shop Catalog Image</span>
                      </label>
                      <span className="text-[10px] font-mono text-stone-400">STOREFRONT</span>
                    </div>

                    <div className="aspect-[3/4] max-h-52 w-full rounded-xl overflow-hidden border border-white/10 bg-stone-950 flex items-center justify-center relative">
                      <img
                        src={currentSettings.imageUrl || DEFAULT_SHOP_IMAGES[activeTab as CardRarity]}
                        alt="Catalog preview"
                        className="w-full h-full object-cover"
                      />
                      <span className="absolute bottom-2 start-2 text-[9px] font-mono bg-black/80 px-2 py-0.5 rounded text-amber-300 border border-white/10">
                        Store Catalog Preview
                      </span>
                    </div>

                    <input
                      type="text"
                      value={currentSettings.imageUrl ?? (DEFAULT_SHOP_IMAGES[activeTab as CardRarity] || '')}
                      onChange={(e) => handleFieldChange(activeTab as CardRarity, 'imageUrl', e.target.value)}
                      placeholder="https://..."
                      className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-white/10 text-xs text-stone-200 placeholder-stone-500 focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="w-full py-2 px-3 rounded-xl bg-stone-800/80 hover:bg-stone-700 text-stone-200 text-xs font-serif flex items-center justify-center gap-2 border border-white/10 cursor-pointer transition-colors">
                      <Upload size={14} className="text-stone-300" />
                      <span>Upload Catalog Art</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handleFileUpload(activeTab as CardRarity, 'imageUrl', e)}
                      />
                    </label>
                  </div>
                </div>

                {/* Opening Pack Image */}
                <div className="p-4 sm:p-5 rounded-2xl bg-black/40 border border-amber-500/25 space-y-3 flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-serif font-bold text-amber-200 flex items-center gap-1.5">
                        <Box size={15} className="text-amber-400" />
                        <span>Card Open Booster Pack Art</span>
                      </label>
                      <span className="text-[10px] font-mono text-amber-400">UNSEAL ARENA</span>
                    </div>

                    <div className="aspect-[3/4] max-h-52 w-full rounded-xl overflow-hidden border border-amber-500/40 bg-stone-950 flex items-center justify-center relative shadow-lg">
                      <img
                        src={currentSettings.openImageUrl || DEFAULT_OPEN_IMAGES[activeTab as CardRarity]}
                        alt="Open Pack Preview"
                        className="w-full h-full object-contain"
                      />
                      <span className="absolute bottom-2 start-2 text-[9px] font-mono bg-black/85 px-2 py-0.5 rounded text-amber-300 border border-amber-500/40">
                        Unseal Modal Preview
                      </span>
                    </div>

                    <input
                      type="text"
                      value={currentSettings.openImageUrl ?? (DEFAULT_OPEN_IMAGES[activeTab as CardRarity] || '')}
                      onChange={(e) => handleFieldChange(activeTab as CardRarity, 'openImageUrl', e.target.value)}
                      placeholder="https://..."
                      className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-amber-500/30 text-xs text-stone-200 placeholder-stone-500 focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="w-full py-2 px-3 rounded-xl bg-amber-950/60 hover:bg-amber-900/80 text-amber-200 text-xs font-serif flex items-center justify-center gap-2 border border-amber-500/40 cursor-pointer transition-colors">
                      <Upload size={14} className="text-amber-300" />
                      <span>Upload Card Open Art</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handleFileUpload(activeTab as CardRarity, 'openImageUrl', e)}
                      />
                    </label>
                  </div>
                </div>
              </div>

              {/* Tier Reset Controls */}
              <div className="flex items-center justify-between pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => handleResetToDefault(activeTab as CardRarity)}
                  className="px-3.5 py-2 rounded-xl text-xs font-serif text-stone-400 hover:text-white bg-black/40 hover:bg-black/70 border border-white/10 flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <RotateCcw size={14} />
                  <span>Reset {activeTab} Defaults</span>
                </button>

                <span className="text-[11px] text-stone-400 italic">
                  Changes apply instantly across all player sessions upon saving.
                </span>
              </div>
            </>
          )}

          {/* Footer Save Action */}
          <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-serif text-stone-400 hover:text-white transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 rounded-xl text-xs font-serif font-bold uppercase tracking-wider text-stone-950 bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 hover:brightness-110 shadow-lg shadow-amber-500/10 flex items-center gap-2 transition-all active:scale-95 cursor-pointer disabled:opacity-50"
            >
              <Save size={15} />
              <span>{isSaving ? 'Deploying Changes...' : 'Save All Artwork & Settings'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
