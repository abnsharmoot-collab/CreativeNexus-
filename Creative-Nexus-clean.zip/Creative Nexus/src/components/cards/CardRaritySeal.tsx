import React from 'react';
import { CardRarity, CardElement } from '../../types/cards';
import { Sparkles, Globe, Wind, Flame, Droplets, Crown, Zap, ShieldAlert, Circle } from 'lucide-react';
import { getRarityConfig } from '../../config/rarityConfig';

interface CardRaritySealProps {
  rarity: CardRarity;
  element?: CardElement;
  accentColor?: string;
  borderColor?: string;
  isLegendary?: boolean;
  cardNumber?: number;
}

const ELEMENT_DATA: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
  ASTRAL: { label: 'Astral', icon: <Sparkles size={11} />, color: '#f59e0b' },
  STONE: { label: 'Titan', icon: <Globe size={11} />, color: '#94a3b8' },
  STORM: { label: 'Storm', icon: <Wind size={11} />, color: '#38bdf8' },
  FIRE: { label: 'Plasma', icon: <Flame size={11} />, color: '#f43f5e' },
  WATER: { label: 'Glacial', icon: <Droplets size={11} />, color: '#38bdf8' },
};

export const CardRaritySeal: React.FC<CardRaritySealProps> = ({
  rarity,
  element = 'ASTRAL',
  accentColor,
  borderColor,
}) => {
  const elData = ELEMENT_DATA[element] || ELEMENT_DATA.ASTRAL;
  const config = getRarityConfig(rarity);
  const primaryColor = borderColor || accentColor || config.primaryColor;

  if (config.id === 'HALLOWEEN_2026') {
    return (
      <div className="flex items-center gap-1.5 sm:gap-2 select-none pointer-events-none">
        {/* Halloween 2026 Limited Edition Cartouche */}
        <div
          className="relative inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-xl shadow-lg border backdrop-blur-md overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, rgba(50,14,0,0.96) 0%, rgba(24,2,30,0.98) 100%)',
            borderColor: '#ff5e00',
            boxShadow: '0 4px 16px rgba(0,0,0,0.9), 0 0 16px rgba(255,94,0,0.7), 0 0 8px rgba(176,38,255,0.6)',
          }}
        >
          {/* Subtle light sweep */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-orange-300/20 to-transparent pointer-events-none animate-pulse" />

          {/* Spooky Pumpkin Icon */}
          <span className="text-xs shrink-0 drop-shadow-[0_0_6px_#ff5e00]">🎃</span>

          {/* Limited tag */}
          <span className="text-[9px] font-mono font-bold tracking-wider text-orange-200 uppercase">MYTHIC</span>

          {/* Gemstone Accent */}
          <span className="w-2 h-2 rounded-full bg-orange-400 shrink-0 shadow-[0_0_8px_#ff5e00]" />
        </div>

        {/* Element Glyph */}
        <div
          className="inline-flex items-center gap-1 px-1.5 sm:px-2 py-0.8 rounded-lg border text-[9px] font-sans font-semibold uppercase tracking-wider backdrop-blur-md bg-black/60"
          style={{
            borderColor: `${elData.color}50`,
            color: elData.color
          }}
        >
          {elData.icon}
          <span className="hidden sm:inline text-[9px]">{elData.label}</span>
        </div>
      </div>
    );
  }

  if (config.id === 'LEGENDARY') {
    return (
      <div className="flex items-center gap-1.5 sm:gap-2 select-none pointer-events-none">
        {/* Sovereign Gold Cartouche */}
        <div
          className="relative inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1 rounded-xl shadow-lg border backdrop-blur-md overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, rgba(38,18,2,0.95) 0%, rgba(15,7,1,0.98) 100%)',
            borderColor: '#f59e0b',
            boxShadow: '0 4px 14px rgba(0,0,0,0.85), 0 0 14px rgba(245,158,11,0.5), 0 0 4px rgba(255,215,0,0.4)',
          }}
        >
          {/* Subtle light sweep */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-amber-200/15 to-transparent pointer-events-none" />

          {/* Golden Crown Sigil */}
          <Crown size={12} className="text-amber-400 shrink-0 drop-shadow-[0_0_6px_rgba(245,158,11,0.8)]" />

          {/* Gemstone Accent without rarity text */}
          <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0 shadow-[0_0_8px_#ffd700]" />
        </div>

        {/* Discreet Element Glyph */}
        <div
          className="inline-flex items-center gap-1 px-1.5 sm:px-2 py-0.8 rounded-lg border text-[9px] font-sans font-semibold uppercase tracking-wider backdrop-blur-md bg-black/60"
          style={{
            borderColor: `${elData.color}50`,
            color: elData.color
          }}
        >
          {elData.icon}
          <span className="hidden sm:inline text-[9px]">{elData.label}</span>
        </div>
      </div>
    );
  }

  if (config.id === 'EPIC') {
    return (
      <div className="flex items-center gap-1.5 sm:gap-2 select-none pointer-events-none">
        {/* Royal Amethyst Cartouche without rarity text */}
        <div
          className="relative inline-flex items-center gap-1.5 px-2 py-1 rounded-xl shadow-lg border backdrop-blur-md overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, rgba(32,10,50,0.94) 0%, rgba(14,3,24,0.98) 100%)',
            borderColor: '#a855f7',
            boxShadow: '0 4px 12px rgba(0,0,0,0.85), 0 0 12px rgba(168,85,247,0.45)',
          }}
        >
          <span className="text-[11px] text-purple-300">✦</span>
          <span className="w-1.5 h-1.5 rounded-full bg-purple-400 shrink-0 shadow-[0_0_6px_rgba(168,85,247,0.9)]" />
        </div>

        <div
          className="inline-flex items-center gap-1 px-1.5 sm:px-2 py-0.8 rounded-lg border text-[9px] font-sans font-medium uppercase tracking-wider backdrop-blur-md bg-black/60"
          style={{ borderColor: `${elData.color}40`, color: elData.color }}
        >
          {elData.icon}
          <span className="hidden sm:inline">{elData.label}</span>
        </div>
      </div>
    );
  }

  if (config.id === 'RARE') {
    return (
      <div className="flex items-center gap-1.5 sm:gap-2 select-none pointer-events-none">
        {/* Sapphire Azure Cartouche without rarity text */}
        <div
          className="relative inline-flex items-center gap-1.5 px-2 py-1 rounded-xl shadow-md border backdrop-blur-md overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, rgba(6,28,58,0.94) 0%, rgba(3,13,30,0.98) 100%)',
            borderColor: '#3b82f6',
            boxShadow: '0 4px 10px rgba(0,0,0,0.8), 0 0 10px rgba(59,130,246,0.4)',
          }}
        >
          <span className="text-[10px] text-blue-300">◆</span>
          <span className="w-1.5 h-1.5 rounded-full bg-blue-400 shrink-0 shadow-[0_0_6px_rgba(59,130,246,0.8)]" />
        </div>

        <div
          className="inline-flex items-center gap-1 px-1.5 sm:px-2 py-0.8 rounded-lg border text-[9px] font-sans font-medium uppercase tracking-wider backdrop-blur-md bg-black/60"
          style={{ borderColor: `${elData.color}40`, color: elData.color }}
        >
          {elData.icon}
          <span className="hidden sm:inline">{elData.label}</span>
        </div>
      </div>
    );
  }

  if (config.id === 'UNCOMMON') {
    return (
      <div className="flex items-center gap-1.5 sm:gap-2 select-none pointer-events-none">
        {/* Emerald Jade Cartouche without rarity text */}
        <div
          className="relative inline-flex items-center gap-1.5 px-2 py-0.8 rounded-xl shadow-sm border backdrop-blur-md overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, rgba(6,32,16,0.94) 0%, rgba(2,16,8,0.98) 100%)',
            borderColor: '#35C759',
            boxShadow: '0 3px 8px rgba(0,0,0,0.8), 0 0 8px rgba(53,199,89,0.3)',
          }}
        >
          <span className="text-[9px] text-emerald-300">▲</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0 shadow-[0_0_4px_#35c759]" />
        </div>

        <div
          className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md border text-[9px] font-sans text-stone-300 backdrop-blur-md bg-black/50"
          style={{ borderColor: 'rgba(255,255,255,0.1)' }}
        >
          {elData.icon}
        </div>
      </div>
    );
  }

  // COMMON: Muted gray, desaturated, basic, mass-produced
  return (
    <div className="flex items-center gap-1.5 sm:gap-2 select-none pointer-events-none">
      <div
        className="relative inline-flex items-center gap-1.5 px-2 py-0.8 rounded-xl border backdrop-blur-md overflow-hidden bg-zinc-900/90"
        style={{
          borderColor: '#555555',
          boxShadow: '0 2px 6px rgba(0,0,0,0.7), 0 0 4px rgba(119,119,119,0.15)',
        }}
      >
        <span className="w-1.5 h-1.5 rounded-full bg-zinc-500" />
      </div>

      <div
        className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md border text-[9px] font-sans text-stone-400 backdrop-blur-md bg-black/50"
        style={{ borderColor: 'rgba(255,255,255,0.08)' }}
      >
        {elData.icon}
      </div>
    </div>
  );
};
