import React, { useState, useEffect, useRef } from 'react';
import { X, Volume2, Upload, Play, Music, Check, RefreshCw, Trash2, Scissors, Hand, Sparkles, Crown } from 'lucide-react';
import { RevealSfxConfig, DEFAULT_SFX_CONFIG, playAudioUrl, playRevealSound } from '../../utils/cardRevealAudio';

interface OwnerRevealAudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaved?: (config: RevealSfxConfig) => void;
}

export const OwnerRevealAudioModal: React.FC<OwnerRevealAudioModalProps> = ({
  isOpen,
  onClose,
  onSaved
}) => {
  const [config, setConfig] = useState<RevealSfxConfig>(DEFAULT_SFX_CONFIG);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [testingKey, setTestingKey] = useState<string | null>(null);

  const fileInputRefs = {
    cut: useRef<HTMLInputElement>(null),
    pull: useRef<HTMLInputElement>(null),
    reveal: useRef<HTMLInputElement>(null),
    legendary: useRef<HTMLInputElement>(null)
  };

  // Fetch current settings on open
  useEffect(() => {
    if (!isOpen) return;
    let isMounted = true;
    setError(null);

    fetch('/api/cards/reveal-sfx')
      .then(res => res.json())
      .then(data => {
        if (isMounted && data.success && data.sfxConfig) {
          setConfig({
            volume: typeof data.sfxConfig.volume === 'number' ? data.sfxConfig.volume : 0.75,
            enabled: data.sfxConfig.enabled !== false,
            deviceAudio: data.sfxConfig.deviceAudio || {}
          });
        }
      })
      .catch(err => {
        console.warn('Failed to load sfx config, using defaults:', err);
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleFileUpload = (
    key: 'cut' | 'pull' | 'reveal' | 'legendary',
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/') && !file.name.match(/\.(mp3|wav|ogg|m4a|aac|webm)$/i)) {
      setError('Please select an audio file (MP3, WAV, OGG, M4A, etc.)');
      return;
    }

    if (file.size > 8 * 1024 * 1024) {
      setError('Audio file is too large (maximum 8MB per effect)');
      return;
    }

    setError(null);
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setConfig(prev => ({
        ...prev,
        deviceAudio: {
          ...prev.deviceAudio,
          [key]: {
            dataUrl,
            fileName: file.name,
            fileSize: file.size
          }
        }
      }));
    };
    reader.onerror = () => {
      setError('Failed to read audio file from device');
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveSlot = (key: 'cut' | 'pull' | 'reveal' | 'legendary') => {
    setConfig(prev => {
      const nextAudio = { ...prev.deviceAudio };
      delete nextAudio[key];
      return {
        ...prev,
        deviceAudio: nextAudio
      };
    });
    if (fileInputRefs[key].current) {
      fileInputRefs[key].current!.value = '';
    }
  };

  const handleTestSlot = async (key: 'cut' | 'pull' | 'reveal' | 'legendary') => {
    setTestingKey(key);
    try {
      const slot = config.deviceAudio?.[key];
      if (slot?.dataUrl) {
        await playAudioUrl(slot.dataUrl, config.volume);
      } else {
        await playRevealSound(key, key === 'legendary' ? 'LEGENDARY' : 'COMMON', config);
      }
    } finally {
      setTimeout(() => setTestingKey(null), 800);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setError(null);
    try {
      const res = await fetch('/api/cards/owner/reveal-sfx', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sfxConfig: config })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to save sound settings');
      }
      setSaveSuccess(true);
      if (onSaved) onSaved(data.sfxConfig);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err: any) {
      setError(err.message || 'Error saving settings');
    } finally {
      setIsSaving(false);
    }
  };

  const audioSlots: Array<{
    key: 'cut' | 'pull' | 'reveal' | 'legendary';
    title: string;
    titleAr: string;
    description: string;
    icon: React.ReactNode;
    accentColor: string;
  }> = [
    {
      key: 'cut',
      title: '1. Package Cut & Foil Slice',
      titleAr: 'صوت قطع الغلاف العلوي',
      description: 'Plays at the exact instant the upper part of the booster pack is sliced open.',
      icon: <Scissors size={18} />,
      accentColor: '#38bdf8'
    },
    {
      key: 'pull',
      title: '2. Card Pull Out (Slide)',
      titleAr: 'صوت سحب الكرت من الغلاف',
      description: 'Plays smoothly as the card is drawn and pulled upwards out from the opened pack.',
      icon: <Hand size={18} />,
      accentColor: '#5eead4'
    },
    {
      key: 'reveal',
      title: '3. Card Reveal (Manifestation)',
      titleAr: 'صوت كشف الكرت والرتبة',
      description: 'Plays when the card turns and reveals its character artwork and tier.',
      icon: <Sparkles size={18} />,
      accentColor: '#a855f7'
    },
    {
      key: 'legendary',
      title: '4. Legendary Fanfare / Impact',
      titleAr: 'صوت كشف كروت الليجندري النادرة',
      description: 'Special sound played when opening high-tier Legendary relics.',
      icon: <Crown size={18} />,
      accentColor: '#f59e0b'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-stone-900 via-stone-950 to-stone-900 border border-amber-500/40 rounded-3xl shadow-2xl p-4 sm:p-6 my-auto text-stone-200 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-center text-amber-300 shadow-inner shrink-0">
              <Music size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono uppercase font-bold text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-500/30">
                  DEVICE AUDIO UPLOAD
                </span>
                <span className="text-xs text-stone-400 font-mono">OWNER SFX</span>
              </div>
              <h2 className="text-lg sm:text-xl font-bold font-serif text-[#eafffa]">
                Custom Device Sound Effects // مؤثرات صوتية من جهازك
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-white bg-black/40 hover:bg-black/80 border border-white/10 transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Feedback Alerts */}
        {saveSuccess && (
          <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-200 text-xs flex items-center gap-2">
            <Check size={16} className="text-emerald-400 shrink-0" />
            <span>Device sound effects saved successfully! All users will now hear your custom sound files.</span>
          </div>
        )}

        {error && (
          <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs flex items-center gap-2">
            <X size={16} className="text-rose-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Audio Slots from Device */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-mono uppercase tracking-wider text-amber-300 font-bold block">
              Upload Audio From Your Device // اختر الأصوات من ملفات جهازك
            </label>
            <span className="text-[11px] font-mono text-stone-400">MP3 / WAV / OGG</span>
          </div>

          <div className="space-y-2.5">
            {audioSlots.map(slot => {
              const currentAudio = config.deviceAudio?.[slot.key];
              const hasCustom = Boolean(currentAudio?.dataUrl);

              return (
                <div
                  key={slot.key}
                  className={`p-3 sm:p-3.5 rounded-2xl border transition-all ${
                    hasCustom
                      ? 'bg-stone-900/90 border-amber-500/40 shadow-sm'
                      : 'bg-black/50 border-white/10'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0">
                      <div
                        className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 shadow-inner"
                        style={{
                          backgroundColor: `${slot.accentColor}18`,
                          color: slot.accentColor,
                          border: `1px solid ${slot.accentColor}40`
                        }}
                      >
                        {slot.icon}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-xs sm:text-sm text-stone-100">{slot.title}</span>
                          <span className="text-[10px] text-amber-200/70 font-arabic">{slot.titleAr}</span>
                        </div>
                        <p className="text-[11px] text-stone-400 mt-0.5">{slot.description}</p>
                        {hasCustom ? (
                          <div className="mt-1 flex items-center gap-1.5 text-[10px] font-mono text-emerald-400">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                            <span className="truncate max-w-[200px]">{currentAudio?.fileName || 'Custom File'}</span>
                            {currentAudio?.fileSize && (
                              <span className="text-stone-500">({Math.round(currentAudio.fileSize / 1024)} KB)</span>
                            )}
                          </div>
                        ) : (
                          <div className="mt-1 text-[10px] font-mono text-stone-500 italic">
                            Default physical acoustic synthesis (Click upload to pick your file)
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Actions for this slot */}
                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                      <input
                        ref={fileInputRefs[slot.key]}
                        type="file"
                        accept="audio/*,.mp3,.wav,.ogg,.m4a"
                        onChange={e => handleFileUpload(slot.key, e)}
                        className="hidden"
                      />

                      <button
                        type="button"
                        onClick={() => handleTestSlot(slot.key)}
                        className="px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-amber-300 border border-white/10 text-xs font-mono flex items-center gap-1.5 transition-colors cursor-pointer"
                        title="Test Sound"
                      >
                        <Play size={12} className={testingKey === slot.key ? 'animate-spin text-amber-400' : ''} />
                        <span>Play</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => fileInputRefs[slot.key].current?.click()}
                        className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Upload size={12} />
                        <span>{hasCustom ? 'Change File' : 'Upload From Device'}</span>
                      </button>

                      {hasCustom && (
                        <button
                          type="button"
                          onClick={() => handleRemoveSlot(slot.key)}
                          className="p-1.5 rounded-xl bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border border-rose-500/30 transition-colors cursor-pointer"
                          title="Remove custom audio and use default"
                        >
                          <Trash2 size={13} />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Master Volume Slider */}
        <div className="p-3.5 rounded-2xl bg-black/60 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Volume2 size={16} className="text-amber-400 shrink-0" />
            <div>
              <span className="text-xs font-mono font-bold text-stone-200 block">Master Sound Volume</span>
              <span className="text-[10px] text-stone-400">Controls loudness for all reveal sound effects</span>
            </div>
          </div>
          <div className="flex items-center gap-3 w-full sm:w-48">
            <input
              type="range"
              min="0.1"
              max="1.0"
              step="0.05"
              value={config.volume}
              onChange={e => setConfig(prev => ({ ...prev, volume: parseFloat(e.target.value) }))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <span className="text-xs font-mono font-bold text-amber-300 w-9 text-end">
              {Math.round(config.volume * 100)}%
            </span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-white/10">
          <button
            type="button"
            onClick={() => setConfig(DEFAULT_SFX_CONFIG)}
            className="text-xs text-stone-400 hover:text-white transition-colors cursor-pointer"
          >
            Clear All & Reset to Default
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-mono text-stone-400 hover:text-white bg-stone-900 hover:bg-stone-800 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={isSaving}
              onClick={handleSave}
              className="px-5 py-2 rounded-xl text-xs font-serif font-bold uppercase tracking-wider bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-stone-950 hover:brightness-110 shadow-lg shadow-amber-500/25 transition-all cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
            >
              {isSaving ? (
                <>
                  <RefreshCw size={14} className="animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <Check size={14} />
                  <span>Save Sound Effects</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
