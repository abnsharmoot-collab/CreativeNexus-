import React, { useMemo } from 'react';
import { CardRarity, CardFoilStyle, HolographicBehavior, FoilIntensity } from '../../types/cards';
import { resolveEffectiveCardMaterial } from '../../config/cardMaterialConfig';

export interface CardFoilOverlayProps {
  rarity?: CardRarity;
  foilStyle?: CardFoilStyle;
  foilColor?: string;
  foilIntensity?: FoilIntensity;
  foilOpacity?: number; // 0 - 100 percentage
  holographicBehavior?: HolographicBehavior;
  reflectionStrength?: number; // 0 - 100
  reflectionSpeed?: number; // 0.5 - 2.0 speed multiplier
  reflectionWidth?: number; // 10 - 100 percentage
  reflectionAngle?: number; // deg
  surfaceShine?: number; // 0 - 100
  metallicStrength?: number; // 0 - 100
  edgeReflection?: number; // 0 - 100
  iridescence?: number; // 0 - 100
  isHovered?: boolean;
  glareX?: number; // 0 - 100 percentage
  glareY?: number; // 0 - 100 percentage
  cardAccent?: string;
}

export const CardFoilOverlay: React.FC<CardFoilOverlayProps> = ({
  rarity = 'COMMON',
  foilStyle,
  foilColor,
  foilIntensity,
  foilOpacity,
  holographicBehavior,
  reflectionStrength,
  reflectionSpeed = 1.0,
  reflectionWidth = 42,
  reflectionAngle = 35,
  surfaceShine,
  metallicStrength,
  edgeReflection,
  iridescence,
  isHovered = false,
  glareX = 50,
  glareY = 30,
  cardAccent,
}) => {
  // Authoritative resolved material properties from the reusable rarity config system
  const material = useMemo(() => {
    return resolveEffectiveCardMaterial({
      rarity: (rarity as CardRarity) || 'COMMON',
      foilStyle,
      foilColor,
      foilIntensity,
      foilOpacity,
      holographicBehavior,
      reflectionStrength,
      reflectionSpeed,
      reflectionWidth,
      reflectionAngle,
      surfaceShine,
      metallicStrength,
      edgeReflection,
      iridescence,
      accentColor: cardAccent,
    });
  }, [
    rarity,
    foilStyle,
    foilColor,
    foilIntensity,
    foilOpacity,
    holographicBehavior,
    reflectionStrength,
    reflectionSpeed,
    reflectionWidth,
    reflectionAngle,
    surfaceShine,
    metallicStrength,
    edgeReflection,
    iridescence,
    cardAccent,
  ]);

  const isLegendary = material.rarity === 'LEGENDARY';
  const effectiveTint = isLegendary ? (foilColor || cardAccent || material.primaryColor) : material.primaryColor;
  const secondaryTint = material.secondaryColor;
  const activeBehavior = material.activeBehavior;
  const currentPeakOpacity = isHovered ? material.hoverPeakOpacity : material.idlePeakOpacity;
  const cycleDurationSec = material.cycleDurationSec;
  const bandWidth = material.bandWidth;

  // Dynamic angle combining base angle with slight interactive glare response
  const dynamicAngle = Math.round(material.reflectionAngle + (glareX - 50) * 0.8 + (glareY - 50) * 0.5);

  const cssVars = useMemo(() => ({
    '--holo-peak-opacity': currentPeakOpacity.toFixed(3),
    '--holo-base-opacity': (currentPeakOpacity * 0.35).toFixed(3),
    '--holo-angle': `${dynamicAngle}deg`,
    '--holo-cycle': `${cycleDurationSec.toFixed(2)}s`,
  } as React.CSSProperties), [currentPeakOpacity, dynamicAngle, cycleDurationSec]);

  return (
    <div
      className="absolute inset-0 pointer-events-none rounded-[inherit] overflow-hidden z-15 select-none"
      style={cssVars}
      aria-hidden="true"
    >
      {/* ========================================================================= */}
      {/* LAYER 1: BASE MATERIAL METALLIC GRAIN & SPECULAR TEXTURE                  */}
      {/* Physically embedded into the card surface, below animated reflections     */}
      {/* ========================================================================= */}
      <div
        className="absolute inset-0 mix-blend-overlay transition-opacity duration-300 pointer-events-none"
        style={{
          opacity: isHovered
            ? Math.min(0.5, (material.metallicStrength / 100) * 0.45)
            : Math.min(0.35, (material.metallicStrength / 100) * 0.3),
          background: `radial-gradient(circle at ${glareX}% ${glareY}%, ${effectiveTint}40 0%, transparent 65%),
                       linear-gradient(135deg, ${material.metallicGrain} 0%, transparent 50%, ${material.metallicGrain} 100%)`,
        }}
      />

      {/* ========================================================================= */}
      {/* LAYER 2: CONTINUOUS IDLE HOLOGRAPHIC BEHAVIORS (All 10 Behaviors)         */}
      {/* Runs automatically on PC & Mobile without requiring hover or click        */}
      {/* ========================================================================= */}

      {/* BEHAVIOR 1: NONE (Static Rarity Metallic Material only) */}
      {activeBehavior === 'none' && (
        <div
          className="absolute inset-0 mix-blend-color-dodge transition-opacity duration-300 pointer-events-none"
          style={{
            opacity: currentPeakOpacity * 0.35,
            background: `radial-gradient(ellipse 90% 70% at 50% 35%, ${effectiveTint}45 0%, transparent 65%)`,
          }}
        />
      )}

      {/* BEHAVIOR 2: DIAGONAL SWEEP (Soft reflective band continuously travelling diagonally) */}
      {activeBehavior === 'diagonal_sweep' && (
        <div
          className="absolute -inset-[60%] pointer-events-none mix-blend-color-dodge holo-anim-diagonal"
          style={{
            background: `linear-gradient(${dynamicAngle}deg,
              transparent calc(50% - ${bandWidth}%),
              ${effectiveTint}25 calc(50% - ${bandWidth / 2}%),
              rgba(255, 255, 255, 0.92) 50%,
              ${secondaryTint}55 calc(50% + ${bandWidth / 2}%),
              transparent calc(50% + ${bandWidth}%)
            )`,
            animation: `holoDiagonalSweep ${cycleDurationSec}s cubic-bezier(0.4, 0, 0.2, 1) infinite`,
            filter: 'blur(3px)',
          }}
        />
      )}

      {/* BEHAVIOR 3: HORIZONTAL SWEEP (Metallic reflection travels left to right) */}
      {activeBehavior === 'horizontal_sweep' && (
        <div
          className="absolute inset-y-0 -inset-x-[40%] pointer-events-none mix-blend-color-dodge holo-anim-horizontal"
          style={{
            background: `linear-gradient(90deg,
              transparent calc(50% - ${bandWidth}%),
              ${effectiveTint}30 calc(50% - ${bandWidth / 2}%),
              rgba(255, 255, 255, 0.92) 50%,
              ${secondaryTint}55 calc(50% + ${bandWidth / 2}%),
              transparent calc(50% + ${bandWidth}%)
            )`,
            animation: `holoHorizontalSweep ${cycleDurationSec}s cubic-bezier(0.4, 0, 0.2, 1) infinite`,
            filter: 'blur(2px)',
          }}
        />
      )}

      {/* BEHAVIOR 4: VERTICAL SWEEP (Reflection travels top to bottom) */}
      {activeBehavior === 'vertical_sweep' && (
        <div
          className="absolute inset-x-0 -inset-y-[40%] pointer-events-none mix-blend-color-dodge holo-anim-vertical"
          style={{
            background: `linear-gradient(180deg,
              transparent calc(50% - ${bandWidth}%),
              ${effectiveTint}30 calc(50% - ${bandWidth / 2}%),
              rgba(255, 255, 255, 0.92) 50%,
              ${secondaryTint}55 calc(50% + ${bandWidth / 2}%),
              transparent calc(50% + ${bandWidth}%)
            )`,
            animation: `holoVerticalSweep ${cycleDurationSec}s cubic-bezier(0.4, 0, 0.2, 1) infinite`,
            filter: 'blur(2px)',
          }}
        />
      )}

      {/* BEHAVIOR 5: PRISMATIC SHIFT (Controlled spectral chromatic refraction - Not cheap RGB) */}
      {activeBehavior === 'prismatic_shift' && (
        <div
          className="absolute inset-0 pointer-events-none mix-blend-color-dodge holo-anim-prismatic transition-opacity duration-300"
          style={{
            opacity: currentPeakOpacity,
            backgroundImage: `linear-gradient(130deg,
              rgba(6, 182, 212, 0.35) 0%,
              rgba(59, 130, 246, 0.35) 20%,
              rgba(147, 51, 234, 0.40) 40%,
              rgba(217, 70, 239, 0.35) 60%,
              rgba(245, 158, 11, 0.42) 80%,
              rgba(6, 182, 212, 0.35) 100%
            )`,
            backgroundSize: '240% 240%',
            animation: `holoPrismaticShift ${cycleDurationSec * 1.2}s ease-in-out infinite`,
          }}
        />
      )}

      {/* BEHAVIOR 6: IRIDESCENT FLOW (Slow pearlescent oil-on-water movement) */}
      {activeBehavior === 'iridescent_flow' && (
        <div
          className="absolute inset-0 pointer-events-none mix-blend-color-dodge holo-anim-iridescent transition-opacity duration-300"
          style={{
            opacity: currentPeakOpacity * 0.95,
            backgroundImage: `radial-gradient(circle at 30% 25%, ${effectiveTint}55 0%, transparent 45%),
                              radial-gradient(circle at 75% 70%, ${secondaryTint}45 0%, transparent 50%),
                              linear-gradient(135deg, rgba(20, 184, 166, 0.25) 0%, rgba(139, 92, 246, 0.32) 50%, rgba(244, 63, 94, 0.25) 100%)`,
            backgroundSize: '200% 200%',
            animation: `holoIridescentFlow ${cycleDurationSec * 1.3}s ease-in-out infinite`,
            filter: 'blur(1px)',
          }}
        />
      )}

      {/* BEHAVIOR 7: RADIAL GLEAM (Concentrated gemstone luster on the surface) */}
      {activeBehavior === 'radial_gleam' && (
        <div
          className="absolute -inset-[35%] pointer-events-none mix-blend-screen holo-anim-radial"
          style={{
            background: `radial-gradient(circle 190px at 50% 50%,
              rgba(255, 255, 255, 0.95) 0%,
              ${secondaryTint}77 25%,
              ${effectiveTint}40 50%,
              transparent 70%
            )`,
            animation: `holoRadialGleam ${cycleDurationSec * 1.1}s ease-in-out infinite`,
            filter: 'blur(2px)',
          }}
        />
      )}

      {/* BEHAVIOR 8: EDGE SHIMMER (Continuous highlight traveling around the perimeter) */}
      {activeBehavior === 'edge_shimmer' && (
        <div
          className="absolute inset-0 pointer-events-none holo-anim-edge rounded-[inherit] overflow-hidden"
          style={{
            padding: '2.5px',
            background: `linear-gradient(90deg,
              transparent 0%,
              ${effectiveTint}60 20%,
              rgba(255, 255, 255, 0.95) 50%,
              ${secondaryTint}60 80%,
              transparent 100%
            )`,
            backgroundSize: '300% 100%',
            animation: `holoEdgeShimmer ${cycleDurationSec}s linear infinite`,
            WebkitMask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
            WebkitMaskComposite: 'xor',
            maskComposite: 'exclude',
          }}
        />
      )}

      {/* BEHAVIOR 9: HOLOGRAPHIC WAVE (Multiple soft layered interference waves) */}
      {activeBehavior === 'holographic_wave' && (
        <>
          <div
            className="absolute -inset-[50%] pointer-events-none mix-blend-color-dodge holo-anim-wave-1"
            style={{
              background: `repeating-linear-gradient(${dynamicAngle}deg,
                transparent 0px,
                ${effectiveTint}30 40px,
                rgba(255, 255, 255, 0.7) 60px,
                ${secondaryTint}35 80px,
                transparent 120px
              )`,
              animation: `holoWaveOne ${cycleDurationSec * 1.1}s ease-in-out infinite`,
              filter: 'blur(2px)',
            }}
          />
          <div
            className="absolute -inset-[50%] pointer-events-none mix-blend-screen holo-anim-wave-2"
            style={{
              background: `repeating-linear-gradient(${dynamicAngle - 45}deg,
                transparent 0px,
                rgba(255, 255, 255, 0.5) 50px,
                transparent 100px
              )`,
              animation: `holoWaveTwo ${cycleDurationSec * 1.4}s ease-in-out infinite`,
              filter: 'blur(3px)',
            }}
          />
        </>
      )}

      {/* BEHAVIOR 10: FULL FOIL (Metallic reflection, holo, iridescence & edge shimmer combined) */}
      {activeBehavior === 'full_foil' && (
        <>
          {/* Base iridescent shifting surface */}
          <div
            className="absolute inset-0 pointer-events-none mix-blend-color-dodge holo-anim-full"
            style={{
              backgroundImage: `linear-gradient(135deg,
                rgba(245, 158, 11, 0.35) 0%,
                rgba(16, 185, 129, 0.25) 25%,
                rgba(6, 182, 212, 0.35) 50%,
                rgba(168, 85, 247, 0.35) 75%,
                rgba(245, 158, 11, 0.35) 100%
              )`,
              backgroundSize: '260% 260%',
              animation: `holoFullFoilPulse ${cycleDurationSec}s ease-in-out infinite`,
            }}
          />
          {/* Continuous diagonal traveling light band */}
          <div
            className="absolute -inset-[50%] pointer-events-none mix-blend-screen"
            style={{
              background: `linear-gradient(${dynamicAngle}deg,
                transparent 40%,
                rgba(255, 255, 255, 0.88) 50%,
                transparent 60%
              )`,
              animation: `holoDiagonalSweep ${cycleDurationSec * 0.9}s cubic-bezier(0.4, 0, 0.2, 1) infinite`,
              filter: 'blur(3px)',
            }}
          />
          {/* Perimeter edge highlight */}
          <div
            className="absolute inset-0 pointer-events-none rounded-[inherit] overflow-hidden"
            style={{
              padding: '2px',
              background: `linear-gradient(90deg, transparent 0%, rgba(255, 255, 255, 0.85) 50%, transparent 100%)`,
              backgroundSize: '300% 100%',
              animation: `holoEdgeShimmer ${cycleDurationSec * 1.2}s linear infinite`,
              WebkitMask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
              WebkitMaskComposite: 'xor',
              maskComposite: 'exclude',
            }}
          />
        </>
      )}

      {/* ========================================================================= */}
      {/* LAYER 3: DEDICATED FOIL STYLE FINISHES (Enhanced Existing Foil Styles)    */}
      {/* ========================================================================= */}
      {material.effectiveFoilStyle === 'holographic' && (
        <div
          className="absolute inset-0 mix-blend-color-dodge pointer-events-none"
          style={{
            opacity: currentPeakOpacity * 0.85,
            background: `linear-gradient(${dynamicAngle}deg, 
              rgba(255, 0, 128, 0.20) 0%, 
              rgba(121, 40, 202, 0.20) 25%, 
              rgba(0, 112, 243, 0.20) 50%, 
              rgba(0, 223, 216, 0.20) 75%, 
              rgba(250, 204, 21, 0.20) 100%
            )`,
            backgroundSize: '200% 200%',
            backgroundPosition: `${glareX}% ${glareY}%`,
          }}
        />
      )}

      {material.effectiveFoilStyle === 'cosmic' && (
        <div
          className="absolute inset-0 mix-blend-screen pointer-events-none"
          style={{
            opacity: currentPeakOpacity * 0.8,
            backgroundImage: `radial-gradient(circle 1.2px at 20% 30%, #fff 100%, transparent 0),
                              radial-gradient(circle 1.5px at 75% 20%, #fff 100%, transparent 0),
                              radial-gradient(circle 1.8px at 85% 65%, #fff 100%, transparent 0),
                              radial-gradient(circle 1.2px at 40% 70%, #fff 100%, transparent 0)`,
            backgroundSize: '140px 140px',
          }}
        />
      )}

      {material.effectiveFoilStyle === 'gold_embossed' && (
        <div
          className="absolute inset-0 mix-blend-color-dodge pointer-events-none"
          style={{
            opacity: currentPeakOpacity * 0.9,
            background: `linear-gradient(${dynamicAngle}deg, 
              rgba(180, 83, 9, 0.3) 0%, 
              rgba(245, 158, 11, 0.45) 40%, 
              rgba(254, 240, 138, 0.6) 50%, 
              rgba(245, 158, 11, 0.45) 60%, 
              rgba(120, 53, 15, 0.3) 100%
            )`,
            backgroundSize: '160% 160%',
            backgroundPosition: `${glareX}% ${glareY}%`,
          }}
        />
      )}

      {material.effectiveFoilStyle === 'prismatic_crystal' && (
        <div
          className="absolute inset-0 mix-blend-overlay pointer-events-none"
          style={{
            opacity: currentPeakOpacity * 0.7,
            backgroundImage: `repeating-linear-gradient(45deg, rgba(255,255,255,0.12) 0px, transparent 2px, transparent 10px)`,
          }}
        />
      )}

      {material.effectiveFoilStyle === 'cyber_matrix' && (
        <div
          className="absolute inset-0 mix-blend-overlay pointer-events-none"
          style={{
            opacity: currentPeakOpacity * 0.7,
            backgroundImage: 'repeating-linear-gradient(0deg, rgba(34,211,238,0.14) 0px, transparent 1px, transparent 4px)',
          }}
        />
      )}

      {material.effectiveFoilStyle === 'astral_supernova' && (
        <div
          className="absolute inset-0 mix-blend-screen pointer-events-none"
          style={{
            opacity: currentPeakOpacity * 0.75,
            background: `linear-gradient(${dynamicAngle}deg, transparent 35%, rgba(255,255,255,0.4) 50%, transparent 65%)`,
          }}
        />
      )}

      {material.effectiveFoilStyle === 'aurora_emerald' && (
        <div
          className="absolute inset-0 mix-blend-color-dodge pointer-events-none"
          style={{
            opacity: currentPeakOpacity * 0.8,
            background: `radial-gradient(circle 280px at ${glareX}% ${glareY}%, #10b981 0%, #06b6d4 45%, transparent 75%)`,
          }}
        />
      )}

      {material.effectiveFoilStyle === 'crimson_inferno' && (
        <div
          className="absolute inset-0 mix-blend-color-dodge pointer-events-none"
          style={{
            opacity: currentPeakOpacity * 0.8,
            background: `radial-gradient(circle 280px at ${glareX}% ${glareY}%, #f43f5e 0%, #ea580c 45%, transparent 75%)`,
          }}
        />
      )}

      {material.effectiveFoilStyle === 'obsidian_mirror' && (
        <div
          className="absolute inset-0 mix-blend-soft-light pointer-events-none"
          style={{
            opacity: currentPeakOpacity * 0.7,
            background: `radial-gradient(circle 280px at ${glareX}% ${glareY}%, rgba(255,255,255,0.3) 0%, rgba(148,163,184,0.15) 40%, transparent 75%)`,
          }}
        />
      )}

      {/* Halloween 2026 Witchfire Specter Foil Overlay */}
      {(material.effectiveFoilStyle === 'halloween_specter' || material.rarity === 'HALLOWEEN_2026') && (
        <>
          {/* Spectral dual-vortex color-dodge glow */}
          <div
            className="absolute inset-0 mix-blend-color-dodge pointer-events-none animate-pulse"
            style={{
              opacity: currentPeakOpacity * 0.88,
              background: `radial-gradient(circle 320px at ${glareX}% ${glareY}%, rgba(255, 94, 0, 0.7) 0%, rgba(176, 38, 255, 0.55) 45%, rgba(18, 2, 28, 0.3) 75%, transparent 100%)`,
            }}
          />

          {/* Cursed Halloween spiderweb / fractured geometric matrix */}
          <div
            className="absolute inset-0 mix-blend-overlay pointer-events-none"
            style={{
              opacity: currentPeakOpacity * 0.65,
              backgroundImage: 'repeating-linear-gradient(60deg, rgba(255,94,0,0.18) 0px, transparent 2px, transparent 12px), repeating-linear-gradient(-60deg, rgba(176,38,255,0.18) 0px, transparent 2px, transparent 12px)',
            }}
          />

          {/* Floating Spooky Embers */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <span
              className="absolute w-1.5 h-1.5 rounded-full bg-orange-400 shadow-[0_0_8px_#ff5e00] animate-ping"
              style={{ top: '20%', left: '25%', animationDuration: '2.8s' }}
            />
            <span
              className="absolute w-2 h-2 rounded-full bg-purple-400 shadow-[0_0_10px_#b026ff] animate-ping"
              style={{ top: '65%', right: '20%', animationDuration: '3.4s' }}
            />
            <span
              className="absolute w-1 h-1 rounded-full bg-amber-300 shadow-[0_0_6px_#f59e0b] animate-ping"
              style={{ top: '40%', right: '35%', animationDuration: '2.2s' }}
            />
            <span
              className="absolute w-1.5 h-1.5 rounded-full bg-orange-500 shadow-[0_0_9px_#ff3300] animate-ping"
              style={{ bottom: '25%', left: '30%', animationDuration: '3.1s' }}
            />
          </div>
        </>
      )}

      {/* ========================================================================= */}
      {/* LAYER 4: INTERACTIVE SPECULAR GLARE (Desktop Hover Enhancement)           */}
      {/* Follows cursor when hovered without disrupting continuous idle animation   */}
      {/* ========================================================================= */}
      {isHovered && (
        <div
          className="absolute inset-0 mix-blend-screen transition-opacity duration-200 pointer-events-none"
          style={{
            opacity: 0.18,
            background: `radial-gradient(circle 260px at ${glareX}% ${glareY}%, rgba(255,255,255,0.85) 0%, ${effectiveTint}40 40%, transparent 70%)`,
          }}
        />
      )}

      {/* ========================================================================= */}
      {/* LAYER 5: PERIMETER EDGE BEVEL REFLECTION (Clipped within card bounds)     */}
      {/* ========================================================================= */}
      <div
        className="absolute inset-[1px] rounded-[inherit] pointer-events-none border transition-opacity duration-300"
        style={{
          borderColor: material.borderSheen,
          opacity: isHovered ? 0.9 : 0.55,
        }}
      />
    </div>
  );
};
