import React, { useRef, useState, useEffect, useMemo } from 'react';
import { motion } from 'motion/react';
import { CollectibleCardData, CardRarity, getUnifiedCardStats, calculateCardOverallRating, CardStatItem } from '../../types/cards';
import { useScroll3DTilt } from '../../hooks/useScroll3DTilt';
import { Star, Lock, Zap, Swords, Shield, Heart, Sparkles, Flame, Crown } from 'lucide-react';
import { CardBorderElements } from './CardBorderElements';
import { CardFoilOverlay } from './CardFoilOverlay';
import { useCards } from '../../context/CardContext';
import { resolveEffectiveCardMaterial, RARITY_MATERIAL_SYSTEM } from '../../config/cardMaterialConfig';

interface CollectibleCardProps {
  card: CollectibleCardData;
  isOwned?: boolean;
  duplicateCount?: number;
  isShowcased?: boolean;
  onToggleShowcase?: (cardId: string) => void;
  onClickDetail?: (card: CollectibleCardData) => void;
  size?: 'normal' | 'large' | 'compact';
  containedLighting?: boolean;
  progressiveReveal?: boolean;
  disableScrollTilt?: boolean;
  className?: string;
}

export const RARITY_THEMES: Record<CardRarity, {
  label: string;
  badge: string;
  glow: string;
  accent: string;
  borderClass: string;
  innerBorder: string;
  faceGradient: string;
  textGradient: string;
  seriesTag: string;
  romanNumeral: string;
  cornerAccent: string;
  sealGradient: string;
}> = {
  COMMON: {
    label: 'COMMON',
    badge: 'bg-black/65 text-zinc-300 border-zinc-500/40 shadow-xs',
    glow: RARITY_MATERIAL_SYSTEM.COMMON.ambientGlow,
    accent: RARITY_MATERIAL_SYSTEM.COMMON.primaryColor,
    borderClass: 'border-0',
    innerBorder: 'border-0',
    faceGradient: RARITY_MATERIAL_SYSTEM.COMMON.faceGradient,
    textGradient: RARITY_MATERIAL_SYSTEM.COMMON.textGradient,
    seriesTag: 'STANDARD // 01',
    romanNumeral: 'I',
    cornerAccent: 'rgba(156, 163, 175, 0.4)',
    sealGradient: 'from-zinc-500/20 to-transparent',
  },
  UNCOMMON: {
    label: 'UNCOMMON',
    badge: 'bg-black/65 text-emerald-300 border-emerald-500/40 shadow-xs',
    glow: RARITY_MATERIAL_SYSTEM.UNCOMMON.ambientGlow,
    accent: RARITY_MATERIAL_SYSTEM.UNCOMMON.primaryColor,
    borderClass: 'border-0',
    innerBorder: 'border-0',
    faceGradient: RARITY_MATERIAL_SYSTEM.UNCOMMON.faceGradient,
    textGradient: RARITY_MATERIAL_SYSTEM.UNCOMMON.textGradient,
    seriesTag: 'VANGUARD // 02',
    romanNumeral: 'II',
    cornerAccent: 'rgba(16, 185, 129, 0.4)',
    sealGradient: 'from-emerald-500/20 to-transparent',
  },
  RARE: {
    label: 'RARE',
    badge: 'bg-black/65 text-cyan-300 border-cyan-500/40 shadow-xs',
    glow: RARITY_MATERIAL_SYSTEM.RARE.ambientGlow,
    accent: RARITY_MATERIAL_SYSTEM.RARE.primaryColor,
    borderClass: 'border-0',
    innerBorder: 'border-0',
    faceGradient: RARITY_MATERIAL_SYSTEM.RARE.faceGradient,
    textGradient: RARITY_MATERIAL_SYSTEM.RARE.textGradient,
    seriesTag: 'CHRONO // 03',
    romanNumeral: 'III',
    cornerAccent: 'rgba(6, 182, 212, 0.45)',
    sealGradient: 'from-cyan-500/20 to-transparent',
  },
  EPIC: {
    label: 'EPIC',
    badge: 'bg-black/65 text-purple-300 border-purple-500/40 shadow-xs',
    glow: RARITY_MATERIAL_SYSTEM.EPIC.ambientGlow,
    accent: RARITY_MATERIAL_SYSTEM.EPIC.primaryColor,
    borderClass: 'border-0',
    innerBorder: 'border-0',
    faceGradient: RARITY_MATERIAL_SYSTEM.EPIC.faceGradient,
    textGradient: RARITY_MATERIAL_SYSTEM.EPIC.textGradient,
    seriesTag: 'HYPERION // 04',
    romanNumeral: 'IV',
    cornerAccent: 'rgba(168, 85, 247, 0.5)',
    sealGradient: 'from-purple-500/25 to-transparent',
  },
  LEGENDARY: {
    label: 'LEGENDARY',
    badge: 'bg-amber-950/85 text-amber-200 border-amber-400/80 shadow-[0_0_14px_rgba(245,158,11,0.5)]',
    glow: RARITY_MATERIAL_SYSTEM.LEGENDARY.ambientGlow,
    accent: RARITY_MATERIAL_SYSTEM.LEGENDARY.primaryColor,
    borderClass: 'border-0',
    innerBorder: 'border-0',
    faceGradient: RARITY_MATERIAL_SYSTEM.LEGENDARY.faceGradient,
    textGradient: RARITY_MATERIAL_SYSTEM.LEGENDARY.textGradient,
    seriesTag: 'SOVEREIGN // 05',
    romanNumeral: 'V',
    cornerAccent: 'rgba(251, 191, 36, 0.7)',
    sealGradient: 'from-amber-400/30 to-transparent',
  },
  HALLOWEEN_2026: {
    label: 'HALLOWEEN',
    badge: 'bg-orange-950/90 text-orange-200 border-orange-500/90 shadow-[0_0_18px_rgba(255,94,0,0.7),0_0_8px_rgba(176,38,255,0.6)]',
    glow: 'rgba(255, 94, 0, 0.85)',
    accent: '#ff5e00',
    borderClass: 'border-0',
    innerBorder: 'border-0',
    faceGradient: 'from-[#380e00]/98 via-[#1f0525]/96 to-[#09000e]/99',
    textGradient: 'from-orange-100 via-amber-200 to-purple-400',
    seriesTag: 'HALLOWEEN // LIMITED',
    romanNumeral: 'VI',
    cornerAccent: 'rgba(255, 94, 0, 0.85)',
    sealGradient: 'from-orange-500/40 via-purple-600/30 to-transparent',
  },
};

const BACKGROUND_THEMES: Record<string, string> = {
  dark_slate: 'from-[#0a1518]/96 via-[#040c0f]/94 to-[#020608]/98',
  deep_obsidian: 'from-[#050508]/98 via-[#020204]/96 to-[#000000]/99',
  void_nebula: 'from-[#170524]/98 via-[#0b0314]/96 to-[#030106]/99',
  ancient_gold: 'from-[#261603]/98 via-[#120a01]/96 to-[#080400]/99',
  emerald_marble: 'from-[#03201a]/98 via-[#02130f]/96 to-[#010a08]/99',
};

export const CollectibleCard: React.FC<CollectibleCardProps> = ({
  card,
  isOwned = true,
  duplicateCount = 1,
  isShowcased = false,
  onToggleShowcase,
  onClickDetail,
  size = 'normal',
  containedLighting = false,
  progressiveReveal = false,
  disableScrollTilt = false,
  className = ''
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [hoverRotateX, setHoverRotateX] = useState(0);
  const [hoverRotateY, setHoverRotateY] = useState(0);
  const [hoverGlarePos, setHoverGlarePos] = useState({ x: 50, y: 30 });
  const [isHovered, setIsHovered] = useState(false);
  const [, setImgError] = useState(false);
  const prefersReducedMotion = useRef(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
      prefersReducedMotion.current = mq.matches;
      const onChange = (e: MediaQueryListEvent) => {
        prefersReducedMotion.current = e.matches;
      };
      mq.addEventListener('change', onChange);
      return () => mq.removeEventListener('change', onChange);
    }
  }, []);

  const material = useMemo(() => resolveEffectiveCardMaterial(card), [card]);
  const isTopTier = card.rarity === 'LEGENDARY' || card.rarity === 'HALLOWEEN_2026';
  const isLegendary = card.rarity === 'LEGENDARY';
  const isHalloween = card.rarity === 'HALLOWEEN_2026';
  const theme = RARITY_THEMES[card.rarity] || RARITY_THEMES.COMMON;
  const cardAccent = isTopTier
    ? (card.borderColor || (card.isCustom ? card.accentColor : undefined) || material.primaryColor)
    : material.primaryColor;
  const cardGlow = isTopTier ? (card.glowColor || cardAccent) : material.primaryColor;
  const cardNameColor = isTopTier
    ? (card.nameColor || card.borderColor || (card.isCustom ? card.accentColor : undefined) || material.primaryColor)
    : material.primaryColor;
  const effectiveGradient = (card.backgroundTheme && BACKGROUND_THEMES[card.backgroundTheme]) || material.faceGradient;

  // Unified Stats Extraction & Dynamic Overall (OVR) Calculation (0 - 100 SCALE)
  const unifiedStats: CardStatItem[] = getUnifiedCardStats(card);
  const displayOvr = Math.min(100, Math.max(10, card.overallRating || calculateCardOverallRating(unifiedStats, card.rarity)));
  const primaryStats = unifiedStats.slice(0, 3);

  // Fallback to global rating settings from CardContext if not overridden on card
  let globalRating = { fontSize: 24, offsetX: 16, offsetY: 14 };
  let cardCtx: any = null;
  try {
    cardCtx = useCards();
    if (cardCtx?.globalRatingSettings) {
      globalRating = cardCtx.globalRatingSettings;
    }
  } catch {}

  const effectiveFontSize = typeof card.ratingFontSize === 'number'
    ? card.ratingFontSize
    : (globalRating.fontSize || 24);
  const effectiveOffsetX = typeof card.ratingOffsetX === 'number'
    ? card.ratingOffsetX
    : (globalRating.offsetX ?? 16);
  const effectiveOffsetY = typeof card.ratingOffsetY === 'number'
    ? card.ratingOffsetY
    : (globalRating.offsetY ?? 14);

  const scrollTilt = useScroll3DTilt({
    cardRef,
    isHovered,
    hoverRotateX,
    hoverRotateY,
    maxTiltX: 2.8,
    maxTiltY: 1.8,
    accentColorHex: cardAccent,
    glowIntensity: isLegendary ? 0.8 : 0.45,
    enabled: true,
  });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (prefersReducedMotion.current || !cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotX = ((y - centerY) / centerY) * -2.8;
    const rotY = ((x - centerX) / centerX) * 2.8;
    setHoverRotateX(rotX);
    setHoverRotateY(rotY);

    const glareX = Math.round((x / rect.width) * 100);
    const glareY = Math.round((y / rect.height) * 100);
    setHoverGlarePos({ x: glareX, y: glareY });
  };

  const handleMouseEnter = () => {
    if (prefersReducedMotion.current) return;
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setHoverRotateX(0);
    setHoverRotateY(0);
    setHoverGlarePos({ x: 50, y: 30 });
  };

  // Dimensions & Height Presets matching Owner Cards
  const minHeightClass = size === 'compact'
    ? 'min-h-[420px] sm:min-h-[455px]'
    : size === 'large'
    ? 'min-h-[580px] sm:min-h-[640px]'
    : 'min-h-[460px] sm:min-h-[510px]';

  // Dynamic box shadow based on reusable rarity material system and optional owner glow override
  const glowInt = card.glowIntensity;
  const isNoGlow = glowInt === 'none';
  const dynamicBoxShadow = isNoGlow
    ? (isHovered
        ? '0 25px 60px -10px rgba(0,0,0,0.95)'
        : '0 16px 40px -12px rgba(0,0,0,0.9)')
    : (glowInt && glowInt !== 'radiant'
        ? (containedLighting
            ? (isHovered ? '0 25px 60px -10px rgba(0,0,0,0.95)' : '0 16px 40px -12px rgba(0,0,0,0.9)')
            : (isHovered
                ? `0 30px 70px rgba(0,0,0,0.94), 0 0 ${glowInt === 'celestial' ? '65px' : glowInt === 'blazing' ? '48px' : '18px'} ${cardGlow}${glowInt === 'celestial' ? '88' : '55'}`
                : `0 20px 50px rgba(0,0,0,0.88), 0 0 ${glowInt === 'celestial' ? '45px' : glowInt === 'blazing' ? '36px' : '12px'} ${cardGlow}${glowInt === 'celestial' ? '66' : '44'}`))
        : material.dynamicBoxShadow(isHovered, containedLighting));

  // Unobtained Locked State (Seamless single chassis, zero separate borders)
  if (!isOwned) {
    return (
      <div
        className={`relative group w-full ${minHeightClass} flex flex-col justify-between rounded-[2rem] sm:rounded-[2.2rem] overflow-hidden bg-gradient-to-b from-[#0a1215]/95 via-[#030809]/95 to-[#010304]/98 shadow-xl select-none opacity-60 hover:opacity-85 transition-all duration-300 p-4 sm:p-5 text-center border-0`}
      >
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_35%,rgba(148,163,184,0.06),transparent_70%)] pointer-events-none" />

        {/* Top Bar */}
        <div className="w-full flex items-center justify-between z-10">
          <span className="text-[10px] font-mono tracking-widest text-slate-400 font-bold uppercase px-2 py-0.5 rounded-lg bg-black/50 border border-white/5 backdrop-blur-md">
            #{String(card.cardNumber).padStart(3, '0')}
          </span>
          {card.cardType && (
            <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400">
              {card.cardType}
            </span>
          )}
        </div>

        {/* Locked Icon & Title */}
        <div className="my-auto flex flex-col items-center gap-2.5 z-10 py-6">
          <div className="w-13 h-13 rounded-2xl bg-black/70 border border-white/10 flex items-center justify-center text-slate-400 shadow-inner">
            <Lock size={20} />
          </div>
          <h4 className="text-sm sm:text-base font-bold text-slate-200 font-display tracking-wide line-clamp-1">
            {card.name}
          </h4>
          <span className="text-[10px] font-mono text-slate-400 tracking-wider">
            UNDISCOVERED RELIC
          </span>
        </div>

        {/* Bottom Series Tag */}
        <div className="w-full pt-3 border-t border-white/5 flex items-center justify-between text-[10px] font-mono text-slate-400 uppercase tracking-widest z-10">
          <span>{theme.seriesTag}</span>
          <span>{theme.romanNumeral}</span>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={() => onClickDetail && onClickDetail(card)}
      className={`relative group w-full ${minHeightClass} flex flex-col justify-between rounded-[2rem] sm:rounded-[2.2rem] overflow-hidden select-none cursor-pointer transform-gpu transition-all duration-300 ${effectiveGradient} border-0 active:scale-[0.98] shadow-2xl backdrop-blur-md ${className}`}
      style={{
        transform: isHovered
          ? (prefersReducedMotion.current ? 'none' : `perspective(1200px) rotateX(${hoverRotateX}deg) rotateY(${hoverRotateY}deg) translateY(-4px) scale3d(1.015, 1.015, 1.015)`)
          : (disableScrollTilt ? 'perspective(1200px) rotateX(0deg) rotateY(0deg)' : scrollTilt.transform),
        transformStyle: 'preserve-3d',
        boxShadow: dynamicBoxShadow,
        filter: isHovered ? 'brightness(1.04) contrast(1.02)' : (disableScrollTilt ? 'none' : scrollTilt.filterStyle),
        transition: isHovered ? 'box-shadow 0.2s ease, filter 0.2s ease' : 'box-shadow 0.35s ease, filter 0.35s ease',
        willChange: 'transform, filter, box-shadow',
      }}
    >
      {/* -1. Flowing Ambient Halo Glow (Deep volumetric aura breathing behind the chassis) */}
      <div 
        className="absolute -inset-1.5 rounded-[2.2rem] sm:rounded-[2.4rem] opacity-35 group-hover:opacity-75 blur-xl pointer-events-none transition-all duration-500 animate-card-river z-0"
        style={{
          background: `radial-gradient(circle at 50% 50%, ${cardGlow}88 0%, ${cardAccent}44 40%, transparent 70%)`
        }}
        aria-hidden="true"
      />

      {/* 0. Modern Flowing Ambient Light Canvas (Living Silk/Liquid Flow) */}
      <div 
        className="absolute inset-0 pointer-events-none rounded-[inherit] overflow-hidden z-10 opacity-35 mix-blend-screen"
        aria-hidden="true"
      >
        <div 
          className="absolute -inset-1/2 animate-card-liquid pointer-events-none"
          style={{
            background: `radial-gradient(circle at 35% 25%, ${cardAccent}35 0%, transparent 60%),
                         radial-gradient(circle at 65% 75%, ${cardGlow}25 0%, transparent 65%)`
          }}
        />
      </div>

      {/* 0.5 Running Perimeter Light Rim (Fiber-optic liquid flow contour) */}
      <div className="absolute inset-0 rounded-[inherit] pointer-events-none z-30 overflow-hidden" aria-hidden="true">
        <div 
          className="absolute inset-0 rounded-[inherit] border border-transparent animate-card-perimeter opacity-50 group-hover:opacity-90 transition-opacity duration-300"
          style={{
            background: `linear-gradient(135deg, transparent 20%, ${cardAccent} 50%, rgba(255,255,255,0.85) 55%, ${cardAccent} 60%, transparent 80%) border-box`,
            WebkitMask: 'linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0)',
            WebkitMaskComposite: 'destination-out',
            maskComposite: 'exclude',
            borderWidth: '1.5px',
          }}
        />
      </div>

      {/* 1. Dynamic Flowing Liquid Light Sweep Layer (Silky, organic fluid motion) */}
      <div
        className="absolute inset-0 pointer-events-none rounded-[inherit] transition-opacity duration-300 z-25 overflow-hidden"
        style={{
          opacity: isHovered ? 0.28 : (disableScrollTilt ? 0.08 : 0.14),
        }}
        aria-hidden="true"
      >
        {/* Continuous Soft Ambient Flow Wave */}
        <div 
          className="absolute -inset-full animate-card-sweep pointer-events-none"
          style={{
            background: `linear-gradient(115deg, transparent 25%, rgba(255,255,255,0.18) 50%, ${cardAccent}33 60%, transparent 75%)`,
          }}
        />
        {/* Interactive Mouse Tilt Sheen */}
        <div
          className="absolute -inset-full bg-gradient-to-tr from-transparent via-white/12 to-transparent pointer-events-none"
          style={{
            transform: `translateY(${(50 - (isHovered ? hoverGlarePos.y : (disableScrollTilt ? 30 : scrollTilt.glarePos.y))) * 1.5}%) rotate(-25deg)`,
            transition: 'transform 0.15s ease-out',
          }}
        />
      </div>

      {/* 2. Interactive Specular Glare Surface (Soft fluid sheen) */}
      <div
        className="absolute inset-0 pointer-events-none rounded-[inherit] transition-opacity duration-300 z-20"
        style={{
          opacity: isHovered && !prefersReducedMotion.current ? 0.12 : (disableScrollTilt ? 0 : scrollTilt.glareOpacity * 0.6),
          background: `radial-gradient(circle 380px at ${isHovered ? hoverGlarePos.x : (disableScrollTilt ? 50 : scrollTilt.glarePos.x)}% ${isHovered ? hoverGlarePos.y : (disableScrollTilt ? 30 : scrollTilt.glarePos.y)}%, rgba(255,255,255,0.7), transparent 70%)`,
        }}
        aria-hidden="true"
      />

      {/* 3. Upgraded Continuous Holographic & Foil Visual Finish */}
      <CardFoilOverlay
        rarity={card.rarity}
        foilStyle={card.foilStyle}
        foilColor={card.foilColor}
        holographicBehavior={card.holographicBehavior}
        foilIntensity={card.foilIntensity}
        foilOpacity={card.foilOpacity}
        reflectionStrength={card.reflectionStrength}
        reflectionSpeed={card.reflectionSpeed}
        reflectionWidth={card.reflectionWidth}
        reflectionAngle={card.reflectionAngle}
        surfaceShine={card.surfaceShine}
        metallicStrength={card.metallicStrength}
        edgeReflection={card.edgeReflection}
        iridescence={card.iridescence}
        isHovered={isHovered}
        glareX={isHovered ? hoverGlarePos.x : (disableScrollTilt ? 50 : scrollTilt.glarePos.x)}
        glareY={isHovered ? hoverGlarePos.y : (disableScrollTilt ? 30 : scrollTilt.glarePos.y)}
        cardAccent={cardAccent}
      />

      {/* 3.5 DYNAMIC RARITY BORDER ELEMENTS (Clean, no corner ornaments/gems) */}
      <CardBorderElements
        rarity={card.rarity}
        accentColor={cardAccent}
        borderColor={card.borderColor}
        glowColor={card.glowColor}
        frameStyle={card.frameStyle}
        isHovered={isHovered}
      />

      {/* 4. FULL-HEIGHT CONTINUOUS ARTWORK CANVAS LAYER (Full Bleed Edge to Edge, No Borders) */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none rounded-[inherit]">
        <img
          src={card.imageUrl}
          alt={card.name}
          onError={() => setImgError(true)}
          className="w-full h-full object-cover object-center filter brightness-100 contrast-105 group-hover:scale-105 transition-transform duration-700 ease-out select-none"
          style={{
            objectFit: 'cover',
            objectPosition: 'center',
          }}
          loading="lazy"
        />

        {/* Refined Atmospheric Vignette with flowing seamless transition */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/95 via-slate-950/30 to-transparent pointer-events-none" />
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(circle at 50% 35%, transparent 50%, rgba(2, 6, 7, 0.5) 100%)'
          }}
        />

        {/* Progressive Unmasking Curtain (Hidden -> Fully Revealed downward) */}
        {progressiveReveal && (
          <motion.div
            initial={{ y: '0%' }}
            animate={{ y: '100%' }}
            transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1], delay: 0.15 }}
            className="absolute inset-0 bg-gradient-to-b from-[#091014] via-[#05090b] to-[#020405] pointer-events-none z-10"
          >
            {/* Leading edge laser unmask beam */}
            <div
              className="absolute bottom-0 inset-x-0 h-[2.5px]"
              style={{
                background: `linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.95) 40%, ${cardAccent} 65%, transparent 100%)`,
                boxShadow: `0 0 14px rgba(255,255,255,0.9), 0 0 22px ${cardAccent}`
              }}
            />
          </motion.div>
        )}
      </div>

      {/* Upper-Right Sovereign Rating Number (Pure number matching Card Profile exactly, no crown, no boxed border) */}
      <div
        className="absolute z-35 select-none font-display font-black leading-none tracking-tight flex items-center justify-center pointer-events-none"
        style={{
          top: `${effectiveOffsetY}px`,
          right: `${effectiveOffsetX}px`,
          fontSize: `${Math.max(16, effectiveFontSize)}px`,
          color: card.nameColor || cardAccent || '#f59e0b',
          textShadow: `0 0 16px ${cardAccent}99, 0 2px 6px rgba(0,0,0,0.95)`,
          transform: isHovered && !prefersReducedMotion.current ? 'translateZ(26px)' : 'translateZ(18px)',
          transition: 'transform 0.35s ease-out, top 0.2s ease, right 0.2s ease',
        }}
      >
        <span className="tabular-nums drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]">
          {displayOvr}
        </span>
      </div>

      {/* 5. TOP FLOATING ZONE (Z-20, translateZ for depth) - Clean, No Rarity Badge or Icon */}
      <div
        className="relative z-20 p-4 sm:p-5 pb-2 flex items-center justify-between gap-2 pointer-events-none"
        style={{
          transform: isHovered && !prefersReducedMotion.current ? 'translateZ(16px)' : 'translateZ(8px)',
          transition: 'transform 0.35s ease-out',
        }}
      >
        {/* Top Left: Clean Card Identifier */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono tracking-widest text-slate-300 font-bold px-2 py-0.5 rounded-lg bg-black/60 border border-white/10 backdrop-blur-md">
            #{String(card.cardNumber).padStart(3, '0')}
          </span>
          {card.cardType && (
            <span className="text-[9px] font-mono tracking-wider text-slate-400 uppercase hidden sm:inline px-1.5 py-0.5 rounded-md bg-black/40 border border-white/5">
              {card.cardType}
            </span>
          )}
        </div>

        {/* Top Right: Multiplier & Showcase Pin */}
        <div className="flex items-center gap-1.5 me-9 sm:me-11 pointer-events-auto">
          {duplicateCount > 1 && (
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-black/65 text-amber-300 border border-amber-500/30 backdrop-blur-md shadow-xs">
              x{duplicateCount}
            </span>
          )}

          {/* Showcase Pin Action */}
          {onToggleShowcase && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleShowcase(card.id);
              }}
              title={isShowcased ? 'Pinned in Showcase' : 'Pin to Showcase'}
              className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full border flex items-center justify-center transition-all cursor-pointer backdrop-blur-md ${
                isShowcased
                  ? 'bg-amber-950/85 border-amber-400 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.5)]'
                  : 'bg-black/55 border-white/15 text-slate-400 hover:text-amber-200 hover:border-amber-400/50'
              }`}
            >
              <Star size={12} className={isShowcased ? 'fill-current' : ''} />
            </button>
          )}
        </div>
      </div>

      {/* Middle Breathing Spacer (Allows artwork character to command attention) */}
      <div className="relative z-10 flex-1 min-h-[150px] sm:min-h-[190px] pointer-events-none" />

      {/* 6. BOTTOM CARD FACE: Modern Premium Glassmorphic Flow Plate */}
      <div
        className="relative z-20 pt-4 pb-4 px-4 sm:px-5 bg-gradient-to-t from-slate-950 via-slate-950/94 to-transparent border-t border-white/[0.06] backdrop-blur-[3px] pointer-events-none"
        style={{
          transform: isHovered && !prefersReducedMotion.current ? 'translateZ(20px)' : 'translateZ(10px)',
          transition: 'transform 0.35s ease-out',
        }}
      >
        {/* Card Display Name with Royal Flowing Typography */}
        <div className="text-center mb-1">
          <h3
            className="font-display font-black text-base sm:text-lg md:text-xl tracking-wide break-words max-w-full leading-snug drop-shadow-[0_2px_12px_rgba(0,0,0,0.9)] transition-colors duration-200"
            style={{
              color: cardNameColor,
              textShadow: `0 0 18px ${cardNameColor}77, 0 2px 6px rgba(0,0,0,0.95)`,
            }}
          >
            {card.name}
          </h3>
        </div>

        {/* Clean Royal Flowing Hairline Divider with Jewel Center Node */}
        <div className="my-1.5 mx-auto w-3/4 flex items-center justify-center relative">
          <div 
            className="w-full h-[1px] opacity-70"
            style={{
              background: `linear-gradient(90deg, transparent 0%, ${cardAccent} 50%, transparent 100%)`,
            }}
          />
          <div 
            className="absolute w-1.5 h-1.5 rotate-45 rounded-[0.5px] border shadow-[0_0_8px_currentColor]"
            style={{
              borderColor: cardAccent,
              backgroundColor: 'rgba(255,255,255,0.9)',
              color: cardAccent
            }}
          />
        </div>

        {/* Subtitle & Narrative Bio */}
        {(card.title || card.lore || card.description) && (
          <div className="space-y-0.5 mb-2.5 text-center">
            {card.title && (
              <p className={`font-sans text-[10px] sm:text-[11px] font-semibold tracking-wider uppercase line-clamp-1 ${
                card.rarity === 'COMMON' ? 'text-zinc-300' : 'text-amber-200/95'
              }`}>
                {card.title}
              </p>
            )}
            {(card.lore || card.description) && (
              <p className="font-sans text-slate-300/90 leading-relaxed font-normal text-[10.5px] sm:text-[11px] px-1 drop-shadow-sm line-clamp-2">
                {card.lore || card.description}
              </p>
            )}
          </div>
        )}

        {/* Bottom Bar: Telemetry Stats HUD & Roman Numeral Watermark (Clean, No OVR) */}
        <div className="pt-2 border-t border-white/[0.08] flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2 sm:gap-2.5 font-mono flex-wrap">
            {/* Dynamic Unified Stats (Clean, Modern Pill-less Indicators) */}
            {primaryStats.map((st, idx) => (
              <React.Fragment key={st.id}>
                {idx > 0 && <span className="text-white/20">·</span>}
                <span
                  className="text-[10px] sm:text-[11px] font-bold flex items-center gap-1.5"
                  style={{ color: st.color || '#38bdf8' }}
                  title={`${st.name}: ${st.value}/${st.maxValue || 100}`}
                >
                  <span 
                    className="w-1.5 h-1.5 rounded-full shadow-[0_0_6px_currentColor]"
                    style={{ backgroundColor: st.color || '#38bdf8' }}
                  />
                  <span className="truncate max-w-[42px] uppercase opacity-85 text-[9.5px]">{st.name.slice(0, 3)}</span>
                  <span className="tabular-nums font-black">{st.value}</span>
                </span>
              </React.Fragment>
            ))}
          </div>

          {/* Bottom Right: Discreet Jewel Accent (No rarity text) */}
          <div className="flex items-center gap-1.5 ms-auto shrink-0 select-none pointer-events-none">
            <span
              className="w-2 h-2 rounded-full shadow-[0_0_8px_currentColor] opacity-80"
              style={{
                backgroundColor: cardAccent,
                color: cardAccent
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
