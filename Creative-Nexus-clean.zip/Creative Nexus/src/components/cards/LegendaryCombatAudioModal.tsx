import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CollectibleCardData } from '../../types/cards';
import { LegendaryCombatAudioSection } from './LegendaryCombatAudioSection';
import { X, Crown } from 'lucide-react';

interface LegendaryCombatAudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetCard?: CollectibleCardData | null;
  legendaryCards?: CollectibleCardData[];
  isAr?: boolean;
}

export const LegendaryCombatAudioModal: React.FC<LegendaryCombatAudioModalProps> = ({
  isOpen,
  onClose,
  targetCard = null,
  legendaryCards = [],
  isAr = false
}) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/90 backdrop-blur-2xl overflow-y-auto"
        dir={isAr ? 'rtl' : 'ltr'}
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 15 }}
          transition={{ duration: 0.22, ease: 'easeOut' }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-2xl bg-gradient-to-b from-[#06181d]/98 via-[#041115]/98 to-[#020a0d]/98 border border-amber-400/40 rounded-3xl p-4 sm:p-6 shadow-[0_20px_70px_rgba(0,0,0,0.95),0_0_35px_rgba(245,158,11,0.2)] overflow-hidden my-auto flex flex-col max-h-[92vh]"
        >
          {/* Luminous Top Gold Bevel */}
          <div className="absolute top-0 inset-x-0 h-[2.5px] bg-gradient-to-r from-transparent via-amber-400 via-yellow-300 to-transparent pointer-events-none shadow-[0_0_14px_rgba(245,158,11,0.8)]" />

          {/* Header */}
          <div className="flex items-center justify-between pb-3.5 border-b border-amber-400/20 shrink-0 mb-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-600 text-stone-950 flex items-center justify-center shadow-lg shadow-amber-500/30 shrink-0 font-bold">
                <Crown size={22} className="drop-shadow-sm" />
              </div>
              <div className="min-w-0">
                <h3 className="text-base sm:text-lg font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-400 uppercase tracking-tight truncate">
                  {isAr ? 'تخصيص أصوات البطاقات الأسطورية' : 'Legendary Battle SFX Forge'}
                </h3>
                <p className="text-xs text-stone-300 font-mono truncate">
                  {isAr 
                    ? 'عيّن أصواتاً مميزة أو ارفع ملفات صوتية لكل هجوم ودفاع ومهارة'
                    : 'Assign distinct sounds or upload custom audio for every combat action'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-white/5 hover:bg-rose-500/20 text-stone-400 hover:text-rose-200 flex items-center justify-center transition-all cursor-pointer border border-white/10 shrink-0"
            >
              <X size={16} />
            </button>
          </div>

          {/* Embedded Section */}
          <div className="flex-1 overflow-y-auto studio-scrollbar pr-1">
            <LegendaryCombatAudioSection
              targetCard={targetCard}
              legendaryCards={legendaryCards}
              isAr={isAr}
              embedded={true}
              onSaveComplete={onClose}
            />
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
