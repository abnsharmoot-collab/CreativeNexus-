import React, { useState, useEffect, useRef } from 'react';
import { 
  LegendaryCombatSfxConfig,
  ActionSoundConfig,
  CombatActionType,
  ACTION_PRESET_OPTIONS,
  getLegendaryCombatSfxConfig,
  saveLegendaryCombatSfxConfig,
  playCustomAudio,
  playBattleSound
} from '../../utils/battleAudio';
import { CollectibleCardData } from '../../types/cards';
import { 
  Volume2, Music, Upload, Trash2, Play, Check, 
  Sparkles, Swords, Shield, Zap, Flame, Crown, Sliders, RefreshCw
} from 'lucide-react';

export interface LegendaryCombatAudioSectionProps {
  targetCard?: CollectibleCardData | null;
  legendaryCards?: CollectibleCardData[];
  isAr?: boolean;
  embedded?: boolean;
  onSaveComplete?: () => void;
}

export const LegendaryCombatAudioSection: React.FC<LegendaryCombatAudioSectionProps> = ({
  targetCard = null,
  legendaryCards = [],
  isAr = false,
  embedded = true,
  onSaveComplete
}) => {
  const [config, setConfig] = useState<LegendaryCombatSfxConfig>(() => getLegendaryCombatSfxConfig());
  const [selectedCardId, setSelectedCardId] = useState<string>(targetCard?.id || 'ALL_LEGENDARY');
  const [activeAction, setActiveAction] = useState<CombatActionType>('strike');
  const [testingAction, setTestingAction] = useState<CombatActionType | null>(null);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const fileInputRefs = {
    strike: useRef<HTMLInputElement>(null),
    heavy: useRef<HTMLInputElement>(null),
    defense: useRef<HTMLInputElement>(null),
    skill: useRef<HTMLInputElement>(null)
  };

  useEffect(() => {
    setConfig(getLegendaryCombatSfxConfig());
    if (targetCard) {
      setSelectedCardId(targetCard.id);
    }
  }, [targetCard]);

  const isCardSpecific = selectedCardId !== 'ALL_LEGENDARY';

  const currentActionConfig: ActionSoundConfig = isCardSpecific
    ? (config.cardOverrides?.[selectedCardId]?.[activeAction] || config.actions[activeAction] || { presetId: 'default' })
    : (config.actions[activeAction] || { presetId: 'default' });

  // Update current action config
  const updateCurrentActionConfig = (updates: Partial<ActionSoundConfig>) => {
    setConfig(prev => {
      if (isCardSpecific) {
        const prevOverrides = prev.cardOverrides || {};
        const cardMap = prevOverrides[selectedCardId] || {};
        const existing = cardMap[activeAction] || prev.actions[activeAction] || { presetId: 'default' };
        return {
          ...prev,
          cardOverrides: {
            ...prevOverrides,
            [selectedCardId]: {
              ...cardMap,
              [activeAction]: { ...existing, ...updates }
            }
          }
        };
      } else {
        const existing = prev.actions[activeAction] || { presetId: 'default' };
        return {
          ...prev,
          actions: {
            ...prev.actions,
            [activeAction]: { ...existing, ...updates }
          }
        };
      }
    });
  };

  // Handle uploading device audio
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, action: CombatActionType) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/') && !file.name.match(/\.(mp3|wav|ogg|m4a|aac|webm)$/i)) {
      alert(isAr ? 'يرجى اختيار ملف صوتي صالح (MP3, WAV, OGG, M4A, WebM)' : 'Please select a valid audio file (MP3, WAV, OGG, M4A, WebM)');
      return;
    }

    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const base64Url = uploadEvent.target?.result as string;
      if (base64Url) {
        updateCurrentActionConfig({
          presetId: 'custom',
          customAudioUrl: base64Url,
          customAudioName: file.name
        });
      }
    };
    reader.readAsDataURL(file);
  };

  // Remove custom audio and revert to default preset
  const handleRemoveCustomAudio = (action: CombatActionType) => {
    updateCurrentActionConfig({
      presetId: 'default',
      customAudioUrl: undefined,
      customAudioName: undefined
    });
  };

  // Test sound with visual feedback
  const handleTestSound = async (action: CombatActionType) => {
    setTestingAction(action);
    const cfg = isCardSpecific
      ? (config.cardOverrides?.[selectedCardId]?.[action] || config.actions[action])
      : config.actions[action];

    const vol = (cfg?.volume ?? 1.0) * (config.volume ?? 1.0);
    const pitch = cfg?.pitchMultiplier ?? 1.0;

    if (cfg?.customAudioUrl) {
      await playCustomAudio(cfg.customAudioUrl, vol, pitch);
    } else {
      const presetId = cfg?.presetId || 'default';
      const presetList = ACTION_PRESET_OPTIONS[action] || [];
      const found = presetList.find(p => p.id === presetId);
      if (found) {
        playBattleSound(found.soundType, vol);
      }
    }

    setTimeout(() => {
      setTestingAction(null);
    }, 450);
  };

  // Save changes
  const handleSaveAll = async () => {
    setIsSaving(true);
    try {
      await saveLegendaryCombatSfxConfig(config);
      setSaveStatus(isAr ? 'تم حفظ إعدادات الأصوات بنجاح!' : 'Combat sound effects saved successfully!');
      if (onSaveComplete) {
        onSaveComplete();
      }
      setTimeout(() => {
        setSaveStatus(null);
      }, 2500);
    } catch {
      setSaveStatus(isAr ? 'حدث خطأ أثناء الحفظ' : 'Failed to save configuration');
      setTimeout(() => setSaveStatus(null), 2500);
    } finally {
      setIsSaving(false);
    }
  };

  // Reset to system defaults
  const handleResetDefaults = () => {
    if (confirm(isAr ? 'هل تريد استعادة جميع أصوات البطاقات الأسطورية الافتراضية؟' : 'Reset all Legendary sound effects to defaults?')) {
      if (isCardSpecific) {
        setConfig(prev => {
          const nextOverrides = { ...(prev.cardOverrides || {}) };
          delete nextOverrides[selectedCardId];
          return { ...prev, cardOverrides: nextOverrides };
        });
      } else {
        setConfig(getLegendaryCombatSfxConfig());
      }
    }
  };

  const actionTabs: Array<{ id: CombatActionType; label: string; labelAr: string; icon: string; color: string }> = [
    { id: 'strike', label: 'Strike (Fast)', labelAr: 'هجوم سريع', icon: '🗡️', color: 'from-cyan-500 to-teal-400' },
    { id: 'heavy', label: 'Heavy (Slam)', labelAr: 'هجوم ثقيل', icon: '💥', color: 'from-amber-500 to-orange-400' },
    { id: 'defense', label: 'Defense (Shield)', labelAr: 'دفاع محكم', icon: '🛡️', color: 'from-blue-500 to-indigo-400' },
    { id: 'skill', label: 'Skill (Special)', labelAr: 'مهارة تكتيكية', icon: '✨', color: 'from-purple-500 to-pink-400' }
  ];

  const presetsForCurrent = ACTION_PRESET_OPTIONS[activeAction] || [];

  return (
    <div className={`space-y-4 text-xs ${embedded ? 'w-full' : ''}`} dir={isAr ? 'rtl' : 'ltr'}>
      {/* Top Banner & Scope Selector */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-amber-950/70 via-stone-900/90 to-amber-950/70 border border-amber-500/40 space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-600 text-stone-950 flex items-center justify-center font-bold shadow-md">
              <Crown size={18} />
            </div>
            <div>
              <h4 className="font-serif font-black text-amber-200 text-sm">
                {isAr ? 'تخصيص الأصوات القتالية للبطاقات الأسطورية' : 'Legendary Combat Sound Effects'}
              </h4>
              <p className="text-[10px] text-stone-400 font-mono">
                {isAr 
                  ? 'عيّن أصواتاً مخصصة لكل حركة قتالية (هجوم، دفاع، مهارة)'
                  : 'Assign curated epic presets or upload custom audio for each battle action'}
              </p>
            </div>
          </div>

          {/* Master Volume */}
          <div className="flex items-center gap-2 font-mono text-stone-300 bg-black/60 px-3 py-1.5 rounded-xl border border-white/10">
            <Volume2 size={14} className="text-amber-400 shrink-0" />
            <span className="text-[10px] text-stone-400">{isAr ? 'الصوت العام:' : 'Volume:'}</span>
            <input 
              type="range"
              min="0.1"
              max="1.5"
              step="0.05"
              value={config.volume}
              onChange={(e) => setConfig(prev => ({ ...prev, volume: parseFloat(e.target.value) }))}
              className="w-16 sm:w-20 accent-amber-400 cursor-pointer"
            />
            <span className="text-[10px] font-bold text-amber-300 tabular-nums">
              {Math.round(config.volume * 100)}%
            </span>
          </div>
        </div>

        {/* Target Scope Selector */}
        <div className="pt-2 border-t border-amber-500/20 flex items-center justify-between gap-3 flex-wrap text-xs font-mono">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-stone-300 font-bold">{isAr ? 'نطاق التطبيق:' : 'Application Scope:'}</span>
            <select
              value={selectedCardId}
              onChange={(e) => setSelectedCardId(e.target.value)}
              className="bg-black/80 border border-amber-400/40 rounded-xl px-2.5 py-1 text-xs font-mono text-amber-300 focus:outline-none focus:border-amber-400 cursor-pointer"
            >
              {targetCard && (
                <option value={targetCard.id}>
                  👑 {isAr ? 'هذه البطاقة الأسطورية فقط' : 'This Legendary Card Only'}: {targetCard.name}
                </option>
              )}
              <option value="ALL_LEGENDARY">
                ⭐ {isAr ? 'جميع البطاقات الأسطورية (افتراضي عام)' : 'All Legendary Cards (Global Default)'}
              </option>
              {legendaryCards.filter(c => c.id !== targetCard?.id).map(c => (
                <option key={c.id} value={c.id}>
                  👑 {c.name}
                </option>
              ))}
            </select>
          </div>

          {isCardSpecific && (
            <span className="text-[10px] text-amber-400/90 font-mono italic">
              {isAr ? 'يتم تخصيص هذه البطاقة على وجه الخصوص' : 'Custom overrides for this specific card'}
            </span>
          )}
        </div>
      </div>

      {/* 4 Action Navigation Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {actionTabs.map(tab => {
          const isActive = activeAction === tab.id;
          const hasCustom = isCardSpecific
            ? Boolean(config.cardOverrides?.[selectedCardId]?.[tab.id]?.customAudioUrl)
            : Boolean(config.actions[tab.id]?.customAudioUrl);

          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveAction(tab.id)}
              className={`p-2.5 rounded-2xl border transition-all cursor-pointer flex flex-col items-center gap-1 relative overflow-hidden text-center ${
                isActive
                  ? 'bg-gradient-to-b from-[#132c32] via-[#091f24] to-[#041114] border-amber-400 text-white shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                  : 'bg-black/40 hover:bg-black/60 border-white/10 text-stone-400 hover:text-white'
              }`}
            >
              {isActive && (
                <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-amber-400 to-yellow-300" />
              )}
              <div className="flex items-center gap-1.5 text-base sm:text-lg">
                <span>{tab.icon}</span>
                <span className="text-xs font-bold font-mono">
                  {isAr ? tab.labelAr : tab.label}
                </span>
              </div>
              {hasCustom && (
                <span className="text-[9px] font-mono font-black text-emerald-400 bg-emerald-950/80 px-1.5 py-0.2 rounded-full border border-emerald-500/40">
                  {isAr ? 'ملف خاص' : 'CUSTOM FILE'}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Main Configuration Box for Active Action */}
      <div className="space-y-3.5 border border-white/10 rounded-2xl p-3 sm:p-4 bg-black/50">
        {/* Preset Selector */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-black text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
              <Music size={14} className="text-amber-400" />
              <span>{isAr ? 'اختر نغمة مؤثرة جاهزة' : 'Select Curated Epic Sound Preset'}</span>
            </span>
            <span className="text-[10px] font-mono text-stone-400">
              {presetsForCurrent.length} {isAr ? 'نغمات متاحة' : 'presets'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {presetsForCurrent.map(preset => {
              const isSelected = (currentActionConfig.presetId || 'default') === preset.id && !currentActionConfig.customAudioUrl;

              return (
                <div
                  key={preset.id}
                  onClick={() => {
                    updateCurrentActionConfig({
                      presetId: preset.id,
                      customAudioUrl: undefined,
                      customAudioName: undefined
                    });
                    playBattleSound(preset.soundType, (currentActionConfig.volume ?? 1.0) * config.volume);
                  }}
                  className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-gradient-to-r from-amber-500/25 via-yellow-500/15 to-transparent border-amber-400 text-white shadow-[0_0_12px_rgba(245,158,11,0.25)]'
                      : 'bg-stone-950/60 hover:bg-stone-900 border-white/10 text-stone-300'
                  }`}
                >
                  <div className="min-w-0 flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-amber-400 shadow-[0_0_6px_#f59e0b]' : 'bg-stone-600'}`} />
                    <div className="min-w-0">
                      <p className="text-xs font-bold font-mono truncate text-white">
                        {preset.name}
                      </p>
                      <p className="text-[10px] text-stone-400 truncate font-mono">
                        {preset.nameAr}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      playBattleSound(preset.soundType, (currentActionConfig.volume ?? 1.0) * config.volume);
                    }}
                    className="p-1.5 rounded-lg bg-white/10 hover:bg-amber-400 hover:text-stone-950 text-amber-300 transition-colors shrink-0 cursor-pointer"
                    title={isAr ? 'استماع تجريبي' : 'Preview'}
                  >
                    <Play size={12} className="fill-current" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Custom Audio Upload */}
        <div className="p-3 rounded-2xl bg-gradient-to-r from-slate-950/90 via-black/90 to-slate-950/90 border border-amber-400/30 space-y-2">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <span className="text-xs font-mono font-black text-amber-200 block uppercase">
                {isAr ? 'أو ارفع ملف صوتي خاص بك لهذا الإجراء' : 'Or Upload Custom Device Audio'}
              </span>
              <span className="text-[10px] text-stone-400 font-mono">
                {isAr ? 'يدعم MP3, WAV, OGG, M4A' : 'Supports MP3, WAV, OGG, M4A'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="file"
                ref={fileInputRefs[activeAction]}
                accept="audio/*,.mp3,.wav,.ogg,.m4a"
                className="hidden"
                onChange={(e) => handleFileUpload(e, activeAction)}
              />

              <button
                type="button"
                onClick={() => fileInputRefs[activeAction].current?.click()}
                className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-mono font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-md active:scale-95 transition-all"
              >
                <Upload size={13} />
                <span>{isAr ? 'اختيار ملف صوتي' : 'Upload Audio'}</span>
              </button>

              {currentActionConfig.customAudioUrl && (
                <button
                  type="button"
                  onClick={() => handleRemoveCustomAudio(activeAction)}
                  className="p-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500 text-rose-300 hover:text-white border border-rose-500/40 transition-colors cursor-pointer"
                  title={isAr ? 'إلغاء الملف المخصص' : 'Revert to preset'}
                >
                  <Trash2 size={13} />
                </button>
              )}
            </div>
          </div>

          {currentActionConfig.customAudioUrl && (
            <div className="flex items-center justify-between p-2 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-xs font-mono text-emerald-300">
              <span className="truncate max-w-[280px]">
                🎵 {currentActionConfig.customAudioName || 'Custom Audio Active'}
              </span>
              <button
                type="button"
                onClick={() => playCustomAudio(currentActionConfig.customAudioUrl!, (currentActionConfig.volume ?? 1.0) * config.volume, currentActionConfig.pitchMultiplier ?? 1.0)}
                className="px-2 py-0.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500 hover:text-stone-950 text-emerald-300 font-bold transition-colors cursor-pointer flex items-center gap-1"
              >
                <Play size={11} className="fill-current" />
                <span>{isAr ? 'تشغيل' : 'Play'}</span>
              </button>
            </div>
          )}
        </div>

        {/* Volume & Pitch Tuning */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 rounded-2xl bg-black/60 border border-white/10">
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs font-mono text-stone-300">
              <span>{isAr ? 'مستوى صوت هذا الهجوم' : 'Action Loudness'}</span>
              <span className="font-bold text-amber-300 tabular-nums">
                {Math.round((currentActionConfig.volume ?? 1.0) * 100)}%
              </span>
            </div>
            <input
              type="range"
              min="0.2"
              max="1.5"
              step="0.05"
              value={currentActionConfig.volume ?? 1.0}
              onChange={(e) => updateCurrentActionConfig({ volume: parseFloat(e.target.value) })}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs font-mono text-stone-300">
              <span>{isAr ? 'درجة النغمة والسرعة (Pitch)' : 'Pitch / Speed Multiplier'}</span>
              <span className="font-bold text-teal-300 tabular-nums">
                {(currentActionConfig.pitchMultiplier ?? 1.0).toFixed(2)}x
              </span>
            </div>
            <input
              type="range"
              min="0.5"
              max="1.8"
              step="0.05"
              value={currentActionConfig.pitchMultiplier ?? 1.0}
              onChange={(e) => updateCurrentActionConfig({ pitchMultiplier: parseFloat(e.target.value) })}
              className="w-full accent-teal-400 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Action Buttons Toolbar: Test + Reset + Save */}
      <div className="pt-2 flex items-center justify-between gap-2.5 flex-wrap">
        <button
          type="button"
          onClick={() => handleTestSound(activeAction)}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-teal-500/20 via-cyan-500/20 to-teal-500/20 hover:from-teal-500/40 hover:to-cyan-500/40 border border-[#5eead4]/40 text-teal-200 font-mono font-bold text-xs flex items-center gap-2 cursor-pointer shadow-inner active:scale-95 transition-all"
        >
          <Play size={13} className={testingAction === activeAction ? 'animate-ping fill-current' : 'fill-current'} />
          <span>
            {isAr 
              ? `اختبار [${actionTabs.find(t => t.id === activeAction)?.labelAr}]` 
              : `Test [${actionTabs.find(t => t.id === activeAction)?.label}]`}
          </span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-stone-400 hover:text-white transition-colors cursor-pointer border border-white/10"
            title={isAr ? 'استعادة الافتراضي' : 'Reset to default'}
          >
            <RefreshCw size={13} />
          </button>

          <button
            type="button"
            onClick={handleSaveAll}
            disabled={isSaving}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:brightness-110 text-stone-950 font-serif font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md shadow-amber-500/30 cursor-pointer active:scale-95 transition-all disabled:opacity-50"
          >
            {isSaving ? (
              <RefreshCw size={13} className="animate-spin" />
            ) : (
              <Check size={13} />
            )}
            <span>{isAr ? 'حفظ إعدادات الأصوات' : 'Save SFX'}</span>
          </button>
        </div>
      </div>

      {saveStatus && (
        <div className="p-2 rounded-xl bg-emerald-500 text-stone-950 font-bold font-mono text-xs flex items-center gap-1.5">
          <Check size={14} />
          <span>{saveStatus}</span>
        </div>
      )}
    </div>
  );
};
