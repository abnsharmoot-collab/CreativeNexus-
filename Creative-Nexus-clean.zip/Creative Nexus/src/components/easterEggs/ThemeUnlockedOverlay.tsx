import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useEasterEggs } from '../../context/EasterEggContext';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';

export const ThemeUnlockedOverlay: React.FC = () => {
  const { showThemeUnlockedOverlay, dismissThemeUnlockedOverlay } = useEasterEggs();
  const { language } = useLanguage();
  const { isAuthenticated } = useAuth();
  const isAr = language === 'ar';

  // Short and satisfying: dismisses after 3.2 seconds
  useEffect(() => {
    if (!showThemeUnlockedOverlay) return;
    const timer = setTimeout(() => {
      dismissThemeUnlockedOverlay();
    }, 3200);
    return () => clearTimeout(timer);
  }, [showThemeUnlockedOverlay, dismissThemeUnlockedOverlay]);

  return (
    <AnimatePresence>
      {showThemeUnlockedOverlay && (
        <div
          onClick={dismissThemeUnlockedOverlay}
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm cursor-pointer"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8, rotate: -2 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: -15 }}
            transition={{ type: 'spring', damping: 20, stiffness: 280 }}
            className="w-full max-w-[300px] mesopotamian-stone-bg border-2 border-amber-600/60 rounded-3xl p-7 text-center shadow-[0_25px_70px_rgba(0,0,0,0.9),0_0_40px_rgba(217,119,6,0.3)] flex flex-col items-center select-none"
          >
            {/* Mesopotamian Inscription Accent */}
            <div className="text-[10px] font-mono text-amber-500/60 tracking-[0.25em] mb-2">
              𒀭 𒆠 𒈗
            </div>

            {/* Iraqi Flag */}
            <motion.span
              initial={{ scale: 0.6 }}
              animate={{ scale: [0.6, 1.2, 1] }}
              transition={{ duration: 0.5, ease: 'easeOut' }}
              className="text-5xl mb-3 leading-none filter drop-shadow-[0_4px_16px_rgba(0,0,0,0.9)]"
            >
              🇮🇶
            </motion.span>

            {/* Title */}
            <h3 className="text-base sm:text-lg font-serif font-black tracking-widest mesopotamian-gold-text uppercase mb-1">
              {isAr ? 'السمة العراقية' : 'IRAQI THEME'}
            </h3>

            {/* Unlocked Label */}
            <span className="text-xs font-mono font-bold tracking-[0.25em] text-emerald-300 uppercase bg-emerald-950/80 border border-emerald-500/40 px-3.5 py-1 rounded-full mt-2 shadow-inner">
              {isAr ? 'مفتوحة الآن' : 'UNLOCKED'}
            </span>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
