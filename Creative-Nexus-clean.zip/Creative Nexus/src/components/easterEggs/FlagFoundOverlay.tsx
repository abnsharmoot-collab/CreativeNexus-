import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useEasterEggs } from '../../context/EasterEggContext';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { TOTAL_IRAQI_FLAGS } from '../../config/easterEggs';

export const FlagFoundOverlay: React.FC = () => {
  const { recentFlagCollected, dismissRecentFlagBanner } = useEasterEggs();
  const { language } = useLanguage();
  const { isAuthenticated } = useAuth();
  const isAr = language === 'ar';

  // Automatically dismiss overlay after 2.2 seconds
  useEffect(() => {
    if (!recentFlagCollected || !isAuthenticated) return;
    const timer = setTimeout(() => {
      dismissRecentFlagBanner();
    }, 2200);
    return () => clearTimeout(timer);
  }, [recentFlagCollected, isAuthenticated, dismissRecentFlagBanner]);

  if (!isAuthenticated) return null;

  return (
    <AnimatePresence>
      {recentFlagCollected && (
        <div
          onClick={dismissRecentFlagBanner}
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/40 backdrop-blur-[2px] cursor-pointer"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.85, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: -10 }}
            transition={{ type: 'spring', damping: 22, stiffness: 320 }}
            className="w-full max-w-[260px] mesopotamian-stone-bg border-2 border-amber-600/50 rounded-3xl p-6 text-center shadow-[0_20px_60px_rgba(0,0,0,0.9),0_0_35px_rgba(217,119,6,0.2)] flex flex-col items-center select-none"
          >
            {/* Flag Visual */}
            <span className="text-4xl mb-3 leading-none drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)]">
              🇮🇶
            </span>

            {/* Minimal Status Label */}
            <span className="text-xs font-serif font-bold tracking-[0.2em] mesopotamian-gold-text uppercase mb-2">
              {isAr ? 'تم العثور على علم' : 'FLAG FOUND'}
            </span>

            {/* Counter */}
            <span className="text-2xl font-mono font-black text-amber-100 tracking-widest">
              {recentFlagCollected.number} / {TOTAL_IRAQI_FLAGS}
            </span>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
