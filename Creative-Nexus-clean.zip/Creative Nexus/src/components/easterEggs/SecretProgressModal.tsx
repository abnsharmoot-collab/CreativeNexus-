import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check, Compass, Lock } from 'lucide-react';
import { useEasterEggs } from '../../context/EasterEggContext';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { TOTAL_IRAQI_FLAGS } from '../../config/easterEggs';

export const SecretProgressModal: React.FC = () => {
  const {
    isSecretProgressOpen,
    setIsSecretProgressOpen,
    flagsCount,
    totalFlags,
    saddamBestTime,
    saddamGameGoalReached,
    finalRewardGranted,
    iraqiThemeUnlocked,
    activeTheme,
    setThemePreference,
  } = useEasterEggs();

  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { isAuthenticated, isOwner, loginWithDiscord } = useAuth();
  const isOwnerAccess = Boolean(isOwner);

  if (!isSecretProgressOpen) return null;

  // Format MM:SS
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const isAllFlagsFound = flagsCount >= totalFlags;
  const isGoalReached = saddamGameGoalReached || saddamBestTime >= 120;
  const isFullyUnlocked = isOwnerAccess || finalRewardGranted || iraqiThemeUnlocked || (isAllFlagsFound && isGoalReached);

  // Guest found all flags without logging in, but only if theme is not yet fully unlocked
  const isGuestClaimPending = !isOwnerAccess && !isFullyUnlocked && isAllFlagsFound && !isGoalReached && !isAuthenticated;

  const handleLogin = () => {
    loginWithDiscord();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[9990] flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
        {/* Backdrop click to close */}
        <div
          className="absolute inset-0 cursor-pointer"
          onClick={() => setIsSecretProgressOpen(false)}
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -10 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          className="relative w-full max-w-sm mesopotamian-stone-bg border border-amber-600/40 rounded-3xl p-6 shadow-[0_25px_70px_rgba(0,0,0,0.9),0_0_35px_rgba(217,119,6,0.15)] text-white z-10 select-none overflow-hidden"
        >
          {/* Subtle warm antique gold header glow */}
          <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-amber-500 to-transparent opacity-80" />

          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-amber-600/30 mb-5">
            <div className="flex items-center gap-2">
              <span className="text-xl">🇮🇶</span>
              <div>
                <h2 className="text-sm font-serif font-bold tracking-widest mesopotamian-gold-text uppercase">
                  {isAr ? 'السر العراقي' : 'IRAQI SECRET'}
                </h2>
                <div className="text-[9px] font-mono text-amber-500/50 tracking-[0.2em]">
                  𒀭 𒆠 𒈗
                </div>
              </div>
            </div>
            <button
              onClick={() => setIsSecretProgressOpen(false)}
              className="p-1 rounded-lg text-amber-400/60 hover:text-amber-200 hover:bg-amber-950/40 transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X size={18} />
            </button>
          </div>

          {/* Section 1: FLAGS */}
          <div className="mb-5 bg-[#19110a]/90 border border-amber-600/25 rounded-2xl p-4 shadow-inner">
            <div className="flex items-center justify-between text-xs font-mono font-bold text-amber-200/80 tracking-wider uppercase mb-2.5">
              <span>{isAr ? 'الأعلام' : 'FLAGS'}</span>
              <span className="mesopotamian-gold-text font-mono font-bold">
                {flagsCount} / {totalFlags}
              </span>
            </div>

            {/* Visual Progress Bar */}
            <div className="w-full bg-[#0a0604] rounded-full h-2.5 overflow-hidden p-0.5 border border-amber-600/30 flex gap-1 shadow-inner">
              {Array.from({ length: totalFlags }).map((_, i) => (
                <div
                  key={i}
                  className={`flex-1 h-full rounded-sm transition-colors duration-300 ${
                    i < flagsCount ? 'bg-gradient-to-r from-amber-600 to-amber-400 shadow-[0_0_6px_rgba(245,158,11,0.8)]' : 'bg-[#2a170d]'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Section 2: SECRET GAME (WITH SECRET NAME & NO PLAY BUTTON - SEARCH REQUIRED) */}
          <div className="mb-5 bg-[#19110a]/90 border border-amber-600/25 rounded-2xl p-4 shadow-inner">
            <div className="flex items-center justify-between gap-2 text-xs font-mono font-bold tracking-wider uppercase mb-2.5">
              <div className="flex items-center gap-1.5 truncate">
                <span className="text-amber-400">⚡</span>
                <span className="mesopotamian-gold-text truncate font-serif font-bold">
                  {isAr ? 'لعبة سرية' : 'SECRET GAME'}
                </span>
              </div>
              <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-amber-950/80 border border-amber-500/40 text-amber-300 tracking-wider shrink-0">
                {isAr ? 'سري للغاية' : 'CLASSIFIED'}
              </span>
            </div>

            {/* Secret Game Hint (Search only - explicitly requested by user) */}
            <div className="mb-3 px-3 py-2 rounded-xl bg-[#24150b]/90 border border-amber-600/35 flex items-start gap-2 text-[11px] font-mono leading-relaxed text-amber-200/90 shadow-inner">
              <Compass size={13} className="text-amber-400 shrink-0 mt-0.5" />
              <span>
                {isAr
                  ? 'في لعبة سرية موجودة في الموقع، دور عليها فقط!'
                  : 'There is a secret game on the site, search for it!'}
              </span>
            </div>

            <div className="flex items-center justify-between text-xs font-mono">
              <div className="flex flex-col gap-0.5">
                <span className="text-[10px] text-amber-400/50 tracking-widest">{isAr ? 'الأفضل' : 'BEST'}</span>
                <span className="text-sm font-bold text-amber-100 tracking-wider">{formatTime(saddamBestTime)}</span>
              </div>

              <div className="flex flex-col gap-0.5 text-center">
                <span className="text-[10px] text-amber-400/50 tracking-widest">{isAr ? 'الهدف' : 'GOAL'}</span>
                <span className="text-sm font-bold text-amber-400 tracking-wider">2:00</span>
              </div>

              <div className="flex flex-col items-end gap-0.5">
                <span className="text-[10px] text-amber-400/50 tracking-widest">{isAr ? 'الحالة' : 'STATUS'}</span>
                {isGoalReached ? (
                  <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-1">
                    <Check size={12} />
                    <span>{isAr ? 'تم بلوغ 2:00' : '✓ 2:00 REACHED'}</span>
                  </span>
                ) : (
                  <span className="text-[11px] font-bold text-amber-300/40 flex items-center gap-1">
                    <Lock size={11} className="text-amber-500/30" />
                    <span>{isAr ? 'غير مكتمل' : 'INCOMPLETE'}</span>
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Section 3: THEME */}
          <div className="bg-[#19110a]/90 border border-amber-600/25 rounded-2xl p-4 shadow-inner">
            <div className="flex items-center justify-between text-xs font-mono font-bold tracking-wider uppercase mb-3">
              <span className="text-amber-200/80 flex items-center gap-1.5">
                <span>🇮🇶</span>
                <span>{isAr ? 'السمة العراقية' : 'IRAQI THEME'}</span>
              </span>

              {isFullyUnlocked ? (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-mono">
                  {isAr ? 'مفتوحة' : 'UNLOCKED'}
                </span>
              ) : (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#24170d] border border-amber-600/30 text-amber-400/50 font-mono flex items-center gap-1">
                  <span>🔒</span>
                  <span>{isAr ? 'مغلقة' : 'LOCKED'}</span>
                </span>
              )}
            </div>

            {/* Guest with all flags found: Prompt login */}
            {isGuestClaimPending ? (
              <div className="pt-2 text-center">
                <div className="text-xs font-mono font-bold text-amber-300 mb-2">
                  {totalFlags} / {totalFlags} {isAr ? 'أعلام تم العثور عليها' : 'FLAGS FOUND'}
                </div>
                <button
                  onClick={handleLogin}
                  className="w-full py-2.5 rounded-xl mesopotamian-btn-gold text-black font-mono font-black text-xs tracking-wider uppercase shadow-lg hover:brightness-110 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>🔐</span>
                  <span>{isAr ? 'سجل الدخول للمطالبة' : 'LOGIN TO CLAIM'}</span>
                </button>
              </div>
            ) : isFullyUnlocked ? (
              /* Theme Selector Options */
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => setThemePreference('creative-nexus')}
                  className={`py-2 px-2.5 rounded-xl font-mono text-[11px] font-bold tracking-wider uppercase transition-all cursor-pointer border text-center ${
                    activeTheme === 'creative-nexus'
                      ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                      : 'bg-[#120b06] border-amber-900/40 text-amber-200/50 hover:text-amber-100 hover:border-amber-700/50'
                  }`}
                >
                  CREATIVE NEXUS
                </button>

                <button
                  onClick={() => setThemePreference('kohan-iraqi')}
                  className={`py-2 px-2.5 rounded-xl font-mono text-[11px] font-bold tracking-wider uppercase transition-all cursor-pointer border text-center ${
                    activeTheme === 'kohan-iraqi'
                      ? 'mesopotamian-btn-gold text-amber-950 font-black shadow-[0_0_15px_rgba(245,158,11,0.35)]'
                      : 'bg-[#120b06] border-amber-900/40 text-amber-200/50 hover:text-amber-100 hover:border-amber-700/50'
                  }`}
                >
                  IRAQI THEME 🇮🇶
                </button>
              </div>
            ) : (
              /* Still locked guidance */
              <div className="text-[11px] font-mono text-amber-400/50 text-center pt-1">
                {isAr
                  ? `يتطلب العثور على ${totalFlags} أعلام وبلوغ 2:00 في العملية السرية`
                  : `Requires all ${totalFlags} flags & 2:00 in classified operation`}
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
