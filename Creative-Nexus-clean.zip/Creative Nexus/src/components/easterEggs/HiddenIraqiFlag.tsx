import React from 'react';
import { useEasterEggs } from '../../context/EasterEggContext';
import { useAuth } from '../../context/AuthContext';

interface HiddenIraqiFlagProps {
  flagId: string;
  className?: string;
  style?: React.CSSProperties;
  title?: string;
}

/**
 * A discreet, hidden Iraqi flag integrated naturally into existing website elements.
 * - Restricted to logged-in users only.
 * - Non-obvious and subtly integrated.
 * - Disappears immediately upon clicking/tapping.
 * - Persisted so it can never be collected twice.
 */
export const HiddenIraqiFlag: React.FC<HiddenIraqiFlagProps> = ({
  flagId,
  className = '',
  style,
  title,
}) => {
  const { isAuthenticated, isOwner } = useAuth();
  const { isFlagCollected, collectFlag } = useEasterEggs();

  // If not authenticated (and not owner) or already discovered, it is completely removed/invisible
  if ((!isAuthenticated && !isOwner) || isFlagCollected(flagId)) {
    return null;
  }

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    collectFlag(flagId);
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      style={style}
      aria-label={title || 'Decorative archival mark'}
      className={`relative inline-flex items-center justify-center p-1 -m-1 opacity-40 hover:opacity-90 transition-all duration-300 cursor-pointer select-none group focus:outline-none ${className}`}
    >
      {/* Precise, compact Iraqi Flag SVG (18x12 ratio) */}
      <span className="block w-[18px] h-[12px] rounded-[2px] overflow-hidden shadow-sm shadow-black/60 border border-white/10 group-hover:scale-110 transition-transform">
        <svg viewBox="0 0 900 600" className="w-full h-full block">
          {/* Top Red Stripe */}
          <rect width="900" height="200" fill="#ce1126" />
          {/* Middle White Stripe */}
          <rect y="200" width="900" height="200" fill="#ffffff" />
          {/* Bottom Black Stripe */}
          <rect y="400" width="900" height="200" fill="#000000" />
          {/* Green Takbir Kufic Emblem in center */}
          <g fill="#007a3d" transform="translate(450, 300) scale(0.65)">
            <path d="M -160 -25 L -140 -25 L -140 25 L -160 25 Z M -110 -25 L -90 -25 L -90 25 L -110 25 Z M -60 -25 L -40 -25 L -40 25 L -60 25 Z M 40 -25 L 60 -25 L 60 25 L 40 25 Z M 90 -25 L 110 -25 L 110 25 L 90 25 Z M 140 -25 L 160 -25 L 160 25 L 140 25 Z M -25 -25 L 25 -25 L 25 -5 L -25 -5 Z M -25 5 L 25 5 L 25 25 L -25 25 Z" />
          </g>
        </svg>
      </span>
    </button>
  );
};
