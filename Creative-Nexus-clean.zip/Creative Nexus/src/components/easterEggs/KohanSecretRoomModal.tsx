import React from 'react';
import { useEasterEggs } from '../../context/EasterEggContext';
import { useAuth } from '../../context/AuthContext';
import { KohanSecretRoomGame } from '../games/KohanSecretRoomGame';

export const KohanSecretRoomModal: React.FC = () => {
  const { isKohanGameOpen, setIsKohanGameOpen } = useEasterEggs();
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated || !isKohanGameOpen) {
    return null;
  }

  return (
    <KohanSecretRoomGame
      isOpen={isKohanGameOpen}
      onClose={() => setIsKohanGameOpen(false)}
    />
  );
};
