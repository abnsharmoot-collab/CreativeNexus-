import React from 'react';
import { motion } from 'motion/react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid,
  Legend
} from 'recharts';
import { 
  Users, 
  UserPlus, 
  UserMinus, 
  TrendingUp,
  Calendar,
  ShieldCheck,
  Percent,
  Clock
} from 'lucide-react';
import { ServerAnalyticsData } from '../../types/analytics';
import { useLanguage } from '../../context/LanguageContext';

interface MemberGrowthSectionProps {
  data: ServerAnalyticsData;
  timeframe: 'today' | 'week' | 'month';
}

export const MemberGrowthSection: React.FC<MemberGrowthSectionProps> = ({ data, timeframe }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const mg = data.membersGrowth;

  const currentStats = timeframe === 'today'
    ? mg.today
    : timeframe === 'week'
    ? mg.week
    : mg.month;

  const joinedLabel = timeframe === 'today'
    ? (isAr ? 'الأعضاء الجدد اليوم' : 'New Members Joined Today')
    : timeframe === 'week'
    ? (isAr ? 'الأعضاء الجدد هذا الأسبوع' : 'New Members Joined This Week')
    : (isAr ? 'الأعضاء الجدد هذا الشهر' : 'New Members Joined This Month');

  const departuresLabel = timeframe === 'today'
    ? (isAr ? 'المغادرون اليوم' : 'Departures Today')
    : timeframe === 'week'
    ? (isAr ? 'المغادرون هذا الأسبوع' : 'Departures This Week')
    : (isAr ? 'المغادرون هذا الشهر' : 'Departures This Month');

  const chartTitle = timeframe === 'today'
    ? (isAr ? 'توزيع الانضمام والمغادرة على مدار الـ 24 ساعة (اليوم)' : '24-Hour Join & Leave Distribution (Today)')
    : timeframe === 'week'
    ? (isAr ? 'مخطط الانضمام والمغادرة لآخر 7 أيام (أسبوعي)' : '7-Day Join & Leave Distribution (Weekly)')
    : (isAr ? 'مخطط الانضمام والمغادرة على مدار الـ 4 أسابيع (شهري)' : '4-Week Monthly Influx & Departures Trend');

  const periodSubtitle = timeframe === 'today'
    ? (isAr ? 'اليوم (24 ساعة)' : 'Today (24h)')
    : timeframe === 'week'
    ? (isAr ? 'آخر 7 أيام' : 'Last 7 Days')
    : (isAr ? 'آخر 30 يوم (4 أسابيع)' : 'Last 30 Days');

  // Chart data adapting to selected timeframe (Today / Week / Month)
  const trendData = React.useMemo(() => {
    if (timeframe === 'month') {
      const source = mg.monthlyJoinsTrend && mg.monthlyJoinsTrend.length > 0 
        ? mg.monthlyJoinsTrend 
        : [
            { day: 'W1', joined: 65, left: 6 },
            { day: 'W2', joined: 78, left: 8 },
            { day: 'W3', joined: 82, left: 7 },
            { day: 'W4', joined: 65, left: 7 }
          ];

      return source.map((item, idx) => ({
        label: isAr ? `الأسبوع ${idx + 1}` : `Week ${idx + 1}`,
        joined: item.joined,
        left: item.left,
        net: item.joined - item.left
      }));
    }

    if (timeframe === 'today') {
      const source = mg.hourlyJoinsTrend && mg.hourlyJoinsTrend.length > 0
        ? mg.hourlyJoinsTrend
        : [
            { hour: '00:00', joined: 1, left: 0 },
            { hour: '03:00', joined: 0, left: 0 },
            { hour: '06:00', joined: 1, left: 0 },
            { hour: '09:00', joined: 2, left: 0 },
            { hour: '12:00', joined: 3, left: 0 },
            { hour: '14:00', joined: 4, left: 1 },
            { hour: '17:00', joined: 1, left: 0 },
            { hour: '20:00', joined: 0, left: 0 }
          ];

      return source.map(item => ({
        label: item.hour,
        joined: item.joined,
        left: item.left,
        net: item.joined - item.left
      }));
    }

    // Default to 'week' (7 days)
    const source = mg.dailyJoinsTrend && mg.dailyJoinsTrend.length > 0
      ? mg.dailyJoinsTrend
      : [
          { day: 'Tue', joined: 7, left: 1 },
          { day: 'Wed', joined: 25, left: 2 },
          { day: 'Thu', joined: 23, left: 2 },
          { day: 'Fri', joined: 20, left: 2 },
          { day: 'Sat', joined: 18, left: 1 },
          { day: 'Sun', joined: 9, left: 1 },
          { day: 'Mon', joined: 12, left: 1 }
        ];

    const dayNameMap: Record<string, string> = {
      Sun: isAr ? 'الأحد' : 'Sun',
      Mon: isAr ? 'الإثنين' : 'Mon',
      Tue: isAr ? 'الثلاثاء' : 'Tue',
      Wed: isAr ? 'الأربعاء' : 'Wed',
      Thu: isAr ? 'الخميس' : 'Thu',
      Fri: isAr ? 'الجمعة' : 'Fri',
      Sat: isAr ? 'السبت' : 'Sat'
    };

    return source.map(d => ({
      label: dayNameMap[d.day] || d.day,
      joined: d.joined,
      left: d.left,
      net: d.joined - d.left
    }));
  }, [timeframe, mg, isAr]);

  // Calculate join-to-leave ratio
  const joinLeaveRatio = currentStats.left > 0
    ? (currentStats.joined / currentStats.left).toFixed(1)
    : currentStats.joined.toString();

  return (
    <div 
      id="member-growth-section"
      className="w-full rounded-3xl bg-archive-teal-light/20 backdrop-blur-xl border border-archive-cyan/20 p-6 md:p-8 space-y-6 shadow-xl shadow-archive-cyan/5 transition-all duration-300 relative overflow-hidden outline-none"
    >
      {/* Background ambient lighting */}
      <div className="absolute -right-24 -top-24 w-72 h-72 bg-archive-cyan/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10 border-b border-slate-800/80 pb-5">
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-2xl bg-archive-cyan/15 border border-archive-cyan/30 flex items-center justify-center text-archive-cyan shadow-inner shrink-0">
            <Users size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="font-sans text-lg sm:text-xl font-bold text-white tracking-tight">
                {isAr ? 'نمو الأعضاء وإحصائيات الانضمام والمغادرة' : 'Member Influx & Departure Telemetry'}
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-medium bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                {currentStats.growthRate}
              </span>
            </div>
            <p className="font-sans text-xs text-slate-400 mt-0.5">
              {isAr 
                ? 'إحصائيات دقيقة متزامنة ومحدثة تلقائياً بناءً على الفترة الزمنية المحددة (يومي، أسبوعي، شهري).' 
                : 'Accurate telemetry automatically updated according to the active timeframe filter.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-400 bg-archive-dark/40 px-3 py-1.5 rounded-xl border border-archive-cyan/10 shrink-0">
          <Calendar size={13} className="text-archive-cyan" />
          <span>{data.overview.totalMembers} {isAr ? 'إجمالي الأعضاء' : 'Total Members'}</span>
        </div>
      </div>

      {/* 4 Metric Cards for Rich Influx & Departure Information */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 relative z-10">
        {/* Joined */}
        <div className="bg-archive-dark/50 rounded-2xl p-4 border border-emerald-500/20 flex flex-col justify-between">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-mono mb-2">
            <UserPlus size={15} />
            <span>{joinedLabel}</span>
          </div>
          <div className="text-3xl font-display font-bold text-emerald-400 tracking-tight">
            +{(currentStats?.joined ?? 0).toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-400/80 font-mono mt-1 flex items-center justify-between">
            <span>{isAr ? 'أعضاء حقيقيون' : 'Verified Accounts'}</span>
            <span className="text-emerald-300 font-semibold">{currentStats.growthRate}</span>
          </div>
        </div>

        {/* Left */}
        <div className="bg-archive-dark/50 rounded-2xl p-4 border border-rose-500/20 flex flex-col justify-between">
          <div className="flex items-center gap-2 text-rose-400 text-xs font-mono mb-2">
            <UserMinus size={15} />
            <span>{departuresLabel}</span>
          </div>
          <div className="text-3xl font-display font-bold text-rose-300 tracking-tight">
            -{currentStats.left}
          </div>
          <div className="text-[11px] text-rose-400/80 font-mono mt-1 flex items-center justify-between">
            <span>{isAr ? 'معدل مغادرة ضئيل' : 'Low Churn Rate'}</span>
            <span className="text-rose-300 font-semibold">
              {((currentStats.left / Math.max(1, currentStats.joined)) * 100).toFixed(1)}%
            </span>
          </div>
        </div>

        {/* Net Growth */}
        <div className="bg-archive-dark/50 rounded-2xl p-4 border border-archive-cyan/20 flex flex-col justify-between">
          <div className="flex items-center gap-2 text-archive-cyan text-xs font-mono mb-2">
            <TrendingUp size={15} />
            <span>{isAr ? 'صافي النمو' : 'Net Member Growth'}</span>
          </div>
          <div className="text-3xl font-display font-bold text-archive-cyan tracking-tight">
            +{(currentStats?.net ?? 0).toLocaleString()}
          </div>
          <div className="text-[11px] text-archive-cyan/80 font-mono mt-1">
            {isAr ? 'الزيادة الصافية في عدد المجتمع' : 'Positive Community Expansion'}
          </div>
        </div>

        {/* Join/Leave Ratio & Retention */}
        <div className="bg-archive-dark/50 rounded-2xl p-4 border border-amber-500/20 flex flex-col justify-between">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-mono mb-2">
            <Percent size={15} />
            <span>{isAr ? 'نسبة الانضمام للمغادرة' : 'Join / Leave Ratio'}</span>
          </div>
          <div className="text-3xl font-display font-bold text-amber-300 tracking-tight">
            {joinLeaveRatio}x
          </div>
          <div className="text-[11px] text-amber-400/80 font-mono mt-1">
            {isAr 
              ? `${joinLeaveRatio} انضمام مقابل كل مغادرة` 
              : `${joinLeaveRatio} joins per 1 departure`}
          </div>
        </div>
      </div>

      {/* Retention & Health Status Bar */}
      <div className="bg-archive-dark/40 rounded-2xl p-4 border border-archive-cyan/15 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono relative z-10">
        <div className="flex items-center gap-2.5 text-slate-300">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
            <ShieldCheck size={16} />
          </div>
          <div>
            <div className="text-[10px] text-slate-400">{isAr ? 'الاحتفاظ بالأعضاء (7 أيام)' : '7-Day Retention'}</div>
            <div className="text-white font-bold">{mg.retention7Day}% <span className="text-emerald-400 text-[11px]">({isAr ? 'ممتاز' : 'Excellent'})</span></div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 text-slate-300">
          <div className="w-8 h-8 rounded-xl bg-archive-cyan/10 border border-archive-cyan/20 flex items-center justify-center text-archive-cyan shrink-0">
            <Calendar size={16} />
          </div>
          <div>
            <div className="text-[10px] text-slate-400">{isAr ? 'الاحتفاظ بالأعضاء (30 يوماً)' : '30-Day Retention'}</div>
            <div className="text-white font-bold">{mg.retention30Day}%</div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 text-slate-300">
          <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
            <Clock size={16} />
          </div>
          <div>
            <div className="text-[10px] text-slate-400">{isAr ? 'أوقات ذروة الانضمام' : 'Peak Influx Window'}</div>
            <div className="text-amber-300 font-bold">14:00 - 18:00 UTC ({isAr ? 'الأربعاء' : 'Wednesdays'})</div>
          </div>
        </div>
      </div>

      {/* Dynamic Influx & Departures Graph */}
      <div className="bg-archive-dark/50 rounded-2xl p-4 sm:p-6 border border-archive-cyan/20 space-y-4 relative z-10 shadow-lg outline-none">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/60 pb-3">
          <div className="font-mono text-xs sm:text-sm font-semibold text-white">
            {chartTitle}
          </div>
          <span className="text-xs font-mono text-archive-cyan font-bold px-2.5 py-0.5 rounded-lg bg-archive-cyan/10 border border-archive-cyan/20 w-fit">
            {periodSubtitle}
          </span>
        </div>

        {/* Recharts Bar Chart (with outline-none and tabIndex=-1 to remove focus border) */}
        <div className="w-full h-60 sm:h-72 select-none pt-2 outline-none">
          <ResponsiveContainer width="100%" height="100%" className="outline-none">
            <BarChart
              data={trendData}
              margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
              className="outline-none"
              style={{ outline: 'none' }}
              tabIndex={-1}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#0a3a40" opacity={0.3} vertical={false} />
              <XAxis 
                dataKey="label" 
                stroke="#64748b" 
                fontSize={11} 
                fontFamily="monospace" 
                tickLine={false} 
              />
              <YAxis 
                stroke="#64748b" 
                fontSize={11} 
                fontFamily="monospace" 
                tickLine={false} 
                axisLine={false}
                allowDecimals={false}
              />
              <Tooltip
                cursor={{ fill: 'rgba(0, 240, 255, 0.06)' }}
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const d = payload[0].payload;
                    return (
                      <div className="bg-[#031317] border border-archive-cyan/40 p-3 rounded-xl shadow-xl font-mono text-xs space-y-1 outline-none">
                        <div className="text-white font-bold">{d.label}</div>
                        <div className="text-emerald-400 font-bold">+{d.joined} {isAr ? 'انضموا' : 'joined'}</div>
                        <div className="text-rose-400 font-bold">-{d.left} {isAr ? 'غادروا' : 'left'}</div>
                        <div className="text-archive-cyan font-extrabold border-t border-slate-800 pt-1">
                          {isAr ? 'الصافي' : 'Net'}: {d.net >= 0 ? `+${d.net}` : d.net}
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Legend 
                wrapperStyle={{ paddingTop: '10px', fontSize: '11px', fontFamily: 'monospace' }} 
              />
              <Bar 
                dataKey="joined" 
                name={isAr ? 'انضمام' : 'Joined'} 
                fill="#10b981" 
                radius={[4, 4, 0, 0]} 
              />
              <Bar 
                dataKey="left" 
                name={isAr ? 'مغادرة' : 'Left'} 
                fill="#f43f5e" 
                radius={[4, 4, 0, 0]} 
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
