import React from 'react';
import { motion } from 'motion/react';
import { Users, UserCheck, UserPlus, Zap } from 'lucide-react';
import { ServerAnalyticsData } from '../../types/analytics';
import { useLanguage } from '../../context/LanguageContext';

interface ServerStatsSummaryProps {
  data: ServerAnalyticsData;
  timeframe: 'today' | 'week' | 'month';
}

export const ServerStatsSummary: React.FC<ServerStatsSummaryProps> = ({ data, timeframe }) => {
  const { t, language } = useLanguage();
  const isAr = language === 'ar';
  const ov = data.overview;
  const mg = data.membersGrowth;

  const currentStats = timeframe === 'today'
    ? mg.today
    : timeframe === 'week'
    ? mg.week
    : mg.month;

  const joinedLabel = timeframe === 'today'
    ? (isAr ? 'الانضمام اليوم' : 'Joined Today')
    : timeframe === 'week'
    ? (isAr ? 'الانضمام هذا الأسبوع' : 'Joined This Week')
    : (isAr ? 'الانضمام هذا الشهر' : 'Joined This Month');

  const stats = [
    {
      id: 'stat-total-members',
      label: isAr ? 'إجمالي الأعضاء' : 'Total Members',
      value: (ov?.totalMembers ?? 0).toLocaleString(),
      subtext: isAr ? `${ov?.offlineMembers ?? 0} غير متصل • موثق` : `${ov?.offlineMembers ?? 0} offline • Verified`,
      icon: Users,
      color: 'text-archive-cyan',
      delay: 0
    },
    {
      id: 'stat-online-members',
      label: isAr ? 'المتصلون الآن' : 'Online Right Now',
      value: (ov?.onlineMembers ?? 0).toLocaleString(),
      subtext: isAr ? `${ov?.idleMembers ?? 0} بالخارج • ${ov?.dndMembers ?? 0} مشغول` : `${ov?.idleMembers ?? 0} idle • ${ov?.dndMembers ?? 0} dnd`,
      icon: UserCheck,
      color: 'text-emerald-400',
      delay: 0.1
    },
    {
      id: 'stat-joined-period',
      label: joinedLabel,
      value: `+${(currentStats?.joined ?? 0).toLocaleString()}`,
      subtext: isAr ? `${currentStats?.growthRate ?? '+0%'} معدل النمو` : `${currentStats?.growthRate ?? '+0%'} net influx`,
      icon: UserPlus,
      color: 'text-cyan-400',
      delay: 0.2
    },
    {
      id: 'stat-nitro-boosts',
      label: isAr ? 'مستوى النيترو' : 'Nitro Boost Level',
      value: isAr ? `المستوى ${ov.boostTier}` : `Tier ${ov.boostTier}`,
      subtext: isAr ? `${ov.boostCount} تعزيزات نشطة` : `${ov.boostCount} Nitro Boosts Active`,
      icon: Zap,
      color: 'text-amber-400',
      delay: 0.3
    }
  ];

  return (
    <div id="server-stats-summary" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, i) => (
        <motion.div
          key={stat.id}
          id={stat.id}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: stat.delay }}
          className="bg-archive-teal-light/20 backdrop-blur-xl border border-archive-cyan/10 rounded-2xl p-6 relative overflow-hidden group hover:border-archive-cyan/30 transition-all duration-300"
        >
          <div className="absolute top-0 end-0 -mt-4 -me-4 w-24 h-24 bg-gradient-to-br from-archive-cyan/5 to-transparent rounded-full blur-xl group-hover:bg-archive-cyan/10 transition-all duration-500" />
          
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-sans text-xs sm:text-sm font-medium text-archive-paper-muted uppercase tracking-wider">
              {stat.label}
            </h3>
            <div className="flex items-center gap-2">
              <div className={`p-2 rounded-lg bg-archive-dark/50 ${stat.color} border border-archive-cyan/5`}>
                <stat.icon size={18} />
              </div>
            </div>
          </div>
          
          <div className="font-display font-semibold text-3xl sm:text-4xl text-archive-paper tracking-tight drop-shadow-sm">
            {stat.value}
          </div>

          <div className="mt-2 text-xs font-mono text-slate-400">
            {stat.subtext}
          </div>
        </motion.div>
      ))}
    </div>
  );
};
