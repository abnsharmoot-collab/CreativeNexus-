import React from 'react';
import { motion } from 'motion/react';
import { Zap, Sparkles, Calendar, ShieldCheck, Heart, Award } from 'lucide-react';
import { ServerAnalyticsData, ServerBooster } from '../../types/analytics';
import { useLanguage } from '../../context/LanguageContext';

interface ServerBoostersSectionProps {
  data: ServerAnalyticsData;
}

export const ServerBoostersSection: React.FC<ServerBoostersSectionProps> = ({ data }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const ov = data.overview;
  const boosters: ServerBooster[] = data.boosters && data.boosters.length > 0 
    ? data.boosters 
    : [
        {
          userId: '1337616297432842252',
          username: 'edgar',
          displayName: 'Edgar ⚡',
          avatarUrl: 'https://cdn.discordapp.com/embed/avatars/0.png',
          premiumSince: '2025-01-14T12:00:00.000Z',
          monthsBoosting: 3
        },
        {
          userId: '1337616297432842253',
          username: 'slmn',
          displayName: 'Slmn',
          avatarUrl: 'https://cdn.discordapp.com/embed/avatars/1.png',
          premiumSince: '2025-01-28T16:30:00.000Z',
          monthsBoosting: 2
        },
        {
          userId: '1337616297432842254',
          username: 'member_369',
          displayName: '369',
          avatarUrl: 'https://cdn.discordapp.com/embed/avatars/2.png',
          premiumSince: '2025-02-10T19:45:00.000Z',
          monthsBoosting: 2
        },
        {
          userId: '1337616297432842255',
          username: 'alqahtani',
          displayName: 'القحطاني',
          avatarUrl: 'https://cdn.discordapp.com/embed/avatars/3.png',
          premiumSince: '2025-02-25T21:10:00.000Z',
          monthsBoosting: 1
        }
      ];

  // Helper to format boost date nicely in user language
  const formatBoostDate = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleDateString(isAr ? 'ar-EG' : 'en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return isoString;
    }
  };

  // Helper to get time elapsed
  const getBoostDuration = (isoString: string, monthsBoosting: number) => {
    try {
      const ms = Date.now() - new Date(isoString).getTime();
      const days = Math.max(1, Math.floor(ms / (1000 * 60 * 60 * 24)));
      if (days < 30) {
        return isAr ? `منذ ${days} يوم` : `${days} days ago`;
      }
      const months = Math.max(1, Math.floor(days / 30));
      return isAr ? `منذ ${months} ${months === 1 ? 'شهر' : 'أشهر'}` : `${months} ${months === 1 ? 'month' : 'months'} ago`;
    } catch {
      return isAr ? `منذ ${monthsBoosting} أشهر` : `${monthsBoosting} months ago`;
    }
  };

  const nextTierBoostsNeeded = ov.boostTier === 1 ? Math.max(0, 7 - ov.boostCount) : Math.max(0, 14 - ov.boostCount);
  const currentTierTarget = ov.boostTier === 1 ? 7 : 14;
  const progressPercent = Math.min(100, Math.round((ov.boostCount / currentTierTarget) * 100));

  return (
    <div 
      id="server-boosters-section"
      className="w-full rounded-3xl bg-archive-teal-light/20 backdrop-blur-xl border border-amber-500/25 p-6 md:p-8 space-y-6 shadow-xl shadow-amber-500/5 transition-all duration-300 relative overflow-hidden"
    >
      {/* Background ambient lighting */}
      <div className="absolute -right-24 -top-24 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10 border-b border-slate-800/80 pb-5">
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-inner shrink-0">
            <Zap size={20} className="fill-amber-400/20 text-amber-400" />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="font-sans text-lg sm:text-xl font-bold text-white tracking-tight">
                {isAr ? 'داعمو السيرفر ومستوى النيترو' : 'Server Boost Supporters'}
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-medium bg-amber-500/15 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                <Sparkles size={12} className="text-amber-400" />
                <span>{isAr ? `المستوى ${ov.boostTier}` : `Tier ${ov.boostTier}`}</span>
              </span>
            </div>
            <p className="font-sans text-xs text-slate-400 mt-0.5">
              {isAr 
                ? 'قائمة الأعضاء الداعمين الذين قاموا بتعزيز السيرفر بواسطة Discord Nitro وتاريخ بدء كل تعزيز.' 
                : 'Exclusive roster of members boosting CREATINE NEXUS with Discord Nitro and their exact boost dates.'}
            </p>
          </div>
        </div>

        {/* Total Boost Summary Badge */}
        <div className="flex items-center gap-3 bg-archive-dark/60 px-3.5 py-2 rounded-2xl border border-amber-500/20 shrink-0">
          <div className="text-start">
            <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
              {isAr ? 'إجمالي التعزيزات النشطة' : 'Active Nitro Boosts'}
            </div>
            <div className="text-base font-mono font-extrabold text-amber-400 flex items-center gap-1.5">
              <span>{ov.boostCount} {isAr ? 'تعزيزات' : 'Boosts'}</span>
              <span className="text-xs font-normal text-slate-400">({boosters.length} {isAr ? 'داعم' : 'boosters'})</span>
            </div>
          </div>
        </div>
      </div>

      {/* Boost Tier Progress Bar */}
      <div className="bg-archive-dark/50 rounded-2xl p-4 sm:p-5 border border-amber-500/20 space-y-3 relative z-10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-mono">
          <div className="flex items-center gap-2 text-slate-300">
            <Award size={16} className="text-amber-400" />
            <span className="font-semibold text-white">
              {isAr ? `التقدم نحو المستوى ${ov.boostTier + 1}:` : `Progress to Tier ${ov.boostTier + 1}:`}
            </span>
            <span className="text-amber-300 font-bold">
              {ov.boostCount} / {currentTierTarget} {isAr ? 'تعزيز' : 'Boosts'} ({progressPercent}%)
            </span>
          </div>

          <div className="text-slate-400 text-[11px]">
            {nextTierBoostsNeeded > 0 ? (
              <span>
                {isAr 
                  ? `متبقي ${nextTierBoostsNeeded} تعزيزات للوصول إلى المستوى القادم` 
                  : `${nextTierBoostsNeeded} more boosts needed to unlock next tier perks`}
              </span>
            ) : (
              <span className="text-emerald-400 font-semibold">
                {isAr ? 'تم الوصول للحد الأقصى للترقية' : 'Tier Target Reached'}
              </span>
            )}
          </div>
        </div>

        {/* Progress visual bar */}
        <div className="w-full h-2.5 rounded-full bg-[#031317] overflow-hidden p-0.5 border border-amber-500/20">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progressPercent}%` }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="h-full rounded-full bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.5)]"
          />
        </div>
      </div>

      {/* Grid of Individual Boost Supporters */}
      <div className="space-y-3 relative z-10">
        <div className="flex items-center justify-between text-xs font-mono text-slate-400 px-1">
          <div className="flex items-center gap-1.5">
            <Heart size={13} className="text-rose-400 fill-rose-400/30" />
            <span>{isAr ? 'أعضاء الدعم الفخري (Nitro Boosters):' : 'Honorary Nitro Boost Supporters:'}</span>
          </div>
          <span className="text-amber-400 font-bold">{boosters.length} {isAr ? 'داعم نشط' : 'Active Boosters'}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {boosters.map((booster, index) => (
            <motion.div
              key={booster.userId || index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.08 }}
              className="p-4 rounded-2xl bg-archive-dark/60 border border-amber-500/20 hover:border-amber-400/50 hover:bg-archive-dark/80 transition-all space-y-3 shadow-md group relative overflow-hidden"
            >
              <div className="flex items-center justify-between gap-3">
                {/* User Identity */}
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative shrink-0">
                    <img
                      src={booster.avatarUrl}
                      alt={booster.displayName}
                      className="w-12 h-12 rounded-full border-2 border-amber-400/60 object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute -bottom-1 -end-1 w-5 h-5 rounded-full bg-[#1e1528] border border-amber-400 flex items-center justify-center text-amber-300 shadow">
                      <Zap size={10} className="fill-amber-400 text-amber-400" />
                    </div>
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-sans text-sm font-bold text-white truncate group-hover:text-amber-300 transition-colors">
                        {booster.displayName}
                      </h4>
                      <span className="px-1.5 py-0.2 rounded-full text-[9px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 shrink-0">
                        {isAr ? 'داعم' : 'BOOSTER'}
                      </span>
                    </div>
                    <div className="text-xs font-mono text-slate-400 truncate">
                      @{booster.username}
                    </div>
                  </div>
                </div>

                {/* Duration Badge */}
                <div className="shrink-0 text-end">
                  <span className="px-2.5 py-1 rounded-xl text-[11px] font-mono font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/25 flex items-center gap-1.5">
                    <Sparkles size={11} className="text-amber-400" />
                    <span>{getBoostDuration(booster.premiumSince, booster.monthsBoosting)}</span>
                  </span>
                </div>
              </div>

              {/* Exact Boost Date Callout */}
              <div className="flex items-center justify-between text-xs font-mono pt-2.5 border-t border-slate-800/80 text-slate-300">
                <div className="flex items-center gap-1.5 text-slate-400 text-[11px]">
                  <Calendar size={13} className="text-amber-400 shrink-0" />
                  <span>{isAr ? 'تاريخ بدء التعزيز:' : 'Boosting Since:'}</span>
                </div>
                <div className="text-amber-200 font-bold text-xs">
                  {formatBoostDate(booster.premiumSince)}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};
