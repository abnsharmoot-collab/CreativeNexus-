import React from 'react';
import { motion } from 'motion/react';
import { Activity, UserPlus, Zap, Award, Shield, CheckCircle2 } from 'lucide-react';
import { ServerAnalyticsData } from '../../types/analytics';
import { useLanguage } from '../../context/LanguageContext';

interface RecentEventsSectionProps {
  data: ServerAnalyticsData;
}

export const RecentEventsSection: React.FC<RecentEventsSectionProps> = ({ data }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const events = data.recentLiveEvents;

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'JOIN':
        return <UserPlus size={15} className="text-emerald-400" />;
      case 'BOOST':
        return <Zap size={15} className="text-amber-400" />;
      case 'ROLE':
        return <Award size={15} className="text-cyan-400" />;
      case 'MOD':
        return <Shield size={15} className="text-rose-400" />;
      default:
        return <CheckCircle2 size={15} className="text-archive-cyan" />;
    }
  };

  const getEventBadgeClass = (type: string) => {
    switch (type) {
      case 'JOIN':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'BOOST':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      case 'ROLE':
        return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20';
      case 'MOD':
        return 'bg-rose-500/10 text-rose-400 border-rose-500/20';
      default:
        return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20';
    }
  };

  return (
    <div 
      id="recent-events-section"
      className="w-full rounded-3xl bg-archive-teal-light/20 backdrop-blur-xl border border-archive-cyan/20 p-6 md:p-8 space-y-5 shadow-xl shadow-archive-cyan/5 transition-all duration-300 relative overflow-hidden"
    >
      {/* Background ambient lighting */}
      <div className="absolute -right-24 -bottom-24 w-72 h-72 bg-archive-cyan/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between relative z-10 border-b border-slate-800/80 pb-5">
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-2xl bg-archive-cyan/15 border border-archive-cyan/30 flex items-center justify-center text-archive-cyan shadow-inner shrink-0">
            <Activity size={20} />
          </div>
          <div>
            <h2 className="font-sans text-lg sm:text-xl font-bold text-white tracking-tight">
              {isAr ? 'سجل أحداث السيرفر المباشرة' : 'Recent Server Events Stream'}
            </h2>
            <p className="font-sans text-xs text-slate-400 mt-0.5">
              {isAr 
                ? 'آخر عمليات الانضمام والأحداث المسجلة في سيرفر CREATINE NEXUS.' 
                : 'Latest member joins and server milestone events in CREATINE NEXUS.'}
            </p>
          </div>
        </div>

        <span className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>{isAr ? 'تحديث حي' : 'Live Stream'}</span>
        </span>
      </div>

      {/* Events List */}
      <div className="space-y-2.5 relative z-10">
        {events.map((ev, idx) => (
          <motion.div
            key={ev.id || idx}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: idx * 0.05 }}
            className="flex items-center justify-between gap-3 p-3.5 rounded-2xl bg-archive-dark/40 border border-archive-cyan/10 hover:border-archive-cyan/25 transition-all text-xs"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="p-2 rounded-xl bg-archive-dark border border-archive-cyan/10 shrink-0">
                {getEventIcon(ev.type)}
              </div>
              <span className="font-sans text-slate-200 truncate font-medium">
                {ev.message}
              </span>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono border ${getEventBadgeClass(ev.type)}`}>
                {ev.type}
              </span>
              <span className="text-[11px] font-mono text-slate-500">
                {ev.time}
              </span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
