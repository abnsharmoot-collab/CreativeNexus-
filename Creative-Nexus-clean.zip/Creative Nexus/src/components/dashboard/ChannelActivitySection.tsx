import React, { useState } from 'react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid,
  Cell
} from 'recharts';
import { 
  MessageSquare, 
  Hash, 
  BarChart3, 
  Clock, 
  Activity
} from 'lucide-react';
import { ServerAnalyticsData } from '../../types/analytics';
import { useLanguage } from '../../context/LanguageContext';

interface ChannelActivitySectionProps {
  data: ServerAnalyticsData;
  timeframe: 'today' | 'week' | 'month';
}

export const ChannelActivitySection: React.FC<ChannelActivitySectionProps> = ({ data, timeframe }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const msgs = data.messages;

  const [chartType, setChartType] = useState<'area' | 'bar'>('area');

  // Chart data source based on timeframe
  const chartData = React.useMemo(() => {
    if (timeframe === 'month') {
      return msgs.monthlyTrend.map(item => ({
        label: item.day,
        count: item.count,
        subtext: isAr ? 'أسبوع' : 'Week'
      }));
    }
    if (timeframe === 'week') {
      return msgs.weeklyTrend.map(item => ({
        label: item.day,
        count: item.count,
        subtext: isAr ? 'يوم' : 'Day'
      }));
    }
    // 'today' - 24 hours
    return msgs.hourlyToday.map(item => ({
      label: item.hour,
      count: item.count,
      subtext: 'UTC'
    }));
  }, [timeframe, msgs, isAr]);

  const totalPeriodMessages = React.useMemo(() => {
    if (timeframe === 'month') return msgs.thisMonth;
    if (timeframe === 'week') return msgs.thisWeek;
    return msgs.today;
  }, [timeframe, msgs]);

  const chartPeriodName = timeframe === 'today' 
    ? (isAr ? 'اليوم (24 ساعة)' : 'Today (24 Hours)')
    : timeframe === 'week' 
    ? (isAr ? 'الأسبوع (7 أيام)' : 'Week (7 Days)')
    : (isAr ? 'الشهر (4 أسابيع)' : 'Month (4 Weeks)');

  return (
    <div 
      id="channel-activity-section"
      className="w-full rounded-3xl bg-archive-teal-light/20 backdrop-blur-xl border border-archive-cyan/20 p-6 md:p-8 space-y-6 shadow-xl shadow-archive-cyan/5 transition-all duration-300 relative overflow-hidden outline-none"
    >
      {/* Background ambient lighting */}
      <div className="absolute -left-24 -bottom-24 w-72 h-72 bg-archive-teal/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10 border-b border-slate-800/80 pb-5">
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-2xl bg-archive-cyan/15 border border-archive-cyan/30 flex items-center justify-center text-archive-cyan shadow-inner shrink-0">
            <MessageSquare size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="font-sans text-lg sm:text-xl font-bold text-white tracking-tight">
                {isAr ? 'نشاط القنوات ومخطط التفاعل' : 'Active Server Channels & Traffic Graphs'}
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-medium bg-archive-cyan/15 text-archive-cyan border border-archive-cyan/30">
                {totalPeriodMessages.toLocaleString()} {isAr ? 'رسالة' : 'messages'}
              </span>
            </div>
            <p className="font-sans text-xs text-slate-400 mt-0.5">
              {isAr 
                ? 'مخطط بياني دقيق يرصد حركة الرسائل وسرعة التفاعل في السيرفر عبر الوقت.' 
                : 'Telemetry chart tracking message volume and traffic velocity across time.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400 bg-archive-dark/60 px-3 py-1.5 rounded-xl border border-archive-cyan/15">
            <Clock size={13} className="text-archive-cyan" />
            <span>{isAr ? `الذروة: ${msgs.peakHours}` : `Peak: ${msgs.peakHours}`}</span>
          </div>

          {/* Chart View Mode Switcher */}
          <div className="flex items-center bg-archive-dark/80 p-0.5 rounded-xl border border-archive-cyan/20">
            <button
              onClick={() => setChartType('area')}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono font-medium transition-all cursor-pointer flex items-center gap-1 ${
                chartType === 'area'
                  ? 'bg-archive-cyan text-[#020b0d] font-bold shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
              title={isAr ? 'منحنى بياني متصل' : 'Area Wave'}
            >
              <Activity size={13} />
              <span className="hidden sm:inline">{isAr ? 'موجة' : 'Wave'}</span>
            </button>
            <button
              onClick={() => setChartType('bar')}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono font-medium transition-all cursor-pointer flex items-center gap-1 ${
                chartType === 'bar'
                  ? 'bg-archive-cyan text-[#020b0d] font-bold shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
              title={isAr ? 'أعمدة بيانية' : 'Bars'}
            >
              <BarChart3 size={13} />
              <span className="hidden sm:inline">{isAr ? 'أعمدة' : 'Bars'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Graph Card */}
      <div className="bg-archive-dark/50 rounded-2xl p-4 sm:p-6 border border-archive-cyan/20 space-y-4 relative z-10 shadow-lg outline-none">
        <div className="flex items-center justify-between border-b border-slate-800/60 pb-3">
          <div className="text-xs font-mono text-slate-300 font-semibold flex items-center gap-2">
            <span>{isAr ? 'حجم الرسائل عبر الفترة:' : 'Message Traffic Volume:'}</span>
            <span className="text-archive-cyan font-bold">{chartPeriodName}</span>
          </div>
          <div className="text-xs font-mono text-slate-400">
            {isAr ? 'سرعة التفاعل:' : 'Velocity:'}{' '}
            <span className="text-white font-bold">{msgs.velocityPerMinute} {isAr ? 'رسالة/دقيقة' : 'msgs/min'}</span>
          </div>
        </div>

        {/* Recharts Canvas (No click outlines, completely clean) */}
        <div className="w-full h-64 sm:h-72 select-none pt-2 outline-none">
          <ResponsiveContainer width="100%" height="100%" className="outline-none">
            {chartType === 'area' ? (
              <AreaChart
                data={chartData}
                margin={{ top: 10, right: 10, left: -15, bottom: 0 }}
                className="outline-none"
                style={{ outline: 'none' }}
                tabIndex={-1}
              >
                <defs>
                  <linearGradient id="cyanTrafficGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00f0ff" stopOpacity={0.45} />
                    <stop offset="95%" stopColor="#00f0ff" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid 
                  strokeDasharray="3 3" 
                  stroke="#0a3a40" 
                  opacity={0.3} 
                  vertical={false} 
                />
                <XAxis 
                  dataKey="label" 
                  stroke="#64748b" 
                  fontSize={11}
                  fontFamily="monospace"
                  tickLine={false}
                  interval={timeframe === 'today' ? 2 : 0}
                />
                <YAxis 
                  stroke="#64748b" 
                  fontSize={11}
                  fontFamily="monospace"
                  tickLine={false}
                  axisLine={false}
                  allowDecimals={false}
                />
                <Tooltip
                  cursor={{ stroke: '#00f0ff', strokeWidth: 1.5, strokeDasharray: '4 4' }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const d = payload[0].payload;
                      const pct = totalPeriodMessages > 0 ? ((d.count / totalPeriodMessages) * 100).toFixed(1) : 0;
                      return (
                        <div className="bg-[#031317] border border-archive-cyan/40 p-3 rounded-xl shadow-xl font-mono text-xs space-y-1 outline-none">
                          <div className="text-white font-bold flex items-center justify-between gap-3">
                            <span>{d.label} {d.subtext ? `(${d.subtext})` : ''}</span>
                            <span className="text-emerald-400 font-semibold">{pct}%</span>
                          </div>
                          <div className="text-archive-cyan font-extrabold text-sm">
                            {d.count.toLocaleString()} {isAr ? 'رسالة' : 'messages'}
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="count" 
                  stroke="#00f0ff" 
                  strokeWidth={2.5}
                  fillOpacity={1} 
                  fill="url(#cyanTrafficGrad)"
                  activeDot={{ 
                    r: 5, 
                    fill: '#00f0ff', 
                    stroke: '#020b0d', 
                    strokeWidth: 2,
                    className: 'filter drop-shadow-[0_0_8px_#00f0ff]' 
                  }}
                />
              </AreaChart>
            ) : (
              <BarChart
                data={chartData}
                margin={{ top: 10, right: 10, left: -15, bottom: 0 }}
                className="outline-none"
                style={{ outline: 'none' }}
                tabIndex={-1}
              >
                <CartesianGrid 
                  strokeDasharray="3 3" 
                  stroke="#0a3a40" 
                  opacity={0.3} 
                  vertical={false} 
                />
                <XAxis 
                  dataKey="label" 
                  stroke="#64748b" 
                  fontSize={11}
                  fontFamily="monospace"
                  tickLine={false}
                  interval={timeframe === 'today' ? 2 : 0}
                />
                <YAxis 
                  stroke="#64748b" 
                  fontSize={11}
                  fontFamily="monospace"
                  tickLine={false}
                  axisLine={false}
                  allowDecimals={false}
                />
                <Tooltip
                  cursor={{ fill: 'rgba(0, 240, 255, 0.06)' }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const d = payload[0].payload;
                      const pct = totalPeriodMessages > 0 ? ((d.count / totalPeriodMessages) * 100).toFixed(1) : 0;
                      return (
                        <div className="bg-[#031317] border border-archive-cyan/40 p-3 rounded-xl shadow-xl font-mono text-xs space-y-1 outline-none">
                          <div className="text-white font-bold flex items-center justify-between gap-3">
                            <span>{d.label} {d.subtext ? `(${d.subtext})` : ''}</span>
                            <span className="text-emerald-400 font-semibold">{pct}%</span>
                          </div>
                          <div className="text-archive-cyan font-extrabold text-sm">
                            {d.count.toLocaleString()} {isAr ? 'رسالة' : 'messages'}
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar 
                  dataKey="count" 
                  radius={[4, 4, 0, 0]}
                  fill="#00f0ff"
                >
                  {chartData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill="rgba(0, 240, 255, 0.75)"
                      className="transition-all duration-200 hover:fill-cyan-300"
                    />
                  ))}
                </Bar>
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* Channel Activity Breakdown (Visual Horizontal Bars) */}
      <div className="space-y-3 relative z-10">
        <div className="flex items-center justify-between text-xs font-mono text-slate-400 px-1">
          <span>{isAr ? 'توزيع التفاعل على القنوات الرسمية:' : 'Channel Message Distribution Leaderboard:'}</span>
          <span className="text-archive-cyan">{msgs.channelLeaderboard.length} {isAr ? 'قنوات نشطة' : 'active channels'}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {msgs.channelLeaderboard.map((ch, idx) => (
            <div 
              key={ch.id || idx}
              className="p-3.5 rounded-2xl bg-archive-dark/40 border border-archive-cyan/10 hover:border-archive-cyan/30 hover:bg-archive-dark/60 transition-all space-y-2 group"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-mono text-sm text-white font-semibold truncate">
                  <Hash size={14} className="text-archive-cyan shrink-0 group-hover:scale-110 transition-transform" />
                  <span className="truncate group-hover:text-cyan-300 transition-colors">{ch.name}</span>
                </div>
                <span className="text-xs font-mono text-archive-cyan font-bold shrink-0 ms-2">
                  {ch.messages.toLocaleString()} ({ch.percentage}%)
                </span>
              </div>

              {/* Visual Progress Bar */}
              <div className="w-full h-2 rounded-full bg-[#061e23] overflow-hidden p-0.5 border border-archive-cyan/10">
                <div 
                  className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-archive-cyan transition-all duration-500"
                  style={{ width: `${ch.percentage}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
