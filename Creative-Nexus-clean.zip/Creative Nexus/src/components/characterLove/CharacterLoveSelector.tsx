import React from 'react';
import { motion } from 'motion/react';
import { Heart, Sparkles, Check } from 'lucide-react';
import { CharacterDefinition, UserCharacterProgress } from '../../types/characterLove';
import { useLanguage } from '../../context/LanguageContext';

interface CharacterLoveSelectorProps {
  characters: CharacterDefinition[];
  selectedId: string;
  onSelect: (id: string) => void;
  progressMap: Record<string, UserCharacterProgress>;
  isMesopotamian?: boolean;
}

export const CharacterLoveSelector: React.FC<CharacterLoveSelectorProps> = ({
  characters,
  selectedId,
  onSelect,
  progressMap,
  isMesopotamian = false
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-3 px-1">
        <h3 className="font-cairo font-bold text-sm text-slate-200 flex items-center gap-2">
          <Sparkles size={15} className="text-rose-400" />
          <span>{isAr ? 'اختر الشخصية للتفاعل والإهداء' : 'Select Companion to Interact'}</span>
        </h3>
        <span className="text-xs font-mono text-slate-400">
          {characters.length} {isAr ? 'شخصيات متاحة' : 'Available'}
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
        {characters.map(char => {
          const isSelected = char.id === selectedId;
          const progress = progressMap[char.id];
          const level = progress?.level || 1;

          return (
            <button
              key={char.id}
              type="button"
              onClick={() => onSelect(char.id)}
              className={`relative group rounded-2xl p-2.5 text-right transition-all cursor-pointer border overflow-hidden flex items-center gap-3 ${
                isSelected
                  ? isMesopotamian
                    ? 'bg-amber-950/70 border-amber-400 ring-2 ring-amber-500/30 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                    : 'bg-[#09262b] border-[#5eead4] ring-2 ring-[#5eead4]/30 shadow-[0_0_15px_rgba(94,234,212,0.25)]'
                  : 'bg-white/[0.03] border-white/10 hover:border-white/20 hover:bg-white/[0.06]'
              }`}
            >
              {/* Character Avatar Icon */}
              <div className="relative w-12 h-12 rounded-xl overflow-hidden bg-slate-900 border border-white/10 shrink-0 flex items-center justify-center">
                <img
                  src={char.avatarUrl}
                  alt={char.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                {isSelected && (
                  <div className="absolute inset-0 bg-rose-500/20 flex items-center justify-center">
                    <Check size={16} className="text-white drop-shadow-md" />
                  </div>
                )}
              </div>

              {/* Character Info */}
              <div className="min-w-0 flex-1">
                <h4 className="font-cairo font-bold text-xs text-white truncate group-hover:text-rose-300 transition-colors">
                  {isAr ? char.nameAr : char.name}
                </h4>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-md bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-0.5">
                    <Heart size={9} className="fill-rose-300" />
                    Lv.{level}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 truncate">
                    {(progress?.lovePoints || 0)} pts
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
