import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Coins, Heart, X, Package, Gift, Check } from 'lucide-react';
import { ClaimSpecialRewardResult } from '../../types/characterLove';
import { useLanguage } from '../../context/LanguageContext';
import { CardRarity } from '../../types/cards';

interface SpecialRewardCelebrationModalProps {
  data: ClaimSpecialRewardResult | null;
  onClose: () => void;
  companionName?: string;
  companionNameAr?: string;
  isMesopotamian?: boolean;
}

const RARITY_ACCENTS: Record<CardRarity, { border: string; bg: string; text: string; glow: string; nameEn: string; nameAr: string }> = {
  COMMON: {
    border: 'border-zinc-500/60',
    bg: 'from-zinc-900/90 to-black',
    text: 'text-zinc-300',
    glow: 'rgba(156, 163, 175, 0.3)',
    nameEn: 'Common',
    nameAr: 'شائعة'
  },
  UNCOMMON: {
    border: 'border-emerald-500/70',
    bg: 'from-emerald-950/90 to-black',
    text: 'text-emerald-400',
    glow: 'rgba(16, 185, 129, 0.4)',
    nameEn: 'Uncommon',
    nameAr: 'غير شائعة'
  },
  RARE: {
    border: 'border-cyan-500/70',
    bg: 'from-cyan-950/90 to-black',
    text: 'text-cyan-300',
    glow: 'rgba(6, 182, 212, 0.45)',
    nameEn: 'Rare',
    nameAr: 'نادرة'
  },
  EPIC: {
    border: 'border-purple-500/80',
    bg: 'from-purple-950/90 to-black',
    text: 'text-purple-300',
    glow: 'rgba(168, 85, 247, 0.55)',
    nameEn: 'Epic',
    nameAr: 'ملحمية'
  },
  LEGENDARY: {
    border: 'border-amber-400/90',
    bg: 'from-amber-950/90 to-black',
    text: 'text-amber-300',
    glow: 'rgba(245, 158, 11, 0.65)',
    nameEn: 'Legendary',
    nameAr: 'أسطورية'
  },
  HALLOWEEN_2026: {
    border: 'border-orange-500/90',
    bg: 'from-orange-950/90 to-black',
    text: 'text-orange-300',
    glow: 'rgba(249, 115, 22, 0.65)',
    nameEn: 'Halloween 2026',
    nameAr: 'هالوين 2026'
  }
};

export const SpecialRewardCelebrationModal: React.FC<SpecialRewardCelebrationModalProps> = ({
  data,
  onClose,
  companionName,
  companionNameAr,
  isMesopotamian = false
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  if (!data || !data.reward) return null;
  const reward = data.reward;
  const rarityTheme = RARITY_ACCENTS[reward.rarity || 'RARE'] || RARITY_ACCENTS.RARE;
  const isPackage = data.awardedType === 'PACKAGE';
  const rewardTitle = isAr ? reward.nameAr : reward.name;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/85 backdrop-blur-sm"
        />

        {/* Modal Window with Pixel-art aesthetic */}
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className={`relative w-full max-w-md rounded-3xl p-5 sm:p-6 overflow-hidden border-2 shadow-2xl z-10 ${
            rarityTheme.border
          } bg-gradient-to-b ${rarityTheme.bg}`}
          style={{ boxShadow: `0 0 35px ${rarityTheme.glow}` }}
        >
          {/* Subtle pixel corner details */}
          <div className="absolute top-2 left-2 w-2 h-2 bg-white/40" />
          <div className="absolute top-2 right-2 w-2 h-2 bg-white/40" />
          <div className="absolute bottom-2 left-2 w-2 h-2 bg-white/40" />
          <div className="absolute bottom-2 right-2 w-2 h-2 bg-white/40" />

          {/* Close Button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3.5 right-3.5 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>

          {/* Modal Header */}
          <div className="text-center space-y-1.5 pb-3 border-b border-white/10">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/10 border border-white/20 text-[10px] font-mono font-bold tracking-wider uppercase text-cyan-300">
              <Sparkles size={11} className="text-yellow-400 animate-spin" />
              <span>{isAr ? 'مكافأة الرفيقة الخاصة (كل 3 أيام)' : '3-Day Special Favor'}</span>
            </div>

            <h3 className="text-xl sm:text-2xl font-black font-cairo text-white">
              {rewardTitle}
            </h3>

            <p className="text-xs font-cairo text-slate-300">
              {isAr
                ? `هدية خاصة ومميزة قُدمت لك من ${companionNameAr || 'الرفيقة'}!`
                : `A special favor presented to you by ${companionName || 'your Companion'}!`}
            </p>
          </div>

          {/* Artwork & Reward Visual */}
          <div className="py-4 flex flex-col items-center text-center space-y-3">
            <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-2xl bg-black/60 border-2 border-white/20 p-2 flex items-center justify-center shadow-inner overflow-hidden">
              {reward.iconUrl ? (
                <img
                  src={reward.iconUrl}
                  alt={rewardTitle}
                  className="w-full h-full object-contain drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)]"
                />
              ) : isPackage ? (
                <Package size={56} className="text-cyan-400 animate-bounce" />
              ) : (
                <Gift size={56} className="text-amber-400 animate-bounce" />
              )}

              {/* Rarity Tag */}
              <div className="absolute top-1.5 right-1.5 px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-black/80 border border-white/30 text-white">
                {isAr ? rarityTheme.nameAr : rarityTheme.nameEn}
              </div>
            </div>

            {/* If Package was drawn with a card, display drawn card info */}
            {data.drawnCard && (
              <div className="p-2.5 rounded-xl bg-white/5 border border-cyan-400/30 text-xs font-cairo text-cyan-200 w-full flex items-center justify-between gap-2">
                <span className="flex items-center gap-1.5 truncate">
                  <Package size={14} className="text-cyan-400 shrink-0" />
                  <span className="truncate">
                    {isAr ? `بطاقة جديدة مضافة للخزينة: ${data.drawnCard.nameAr || data.drawnCard.name}` : `Card Vault: ${data.drawnCard.name}`}
                  </span>
                </span>
                <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-cyan-900/60 border border-cyan-400/40 text-cyan-300 shrink-0">
                  {data.drawnCard.rarity}
                </span>
              </div>
            )}

            {/* Bonus Metrics (Coins & Affection) */}
            <div className="flex items-center justify-center gap-3 pt-1">
              {data.coinsAwarded > 0 && (
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-300 font-mono text-xs font-bold shadow-xs">
                  <Coins size={14} className="text-yellow-400" />
                  <span>+{data.coinsAwarded} Coins</span>
                </div>
              )}

              {data.lovePointsAwarded > 0 && (
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/20 border border-rose-400/40 text-rose-300 font-mono text-xs font-bold shadow-xs">
                  <Heart size={14} className="text-rose-400 fill-rose-400" />
                  <span>+{data.lovePointsAwarded} Affection</span>
                </div>
              )}
            </div>
          </div>

          {/* Action Button */}
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 rounded-xl font-cairo font-bold text-xs sm:text-sm text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 hover:from-amber-300 hover:to-yellow-200 border border-amber-200 shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Check size={16} />
            <span>{isAr ? 'استلام ومتابعة' : 'Claim & Continue'}</span>
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
