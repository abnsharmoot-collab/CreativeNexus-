import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Sparkles, Star, Crown, X, Check, ArrowRight } from 'lucide-react';
import { GiveGiftResult, CharacterDefinition } from '../../types/characterLove';
import { useLanguage } from '../../context/LanguageContext';

interface CharacterLoveLevelUpModalProps {
  data: GiveGiftResult | null;
  character: CharacterDefinition | undefined;
  onClose: () => void;
  isMesopotamian?: boolean;
}

export const CharacterLoveLevelUpModal: React.FC<CharacterLoveLevelUpModalProps> = ({
  data,
  character,
  onClose,
  isMesopotamian = false
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  if (!data || !character) return null;

  const stage = data.currentStage;
  const quote = isAr ? (stage?.quoteAr || stage?.quote) : (stage?.quote || stage?.quoteAr);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/85 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.85, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.85, y: 20 }}
          transition={{ type: 'spring', stiffness: 280, damping: 22 }}
          className={`relative w-full max-w-md rounded-3xl border overflow-hidden p-6 text-center z-10 shadow-[0_20px_70px_rgba(0,0,0,0.9)] ${
            isMesopotamian
              ? 'bg-[#150d08] border-amber-500/50 text-amber-100 shadow-amber-500/20'
              : 'bg-[#04161a] border-[#5eead4]/40 text-[#eafffa] shadow-cyan-500/20'
          }`}
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 end-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X size={16} />
          </button>

          {/* Glowing Aura Ambient Orb */}
          <div className="absolute top-1/4 start-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full bg-rose-500/30 blur-[70px] pointer-events-none" />

          {/* Celebratory Icon */}
          <div className="mx-auto w-16 h-16 rounded-2xl bg-gradient-to-tr from-rose-500 to-amber-500 p-0.5 shadow-[0_0_25px_rgba(244,63,94,0.6)] flex items-center justify-center mb-4">
            <div className="w-full h-full rounded-2xl bg-black/50 backdrop-blur-md flex items-center justify-center">
              {data.newStageUnlocked ? (
                <Sparkles size={32} className="text-yellow-300 animate-spin" />
              ) : (
                <Heart size={32} className="text-rose-400 fill-rose-500 animate-pulse" />
              )}
            </div>
          </div>

          {/* Title */}
          <h3 className="font-cairo font-black text-2xl text-white mb-1">
            {data.newStageUnlocked
              ? (isAr ? 'مظهر جديد فائق تم فتحه!' : 'New Stage Appearance Unlocked!')
              : (isAr ? 'ارتقاء مستوى المحبة!' : 'Love Level Up!')}
          </h3>

          <p className="font-cairo text-xs text-rose-300 font-semibold mb-5">
            {isAr
              ? `ازدادت رابطتك مع ${character.nameAr} ووصلت إلى المستوى ${data.newLevel}`
              : `Your bond with ${character.name} reached Love Level ${data.newLevel}`}
          </p>

          {/* Character Stage Artwork Preview */}
          <div className="relative w-44 h-44 mx-auto rounded-2xl overflow-hidden bg-slate-900/60 border border-white/10 p-2 flex items-center justify-center mb-4 shadow-inner">
            <img
              src={stage?.imageUrl || character.avatarUrl}
              alt={character.name}
              className="max-w-full max-h-full object-contain filter drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)]"
            />
            <div className="absolute bottom-2 start-2 end-2 py-1 rounded-lg bg-black/75 backdrop-blur-md text-[10px] font-cairo font-bold text-amber-300 border border-amber-500/30">
              {isAr ? stage.nameAr : stage.name}
            </div>
          </div>

          {/* Quote Dialogue */}
          {quote && (
            <div className="p-3 rounded-xl bg-white/[0.04] border border-white/10 text-xs font-cairo italic text-slate-200 mb-5 leading-relaxed">
              "{quote}"
            </div>
          )}

          {/* Close Action */}
          <button
            type="button"
            onClick={onClose}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-500 via-pink-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-white font-cairo font-black text-sm shadow-lg shadow-rose-500/30 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Check size={16} />
            <span>{isAr ? 'متابعة المودة والمغامرة' : 'Continue'}</span>
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
