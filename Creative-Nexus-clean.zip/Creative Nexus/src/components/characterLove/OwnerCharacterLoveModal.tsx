import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Plus,
  Trash2,
  Upload,
  Crown,
  Heart,
  Sparkles,
  Sliders,
  Layers,
  Save,
  Check,
  RefreshCw,
  Gift,
  AlertCircle,
  Volume2,
  VolumeX,
  Eye,
  Play,
  Square,
  RotateCcw,
  Image as ImageIcon,
  Move,
  Palette,
  Music,
  Zap,
  Shuffle,
  Coins,
  Clock,
  Package,
  Percent
} from 'lucide-react';
import { useCharacterLove } from '../../context/CharacterLoveContext';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import {
  CharacterDefinition,
  CharacterStage,
  LoveItemDefinition,
  LoveLevelThreshold,
  CharacterImageGradientConfig,
  CharacterAudioConfig,
  CharacterClickTransformConfig,
  CharacterSoundClip,
  SpecialRewardDefinition,
  SpecialRewardsConfig,
  SpecialRewardType
} from '../../types/characterLove';
import { CardRarity } from '../../types/cards';
import {
  readFileAsDataUrl,
  preloadCharacterAudio,
  buildMaskImageStyle,
  playSoundUrl,
  stopCurrentAudio,
  playRandomCharacterSound,
  preloadImages
} from '../../utils/characterImageEffects';

const PACK_OPTIONS: { id: CardRarity; nameEn: string; nameAr: string }[] = [
  { id: 'COMMON', nameEn: 'Genesis Apex Core [COMMON]', nameAr: 'حزمة جينيسيس أبيكس [شائعة]' },
  { id: 'UNCOMMON', nameEn: 'Prism Emerald Drive [UNCOMMON]', nameAr: 'حزمة بريزم إميرالد [غير شائعة]' },
  { id: 'RARE', nameEn: 'Quantum Azure Vault [RARE]', nameAr: 'خزانة كوانتوم الزرقاء [نادرة]' },
  { id: 'EPIC', nameEn: 'Hyperion Amethyst Nexus [EPIC]', nameAr: 'مركز هايبريون البنفسجي [ملحمي]' },
  { id: 'LEGENDARY', nameEn: 'Sovereign Solar Eclipse [LEGENDARY]', nameAr: 'كسوف الشمس السيادي [أسطوري]' }
];

const DEFAULT_GRADIENT: CharacterImageGradientConfig = {
  enabled: false,
  direction: 'to-bottom',
  angle: 180,
  startPercent: 60,
  endPercent: 100,
  opacity: 1,
  fadeIntensity: 100
};

const DEFAULT_AUDIO: CharacterAudioConfig = {
  enabled: false,
  audioUrl: '',
  audioName: '',
  volume: 80,
  sounds: []
};

const DEFAULT_CLICK_TRANSFORM: CharacterClickTransformConfig = {
  enabled: false,
  imageUrl: '',
  mode: 'timed',
  durationMs: 1200
};

export const OwnerCharacterLoveModal: React.FC = () => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { user } = useAuth();
  const {
    characters,
    items,
    thresholds,
    userProgress,
    specialRewardsConfig,
    isOwnerModalOpen,
    ownerInitialTab,
    closeOwnerModal,
    ownerSaveCharacter,
    ownerDeleteCharacter,
    ownerSaveItem,
    ownerDeleteItem,
    ownerManualAdjust,
    ownerSaveThresholds,
    ownerSaveSpecialRewardsConfig,
    ownerResetSpecialRewardCooldown,
    ownerUpdateStageCoins,
    refreshAll
  } = useCharacterLove();

  const [activeTab, setActiveTab] = useState<'characters' | 'rewards' | 'items' | 'adjust' | 'thresholds'>(
    (ownerInitialTab as any) === 'rewards' ? 'rewards' : (ownerInitialTab || 'characters')
  );

  // Rewards Tab State
  const [editingRewards, setEditingRewards] = useState<SpecialRewardDefinition[]>([]);
  const [editingCycleHours, setEditingCycleHours] = useState<number>(72);
  const [selectedPackageToAdd, setSelectedPackageToAdd] = useState<CardRarity>('RARE');
  const [selectedItemToAdd, setSelectedItemToAdd] = useState<string>(items[0]?.id || '');
  const [stageCoinEdits, setStageCoinEdits] = useState<Record<string, Record<number, number>>>({});
  const [isResettingCooldown, setIsResettingCooldown] = useState<boolean>(false);

  // Sync special rewards config
  useEffect(() => {
    if (specialRewardsConfig) {
      setEditingRewards(specialRewardsConfig.rewards || []);
      setEditingCycleHours(specialRewardsConfig.cycleHours || 72);
    }
  }, [specialRewardsConfig]);

  // Reset editing states when modal is closed
  useEffect(() => {
    if (!isOwnerModalOpen) {
      setEditingCharacter(null);
      setEditingItem(null);
    }
  }, [isOwnerModalOpen]);

  // Sync stage coins
  useEffect(() => {
    const map: Record<string, Record<number, number>> = {};
    characters.forEach(c => {
      map[c.id] = {};
      (c.stages || []).forEach(st => {
        map[c.id][st.stageNumber] = typeof st.passiveCoinReward === 'number'
          ? st.passiveCoinReward
          : (st.stageNumber * 50);
      });
    });
    setStageCoinEdits(map);
  }, [characters]);

  // Character Form State
  const [editingCharacter, setEditingCharacter] = useState<Partial<CharacterDefinition> | null>(null);
  const [charSubTab, setCharSubTab] = useState<'stages' | 'position' | 'gradient' | 'audio' | 'transform' | 'preview'>('stages');

  // Preview interactive state inside modal
  const [previewTransformed, setPreviewTransformed] = useState<boolean>(false);
  const previewTimerRef = useRef<any>(null);
  const previewLastSoundIdRef = useRef<string | null>(null);
  const [playingClipId, setPlayingClipId] = useState<string | null>(null);

  // Item Form State
  const [editingItem, setEditingItem] = useState<Partial<LoveItemDefinition> | null>(null);

  // Manual Adjust State
  const [adjustTargetCharId, setAdjustTargetCharId] = useState<string>(characters[0]?.id || '');
  const [adjustLovePoints, setAdjustLovePoints] = useState<number>(100);
  const [adjustLevel, setAdjustLevel] = useState<number>(2);

  // Thresholds State
  const [editingThresholds, setEditingThresholds] = useState<LoveLevelThreshold[]>([...thresholds]);

  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // File input refs
  const defaultImageInputRef = useRef<HTMLInputElement>(null);
  const clickImageInputRef = useRef<HTMLInputElement>(null);
  const multiAudioInputRef = useRef<HTMLInputElement>(null);
  const replaceAudioInputRef = useRef<HTMLInputElement>(null);
  const [replaceTargetClipId, setReplaceTargetClipId] = useState<string | null>(null);
  const itemFileInputRef = useRef<HTMLInputElement>(null);
  const stageFileInputRef = useRef<HTMLInputElement>(null);
  const [stageUploadTargetIdx, setStageUploadTargetIdx] = useState<number | null>(null);

  // Preload preview images
  useEffect(() => {
    if (editingCharacter) {
      const normalImg = editingCharacter.stages?.[0]?.imageUrl || editingCharacter.avatarUrl;
      const altImg = editingCharacter.clickTransform?.imageUrl;
      preloadImages([normalImg, altImg]);
    }
  }, [editingCharacter?.avatarUrl, editingCharacter?.stages, editingCharacter?.clickTransform?.imageUrl]);

  // ----------------------------------------------------
  // REWARDS TAB HANDLERS (12H COINS & 3D SPECIAL REWARDS)
  // ----------------------------------------------------
  const handleSaveSpecialRewardsPool = async () => {
    setIsSaving(true);
    setStatusMessage(null);
    try {
      const res = await ownerSaveSpecialRewardsConfig({
        cycleHours: editingCycleHours,
        rewards: editingRewards
      });
      if (!res.success) throw new Error(res.error || 'Failed to save special rewards');
      setStatusMessage({
        text: isAr ? 'تم حفظ إعدادات المكافآت الخاصة ونسب السحب بنجاح' : 'Special rewards pool and probabilities saved successfully',
        type: 'success'
      });
    } catch (err: any) {
      setStatusMessage({ text: err?.message || 'Error saving rewards', type: 'error' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleAddPackageReward = () => {
    const pack = PACK_OPTIONS.find(p => p.id === selectedPackageToAdd) || PACK_OPTIONS[0];
    const newReward: SpecialRewardDefinition = {
      id: `spec_pack_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: 'PACKAGE',
      name: pack.nameEn,
      nameAr: pack.nameAr,
      rarity: pack.id,
      packageId: pack.id,
      dropWeight: pack.id === 'LEGENDARY' ? 5 : pack.id === 'EPIC' ? 10 : pack.id === 'RARE' ? 20 : 30,
      bonusCoins: pack.id === 'LEGENDARY' ? 500 : pack.id === 'EPIC' ? 200 : pack.id === 'RARE' ? 100 : 50,
      isActive: true
    };
    setEditingRewards(prev => [...prev, newReward]);
    setStatusMessage({
      text: isAr ? `تمت إضافة حزمة "${pack.nameAr}" إلى مكافآت السحب` : `Added "${pack.nameEn}" to rewards pool`,
      type: 'success'
    });
  };

  const handleAddItemReward = () => {
    const item = items.find(i => i.id === selectedItemToAdd) || items[0];
    if (!item) return;
    const newReward: SpecialRewardDefinition = {
      id: `spec_item_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: 'ITEM',
      name: item.name,
      nameAr: item.nameAr,
      rarity: item.rarity,
      itemId: item.id,
      dropWeight: 20,
      bonusCoins: 50,
      bonusLovePoints: item.lovePoints || 25,
      iconUrl: item.imageUrl,
      isActive: true
    };
    setEditingRewards(prev => [...prev, newReward]);
    setStatusMessage({
      text: isAr ? `تمت إضافة هدية "${item.nameAr}" إلى مكافآت السحب` : `Added "${item.name}" to rewards pool`,
      type: 'success'
    });
  };

  const handleToggleRewardActive = (id: string) => {
    setEditingRewards(prev => prev.map(r => r.id === id ? { ...r, isActive: !r.isActive } : r));
  };

  const handleDeleteReward = (id: string) => {
    setEditingRewards(prev => prev.filter(r => r.id !== id));
  };

  const handleUpdateRewardField = (id: string, updates: Partial<SpecialRewardDefinition>) => {
    setEditingRewards(prev => prev.map(r => r.id === id ? { ...r, ...updates } : r));
  };

  const handleResetMyCooldown = async () => {
    setIsResettingCooldown(true);
    setStatusMessage(null);
    try {
      const targetChar = characters[0]?.id;
      if (!targetChar) return;
      await ownerResetSpecialRewardCooldown(user?.discordId || 'guest_user', targetChar);
      await refreshAll();
      setStatusMessage({
        text: isAr ? 'تم تصفير مؤقت الـ 3 أيام لحسابك! يمكنك الآن تجربة زر الاستلام في الصفحة.' : '3-Day reward timer reset for your account! You can now test the claim button on the page.',
        type: 'success'
      });
    } catch (err: any) {
      setStatusMessage({ text: err?.message || 'Error resetting cooldown', type: 'error' });
    } finally {
      setIsResettingCooldown(false);
    }
  };

  const handleSaveStageCoins = async (charId: string, stageNum: number) => {
    const coins = stageCoinEdits[charId]?.[stageNum] ?? 50;
    try {
      const res = await ownerUpdateStageCoins(charId, stageNum, coins);
      if (!res.success) throw new Error(res.error || 'Failed to update coins');
      setStatusMessage({
        text: isAr ? `تم تحديث عملات المرحلة ${stageNum} إلى ${coins} عملة` : `Stage ${stageNum} passive reward updated to ${coins} coins`,
        type: 'success'
      });
    } catch (err: any) {
      setStatusMessage({ text: err?.message || 'Error updating stage coins', type: 'error' });
    }
  };

  // ----------------------------------------------------
  // CHARACTER FORM HANDLERS
  // ----------------------------------------------------
  const handleStartNewCharacter = () => {
    const id = `char_custom_${Date.now()}`;
    setEditingCharacter({
      id,
      name: '',
      nameAr: '',
      title: '',
      titleAr: '',
      description: '',
      descriptionAr: '',
      avatarUrl: '',
      themeColor: '#f43f5e',
      order: characters.length + 1,
      isActive: true,
      scale: 1.0,
      offsetX: 0,
      offsetY: 0,
      imageWidth: 'auto',
      imageHeight: 'auto',
      cardHeight: 480,
      cardWidth: 460,
      layering: 'popout_overflow',
      overflowMode: 'visible',
      zIndex: 20,
      gradientFade: { ...DEFAULT_GRADIENT },
      audioConfig: { ...DEFAULT_AUDIO },
      clickTransform: { ...DEFAULT_CLICK_TRANSFORM },
      stages: [
        {
          id: `stage_1_${Date.now()}`,
          stageNumber: 1,
          name: 'Stage 1: Beginning',
          nameAr: 'المرحلة 1: البداية',
          requiredLevel: 1,
          requiredPoints: 0,
          imageUrl: '',
          quote: '',
          quoteAr: ''
        }
      ]
    });
    setCharSubTab('stages');
  };

  const handleEditCharacter = (char: CharacterDefinition) => {
    setEditingCharacter({
      ...char,
      scale: char.scale ?? 1.0,
      offsetX: char.offsetX ?? 0,
      offsetY: char.offsetY ?? 0,
      imageWidth: char.imageWidth ?? 'auto',
      imageHeight: char.imageHeight ?? 'auto',
      cardHeight: char.cardHeight ?? 480,
      cardWidth: char.cardWidth ?? 460,
      layering: char.layering ?? 'popout_overflow',
      overflowMode: char.overflowMode ?? 'visible',
      zIndex: char.zIndex ?? 20,
      gradientFade: char.gradientFade ? { ...char.gradientFade } : { ...DEFAULT_GRADIENT },
      audioConfig: char.audioConfig ? {
        ...char.audioConfig,
        sounds: Array.isArray(char.audioConfig.sounds) ? [...char.audioConfig.sounds] : []
      } : { ...DEFAULT_AUDIO },
      clickTransform: char.clickTransform ? { ...char.clickTransform } : { ...DEFAULT_CLICK_TRANSFORM }
    });
    setCharSubTab('stages');
  };

  const handleResetCharacterDefaults = () => {
    if (!editingCharacter) return;
    setEditingCharacter(prev => ({
      ...prev,
      scale: 1.0,
      offsetX: 0,
      offsetY: 0,
      imageWidth: 'auto',
      imageHeight: 'auto',
      cardHeight: 480,
      cardWidth: 460,
      layering: 'popout_overflow',
      overflowMode: 'visible',
      zIndex: 20,
      gradientFade: { ...DEFAULT_GRADIENT },
      audioConfig: { ...DEFAULT_AUDIO },
      clickTransform: { ...DEFAULT_CLICK_TRANSFORM }
    }));
    setStatusMessage({
      text: isAr ? 'تمت استعادة الإعدادات الافتراضية' : 'Reset to default settings',
      type: 'success'
    });
  };

  const handleAutoAdaptCardDimensions = () => {
    if (!editingCharacter) return;
    const scale = editingCharacter.scale ?? 1.0;
    const offsetY = editingCharacter.offsetY ?? 0;
    const idealHeight = Math.round(480 * Math.max(0.85, Math.min(1.4, scale)) + (offsetY > 0 ? offsetY * 0.4 : 0));
    const idealWidth = Math.round(460 * Math.max(0.9, Math.min(1.3, scale)));
    setEditingCharacter(prev => ({
      ...prev,
      cardHeight: idealHeight,
      cardWidth: idealWidth
    }));
    setStatusMessage({
      text: isAr ? `تمت ملاءمة أبعاد البطاقة تلقائياً (${idealWidth}px × ${idealHeight}px)` : `Card auto-adapted to image (${idealWidth}px × ${idealHeight}px)`,
      type: 'success'
    });
  };

  // Image Uploads
  const handleDefaultImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await readFileAsDataUrl(file);
      setEditingCharacter(prev => ({
        ...prev,
        avatarUrl: dataUrl,
        stages: prev?.stages?.map((st, i) => i === 0 && !st.imageUrl ? { ...st, imageUrl: dataUrl } : st)
      }));
      setStatusMessage({ text: isAr ? 'تم تحميل صورة PNG الأساسية' : 'Default PNG uploaded', type: 'success' });
    } catch {
      setStatusMessage({ text: isAr ? 'فشل تحميل الصورة' : 'Failed to load image', type: 'error' });
    }
  };

  const handleClickImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await readFileAsDataUrl(file);
      setEditingCharacter(prev => ({
        ...prev,
        clickTransform: {
          enabled: true,
          imageUrl: dataUrl,
          mode: prev?.clickTransform?.mode || 'timed',
          durationMs: prev?.clickTransform?.durationMs || 1200
        }
      }));
      setStatusMessage({ text: isAr ? 'تم تحميل صورة التحول عند النقر' : 'Click transformation PNG uploaded', type: 'success' });
    } catch {
      setStatusMessage({ text: isAr ? 'فشل تحميل الصورة' : 'Failed to load click image', type: 'error' });
    }
  };

  // Multi-Audio upload handler
  const handleMultiAudioUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    try {
      const newClips: CharacterSoundClip[] = [];
      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        const dataUrl = await readFileAsDataUrl(f);
        newClips.push({
          id: `sound_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          name: f.name.replace(/\.[^/.]+$/, ''),
          url: dataUrl,
          volume: editingCharacter?.audioConfig?.volume ?? 80
        });
      }

      setEditingCharacter(prev => {
        const curAudio = prev?.audioConfig || { ...DEFAULT_AUDIO };
        const existingSounds = Array.isArray(curAudio.sounds) ? curAudio.sounds : [];
        return {
          ...prev,
          audioConfig: {
            ...curAudio,
            enabled: true,
            sounds: [...existingSounds, ...newClips]
          }
        };
      });

      setStatusMessage({
        text: isAr ? `تمت إضافة ${newClips.length} مقطع صوتي إلى المجموعة بنجاح` : `Added ${newClips.length} audio file(s) to collection`,
        type: 'success'
      });
    } catch {
      setStatusMessage({ text: isAr ? 'فشل تحميل الملفات الصوتية' : 'Failed to load audio files', type: 'error' });
    } finally {
      if (e.target) e.target.value = '';
    }
  };

  // Replace single audio clip handler
  const handleReplaceAudioClip = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !replaceTargetClipId) return;

    try {
      const dataUrl = await readFileAsDataUrl(file);
      setEditingCharacter(prev => {
        if (!prev?.audioConfig) return prev;
        const sounds = (prev.audioConfig.sounds || []).map(s => {
          if (s.id === replaceTargetClipId) {
            return {
              ...s,
              name: file.name.replace(/\.[^/.]+$/, ''),
              url: dataUrl
            };
          }
          return s;
        });
        return {
          ...prev,
          audioConfig: {
            ...prev.audioConfig,
            sounds
          }
        };
      });
      setStatusMessage({ text: isAr ? 'تم استبدال المقطع الصوتي' : 'Audio clip replaced', type: 'success' });
    } catch {
      setStatusMessage({ text: isAr ? 'فشل استبدال المقطع' : 'Failed to replace audio clip', type: 'error' });
    } finally {
      setReplaceTargetClipId(null);
      if (e.target) e.target.value = '';
    }
  };

  const handleRemoveAudioClip = (clipId: string) => {
    setEditingCharacter(prev => {
      if (!prev?.audioConfig) return prev;
      const sounds = (prev.audioConfig.sounds || []).filter(s => s.id !== clipId);
      return {
        ...prev,
        audioConfig: {
          ...prev.audioConfig,
          sounds
        }
      };
    });
  };

  const handleUpdateClipVolume = (clipId: string, volume: number) => {
    setEditingCharacter(prev => {
      if (!prev?.audioConfig) return prev;
      const sounds = (prev.audioConfig.sounds || []).map(s => {
        if (s.id === clipId) {
          return { ...s, volume };
        }
        return s;
      });
      return {
        ...prev,
        audioConfig: {
          ...prev.audioConfig,
          sounds
        }
      };
    });
  };

  const handleUpdateClipName = (clipId: string, name: string) => {
    setEditingCharacter(prev => {
      if (!prev?.audioConfig) return prev;
      const sounds = (prev.audioConfig.sounds || []).map(s => {
        if (s.id === clipId) {
          return { ...s, name };
        }
        return s;
      });
      return {
        ...prev,
        audioConfig: {
          ...prev.audioConfig,
          sounds
        }
      };
    });
  };

  const handleTestClipPlayback = (clip: CharacterSoundClip) => {
    if (playingClipId === clip.id) {
      stopCurrentAudio();
      setPlayingClipId(null);
    } else {
      stopCurrentAudio();
      setPlayingClipId(clip.id);
      playSoundUrl(clip.url, clip.volume ?? (editingCharacter?.audioConfig?.volume ?? 80));
    }
  };

  // Stage PNG Upload
  const handleStageFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || stageUploadTargetIdx === null) return;
    try {
      const dataUrl = await readFileAsDataUrl(file);
      setEditingCharacter(prev => {
        if (!prev) return prev;
        const stages = [...(prev.stages || [])];
        if (stages[stageUploadTargetIdx]) {
          stages[stageUploadTargetIdx] = { ...stages[stageUploadTargetIdx], imageUrl: dataUrl };
        }
        return { ...prev, stages };
      });
      setStatusMessage({
        text: isAr ? `تم تحديث صورة المرحلة ${stageUploadTargetIdx + 1}` : `Stage ${stageUploadTargetIdx + 1} PNG uploaded`,
        type: 'success'
      });
    } catch {
      setStatusMessage({ text: isAr ? 'فشل تحميل صورة المرحلة' : 'Failed to load stage image', type: 'error' });
    } finally {
      setStageUploadTargetIdx(null);
    }
  };

  const handleAddStage = () => {
    if (!editingCharacter) return;
    const currentStages = editingCharacter.stages || [];
    const nextNum = currentStages.length + 1;
    const nextReqLevel = nextNum * 2 - 1;
    const nextReqPoints = (nextNum - 1) * 300;
    const newStage: CharacterStage = {
      id: `stage_${nextNum}_${Date.now()}`,
      stageNumber: nextNum,
      name: `Stage ${nextNum}: Awakening`,
      nameAr: `المرحلة ${nextNum}: ارتقاء`,
      requiredLevel: nextReqLevel,
      requiredPoints: nextReqPoints,
      imageUrl: editingCharacter.avatarUrl || '',
      quote: '',
      quoteAr: ''
    };
    setEditingCharacter({ ...editingCharacter, stages: [...currentStages, newStage] });
  };

  const handleRemoveStage = (index: number) => {
    if (!editingCharacter || (editingCharacter.stages?.length || 0) <= 1) return;
    const updated = (editingCharacter.stages || []).filter((_, i) => i !== index);
    setEditingCharacter({ ...editingCharacter, stages: updated });
  };

  const handleSaveCharacterSubmit = async () => {
    if (!editingCharacter?.name || !editingCharacter?.nameAr) {
      setStatusMessage({ text: isAr ? 'يرجى إدخال اسم الشخصية بالعربية والإنجليزية' : 'Name is required in both English & Arabic', type: 'error' });
      return;
    }
    setIsSaving(true);
    setStatusMessage(null);
    const res = await ownerSaveCharacter(editingCharacter);
    setIsSaving(false);
    if (res.success) {
      setStatusMessage({ text: isAr ? 'تم حفظ الشخصية وجميع إعداداتها بنجاح!' : 'Character and all settings saved successfully!', type: 'success' });
      setEditingCharacter(null);
      refreshAll();
    } else {
      setStatusMessage({ text: res.error || 'Failed to save', type: 'error' });
    }
  };

  // ----------------------------------------------------
  // ITEM & ADJUST & THRESHOLDS HANDLERS
  // ----------------------------------------------------
  const handleStartNewItem = () => {
    setEditingItem({
      id: `item_custom_${Date.now()}`,
      name: '',
      nameAr: '',
      description: '',
      descriptionAr: '',
      imageUrl: '',
      rarity: 'RARE',
      targetCharacterId: 'ANY',
      lovePoints: 50,
      packages: ['COMMON', 'UNCOMMON', 'RARE', 'EPIC', 'LEGENDARY'],
      dropWeight: 25
    });
  };

  const handleItemFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await readFileAsDataUrl(file);
      setEditingItem(prev => ({ ...prev, imageUrl: dataUrl }));
    } catch {
      setStatusMessage({ text: isAr ? 'فشل تحميل الصورة' : 'Failed to load image', type: 'error' });
    }
  };

  const handleSaveItemSubmit = async () => {
    if (!editingItem?.name || !editingItem?.nameAr) {
      setStatusMessage({ text: isAr ? 'يرجى إدخال اسم الهدية بالعربية والإنجليزية' : 'Item name is required', type: 'error' });
      return;
    }
    setIsSaving(true);
    setStatusMessage(null);
    const res = await ownerSaveItem(editingItem);
    setIsSaving(false);
    if (res.success) {
      setStatusMessage({ text: isAr ? 'تم حفظ الهدية بنجاح!' : 'Gift item saved successfully!', type: 'success' });
      setEditingItem(null);
      refreshAll();
    } else {
      setStatusMessage({ text: res.error || 'Failed to save item', type: 'error' });
    }
  };

  const handleApplyManualAdjust = async () => {
    if (!adjustTargetCharId) return;
    setIsSaving(true);
    setStatusMessage(null);
    const targetUid = user?.discordId || 'guest_user';
    const res = await ownerManualAdjust(targetUid, adjustTargetCharId, {
      level: adjustLevel,
      lovePoints: adjustLovePoints
    });
    setIsSaving(false);
    if (res.success) {
      setStatusMessage({
        text: isAr ? `تم تحديث الشخصية إلى المستوى ${adjustLevel} (${adjustLovePoints} نقطة محبة)` : `Adjusted character to Level ${adjustLevel} (${adjustLovePoints} pts)`,
        type: 'success'
      });
      refreshAll();
    } else {
      setStatusMessage({ text: res.error || 'Adjustment failed', type: 'error' });
    }
  };

  const handleSaveThresholdsSubmit = async () => {
    setIsSaving(true);
    setStatusMessage(null);
    const res = await ownerSaveThresholds(editingThresholds);
    setIsSaving(false);
    if (res.success) {
      setStatusMessage({ text: isAr ? 'تم حفظ مستويات ونقاط المحبة بنجاح!' : 'Thresholds saved successfully!', type: 'success' });
      refreshAll();
    } else {
      setStatusMessage({ text: res.error || 'Failed to save thresholds', type: 'error' });
    }
  };

  // Preview interactive click: random non-overlapping sound + 100ms instant image crossfade
  const handlePreviewCardClick = () => {
    // 1. Play random audio from sound collection (non-overlapping)
    if (editingCharacter?.audioConfig?.enabled) {
      const res = playRandomCharacterSound(editingCharacter.audioConfig, previewLastSoundIdRef.current);
      if (res.playedId) {
        previewLastSoundIdRef.current = res.playedId;
      }
    }

    // 2. Instant Image Crossfade (80-120ms)
    if (editingCharacter?.clickTransform?.enabled && editingCharacter?.clickTransform?.imageUrl) {
      const mode = editingCharacter.clickTransform.mode || 'timed';
      if (mode === 'toggle') {
        setPreviewTransformed(prev => !prev);
      } else {
        setPreviewTransformed(true);
        if (previewTimerRef.current) clearTimeout(previewTimerRef.current);
        const duration = editingCharacter.clickTransform.durationMs || 1200;
        previewTimerRef.current = setTimeout(() => {
          setPreviewTransformed(false);
          previewTimerRef.current = null;
        }, duration);
      }
    }
  };

  const previewNormalImg = editingCharacter?.stages?.[0]?.imageUrl || editingCharacter?.avatarUrl || '';
  const previewAltImg = editingCharacter?.clickTransform?.enabled && editingCharacter?.clickTransform?.imageUrl
    ? editingCharacter.clickTransform.imageUrl
    : null;
  const previewMaskStyle = buildMaskImageStyle(editingCharacter?.gradientFade);
  const previewHeight = editingCharacter?.cardHeight || 480;
  const previewMaxWidth = editingCharacter?.cardWidth || 460;
  const soundClipsCount = editingCharacter?.audioConfig?.sounds?.length || 0;

  if (!isOwnerModalOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
        {/* Hidden File Inputs */}
        <input
          ref={defaultImageInputRef}
          type="file"
          accept="image/png,image/*"
          onChange={handleDefaultImageUpload}
          className="hidden"
        />
        <input
          ref={clickImageInputRef}
          type="file"
          accept="image/png,image/*"
          onChange={handleClickImageUpload}
          className="hidden"
        />
        <input
          ref={multiAudioInputRef}
          type="file"
          multiple
          accept="audio/*,.mp3,.wav,.ogg,.m4a"
          onChange={handleMultiAudioUpload}
          className="hidden"
        />
        <input
          ref={replaceAudioInputRef}
          type="file"
          accept="audio/*,.mp3,.wav,.ogg,.m4a"
          onChange={handleReplaceAudioClip}
          className="hidden"
        />
        <input
          ref={stageFileInputRef}
          type="file"
          accept="image/png,image/*"
          onChange={handleStageFileUpload}
          className="hidden"
        />

        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={closeOwnerModal}
          className="fixed inset-0 bg-black/85 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-5xl rounded-3xl bg-[#051114] border border-rose-500/40 text-slate-100 shadow-[0_20px_70px_rgba(0,0,0,0.9)] overflow-hidden z-10 my-auto flex flex-col max-h-[92vh]"
        >
          {/* Header */}
          <div className="px-6 py-4 bg-gradient-to-r from-rose-950/40 via-[#0a181c] to-amber-950/30 border-b border-rose-500/30 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-500 to-amber-500 flex items-center justify-center text-white shadow-md shadow-rose-500/25">
                <Crown size={20} />
              </div>
              <div>
                <h3 className="font-cairo font-bold text-base sm:text-lg text-white flex items-center gap-2">
                  <span>{isAr ? 'لوحة تحكم نظام المحبة والشخصيات' : 'Character Love System Control'}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                    OWNER
                  </span>
                </h3>
                <p className="font-cairo text-xs text-slate-400">
                  {isAr ? 'مزامنة أبعاد البطاقة، انتقال 100ms للصور البديلة، بنك أصوات عشوائية غير متكررة' : 'Card & image synchronization, 100ms instant crossfade, and random sound collections'}
                </p>
              </div>
            </div>

            <button
              onClick={closeOwnerModal}
              className="w-9 h-9 rounded-xl bg-white/[0.05] border border-white/10 flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="px-6 pt-2.5 bg-black/40 border-b border-white/10 flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
            {[
              { id: 'characters', labelAr: 'إدارة الشخصيات والمراحل', labelEn: 'Characters & Stages', icon: Layers },
              { id: 'rewards', labelAr: 'مكافآت المراحل والسحب الخاص', labelEn: 'Stage Rewards & Special Pool', icon: Sparkles },
              { id: 'items', labelAr: 'استوديو الهدايا والحزم', labelEn: 'Item Studio & Packs', icon: Gift },
              { id: 'adjust', labelAr: 'تعديل المستويات والنقاط يدوياً', labelEn: 'Manual Adjuster', icon: Sliders },
              { id: 'thresholds', labelAr: 'حدود متطلبات المستويات', labelEn: 'Level Thresholds', icon: Crown }
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setActiveTab(tab.id as any);
                    setStatusMessage(null);
                  }}
                  className={`px-4 py-2.5 rounded-t-xl font-cairo font-bold text-xs flex items-center gap-2 border-t border-x transition-all cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-[#051114] text-rose-300 border-rose-500/40 shadow-xs'
                      : 'bg-transparent text-slate-400 border-transparent hover:text-white hover:bg-white/[0.03]'
                  }`}
                >
                  <Icon size={14} className={isActive ? 'text-rose-400' : 'text-slate-500'} />
                  <span>{isAr ? tab.labelAr : tab.labelEn}</span>
                </button>
              );
            })}
          </div>

          {/* Modal Body */}
          <div className="p-5 sm:p-6 overflow-y-auto custom-scrollbar flex-1 space-y-6">
            {/* Status Message */}
            {statusMessage && (
              <div className={`p-3 rounded-xl text-xs font-cairo flex items-center gap-2 ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-950/60 border border-emerald-500/40 text-emerald-200'
                  : 'bg-rose-950/60 border border-rose-500/40 text-rose-200'
              }`}>
                {statusMessage.type === 'success' ? <Check size={16} /> : <AlertCircle size={16} />}
                <span>{statusMessage.text}</span>
              </div>
            )}

            {/* TAB 1: CHARACTERS & OWNER CONTROLS */}
            {activeTab === 'characters' && (
              <div className="space-y-6">
                {!editingCharacter ? (
                  <>
                    <div className="flex items-center justify-between">
                      <h4 className="font-cairo font-bold text-sm text-slate-200">
                        {isAr ? 'الشخصيات المسجلة في النظام' : 'Registered Companions'} ({characters.length})
                      </h4>
                      <button
                        type="button"
                        onClick={handleStartNewCharacter}
                        className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-white font-cairo font-bold text-xs shadow-md shadow-rose-500/20 flex items-center gap-1.5 cursor-pointer"
                      >
                        <Plus size={14} />
                        <span>{isAr ? 'إضافة شخصية جديدة' : 'Add New Character'}</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                      {characters.map(char => (
                        <div
                          key={char.id}
                          className="rounded-2xl p-4 bg-white/[0.03] border border-white/10 flex flex-col justify-between hover:border-white/20 transition-all"
                        >
                          <div className="flex items-start gap-3">
                            <img
                              src={char.avatarUrl}
                              alt={char.name}
                              className="w-14 h-14 rounded-xl object-contain bg-slate-900 border border-white/10 p-1 shrink-0"
                            />
                            <div className="min-w-0 flex-1">
                              <h5 className="font-cairo font-bold text-xs text-white truncate">
                                {isAr ? char.nameAr : char.name}
                              </h5>
                              <p className="font-cairo text-[11px] text-slate-400 truncate mt-0.5">
                                {isAr ? char.titleAr : char.title}
                              </p>
                              <div className="flex flex-wrap gap-1 mt-1.5">
                                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300">
                                  {char.stages?.length || 1} {isAr ? 'مراحل' : 'Stages'}
                                </span>
                                {char.cardHeight && (
                                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300">
                                    {char.cardHeight}px
                                  </span>
                                )}
                                {char.audioConfig?.sounds && char.audioConfig.sounds.length > 0 && (
                                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300">
                                    {char.audioConfig.sounds.length} Sounds
                                  </span>
                                )}
                                {char.clickTransform?.enabled && (
                                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300">
                                    Transform
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                            <button
                              type="button"
                              onClick={() => handleEditCharacter(char)}
                              className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-cairo font-semibold text-white transition-colors cursor-pointer flex items-center gap-1.5"
                            >
                              <Sliders size={13} />
                              <span>{isAr ? 'تخصيص الإعدادات' : 'Configure'}</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                if (window.confirm(isAr ? 'هل أنت متأكد من حذف هذه الشخصية؟' : 'Delete character?')) {
                                  ownerDeleteCharacter(char.id);
                                }
                              }}
                              className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer"
                            >
                              <Trash2 size={15} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  /* Character Editor */
                  <div className="space-y-5 bg-white/[0.02] p-4 sm:p-5 rounded-2xl border border-white/10">
                    {/* Top Bar */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
                      <div>
                        <h4 className="font-cairo font-bold text-sm text-rose-300 flex items-center gap-2">
                          <Crown size={16} />
                          <span>{isAr ? `تخصيص شخصية: ${editingCharacter.nameAr || editingCharacter.name || 'جديدة'}` : `Configure Companion: ${editingCharacter.name || 'New'}`}</span>
                        </h4>
                        <p className="font-cairo text-xs text-slate-400 mt-0.5">
                          {isAr ? 'مزامنة أبعاد البطاقة مع الصورة، انتقال سلس 100ms، وبنك أصوات عشوائية غير متكررة' : 'Card dimensions sync, instant 100ms crossfade, and multi-sound collection'}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={handleResetCharacterDefaults}
                          className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/15 border border-white/10 text-xs font-cairo text-slate-300 flex items-center gap-1 cursor-pointer"
                        >
                          <RotateCcw size={12} />
                          <span>{isAr ? 'استعادة الافتراضي' : 'Reset Defaults'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingCharacter(null)}
                          className="px-3 py-1 rounded-lg text-xs font-cairo text-slate-400 hover:text-white"
                        >
                          {isAr ? 'إلغاء' : 'Cancel'}
                        </button>
                      </div>
                    </div>

                    {/* Sub-Tabs */}
                    <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar border-b border-white/10 pb-2">
                      {[
                        { id: 'stages', labelAr: 'المراحل والصور', labelEn: 'Stages & Artwork', icon: ImageIcon },
                        { id: 'position', labelAr: 'الموضع وأبعاد البطاقة', labelEn: 'Position & Card Sync', icon: Move },
                        { id: 'gradient', labelAr: 'تدرج شفافية الحواف', labelEn: 'Gradient & Fade', icon: Palette },
                        { id: 'audio', labelAr: `بنك الأصوات العشوائية (${soundClipsCount})`, labelEn: `Sound Collection (${soundClipsCount})`, icon: Music },
                        { id: 'transform', labelAr: 'التحول عند النقر (100ms)', labelEn: 'Click Transform (100ms)', icon: Zap },
                        { id: 'preview', labelAr: 'المعاينة الحية المتطابقة', labelEn: 'Synced Live Preview', icon: Eye }
                      ].map(sub => {
                        const Icon = sub.icon;
                        const isSubActive = charSubTab === sub.id;
                        return (
                          <button
                            key={sub.id}
                            type="button"
                            onClick={() => setCharSubTab(sub.id as any)}
                            className={`px-3 py-1.5 rounded-xl font-cairo font-bold text-xs flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
                              isSubActive
                                ? 'bg-gradient-to-r from-rose-500 to-amber-500 text-white shadow-sm'
                                : 'bg-white/[0.04] text-slate-400 hover:text-white hover:bg-white/10'
                            }`}
                          >
                            <Icon size={13} />
                            <span>{isAr ? sub.labelAr : sub.labelEn}</span>
                          </button>
                        );
                      })}
                    </div>

                    {/* SUB-TAB 1: STAGES & ARTWORK */}
                    {charSubTab === 'stages' && (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1">
                              {isAr ? 'الاسم بالعربية' : 'Arabic Name'}
                            </label>
                            <input
                              type="text"
                              value={editingCharacter.nameAr || ''}
                              onChange={(e) => setEditingCharacter({ ...editingCharacter, nameAr: e.target.value })}
                              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                              placeholder="مثال: عشتار - سيدة الضياء"
                            />
                          </div>

                          <div>
                            <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1">
                              {isAr ? 'الاسم بالإنجليزية' : 'English Name'}
                            </label>
                            <input
                              type="text"
                              value={editingCharacter.name || ''}
                              onChange={(e) => setEditingCharacter({ ...editingCharacter, name: e.target.value })}
                              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                              placeholder="e.g. Ishtar, Maiden of Love"
                            />
                          </div>

                          <div>
                            <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1">
                              {isAr ? 'اللقب / الصفة (عربي)' : 'Arabic Title'}
                            </label>
                            <input
                              type="text"
                              value={editingCharacter.titleAr || ''}
                              onChange={(e) => setEditingCharacter({ ...editingCharacter, titleAr: e.target.value })}
                              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                            />
                          </div>

                          <div>
                            <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1">
                              {isAr ? 'اللقب / الصفة (إنجليزي)' : 'English Title'}
                            </label>
                            <input
                              type="text"
                              value={editingCharacter.title || ''}
                              onChange={(e) => setEditingCharacter({ ...editingCharacter, title: e.target.value })}
                              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                            />
                          </div>
                        </div>

                        {/* Default Transparent PNG Artwork */}
                        <div className="p-3.5 rounded-2xl bg-black/30 border border-white/10 space-y-2">
                          <label className="text-xs font-cairo font-semibold text-slate-200 block">
                            {isAr ? 'صورة الشخصية الشفافة الأساسية (Default PNG)' : 'Default Transparent PNG'}
                          </label>
                          <div className="flex items-center gap-3">
                            <button
                              type="button"
                              onClick={() => defaultImageInputRef.current?.click()}
                              className="px-3.5 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-xs font-cairo font-semibold text-rose-200 flex items-center gap-2 cursor-pointer shrink-0"
                            >
                              <Upload size={14} />
                              <span>{isAr ? 'رفع من جهازي' : 'Upload PNG'}</span>
                            </button>
                            <input
                              type="text"
                              value={editingCharacter.avatarUrl || ''}
                              onChange={(e) => setEditingCharacter({ ...editingCharacter, avatarUrl: e.target.value })}
                              placeholder="https://... or /src/assets/..."
                              className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs font-mono text-slate-200"
                            />
                            {editingCharacter.avatarUrl && (
                              <img
                                src={editingCharacter.avatarUrl}
                                alt="preview"
                                className="w-10 h-10 rounded-lg object-contain bg-slate-950 p-1 border border-white/20 shrink-0"
                              />
                            )}
                          </div>
                        </div>

                        {/* Separate Stages Manager with Direct Upload per Stage */}
                        <div className="space-y-3 pt-2">
                          <div className="flex items-center justify-between">
                            <label className="text-xs font-cairo font-bold text-amber-300 flex items-center gap-1.5">
                              <Crown size={14} />
                              <span>{isAr ? 'مراحل ارتقاء المظهر وصور كل مرحلة (Level Stages):' : 'Love Level Stages & PNGs:'}</span>
                            </label>
                            <button
                              type="button"
                              onClick={handleAddStage}
                              className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-cairo font-semibold flex items-center gap-1 cursor-pointer"
                            >
                              <Plus size={12} />
                              <span>{isAr ? 'إضافة مرحلة جديدة' : 'Add Stage'}</span>
                            </button>
                          </div>

                          <div className="space-y-3">
                            {editingCharacter.stages?.map((stage, idx) => (
                              <div
                                key={stage.id || idx}
                                className="p-3.5 rounded-xl bg-black/40 border border-white/10 space-y-3"
                              >
                                <div className="flex items-center justify-between">
                                  <span className="font-cairo font-bold text-xs text-rose-300 flex items-center gap-1.5">
                                    <Sparkles size={12} />
                                    {isAr ? `المرحلة ${stage.stageNumber}` : `Stage ${stage.stageNumber}`}
                                  </span>
                                  {editingCharacter.stages && editingCharacter.stages.length > 1 && (
                                    <button
                                      type="button"
                                      onClick={() => handleRemoveStage(idx)}
                                      className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                                    >
                                      <Trash2 size={13} />
                                    </button>
                                  )}
                                </div>

                                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-2.5">
                                  <div>
                                    <label className="text-[11px] font-cairo text-slate-400 block mb-1">
                                      {isAr ? 'اسم المرحلة (عربي)' : 'Stage Name (Ar)'}
                                    </label>
                                    <input
                                      type="text"
                                      value={stage.nameAr || ''}
                                      onChange={(e) => {
                                        const next = [...(editingCharacter.stages || [])];
                                        next[idx] = { ...next[idx], nameAr: e.target.value };
                                        setEditingCharacter({ ...editingCharacter, stages: next });
                                      }}
                                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                                    />
                                  </div>

                                  <div>
                                    <label className="text-[11px] font-cairo text-slate-400 block mb-1">
                                      {isAr ? 'المستوى المطلوب' : 'Required Level'}
                                    </label>
                                    <input
                                      type="number"
                                      min="1"
                                      max="20"
                                      value={stage.requiredLevel}
                                      onChange={(e) => {
                                        const next = [...(editingCharacter.stages || [])];
                                        next[idx] = { ...next[idx], requiredLevel: parseInt(e.target.value) || 1 };
                                        setEditingCharacter({ ...editingCharacter, stages: next });
                                      }}
                                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                                    />
                                  </div>

                                  <div>
                                    <label className="text-[11px] font-cairo text-slate-400 block mb-1">
                                      {isAr ? 'النقاط المطلوبة' : 'Required Points'}
                                    </label>
                                    <input
                                      type="number"
                                      min="0"
                                      step="50"
                                      value={stage.requiredPoints ?? ((stage.requiredLevel - 1) * 250)}
                                      onChange={(e) => {
                                        const next = [...(editingCharacter.stages || [])];
                                        next[idx] = { ...next[idx], requiredPoints: parseInt(e.target.value) || 0 };
                                        setEditingCharacter({ ...editingCharacter, stages: next });
                                      }}
                                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white font-mono"
                                    />
                                  </div>

                                  <div>
                                    <label className="text-[11px] font-cairo text-amber-300 block mb-1">
                                      {isAr ? 'عملات الحصاد (12س)' : '12h Coins'}
                                    </label>
                                    <div className="flex items-center gap-1">
                                      <Coins size={12} className="text-amber-400 shrink-0" />
                                      <input
                                        type="number"
                                        min="0"
                                        step="10"
                                        value={stage.passiveCoinReward ?? (stage.stageNumber * 50)}
                                        onChange={(e) => {
                                          const next = [...(editingCharacter.stages || [])];
                                          next[idx] = { ...next[idx], passiveCoinReward: parseInt(e.target.value) || 0 };
                                          setEditingCharacter({ ...editingCharacter, stages: next });
                                        }}
                                        className="w-full px-2 py-1.5 rounded-lg bg-slate-900 border border-amber-500/40 text-xs text-amber-300 font-mono"
                                      />
                                    </div>
                                  </div>

                                  <div>
                                    <label className="text-[11px] font-cairo text-slate-400 block mb-1">
                                      {isAr ? 'صورة المرحلة (PNG)' : 'Stage PNG'}
                                    </label>
                                    <div className="flex items-center gap-1.5">
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setStageUploadTargetIdx(idx);
                                          stageFileInputRef.current?.click();
                                        }}
                                        className="px-2 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] font-cairo text-white flex items-center gap-1 cursor-pointer shrink-0"
                                      >
                                        <Upload size={12} />
                                        <span>{isAr ? 'رفع' : 'Upload'}</span>
                                      </button>
                                      <input
                                        type="text"
                                        value={stage.imageUrl || ''}
                                        onChange={(e) => {
                                          const next = [...(editingCharacter.stages || [])];
                                          next[idx] = { ...next[idx], imageUrl: e.target.value };
                                          setEditingCharacter({ ...editingCharacter, stages: next });
                                        }}
                                        placeholder="URL or Upload"
                                        className="flex-1 min-w-0 px-2 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-[11px] text-white"
                                      />
                                      {stage.imageUrl && (
                                        <img
                                          src={stage.imageUrl}
                                          alt="preview"
                                          className="w-7 h-7 rounded object-contain bg-slate-950 border border-white/20 shrink-0"
                                        />
                                      )}
                                    </div>
                                  </div>
                                </div>

                                <div>
                                  <label className="text-[11px] font-cairo text-slate-400 block mb-1">
                                    {isAr ? 'عبارة الشخصية عند الوصول لهذه المرحلة' : 'Stage Dialogue Quote'}
                                  </label>
                                  <input
                                    type="text"
                                    value={stage.quoteAr || stage.quote || ''}
                                    onChange={(e) => {
                                      const next = [...(editingCharacter.stages || [])];
                                      next[idx] = { ...next[idx], quoteAr: e.target.value, quote: e.target.value };
                                      setEditingCharacter({ ...editingCharacter, stages: next });
                                    }}
                                    placeholder={isAr ? 'عبارة مودة خاصة تظهر في فقاعة المحادثة' : 'Affection quote'}
                                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200"
                                  />
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* SUB-TAB 2: POSITION, CARD DIMENSIONS & LAYERING */}
                    {charSubTab === 'position' && (
                      <div className="space-y-5">
                        <div className="p-3 rounded-xl bg-teal-950/40 border border-teal-500/30 text-teal-200 text-xs font-cairo flex items-center gap-2">
                          <Move size={16} className="text-teal-400 shrink-0" />
                          <span>
                            {isAr
                              ? 'مزامنة أبعاد البطاقة (Card Height / Width) مع حجم وموضع الصورة تماماً. تضمن هذه الإعدادات تطابقاً 1:1 بين المعاينة والشاشة الحقيقية دون أي قص أو إزاحة.'
                              : 'Synchronize Card dimensions with image placement. The card adapts automatically to character size, scale, and overflow with zero layout shifts.'}
                          </span>
                        </div>

                        {/* Synchronized Card Dimensions */}
                        <div className="p-4 rounded-xl bg-black/40 border border-cyan-500/30 space-y-3">
                          <label className="text-xs font-cairo font-bold text-cyan-300 block">
                            {isAr ? 'أبعاد بطاقة العرض الحقيقية (Card Dimensions Sync):' : 'Synchronized Card Dimensions:'}
                          </label>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div className="space-y-1.5">
                              <div className="flex justify-between items-center text-xs font-cairo">
                                <span className="text-slate-300">{isAr ? 'ارتفاع البطاقة (Card Height)' : 'Card Height'}</span>
                                <span className="font-mono text-cyan-400 font-bold">{editingCharacter.cardHeight ?? 480} px</span>
                              </div>
                              <input
                                type="range"
                                min="380"
                                max="700"
                                step="10"
                                value={editingCharacter.cardHeight ?? 480}
                                onChange={(e) => setEditingCharacter({ ...editingCharacter, cardHeight: parseInt(e.target.value) })}
                                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                              />
                              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                                <span>380px</span>
                                <span>480px (Standard)</span>
                                <span>700px</span>
                              </div>
                            </div>

                            <div className="space-y-1.5">
                              <div className="flex justify-between items-center text-xs font-cairo">
                                <span className="text-slate-300">{isAr ? 'أقصى عرض للبطاقة (Card Max Width)' : 'Card Max Width'}</span>
                                <span className="font-mono text-cyan-400 font-bold">{editingCharacter.cardWidth ?? 460} px</span>
                              </div>
                              <input
                                type="range"
                                min="340"
                                max="620"
                                step="10"
                                value={editingCharacter.cardWidth ?? 460}
                                onChange={(e) => setEditingCharacter({ ...editingCharacter, cardWidth: parseInt(e.target.value) })}
                                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                              />
                              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                                <span>340px</span>
                                <span>460px (Standard)</span>
                                <span>620px</span>
                              </div>
                            </div>
                          </div>

                          {/* Auto-Adapt Button */}
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-white/10">
                            <span className="text-[11px] font-cairo text-slate-400">
                              {isAr ? 'ملاءمة أبعاد البطاقة تلقائياً حسب حجم ومقياس الصورة وموضعها' : 'Auto-adapt card frame to match image scale & position'}
                            </span>
                            <button
                              type="button"
                              onClick={handleAutoAdaptCardDimensions}
                              className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-200 text-xs font-cairo font-semibold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                            >
                              <Sparkles size={12} className="text-cyan-300" />
                              <span>{isAr ? 'ملاءمة أبعاد البطاقة تلقائياً' : 'Auto-Adapt Card'}</span>
                            </button>
                          </div>
                        </div>

                        {/* Image Placement & Scale */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {/* Scale Slider */}
                          <div className="p-4 rounded-xl bg-black/30 border border-white/10 space-y-2">
                            <div className="flex justify-between items-center text-xs font-cairo">
                              <span className="text-slate-300 font-semibold">{isAr ? 'الحجم والتقريب (Scale)' : 'Scale Multiplier'}</span>
                              <span className="font-mono text-rose-400 font-bold">{(editingCharacter.scale ?? 1.0).toFixed(2)}x</span>
                            </div>
                            <input
                              type="range"
                              min="0.2"
                              max="2.5"
                              step="0.05"
                              value={editingCharacter.scale ?? 1.0}
                              onChange={(e) => setEditingCharacter({ ...editingCharacter, scale: parseFloat(e.target.value) })}
                              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-500"
                            />
                            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                              <span>0.2x</span>
                              <span>1.0x (Normal)</span>
                              <span>2.5x</span>
                            </div>
                          </div>

                          {/* Offset X Slider */}
                          <div className="p-4 rounded-xl bg-black/30 border border-white/10 space-y-2">
                            <div className="flex justify-between items-center text-xs font-cairo">
                              <span className="text-slate-300 font-semibold">{isAr ? 'الإزاحة الأفقية X (يسار / يمين)' : 'Horizontal Offset (X)'}</span>
                              <span className="font-mono text-cyan-400 font-bold">{editingCharacter.offsetX ?? 0} px</span>
                            </div>
                            <input
                              type="range"
                              min="-300"
                              max="300"
                              step="5"
                              value={editingCharacter.offsetX ?? 0}
                              onChange={(e) => setEditingCharacter({ ...editingCharacter, offsetX: parseInt(e.target.value) })}
                              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                            />
                            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                              <span>-300px</span>
                              <span>0 (Center)</span>
                              <span>+300px</span>
                            </div>
                          </div>

                          {/* Offset Y Slider */}
                          <div className="p-4 rounded-xl bg-black/30 border border-white/10 space-y-2">
                            <div className="flex justify-between items-center text-xs font-cairo">
                              <span className="text-slate-300 font-semibold">{isAr ? 'الإزاحة العمودية Y (أعلى / أسفل)' : 'Vertical Offset (Y)'}</span>
                              <span className="font-mono text-amber-400 font-bold">{editingCharacter.offsetY ?? 0} px</span>
                            </div>
                            <input
                              type="range"
                              min="-300"
                              max="300"
                              step="5"
                              value={editingCharacter.offsetY ?? 0}
                              onChange={(e) => setEditingCharacter({ ...editingCharacter, offsetY: parseInt(e.target.value) })}
                              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                            />
                            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                              <span>-300px (Upwards)</span>
                              <span>0</span>
                              <span>+300px (Downwards)</span>
                            </div>
                          </div>

                          {/* Mouth Drop Zone (Mouth X & Y) */}
                          <div className="p-4 rounded-xl bg-black/30 border border-white/10 space-y-4 sm:col-span-2">
                            <label className="text-xs font-cairo font-bold text-rose-300 block">
                              {isAr ? 'إحداثيات نقطة الفم للسحب والإطعام (Drag-to-Feed Mouth Target X/Y):' : 'Drag-to-Feed Mouth Target Coordinates (X/Y):'}
                            </label>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                              <div className="space-y-1.5">
                                <div className="flex justify-between items-center text-xs font-cairo">
                                  <span className="text-slate-300">{isAr ? 'موضع الفم الأفقي (Mouth X)' : 'Mouth X Offset'}</span>
                                  <span className="font-mono text-rose-400 font-bold">{editingCharacter.mouthX ?? 0} px</span>
                                </div>
                                <input
                                  type="range"
                                  min="-150"
                                  max="150"
                                  step="5"
                                  value={editingCharacter.mouthX ?? 0}
                                  onChange={(e) => setEditingCharacter({ ...editingCharacter, mouthX: parseInt(e.target.value) })}
                                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-500"
                                />
                              </div>
                              <div className="space-y-1.5">
                                <div className="flex justify-between items-center text-xs font-cairo">
                                  <span className="text-slate-300">{isAr ? 'موضع الفم العمودي (Mouth Y)' : 'Mouth Y Offset'}</span>
                                  <span className="font-mono text-amber-400 font-bold">{editingCharacter.mouthY ?? -60} px</span>
                                </div>
                                <input
                                  type="range"
                                  min="-250"
                                  max="50"
                                  step="5"
                                  value={editingCharacter.mouthY ?? -60}
                                  onChange={(e) => setEditingCharacter({ ...editingCharacter, mouthY: parseInt(e.target.value) })}
                                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                                />
                              </div>
                            </div>
                          </div>

                          {/* Layering & Overflow Mode */}
                          <div className="p-4 rounded-xl bg-black/30 border border-white/10 space-y-3">
                            <div>
                              <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1">
                                {isAr ? 'نمط الطبقات والتموضع (Layering)' : 'Layering Mode'}
                              </label>
                              <select
                                value={editingCharacter.layering || 'popout_overflow'}
                                onChange={(e) => setEditingCharacter({ ...editingCharacter, layering: e.target.value as any })}
                                className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                              >
                                <option value="popout_overflow">{isAr ? 'بارزة للأمام خارج إطار البطاقة (Pop-out 3D)' : 'Pop-out Overflowing Card'}</option>
                                <option value="front">{isAr ? 'أمام جميع العناصر (Top Layer Foreground)' : 'Foreground In Front of All'}</option>
                                <option value="behind_pedestal">{isAr ? 'خلف المنصة البيضاوية المرتفعة' : 'Behind Raised Pedestal'}</option>
                                <option value="contained">{isAr ? 'محتواة ومقصوصة داخل البطاقة' : 'Contained Inside Borders'}</option>
                              </select>
                            </div>

                            <div>
                              <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1">
                                {isAr ? 'القص عند حدود البطاقة (Overflow)' : 'Overflow Boundary'}
                              </label>
                              <div className="flex gap-2">
                                <button
                                  type="button"
                                  onClick={() => setEditingCharacter({ ...editingCharacter, overflowMode: 'visible' })}
                                  className={`flex-1 py-1.5 rounded-lg font-cairo text-xs font-semibold border transition-colors cursor-pointer ${
                                    (editingCharacter.overflowMode ?? 'visible') === 'visible'
                                      ? 'bg-rose-500/20 border-rose-500/60 text-rose-200'
                                      : 'bg-white/5 border-white/10 text-slate-400'
                                  }`}
                                >
                                  {isAr ? 'بارزة للخارج (Visible)' : 'Visible (Pop Out)'}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEditingCharacter({ ...editingCharacter, overflowMode: 'clipped' })}
                                  className={`flex-1 py-1.5 rounded-lg font-cairo text-xs font-semibold border transition-colors cursor-pointer ${
                                    editingCharacter.overflowMode === 'clipped'
                                      ? 'bg-rose-500/20 border-rose-500/60 text-rose-200'
                                      : 'bg-white/5 border-white/10 text-slate-400'
                                  }`}
                                >
                                  {isAr ? 'مقصوصة بالداخل (Clipped)' : 'Clipped (Contained)'}
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Custom Dimensions (Width / Height) */}
                        <div className="p-4 rounded-xl bg-black/30 border border-white/10 space-y-3">
                          <label className="text-xs font-cairo font-bold text-slate-200 block">
                            {isAr ? 'تخصيص أبعاد صورة الـ PNG المباشرة:' : 'Explicit PNG Dimensions:'}
                          </label>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                              <label className="text-[11px] font-cairo text-slate-400 block mb-1">
                                {isAr ? 'العرض (Width: auto أو بالبكسل)' : 'Width (auto or px)'}
                              </label>
                              <input
                                type="text"
                                value={editingCharacter.imageWidth ?? 'auto'}
                                onChange={(e) => setEditingCharacter({ ...editingCharacter, imageWidth: e.target.value })}
                                placeholder="auto, 320px, 100%..."
                                className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white font-mono"
                              />
                            </div>
                            <div>
                              <label className="text-[11px] font-cairo text-slate-400 block mb-1">
                                {isAr ? 'الارتفاع (Height: auto أو بالبكسل)' : 'Height (auto or px)'}
                              </label>
                              <input
                                type="text"
                                value={editingCharacter.imageHeight ?? 'auto'}
                                onChange={(e) => setEditingCharacter({ ...editingCharacter, imageHeight: e.target.value })}
                                placeholder="auto, 520px, 130%..."
                                className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white font-mono"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* SUB-TAB 3: IMAGE GRADIENT & EDGE FADE */}
                    {charSubTab === 'gradient' && (
                      <div className="space-y-5">
                        <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-500/30 text-purple-200 text-xs font-cairo flex items-center gap-2">
                          <Palette size={16} className="text-purple-400 shrink-0" />
                          <span>
                            {isAr
                              ? 'تطبيق تأثير التلاشي التدريجي الشفاف (Mask Gradient) على صورة الـ PNG حصراً، لتتلاشى حوافها بنعومة فائقة دون التأثير إطلاقاً على خلفية البطاقة أو المنصة.'
                              : 'Applies transparent gradient masks to fade character image edges smoothly without affecting card slab or background.'}
                          </span>
                        </div>

                        {/* Enable Gradient Toggle */}
                        <div className="flex items-center justify-between p-4 rounded-xl bg-black/30 border border-white/10">
                          <div>
                            <span className="font-cairo font-bold text-xs text-white block">
                              {isAr ? 'تفعيل تدرج شفافية الحواف (Transparent Fade)' : 'Enable Edge Fade Mask'}
                            </span>
                            <span className="font-cairo text-[11px] text-slate-400">
                              {isAr ? 'إخفاء أو تلاشي أطراف الصورة نحو الشفافية الكاملة' : 'Fades character edges seamlessly into transparency'}
                            </span>
                          </div>

                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={Boolean(editingCharacter.gradientFade?.enabled)}
                              onChange={(e) => setEditingCharacter({
                                ...editingCharacter,
                                gradientFade: {
                                  ...(editingCharacter.gradientFade || DEFAULT_GRADIENT),
                                  enabled: e.target.checked
                                }
                              })}
                              className="sr-only peer"
                            />
                            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                          </label>
                        </div>

                        {editingCharacter.gradientFade?.enabled && (
                          <div className="space-y-4 p-4 rounded-xl bg-black/40 border border-purple-500/30">
                            <div>
                              <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1.5">
                                {isAr ? 'اتجاه التلاشي التدريجي' : 'Fade Direction'}
                              </label>
                              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                                {[
                                  { id: 'to-bottom', labelAr: 'من الأعلى للأسفل', labelEn: 'To Bottom' },
                                  { id: 'to-top', labelAr: 'من الأسفل للأعلى', labelEn: 'To Top' },
                                  { id: 'to-left', labelAr: 'نحو اليسار', labelEn: 'To Left' },
                                  { id: 'to-right', labelAr: 'نحو اليمين', labelEn: 'To Right' },
                                  { id: 'radial', labelAr: 'تلاشي دائري (Radial)', labelEn: 'Radial Vignette' },
                                  { id: 'angle', labelAr: 'زاوية مخصصة', labelEn: 'Custom Angle' }
                                ].map(dir => (
                                  <button
                                    key={dir.id}
                                    type="button"
                                    onClick={() => setEditingCharacter({
                                      ...editingCharacter,
                                      gradientFade: {
                                        ...(editingCharacter.gradientFade || DEFAULT_GRADIENT),
                                        direction: dir.id as any
                                      }
                                    })}
                                    className={`p-2 rounded-xl text-xs font-cairo font-semibold border transition-colors cursor-pointer ${
                                      (editingCharacter.gradientFade?.direction || 'to-bottom') === dir.id
                                        ? 'bg-purple-950/60 border-purple-500/70 text-purple-200 shadow-sm'
                                        : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                                    }`}
                                  >
                                    {isAr ? dir.labelAr : dir.labelEn}
                                  </button>
                                ))}
                              </div>
                            </div>

                            {editingCharacter.gradientFade?.direction === 'angle' && (
                              <div className="space-y-1.5">
                                <div className="flex justify-between items-center text-xs font-cairo">
                                  <span className="text-slate-300">{isAr ? 'درجة الزاوية' : 'Angle Degrees'}</span>
                                  <span className="font-mono text-purple-300 font-bold">{editingCharacter.gradientFade?.angle ?? 180}°</span>
                                </div>
                                <input
                                  type="range"
                                  min="0"
                                  max="360"
                                  value={editingCharacter.gradientFade?.angle ?? 180}
                                  onChange={(e) => setEditingCharacter({
                                    ...editingCharacter,
                                    gradientFade: {
                                      ...(editingCharacter.gradientFade || DEFAULT_GRADIENT),
                                      angle: parseInt(e.target.value)
                                    }
                                  })}
                                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
                                />
                              </div>
                            )}

                            <div className="space-y-1.5">
                              <div className="flex justify-between items-center text-xs font-cairo">
                                <span className="text-slate-300">{isAr ? 'نقطة بداية التلاشي' : 'Fade Start Point'}</span>
                                <span className="font-mono text-purple-300 font-bold">{editingCharacter.gradientFade?.startPercent ?? 60}%</span>
                              </div>
                              <input
                                type="range"
                                min="0"
                                max="100"
                                value={editingCharacter.gradientFade?.startPercent ?? 60}
                                onChange={(e) => setEditingCharacter({
                                  ...editingCharacter,
                                  gradientFade: {
                                    ...(editingCharacter.gradientFade || DEFAULT_GRADIENT),
                                    startPercent: parseInt(e.target.value)
                                  }
                                })}
                                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
                              />
                            </div>

                            <div className="space-y-1.5">
                              <div className="flex justify-between items-center text-xs font-cairo">
                                <span className="text-slate-300">{isAr ? 'نقطة انتهاء التلاشي (شفافية تامة)' : 'Fade End Point (Full Transparency)'}</span>
                                <span className="font-mono text-purple-300 font-bold">{editingCharacter.gradientFade?.endPercent ?? 100}%</span>
                              </div>
                              <input
                                type="range"
                                min="0"
                                max="100"
                                value={editingCharacter.gradientFade?.endPercent ?? 100}
                                onChange={(e) => setEditingCharacter({
                                  ...editingCharacter,
                                  gradientFade: {
                                    ...(editingCharacter.gradientFade || DEFAULT_GRADIENT),
                                    endPercent: parseInt(e.target.value)
                                  }
                                })}
                                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
                              />
                            </div>

                            <div className="pt-2">
                              <label className="text-[11px] font-cairo text-slate-400 block mb-1">
                                {isAr ? 'محاكاة بصرية لقناع التلاشي (Gradient Mask Preview):' : 'Visual Gradient Mask Simulation:'}
                              </label>
                              <div
                                className="w-full h-6 rounded-lg border border-white/20"
                                style={{
                                  background: editingCharacter.gradientFade?.direction === 'radial'
                                    ? `radial-gradient(circle at center, #ec4899 ${editingCharacter.gradientFade?.startPercent ?? 60}%, transparent ${editingCharacter.gradientFade?.endPercent ?? 100}%)`
                                    : `linear-gradient(90deg, #ec4899 ${editingCharacter.gradientFade?.startPercent ?? 60}%, transparent ${editingCharacter.gradientFade?.endPercent ?? 100}%)`
                                }}
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* SUB-TAB 4: RANDOM CHARACTER SOUNDS COLLECTION */}
                    {charSubTab === 'audio' && (
                      <div className="space-y-5">
                        <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs font-cairo flex items-center gap-2">
                          <Music size={16} className="text-amber-400 shrink-0" />
                          <span>
                            {isAr
                              ? 'بنك الأصوات العشوائية: ارفع عدة ملفات صوتية من جهازك. عند النقر على الشخصية سيتم تشغيل صوت عشوائي مسبق التحميل دون تكرار متتالي ودون أي تداخل بين الأصوات.'
                              : 'Random Sound Collection: Upload multiple audio files from your device. One random preloaded sound will play on click without consecutive repeats or overlapping.'}
                          </span>
                        </div>

                        {/* Enable Audio Toggle */}
                        <div className="flex items-center justify-between p-4 rounded-xl bg-black/30 border border-white/10">
                          <div>
                            <span className="font-cairo font-bold text-xs text-white block">
                              {isAr ? 'تفعيل بنك الأصوات التفاعلية' : 'Enable Interaction Sound Collection'}
                            </span>
                            <span className="font-cairo text-[11px] text-slate-400">
                              {isAr ? 'تشغيل مقطع عشوائي من الأصوات المرفوعة عند النقر' : 'Plays a random sound clip from assigned collection on click'}
                            </span>
                          </div>

                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={Boolean(editingCharacter.audioConfig?.enabled)}
                              onChange={(e) => setEditingCharacter({
                                ...editingCharacter,
                                audioConfig: {
                                  ...(editingCharacter.audioConfig || DEFAULT_AUDIO),
                                  enabled: e.target.checked
                                }
                              })}
                              className="sr-only peer"
                            />
                            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
                          </label>
                        </div>

                        {/* Master Volume & Multi-Upload Actions */}
                        <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-4">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => multiAudioInputRef.current?.click()}
                                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer shadow-md shadow-amber-500/20"
                              >
                                <Upload size={14} />
                                <span>{isAr ? 'رفع ملفات صوتية من جهازي (متعدد)' : 'Upload Audio Files (Multiple)'}</span>
                              </button>

                              {(editingCharacter.audioConfig?.sounds?.length || 0) > 0 && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    const res = playRandomCharacterSound(editingCharacter.audioConfig, previewLastSoundIdRef.current);
                                    if (res.playedId) {
                                      previewLastSoundIdRef.current = res.playedId;
                                      setStatusMessage({
                                        text: isAr ? `تم تشغيل: ${res.playedName} 🎲` : `Played: ${res.playedName} 🎲`,
                                        type: 'success'
                                      });
                                    }
                                  }}
                                  className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer shadow-sm"
                                >
                                  <Shuffle size={14} />
                                  <span>{isAr ? 'تجربة صوت عشوائي' : 'Test Random Sound'}</span>
                                </button>
                              )}
                            </div>

                            <span className="text-xs font-mono font-bold text-amber-300">
                              {editingCharacter.audioConfig?.sounds?.length || 0} {isAr ? 'مقاطع صوتية مسجلة' : 'Clips Assigned'}
                            </span>
                          </div>

                          {/* Master Volume Slider */}
                          <div className="space-y-1.5 pt-2 border-t border-white/10">
                            <div className="flex justify-between items-center text-xs font-cairo">
                              <span className="text-slate-300 font-semibold flex items-center gap-1.5">
                                <Volume2 size={14} className="text-amber-400" />
                                <span>{isAr ? 'مستوى الصوت العام (Master Volume)' : 'Master Volume'}</span>
                              </span>
                              <span className="font-mono text-amber-300 font-bold">
                                {editingCharacter.audioConfig?.volume ?? 80}%
                              </span>
                            </div>
                            <input
                              type="range"
                              min="0"
                              max="100"
                              value={editingCharacter.audioConfig?.volume ?? 80}
                              onChange={(e) => setEditingCharacter({
                                ...editingCharacter,
                                audioConfig: {
                                  ...(editingCharacter.audioConfig || DEFAULT_AUDIO),
                                  volume: parseInt(e.target.value)
                                }
                              })}
                              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                            />
                          </div>

                          {/* Sound Clips List */}
                          <div className="space-y-2.5 pt-3 border-t border-white/10">
                            <label className="text-xs font-cairo font-bold text-slate-200 block">
                              {isAr ? 'مجموعة المقاطع الصوتية (Sound Collection):' : 'Sound Collection Items:'}
                            </label>

                            {(!editingCharacter.audioConfig?.sounds || editingCharacter.audioConfig.sounds.length === 0) ? (
                              <div className="p-4 rounded-xl border border-dashed border-white/10 text-center text-slate-500 font-cairo text-xs">
                                {isAr ? 'لم تتم إضافة مقاطع صوتية بعد. اضغط "رفع ملفات صوتية من جهازي" لإضافة أصوات.' : 'No audio files added yet. Click "Upload Audio Files" to add.'}
                              </div>
                            ) : (
                              <div className="space-y-2 max-h-[300px] overflow-y-auto custom-scrollbar pr-1">
                                {editingCharacter.audioConfig.sounds.map((clip, idx) => (
                                  <div
                                    key={clip.id}
                                    className="p-3 rounded-xl bg-white/[0.03] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                                  >
                                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                                      <button
                                        type="button"
                                        onClick={() => handleTestClipPlayback(clip)}
                                        className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 cursor-pointer transition-colors ${
                                          playingClipId === clip.id
                                            ? 'bg-rose-500 text-white animate-pulse'
                                            : 'bg-emerald-600/80 hover:bg-emerald-500 text-white'
                                        }`}
                                        title={playingClipId === clip.id ? 'Stop' : 'Play'}
                                      >
                                        {playingClipId === clip.id ? <Square size={13} /> : <Play size={13} />}
                                      </button>

                                      <div className="min-w-0 flex-1">
                                        <input
                                          type="text"
                                          value={clip.name}
                                          onChange={(e) => handleUpdateClipName(clip.id, e.target.value)}
                                          className="w-full px-2 py-1 rounded bg-slate-900 border border-slate-700 text-xs text-white font-medium"
                                          placeholder="Clip name..."
                                        />
                                      </div>
                                    </div>

                                    {/* Clip Individual Volume Slider */}
                                    <div className="flex items-center gap-3 shrink-0">
                                      <div className="flex items-center gap-1.5 w-32">
                                        <Volume2 size={12} className="text-slate-400 shrink-0" />
                                        <input
                                          type="range"
                                          min="0"
                                          max="100"
                                          value={clip.volume ?? 80}
                                          onChange={(e) => handleUpdateClipVolume(clip.id, parseInt(e.target.value))}
                                          className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                                          title={`Volume: ${clip.volume ?? 80}%`}
                                        />
                                        <span className="font-mono text-[10px] text-slate-400 w-7 text-right">
                                          {clip.volume ?? 80}%
                                        </span>
                                      </div>

                                      {/* Replace File Button */}
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setReplaceTargetClipId(clip.id);
                                          replaceAudioInputRef.current?.click();
                                        }}
                                        className="px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-[11px] font-cairo text-slate-300 cursor-pointer"
                                        title="Replace file"
                                      >
                                        {isAr ? 'استبدال' : 'Replace'}
                                      </button>

                                      {/* Remove Clip Button */}
                                      <button
                                        type="button"
                                        onClick={() => handleRemoveAudioClip(clip.id)}
                                        className="p-1 rounded text-rose-400 hover:bg-rose-950/50 cursor-pointer"
                                        title="Remove clip"
                                      >
                                        <Trash2 size={14} />
                                      </button>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* SUB-TAB 5: CLICK TRANSFORMATION (100MS CROSSFADE) */}
                    {charSubTab === 'transform' && (
                      <div className="space-y-5">
                        <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-200 text-xs font-cairo flex items-center gap-2">
                          <Zap size={16} className="text-rose-400 shrink-0" />
                          <span>
                            {isAr
                              ? 'انتقال فوري شبه غير ملحوظ (80–120ms Crossfade) إلى صورة PNG البديلة عند النقر، مع تحميل مسبق يمنع أي تأخير أو رمشة أو وميض أو تغيير في الحجم.'
                              : 'Instant 80–120ms subtle crossfade to alternate pose upon click. Preloaded to prevent any flickering, frame jumps, or size changes.'}
                          </span>
                        </div>

                        {/* Enable Click Transform Toggle */}
                        <div className="flex items-center justify-between p-4 rounded-xl bg-black/30 border border-white/10">
                          <div>
                            <span className="font-cairo font-bold text-xs text-white block">
                              {isAr ? 'تفعيل الاستبدال الفوري عند النقر' : 'Enable Instant Click Transformation'}
                            </span>
                            <span className="font-cairo text-[11px] text-slate-400">
                              {isAr ? 'استبدال الصورة بتعبير آخر بتلاشي خاطف 100ms' : 'Seamless 100ms crossfade to alternate pose'}
                            </span>
                          </div>

                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={Boolean(editingCharacter.clickTransform?.enabled)}
                              onChange={(e) => setEditingCharacter({
                                ...editingCharacter,
                                clickTransform: {
                                  ...(editingCharacter.clickTransform || DEFAULT_CLICK_TRANSFORM),
                                  enabled: e.target.checked
                                }
                              })}
                              className="sr-only peer"
                            />
                            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-500"></div>
                          </label>
                        </div>

                        {/* Transformation Settings */}
                        <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-4">
                          <div>
                            <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1.5">
                              {isAr ? 'صورة التحول (PNG شفاف بديل)' : 'Alternate Pose PNG Image'}
                            </label>
                            <div className="flex items-center gap-3">
                              <button
                                type="button"
                                onClick={() => clickImageInputRef.current?.click()}
                                className="px-3.5 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-xs font-cairo font-semibold text-rose-200 flex items-center gap-1.5 cursor-pointer shrink-0"
                              >
                                <Upload size={14} />
                                <span>{isAr ? 'رفع PNG بديل' : 'Upload PNG'}</span>
                              </button>
                              <input
                                type="text"
                                value={editingCharacter.clickTransform?.imageUrl || ''}
                                onChange={(e) => setEditingCharacter({
                                  ...editingCharacter,
                                  clickTransform: {
                                    ...(editingCharacter.clickTransform || DEFAULT_CLICK_TRANSFORM),
                                    imageUrl: e.target.value
                                  }
                                })}
                                placeholder="https://... or data:image/png..."
                                className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs font-mono text-slate-200"
                              />
                              {editingCharacter.clickTransform?.imageUrl && (
                                <img
                                  src={editingCharacter.clickTransform.imageUrl}
                                  alt="preview"
                                  className="w-10 h-10 rounded-lg object-contain bg-slate-950 p-1 border border-white/20 shrink-0"
                                />
                              )}
                            </div>
                          </div>

                          {/* Mode (Timed vs Toggle) */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-white/10">
                            <div>
                              <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1">
                                {isAr ? 'نمط العودة بعد النقر' : 'Return Behavior'}
                              </label>
                              <div className="flex gap-2">
                                <button
                                  type="button"
                                  onClick={() => setEditingCharacter({
                                    ...editingCharacter,
                                    clickTransform: {
                                      ...(editingCharacter.clickTransform || DEFAULT_CLICK_TRANSFORM),
                                      mode: 'timed'
                                    }
                                  })}
                                  className={`flex-1 py-1.5 rounded-lg font-cairo text-xs font-semibold border transition-colors cursor-pointer ${
                                    (editingCharacter.clickTransform?.mode || 'timed') === 'timed'
                                      ? 'bg-rose-500/20 border-rose-500/60 text-rose-200'
                                      : 'bg-white/5 border-white/10 text-slate-400'
                                  }`}
                                >
                                  {isAr ? 'مؤقت (Timed)' : 'Timed Revert'}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEditingCharacter({
                                    ...editingCharacter,
                                    clickTransform: {
                                      ...(editingCharacter.clickTransform || DEFAULT_CLICK_TRANSFORM),
                                      mode: 'toggle'
                                    }
                                  })}
                                  className={`flex-1 py-1.5 rounded-lg font-cairo text-xs font-semibold border transition-colors cursor-pointer ${
                                    editingCharacter.clickTransform?.mode === 'toggle'
                                      ? 'bg-rose-500/20 border-rose-500/60 text-rose-200'
                                      : 'bg-white/5 border-white/10 text-slate-400'
                                  }`}
                                >
                                  {isAr ? 'تبديل مستمر (Toggle)' : 'Toggle Mode'}
                                </button>
                              </div>
                            </div>

                            {/* Duration Slider if timed */}
                            {(editingCharacter.clickTransform?.mode || 'timed') === 'timed' && (
                              <div className="space-y-1">
                                <div className="flex justify-between items-center text-xs font-cairo">
                                  <span className="text-slate-300">{isAr ? 'مدة بقاء التعبير قبل العودة' : 'Duration (ms)'}</span>
                                  <span className="font-mono text-rose-400 font-bold">{editingCharacter.clickTransform?.durationMs ?? 1200} ms</span>
                                </div>
                                <input
                                  type="range"
                                  min="300"
                                  max="4000"
                                  step="100"
                                  value={editingCharacter.clickTransform?.durationMs ?? 1200}
                                  onChange={(e) => setEditingCharacter({
                                    ...editingCharacter,
                                    clickTransform: {
                                      ...(editingCharacter.clickTransform || DEFAULT_CLICK_TRANSFORM),
                                      durationMs: parseInt(e.target.value)
                                    }
                                  })}
                                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-500"
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* SUB-TAB 6: SYNCHRONIZED LIVE PREVIEW */}
                    {charSubTab === 'preview' && (
                      <div className="flex flex-col items-center space-y-4">
                        <div className="text-center">
                          <span className="text-xs font-cairo font-semibold text-slate-300">
                            {isAr ? 'المعاينة الحية المتطابقة تماماً: انقر لاختبار بنك الأصوات العشوائي والانتقال الفوري (100ms)' : 'Synced Live Preview: Click card to test random sounds and instant 100ms crossfade:'}
                          </span>
                        </div>

                        {/* Interactive Synchronized Preview Card */}
                        <div
                          onClick={handlePreviewCardClick}
                          style={{
                            height: `${previewHeight}px`,
                            maxWidth: `${previewMaxWidth}px`
                          }}
                          className={`relative w-full rounded-[2.5rem] border cursor-pointer select-none shadow-2xl transition-all duration-200 ${
                            editingCharacter.overflowMode === 'clipped' ? 'overflow-hidden' : 'overflow-visible'
                          } ${
                            'bg-gradient-to-b from-[#062428]/95 via-[#03171a]/98 to-[#010e10] border-[#5eead4]/40 shadow-[0_20px_50px_rgba(0,0,0,0.85)]'
                          }`}
                        >
                          {/* Radial Glow */}
                          <div
                            className="absolute top-[35%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] rounded-full blur-[80px] pointer-events-none"
                            style={{ backgroundColor: editingCharacter.themeColor || '#f43f5e', opacity: 0.5 }}
                          />

                          {/* Pedestal */}
                          <div className="absolute bottom-7 left-1/2 -translate-x-1/2 w-[80%] max-w-[320px] h-10 rounded-[100%] bg-gradient-to-b from-[#0f4f56] to-[#021113] border border-[#5eead4]/60 pointer-events-none shadow-lg z-10" />

                          {/* Synchronized Character Stack with 100ms Crossfade */}
                          <div
                            className={`absolute inset-0 flex items-end justify-center pointer-events-none ${
                              editingCharacter.overflowMode === 'clipped' ? 'overflow-hidden' : 'overflow-visible'
                            }`}
                            style={{
                              zIndex: editingCharacter.layering === 'behind_pedestal' ? 5 : 20
                            }}
                          >
                            <div
                              className="relative w-full h-full flex items-end justify-center pb-8"
                              style={{
                                transform: `translate(${editingCharacter.offsetX || 0}px, ${editingCharacter.offsetY || 0}px) scale(${editingCharacter.scale || 1.0})`
                              }}
                            >
                              <div
                                className="relative flex items-end justify-center pointer-events-none select-none"
                                style={{
                                  width: editingCharacter.imageWidth && editingCharacter.imageWidth !== 'auto' ? editingCharacter.imageWidth : 'auto',
                                  height: editingCharacter.imageHeight && editingCharacter.imageHeight !== 'auto' ? editingCharacter.imageHeight : '130%',
                                  maxHeight: `${previewHeight * 1.25}px`
                                }}
                              >
                                {/* 1. Normal Image */}
                                {previewNormalImg && (
                                  <img
                                    src={previewNormalImg}
                                    alt="character normal"
                                    className="max-h-full max-w-full object-contain object-bottom select-none filter drop-shadow-[0_20px_35px_rgba(0,0,0,0.85)]"
                                    style={{
                                      opacity: previewTransformed && previewAltImg ? 0 : 1,
                                      transition: 'opacity 100ms ease-in-out',
                                      ...previewMaskStyle
                                    }}
                                  />
                                )}

                                {/* 2. Alternate Image (Stacked with 100ms crossfade) */}
                                {previewAltImg && (
                                  <img
                                    src={previewAltImg}
                                    alt="character alternate"
                                    className="absolute inset-x-0 bottom-0 m-auto max-h-full max-w-full object-contain object-bottom select-none filter drop-shadow-[0_20px_35px_rgba(0,0,0,0.85)]"
                                    style={{
                                      opacity: previewTransformed ? 1 : 0,
                                      transition: 'opacity 100ms ease-in-out',
                                      ...previewMaskStyle
                                    }}
                                  />
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Indicator pill inside preview */}
                          <div className="absolute bottom-2.5 inset-x-2 z-30 pointer-events-none text-center">
                            <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-black/80 text-slate-300 border border-white/10 backdrop-blur-sm">
                              {previewTransformed ? (isAr ? 'صورة التحول نشطة ⚡' : 'Transformed Pose ⚡') : (isAr ? 'الصورة الأساسية' : 'Normal Pose')}
                              {' • '}
                              {soundClipsCount} {isAr ? 'أصوات' : 'Sounds'}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Footer */}
                    <div className="flex items-center justify-between pt-4 border-t border-white/10">
                      <button
                        type="button"
                        onClick={handleResetCharacterDefaults}
                        className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 text-xs font-cairo text-slate-300 flex items-center gap-1.5 cursor-pointer"
                      >
                        <RotateCcw size={13} />
                        <span>{isAr ? 'استعادة الافتراضيات' : 'Reset Defaults'}</span>
                      </button>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setEditingCharacter(null)}
                          className="px-4 py-2 rounded-xl text-xs font-cairo text-slate-400 hover:text-white cursor-pointer"
                        >
                          {isAr ? 'إلغاء' : 'Cancel'}
                        </button>
                        <button
                          type="button"
                          disabled={isSaving}
                          onClick={handleSaveCharacterSubmit}
                          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-white font-cairo font-bold text-xs shadow-lg shadow-rose-500/25 flex items-center gap-2 cursor-pointer disabled:opacity-50"
                        >
                          {isSaving ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
                          <span>{isAr ? 'حفظ الشخصية والتعديلات' : 'Save All Changes'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB: STAGE REWARDS & 3-DAY SPECIAL POOL (OWNER CONFIGURATION) */}
            {activeTab === 'rewards' && (
              <div className="space-y-6">
                {/* Header Banner */}
                <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/15 via-teal-500/10 to-indigo-500/15 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shrink-0">
                      <Sparkles size={20} />
                    </div>
                    <div>
                      <h4 className="font-cairo font-bold text-sm text-slate-100 flex items-center gap-2">
                        <span>{isAr ? 'إدارة مكافآت المراحل (12س) ومستودع السحب الخاص (3 أيام)' : 'Love Stage Coins (12h) & Special Reward Pool (3D)'}</span>
                      </h4>
                      <p className="font-cairo text-xs text-slate-400">
                        {isAr
                          ? 'تحديد عملات كل مرحلة بدقة، واختيار الحزم والهدايا المؤهلة للسحب الخاص مع التحكم بنسب الفرص والمؤقت'
                          : 'Configure coins per Love Stage, select eligible packages/items, customize probabilities and timer.'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      disabled={isResettingCooldown}
                      onClick={handleResetMyCooldown}
                      className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/40 text-cyan-200 text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer transition-all shadow-xs"
                      title={isAr ? 'تصفير مؤقت الـ 3 أيام لحسابك لتجربة الزر' : 'Reset 3-day timer to test claim button'}
                    >
                      <RotateCcw size={13} className={isResettingCooldown ? 'animate-spin' : ''} />
                      <span>{isAr ? 'تصفير مؤقتي (تجربة)' : 'Reset My Cooldown'}</span>
                    </button>

                    <button
                      type="button"
                      disabled={isSaving}
                      onClick={handleSaveSpecialRewardsPool}
                      className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-cairo font-bold text-xs shadow-md shadow-amber-500/20 flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      {isSaving ? <RefreshCw size={13} className="animate-spin" /> : <Save size={13} />}
                      <span>{isAr ? 'حفظ إعدادات السحب' : 'Save Special Pool'}</span>
                    </button>
                  </div>
                </div>

                {/* ---------------------------------------------------- */}
                {/* SECTION 1: 12-HOUR STAGE COIN REWARDS CONFIGURATION   */}
                {/* ---------------------------------------------------- */}
                <div className="p-4 sm:p-5 rounded-2xl bg-white/[0.02] border border-amber-500/25 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
                    <div className="flex items-center gap-2">
                      <Coins size={16} className="text-amber-400" />
                      <h5 className="font-cairo font-bold text-xs sm:text-sm text-amber-200">
                        {isAr ? 'مكافآت العملات لكل مرحلة (تُحصّل كل 12 ساعة)' : 'Stage Coin Yields (Claimable Every 12 Hours)'}
                      </h5>
                    </div>
                    <span className="text-[11px] font-cairo text-slate-400">
                      {isAr ? 'تحديد مقدار العملات التي يحصل عليها اللاعب دورياً حسب مرحلة الشخصية' : 'Define regular coin income per stage for each companion'}
                    </span>
                  </div>

                  <div className="space-y-4">
                    {characters.map(char => (
                      <div key={char.id} className="p-3.5 rounded-xl bg-black/40 border border-white/10 space-y-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={char.avatarUrl}
                            alt={char.name}
                            className="w-8 h-8 rounded-lg object-contain bg-slate-900 border border-white/10 p-0.5"
                          />
                          <div>
                            <h6 className="font-cairo font-bold text-xs text-white">
                              {isAr ? char.nameAr : char.name}
                            </h6>
                            <span className="text-[10px] font-mono text-slate-400">
                              {char.stages?.length || 1} {isAr ? 'مراحل مظهر' : 'stages'}
                            </span>
                          </div>
                        </div>

                        {/* Stages Grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                          {(char.stages || []).map(st => {
                            const curCoins = stageCoinEdits[char.id]?.[st.stageNumber] ?? (st.passiveCoinReward ?? (st.stageNumber * 50));
                            return (
                              <div
                                key={st.id || st.stageNumber}
                                className="p-2.5 rounded-lg bg-white/[0.03] border border-white/10 flex items-center justify-between gap-2"
                              >
                                <div className="min-w-0">
                                  <span className="font-cairo font-bold text-[11px] text-rose-300 block truncate">
                                    {isAr ? (st.nameAr || `المرحلة ${st.stageNumber}`) : (st.name || `Stage ${st.stageNumber}`)}
                                  </span>
                                  <span className="text-[10px] font-mono text-slate-400">
                                    Lv.{st.requiredLevel} • {st.requiredPoints} pts
                                  </span>
                                </div>

                                <div className="flex items-center gap-1.5 shrink-0">
                                  <div className="flex items-center gap-1 bg-slate-900 px-2 py-1 rounded-md border border-amber-500/30">
                                    <Coins size={12} className="text-amber-400" />
                                    <input
                                      type="number"
                                      min="0"
                                      step="10"
                                      value={curCoins}
                                      onChange={(e) => {
                                        const val = parseInt(e.target.value) || 0;
                                        setStageCoinEdits(prev => ({
                                          ...prev,
                                          [char.id]: {
                                            ...(prev[char.id] || {}),
                                            [st.stageNumber]: val
                                          }
                                        }));
                                      }}
                                      className="w-14 bg-transparent text-xs font-mono font-bold text-amber-300 outline-none text-right"
                                    />
                                  </div>

                                  <button
                                    type="button"
                                    onClick={() => handleSaveStageCoins(char.id, st.stageNumber)}
                                    className="p-1 rounded-md bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-cairo cursor-pointer"
                                    title={isAr ? 'تحديث العملات' : 'Update Coins'}
                                  >
                                    <Check size={13} />
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* ---------------------------------------------------- */}
                {/* SECTION 2: 3-DAY SPECIAL RANDOM REWARD POOL           */}
                {/* ---------------------------------------------------- */}
                <div className="p-4 sm:p-5 rounded-2xl bg-white/[0.02] border border-cyan-500/25 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
                    <div className="flex items-center gap-2">
                      <Gift size={16} className="text-cyan-400" />
                      <div>
                        <h5 className="font-cairo font-bold text-xs sm:text-sm text-cyan-200 flex items-center gap-2">
                          <span>{isAr ? 'مستودع السحب الخاص (كل 3 أيام)' : '3-Day Special Random Reward Pool'}</span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
                            {editingRewards.filter(r => r.isActive).length} {isAr ? 'جوائز نشطة' : 'active rewards'}
                          </span>
                        </h5>
                        <p className="font-cairo text-[11px] text-slate-400">
                          {isAr
                            ? 'يتم السحب حصراً وبشكل آمن من العناصر والحزم التي تختارها هنا. لا يتم توليد أي مكافأة غير معرّفة.'
                            : 'Awards are strictly rolled server-side from eligible items/packages you configure below.'}
                        </p>
                      </div>
                    </div>

                    {/* Timer Cycle Setting */}
                    <div className="flex items-center gap-2 bg-slate-900/80 p-2 rounded-xl border border-white/10">
                      <Clock size={14} className="text-cyan-400 shrink-0" />
                      <span className="text-xs font-cairo text-slate-300 shrink-0">
                        {isAr ? 'دورة التكرار:' : 'Cycle:'}
                      </span>
                      <input
                        type="number"
                        min="1"
                        max="720"
                        value={editingCycleHours}
                        onChange={(e) => setEditingCycleHours(parseInt(e.target.value) || 72)}
                        className="w-14 px-1.5 py-0.5 rounded bg-black/60 border border-cyan-500/40 text-xs font-mono text-cyan-300 text-center"
                      />
                      <span className="text-xs font-cairo text-slate-400">
                        {isAr ? 'ساعة (افتراضي: 72س = 3 أيام)' : 'h (3 Days)'}
                      </span>
                    </div>
                  </div>

                  {/* Add New Reward Quick Toolbar */}
                  <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 space-y-3">
                    <span className="text-xs font-cairo font-bold text-slate-300 block">
                      {isAr ? 'إضافة عناصر وحزم جديدة إلى مستودع السحب:' : 'Add Eligible Packages or Items to Pool:'}
                    </span>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {/* Add Card Package */}
                      <div className="flex items-center gap-2 bg-slate-900/60 p-2 rounded-lg border border-white/10">
                        <Package size={14} className="text-amber-400 shrink-0" />
                        <select
                          value={selectedPackageToAdd}
                          onChange={(e) => setSelectedPackageToAdd(e.target.value as CardRarity)}
                          className="flex-1 min-w-0 bg-transparent text-xs font-cairo text-white outline-none cursor-pointer"
                        >
                          {PACK_OPTIONS.map(p => (
                            <option key={p.id} value={p.id} className="bg-slate-900 text-white">
                              {isAr ? p.nameAr : p.nameEn}
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          onClick={handleAddPackageReward}
                          className="px-2.5 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-200 text-xs font-cairo font-bold flex items-center gap-1 cursor-pointer shrink-0"
                        >
                          <Plus size={12} />
                          <span>{isAr ? 'إضافة حزمة' : 'Add Pack'}</span>
                        </button>
                      </div>

                      {/* Add Gift Item from Catalog */}
                      <div className="flex items-center gap-2 bg-slate-900/60 p-2 rounded-lg border border-white/10">
                        <Gift size={14} className="text-pink-400 shrink-0" />
                        <select
                          value={selectedItemToAdd}
                          onChange={(e) => setSelectedItemToAdd(e.target.value)}
                          className="flex-1 min-w-0 bg-transparent text-xs font-cairo text-white outline-none cursor-pointer"
                        >
                          {items.map(i => (
                            <option key={i.id} value={i.id} className="bg-slate-900 text-white">
                              {isAr ? i.nameAr : i.name} ({i.rarity})
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          onClick={handleAddItemReward}
                          className="px-2.5 py-1 rounded bg-pink-500/20 hover:bg-pink-500/30 border border-pink-400/40 text-pink-200 text-xs font-cairo font-bold flex items-center gap-1 cursor-pointer shrink-0"
                        >
                          <Plus size={12} />
                          <span>{isAr ? 'إضافة هدية' : 'Add Item'}</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Active Rewards List */}
                  <div className="space-y-2.5">
                    {(() => {
                      const totalWeight = editingRewards
                        .filter(r => r.isActive)
                        .reduce((sum, r) => sum + (r.dropWeight || 0), 0);

                      return (
                        <>
                          <div className="flex items-center justify-between text-xs font-cairo text-slate-400 px-1">
                            <span>
                              {isAr ? 'العناصر المسجلة ونسب احتمال السحب:' : 'Configured Rewards & Probabilities:'}
                            </span>
                            <span className="font-mono text-cyan-300">
                              {isAr ? 'مجموع الأوزان:' : 'Total Weight:'} {totalWeight}
                            </span>
                          </div>

                          {editingRewards.length === 0 ? (
                            <div className="p-6 rounded-xl border border-dashed border-white/10 text-center font-cairo text-xs text-slate-500">
                              {isAr ? 'لا توجد مكافآت مسجلة في السحب. قم بإضافة حزمة أو هدية أعلاه.' : 'No rewards in pool. Add a card pack or item above.'}
                            </div>
                          ) : (
                            <div className="space-y-2">
                              {editingRewards.map(reward => {
                                const dropPercent = totalWeight > 0 && reward.isActive
                                  ? ((reward.dropWeight / totalWeight) * 100).toFixed(1)
                                  : '0';

                                const rarityColor =
                                  reward.rarity === 'LEGENDARY' ? 'text-amber-400 border-amber-500/40 bg-amber-500/10' :
                                  reward.rarity === 'EPIC' ? 'text-purple-400 border-purple-500/40 bg-purple-500/10' :
                                  reward.rarity === 'RARE' ? 'text-cyan-400 border-cyan-500/40 bg-cyan-500/10' :
                                  reward.rarity === 'UNCOMMON' ? 'text-emerald-400 border-emerald-500/40 bg-emerald-500/10' :
                                  'text-slate-300 border-slate-500/40 bg-slate-500/10';

                                return (
                                  <div
                                    key={reward.id}
                                    className={`p-3 rounded-xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                                      reward.isActive
                                        ? 'bg-black/50 border-white/15'
                                        : 'bg-black/20 border-white/5 opacity-50'
                                    }`}
                                  >
                                    {/* Left: Type, Name, Rarity */}
                                    <div className="flex items-center gap-3 min-w-0 flex-1">
                                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border ${
                                        reward.type === 'PACKAGE'
                                          ? 'bg-amber-500/20 border-amber-400/40 text-amber-300'
                                          : 'bg-pink-500/20 border-pink-400/40 text-pink-300'
                                      }`}>
                                        {reward.type === 'PACKAGE' ? <Package size={15} /> : <Gift size={15} />}
                                      </div>

                                      <div className="min-w-0 flex-1">
                                        <div className="flex items-center gap-2">
                                          <input
                                            type="text"
                                            value={isAr ? (reward.nameAr || reward.name) : reward.name}
                                            onChange={(e) => {
                                              if (isAr) {
                                                handleUpdateRewardField(reward.id, { nameAr: e.target.value });
                                              } else {
                                                handleUpdateRewardField(reward.id, { name: e.target.value });
                                              }
                                            }}
                                            className="bg-transparent font-cairo font-bold text-xs text-white outline-none border-b border-transparent hover:border-white/20 focus:border-cyan-400 px-0.5 truncate"
                                          />
                                          <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded border uppercase font-bold shrink-0 ${rarityColor}`}>
                                            {reward.rarity}
                                          </span>
                                        </div>
                                        <span className="text-[10px] font-mono text-slate-400 block mt-0.5">
                                          {reward.type === 'PACKAGE' ? `Pack ID: ${reward.packageId}` : `Item ID: ${reward.itemId}`}
                                        </span>
                                      </div>
                                    </div>

                                    {/* Middle: Probabilities & Bonus Coins */}
                                    <div className="flex flex-wrap items-center gap-3 shrink-0">
                                      {/* Rarity Selector */}
                                      <div className="flex items-center gap-1">
                                        <select
                                          value={reward.rarity}
                                          onChange={(e) => handleUpdateRewardField(reward.id, { rarity: e.target.value as CardRarity })}
                                          className="px-2 py-1 rounded bg-slate-900 border border-slate-700 text-[11px] font-mono text-slate-200 outline-none cursor-pointer"
                                        >
                                          <option value="COMMON">COMMON</option>
                                          <option value="UNCOMMON">UNCOMMON</option>
                                          <option value="RARE">RARE</option>
                                          <option value="EPIC">EPIC</option>
                                          <option value="LEGENDARY">LEGENDARY</option>
                                        </select>
                                      </div>

                                      {/* Drop Weight & % Chance */}
                                      <div className="flex items-center gap-1.5 bg-slate-900 px-2.5 py-1 rounded-lg border border-cyan-500/30">
                                        <span className="text-[10px] font-cairo text-slate-400">
                                          {isAr ? 'الوزن:' : 'Weight:'}
                                        </span>
                                        <input
                                          type="number"
                                          min="1"
                                          max="500"
                                          value={reward.dropWeight}
                                          onChange={(e) => handleUpdateRewardField(reward.id, { dropWeight: parseInt(e.target.value) || 1 })}
                                          className="w-12 bg-black/50 text-center text-xs font-mono font-bold text-cyan-300 rounded border border-white/10"
                                        />
                                        <span className="font-mono text-[11px] font-bold text-emerald-400 px-1">
                                          {dropPercent}%
                                        </span>
                                      </div>

                                      {/* Bonus Coins */}
                                      <div className="flex items-center gap-1 bg-slate-900 px-2 py-1 rounded-lg border border-amber-500/30">
                                        <Coins size={12} className="text-amber-400" />
                                        <input
                                          type="number"
                                          min="0"
                                          step="25"
                                          value={reward.bonusCoins || 0}
                                          onChange={(e) => handleUpdateRewardField(reward.id, { bonusCoins: parseInt(e.target.value) || 0 })}
                                          className="w-14 bg-black/50 text-center text-xs font-mono font-bold text-amber-300 rounded border border-white/10"
                                          placeholder="Coins"
                                          title={isAr ? 'عملات إضافية' : 'Bonus Coins'}
                                        />
                                      </div>

                                      {/* Active Switch */}
                                      <button
                                        type="button"
                                        onClick={() => handleToggleRewardActive(reward.id)}
                                        className={`px-2 py-1 rounded text-[11px] font-cairo font-bold cursor-pointer transition-colors ${
                                          reward.isActive
                                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                                        }`}
                                      >
                                        {reward.isActive ? (isAr ? 'مفعّل' : 'Active') : (isAr ? 'معطّل' : 'Disabled')}
                                      </button>

                                      {/* Delete */}
                                      <button
                                        type="button"
                                        onClick={() => handleDeleteReward(reward.id)}
                                        className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 cursor-pointer"
                                        title={isAr ? 'حذف المكافأة' : 'Delete reward'}
                                      >
                                        <Trash2 size={14} />
                                      </button>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </>
                      );
                    })()}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: ITEM STUDIO & PACKAGE INTEGRATION */}
            {activeTab === 'items' && (
              <div className="space-y-6">
                {!editingItem ? (
                  <>
                    <div className="flex items-center justify-between">
                      <h4 className="font-cairo font-bold text-sm text-slate-200">
                        {isAr ? 'الهدايا المسجلة وربط الحزم' : 'Gift Items & Pack Distribution'} ({items.length})
                      </h4>
                      <button
                        type="button"
                        onClick={handleStartNewItem}
                        className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-white font-cairo font-bold text-xs shadow-md shadow-rose-500/20 flex items-center gap-1.5 cursor-pointer"
                      >
                        <Plus size={14} />
                        <span>{isAr ? 'إنشاء هدية جديدة' : 'Create Custom Item'}</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                      {items.map(item => {
                        const targetChar = characters.find(c => c.id === item.targetCharacterId);
                        return (
                          <div
                            key={item.id}
                            className="rounded-2xl p-4 bg-white/[0.03] border border-white/10 flex flex-col justify-between hover:border-white/20 transition-all"
                          >
                            <div className="flex items-start gap-3">
                              <img
                                src={item.imageUrl}
                                alt={item.name}
                                className="w-14 h-14 rounded-xl object-contain bg-slate-900 border border-white/10 p-1 shrink-0"
                              />
                              <div className="min-w-0 flex-1">
                                <span className="text-[10px] font-mono font-bold text-amber-400 uppercase">
                                  {item.rarity}
                                </span>
                                <h5 className="font-cairo font-bold text-xs text-white truncate">
                                  {isAr ? item.nameAr : item.name}
                                </h5>
                                <div className="text-[11px] font-mono text-rose-300 mt-1 flex items-center gap-1">
                                  <Heart size={11} className="fill-rose-300" />
                                  +{item.lovePoints} Love Pts
                                </div>
                                <span className="text-[10px] font-cairo text-slate-400 block truncate mt-0.5">
                                  {isAr ? 'تعشقها:' : 'Lover:'} {item.targetCharacterId === 'ANY' ? (isAr ? 'الجميع' : 'Universal') : (targetChar?.nameAr || targetChar?.name || item.targetCharacterId)}
                                </span>
                              </div>
                            </div>

                            <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                              <button
                                type="button"
                                onClick={() => setEditingItem({ ...item })}
                                className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-cairo font-semibold text-white transition-colors cursor-pointer"
                              >
                                {isAr ? 'تعديل الخصائص' : 'Edit Item'}
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  if (window.confirm(isAr ? 'هل تريد حذف هذه الهدية؟' : 'Delete item?')) {
                                    ownerDeleteItem(item.id);
                                  }
                                }}
                                className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer"
                              >
                                <Trash2 size={15} />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </>
                ) : (
                  /* Item Editing Form */
                  <div className="space-y-5 bg-white/[0.02] p-5 rounded-2xl border border-white/10">
                    <div className="flex items-center justify-between border-b border-white/10 pb-3">
                      <h4 className="font-cairo font-bold text-sm text-amber-300 flex items-center gap-2">
                        <Gift size={16} />
                        <span>{isAr ? 'تخصيص الهدية والحزم الموزعة منها' : 'Configure Custom Gift & Packages'}</span>
                      </h4>
                      <button
                        type="button"
                        onClick={() => setEditingItem(null)}
                        className="text-xs font-cairo text-slate-400 hover:text-white"
                      >
                        {isAr ? 'إلغاء' : 'Cancel'}
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1">
                          {isAr ? 'اسم الهدية بالعربية' : 'Arabic Item Name'}
                        </label>
                        <input
                          type="text"
                          value={editingItem.nameAr || ''}
                          onChange={(e) => setEditingItem({ ...editingItem, nameAr: e.target.value })}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                          placeholder="مثال: قلادة اللازورد الملكية"
                        />
                      </div>

                      <div>
                        <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1">
                          {isAr ? 'اسم الهدية بالإنجليزية' : 'English Item Name'}
                        </label>
                        <input
                          type="text"
                          value={editingItem.name || ''}
                          onChange={(e) => setEditingItem({ ...editingItem, name: e.target.value })}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                          placeholder="e.g. Royal Lapis Pendant"
                        />
                      </div>

                      <div>
                        <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1">
                          {isAr ? 'الشخصية التي تعشق هذه الهدية' : 'Which Character Loves It?'}
                        </label>
                        <select
                          value={editingItem.targetCharacterId || 'ANY'}
                          onChange={(e) => setEditingItem({ ...editingItem, targetCharacterId: e.target.value })}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                        >
                          <option value="ANY">{isAr ? 'جميع الشخصيات (هدية عالمية)' : 'All Companions (Universal)'}</option>
                          {characters.map(c => (
                            <option key={c.id} value={c.id}>{isAr ? c.nameAr : c.name}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1">
                          {isAr ? 'نقاط المحبة الممنوحة (Love Points)' : 'Love Points Awarded'}
                        </label>
                        <input
                          type="number"
                          min="5"
                          max="2000"
                          step="5"
                          value={editingItem.lovePoints || 50}
                          onChange={(e) => setEditingItem({ ...editingItem, lovePoints: parseInt(e.target.value) || 50 })}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1">
                          {isAr ? 'درجة الندرة (Rarity)' : 'Rarity Tier'}
                        </label>
                        <select
                          value={editingItem.rarity || 'RARE'}
                          onChange={(e) => setEditingItem({ ...editingItem, rarity: e.target.value as any })}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                        >
                          <option value="COMMON">COMMON (شائع)</option>
                          <option value="UNCOMMON">UNCOMMON (غير شائع)</option>
                          <option value="RARE">RARE (نادر)</option>
                          <option value="EPIC">EPIC (ملحمي)</option>
                          <option value="LEGENDARY">LEGENDARY (أسطوري)</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1">
                          {isAr ? 'صورة الهدية (رفع PNG أو رابط)' : 'Item PNG Image'}
                        </label>
                        <div className="flex gap-2">
                          <input
                            ref={itemFileInputRef}
                            type="file"
                            accept="image/*"
                            onChange={handleItemFileUpload}
                            className="hidden"
                          />
                          <button
                            type="button"
                            onClick={() => itemFileInputRef.current?.click()}
                            className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-cairo font-semibold flex items-center gap-1.5 cursor-pointer"
                          >
                            <Upload size={13} />
                            <span>{isAr ? 'رفع PNG' : 'Upload'}</span>
                          </button>
                          <input
                            type="text"
                            value={editingItem.imageUrl || ''}
                            onChange={(e) => setEditingItem({ ...editingItem, imageUrl: e.target.value })}
                            placeholder="URL..."
                            className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs font-mono text-white"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Integrated Existing Packages Selection */}
                    <div className="space-y-2 pt-3 border-t border-white/10">
                      <label className="text-xs font-cairo font-bold text-amber-300 block">
                        {isAr 
                          ? 'أي الحزم الحالية تحتوي على هذه الهدية ويمكن إسقاطها منها؟' 
                          : 'Which Existing Booster Packs Contain This Item?'}
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {PACK_OPTIONS.map(pack => {
                          const isChecked = editingItem.packages?.includes(pack.id);
                          return (
                            <label
                              key={pack.id}
                              className={`p-3 rounded-xl border flex items-center gap-3 cursor-pointer transition-colors ${
                                isChecked
                                  ? 'bg-amber-950/40 border-amber-500/60 text-white'
                                  : 'bg-black/20 border-white/10 text-slate-400 hover:text-white'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={isChecked}
                                onChange={(e) => {
                                  const cur = editingItem.packages || [];
                                  const next = e.target.checked
                                    ? [...cur, pack.id]
                                    : cur.filter(p => p !== pack.id);
                                  setEditingItem({ ...editingItem, packages: next });
                                }}
                                className="rounded accent-amber-400 w-4 h-4 cursor-pointer"
                              />
                              <span className="font-cairo text-xs font-medium">
                                {isAr ? pack.nameAr : pack.nameEn}
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                      <button
                        type="button"
                        onClick={() => setEditingItem(null)}
                        className="px-4 py-2 rounded-xl text-xs font-cairo text-slate-400 hover:text-white"
                      >
                        {isAr ? 'إلغاء' : 'Cancel'}
                      </button>
                      <button
                        type="button"
                        disabled={isSaving}
                        onClick={handleSaveItemSubmit}
                        className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-white font-cairo font-bold text-xs shadow-lg shadow-rose-500/25 flex items-center gap-2 cursor-pointer disabled:opacity-50"
                      >
                        {isSaving ? <RefreshCw size={14} className="animate-spin" /> : <Save size={14} />}
                        <span>{isAr ? 'حفظ الهدية' : 'Save Item'}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: MANUAL ADJUSTER */}
            {activeTab === 'adjust' && (
              <div className="space-y-6 max-w-xl mx-auto">
                <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs font-cairo leading-relaxed flex items-center gap-2">
                  <Sliders size={18} className="shrink-0 text-amber-400" />
                  <span>
                    {isAr
                      ? 'يمكنك كمالك للسيرفر تعديل مستوى ونقاط محبة أي شخصية مباشرة لتجربة المراحل والمظاهر فوراً'
                      : 'As the Owner, you can manually set character love levels and points to immediately test all appearances and stages.'}
                  </span>
                </div>

                <div className="space-y-4 bg-white/[0.03] p-5 rounded-2xl border border-white/10">
                  <div>
                    <label className="text-xs font-cairo font-semibold text-slate-300 block mb-1.5">
                      {isAr ? 'اختر الشخصية المستهدفة' : 'Select Target Character'}
                    </label>
                    <select
                      value={adjustTargetCharId}
                      onChange={(e) => {
                        setAdjustTargetCharId(e.target.value);
                        const p = userProgress[e.target.value];
                        if (p) {
                          setAdjustLevel(p.level || 1);
                          setAdjustLovePoints(p.lovePoints || 0);
                        }
                      }}
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                    >
                      {characters.map(c => (
                        <option key={c.id} value={c.id}>
                          {isAr ? c.nameAr : c.name} (Lv.{userProgress[c.id]?.level || 1})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-cairo mb-1.5">
                      <span className="text-slate-300 font-semibold">{isAr ? 'مستوى المحبة (Level)' : 'Love Level'}</span>
                      <span className="font-mono text-rose-400 font-bold">Level {adjustLevel}</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={adjustLevel}
                      onChange={(e) => setAdjustLevel(parseInt(e.target.value))}
                      className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-500"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-cairo mb-1.5">
                      <span className="text-slate-300 font-semibold">{isAr ? 'نقاط المحبة الإجمالية (Love Points)' : 'Love Points'}</span>
                      <span className="font-mono text-amber-400 font-bold">{adjustLovePoints} pts</span>
                    </div>
                    <input
                      type="number"
                      min="0"
                      max="10000"
                      step="50"
                      value={adjustLovePoints}
                      onChange={(e) => setAdjustLovePoints(parseInt(e.target.value) || 0)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white font-mono"
                    />
                  </div>

                  {/* Quick Preset Buttons */}
                  <div className="flex flex-wrap gap-2 pt-2">
                    {[
                      { label: isAr ? 'المستوى 1 (بداية)' : 'Lv.1 Reset', lvl: 1, pts: 0 },
                      { label: isAr ? 'المستوى 3 (مرحلة 2)' : 'Lv.3 Stage 2', lvl: 3, pts: 250 },
                      { label: isAr ? 'المستوى 5 (مرحلة 3)' : 'Lv.5 Stage 3', lvl: 5, pts: 800 },
                      { label: isAr ? 'المستوى 10 (أقصى مودة)' : 'Lv.10 Max Love', lvl: 10, pts: 5000 },
                    ].map((p, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => {
                          setAdjustLevel(p.lvl);
                          setAdjustLovePoints(p.pts);
                        }}
                        className="px-3 py-1 rounded-lg bg-white/5 hover:bg-white/15 border border-white/10 text-xs font-cairo text-slate-300 cursor-pointer"
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>

                  <button
                    type="button"
                    disabled={isSaving}
                    onClick={handleApplyManualAdjust}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-white font-cairo font-bold text-xs shadow-lg shadow-rose-500/25 flex items-center justify-center gap-2 cursor-pointer mt-4"
                  >
                    {isSaving ? <RefreshCw size={14} className="animate-spin" /> : <Check size={14} />}
                    <span>{isAr ? 'تطبيق التعديلات الآن' : 'Apply Manual Adjustments'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* TAB 4: THRESHOLDS CONFIG */}
            {activeTab === 'thresholds' && (
              <div className="space-y-4 max-w-2xl mx-auto">
                <div className="flex items-center justify-between">
                  <h4 className="font-cairo font-bold text-sm text-slate-200">
                    {isAr ? 'جدول متطلبات نقاط مستويات المحبة' : 'Love Level Thresholds Configuration'}
                  </h4>
                  <button
                    type="button"
                    disabled={isSaving}
                    onClick={handleSaveThresholdsSubmit}
                    className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 text-white font-cairo font-bold text-xs shadow-md shadow-rose-500/20 flex items-center gap-1.5 cursor-pointer"
                  >
                    <Save size={13} />
                    <span>{isAr ? 'حفظ الحدود' : 'Save Thresholds'}</span>
                  </button>
                </div>

                <div className="rounded-2xl border border-white/10 overflow-hidden bg-black/30">
                  <table className="w-full text-right text-xs font-cairo">
                    <thead className="bg-white/[0.04] text-slate-400 border-b border-white/10">
                      <tr>
                        <th className="p-3">{isAr ? 'المستوى' : 'Level'}</th>
                        <th className="p-3">{isAr ? 'النقاط المطلوبة' : 'Required Points'}</th>
                        <th className="p-3">{isAr ? 'لقب الرتبة (عربي)' : 'Rank Title (Ar)'}</th>
                        <th className="p-3">{isAr ? 'لقب الرتبة (إنجليزي)' : 'Rank Title (En)'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {editingThresholds.map((t, idx) => (
                        <tr key={t.level} className="hover:bg-white/[0.02]">
                          <td className="p-3 font-mono font-bold text-rose-400">Lv.{t.level}</td>
                          <td className="p-3">
                            <input
                              type="number"
                              min="0"
                              value={t.requiredPoints}
                              onChange={(e) => {
                                const next = [...editingThresholds];
                                next[idx] = { ...next[idx], requiredPoints: parseInt(e.target.value) || 0 };
                                setEditingThresholds(next);
                              }}
                              className="w-24 px-2 py-1 rounded bg-slate-900 border border-slate-700 text-xs font-mono text-white"
                            />
                          </td>
                          <td className="p-3">
                            <input
                              type="text"
                              value={t.titleAr}
                              onChange={(e) => {
                                const next = [...editingThresholds];
                                next[idx] = { ...next[idx], titleAr: e.target.value };
                                setEditingThresholds(next);
                              }}
                              className="w-full px-2 py-1 rounded bg-slate-900 border border-slate-700 text-xs text-white"
                            />
                          </td>
                          <td className="p-3">
                            <input
                              type="text"
                              value={t.titleEn}
                              onChange={(e) => {
                                const next = [...editingThresholds];
                                next[idx] = { ...next[idx], titleEn: e.target.value };
                                setEditingThresholds(next);
                              }}
                              className="w-full px-2 py-1 rounded bg-slate-900 border border-slate-700 text-xs text-white"
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
