import React, { useState, useRef, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Heart,
  Sparkles,
  Flame,
  Coins,
  Gift,
  Clock,
  CheckCircle2,
  AlertCircle,
  Zap,
  Hand
} from 'lucide-react';
import {
  CharacterDefinition,
  CharacterStage,
  UserCharacterProgress,
  LoveLevelThreshold,
  LoveItemDefinition,
  UserLoveItemOwnership,
  calculateLevelFromPoints
} from '../../types/characterLove';
import { useLanguage } from '../../context/LanguageContext';
import { useCharacterLove } from '../../context/CharacterLoveContext';
import { useCards } from '../../context/CardContext';
import {
  buildMaskImageStyle,
  preloadImages,
  preloadCharacterAudio,
  playRandomCharacterSound
} from '../../utils/characterImageEffects';

interface CharacterLoveDisplayProps {
  character: CharacterDefinition;
  progress: UserCharacterProgress;
  activeStage: CharacterStage;
  thresholds: LoveLevelThreshold[];
  isMesopotamian?: boolean;
  items?: LoveItemDefinition[];
  inventory?: Record<string, UserLoveItemOwnership>;
  onGiveGift?: (characterId: string, itemId: string, count?: number) => Promise<any>;
}

interface HeartParticle {
  id: number;
  x: number;
  y: number;
  size: number;
  rotation: number;
}

export const CharacterLoveDisplay: React.FC<CharacterLoveDisplayProps> = ({
  character,
  progress,
  activeStage,
  thresholds,
  isMesopotamian = false,
  items = [],
  inventory = {},
  onGiveGift
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const containerRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState<{ x: number; y: number; glareX: number; glareY: number }>({
    x: 0,
    y: 0,
    glareX: 50,
    glareY: 50
  });
  const [isInteracting, setIsInteracting] = useState<boolean>(false);
  const [heartParticles, setHeartParticles] = useState<HeartParticle[]>([]);
  const [isPetted, setIsPetted] = useState<boolean>(false);

  // Character Love & Card Context Hooks
  const {
    claimPassiveCoins,
    claimSpecialReward,
    specialRewardsConfig,
    isClaimingCoins,
    isClaimingSpecialReward
  } = useCharacterLove();
  const { refreshProfile } = useCards();

  // 12-Hour Passive Coin Cooldown State
  const [timeRemainingMs, setTimeRemainingMs] = useState<number>(0);
  const [claimSuccessMessage, setClaimSuccessMessage] = useState<string | null>(null);
  const [claimErrorMessage, setClaimErrorMessage] = useState<string | null>(null);

  // 3-Day Special Reward Cooldown State
  const [specialTimeRemainingMs, setSpecialTimeRemainingMs] = useState<number>(0);
  const specialCycleHours = specialRewardsConfig?.cycleHours || 72;
  const totalSpecialCycleMs = specialCycleHours * 60 * 60 * 1000;

  // Click Transformation State
  const [isTransformed, setIsTransformed] = useState<boolean>(false);
  const transformTimerRef = useRef<any>(null);

  // Random Sound consecutive repeat prevention ref
  const lastPlayedSoundIdRef = useRef<string | null>(null);

  // Drag-to-Feed Mechanic State
  const [draggingItem, setDraggingItem] = useState<{ id: string; name: string; nameAr: string; imageUrl: string; lovePoints: number } | null>(null);
  const [dragPos, setDragPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isNearMouth, setIsNearMouth] = useState<boolean>(false);
  const [feedFeedback, setFeedFeedback] = useState<string | null>(null);

  // 1-Second Hold-to-Drag States with Smooth Touch-Scroll Detection
  const [holdingItemId, setHoldingItemId] = useState<string | null>(null);
  const [holdProgress, setHoldProgress] = useState<number>(0);
  const holdTimerRef = useRef<any>(null);
  const holdIntervalRef = useRef<any>(null);
  const touchStartPosRef = useRef<{ x: number; y: number } | null>(null);
  const isScrollingGestureRef = useRef<boolean>(false);

  const startHoldingItem = (item: { id: string; name: string; nameAr: string; imageUrl: string; lovePoints: number }, clientX: number, clientY: number) => {
    isScrollingGestureRef.current = false;
    touchStartPosRef.current = { x: clientX, y: clientY };
    setHoldingItemId(item.id);
    setHoldProgress(0);

    const startTime = Date.now();
    const duration = 1000; // 1 second

    if (holdTimerRef.current) clearTimeout(holdTimerRef.current);
    if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);

    holdIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(100, (elapsed / duration) * 100);
      setHoldProgress(progress);
    }, 25);

    holdTimerRef.current = setTimeout(() => {
      if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
      setDraggingItem(item);
      setDragPos({ x: clientX, y: clientY });
      setHoldingItemId(null);
      setHoldProgress(0);
    }, duration);
  };

  const cancelHoldingItem = () => {
    if (holdTimerRef.current) {
      clearTimeout(holdTimerRef.current);
      holdTimerRef.current = null;
    }
    if (holdIntervalRef.current) {
      clearInterval(holdIntervalRef.current);
      holdIntervalRef.current = null;
    }
    setHoldingItemId(null);
    setHoldProgress(0);
  };

  const handleItemTouchMove = (e: React.TouchEvent) => {
    if (!touchStartPosRef.current || !holdingItemId) return;
    const touch = e.touches[0];
    const dx = Math.abs(touch.clientX - touchStartPosRef.current.x);
    const dy = Math.abs(touch.clientY - touchStartPosRef.current.y);
    if (dx > 7 || dy > 7) {
      // User is scrolling the food items horizontally/vertically! Cancel hold immediately
      isScrollingGestureRef.current = true;
      cancelHoldingItem();
      touchStartPosRef.current = null;
    }
  };

  const handleItemMouseMove = (e: React.MouseEvent) => {
    if (!touchStartPosRef.current || !holdingItemId) return;
    const dx = Math.abs(e.clientX - touchStartPosRef.current.x);
    const dy = Math.abs(e.clientY - touchStartPosRef.current.y);
    if (dx > 10 || dy > 10) {
      cancelHoldingItem();
      touchStartPosRef.current = null;
    }
  };

  // Images to display
  const normalImg = activeStage?.imageUrl || character.avatarUrl;
  const alternateImg = character.clickTransform?.enabled && character.clickTransform?.imageUrl
    ? character.clickTransform.imageUrl
    : null;

  // Preload both images and all audio clips immediately
  useEffect(() => {
    preloadImages([normalImg, alternateImg, character.avatarUrl]);
    preloadCharacterAudio(character.audioConfig);
  }, [normalImg, alternateImg, character.avatarUrl, character.audioConfig]);

  // Reset transformation state on character switch
  useEffect(() => {
    setIsTransformed(false);
    if (transformTimerRef.current) {
      clearTimeout(transformTimerRef.current);
      transformTimerRef.current = null;
    }
  }, [character.id]);

  // 12-Hour Passive Coin Cooldown Timer Calculation
  useEffect(() => {
    const checkCooldown = () => {
      if (!progress.lastPassiveCoinClaimAt) {
        setTimeRemainingMs(0);
        return;
      }
      const lastClaimTime = new Date(progress.lastPassiveCoinClaimAt).getTime();
      const elapsed = Date.now() - lastClaimTime;
      const cooldownMs = 12 * 60 * 60 * 1000; // 12 hours
      const remaining = Math.max(0, cooldownMs - elapsed);
      setTimeRemainingMs(remaining);
    };

    checkCooldown();
    const interval = setInterval(checkCooldown, 1000);
    return () => clearInterval(interval);
  }, [progress.lastPassiveCoinClaimAt]);

  const isCoinClaimReady = timeRemainingMs <= 0;
  const hours = Math.floor(timeRemainingMs / (1000 * 60 * 60));
  const minutes = Math.floor((timeRemainingMs % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((timeRemainingMs % (1000 * 60)) / 1000);
  const countdownFormatted = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  const total12hMs = 12 * 60 * 60 * 1000;
  const percentElapsed = Math.min(100, Math.max(0, ((total12hMs - timeRemainingMs) / total12hMs) * 100));

  // 3-Day Special Reward Cooldown Timer Calculation
  useEffect(() => {
    const checkSpecialCooldown = () => {
      if (!progress.lastSpecialRewardClaimAt) {
        setSpecialTimeRemainingMs(0);
        return;
      }
      const lastClaimTime = new Date(progress.lastSpecialRewardClaimAt).getTime();
      const elapsed = Date.now() - lastClaimTime;
      const remaining = Math.max(0, totalSpecialCycleMs - elapsed);
      setSpecialTimeRemainingMs(remaining);
    };

    checkSpecialCooldown();
    const interval = setInterval(checkSpecialCooldown, 1000);
    return () => clearInterval(interval);
  }, [progress.lastSpecialRewardClaimAt, totalSpecialCycleMs]);

  const isSpecialRewardReady = specialTimeRemainingMs <= 0;
  const specHours = Math.floor(specialTimeRemainingMs / (1000 * 60 * 60));
  const specMinutes = Math.floor((specialTimeRemainingMs % (1000 * 60 * 60)) / (1000 * 60));
  const specSeconds = Math.floor((specialTimeRemainingMs % (1000 * 60)) / 1000);
  const specialCountdownFormatted = `${String(specHours).padStart(2, '0')}:${String(specMinutes).padStart(2, '0')}:${String(specSeconds).padStart(2, '0')}`;
  const specialPercentElapsed = Math.min(100, Math.max(0, ((totalSpecialCycleMs - specialTimeRemainingMs) / totalSpecialCycleMs) * 100));

  const stageCoinReward = typeof activeStage.passiveCoinReward === 'number'
    ? activeStage.passiveCoinReward
    : (activeStage.stageNumber * 50);

  // Claim Passive Coins Handler
  const handleClaimPassiveCoins = async () => {
    if (!isCoinClaimReady || isClaimingCoins) return;
    setClaimErrorMessage(null);
    try {
      const res = await claimPassiveCoins(character.id);
      await refreshProfile();
      setClaimSuccessMessage(
        isAr
          ? `+${res.coinsAwarded} عملة ذهبية جُمعت من ${character.nameAr}!`
          : `+${res.coinsAwarded} Coins Collected from ${character.name}!`
      );
      setTimeout(() => setClaimSuccessMessage(null), 4500);
    } catch (err: any) {
      const errMsg = err?.message || '';
      if (errMsg.includes('Cooldown is active')) {
        setClaimErrorMessage(isAr ? 'فترة الانتظار (12 ساعة) لا تزال نشطة!' : '12-hour cooldown is still active!');
      } else {
        setClaimErrorMessage(err?.message || (isAr ? 'فشل جمع العملات' : 'Failed to collect coins'));
      }
      setTimeout(() => setClaimErrorMessage(null), 4000);
    }
  };

  // Claim 3-Day Special Reward Handler
  const handleClaimSpecialReward = async () => {
    if (!isSpecialRewardReady || isClaimingSpecialReward) return;
    try {
      await claimSpecialReward(character.id);
      await refreshProfile();
    } catch (err: any) {
      console.error('Failed to claim special reward:', err);
    }
  };

  // 3D Tilt Glare calculation
  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotateX = ((y - centerY) / centerY) * -10;
    const rotateY = ((x - centerX) / centerX) * 10;
    const glareX = Math.max(0, Math.min(100, (x / rect.width) * 100));
    const glareY = Math.max(0, Math.min(100, (y / rect.height) * 100));

    setTilt({ x: rotateX, y: rotateY, glareX, glareY });

    if (draggingItem) {
      setDragPos({ x: e.clientX, y: e.clientY });
      checkMouthProximity(e.clientX, e.clientY);
    }
  }, [draggingItem, character, activeStage]);

  const handleTouchMove = useCallback((e: React.TouchEvent<HTMLDivElement>) => {
    if (!draggingItem || e.touches.length === 0) return;
    const touch = e.touches[0];
    setDragPos({ x: touch.clientX, y: touch.clientY });
    checkMouthProximity(touch.clientX, touch.clientY);
  }, [draggingItem, character, activeStage]);

  const checkMouthProximity = (clientX: number, clientY: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    
    const mouthOffsetX = character.mouthX ?? activeStage?.mouthX ?? 0;
    const mouthOffsetY = character.mouthY ?? activeStage?.mouthY ?? -60;
    const mouthScreenX = rect.left + rect.width / 2 + mouthOffsetX;
    const mouthScreenY = rect.top + rect.height * 0.35 + mouthOffsetY;

    const distance = Math.hypot(clientX - mouthScreenX, clientY - mouthScreenY);
    setIsNearMouth(distance < 75);
  };

  const handleInteractionStart = () => setIsInteracting(true);

  const handleInteractionEnd = useCallback(() => {
    setIsInteracting(false);
    setTilt({ x: 0, y: 0, glareX: 50, glareY: 50 });

    if (draggingItem && !window.PointerEvent) {
      if (isNearMouth) {
        executeFeed(draggingItem.id, draggingItem.name, draggingItem.nameAr, draggingItem.lovePoints);
      }
      setDraggingItem(null);
      setIsNearMouth(false);
    }
  }, [draggingItem, isNearMouth, character, activeStage]);

  // Global window listeners so dragged item follows cursor/finger anywhere as long as holding press
  useEffect(() => {
    if (!draggingItem && !holdingItemId) return;

    const handleWindowMouseMove = (e: MouseEvent) => {
      if (draggingItem) {
        setDragPos({ x: e.clientX, y: e.clientY });
        checkMouthProximity(e.clientX, e.clientY);
      }
    };

    const handleWindowTouchMove = (e: TouchEvent) => {
      if (draggingItem && e.touches.length > 0) {
        const touch = e.touches[0];
        setDragPos({ x: touch.clientX, y: touch.clientY });
        checkMouthProximity(touch.clientX, touch.clientY);
      }
    };

    const handleWindowMouseUp = () => {
      cancelHoldingItem();
      if (draggingItem) {
        if (isNearMouth) {
          executeFeed(draggingItem.id, draggingItem.name, draggingItem.nameAr, draggingItem.lovePoints);
        }
        setDraggingItem(null);
        setIsNearMouth(false);
      }
    };

    const handleWindowTouchEnd = () => {
      cancelHoldingItem();
      if (draggingItem) {
        if (isNearMouth) {
          executeFeed(draggingItem.id, draggingItem.name, draggingItem.nameAr, draggingItem.lovePoints);
        }
        setDraggingItem(null);
        setIsNearMouth(false);
      }
    };

    window.addEventListener('mousemove', handleWindowMouseMove);
    window.addEventListener('mouseup', handleWindowMouseUp);
    window.addEventListener('touchmove', handleWindowTouchMove);
    window.addEventListener('touchend', handleWindowTouchEnd);

    return () => {
      window.removeEventListener('mousemove', handleWindowMouseMove);
      window.removeEventListener('mouseup', handleWindowMouseUp);
      window.removeEventListener('touchmove', handleWindowTouchMove);
      window.removeEventListener('touchend', handleWindowTouchEnd);
    };
  }, [draggingItem, holdingItemId, isNearMouth, character, activeStage]);

  // Execute Feeding Action (shared by Drag-to-Feed and Tap-to-Feed)
  const executeFeed = async (itemId: string, itemName: string, itemNameAr: string, lovePoints: number) => {
    if (character.audioConfig?.enabled) {
      const res = playRandomCharacterSound(character.audioConfig, lastPlayedSoundIdRef.current);
      if (res.playedId) {
        lastPlayedSoundIdRef.current = res.playedId;
      }
    }

    if (character.clickTransform?.enabled && character.clickTransform?.imageUrl) {
      setIsTransformed(true);
      if (transformTimerRef.current) clearTimeout(transformTimerRef.current);
      const duration = character.clickTransform.durationMs || 1200;
      transformTimerRef.current = setTimeout(() => {
        setIsTransformed(false);
        transformTimerRef.current = null;
      }, duration);
    }

    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const mouthXCoord = rect.width / 2 + (character.mouthX ?? activeStage?.mouthX ?? 0);
      const mouthYCoord = rect.height * 0.35 + (character.mouthY ?? activeStage?.mouthY ?? -60);
      const newParticles: HeartParticle[] = Array.from({ length: 9 }).map((_, i) => ({
        id: Date.now() + i + Math.random(),
        x: mouthXCoord + (Math.random() * 60 - 30),
        y: mouthYCoord + (Math.random() * 40 - 20),
        size: Math.random() * 16 + 16,
        rotation: Math.random() * 40 - 20
      }));
      setHeartParticles(prev => [...prev.slice(-14), ...newParticles]);
      setTimeout(() => {
        setHeartParticles(prev => prev.filter(p => !newParticles.some(np => np.id === p.id)));
      }, 1500);
    }

    setFeedFeedback(isAr ? `أكلت "${itemNameAr}"! +${lovePoints} مودة ❤️` : `Ate "${itemName}"! +${lovePoints} Love ❤️`);
    setTimeout(() => setFeedFeedback(null), 3000);

    if (onGiveGift) {
      try {
        await onGiveGift(character.id, itemId, 1);
        await refreshProfile();
      } catch (err) {
        console.error('Failed to give item:', err);
      }
    }
  };

  const handleCharacterClick = (e: React.MouseEvent<HTMLDivElement>) => {
    setIsPetted(true);
    setTimeout(() => setIsPetted(false), 200);

    if (character.audioConfig?.enabled) {
      const res = playRandomCharacterSound(character.audioConfig, lastPlayedSoundIdRef.current);
      if (res.playedId) {
        lastPlayedSoundIdRef.current = res.playedId;
      }
    }

    if (character.clickTransform?.enabled && character.clickTransform?.imageUrl) {
      const mode = character.clickTransform.mode || 'timed';
      if (mode === 'toggle') {
        setIsTransformed(prev => !prev);
      } else {
        setIsTransformed(true);
        if (transformTimerRef.current) clearTimeout(transformTimerRef.current);
        const duration = character.clickTransform.durationMs || 1200;
        transformTimerRef.current = setTimeout(() => {
          setIsTransformed(false);
          transformTimerRef.current = null;
        }, duration);
      }
    }

    let startX = 200;
    let startY = 220;
    if (containerRef.current && e.clientX !== undefined && e.clientY !== undefined) {
      const rect = containerRef.current.getBoundingClientRect();
      startX = e.clientX - rect.left;
      startY = e.clientY - rect.top;
    }

    const newParticles: HeartParticle[] = Array.from({ length: 7 }).map((_, i) => ({
      id: Date.now() + i + Math.random(),
      x: startX + (Math.random() * 60 - 30),
      y: startY + (Math.random() * 40 - 20),
      size: Math.random() * 16 + 14,
      rotation: Math.random() * 40 - 20
    }));

    setHeartParticles(prev => [...prev.slice(-14), ...newParticles]);
    setTimeout(() => {
      setHeartParticles(prev => prev.filter(p => !newParticles.some(np => np.id === p.id)));
    }, 1400);
  };

  const themeColor = character.themeColor || (isMesopotamian ? '#f59e0b' : '#5eead4');

  const scale = character.scale || 1.0;
  const offsetX = character.offsetX || 0;
  const offsetY = character.offsetY || 0;
  const isClipped = character.overflowMode === 'clipped';

  const cardHeightPx = character.cardHeight || 480;
  const cardMaxW = character.cardWidth ? `${character.cardWidth}px` : undefined;

  let characterZIndex = 20;
  if (character.layering === 'behind_pedestal') {
    characterZIndex = 8;
  } else if (character.layering === 'front') {
    characterZIndex = 35;
  } else if (typeof character.zIndex === 'number') {
    characterZIndex = character.zIndex;
  }

  const maskStyle = buildMaskImageStyle(character.gradientFade);

  const customWidth = character.imageWidth && character.imageWidth !== 'auto'
    ? (typeof character.imageWidth === 'number' ? `${character.imageWidth}px` : character.imageWidth)
    : undefined;

  const customHeight = character.imageHeight && character.imageHeight !== 'auto'
    ? (typeof character.imageHeight === 'number' ? `${character.imageHeight}px` : character.imageHeight)
    : undefined;

  const ownedItemsList = Object.values(inventory || {}).filter(Boolean) as UserLoveItemOwnership[];
  const displayItems = ownedItemsList.length > 0
    ? ownedItemsList.map(inv => {
        const itemDef = items.find(i => i.id === inv.itemId);
        return {
          id: inv.itemId,
          name: itemDef?.name || inv.itemData?.name || 'Gift',
          nameAr: itemDef?.nameAr || inv.itemData?.nameAr || 'هدية',
          imageUrl: itemDef?.imageUrl || inv.itemData?.imageUrl || 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=150&auto=format&fit=crop&q=80',
          lovePoints: itemDef?.lovePoints || 50,
          count: inv.count
        };
      })
    : items.slice(0, 6).map(item => ({
        id: item.id,
        name: item.name,
        nameAr: item.nameAr,
        imageUrl: item.imageUrl,
        lovePoints: item.lovePoints,
        count: 99
      }));

  return (
    <div className="w-full flex flex-col items-center">
      {/* ======================================================== */}
      {/* 3D SHOWCASE VIEWPORT (Synchronized with Card Dimensions)  */}
      {/* ======================================================== */}
      <div
        className="relative w-full pt-6 pb-2 px-1 flex flex-col items-center"
        style={{ maxWidth: cardMaxW || '460px' }}
      >
        <div
          ref={containerRef}
          onMouseMove={handleMouseMove}
          onMouseEnter={handleInteractionStart}
          onMouseLeave={handleInteractionEnd}
          onTouchStart={handleInteractionStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleInteractionEnd}
          onMouseUp={handleInteractionEnd}
          onClick={handleCharacterClick}
          style={{
            perspective: 1400,
            height: `${cardHeightPx}px`
          }}
          className={`relative w-full cursor-pointer select-none group touch-manipulation ${
            isClipped ? 'overflow-hidden rounded-[2.5rem]' : 'overflow-visible'
          }`}
        >
          {/* LAYER 1: CARD SLAB */}
          <motion.div
            animate={{
              rotateX: tilt.x * 0.85,
              rotateY: tilt.y * 0.85,
              scale: isInteracting ? 1.015 : 1
            }}
            transition={{ type: 'spring', stiffness: 300, damping: 28 }}
            style={{ transformStyle: 'preserve-3d' }}
            className={`absolute inset-0 rounded-[2.5rem] border transition-colors duration-500 overflow-hidden shadow-2xl ${
              isMesopotamian
                ? 'bg-gradient-to-b from-[#1f1207]/95 via-[#120803]/98 to-[#090401] border-amber-500/50 shadow-[0_20px_50px_rgba(0,0,0,0.85),0_0_40px_rgba(245,158,11,0.2),inset_0_1px_2px_rgba(255,215,0,0.35)]'
                : 'bg-gradient-to-b from-[#062428]/95 via-[#03171a]/98 to-[#010e10] border-[#5eead4]/40 shadow-[0_20px_50px_rgba(0,0,0,0.85),0_0_40px_rgba(94,234,212,0.22),inset_0_1px_2px_rgba(94,234,212,0.4)]'
            }`}
          >
            <div
              className="absolute top-[35%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-[360px] h-[360px] rounded-full blur-[100px] pointer-events-none transition-all duration-700"
              style={{
                backgroundColor: themeColor,
                opacity: isInteracting ? 0.65 : 0.45
              }}
            />
            <div
              className="absolute inset-0 opacity-[0.07] pointer-events-none"
              style={{
                backgroundImage: isMesopotamian
                  ? 'radial-gradient(circle at 50% 50%, #f59e0b 1px, transparent 1px)'
                  : 'radial-gradient(circle at 50% 50%, #5eead4 1px, transparent 1px)',
                backgroundSize: '24px 24px'
              }}
            />
            <div className={`absolute inset-3 rounded-[2rem] border pointer-events-none ${
              isMesopotamian
                ? 'border-amber-500/20 shadow-[inset_0_0_20px_rgba(245,158,11,0.1)]'
                : 'border-[#5eead4]/15 shadow-[inset_0_0_20px_rgba(94,234,212,0.08)]'
            }`} />
          </motion.div>

          {/* LAYER 2: RAISED OVAL PLATFORM */}
          <motion.div
            animate={{
              rotateX: tilt.x * 0.95,
              rotateY: tilt.y * 0.95,
              y: isInteracting ? -2 : 0
            }}
            transition={{ type: 'spring', stiffness: 300, damping: 28 }}
            style={{ transformStyle: 'preserve-3d', zIndex: 10 }}
            className="absolute bottom-8 left-1/2 -translate-x-1/2 w-[82%] sm:w-[80%] max-w-[340px] pointer-events-none flex flex-col items-center"
          >
            <div
              className="absolute -bottom-4 w-[110%] h-14 rounded-[100%] blur-xl opacity-80"
              style={{
                background: 'radial-gradient(ellipse at center, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.6) 45%, transparent 75%)'
              }}
            />
            <div className="relative w-full h-12 flex flex-col items-center justify-end">
              <div
                className={`w-full h-8 rounded-[100%] border-b-2 shadow-2xl ${
                  isMesopotamian
                    ? 'bg-gradient-to-b from-[#2e190b] via-[#1a0e05] to-[#0c0602] border-amber-600/60 shadow-[0_10px_25px_rgba(0,0,0,0.9)]'
                    : 'bg-gradient-to-b from-[#09353a] via-[#052125] to-[#021113] border-[#2dd4bf]/60 shadow-[0_10px_25px_rgba(0,0,0,0.9)]'
                }`}
              />
              <div
                className={`absolute top-0 w-full h-11 rounded-[100%] border-2 flex items-center justify-center overflow-hidden shadow-inner ${
                  isMesopotamian
                    ? 'bg-gradient-to-b from-[#452713] via-[#2c1709] to-[#160b04] border-amber-400/80 shadow-[0_0_20px_rgba(245,158,11,0.4)]'
                    : 'bg-gradient-to-b from-[#0f4f56] via-[#072f34] to-[#031c1f] border-[#5eead4]/80 shadow-[0_0_25px_rgba(94,234,212,0.45)]'
                }`}
              >
                <div
                  className={`w-[84%] h-[72%] rounded-[100%] border border-dashed opacity-60 ${
                    isMesopotamian ? 'border-amber-300' : 'border-[#5eead4]'
                  }`}
                />
              </div>
            </div>
          </motion.div>

          {/* MOUTH DROP-ZONE TARGET */}
          <div
            className="absolute left-1/2 pointer-events-none transition-all duration-300 flex items-center justify-center"
            style={{
              top: `calc(35% + ${character.mouthY ?? activeStage?.mouthY ?? -60}px)`,
              transform: `translate(calc(-50% + ${character.mouthX ?? activeStage?.mouthX ?? 0}px), -50%)`,
              zIndex: characterZIndex + 5
            }}
          >
            <div
              className={`rounded-full transition-all duration-300 flex items-center justify-center ${
                isNearMouth
                  ? 'w-16 h-16 bg-rose-500/30 border-2 border-rose-400 shadow-[0_0_25px_rgba(244,63,94,0.8)] scale-125 animate-pulse'
                  : draggingItem
                    ? 'w-12 h-12 bg-white/10 border border-white/30 shadow-[0_0_15px_rgba(255,255,255,0.3)] animate-bounce'
                    : 'w-4 h-4 opacity-0'
              }`}
            >
              {isNearMouth && <Heart size={20} className="text-rose-300 fill-rose-400 animate-ping" />}
            </div>
          </div>

          {/* LAYER 3: SYNCHRONIZED CHARACTER IMAGES (FIXED SIZING & PLACEMENT) */}
          <div
            className={`absolute inset-0 pointer-events-none flex items-end justify-center ${
              isClipped ? 'overflow-hidden' : 'overflow-visible'
            }`}
            style={{ zIndex: characterZIndex }}
          >
            <motion.div
              animate={{
                scale: scale,
                x: offsetX,
                y: offsetY,
                rotateX: tilt.x * 1.25,
                rotateY: tilt.y * 1.25
              }}
              transition={{ type: 'spring', stiffness: 280, damping: 26 }}
              style={{ transformStyle: 'preserve-3d' }}
              className={`relative w-full h-full flex items-end justify-center ${
                isClipped ? 'overflow-hidden' : 'overflow-visible'
              }`}
            >
              <div
                className={`relative w-full flex items-end justify-center ${
                  isClipped ? 'overflow-hidden' : 'overflow-visible'
                } pb-8`}
              >
                <div
                  className="relative flex items-end justify-center pointer-events-none select-none"
                  style={{
                    transform: 'translateZ(50px)',
                    width: customWidth || 'auto',
                    height: customHeight || '130%',
                    maxWidth: '100%',
                    maxHeight: `${cardHeightPx * 1.25}px`
                  }}
                >
                  {normalImg && (
                    <img
                      src={normalImg}
                      alt={character.name}
                      className="max-h-full max-w-full object-contain object-bottom pointer-events-none select-none filter drop-shadow-[0_20px_35px_rgba(0,0,0,0.85)] drop-shadow-[0_5px_12px_rgba(0,0,0,0.6)] will-change-[opacity]"
                      style={{
                        opacity: isTransformed && alternateImg ? 0 : 1,
                        transition: 'opacity 100ms ease-in-out',
                        ...maskStyle
                      }}
                    />
                  )}

                  {alternateImg && (
                    <img
                      src={alternateImg}
                      alt={`${character.name} alternate`}
                      className="absolute inset-x-0 bottom-0 m-auto max-h-full max-w-full object-contain object-bottom pointer-events-none select-none filter drop-shadow-[0_20px_35px_rgba(0,0,0,0.85)] drop-shadow-[0_5px_12px_rgba(0,0,0,0.6)] will-change-[opacity]"
                      style={{
                        opacity: isTransformed ? 1 : 0,
                        transition: 'opacity 100ms ease-in-out',
                        ...maskStyle
                      }}
                    />
                  )}
                </div>
              </div>
            </motion.div>
          </div>

          {/* FLOATING HEART PARTICLES & FEEDBACK */}
          <AnimatePresence>
            {heartParticles.map(p => (
              <motion.div
                key={p.id}
                initial={{ opacity: 1, scale: 0.5, y: 0, x: 0 }}
                animate={{ opacity: 0, scale: 1.4, y: -90, x: (Math.random() - 0.5) * 50 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1.2, ease: 'easeOut' }}
                style={{
                  position: 'absolute',
                  left: `${p.x}px`,
                  top: `${p.y}px`,
                  zIndex: 45,
                  pointerEvents: 'none'
                }}
              >
                <Heart size={p.size} className="text-rose-400 fill-rose-500 drop-shadow-[0_2px_8px_rgba(244,63,94,0.6)]" />
              </motion.div>
            ))}
          </AnimatePresence>

          <AnimatePresence>
            {feedFeedback && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.8, y: -15 }}
                className="absolute top-4 inset-x-4 z-50 pointer-events-none flex justify-center"
              >
                <div className="px-4 py-2 rounded-2xl bg-rose-950/90 border border-rose-500/50 text-rose-200 font-cairo font-bold text-xs shadow-2xl backdrop-blur-md flex items-center gap-2">
                  <Heart size={15} className="text-rose-400 fill-rose-400 animate-pulse" />
                  <span>{feedFeedback}</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* ======================================================== */}
      {/* CUTE & PREMIUM COMPANION DEVOTION BAR + SQUARE BUTTONS    */}
      {/* ======================================================== */}
      {(() => {
        const safeLovePoints = typeof progress?.lovePoints === 'number' && !isNaN(progress.lovePoints)
          ? progress.lovePoints
          : Number(progress?.lovePoints) || 0;

        const currentLevelInfo = calculateLevelFromPoints(safeLovePoints, thresholds);
        const currentLevel = currentLevelInfo?.level || 1;

        let progressPercent = 0;
        if (typeof currentLevelInfo?.progressPercent === 'number' && !isNaN(currentLevelInfo.progressPercent)) {
          progressPercent = Math.min(100, Math.max(0, Math.round(currentLevelInfo.progressPercent)));
        } else {
          const nextPts = Number(currentLevelInfo?.nextThreshold?.requiredPoints) || 100;
          const prevPts = Number(currentLevelInfo?.currentThreshold?.requiredPoints) || 0;
          const diff = nextPts - prevPts;
          progressPercent = diff > 0 ? Math.min(100, Math.max(0, Math.round(((safeLovePoints - prevPts) / diff) * 100))) : 100;
        }

        const coinsWaitHours = Math.max(1, Math.ceil(timeRemainingMs / (1000 * 60 * 60)));
        const specialWaitHours = Math.max(1, Math.ceil(specialTimeRemainingMs / (1000 * 60 * 60)));

        return (
          <div className="w-full max-w-lg mt-3 sm:mt-4 px-2 flex flex-col gap-3">
            {/* Cute & Luxurious Devotion Bar (Full Width - Generous for Phone & Desktop) */}
            <div className="w-full rounded-2xl sm:rounded-3xl bg-gradient-to-b from-white/[0.09] via-black/90 to-[#0e0409]/95 border border-rose-400/40 shadow-[0_12px_35px_rgba(0,0,0,0.7),inset_0_1px_2px_rgba(255,255,255,0.18)] backdrop-blur-2xl p-3.5 sm:p-4 space-y-3 relative overflow-hidden">
              {/* Cute ambient glow */}
              <div className="absolute -top-6 left-1/4 w-40 h-20 bg-rose-500/25 blur-3xl pointer-events-none rounded-full" />

              {/* Cute Header: Level Badge on Left + Percentage on Right (No Numbers) */}
              <div className="flex items-center justify-between font-cairo">
                <div className="flex items-center gap-2.5">
                  <div className="relative flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-tr from-rose-500 via-pink-400 to-amber-300 p-0.5 shadow-[0_0_14px_rgba(244,63,94,0.6)] shrink-0">
                    <div className="w-full h-full rounded-full bg-black/80 flex items-center justify-center">
                      <Heart className="w-4 h-4 text-rose-300 fill-rose-400 animate-pulse" />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full bg-rose-500/25 text-rose-100 border border-rose-400/50 font-mono font-bold text-xs tracking-wider shadow-sm">
                      {isAr ? `المستوى ${currentLevel}` : `Lv.${currentLevel}`}
                    </span>
                    <span className="text-xs font-bold text-rose-300/80 hidden xs:inline">
                      {isAr ? 'مودة الرفيق' : 'Affection'}
                    </span>
                  </div>
                </div>

                {/* Percentage Badge Only (No Numbers) */}
                <div className="flex items-center">
                  <span className="px-3 py-1 rounded-full bg-gradient-to-r from-rose-500 via-pink-500 to-rose-500 text-white font-mono font-extrabold text-xs tracking-wider shadow-[0_0_14px_rgba(244,63,94,0.5)] border border-rose-300/40 flex items-center gap-1.5">
                    <Heart className="w-3.5 h-3.5 fill-white text-white animate-pulse" />
                    <span>{progressPercent}%</span>
                  </span>
                </div>
              </div>

              {/* Cute Jelly Bar Track with Progress Tip Heart */}
              <div className="w-full h-5 rounded-full bg-black/85 border border-white/15 p-0.5 relative overflow-hidden shadow-[inset_0_2px_6px_rgba(0,0,0,0.9)]">
                {/* Specular gloss reflection along top */}
                <div className="absolute inset-x-0 top-0 h-[48%] bg-gradient-to-b from-white/35 to-transparent rounded-t-full pointer-events-none z-10" />

                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-pink-400 via-rose-500 to-amber-400 relative overflow-hidden shadow-[0_0_18px_rgba(244,63,94,0.7)]"
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercent}%` }}
                  transition={{ type: 'spring', stiffness: 120, damping: 18 }}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent -skew-x-12 animate-pulse" />
                  {progressPercent > 5 && (
                    <div className="absolute right-0.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 rounded-full bg-white shadow-[0_0_8px_rgba(255,255,255,0.95)] flex items-center justify-center">
                      <Heart size={8} className="text-rose-500 fill-rose-500" />
                    </div>
                  )}
                </motion.div>
              </div>
            </div>

            {/* Quick Reward Square Action Buttons Row */}
            <div className="flex items-center justify-center gap-3.5">
              {/* 24-Hour Coins Square Button (Showing Hours Remaining) */}
              <button
                type="button"
                onClick={handleClaimPassiveCoins}
                disabled={!isCoinClaimReady || isClaimingCoins}
                className={`relative group w-16 h-16 aspect-square rounded-2xl border transition-all flex flex-col items-center justify-center shadow-xl cursor-pointer shrink-0 ${
                  isCoinClaimReady
                    ? isMesopotamian
                      ? 'bg-gradient-to-br from-amber-500/30 via-amber-600/40 to-black border-amber-400/80 shadow-[0_0_20px_rgba(245,158,11,0.5)] hover:scale-105 active:scale-95'
                      : 'bg-gradient-to-br from-teal-500/30 via-cyan-600/40 to-black border-teal-400/80 shadow-[0_0_20px_rgba(45,212,191,0.5)] hover:scale-105 active:scale-95'
                    : 'bg-black/60 border-white/10 opacity-70 cursor-not-allowed'
                }`}
                title={isAr ? 'هدية العملات الدورية' : 'Periodic Coins Gift'}
              >
                <div className="relative mb-0.5">
                  <Coins className={`w-5 h-5 ${isCoinClaimReady ? 'text-amber-300 drop-shadow-[0_0_10px_rgba(252,211,77,0.9)]' : 'text-slate-400'}`} />
                  {isCoinClaimReady && (
                    <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-teal-400 shadow-[0_0_8px_rgba(45,212,191,1)] animate-ping" />
                  )}
                </div>
                <span className={`px-1.5 py-0.2 rounded-md font-mono font-bold text-[10px] ${
                  isCoinClaimReady
                    ? 'bg-teal-500/30 text-teal-300 border border-teal-400/40 animate-pulse'
                    : 'bg-black/80 text-slate-300 border border-white/10'
                }`}>
                  {isCoinClaimReady ? (isAr ? 'جاهز' : 'READY') : `${coinsWaitHours}h`}
                </span>
              </button>

              {/* Random Gift Square Button (Showing Hours Remaining) */}
              <button
                type="button"
                onClick={handleClaimSpecialReward}
                disabled={!isSpecialRewardReady || isClaimingSpecialReward}
                className={`relative group w-16 h-16 aspect-square rounded-2xl border transition-all flex flex-col items-center justify-center shadow-xl cursor-pointer shrink-0 ${
                  isSpecialRewardReady
                    ? 'bg-gradient-to-br from-rose-500/30 via-pink-600/40 to-black border-rose-400/80 shadow-[0_0_20px_rgba(244,63,94,0.5)] hover:scale-105 active:scale-95'
                    : 'bg-black/60 border-white/10 opacity-70 cursor-not-allowed'
                }`}
                title={isAr ? 'هدية عشوائية خاصة' : 'Special Random Gift'}
              >
                <div className="relative mb-0.5">
                  <Sparkles className={`w-5 h-5 ${isSpecialRewardReady ? 'text-rose-300 drop-shadow-[0_0_10px_rgba(244,63,94,0.9)] animate-spin' : 'text-slate-400'}`} style={{ animationDuration: '6s' }} />
                  {isSpecialRewardReady && (
                    <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-rose-400 shadow-[0_0_8px_rgba(244,63,94,1)] animate-ping" />
                  )}
                </div>
                <span className={`px-1.5 py-0.2 rounded-md font-mono font-bold text-[10px] ${
                  isSpecialRewardReady
                    ? 'bg-rose-500/30 text-rose-300 border border-rose-400/40 animate-pulse'
                    : 'bg-black/80 text-slate-300 border border-white/10'
                }`}>
                  {isSpecialRewardReady ? (isAr ? 'جاهز' : 'READY') : `${specialWaitHours}h`}
                </span>
              </button>
            </div>
          </div>
        );
      })()}

      {/* Success / Error Banners */}
      {(claimSuccessMessage || claimErrorMessage) && (
        <div className="w-full max-w-lg mt-2 px-2">
          {claimSuccessMessage && (
            <div className="p-2.5 rounded-xl bg-teal-950/80 border border-teal-500/40 text-teal-200 text-xs font-cairo font-bold flex items-center gap-2 shadow-lg">
              <CheckCircle2 size={16} className="text-teal-400 shrink-0" />
              <span>{claimSuccessMessage}</span>
            </div>
          )}
          {claimErrorMessage && (
            <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-500/40 text-rose-200 text-xs font-cairo font-bold flex items-center gap-2 shadow-lg">
              <AlertCircle size={16} className="text-rose-400 shrink-0" />
              <span>{claimErrorMessage}</span>
            </div>
          )}
        </div>
      )}

      {/* ======================================================== */}
      {/* SIMPLIFIED, SMALL & ENHANCED FOOD ITEMS PANEL            */}
      {/* ======================================================== */}
      <div className="w-full max-w-lg mt-3 px-2 space-y-1.5">
        <div className="flex items-center justify-between px-1">
          <span className="font-cairo font-bold text-xs text-rose-300 flex items-center gap-1.5">
            <Gift size={13} className="text-rose-400" />
            <span>{isAr ? 'اسحب أو اضغط للإطعام:' : 'Drag or tap to feed:'}</span>
          </span>
          <span className="text-[10px] font-mono text-slate-400">
            {displayItems.length} {isAr ? 'عناصر' : 'Items'}
          </span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto touch-pan-x custom-scrollbar p-2 rounded-2xl bg-black/60 border border-white/10 backdrop-blur-xl select-none">
          {displayItems.map(item => {
            const isHolding = holdingItemId === item.id;

            return (
              <div
                key={item.id}
                onMouseDown={(e) => {
                  e.preventDefault();
                  startHoldingItem(item, e.clientX, e.clientY);
                }}
                onMouseMove={handleItemMouseMove}
                onMouseUp={cancelHoldingItem}
                onMouseLeave={cancelHoldingItem}
                onTouchStart={(e) => {
                  const touch = e.touches[0];
                  startHoldingItem(item, touch.clientX, touch.clientY);
                }}
                onTouchMove={handleItemTouchMove}
                onTouchEnd={cancelHoldingItem}
                onClick={() => {
                  if (isScrollingGestureRef.current) {
                    isScrollingGestureRef.current = false;
                    return;
                  }
                  executeFeed(item.id, item.name, item.nameAr, item.lovePoints);
                }}
                className={`relative group flex flex-col items-center justify-center p-2 rounded-xl border transition-all cursor-pointer select-none touch-pan-x shrink-0 w-[72px] ${
                  isHolding
                    ? 'bg-rose-950/80 border-rose-400 shadow-[0_0_15px_rgba(244,63,94,0.4)] scale-95'
                    : 'bg-white/[0.04] border-white/10 hover:border-rose-400/50 hover:bg-white/[0.08]'
                }`}
                title={isAr ? `${item.nameAr} (+${item.lovePoints})` : `${item.name} (+${item.lovePoints})`}
              >
                {/* Hold Progress Fill */}
                {isHolding && (
                  <div className="absolute inset-0 rounded-xl overflow-hidden pointer-events-none border-2 border-rose-400">
                    <div
                      className="absolute bottom-0 inset-x-0 bg-rose-400/25 transition-all duration-75"
                      style={{ height: `${holdProgress}%` }}
                    />
                  </div>
                )}

                {/* Just the item image (small) */}
                <div className="w-10 h-10 rounded-lg bg-black/50 border border-white/10 p-1 flex items-center justify-center overflow-hidden mb-1 group-hover:scale-105 transition-transform">
                  <img
                    src={item.imageUrl}
                    alt={item.name}
                    className="w-full h-full object-contain pointer-events-none"
                  />
                </div>

                {/* The name (small) */}
                <span className="font-cairo font-bold text-[11px] text-white truncate max-w-[64px] text-center leading-tight">
                  {isAr ? item.nameAr : item.name}
                </span>

                {/* How much it gives (small) */}
                <span className="font-mono font-bold text-[10px] text-rose-300 mt-0.5">
                  +{item.lovePoints}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* DRAGGING ITEM GHOST (FOLLOWS CURSOR/FINGER SMOOTHLY ANYWHERE) */}
      {draggingItem && (
        <div
          style={{
            position: 'fixed',
            left: `${dragPos.x - 30}px`,
            top: `${dragPos.y - 30}px`,
            zIndex: 9999,
            pointerEvents: 'none'
          }}
          className="w-16 h-16 rounded-2xl bg-[#09262b]/95 border-2 border-rose-400 shadow-[0_15px_40px_rgba(244,63,94,0.7)] p-2 flex items-center justify-center animate-bounce backdrop-blur-md"
        >
          <img src={draggingItem.imageUrl} alt={draggingItem.name} className="w-full h-full object-contain" />
          <span className="absolute -bottom-6 px-2 py-0.5 rounded-full bg-black/90 text-[9px] font-mono text-rose-300 border border-rose-500/40 whitespace-nowrap shadow">
            {isAr ? 'افلت عند الفم 🎯' : 'Release at Mouth 🎯'}
          </span>
        </div>
      )}
    </div>
  );
};
