import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Heart, Gift, Sparkles, Package, Plus, Flame, Check, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import { LoveItemDefinition, UserLoveItemOwnership, CharacterDefinition } from '../../types/characterLove';
import { useLanguage } from '../../context/LanguageContext';
import { RARITY_SHOWCASE } from '../cards/PackOpeningModal';

interface CharacterLoveInventoryProps {
  items: LoveItemDefinition[];
  inventory: Record<string, UserLoveItemOwnership>;
  character: CharacterDefinition;
  onGiveGift: (characterId: string, itemId: string, count: number) => Promise<any>;
  isGivingGift: boolean;
  isMesopotamian?: boolean;
}

export const CharacterLoveInventory: React.FC<CharacterLoveInventoryProps> = ({
  items,
  inventory,
  character,
  onGiveGift,
  isGivingGift,
  isMesopotamian = false
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [giftQuantity, setGiftQuantity] = useState<number>(1);
  const [successAnimationItem, setSuccessAnimationItem] = useState<string | null>(null);

  // Split into owned items and unowned items
  const ownedItems = items.filter(it => (inventory[it.id]?.count || 0) > 0);
  const unownedItems = items.filter(it => (inventory[it.id]?.count || 0) === 0);

  const handleGive = async (item: LoveItemDefinition, qty = 1) => {
    if (isGivingGift) return;
    setSuccessAnimationItem(item.id);
    try {
      await onGiveGift(character.id, item.id, qty);
    } finally {
      setTimeout(() => {
        setSuccessAnimationItem(null);
      }, 1000);
    }
  };

  return (
    <div className="w-full space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between px-1">
        <div>
          <h3 className="font-cairo font-bold text-base text-white flex items-center gap-2">
            <Gift size={18} className="text-rose-400" />
            <span>{isAr ? 'حقيبة الهدايا ونفائس المودة' : 'Gifts & Affection Inventory'}</span>
          </h3>
          <p className="font-cairo text-xs text-slate-400">
            {isAr 
              ? 'أهدِ الشخصية عناصرها المفضلة لرفع مستوى المحبة وفتح مظاهر جديدة تلقائياً' 
              : 'Gift your companion items to earn Love Points and unlock new stage appearances'}
          </p>
        </div>

        <Link
          to="/cards"
          className="px-3 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/10 border border-white/10 text-xs font-cairo font-semibold text-teal-300 hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer shrink-0"
        >
          <Package size={14} />
          <span>{isAr ? 'احصل على هدايا من الحزم' : 'Get from Packs'}</span>
          <ExternalLink size={12} />
        </Link>
      </div>

      {/* Owned Gifts Section */}
      {ownedItems.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {ownedItems.map(item => {
            const count = inventory[item.id]?.count || 0;
            const isBeloved = (item.targetCharacterId === character.id || item.targetCharacterId === 'ANY' || (character.lovedItemIds?.includes(item.id)));
            const raritySpec = RARITY_SHOWCASE[item.rarity] || RARITY_SHOWCASE.COMMON;

            return (
              <motion.div
                key={item.id}
                whileHover={{ y: -2 }}
                className={`relative rounded-2xl p-3.5 border transition-all overflow-hidden flex flex-col justify-between ${
                  isBeloved
                    ? 'bg-gradient-to-br from-rose-950/40 via-[#140b10] to-purple-950/30 border-rose-500/50 shadow-[0_0_15px_rgba(244,63,94,0.18)]'
                    : 'bg-white/[0.03] border-white/10 hover:border-white/20'
                }`}
              >
                {/* Beloved Ribbon / Badge */}
                {isBeloved && (
                  <div className="absolute top-2.5 end-2.5 px-2 py-0.5 rounded-full text-[9px] font-cairo font-black bg-gradient-to-r from-rose-500 to-amber-500 text-white shadow-[0_0_10px_rgba(244,63,94,0.5)] flex items-center gap-1">
                    <Flame size={10} className="fill-white" />
                    <span>{isAr ? 'محبوبة جداً! (+35% نقاط)' : 'Beloved! (+35% Bonus)'}</span>
                  </div>
                )}

                {/* Top Info */}
                <div className="flex items-start gap-3">
                  <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-slate-900 border border-white/10 shrink-0 flex items-center justify-center p-1">
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      className="w-full h-full object-contain filter drop-shadow-md"
                    />
                    <span className="absolute bottom-1 end-1 px-1.5 py-0.2 rounded-md bg-black/80 font-mono font-bold text-[10px] text-white border border-white/20">
                      x{count}
                    </span>
                  </div>

                  <div className="min-w-0 flex-1 pe-16">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded font-mono border ${raritySpec.bright}`} style={{ color: raritySpec.accent, borderColor: raritySpec.accent }}>
                        {item.rarity}
                      </span>
                    </div>
                    <h4 className="font-cairo font-bold text-xs text-white truncate">
                      {isAr ? item.nameAr : item.name}
                    </h4>
                    <p className="font-cairo text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                      {isAr ? item.descriptionAr : item.description}
                    </p>
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1 text-xs font-mono font-bold text-rose-400">
                    <Heart size={13} className="fill-rose-400" />
                    <span>+{isBeloved ? Math.round(item.lovePoints * 1.35) : item.lovePoints} pts</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {count >= 5 && (
                      <button
                        type="button"
                        disabled={isGivingGift}
                        onClick={() => handleGive(item, 5)}
                        className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-[11px] font-cairo font-bold text-white transition-colors cursor-pointer disabled:opacity-50"
                      >
                        x5
                      </button>
                    )}
                    <button
                      type="button"
                      disabled={isGivingGift}
                      onClick={() => handleGive(item, 1)}
                      className={`px-3.5 py-1 rounded-xl text-xs font-cairo font-bold shadow-md transition-all flex items-center gap-1 cursor-pointer disabled:opacity-50 ${
                        isBeloved
                          ? 'bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-white shadow-rose-500/25'
                          : 'bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-400 hover:to-cyan-400 text-slate-950 shadow-cyan-500/25'
                      }`}
                    >
                      {successAnimationItem === item.id ? (
                        <Check size={13} />
                      ) : (
                        <Gift size={13} />
                      )}
                      <span>{isAr ? 'إهداء' : 'Give'}</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      ) : (
        <div className="p-8 rounded-3xl bg-white/[0.02] border border-white/10 text-center flex flex-col items-center justify-center">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-3">
            <Gift size={24} />
          </div>
          <h4 className="font-cairo font-bold text-sm text-white mb-1">
            {isAr ? 'حقيبة الهدايا فارغة حالياً' : 'Your Gift Inventory is Empty'}
          </h4>
          <p className="font-cairo text-xs text-slate-400 max-w-sm mb-4">
            {isAr 
              ? 'افتح حزم البطاقات من المتجر للحصول على هدايا نادرة للشخصيات' 
              : 'Open booster packs in the Card Vault shop to discover gifts for companions'}
          </p>
          <Link
            to="/cards"
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 text-white font-cairo font-bold text-xs shadow-lg shadow-rose-500/20 hover:scale-105 transition-transform flex items-center gap-2"
          >
            <Package size={15} />
            <span>{isAr ? 'الذهاب إلى متجر الحزم' : 'Go to Card Shop'}</span>
          </Link>
        </div>
      )}

      {/* Unowned Items Directory (Package Drop Source Guide) */}
      {unownedItems.length > 0 && (
        <div className="mt-6 pt-4 border-t border-white/10">
          <div className="flex items-center justify-between mb-3 px-1">
            <h4 className="font-cairo font-bold text-xs text-slate-400 flex items-center gap-1.5">
              <Package size={14} className="text-slate-500" />
              <span>{isAr ? 'هدايا يمكن الحصول عليها من الحزم:' : 'Gifts obtainable from Card Packs:'}</span>
            </h4>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-2.5">
            {unownedItems.map(item => {
              const isBeloved = (item.targetCharacterId === character.id || item.targetCharacterId === 'ANY' || (character.lovedItemIds?.includes(item.id)));
              const packsList = item.packages?.join(', ') || 'COMMON';

              return (
                <div
                  key={item.id}
                  className="rounded-xl p-2.5 bg-black/20 border border-white/[0.06] flex items-center gap-2 opacity-70 hover:opacity-100 transition-opacity"
                >
                  <img
                    src={item.imageUrl}
                    alt={item.name}
                    className="w-9 h-9 rounded-lg object-contain bg-slate-900/60 p-0.5 border border-white/10 shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <span className="font-cairo font-semibold text-[11px] text-slate-200 block truncate">
                      {isAr ? item.nameAr : item.name}
                    </span>
                    <span className="text-[9px] font-mono text-slate-400 block truncate">
                      Packs: {packsList}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
