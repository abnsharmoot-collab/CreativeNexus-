import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Gift,
  Sparkles,
  Coins,
  Heart,
  PackageCheck,
  X,
  Crown,
  ChevronRight
} from 'lucide-react';
import { TriggerRandomGiftResult } from '../../types/characterLove';
import { useLanguage } from '../../context/LanguageContext';
import { CardRarity } from '../../types/cards';

interface CharacterSurpriseGiftModalProps {
  data: TriggerRandomGiftResult | null;
  onClose: () => void;
  companionName?: string;
  companionNameAr?: string;
  companionImage?: string;
  isMesopotamian?: boolean;
}

const RARITY_THEMES: Record<CardRarity, { border: string; bg: string; text: string; glow: string; nameEn: string; nameAr: string }> = {
  COMMON: {
    border: 'border-slate-400/40',
    bg: 'from-slate-800/80 to-slate-950/90',
    text: 'text-slate-300',
    glow: 'rgba(148, 163, 184, 0.4)',
    nameEn: 'Common Favor',
    nameAr: 'هدية شائعة'
  },
  UNCOMMON: {
    border: 'border-emerald-500/50',
    bg: 'from-emerald-950/80 to-slate-950/90',
    text: 'text-emerald-400',
    glow: 'rgba(16, 185, 129, 0.45)',
    nameEn: 'Uncommon Treasure',
    nameAr: 'هدية غير شائعة'
  },
  RARE: {
    border: 'border-cyan-500/60',
    bg: 'from-cyan-950/80 to-slate-950/90',
    text: 'text-cyan-300',
    glow: 'rgba(6, 182, 212, 0.55)',
    nameEn: 'Rare Blessing',
    nameAr: 'بركة نادرة'
  },
  EPIC: {
    border: 'border-purple-500/70',
    bg: 'from-purple-950/80 to-slate-950/90',
    text: 'text-purple-300',
    glow: 'rgba(168, 85, 247, 0.65)',
    nameEn: 'Epic Relic',
    nameAr: 'أثر ملحمي نفيس'
  },
  LEGENDARY: {
    border: 'border-amber-400/80',
    bg: 'from-amber-950/80 to-slate-950/90',
    text: 'text-amber-300',
    glow: 'rgba(245, 158, 11, 0.75)',
    nameEn: 'Legendary Sovereign Treasure',
    nameAr: 'كنز سيادي أسطوري'
  },
  HALLOWEEN_2026: {
    border: 'border-orange-500/80',
    bg: 'from-orange-950/80 to-slate-950/90',
    text: 'text-orange-300',
    glow: 'rgba(249, 115, 22, 0.75)',
    nameEn: 'Halloween 2026 Event',
    nameAr: 'فعالية هالوين 2026'
  }
};

export const CharacterSurpriseGiftModal: React.FC<CharacterSurpriseGiftModalProps> = ({
  data,
  onClose,
  companionName = 'Companion',
  companionNameAr = 'الرفيقة',
  companionImage,
  isMesopotamian = false
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  if (!data || !data.giftDropped || !data.gift) return null;
  const gift = data.gift;
  const rarityTheme = RARITY_THEMES[gift.rarity || 'COMMON'] || RARITY_THEMES.COMMON;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/85 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.88, y: 25 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.88, y: 25 }}
          transition={{ type: 'spring', stiffness: 350, damping: 26 }}
          className="relative w-full max-w-lg rounded-3xl bg-[#071317] border border-pink-500/40 text-slate-100 shadow-[0_20px_70px_rgba(0,0,0,0.95)] overflow-hidden z-10 my-auto flex flex-col"
          style={{
            boxShadow: `0 0 50px ${rarityTheme.glow}, 0 20px 70px rgba(0,0,0,0.95)`
          }}
        >
          {/* Header Glow */}
          <div
            className="absolute -top-24 left-1/2 -translate-x-1/2 w-72 h-72 rounded-full blur-[80px] pointer-events-none opacity-50"
            style={{ backgroundColor: rarityTheme.glow }}
          />

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-black/40 border border-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X size={16} />
          </button>

          {/* Body Content */}
          <div className="relative z-10 p-6 sm:p-7 flex flex-col items-center text-center space-y-4">
            {/* Title & Badge */}
            <div className="space-y-1">
              <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-cairo font-bold border ${rarityTheme.border} ${rarityTheme.text} bg-black/40`}>
                <Sparkles size={13} className="animate-pulse" />
                <span>{isAr ? rarityTheme.nameAr : rarityTheme.nameEn}</span>
              </span>

              <h3 className="font-cairo font-black text-xl sm:text-2xl text-transparent bg-clip-text bg-gradient-to-r from-pink-300 via-rose-200 to-amber-300">
                {isAr ? 'هدية مفاجئة من الرفيقة!' : 'Surprise Gift from Companion!'}
              </h3>
              <p className="font-cairo text-xs text-slate-400">
                {isAr ? `قدمت لك ${companionNameAr} هذه الهدية امتناناً لمودتك الكريمة` : `${companionName} presented this gift in appreciation of your devotion`}
              </p>
            </div>

            {/* Gift Artwork Showcase */}
            <div className="relative my-2 flex items-center justify-center">
              <div
                className="absolute inset-0 rounded-full blur-2xl opacity-60"
                style={{ backgroundColor: rarityTheme.glow }}
              />

              <div className={`relative w-36 h-36 sm:w-40 sm:h-40 rounded-3xl bg-gradient-to-b ${rarityTheme.bg} border-2 ${rarityTheme.border} p-3 flex items-center justify-center shadow-2xl`}>
                <img
                  src={gift.imageUrl}
                  alt={gift.name}
                  className="w-full h-full object-contain filter drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)]"
                />

                {companionImage && (
                  <div className="absolute -bottom-2 -left-2 w-10 h-10 rounded-full border-2 border-pink-400 overflow-hidden bg-black/70 shadow-md">
                    <img src={companionImage} alt={companionName} className="w-full h-full object-cover object-top" />
                  </div>
                )}
              </div>
            </div>

            {/* Gift Names & Description */}
            <div className="space-y-1 max-w-sm">
              <h4 className="font-cairo font-bold text-base sm:text-lg text-white">
                {isAr ? gift.nameAr : gift.name}
              </h4>
              <p className="font-cairo text-xs text-slate-300 line-clamp-2">
                {isAr ? gift.descriptionAr : gift.description}
              </p>
            </div>

            {/* Rewards Breakdown Cards */}
            <div className="w-full grid grid-cols-2 sm:grid-cols-3 gap-2 pt-2">
              {/* Coins Awarded */}
              {typeof data.coinsAwarded === 'number' && data.coinsAwarded > 0 && (
                <div className="p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex flex-col items-center justify-center text-center">
                  <div className="flex items-center gap-1 text-amber-400 font-mono font-bold text-sm">
                    <Coins size={15} />
                    <span>+{data.coinsAwarded}</span>
                  </div>
                  <span className="font-cairo text-[11px] text-amber-200 mt-0.5">
                    {isAr ? 'عملة نقدية' : 'Coins'}
                  </span>
                </div>
              )}

              {/* Love Points Awarded */}
              {typeof data.lovePointsAwarded === 'number' && data.lovePointsAwarded > 0 && (
                <div className="p-2.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex flex-col items-center justify-center text-center">
                  <div className="flex items-center gap-1 text-rose-400 font-mono font-bold text-sm">
                    <Heart size={15} className="fill-rose-400" />
                    <span>+{data.lovePointsAwarded}</span>
                  </div>
                  <span className="font-cairo text-[11px] text-rose-200 mt-0.5">
                    {isAr ? 'نقاط محبة' : 'Love Points'}
                  </span>
                </div>
              )}

              {/* Inventory Item Storage */}
              <div className="p-2.5 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex flex-col items-center justify-center text-center col-span-2 sm:col-span-1">
                <div className="flex items-center gap-1 text-cyan-300 font-cairo font-bold text-xs">
                  <PackageCheck size={15} />
                  <span>{isAr ? 'في الحقيبة' : 'Stored'}</span>
                </div>
                <span className="font-cairo text-[11px] text-cyan-200 mt-0.5">
                  {isAr ? 'أضيفت لمخزونك' : 'Added to Inventory'}
                </span>
              </div>
            </div>

            {/* Action Button */}
            <div className="w-full pt-2">
              <button
                type="button"
                onClick={onClose}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-pink-500 via-rose-500 to-amber-500 hover:from-pink-400 hover:to-amber-400 text-white font-cairo font-bold text-sm shadow-lg shadow-pink-500/30 flex items-center justify-center gap-2 cursor-pointer transition-transform hover:scale-[1.02] active:scale-[0.98]"
              >
                <span>{isAr ? 'استلام الهدية والاحتفاظ بها' : 'Claim & Keep Gift'}</span>
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
