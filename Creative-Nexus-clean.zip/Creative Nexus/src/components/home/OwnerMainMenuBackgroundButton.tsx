import React from 'react';
import { motion } from 'motion/react';
import { Sliders, Crown } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { useMainMenuBackground } from '../../context/MainMenuBackgroundContext';
import { useEasterEggs } from '../../context/EasterEggContext';

export const OwnerMainMenuBackgroundButton: React.FC = () => {
  const { isOwner } = useAuth();
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { openEditModal, getBackgroundForTheme } = useMainMenuBackground();
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  const currentThemeBg = getBackgroundForTheme(activeTheme);

  if (!isOwner) {
    return null;
  }

  const handleOpen = () => {
    openEditModal(isMesopotamian ? 'kohan-iraqi' : 'creative-nexus');
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.5, duration: 0.4 }}
      className="inline-flex items-center"
    >
      <button
        type="button"
        onClick={handleOpen}
        title={
          isMesopotamian
            ? (isAr ? 'تخصيص خلفية ثيم كوهان المنفصلة (خاص بالمالك)' : 'Customize Kohan Theme Background (Owner Only)')
            : (isAr ? 'تخصيص خلفية القائمة الرئيسية (خاص بالمالك)' : 'Customize Main Menu Background (Owner Only)')
        }
        className={`group relative flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-cairo font-bold backdrop-blur-md transition-all duration-200 cursor-pointer ${
          isMesopotamian
            ? 'bg-[#18110b]/92 hover:bg-[#241a10] text-amber-300 hover:text-amber-100 border border-amber-500/40 hover:border-amber-400/80 shadow-[0_0_15px_rgba(245,158,11,0.2)] hover:shadow-[0_0_20px_rgba(245,158,11,0.35)]'
            : 'bg-[#07171a]/90 hover:bg-[#0c262c] text-cyan-300 hover:text-cyan-100 border border-cyan-500/40 hover:border-cyan-400/80 shadow-[0_0_15px_rgba(6,182,212,0.25)] hover:shadow-[0_0_20px_rgba(6,182,212,0.4)]'
        }`}
      >
        <span className="relative flex h-2 w-2">
          <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
            isMesopotamian ? 'bg-amber-400' : 'bg-cyan-400'
          }`} />
          <span className={`relative inline-flex rounded-full h-2 w-2 ${
            isMesopotamian ? 'bg-amber-500' : 'bg-cyan-500'
          }`} />
        </span>

        {isMesopotamian ? (
          <Crown size={13} className="text-amber-400 group-hover:rotate-12 transition-transform duration-300" />
        ) : (
          <Sliders size={13} className="text-cyan-400 group-hover:rotate-45 transition-transform duration-300" />
        )}

        <span>
          {isMesopotamian
            ? (isAr ? 'خلفية ثيم كوهان' : 'Kohan Background')
            : (isAr ? 'خلفية القائمة' : 'Menu Background')}
        </span>

        {currentThemeBg?.imageUrl && (
          <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono border ${
            isMesopotamian
              ? 'bg-amber-950/80 text-amber-200 border-amber-600/40'
              : 'bg-cyan-950 text-cyan-200 border-cyan-600/40'
          }`}>
            {currentThemeBg.blur || 0}px / {Math.round((currentThemeBg.opacity ?? 0.85) * 100)}%
          </span>
        )}
      </button>
    </motion.div>
  );
};
