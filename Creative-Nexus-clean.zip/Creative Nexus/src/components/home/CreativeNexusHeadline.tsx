import React from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { useSiteLogo } from '../../context/SiteLogoContext';
import { MinecraftSplashText } from './MinecraftSplashText';

export const CreativeNexusHeadline: React.FC = () => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';
  const { logoSettings } = useSiteLogo();

  // Unified title without word-by-word split
  const titleText = isAr
    ? (logoSettings.titleAr || 'مركز الإبداع')
    : (logoSettings.titleEn || 'Creative Nexus');

  return (
    <div className="relative group/headline flex flex-col items-center justify-center max-w-full w-full select-none">
      {/* Minecraft-Style Splash Text positioned on the upper-right */}
      <MinecraftSplashText />

      {/* 
        ========================================================================
        RESTORED 3D VOLUMETRIC AMBIENT LIGHTING & CELESTIAL DEPTH GLOW
        Guaranteed exact center behind text in both English (LTR) and Arabic (RTL)
        Rendered only in standard creative nexus theme; completely removed in Kohan theme
        to eliminate the orange floating overlay/glow moving with scrolling
        ========================================================================
      */}
      {/* 
        ========================================================================
        REBUILT 3D VOLUMETRIC BACKGROUND BEHIND SERVER NAME (THEME-SEPARATED)
        Guaranteed exact center behind text in both English (LTR) and Arabic (RTL)
        - In Creative Nexus: Cyan/Teal celestial aura
        - In Kohan's Theme: Imperial Mesopotamian golden relic halo & ancient aura
        ========================================================================
      */}
      {!isMesopotamian ? (
        <div 
          dir="ltr"
          className="absolute inset-0 flex items-center justify-center pointer-events-none select-none -z-10 overflow-visible"
          style={{ transform: 'translateZ(-40px)' }}
        >
          <div 
            className="w-[140%] max-w-4xl h-[320px] sm:h-[400px] rounded-full opacity-85 group-hover/headline:opacity-100 transition-opacity duration-700 shrink-0"
            style={{
              background: 'radial-gradient(circle at 50% 50%, rgba(94, 234, 212, 0.30) 0%, rgba(45, 212, 191, 0.16) 28%, rgba(13, 148, 136, 0.05) 50%, transparent 72%)',
              filter: 'blur(36px)',
            }}
          />
          <div 
            className="absolute w-[100%] max-w-2xl h-[200px] sm:h-[260px] rounded-full opacity-90 shrink-0"
            style={{
              background: 'radial-gradient(circle at 50% 50%, rgba(94, 234, 212, 0.40) 0%, rgba(20, 184, 166, 0.20) 32%, transparent 68%)',
              filter: 'blur(20px)',
            }}
          />
          <div 
            className="absolute w-4/5 max-w-xl h-28 rounded-full opacity-65 shrink-0"
            style={{
              background: 'radial-gradient(circle at 50% 50%, rgba(255, 255, 255, 0.26) 0%, rgba(94, 234, 212, 0.16) 40%, transparent 70%)',
              filter: 'blur(14px)',
            }}
          />
        </div>
      ) : null}

      {/* 
        ========================================================================
        CLEAN UNIFIED HEADLINE (NO WORD-BY-WORD ANIMATION, NO BARS)
        ========================================================================
      */}
      <h1 
        className={`relative font-black text-5xl min-[480px]:text-6xl sm:text-7xl md:text-8xl lg:text-9xl xl:text-[9.8rem] mb-3 sm:mb-5 leading-[1.06] tracking-tight ${
          isMesopotamian
            ? 'mesopotamian-chiseled-title font-meso-serif'
            : (isAr ? 'font-messiri' : 'font-display')
        }`}
        style={{
          transform: 'translateZ(75px)',
          textShadow: isMesopotamian
            ? '0 1px 0 #fffbeb, 0 3px 0 #d97706, 0 5px 0 #92400e, 0 8px 1px #451a03, 0 16px 28px rgba(0,0,0,0.9), 0 0 32px rgba(245,158,11,0.5)'
            : [
                '0 1px 0 rgba(255, 255, 255, 0.98)',
                '0 2px 0 rgba(224, 254, 247, 0.95)',
                '0 3px 0 #5eead4',
                '0 4px 0 #2dd4bf',
                '0 5px 0 #14b8a6',
                '0 6px 0 #0d9488',
                '0 7px 0 #0f766e',
                '0 8px 0 #115e59',
                '0 9px 1px #042f2e',
                '0 12px 3px rgba(0, 20, 20, 0.65)',
                '0 20px 40px rgba(0, 0, 0, 0.95)',
                '0 25px 50px rgba(0, 0, 0, 0.85)',
                '0 0 35px rgba(94, 234, 212, 0.55)',
                '0 0 65px rgba(45, 212, 191, 0.3)'
              ].join(', '),
        }}
      >
        <span
          className="relative z-10 block text-transparent bg-clip-text select-none"
          style={{
            backgroundImage: isMesopotamian
              ? 'linear-gradient(180deg, #fffbeb 0%, #fef3c7 20%, #f59e0b 55%, #d97706 82%, #b45309 100%)'
              : 'linear-gradient(180deg, #ffffff 0%, #e2fef7 22%, #5eead4 52%, #14b8a6 82%, #0f766e 100%)',
          }}
        >
          {titleText}
        </span>
      </h1>
    </div>
  );
};
