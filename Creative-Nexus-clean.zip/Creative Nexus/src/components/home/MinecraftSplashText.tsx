import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Edit2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { OwnerSplashManagerModal, SplashConfigData } from './OwnerSplashManagerModal';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../../lib/firebase';

const DEFAULT_SPLASH_TEXTS = [
  "Welcome to the Nexus!",
  "Also try Codex!",
  "Crafted with passion!",
  "Legends never fade!",
  "Sovereign Edgar approved!",
  "The Sanctuary Lives!",
  "Creeper? Aw man!",
  "100% Organic Energy!",
  "مركز الإبداع بلا حدود!",
  "سيرفر الأساطير!",
  "الذهب الحقيقي هو المجتمع!",
  "منذ 2023 وحتى الأبد!",
  "ابقَ مبدعاً!"
];

const LOCAL_STORAGE_KEY = 'creatine_nexus_splash_texts';
const LOCAL_STORAGE_CONFIG_KEY = 'creatine_nexus_splash_config';
const LAST_SPLASH_INDEX_KEY = 'creatine_nexus_last_splash_idx';

export const MinecraftSplashText: React.FC = () => {
  const { isOwner, user } = useAuth();
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const [sentences, setSentences] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      return saved ? JSON.parse(saved) : DEFAULT_SPLASH_TEXTS;
    } catch {
      return DEFAULT_SPLASH_TEXTS;
    }
  });

  const [angle, setAngle] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_CONFIG_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed.angle === 'number') return parsed.angle;
      }
    } catch {}
    return 45;
  });

  const [position, setPosition] = useState<string>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_CONFIG_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed.position === 'string') return parsed.position;
      }
    } catch {}
    return 'top-right';
  });

  const [offsetX, setOffsetX] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_CONFIG_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed.offsetX === 'number') return parsed.offsetX;
      }
    } catch {}
    return 0;
  });

  const [offsetY, setOffsetY] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_CONFIG_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed.offsetY === 'number') return parsed.offsetY;
      }
    } catch {}
    return 0;
  });

  const [size, setSize] = useState<'sm' | 'md' | 'lg' | 'xl'>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_CONFIG_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.size) return parsed.size;
      }
    } catch {}
    return 'md';
  });

  const [scale, setScale] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_CONFIG_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed.scale === 'number') return parsed.scale;
      }
    } catch {}
    return 1.0;
  });

  const [currentText, setCurrentText] = useState<string>('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [bounceTrigger, setBounceTrigger] = useState(0);

  // Pick a random sentence, avoiding immediately repeating the same one if multiple exist
  const pickRandomSentence = useCallback((list: string[]) => {
    if (!list || list.length === 0) return DEFAULT_SPLASH_TEXTS[0];
    if (list.length === 1) return list[0];

    let lastIdx = -1;
    try {
      const stored = sessionStorage.getItem(LAST_SPLASH_INDEX_KEY);
      if (stored !== null) lastIdx = parseInt(stored, 10);
    } catch {}

    let randomIdx = Math.floor(Math.random() * list.length);
    if (randomIdx === lastIdx) {
      randomIdx = (randomIdx + 1) % list.length;
    }

    try {
      sessionStorage.setItem(LAST_SPLASH_INDEX_KEY, String(randomIdx));
    } catch {}

    return list[randomIdx];
  }, []);

  // Fetch sentences and placement from server
  useEffect(() => {
    let isMounted = true;

    const fetchSplash = async () => {
      try {
        const res = await fetch('/api/settings/splash-texts');
        if (res.ok) {
          const data = await res.json();
          if (isMounted) {
            if (Array.isArray(data.splashTexts) && data.splashTexts.length > 0) {
              setSentences(data.splashTexts);
              try {
                localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data.splashTexts));
              } catch {}
              setCurrentText(pickRandomSentence(data.splashTexts));
            }
            if (typeof data.angle === 'number') setAngle(data.angle);
            if (typeof data.position === 'string') setPosition(data.position);
            if (typeof data.offsetX === 'number') setOffsetX(data.offsetX);
            if (typeof data.offsetY === 'number') setOffsetY(data.offsetY);
            if (typeof data.size === 'string') setSize(data.size);
            if (typeof data.scale === 'number') setScale(data.scale);

            try {
              localStorage.setItem(LOCAL_STORAGE_CONFIG_KEY, JSON.stringify({
                angle: data.angle,
                position: data.position,
                offsetX: data.offsetX,
                offsetY: data.offsetY,
                size: data.size,
                scale: data.scale
              }));
            } catch {}
          }
        }
      } catch (err) {
        console.warn('Could not fetch splash texts:', err);
      }
    };

    fetchSplash();

    // Firestore realtime listener
    if (db) {
      try {
        const unsub = onSnapshot(doc(db, 'site_settings', 'splash_texts'), (snapshot) => {
          if (snapshot.exists()) {
            const data = snapshot.data();
            if (isMounted) {
              if (Array.isArray(data.sentences) && data.sentences.length > 0) {
                setSentences(data.sentences);
                try {
                  localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data.sentences));
                } catch {}
              }
              if (typeof data.angle === 'number') setAngle(data.angle);
              if (typeof data.position === 'string') setPosition(data.position);
              if (typeof data.offsetX === 'number') setOffsetX(data.offsetX);
              if (typeof data.offsetY === 'number') setOffsetY(data.offsetY);
              if (typeof data.size === 'string') setSize(data.size);
              if (typeof data.scale === 'number') setScale(data.scale);

              try {
                localStorage.setItem(LOCAL_STORAGE_CONFIG_KEY, JSON.stringify({
                  angle: data.angle,
                  position: data.position,
                  offsetX: data.offsetX,
                  offsetY: data.offsetY,
                  size: data.size,
                  scale: data.scale
                }));
              } catch {}
            }
          }
        });
        return () => {
          isMounted = false;
          unsub();
        };
      } catch (e) {
        // Fallback
      }
    }

    return () => {
      isMounted = false;
    };
  }, [pickRandomSentence]);

  // Re-generate random splash whenever user logs in or auth state changes
  useEffect(() => {
    setCurrentText(pickRandomSentence(sentences));
  }, [user?.discordId, pickRandomSentence]);

  // Fallback initial currentText
  useEffect(() => {
    if (!currentText && sentences.length > 0) {
      setCurrentText(pickRandomSentence(sentences));
    }
  }, [currentText, sentences, pickRandomSentence]);

  // Clicking splash rolls a new one with a bounce
  const handleRollNext = () => {
    setBounceTrigger((prev) => prev + 1);
    setCurrentText(pickRandomSentence(sentences));
  };

  const handleSaveConfig = async (newConfig: SplashConfigData) => {
    // 1. Optimistic immediate state update
    const updatedSentences = newConfig.sentences && newConfig.sentences.length > 0 ? newConfig.sentences : sentences;
    setSentences(updatedSentences);
    if (typeof newConfig.angle === 'number') setAngle(newConfig.angle);
    if (typeof newConfig.position === 'string') setPosition(newConfig.position);
    if (typeof newConfig.offsetX === 'number') setOffsetX(newConfig.offsetX);
    if (typeof newConfig.offsetY === 'number') setOffsetY(newConfig.offsetY);
    if (newConfig.size) setSize(newConfig.size);
    if (typeof (newConfig as any).scale === 'number') setScale((newConfig as any).scale);

    // 2. Immediate persistent local storage update
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedSentences));
      localStorage.setItem(LOCAL_STORAGE_CONFIG_KEY, JSON.stringify({
        angle: newConfig.angle,
        position: newConfig.position,
        offsetX: newConfig.offsetX,
        offsetY: newConfig.offsetY,
        size: newConfig.size,
        scale: (newConfig as any).scale
      }));
    } catch (storageErr) {
      console.warn('LocalStorage save error:', storageErr);
    }

    // 3. Sync with backend API
    try {
      const res = await fetch('/api/settings/splash-texts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(newConfig),
      });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.splashTexts) && data.splashTexts.length > 0) {
          setSentences(data.splashTexts);
        }
      }
    } catch (err) {
      console.warn('Network sync notice (changes saved locally):', err);
    }

    setCurrentText(pickRandomSentence(updatedSentences));
    return true; // Always return true because local changes are guaranteed persisted!
  };

  // Detect if current splash contains Arabic characters
  const hasArabic = useMemo(() => {
    return /[\u0600-\u06FF]/.test(currentText);
  }, [currentText]);

  // Compute effective scale multiplier for splash text
  const sizeScaleFactor = useMemo(() => {
    if (typeof scale === 'number' && scale !== 1.0) return scale;
    switch (size) {
      case 'sm': return 0.82;
      case 'lg': return 1.25;
      case 'xl': return 1.55;
      case 'md':
      default: return 1.0;
    }
  }, [size, scale]);

  // Determine anchor positioning styles - Using physical right/left coordinates
  // so switching to Arabic (RTL) NEVER moves the splash text to the left!
  const anchorClasses = useMemo(() => {
    switch (position) {
      case 'top-left':
        return 'top-0 left-0 sm:left-2';
      case 'top-center':
        return '-top-5 left-1/2 -translate-x-1/2';
      case 'bottom-right':
        return 'bottom-0 right-0 sm:-right-6';
      case 'top-right':
      default:
        // Scaled and positioned gracefully on mobile so it stays within viewport
        return '-top-4 xs:-top-5 sm:-top-7 right-0 xs:right-1 sm:-right-6 md:-right-10';
    }
  }, [position]);

  if (!currentText) return null;

  return (
    <>
      {/* 
        Minecraft Splash Text:
        Owner customizable position, angle, size scale, pixel font, vibrant yellow color,
        dark text shadow, and pulsating bounce animation!
        Supports direct long-tap / drag & drop movement for the owner!
        dir="ltr" ensures coordinates stay identical regardless of website language!
      */}
      <motion.div 
        dir="ltr"
        drag={isOwner}
        dragMomentum={false}
        dragElastic={0.06}
        onDragEnd={(_e, info) => {
          if (!isOwner) return;
          const newX = Math.round(offsetX + info.offset.x);
          const newY = Math.round(offsetY + info.offset.y);
          setOffsetX(newX);
          setOffsetY(newY);
          handleSaveConfig({
            sentences,
            angle,
            position,
            offsetX: newX,
            offsetY: newY,
            size,
            scale
          });
        }}
        className={`absolute ${anchorClasses} z-30 select-none pointer-events-auto transition-transform duration-200 ${
          isOwner ? 'cursor-grab active:cursor-grabbing touch-none' : ''
        }`}
        style={{ 
          transform: `translate3d(${offsetX}px, ${offsetY}px, 90px)`,
        }}
        title={isOwner ? (isAr ? 'اضغط مطولاً واسحب لتحريك الموضع مباشرة!' : 'Long tap and drag to move splash text position!') : undefined}
      >
        <div className="relative group/splash flex items-center">
          <motion.button
            key={`${currentText}-${bounceTrigger}`}
            onClick={handleRollNext}
            initial={{ scale: 0.6 * sizeScaleFactor, rotate: angle }}
            animate={{ scale: 1 * sizeScaleFactor, rotate: angle }}
            whileHover={{ scale: 1.15 * sizeScaleFactor, rotate: angle }}
            whileTap={{ scale: 0.9 * sizeScaleFactor, rotate: angle }}
            transition={{ type: 'spring', stiffness: 350, damping: 18 }}
            className={`animate-minecraft-splash inline-block text-[#ffff00] hover:text-[#fef08a] transition-colors whitespace-nowrap cursor-pointer px-2 py-0.5 ${
              hasArabic
                ? 'font-pixel-arabic text-sm xs:text-base sm:text-lg md:text-xl font-bold tracking-wide'
                : 'font-pixel text-[10px] xs:text-xs sm:text-sm md:text-base font-black'
            }`}
            style={{
              textShadow: hasArabic
                ? '2px 2px 0px #3f3f00, 3px 3px 0px #000000, 0 0 14px rgba(255, 255, 0, 0.7)'
                : '2px 2px 0px #3f3f00, 3px 3px 0px #000000, 0 0 10px rgba(255, 255, 0, 0.65)',
              transformOrigin: 'center center',
              // @ts-ignore
              '--splash-angle': `${angle}deg`
            }}
            title={isAr ? 'اضغط لتوليد جملة عشوائية أخرى!' : 'Click to roll another random splash!'}
          >
            {currentText}
          </motion.button>

          {/* Owner Splash Manager trigger button */}
          {isOwner && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setIsModalOpen(true);
              }}
              className="ms-1.5 p-1 rounded-md bg-black/60 hover:bg-black/90 border border-yellow-400/50 text-yellow-300 hover:text-white transition-all shadow-md cursor-pointer opacity-70 hover:opacity-100 scale-90"
              title={isAr ? 'تعديل جمل وموضع وحجم الماينكرافت (المالك فقط)' : 'Edit Minecraft Splash Texts, Position & Size (Owner Only)'}
            >
              <Edit2 size={11} />
            </button>
          )}
        </div>
      </motion.div>

      {/* Owner Splash Manager Modal */}
      <OwnerSplashManagerModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        config={{
          sentences,
          angle,
          position,
          offsetX,
          offsetY,
          size,
          scale
        }}
        onSaveConfig={handleSaveConfig}
        onRerollSplash={handleRollNext}
      />
    </>
  );
};
