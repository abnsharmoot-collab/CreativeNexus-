import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence, useDragControls } from 'motion/react';
import { 
  X, Plus, Trash2, Edit2, Check, RotateCcw, Sparkles, 
  RefreshCw, Move, Compass, Sliders, Type, ArrowUp, ArrowDown, ArrowLeft, ArrowRight,
  GripHorizontal
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export interface SplashConfigData {
  sentences: string[];
  angle: number;
  position: string;
  offsetX: number;
  offsetY: number;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  scale?: number;
}

interface OwnerSplashManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: SplashConfigData;
  onSaveConfig: (newConfig: SplashConfigData) => Promise<boolean>;
  onRerollSplash: () => void;
}

export const OwnerSplashManagerModal: React.FC<OwnerSplashManagerModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
  onRerollSplash
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const dragControls = useDragControls();

  const [activeTab, setActiveTab] = useState<'sentences' | 'position' | 'size'>('sentences');
  const [list, setList] = useState<string[]>(config.sentences);
  const [angle, setAngle] = useState<number>(config.angle ?? 45);
  const [position, setPosition] = useState<string>(config.position ?? 'top-right');
  const [offsetX, setOffsetX] = useState<number>(config.offsetX ?? 0);
  const [offsetY, setOffsetY] = useState<number>(config.offsetY ?? 0);
  const [size, setSize] = useState<'sm' | 'md' | 'lg' | 'xl'>(config.size || 'md');
  const [scale, setScale] = useState<number>(config.scale ?? (config.size === 'sm' ? 0.82 : config.size === 'lg' ? 1.25 : config.size === 'xl' ? 1.55 : 1.0));

  const [newText, setNewText] = useState('');
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editText, setEditText] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [hasMoved, setHasMoved] = useState(false);

  // Sync state when opened
  useEffect(() => {
    if (isOpen) {
      setList(config.sentences || []);
      setAngle(config.angle ?? 45);
      setPosition(config.position ?? 'top-right');
      setOffsetX(config.offsetX ?? 0);
      setOffsetY(config.offsetY ?? 0);
      setSize(config.size || 'md');
      setScale(config.scale ?? (config.size === 'sm' ? 0.82 : config.size === 'lg' ? 1.25 : config.size === 'xl' ? 1.55 : 1.0));
      setStatusMessage(null);
      setEditingIndex(null);
      setHasMoved(false);
    }
  }, [isOpen, config]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newText.trim();
    if (!clean) return;
    if (list.includes(clean)) {
      alert(isAr ? 'هذه العبارة مضافة بالفعل!' : 'This sentence already exists!');
      return;
    }
    setList([clean, ...list]);
    setNewText('');
  };

  const handleDelete = (index: number) => {
    if (list.length <= 1) {
      alert(isAr ? 'يجب أن تترك عبارة واحدة على الأقل!' : 'You must keep at least one sentence!');
      return;
    }
    setList(list.filter((_, i) => i !== index));
  };

  const handleStartEdit = (index: number) => {
    setEditingIndex(index);
    setEditText(list[index]);
  };

  const handleSaveEdit = (index: number) => {
    const clean = editText.trim();
    if (!clean) return;
    const updated = [...list];
    updated[index] = clean;
    setList(updated);
    setEditingIndex(null);
  };

  const handleResetDefaults = () => {
    const defaults = [
      "Welcome to the Nexus!",
      "Also try Codex!",
      "Crafted with passion!",
      "Legends never fade!",
      "Sovereign Edgar approved!",
      "The Sanctuary Lives!",
      "Creeper? Aw man!",
      "100% Organic Energy!",
      "مركز الإبداع بلا حدود!",
      "سيرفر الأساطير!",
      "الذهب الحقيقي هو المجتمع!",
      "منذ 2023 وحتى الأبد!",
      "ابقَ مبدعاً!"
    ];
    setList(defaults);
    setAngle(45);
    setPosition('top-right');
    setOffsetX(0);
    setOffsetY(0);
    setSize('md');
    setScale(1.0);
  };

  const handleSaveAll = async () => {
    setIsSaving(true);
    setStatusMessage(null);
    try {
      const ok = await onSaveConfig({
        sentences: list,
        angle,
        position,
        offsetX,
        offsetY,
        size,
        scale
      });
      if (ok) {
        setStatusMessage(isAr ? 'تم حفظ التعديلات والموضع ومقياس الحجم بنجاح!' : 'Settings, position, and size saved successfully!');
        onRerollSplash();
        setTimeout(() => {
          onClose();
        }, 800);
      } else {
        setStatusMessage(isAr ? 'فشل حفظ الإعدادات' : 'Failed to save');
      }
    } catch {
      setStatusMessage(isAr ? 'حدث خطأ أثناء الحفظ' : 'Error saving');
    } finally {
      setIsSaving(false);
    }
  };

  const ANGLE_PRESETS = [-45, -20, 0, 15, 25, 45, 90];
  const POSITION_PRESETS = [
    { id: 'top-right', labelAr: 'أعلى اليمين (افتراضي)', labelEn: 'Top Right (Default)' },
    { id: 'top-center', labelAr: 'أعلى المنتصف', labelEn: 'Top Center' },
    { id: 'top-left', labelAr: 'أعلى اليسار', labelEn: 'Top Left' },
    { id: 'bottom-right', labelAr: 'أسفل اليمين', labelEn: 'Bottom Right' },
  ];

  const SIZE_PRESETS: { id: 'sm' | 'md' | 'lg' | 'xl'; labelAr: string; labelEn: string; descAr: string; descEn: string; scale: string }[] = [
    { id: 'sm', labelAr: 'صغير (Small)', labelEn: 'Small (Compact)', descAr: 'خفيف ومدمج للمساحات الضيقة', descEn: 'Compact footprint, fits tight spaces', scale: '0.82×' },
    { id: 'md', labelAr: 'عادي (Normal)', labelEn: 'Normal (Standard)', descAr: 'الحجم الافتراضي الكلاسيكي لماينكرافت', descEn: 'Classic Minecraft standard size', scale: '1.0×' },
    { id: 'lg', labelAr: 'كبير (Large)', labelEn: 'Large (Bold)', descAr: 'بارز وواضح وملفت للانتباه', descEn: 'Prominent, bold and eye-catching', scale: '1.25×' },
    { id: 'xl', labelAr: 'عملاق (Giant)', labelEn: 'Giant (Massive)', descAr: 'حجم ضخم ومهيب يلفت الأنظار بقوة', descEn: 'Massive, commanding sovereign presence', scale: '1.55×' },
  ];

  if (!isOpen || typeof document === 'undefined') return null;

  return createPortal(
    <div className="fixed inset-0 z-[999999] flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md pointer-events-auto">
      {/* Click outside to close (backdrop) */}
      <div 
        className="absolute inset-0 z-0" 
        onClick={onClose} 
        aria-hidden="true"
      />

      <motion.div
        drag
        dragListener={false}
        dragControls={dragControls}
        dragMomentum={false}
        dragElastic={0.06}
        onDragEnd={() => setHasMoved(true)}
        initial={{ opacity: 0, scale: 0.95, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 12 }}
        className="relative z-10 w-full max-w-lg sm:max-w-xl max-h-[88vh] flex flex-col rounded-3xl bg-[#06201e]/98 border border-[rgba(158,255,230,0.3)] p-4 sm:p-6 shadow-[0_25px_80px_rgba(0,0,0,0.95)] text-[#eafffa] overflow-hidden select-text"
        dir={isAr ? 'rtl' : 'ltr'}
      >
        {/* Drag Bar & Reposition Handle (Touch & Mouse Draggable by Long Tap / Hold) */}
        <div 
          onPointerDown={(e) => dragControls.start(e)}
          className="w-full flex items-center justify-between pb-2.5 mb-2 border-b border-[rgba(158,255,230,0.1)] cursor-grab active:cursor-grabbing select-none group/drag text-slate-400 hover:text-yellow-300 transition-colors touch-none"
          title={isAr ? 'اضغط مطولاً أو اسحب لتحريك القائمة في أي مكان على الشاشة' : 'Long press or drag anywhere to reposition this menu'}
        >
          <div className="flex items-center gap-2 text-[11px] font-mono font-medium">
            <Move size={13} className="text-yellow-400 group-hover/drag:scale-110 transition-transform" />
            <span className="opacity-80 group-hover/drag:opacity-100">
              {isAr ? 'اضغط مطولاً واسحب لتحريك القائمة' : 'Long tap & drag to move window'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {hasMoved && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setHasMoved(false);
                }}
                className="text-[10px] px-2 py-0.5 rounded-md bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
              >
                {isAr ? 'إعادة للمنتصف' : 'Center'}
              </button>
            )}
            <div className="flex items-center gap-1 opacity-60 group-hover/drag:opacity-100">
              <span className="w-1.5 h-1.5 rounded-full bg-yellow-400/60" />
              <span className="w-6 h-1 rounded-full bg-white/30 group-hover/drag:bg-yellow-400/70 transition-colors" />
              <span className="w-1.5 h-1.5 rounded-full bg-yellow-400/60" />
            </div>
          </div>
        </div>

        {/* Header */}
        <div 
          onPointerDown={(e) => {
            const target = e.target as HTMLElement;
            if (target.tagName !== 'BUTTON' && target.tagName !== 'INPUT' && !target.closest('button')) {
              dragControls.start(e);
            }
          }}
          className="flex items-center justify-between pb-3.5 border-b border-[rgba(158,255,230,0.15)] shrink-0 cursor-grab active:cursor-grabbing"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-yellow-400/15 border border-yellow-400/30 flex items-center justify-center text-yellow-300 shrink-0">
              <Sparkles size={16} />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white font-display">
                {isAr ? 'تخصيص عبارات الماينكرافت وموضعها' : 'Minecraft Splash Customizer'}
              </h3>
              <p className="text-[11px] text-[#8db8b1] leading-tight">
                {isAr
                  ? 'تحكم بالكلمات العشوائية، وزاوية الميلان والموضع فوق العنوان'
                  : 'Manage sentences, custom angle & position over Creative Nexus'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer shrink-0"
          >
            <X size={16} />
          </button>
        </div>

        {/* Navigation Tabs (Mobile-Friendly Pill Bar) */}
        <div className="flex items-center p-1 rounded-2xl bg-[#031413] border border-[rgba(158,255,230,0.15)] my-3 shrink-0 gap-1">
          <button
            type="button"
            onClick={() => setActiveTab('sentences')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'sentences'
                ? 'bg-yellow-400/20 text-yellow-300 border border-yellow-400/40 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Type size={14} />
            <span className="truncate">{isAr ? `العبارات (${list.length})` : `Words (${list.length})`}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('position')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'position'
                ? 'bg-yellow-400/20 text-yellow-300 border border-yellow-400/40 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Compass size={14} />
            <span className="truncate">{isAr ? `الموضع (${angle}°)` : `Placement (${angle}°)`}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('size')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'size'
                ? 'bg-yellow-400/20 text-yellow-300 border border-yellow-400/40 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sliders size={14} />
            <span className="truncate">{isAr ? `الحجم (${size.toUpperCase()})` : `Size (${size.toUpperCase()})`}</span>
          </button>
        </div>

        {/* Tab 1: Sentences Manager */}
        {activeTab === 'sentences' && (
          <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
            {/* Add New Input */}
            <form onSubmit={handleAdd} className="flex gap-2 shrink-0 mb-3">
              <input
                type="text"
                value={newText}
                onChange={(e) => setNewText(e.target.value)}
                placeholder={isAr ? 'أضف جملة جديدة...' : 'Add a new splash sentence...'}
                maxLength={60}
                className="flex-1 px-3.5 py-2 rounded-xl bg-[#031413] border border-[rgba(158,255,230,0.2)] focus:border-yellow-400 text-xs sm:text-sm text-white placeholder-slate-500 outline-none"
              />
              <button
                type="submit"
                disabled={!newText.trim()}
                className="px-3.5 py-2 rounded-xl bg-yellow-400/20 hover:bg-yellow-400/30 text-yellow-300 border border-yellow-400/40 text-xs font-bold transition-all flex items-center gap-1.5 disabled:opacity-40 cursor-pointer shrink-0"
              >
                <Plus size={14} />
                <span className="hidden xs:inline">{isAr ? 'إضافة' : 'Add'}</span>
              </button>
            </form>

            {/* Sentences List */}
            <div className="flex-1 overflow-y-auto space-y-2 pe-1 max-h-[38vh] custom-scrollbar">
              <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider flex items-center justify-between px-1">
                <span>{isAr ? 'قائمة الجمل المعتمدة' : 'Registered Sentences'}</span>
                <button
                  type="button"
                  onClick={onRerollSplash}
                  className="inline-flex items-center gap-1 text-[10px] text-yellow-400 hover:text-yellow-300 font-bold cursor-pointer"
                >
                  <RefreshCw size={10} />
                  <span>{isAr ? 'تجربة كلمة الآن' : 'Test Roll'}</span>
                </button>
              </div>

              {list.map((sentence, idx) => (
                <div
                  key={idx}
                  className="p-2.5 rounded-xl bg-[#031413]/80 border border-[rgba(158,255,230,0.12)] hover:border-yellow-400/30 transition-all flex items-center justify-between gap-2 group"
                >
                  {editingIndex === idx ? (
                    <div className="flex-1 flex items-center gap-2">
                      <input
                        type="text"
                        value={editText}
                        onChange={(e) => setEditText(e.target.value)}
                        maxLength={60}
                        className="flex-1 px-2.5 py-1 rounded-lg bg-[#06201e] border border-yellow-400/50 text-xs text-white outline-none"
                        autoFocus
                      />
                      <button
                        type="button"
                        onClick={() => handleSaveEdit(idx)}
                        className="p-1 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30"
                      >
                        <Check size={13} />
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingIndex(null)}
                        className="p-1 rounded-lg bg-white/5 text-slate-400 hover:text-white"
                      >
                        <X size={13} />
                      </button>
                    </div>
                  ) : (
                    <>
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <span className="w-5 h-5 rounded-md bg-yellow-400/10 text-yellow-400 text-[10px] font-mono font-bold flex items-center justify-center shrink-0">
                          {idx + 1}
                        </span>
                        <span className={`tracking-wide truncate ${
                          /[\u0600-\u06FF]/.test(sentence)
                            ? 'font-pixel-arabic text-xs sm:text-sm text-yellow-300 font-bold'
                            : 'font-pixel text-[10px] sm:text-xs text-yellow-300'
                        }`}>
                          {sentence}
                        </span>
                      </div>

                      <div className="flex items-center gap-1 shrink-0 opacity-80 group-hover:opacity-100">
                        <button
                          type="button"
                          onClick={() => handleStartEdit(idx)}
                          className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                          title={isAr ? 'تعديل' : 'Edit'}
                        >
                          <Edit2 size={12} />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(idx)}
                          className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 hover:text-red-300 transition-colors"
                          title={isAr ? 'حذف' : 'Delete'}
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 2: Position & Angle Customizer */}
        {activeTab === 'position' && (
          <div className="flex-1 overflow-y-auto space-y-3.5 pe-1 max-h-[46vh] custom-scrollbar">
            {/* Live Interactive Preview Box */}
            <div className="relative p-4 rounded-2xl bg-[#031413] border border-[rgba(158,255,230,0.2)] text-center overflow-hidden">
              <span className="absolute top-2 start-2 text-[9px] font-mono text-slate-500 uppercase tracking-widest">
                {isAr ? 'معاينة حية مباشرة' : 'LIVE PREVIEW'}
              </span>

              <div className="pt-4 pb-2 relative flex flex-col items-center justify-center">
                <span className="text-xl sm:text-2xl font-black text-white/40 tracking-wider font-cinzel">
                  CREATIVE NEXUS
                </span>

                {/* Animated Sample Splash with live transform */}
                <div 
                  className="absolute pointer-events-none transition-all duration-150"
                  style={{
                    transform: `translate(${offsetX}px, ${offsetY}px)`,
                    ...(position === 'top-right' ? { top: '0px', right: '15px' } : {}),
                    ...(position === 'top-left' ? { top: '0px', left: '15px' } : {}),
                    ...(position === 'top-center' ? { top: '-6px' } : {}),
                    ...(position === 'bottom-right' ? { bottom: '0px', right: '15px' } : {}),
                  }}
                >
                  <span
                    className={`inline-block font-black text-[#ffff00] px-2 py-0.5 ${
                      /[\u0600-\u06FF]/.test(list[0] || '')
                        ? 'font-pixel-arabic text-sm sm:text-base font-bold'
                        : 'font-pixel text-xs sm:text-sm'
                    }`}
                    style={{
                      transform: `rotate(${angle}deg) scale(${size === 'sm' ? 0.82 : size === 'lg' ? 1.25 : size === 'xl' ? 1.55 : 1.0})`,
                      textShadow: '2px 2px 0px #3f3f00, 3px 3px 0px #000000, 0 0 10px rgba(255, 255, 0, 0.7)',
                      transformOrigin: 'center center'
                    }}
                  >
                    {list[0] || 'Minecraft Splash!'}
                  </span>
                </div>
              </div>
            </div>

            {/* Angle Controls */}
            <div className="p-3 rounded-2xl bg-[#031413]/70 border border-[rgba(158,255,230,0.12)]">
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-yellow-300 flex items-center gap-1.5">
                  <Compass size={13} />
                  <span>{isAr ? 'زاوية الميلان (Angle):' : 'Splash Angle:'}</span>
                </label>
                <span className="px-2 py-0.5 rounded-md bg-yellow-400/20 text-yellow-300 font-mono text-xs font-bold">
                  {angle}°
                </span>
              </div>

              {/* Slider */}
              <input
                type="range"
                min={-90}
                max={90}
                step={1}
                value={angle}
                onChange={(e) => setAngle(Number(e.target.value))}
                className="w-full accent-yellow-400 h-2 bg-black/40 rounded-lg cursor-pointer"
              />

              {/* Quick Angle Presets */}
              <div className="flex flex-wrap gap-1.5 mt-2">
                {ANGLE_PRESETS.map((deg) => (
                  <button
                    key={deg}
                    type="button"
                    onClick={() => setAngle(deg)}
                    className={`px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer ${
                      angle === deg
                        ? 'bg-yellow-400 text-black shadow-sm font-black'
                        : 'bg-white/5 hover:bg-white/10 text-slate-300'
                    }`}
                  >
                    {deg > 0 ? `+${deg}°` : `${deg}°`}
                  </button>
                ))}
              </div>
            </div>

            {/* Position Anchor Presets */}
            <div className="p-3 rounded-2xl bg-[#031413]/70 border border-[rgba(158,255,230,0.12)]">
              <label className="text-xs font-bold text-yellow-300 flex items-center gap-1.5 mb-2">
                <Move size={13} />
                <span>{isAr ? 'موضع التثبيت (Placement):' : 'Placement Anchor:'}</span>
              </label>

              <div className="grid grid-cols-2 gap-1.5">
                {POSITION_PRESETS.map((pos) => (
                  <button
                    key={pos.id}
                    type="button"
                    onClick={() => setPosition(pos.id)}
                    className={`p-2 rounded-xl text-xs font-bold transition-all text-center cursor-pointer ${
                      position === pos.id
                        ? 'bg-yellow-400/25 text-yellow-300 border border-yellow-400/50'
                        : 'bg-white/5 hover:bg-white/10 text-slate-400'
                    }`}
                  >
                    {isAr ? pos.labelAr : pos.labelEn}
                  </button>
                ))}
              </div>
            </div>

            {/* Fine-Tuning Offsets with Nudge Arrows */}
            <div className="p-3 rounded-2xl bg-[#031413]/70 border border-[rgba(158,255,230,0.12)] space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-yellow-300 flex items-center gap-1.5">
                  <Sliders size={13} />
                  <span>{isAr ? 'الإزاحة الدقيقة (Offsets)' : 'Fine Tuning Offsets'}</span>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setOffsetX(0);
                    setOffsetY(0);
                  }}
                  className="text-[10px] text-slate-400 hover:text-white"
                >
                  {isAr ? 'تصفير الإزاحة' : 'Reset to 0'}
                </button>
              </div>

              {/* Offset X */}
              <div>
                <div className="flex justify-between text-[11px] text-slate-400 font-mono mb-1">
                  <span>{isAr ? 'إزاحة أفقية (X Offset)' : 'Horizontal Offset (X)'}</span>
                  <span className="text-yellow-400 font-bold">{offsetX}px</span>
                </div>
                <input
                  type="range"
                  min={-120}
                  max={120}
                  step={2}
                  value={offsetX}
                  onChange={(e) => setOffsetX(Number(e.target.value))}
                  className="w-full accent-yellow-400 h-1.5 bg-black/40 rounded-lg cursor-pointer"
                />
              </div>

              {/* Offset Y */}
              <div>
                <div className="flex justify-between text-[11px] text-slate-400 font-mono mb-1">
                  <span>{isAr ? 'إزاحة رأسية (Y Offset)' : 'Vertical Offset (Y)'}</span>
                  <span className="text-yellow-400 font-bold">{offsetY}px</span>
                </div>
                <input
                  type="range"
                  min={-80}
                  max={80}
                  step={2}
                  value={offsetY}
                  onChange={(e) => setOffsetY(Number(e.target.value))}
                  className="w-full accent-yellow-400 h-1.5 bg-black/40 rounded-lg cursor-pointer"
                />
              </div>

              {/* Nudge Buttons for Touch / Mobile */}
              <div className="flex items-center justify-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setOffsetX(prev => prev - 5)}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300"
                  title="Move Left"
                >
                  <ArrowLeft size={13} />
                </button>
                <button
                  type="button"
                  onClick={() => setOffsetY(prev => prev - 5)}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300"
                  title="Move Up"
                >
                  <ArrowUp size={13} />
                </button>
                <button
                  type="button"
                  onClick={() => setOffsetY(prev => prev + 5)}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300"
                  title="Move Down"
                >
                  <ArrowDown size={13} />
                </button>
                <button
                  type="button"
                  onClick={() => setOffsetX(prev => prev + 5)}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300"
                  title="Move Right"
                >
                  <ArrowRight size={13} />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Size & Scale Customizer */}
        {activeTab === 'size' && (
          <div className="flex-1 overflow-y-auto space-y-3.5 pe-1 max-h-[46vh] custom-scrollbar">
            {/* Live Interactive Preview Box */}
            <div className="relative p-4 rounded-2xl bg-[#031413] border border-[rgba(158,255,230,0.2)] text-center overflow-hidden">
              <span className="absolute top-2 start-2 text-[9px] font-mono text-slate-500 uppercase tracking-widest">
                {isAr ? 'معاينة مقياس الحجم' : 'SIZE SCALE PREVIEW'}
              </span>

              <div className="pt-4 pb-2 relative flex flex-col items-center justify-center">
                <span className="text-xl sm:text-2xl font-black text-white/40 tracking-wider font-cinzel">
                  CREATIVE NEXUS
                </span>

                <div 
                  className="absolute pointer-events-none transition-all duration-200"
                  style={{
                    transform: `translate(${offsetX}px, ${offsetY}px)`,
                    ...(position === 'top-right' ? { top: '0px', right: '15px' } : {}),
                    ...(position === 'top-left' ? { top: '0px', left: '15px' } : {}),
                    ...(position === 'top-center' ? { top: '-6px' } : {}),
                    ...(position === 'bottom-right' ? { bottom: '0px', right: '15px' } : {}),
                  }}
                >
                  <span
                    className={`inline-block font-black text-[#ffff00] px-2 py-0.5 transition-transform duration-200 ${
                      /[\u0600-\u06FF]/.test(list[0] || '')
                        ? 'font-pixel-arabic font-bold'
                        : 'font-pixel'
                    }`}
                    style={{
                      transform: `rotate(${angle}deg) scale(${scale})`,
                      textShadow: '2px 2px 0px #3f3f00, 3px 3px 0px #000000, 0 0 12px rgba(255, 255, 0, 0.75)',
                      transformOrigin: 'center center'
                    }}
                  >
                    {list[0] || 'Minecraft Splash!'}
                  </span>
                </div>
              </div>
            </div>

            {/* Size Options Grid */}
            <div className="space-y-3">
              <label className="text-xs font-bold text-yellow-300 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Sliders size={13} />
                  <span>{isAr ? 'اختر حجم العبارة فوق العنوان:' : 'Select Splash Scale:'}</span>
                </span>
                <span className="px-2 py-0.5 rounded-md bg-yellow-400/20 text-yellow-300 font-mono text-xs font-black uppercase">
                  {size} ({(scale * 100).toFixed(0)}%)
                </span>
              </label>

              {/* Presets */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {SIZE_PRESETS.map((preset) => {
                  const isSelected = size === preset.id;
                  const presetNumericScale = preset.id === 'sm' ? 0.82 : preset.id === 'lg' ? 1.25 : preset.id === 'xl' ? 1.55 : 1.0;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => {
                        setSize(preset.id);
                        setScale(presetNumericScale);
                      }}
                      className={`p-3 rounded-2xl border text-start transition-all cursor-pointer relative overflow-hidden group ${
                        isSelected
                          ? 'bg-yellow-400/15 border-yellow-400 text-white shadow-lg shadow-yellow-500/10'
                          : 'bg-[#031413]/70 hover:bg-[#031413] border-[rgba(158,255,230,0.12)] text-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className={`text-xs font-bold flex items-center gap-1.5 ${isSelected ? 'text-yellow-300 font-black' : 'text-slate-200'}`}>
                          <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-yellow-400 shadow-sm' : 'bg-slate-600'}`} />
                          <span>{isAr ? preset.labelAr : preset.labelEn}</span>
                        </span>
                        <span className="px-1.5 py-0.5 rounded-md text-[10px] font-mono font-bold bg-black/60 text-yellow-400 border border-yellow-400/30">
                          {preset.scale}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400 leading-snug">
                        {isAr ? preset.descAr : preset.descEn}
                      </p>
                    </button>
                  );
                })}
              </div>

              {/* Continuous Fine-Tune Scale Slider */}
              <div className="p-3.5 rounded-2xl bg-[#031413]/80 border border-[rgba(158,255,230,0.15)] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-yellow-300 flex items-center gap-1.5">
                    <Sliders size={13} />
                    <span>{isAr ? 'تخصيص الحجم الدقيق (مقياس حر):' : 'Fine-Tune Scale (Custom Slider):'}</span>
                  </span>
                  <span className="text-xs font-mono font-bold text-yellow-400">
                    {(scale * 100).toFixed(0)}% ({scale.toFixed(2)}×)
                  </span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={2.2}
                  step={0.05}
                  value={scale}
                  onChange={(e) => {
                    const newScale = Number(e.target.value);
                    setScale(newScale);
                    if (newScale <= 0.88) setSize('sm');
                    else if (newScale <= 1.12) setSize('md');
                    else if (newScale <= 1.4) setSize('lg');
                    else setSize('xl');
                  }}
                  className="w-full accent-yellow-400 h-2 bg-black/50 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] font-mono text-slate-400 px-0.5">
                  <span>50% (Tiny)</span>
                  <span>100% (Normal)</span>
                  <span>150% (Large)</span>
                  <span>220% (Mega)</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {statusMessage && (
          <div className="mt-2.5 p-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs text-center font-bold">
            {statusMessage}
          </div>
        )}

        {/* Modal Footer */}
        <div className="mt-3 pt-3 border-t border-[rgba(158,255,230,0.15)] flex items-center justify-between gap-2 shrink-0">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <RotateCcw size={13} />
            <span className="hidden xs:inline">{isAr ? 'الافتراضيات' : 'Defaults'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-xl text-xs font-medium text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
            >
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>
            <button
              type="button"
              onClick={handleSaveAll}
              disabled={isSaving}
              className="px-4 py-2 rounded-xl text-xs font-bold text-[#031211] bg-gradient-to-r from-yellow-300 via-amber-300 to-yellow-400 hover:brightness-110 transition-all shadow-md flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
            >
              {isSaving ? (
                <span>{isAr ? 'جارِ الحفظ...' : 'Saving...'}</span>
              ) : (
                <>
                  <Check size={14} />
                  <span>{isAr ? 'حفظ ونشر التعديلات' : 'Save & Publish'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </motion.div>
    </div>,
    document.body
  );
};
