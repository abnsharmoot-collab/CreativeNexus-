import React from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, ArrowLeft, Sparkles, BookOpen } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useDiscordServer } from '../../context/DiscordServerContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { StatCard } from '../molecules/StatCard';
import { HiddenIraqiFlag } from '../easterEggs/HiddenIraqiFlag';
import { AncientTorchBrazier } from '../atoms/AncientTorchBrazier';
import { CrowdCanvas } from '../atoms/CrowdCanvas';
import { ServerNewsCarousel } from './ServerNewsCarousel';

export function HomeUnifiedHub() {
  const { t, language } = useLanguage();
  const isAr = language === 'ar';
  const isRtl = isAr;
  const { serverInfo, isLive } = useDiscordServer();
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  return (
    <section className="relative py-12 sm:py-16 lg:py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* ============================================================ */}
      {/* 3D VOLUMETRIC GRADIENT AMBIENCE & CONTINUOUS SPATIAL AURORA  */}
      {/* ============================================================ */}
      {!isMesopotamian ? (
        <div className="absolute inset-0 pointer-events-none select-none overflow-hidden" aria-hidden="true">
          {/* Top-Center Radiant Cyan 3D Light Orb (Darkened/Toned down for deep obsidian mood) */}
          <div className="absolute top-[8%] start-1/2 -translate-x-1/2 w-[700px] sm:w-[950px] h-[450px] bg-gradient-to-b from-[#5eead4]/10 via-teal-500/6 to-transparent blur-[160px] rounded-full" />
          
          {/* Mid-Section Emerald & Cyan Cross-Aura for Server Status */}
          <div className="absolute top-[42%] start-[-10%] w-[650px] sm:w-[850px] h-[550px] bg-gradient-to-tr from-emerald-500/10 via-teal-400/6 to-transparent blur-[180px] rounded-full" />
          <div className="absolute top-[48%] end-[-10%] w-[650px] sm:w-[800px] h-[520px] bg-gradient-to-tl from-cyan-400/10 via-[#2dd4bf]/6 to-indigo-500/5 blur-[180px] rounded-full" />

          {/* Bottom Floor Deep Radiant Reflection for Start Your Journey */}
          <div className="absolute bottom-[5%] start-1/2 -translate-x-1/2 w-[750px] sm:w-[1000px] h-[400px] bg-gradient-to-t from-teal-400/12 via-cyan-500/6 to-transparent blur-[160px] rounded-full" />

          {/* 3D Depth Specular Light Streak */}
          <div className="absolute inset-0 bg-radial from-teal-950/15 via-transparent to-transparent" />
        </div>
      ) : null}

      {/* ============================================================ */}
      {/* CORE HUB SECTIONS (Frameless, Natural Flow on Dark Canvas)    */}
      {/* ============================================================ */}
      <div className="relative z-10 max-w-5xl mx-auto space-y-16 sm:space-y-24">
        {/* ======================================================== */}
        {/* PART 1: GUIDEBOOK & CODEX PORTAL                         */}
        {/* ======================================================== */}
        <motion.div
          id="guidebook"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="relative z-10 px-4 sm:px-6"
        >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 sm:gap-8">
              {/* Text Side */}
              <div className="space-y-2.5 flex-1 max-w-2xl">
                <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full shadow-xs mb-1 ${
                  isMesopotamian
                    ? 'bg-amber-500/10 border border-amber-500/30 text-amber-300'
                    : 'bg-[#5eead4]/10 border border-[#5eead4]/25 text-[#2dd4bf]'
                }`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    isMesopotamian ? 'bg-amber-400 shadow-[0_0_8px_#f59e0b]' : 'bg-[#5eead4] shadow-[0_0_8px_#5eead4]'
                  }`} />
                  <span className="text-xs font-mono tracking-widest uppercase font-bold">
                    {isAr ? 'دليل الإرشادات والقوانين' : 'GUIDEBOOK & CODEX'}
                  </span>
                </div>

                <h2
                  className={`text-xl sm:text-2xl lg:text-3xl font-black tracking-tight leading-snug ${
                    isMesopotamian
                      ? 'font-meso-serif text-amber-100 drop-shadow-md'
                      : 'text-white'
                  }`}
                >
                  {isAr
                    ? 'دليل شامل يساعدك على فهم مجتمع CREATIVE NEXUS وأهم أنظمته.'
                    : 'A quick guide to help you understand Creative Nexus and its core systems.'}
                </h2>

                <p
                  className={`text-sm sm:text-base leading-relaxed ${
                    isMesopotamian
                      ? 'font-serif text-amber-300/80 drop-shadow-sm'
                      : 'text-[#99b8b2]'
                  }`}
                >
                  {isAr
                    ? 'استكشف الرتب ونقاط الترقية واللوائح التنظيمية الرسمية للمجتمع.'
                    : 'Explore ranks, promotion requirements, and official guidelines.'}
                </p>
              </div>

              {/* Action Button */}
              <div className="shrink-0 flex items-center">
                <Link
                  to="/guidebook"
                  id="btn-homepage-enter-guidebook"
                  className={`w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3 rounded-2xl font-bold text-sm transition-all duration-200 group/btn shadow-[0_8px_25px_rgba(45,212,191,0.25),inset_0_1px_1px_rgba(255,255,255,0.25)] hover:scale-[1.03] active:scale-[0.98] ${
                    isMesopotamian
                      ? 'mesopotamian-btn-gold font-serif text-amber-950 shadow-md hover:brightness-105'
                      : 'btn-nexus-primary'
                  }`}
                >
                  <span>{isAr ? 'ادخل الدليل' : 'Enter Guidebook'}</span>
                  {isAr ? (
                    <ArrowLeft size={17} className="group-hover/btn:-translate-x-1 transition-transform" />
                  ) : (
                    <ArrowRight size={17} className="group-hover/btn:translate-x-1 transition-transform" />
                  )}
                </Link>
              </div>
            </div>
        </motion.div>

        {/* ======================================================== */}
        {/* 3D LUMINOUS ENERGY CONDUIT #1                            */}
        {/* ======================================================== */}
        <div className="relative px-6 sm:px-12 flex items-center justify-center pointer-events-none select-none" aria-hidden="true">
          <div className={`w-full max-w-2xl h-px ${
            isMesopotamian
              ? 'bg-gradient-to-r from-transparent via-amber-500/35 to-transparent'
              : 'bg-gradient-to-r from-transparent via-[#5eead4]/25 to-transparent'
          }`} />
          <div className={`absolute w-1.5 h-1.5 rounded-full ${
            isMesopotamian
              ? 'bg-amber-400/90 shadow-[0_0_8px_rgba(245,158,11,0.6)]'
              : 'bg-[#5eead4] shadow-[0_0_10px_#5eead4]'
          }`} />
        </div>

        {/* ======================================================== */}
        {/* SERVER NEWS & BULLETINS (Coverflow Carousel Synced with Announcements) */}
        {/* ======================================================== */}
        <motion.div
          id="news"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <ServerNewsCarousel />
        </motion.div>

        {/* ======================================================== */}
        {/* 3D LUMINOUS ENERGY CONDUIT #1B                           */}
        {/* ======================================================== */}
        <div className="relative px-6 sm:px-12 flex items-center justify-center pointer-events-none select-none" aria-hidden="true">
          <div className={`w-full max-w-2xl h-px ${
            isMesopotamian
              ? 'bg-gradient-to-r from-transparent via-amber-500/35 to-transparent'
              : 'bg-gradient-to-r from-transparent via-[#5eead4]/25 to-transparent'
          }`} />
          <div className={`absolute w-1.5 h-1.5 rounded-full ${
            isMesopotamian
              ? 'bg-amber-400/90 shadow-[0_0_8px_rgba(245,158,11,0.6)]'
              : 'bg-[#5eead4] shadow-[0_0_10px_#5eead4]'
          }`} />
        </div>

        {/* ======================================================== */}
        {/* PART 2: LIVE SERVER STATISTICS (Telemetry & Stat Cards)   */}
        {/* ======================================================== */}
        <motion.div 
          id="archive"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="relative z-10 px-4 sm:px-6 rounded-3xl overflow-hidden pt-4 sm:pt-6 pb-32 sm:pb-36 lg:pb-40"
        >
          {/* Animated CrowdCanvas positioned directly inside Server Stats container, filling the bottom */}
          <CrowdCanvas
            memberCount={serverInfo?.totalMembers ?? 580}
            isMesopotamian={isMesopotamian}
          />

          {/* Dedicated Luminous Gradient Aura for Stats Section */}
          {!isMesopotamian && (
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[850px] sm:w-[1050px] h-[550px] bg-gradient-to-r from-teal-500/20 via-[#5eead4]/15 to-cyan-400/20 blur-[160px] pointer-events-none rounded-full -z-10" />
          )}

          {/* Foreground content: Header & Stat Cards */}
          <div className="relative z-10">
            {/* Header */}
            <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-12">
              {isMesopotamian ? (
                <div className="flex items-center justify-center gap-3 sm:gap-4 text-amber-500/80 mb-3 select-none">
                  <div className="h-px w-12 sm:w-20 bg-gradient-to-r from-transparent to-amber-500/80" />
                  <span className="font-serif tracking-[0.25em] text-sm sm:text-base font-bold text-amber-400">
                    — 𒀭 𒆠 𒈗 𒂍 —
                  </span>
                  <div className="h-px w-12 sm:w-20 bg-gradient-to-l from-transparent to-amber-500/80" />
                  <HiddenIraqiFlag flagId="flag-home-stats" title="Guild registry watermark" />
                </div>
              ) : (
                <div className="flex flex-col items-center mb-2">
                  <HiddenIraqiFlag flagId="flag-home-stats" title="Guild registry watermark" />
                </div>
              )}

              <h2
                className={`font-black text-2xl sm:text-3xl lg:text-4xl tracking-tight mb-3 ${
                  isMesopotamian
                    ? 'font-meso-serif mesopotamian-chiseled-title'
                    : isRtl
                      ? 'font-cairo text-transparent bg-clip-text bg-gradient-to-r from-white via-[#e6fffa] to-[#5eead4] drop-shadow-[0_2px_20px_rgba(45,212,191,0.4)]'
                      : 'font-display text-transparent bg-clip-text bg-gradient-to-r from-white via-[#e6fffa] to-[#5eead4] drop-shadow-[0_2px_20px_rgba(45,212,191,0.4)]'
                }`}
              >
                {isRtl ? 'إحصائيات السيرفر المباشرة' : 'Live Server Statistics'}
              </h2>

              <p
                className={`text-sm sm:text-base font-normal max-w-xl mx-auto leading-relaxed ${
                  isMesopotamian
                    ? 'font-serif text-amber-200/70'
                    : isRtl
                      ? 'font-cairo text-[#99b8b2]'
                      : 'font-sans text-[#99b8b2]'
                }`}
              >
                {isRtl 
                  ? 'الأرقام متزامنة لحظياً ومباشرة مع سيرفر ديسكورد الرسمي ومعرف السيرفر' 
                  : 'All community numbers and metrics synchronized in real time with Discord servers'}
              </p>
            </div>

            {/* 4 Synchronized Metric Cards (2x2 Grid) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6 lg:gap-7 max-w-4xl mx-auto">
              {/* Card 1: Sanctuary Members */}
              <StatCard 
                label={isRtl ? 'أعضاء السيرفر' : 'SANCTUARY MEMBERS'}
                value={(serverInfo?.totalMembers ?? 580).toLocaleString()}
                subtitle="Creative Nexus | سرفر السين"
                delay={0}
                categoryLabel={isRtl ? 'إجمالي الأعضاء' : 'POPULATION'}
              />

              {/* Card 2: Online Vanguard */}
              <StatCard 
                label={isRtl ? 'المتواجدون الآن' : 'ONLINE VANGUARD'}
                value={(serverInfo?.onlineCount ?? 78).toLocaleString()}
                subtitle={isRtl ? 'أعضاء نشطون في هذه اللحظة' : 'Active creators right now'}
                delay={0.1}
                isLive={isLive}
                categoryLabel={isRtl ? 'نشط الآن' : 'TELEMETRY'}
              />

              {/* Card 3: Channels & Archives */}
              <StatCard 
                label={isRtl ? 'القنوات والرومات' : 'CHANNELS & SECTORS'}
                value={(serverInfo?.channelsCount ?? serverInfo?.channels?.length ?? 7).toLocaleString()}
                subtitle={isRtl ? 'غرف نقاش ومشاريع وبناء' : 'Interactive hubs & rooms'}
                delay={0.2}
                categoryLabel={isRtl ? 'البنية التحتية' : 'STRUCTURE'}
              />

              {/* Card 4: Nexus Boost Tier */}
              <StatCard 
                label={isRtl ? 'مستوى تعزيز السيرفر' : 'NEXUS BOOST TIER'}
                value={
                  (serverInfo?.boostCount ?? 0) > 0 
                    ? (isRtl ? `المستوى ${Math.min(3, Math.floor((serverInfo?.boostCount ?? 0) / 2) || 1)}` : `Level ${Math.min(3, Math.floor((serverInfo?.boostCount ?? 0) / 2) || 1)}`)
                    : (isRtl ? 'المستوى 0' : 'Level 0')
                }
                subtitle={isRtl ? 'دعم مستمر من مجتمعنا' : 'Fueled by our server boosters'}
                delay={0.3}
                categoryLabel={isRtl ? 'التعزيز الفائق' : 'COMMUNITY POWER'}
              />
            </div>
          </div>
        </motion.div>

        {/* ======================================================== */}
        {/* 3D LUMINOUS ENERGY CONDUIT #2                            */}
        {/* ======================================================== */}
        <div className="relative px-6 sm:px-12 flex items-center justify-center pointer-events-none select-none" aria-hidden="true">
          <div className={`w-full max-w-2xl h-px ${
            isMesopotamian
              ? 'bg-gradient-to-r from-transparent via-amber-500/35 to-transparent'
              : 'bg-gradient-to-r from-transparent via-[#5eead4]/25 to-transparent'
          }`} />
          <div className={`absolute w-1.5 h-1.5 rounded-full ${
            isMesopotamian
              ? 'bg-amber-400/90 shadow-[0_0_8px_rgba(245,158,11,0.6)]'
              : 'bg-[#5eead4] shadow-[0_0_10px_#5eead4]'
          }`} />
        </div>

        {/* ======================================================== */}
        {/* PART 3: START YOUR JOURNEY (Culminating Call to Action)    */}
        {/* ======================================================== */}
        <motion.div 
          id="join" 
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="relative z-10 px-4 sm:px-6 text-center"
        >
            {/* Ambient 3D Radial Base Glow */}
            {!isMesopotamian && (
              <div className="absolute bottom-0 start-1/2 -translate-x-1/2 w-[600px] h-[250px] bg-gradient-to-t from-[#5eead4]/15 via-teal-500/8 to-transparent blur-3xl pointer-events-none" />
            )}

            <div className="relative z-10 max-w-2xl mx-auto">
              {/* Eyebrow */}
              <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono tracking-widest uppercase mb-3 font-semibold shadow-xs ${
                isMesopotamian
                  ? 'bg-amber-500/10 border border-amber-500/30 text-amber-300'
                  : 'bg-[#5eead4]/10 border border-[#5eead4]/25 text-[#2dd4bf]'
              }`}>
                <Sparkles size={12} className={isMesopotamian ? 'text-amber-400' : 'text-[#5eead4]'} />
                <span>{t('banner.eyebrow')}</span>
              </div>

              {/* Heading with 3D gradient */}
              <h2 className={`font-black text-2xl sm:text-3xl lg:text-4xl tracking-tight mb-3 leading-tight ${
                isMesopotamian
                  ? 'font-meso-serif text-amber-100 drop-shadow-md'
                  : 'text-transparent bg-clip-text bg-gradient-to-r from-white via-[#f0fdfa] to-[#5eead4] drop-shadow-[0_2px_14px_rgba(45,212,191,0.3)]'
              }`}>
                {t('banner.heading')}
              </h2>

              {/* Subheading */}
              <p className={`text-sm sm:text-base max-w-lg mx-auto leading-relaxed mb-8 font-normal ${
                isMesopotamian ? 'font-serif text-amber-300/80' : 'text-[#99b8b2]'
              }`}>
                {t('banner.subheading')}
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 sm:gap-4 max-w-sm sm:max-w-none mx-auto">
                <button
                  onClick={() => window.open(serverInfo.instantInvite || 'https://discord.gg', '_blank', 'noopener,noreferrer')}
                  className={`w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-2xl font-bold text-sm transition-all duration-200 shadow-[0_10px_30px_rgba(45,212,191,0.3),inset_0_1px_1px_rgba(255,255,255,0.3)] hover:scale-[1.03] active:scale-[0.98] ${
                    isMesopotamian
                      ? 'mesopotamian-btn-gold font-serif text-amber-950 shadow-md hover:brightness-105'
                      : 'btn-nexus-primary'
                  }`}
                >
                  <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24">
                    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.893.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
                  </svg>
                  <span>{t('banner.button')}</span>
                </button>

                <Link
                  to="/guidebook"
                  className={`w-full sm:w-auto text-sm py-3 px-6 rounded-2xl flex items-center justify-center gap-2 hover:scale-[1.03] active:scale-[0.98] transition-all ${
                    isMesopotamian
                      ? 'mesopotamian-stone-bg border border-amber-600/40 text-amber-100 shadow-sm hover:border-amber-500/60'
                      : 'btn-nexus-glass'
                  }`}
                >
                  <BookOpen size={16} className={isMesopotamian ? 'text-amber-400' : 'text-[#5eead4]'} />
                  <span>{isAr ? 'استكشف الدليل' : 'Explore Guidebook'}</span>
                  {isAr ? <ArrowLeft size={16} /> : <ArrowRight size={16} />}
                </Link>
              </div>
            </div>
        </motion.div>
      </div>
    </section>
  );
}
