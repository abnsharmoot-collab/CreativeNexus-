import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useMainMenuBackground } from '../../context/MainMenuBackgroundContext';
import { useEasterEggs } from '../../context/EasterEggContext';

interface MainMenuBackgroundLayerProps {
  className?: string;
  scope?: 'hero' | 'full_page';
}

export const MainMenuBackgroundLayer: React.FC<MainMenuBackgroundLayerProps> = ({ 
  className = '',
  scope = 'hero'
}) => {
  const { getBackgroundForTheme } = useMainMenuBackground();
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  const background = getBackgroundForTheme(activeTheme);

  if (!background || !background.imageUrl) {
    return null;
  }

  // If the owner configured the scope for hero only, and this layer is full_page (or vice versa)
  if (scope === 'full_page' && background.scope === 'hero') {
    return null;
  }

  // In Mesopotamian mode (Kohan's theme), ArchivalBackground already renders the single legendary ancient
  // Iraqi civilization background across the entire website. Returning null here prevents duplicate hero
  // parallax layers or moving backgrounds from appearing behind the server stats.
  if (isMesopotamian) {
    return null;
  }

  const blur = typeof background.blur === 'number' ? background.blur : (isMesopotamian ? 0 : 8);
  const opacity = typeof background.opacity === 'number' ? background.opacity : (isMesopotamian ? 0.85 : 0.65);
  const dim = typeof background.dim === 'number' ? background.dim : (isMesopotamian ? 0.25 : 0.4);
  const objectPosition = background.objectPosition || 'center';

  return (
    <div 
      className={`absolute inset-0 pointer-events-none overflow-hidden z-0 select-none ${className}`}
      aria-hidden="true"
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={background.imageUrl + blur + opacity + dim + activeTheme}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="relative w-full h-full"
        >
          {/* Main Background Image with Blur & Visibility Filter */}
          <div
            className="absolute inset-0 w-full h-full bg-cover bg-no-repeat transition-all duration-300"
            style={{
              backgroundImage: `url(${background.imageUrl})`,
              backgroundPosition: objectPosition,
              filter: blur > 0 ? `blur(${blur}px)` : 'none',
              opacity: opacity,
              transform: blur > 0 ? 'scale(1.12)' : 'none'
            }}
          />

          {/* Dark Overlay Tint for Readability & High Contrast */}
          <div
            className="absolute inset-0 transition-opacity duration-300 pointer-events-none"
            style={{
              backgroundColor: isMesopotamian ? 'rgba(10, 7, 5, 0.45)' : 'rgba(3, 18, 17, 0.68)',
              opacity: dim
            }}
          />

          {/* Vignette Edge Gradients to blend smoothly into page */}
          <div className={`absolute inset-0 ${isMesopotamian ? 'bg-gradient-to-t from-[#0a0705]/80 via-transparent to-[#0a0705]/80' : 'bg-gradient-to-t from-[#031211] via-transparent to-[#031211]/90'}`} />
          <div className={`absolute inset-0 ${isMesopotamian ? 'bg-gradient-to-b from-[#0a0705]/70 via-transparent to-[#0a0705]/90' : 'bg-gradient-to-b from-[#031211]/80 via-transparent to-[#031211]'}`} />
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
