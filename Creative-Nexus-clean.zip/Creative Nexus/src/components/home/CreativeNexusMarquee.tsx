import React from 'react';
import { useLanguage } from '../../context/LanguageContext';

export function CreativeNexusMarquee() {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const items = isAr ? [
    'CREATIVE NEXUS',
    'نـكـسـس',
    'الإبداع',
    'مجتمع بلا حدود',
    'DESIGN & DEV',
    'شغف لا ينتهي',
    'CREATIVE NEXUS',
    'نـكـسـس',
    'الإبداع',
    'مجتمع بلا حدود',
    'DESIGN & DEV',
    'شغف لا ينتهي',
  ] : [
    'CREATIVE NEXUS',
    'COMMUNITY',
    'CREATIVITY',
    'LIMITLESS PASSION',
    'DESIGN & DEV',
    'NEVER SETTLE',
    'CREATIVE NEXUS',
    'COMMUNITY',
    'CREATIVITY',
    'LIMITLESS PASSION',
    'DESIGN & DEV',
    'NEVER SETTLE',
  ];

  return (
    <div className="mq select-none" aria-hidden="true">
      <div className="mt">
        {items.map((item, idx) => (
          <React.Fragment key={idx}>
            <span className="font-semibold text-xs sm:text-sm tracking-widest text-[#99b8b2]">{item}</span>
            <span className="mt-divider" />
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}
