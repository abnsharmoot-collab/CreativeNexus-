import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import { useNavigate, Link } from 'react-router-dom';
import { Megaphone, ArrowRight, ArrowLeft, Radio, Sparkles } from 'lucide-react';
import { useAnnouncements } from '../../context/AnnouncementContext';
import { useLanguage } from '../../context/LanguageContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import CoverflowCarousel, { CoverflowCarouselItem } from '@/components/ui/coverflow-carousel';

// Fallback curated news covers if server has no announcements created yet
const FALLBACK_NEWS_ITEMS = [
  {
    id: 'ann-season-3',
    titleEn: 'Creative Nexus Season 3: System Overhaul & Progression',
    titleAr: 'الموسم الثالث لمجتمع كرييتف نكسس: ترقية الأنظمة وتحديث الرتب',
    category: 'Update',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop&q=80',
    dateEn: 'Active Directive',
    dateAr: 'توجيه نشط'
  },
  {
    id: 'ann-community-guardians',
    titleEn: 'Community Guardians Induction & Verified Security Protocol',
    titleAr: 'اعتماد حراس المجتمع الجدد وتفعيل بروتوكول الحماية',
    category: 'Important',
    image: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
    dateEn: 'Security Briefing',
    dateAr: 'إحاطة أمنية'
  },
  {
    id: 'ann-nitro-boost-3',
    titleEn: 'Discord Nitro Boost Tier 3: 100MB Uploads & Hi-Fi Audio',
    titleAr: 'اكتمال تعزيز الديسكورد للمستوى الثالث: رفع 100MB وصوت فائق الجودة',
    category: 'Event',
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1200&auto=format&fit=crop&q=80',
    dateEn: 'Community Milestone',
    dateAr: 'إنجاز مجتمعي'
  },
  {
    id: 'ann-meso-codex',
    titleEn: 'The Mesopotamian Sovereign Codex Archive Unveiled',
    titleAr: 'إطلاق سجلات بلاد الرافدين والرموز المسمارية الملكية',
    category: 'Community',
    image: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&auto=format&fit=crop&q=80',
    dateEn: 'Heritage Archives',
    dateAr: 'الأرشيف التاريخي'
  },
  {
    id: 'ann-bounty-showcase',
    titleEn: 'Bi-Weekly Creative Nexus Design & Bot Creation Bounty',
    titleAr: 'مكافآت الإبداع نصف الشهرية للمصممين والمطورين في السيرفر',
    category: 'General',
    image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=1200&auto=format&fit=crop&q=80',
    dateEn: 'Creations Room',
    dateAr: 'روم الإبداعات'
  }
];

export const ServerNewsCarousel: React.FC = () => {
  const { announcements, loading } = useAnnouncements();
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';
  const navigate = useNavigate();

  // Map synced announcements from the announcements room into Coverflow Carousel slides
  const carouselItems: CoverflowCarouselItem[] = useMemo(() => {
    if (announcements && announcements.length > 0) {
      return announcements.map((ann, idx) => {
        // Fallback image if announcement has no cover uploaded
        const fallbackImg = FALLBACK_NEWS_ITEMS[idx % FALLBACK_NEWS_ITEMS.length].image;
        const img = ann.imageUrl || (ann.images && ann.images[0]) || fallbackImg;

        let dateLabel = '📢 Announcements';
        try {
          const d = new Date(ann.publishedAt);
          dateLabel = new Intl.DateTimeFormat(isAr ? 'ar-EG' : 'en-US', {
            month: 'short',
            day: 'numeric'
          }).format(d);
        } catch {
          // ignore
        }

        return {
          id: ann.id,
          image: img,
          alt: ann.title,
          title: ann.title,
          category: ann.category || (isAr ? 'إعلان' : 'Announcement'),
          date: dateLabel,
          author: ann.authorDisplayName,
          onClick: () => {
            navigate(`/announcements/${ann.id}`);
          }
        };
      });
    }

    // Default seeded preview announcements if none created yet
    return FALLBACK_NEWS_ITEMS.map((item) => ({
      id: item.id,
      image: item.image,
      alt: isAr ? item.titleAr : item.titleEn,
      title: isAr ? item.titleAr : item.titleEn,
      category: item.category,
      date: isAr ? item.dateAr : item.dateEn,
      onClick: () => {
        navigate(`/announcements/${item.id}`);
      }
    }));
  }, [announcements, isAr, navigate]);

  const handleCardTeleport = (item: CoverflowCarouselItem) => {
    navigate(`/announcements/${item.id}`);
  };

  return (
    <section id="server-news" className="relative z-10 w-full px-4 sm:px-6">
      {/* Header Container */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 sm:gap-6 mb-8 max-w-5xl mx-auto">
        <div className="space-y-2">
          {/* Synchronized Live Room Badge */}
          <div className="flex items-center gap-2">
            <div
              className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-bold tracking-wider uppercase shadow-xs ${
                isMesopotamian
                  ? 'bg-amber-500/10 border border-amber-500/30 text-amber-300'
                  : 'bg-archive-cyan/10 border border-archive-cyan/25 text-archive-cyan'
              }`}
            >
              <span className="relative flex h-2 w-2">
                <span
                  className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                    isMesopotamian ? 'bg-amber-400' : 'bg-archive-cyan'
                  }`}
                />
                <span
                  className={`relative inline-flex rounded-full h-2 w-2 ${
                    isMesopotamian ? 'bg-amber-400' : 'bg-archive-cyan'
                  }`}
                />
              </span>
              <span>
                {isAr ? 'متزامن مع روم 📢│announcements' : 'SYNCED WITH 📢│announcements'}
              </span>
            </div>
          </div>

          <h2
            className={`text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight leading-snug ${
              isMesopotamian
                ? 'font-meso-serif text-amber-100 drop-shadow-md'
                : 'text-white'
            }`}
          >
            {isAr ? 'أخبار وإعلانات السيرفر' : 'Server News & Bulletins'}
          </h2>

          <p
            className={`text-sm sm:text-base leading-relaxed max-w-2xl ${
              isMesopotamian
                ? 'font-serif text-amber-300/80'
                : 'text-archive-paper-muted'
            }`}
          >
            {isAr
              ? 'مزامنة مباشرة مع روم الإعلانات الرسمي. اضغط على أي بطاقة للانتقال فوراً إلى روم الإعلانات وتفاصيل الإعلان كاملة.'
              : 'Direct live synchronization with the announcements room. Click any card to teleport directly into the announcement.'}
          </p>
        </div>

        {/* Teleport to Announcement Room Link */}
        <div className="shrink-0 flex items-center">
          <Link
            to="/announcements"
            id="btn-teleport-announcements-room"
            className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all duration-200 group/btn shadow-md border hover:scale-[1.02] active:scale-[0.98] ${
              isMesopotamian
                ? 'mesopotamian-btn-gold font-serif text-amber-950 border-amber-400/40 hover:brightness-105'
                : 'bg-archive-dark/80 text-archive-cyan border-archive-cyan/30 hover:bg-archive-cyan/15 hover:border-archive-cyan/60'
            }`}
          >
            <Megaphone size={16} className="text-archive-cyan group-hover/btn:rotate-12 transition-transform" />
            <span>{isAr ? 'غرفة الإعلانات الرسمية' : 'Announcements Room'}</span>
            {isAr ? (
              <ArrowLeft size={15} className="group-hover/btn:-translate-x-1 transition-transform" />
            ) : (
              <ArrowRight size={15} className="group-hover/btn:translate-x-1 transition-transform" />
            )}
          </Link>
        </div>
      </div>

      {/* 3D Coverflow Carousel Section */}
      <div className="relative max-w-5xl mx-auto py-2">
        <CoverflowCarousel
          items={carouselItems}
          loop={true}
          autoplay={true}
          autoplayDelay={4500}
          depth={170}
          rotation={38}
          spacing={230}
          scaleStep={0.14}
          onItemClick={handleCardTeleport}
          className="w-full"
        />
      </div>
    </section>
  );
};

export default ServerNewsCarousel;
