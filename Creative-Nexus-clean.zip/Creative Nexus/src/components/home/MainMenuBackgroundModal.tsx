import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Upload, 
  Image as ImageIcon, 
  Sliders, 
  Trash2, 
  Check, 
  AlertCircle, 
  Sparkles, 
  Eye, 
  RefreshCw,
  Layers,
  Crown
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { useMainMenuBackground, SupportedThemeType, DEFAULT_KOHAN_BG } from '../../context/MainMenuBackgroundContext';
import { PresetBackground } from '../../types/menuBackground';
import { MESOPOTAMIAN_ASSETS } from '../../assets/mesopotamianAssets';

// Curated high quality presets for Creative Nexus Theme
const CREATIVE_NEXUS_PRESETS: PresetBackground[] = [
  {
    id: 'singularity-horizon',
    theme: 'creative-nexus',
    nameAr: 'أفق التفرد الكوني (ثقب أسود WebGL2 حي)',
    nameEn: 'Singularity Horizon (Live WebGL2 Black Hole)',
    url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1920&q=80',
    previewUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=400&q=80',
    defaultBlur: 0,
    defaultOpacity: 0.9,
    defaultDim: 0.2
  },
  {
    id: 'cosmic-teal',
    theme: 'creative-nexus',
    nameAr: 'السديم الفيروزي الكوني',
    nameEn: 'Cosmic Teal Nebula',
    url: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=1920&q=80',
    previewUrl: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=400&q=80',
    defaultBlur: 8,
    defaultOpacity: 0.65,
    defaultDim: 0.4
  },
  {
    id: 'cyber-obsidian',
    theme: 'creative-nexus',
    nameAr: 'الشبكة السيبرانية المعتمة',
    nameEn: 'Obsidian Cyber Grid',
    url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1920&q=80',
    previewUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=400&q=80',
    defaultBlur: 4,
    defaultOpacity: 0.55,
    defaultDim: 0.45
  },
  {
    id: 'minimal-aurora',
    theme: 'creative-nexus',
    nameAr: 'الشفق الليلي الهادئ',
    nameEn: 'Minimal Midnight Aurora',
    url: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?auto=format&fit=crop&w=1920&q=80',
    previewUrl: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?auto=format&fit=crop&w=400&q=80',
    defaultBlur: 14,
    defaultOpacity: 0.7,
    defaultDim: 0.35
  },
  {
    id: 'abstract-crystal',
    theme: 'creative-nexus',
    nameAr: 'بلورات الزمرد المظلمة',
    nameEn: 'Dark Emerald Crystals',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1920&q=80',
    previewUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=400&q=80',
    defaultBlur: 10,
    defaultOpacity: 0.6,
    defaultDim: 0.4
  },
  {
    id: 'deep-space',
    theme: 'creative-nexus',
    nameAr: 'أعماق الفضاء النجمي',
    nameEn: 'Deep Stellar Void',
    url: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1920&q=80',
    previewUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=400&q=80',
    defaultBlur: 6,
    defaultOpacity: 0.65,
    defaultDim: 0.4
  }
];

// Curated high quality presets for Kohan Theme (Legendary Ancient Iraqi Civilization)
const KOHAN_MESOPOTAMIAN_PRESETS: PresetBackground[] = [
  {
    id: 'meso-legendary-civilization',
    theme: 'kohan-iraqi',
    nameAr: 'الأسطورة الرافدينية (بابل، عشتار، وأور)',
    nameEn: 'Legendary Mesopotamian Civilization',
    url: MESOPOTAMIAN_ASSETS.heroBg,
    previewUrl: MESOPOTAMIAN_ASSETS.heroBg,
    defaultBlur: 0,
    defaultOpacity: 0.88,
    defaultDim: 0.25
  },
  {
    id: 'meso-papyrus-clay',
    theme: 'kohan-iraqi',
    nameAr: 'مخطوطة البردي واللوح الطيني المسماري',
    nameEn: 'Archival Papyrus & Clay Tablet',
    url: MESOPOTAMIAN_ASSETS.papyrusClayTexture,
    previewUrl: MESOPOTAMIAN_ASSETS.papyrusClayTexture,
    defaultBlur: 0,
    defaultOpacity: 0.85,
    defaultDim: 0.25
  },
  {
    id: 'meso-lamassu-relief',
    theme: 'kohan-iraqi',
    nameAr: 'نقش صرح الثور المجنح (لاماسو)',
    nameEn: 'Winged Lamassu Palace Relief',
    url: MESOPOTAMIAN_ASSETS.lamassuRelief,
    previewUrl: MESOPOTAMIAN_ASSETS.lamassuRelief,
    defaultBlur: 2,
    defaultOpacity: 0.85,
    defaultDim: 0.3
  },
  {
    id: 'meso-frieze-banner',
    theme: 'kohan-iraqi',
    nameAr: 'إفريز المسلة والمخطوطات المسمارية',
    nameEn: 'Imperial Cuneiform Frieze',
    url: MESOPOTAMIAN_ASSETS.friezeBanner,
    previewUrl: MESOPOTAMIAN_ASSETS.friezeBanner,
    defaultBlur: 0,
    defaultOpacity: 0.8,
    defaultDim: 0.32
  },
  {
    id: 'meso-palm-relief',
    theme: 'kohan-iraqi',
    nameAr: 'جنائن النخيل وأشجار بلاد الرافدين',
    nameEn: 'Hanging Palm Sanctuary',
    url: MESOPOTAMIAN_ASSETS.palmRelief,
    previewUrl: MESOPOTAMIAN_ASSETS.palmRelief,
    defaultBlur: 0,
    defaultOpacity: 0.85,
    defaultDim: 0.28
  },
  {
    id: 'meso-king-relief',
    theme: 'kohan-iraqi',
    nameAr: 'صرح الملك البابلي المعظم',
    nameEn: 'Babylonian Sovereign Relief',
    url: MESOPOTAMIAN_ASSETS.kingRelief,
    previewUrl: MESOPOTAMIAN_ASSETS.kingRelief,
    defaultBlur: 3,
    defaultOpacity: 0.82,
    defaultDim: 0.35
  }
];

// Fallback raw file reader as Data URL
function readRawFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve((e.target?.result as string) || '');
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

// Helper to compress an image file to a lightweight base64 Data URL
async function compressImageFile(file: File): Promise<string> {
  if (file.type === 'image/svg+xml') {
    return readRawFileAsDataUrl(file);
  }

  if (typeof createImageBitmap === 'function') {
    try {
      const bitmap = await createImageBitmap(file);
      const MAX_WIDTH = 1920;
      const MAX_HEIGHT = 1080;
      let width = bitmap.width;
      let height = bitmap.height;

      if (width > MAX_WIDTH || height > MAX_HEIGHT) {
        if (width / height > MAX_WIDTH / MAX_HEIGHT) {
          height = Math.round((height * MAX_WIDTH) / width);
          width = MAX_WIDTH;
        } else {
          width = Math.round((width * MAX_HEIGHT) / height);
          height = MAX_HEIGHT;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(bitmap, 0, 0, width, height);
        bitmap.close();
        return canvas.toDataURL('image/jpeg', 0.82);
      }
    } catch {}
  }

  return readRawFileAsDataUrl(file);
}

export const MainMenuBackgroundModal: React.FC = () => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { isOwner } = useAuth();
  const { 
    creativeNexusBackground,
    kohanBackground,
    isEditModalOpen, 
    closeEditModal, 
    targetEditTheme,
    setTargetEditTheme,
    updateBackground, 
    removeBackground,
    isKohanSyncedWithMainMenu,
    setIsKohanSyncedWithMainMenu,
    syncKohanWithMainMenu
  } = useMainMenuBackground();

  // Active theme tab currently being customized
  const [activeTab, setActiveTab] = useState<SupportedThemeType>('creative-nexus');

  const [imageUrl, setImageUrl] = useState<string>('');
  const [urlInput, setUrlInput] = useState<string>('');
  const [opacity, setOpacity] = useState<number>(0.65);
  const [blur, setBlur] = useState<number>(8);
  const [dim, setDim] = useState<number>(0.4);
  const [objectPosition, setObjectPosition] = useState<string>('center');
  const [scope, setScope] = useState<'hero' | 'full_page'>('hero');

  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync activeTab with targetEditTheme when modal opens
  useEffect(() => {
    if (isEditModalOpen) {
      setActiveTab(targetEditTheme || 'creative-nexus');
    }
  }, [isEditModalOpen, targetEditTheme]);

  // Load configuration for the selected theme tab
  const loadThemeConfig = (theme: SupportedThemeType) => {
    if (theme === 'kohan-iraqi') {
      const bg = kohanBackground || DEFAULT_KOHAN_BG;
      setImageUrl(bg.imageUrl || DEFAULT_KOHAN_BG.imageUrl);
      setUrlInput(bg.imageUrl?.startsWith('data:') ? '' : (bg.imageUrl || ''));
      setOpacity(typeof bg.opacity === 'number' ? bg.opacity : 0.85);
      setBlur(typeof bg.blur === 'number' ? bg.blur : 0);
      setDim(typeof bg.dim === 'number' ? bg.dim : 0.25);
      setObjectPosition(bg.objectPosition || 'center');
      setScope(bg.scope || 'full_page');
    } else {
      const bg = creativeNexusBackground;
      if (bg) {
        setImageUrl(bg.imageUrl || '');
        setUrlInput(bg.imageUrl?.startsWith('data:') ? '' : (bg.imageUrl || ''));
        setOpacity(typeof bg.opacity === 'number' ? bg.opacity : 0.65);
        setBlur(typeof bg.blur === 'number' ? bg.blur : 8);
        setDim(typeof bg.dim === 'number' ? bg.dim : 0.4);
        setObjectPosition(bg.objectPosition || 'center');
        setScope(bg.scope || 'hero');
      } else {
        setImageUrl('');
        setUrlInput('');
        setOpacity(0.65);
        setBlur(8);
        setDim(0.4);
        setObjectPosition('center');
        setScope('hero');
      }
    }
    setStatusMessage(null);
  };

  // Reload config when activeTab changes or modal opens
  useEffect(() => {
    if (isEditModalOpen) {
      loadThemeConfig(activeTab);
    }
  }, [isEditModalOpen, activeTab, creativeNexusBackground, kohanBackground]);

  if (!isEditModalOpen || !isOwner) {
    return null;
  }

  const isKohanMode = activeTab === 'kohan-iraqi';
  const currentPresets = isKohanMode ? KOHAN_MESOPOTAMIAN_PRESETS : CREATIVE_NEXUS_PRESETS;

  // Handle local image file upload
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/') && !/\.(png|jpe?g|webp|gif|svg|avif)$/i.test(file.name)) {
      setStatusMessage({
        text: isAr ? 'يرجى اختيار ملف صورة صالح (PNG, JPG, WebP, SVG)' : 'Please select a valid image file',
        type: 'error'
      });
      return;
    }

    try {
      setIsUploading(true);
      setStatusMessage(null);
      const dataUrl = await compressImageFile(file);
      setImageUrl(dataUrl);
      setUrlInput('');
      setStatusMessage({
        text: isAr ? 'تم تحميل الصورة بنجاح! يمكنك الآن ضبط مستوى الضبابية والظهور' : 'Image loaded! You can now adjust blur and opacity',
        type: 'success'
      });
    } catch (err) {
      try {
        const raw = await readRawFileAsDataUrl(file);
        setImageUrl(raw);
        setUrlInput('');
        setStatusMessage({
          text: isAr ? 'تم تحميل الصورة بنجاح!' : 'Image loaded successfully!',
          type: 'success'
        });
      } catch (fErr) {
        setStatusMessage({
          text: isAr ? 'فشل تحميل الصورة، يرجى المحاولة بصيغة أخرى' : 'Failed to load image',
          type: 'error'
        });
      }
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleUrlInputChange = (val: string) => {
    setUrlInput(val);
    const trimmed = val.trim();
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://') || trimmed.startsWith('data:') || trimmed.startsWith('/')) {
      setImageUrl(trimmed);
    }
  };

  const handleApplyUrl = () => {
    const trimmed = urlInput.trim();
    if (!trimmed) return;
    const finalUrl = (trimmed.startsWith('http://') || trimmed.startsWith('https://') || trimmed.startsWith('data:') || trimmed.startsWith('/'))
      ? trimmed
      : `https://${trimmed}`;
    setImageUrl(finalUrl);
    setUrlInput(finalUrl);
    setStatusMessage({
      text: isAr ? 'تم تطبيق رابط الصورة' : 'Image URL applied',
      type: 'success'
    });
  };

  const handleSelectPreset = (preset: PresetBackground) => {
    setImageUrl(preset.url);
    setUrlInput(preset.url);
    setBlur(preset.defaultBlur);
    setOpacity(preset.defaultOpacity);
    setDim(preset.defaultDim);
    setStatusMessage({
      text: isAr ? `تم اختيار: ${preset.nameAr}` : `Selected: ${preset.nameEn}`,
      type: 'success'
    });
  };

  // Save changes exclusively for activeTab theme
  const handleSave = async () => {
    const trimmedInput = urlInput.trim();
    let targetUrl = imageUrl.trim();

    if (!targetUrl && trimmedInput) {
      targetUrl = (trimmedInput.startsWith('http://') || trimmedInput.startsWith('https://') || trimmedInput.startsWith('data:') || trimmedInput.startsWith('/'))
        ? trimmedInput
        : `https://${trimmedInput}`;
      setImageUrl(targetUrl);
    }

    if (!targetUrl) {
      setStatusMessage({
        text: isAr ? 'يرجى اختيار صورة أو نموذج أولاً' : 'Please select an image or preset first',
        type: 'error'
      });
      return;
    }

    setIsSaving(true);
    setStatusMessage(null);

    const res = await updateBackground({
      imageUrl: targetUrl,
      opacity,
      blur,
      dim,
      objectPosition,
      scope,
      theme: activeTab
    }, activeTab);

    setIsSaving(false);

    if (res.success) {
      setStatusMessage({
        text: isAr 
          ? `تم حفظ وتطبيق خلفية ثيم ${isKohanMode ? 'كوهان (بلاد الرافدين)' : 'كريتيف نيكسس'} بشكل منفصل بنجاح!` 
          : `${isKohanMode ? "Kohan's Theme" : 'Creative Nexus'} background saved separately!`,
        type: 'success'
      });
      setTimeout(() => {
        closeEditModal();
      }, 700);
    } else {
      setStatusMessage({
        text: res.error || (isAr ? 'تم حفظ التعديل بنجاح' : 'Background applied successfully'),
        type: res.error ? 'error' : 'success'
      });
    }
  };

  // Reset exclusively for activeTab theme
  const handleDelete = async () => {
    const confirmText = isAr 
      ? `هل تريد إعادة تعيين خلفية ثيم ${isKohanMode ? 'كوهان (بلاد الرافدين)' : 'كريتيف نيكسس'} إلى الوضع الافتراضي؟` 
      : `Reset ${isKohanMode ? "Kohan's Theme" : 'Creative Nexus'} background to default?`;

    if (!window.confirm(confirmText)) {
      return;
    }

    setIsDeleting(true);
    setStatusMessage(null);

    const res = await removeBackground(activeTab);
    setIsDeleting(false);

    if (res.success) {
      loadThemeConfig(activeTab);
      setStatusMessage({
        text: isAr 
          ? `تمت استعادة الخلفية الافتراضية لثيم ${isKohanMode ? 'كوهان' : 'كريتيف نيكسس'} بنجاح` 
          : `${isKohanMode ? "Kohan's Theme" : 'Creative Nexus'} background reset to default`,
        type: 'success'
      });
      setTimeout(() => {
        closeEditModal();
      }, 800);
    }
  };

  const handleSyncKohanWithMainMenu = async () => {
    setIsSaving(true);
    setStatusMessage(null);
    const res = await syncKohanWithMainMenu();
    setIsSaving(false);

    if (res.success) {
      loadThemeConfig('kohan-iraqi');
      setStatusMessage({
        text: isAr 
          ? 'تمت مزامنة خلفية ثيم كوهان مع خلفية القائمة الرئيسية بنجاح!' 
          : "Kohan's theme background synced with main menu background successfully!",
        type: 'success'
      });
    } else {
      setStatusMessage({
        text: res.error || (isAr ? 'فشلت المزامنة' : 'Sync failed'),
        type: 'error'
      });
    }
  };

  if (!isEditModalOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={closeEditModal}
          className="fixed inset-0 bg-black/80 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className={`relative w-full max-w-3xl rounded-3xl bg-[#061013] border text-slate-100 shadow-[0_20px_60px_rgba(0,0,0,0.85)] overflow-hidden z-10 my-auto ${
            isKohanMode ? 'border-amber-500/40' : 'border-cyan-500/30'
          }`}
        >
          {/* Header */}
          <div className={`relative px-6 py-5 border-b border-slate-800/80 flex items-center justify-between ${
            isKohanMode 
              ? 'bg-gradient-to-r from-amber-950/40 via-[#0e0a07] to-yellow-950/30' 
              : 'bg-gradient-to-r from-cyan-950/40 via-transparent to-teal-950/30'
          }`}>
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl border flex items-center justify-center ${
                isKohanMode 
                  ? 'bg-amber-500/10 border-amber-500/40 text-amber-300' 
                  : 'bg-cyan-500/10 border-cyan-500/30 text-cyan-300'
              }`}>
                {isKohanMode ? <Crown size={20} /> : <ImageIcon size={20} />}
              </div>
              <div>
                <h3 className="font-cairo font-bold text-lg text-white">
                  {isAr ? 'تخصيص خلفيات الثيمات المستقلة' : 'Theme Background Customizer'}
                </h3>
                <p className="font-cairo text-xs text-slate-400">
                  {isAr 
                    ? 'كل ثيم له تخصيصه المستقل المنفصل تماماً عن الثيم الآخر' 
                    : 'Every theme customization is fully isolated and standalone'}
                </p>
              </div>
            </div>

            <button
              onClick={closeEditModal}
              className="w-9 h-9 rounded-xl bg-white/[0.05] border border-white/10 flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>

          {/* Theme Selector Tabs (Every Theme Customization Alone & Separated) */}
          <div className="px-6 pt-4 pb-0 bg-slate-950/40 border-b border-slate-800/60 flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setActiveTab('creative-nexus');
                setTargetEditTheme('creative-nexus');
              }}
              className={`px-4 py-2.5 rounded-t-xl font-cairo font-bold text-xs flex items-center gap-2 border-t border-x transition-all cursor-pointer ${
                activeTab === 'creative-nexus'
                  ? 'bg-[#061013] text-cyan-300 border-cyan-500/40 shadow-xs'
                  : 'bg-transparent text-slate-400 border-transparent hover:text-white hover:bg-slate-900/50'
              }`}
            >
              <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#5eead4]" />
              <span>{isAr ? 'ثيم كريتيف نيكسس (الافتراضي)' : 'Creative Nexus Theme'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab('kohan-iraqi');
                setTargetEditTheme('kohan-iraqi');
              }}
              className={`px-4 py-2.5 rounded-t-xl font-cairo font-bold text-xs flex items-center gap-2 border-t border-x transition-all cursor-pointer ${
                activeTab === 'kohan-iraqi'
                  ? 'bg-[#061013] text-amber-300 border-amber-500/40 shadow-xs'
                  : 'bg-transparent text-slate-400 border-transparent hover:text-white hover:bg-slate-900/50'
              }`}
            >
              <div className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_8px_#f59e0b]" />
              <span>{isAr ? 'ثيم كوهان (بلاد الرافدين)' : "Kohan's Theme (Mesopotamian)"}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {isAr ? 'منفصل' : 'Separated'}
              </span>
            </button>
          </div>

          {/* Modal Body */}
          <div className="p-5 sm:p-7 space-y-6 max-h-[calc(85vh-170px)] overflow-y-auto custom-scrollbar">
            {/* Kohan & Main Menu Sync Controls */}
            {isKohanMode && (
              <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-amber-950/50 via-[#18110b] to-yellow-950/40 border border-amber-500/40 shadow-md flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300 shrink-0">
                    <Sparkles size={18} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-cairo font-bold text-xs text-amber-200">
                        {isAr ? 'مزامنة مع خلفية القائمة الرئيسية' : 'Sync with Main Menu Background'}
                      </span>
                      {isKohanSyncedWithMainMenu && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold">
                          {isAr ? 'متزامن حالياً' : 'Synced'}
                        </span>
                      )}
                    </div>
                    <p className="font-cairo text-[11px] text-amber-200/70">
                      {isAr
                        ? 'تطبيق خلفية القائمة الرئيسية (كريتيف نيكسس) مباشرة على ثيم كوهان بضغطة واحدة'
                        : "Mirror the Main Menu background directly to Kohan's theme with 1 click"}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                  <button
                    type="button"
                    disabled={isSaving}
                    onClick={handleSyncKohanWithMainMenu}
                    className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 font-cairo font-bold text-xs shadow-md shadow-amber-500/20 flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                  >
                    <RefreshCw size={13} className={isSaving ? 'animate-spin' : ''} />
                    <span>{isAr ? 'مزامنة فورية الآن' : 'Sync Now'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsKohanSyncedWithMainMenu(!isKohanSyncedWithMainMenu)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-cairo font-semibold border transition-all cursor-pointer ${
                      isKohanSyncedWithMainMenu
                        ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                        : 'bg-black/30 border-white/10 text-slate-400 hover:text-white'
                    }`}
                    title={isAr ? 'تفعيل أو إيقاف المزامنة التلقائية' : 'Toggle auto-sync'}
                  >
                    {isKohanSyncedWithMainMenu
                      ? (isAr ? '✓ مزامنة دائمة نشطة' : '✓ Auto-Sync ON')
                      : (isAr ? 'مزامنة يدوية' : 'Manual')}
                  </button>
                </div>
              </div>
            )}

            {/* Live Interactive Preview */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="font-cairo font-semibold text-xs text-slate-300 flex items-center gap-1.5">
                  <Eye size={14} className={isKohanMode ? 'text-amber-400' : 'text-cyan-400'} />
                  <span>
                    {isAr 
                      ? `معاينة خلفية ثيم ${isKohanMode ? 'كوهان (بلاد الرافدين)' : 'كريتيف نيكسس'}:` 
                      : `Live Preview for ${isKohanMode ? "Kohan's Theme" : 'Creative Nexus'}:`}
                  </span>
                </label>
                <span className={`text-[11px] font-mono ${isKohanMode ? 'text-amber-400/80' : 'text-cyan-400/80'}`}>
                  Blur: {blur}px · Opacity: {Math.round(opacity * 100)}% · Dim: {Math.round(dim * 100)}%
                </span>
              </div>

              <div className={`relative h-44 sm:h-52 w-full rounded-2xl border overflow-hidden flex flex-col items-center justify-center text-center p-4 shadow-inner ${
                isKohanMode ? 'border-amber-600/40 bg-[#090503]' : 'border-slate-700/60 bg-[#030a0d]'
              }`}>
                {imageUrl ? (
                  <>
                    <div
                      className="absolute inset-0 bg-cover bg-center transition-all duration-150 pointer-events-none"
                      style={{
                        backgroundImage: `url(${imageUrl})`,
                        backgroundPosition: objectPosition,
                        filter: blur > 0 ? `blur(${blur}px)` : 'none',
                        opacity: opacity,
                        transform: blur > 0 ? 'scale(1.08)' : 'none'
                      }}
                    />
                    <div
                      className="absolute inset-0 bg-black pointer-events-none transition-opacity"
                      style={{ opacity: dim }}
                    />
                  </>
                ) : (
                  <div className="text-slate-500 text-xs font-cairo">
                    {isAr ? 'الخلفية الافتراضية نشطة' : 'Default backdrop active'}
                  </div>
                )}

                {/* Simulated Hero Content */}
                <div className="relative z-10 select-none pointer-events-none flex flex-col items-center">
                  <div className={`text-xs font-mono font-bold uppercase tracking-widest mb-1 ${
                    isKohanMode ? 'text-amber-400' : 'text-cyan-400'
                  }`}>
                    {isKohanMode ? '— 𒀭 𒆠 𒈗 𒂍 —' : 'CREATIVE NEXUS'}
                  </div>
                  <h4 className={`font-black text-2xl sm:text-3xl text-white drop-shadow-md ${
                    isKohanMode ? 'font-meso-serif mesopotamian-gold-text' : 'font-messiri'
                  }`}>
                    {isAr ? 'مركز الإبداع' : 'Creative Nexus'}
                  </h4>
                  <div className="flex items-center gap-2 mt-3">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold shadow-xs ${
                      isKohanMode ? 'bg-amber-400 text-amber-950 font-serif' : 'bg-[#2dd4bf] text-black'
                    }`}>
                      {isAr ? 'انضم للمجتمع' : 'Join Community'}
                    </span>
                    <span className="px-3 py-1 rounded-full text-[10px] font-semibold bg-white/10 text-white border border-white/20">
                      {isAr ? 'استكشف التاريخ' : 'History'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Sliders: Blur & Opacity Controls */}
            <div className={`grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-white/[0.02] border ${
              isKohanMode ? 'border-amber-900/40' : 'border-slate-800'
            }`}>
              {/* Blur Control */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-cairo font-semibold">
                  <span className="text-slate-200">{isAr ? 'مستوى الضبابية (Blur)' : 'Blur Radius'}</span>
                  <span className={`font-mono px-2 py-0.5 rounded border ${
                    isKohanMode 
                      ? 'text-amber-400 bg-amber-950/60 border-amber-500/30' 
                      : 'text-cyan-400 bg-cyan-950/60 border-cyan-500/30'
                  }`}>
                    {blur}px
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="40"
                  step="1"
                  value={blur}
                  onChange={(e) => setBlur(parseInt(e.target.value))}
                  className={`w-full cursor-pointer h-1.5 bg-slate-800 rounded-lg appearance-none ${
                    isKohanMode ? 'accent-amber-400' : 'accent-cyan-400'
                  }`}
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-cairo">
                  <span>{isAr ? '0px (واضحة حادة)' : '0px (Sharp)'}</span>
                  <span>{isAr ? '40px (ضبابية ناعمة)' : '40px (Soft)'}</span>
                </div>
              </div>

              {/* Opacity Control */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-cairo font-semibold">
                  <span className="text-slate-200">{isAr ? 'درجة الظهور (Visibility)' : 'Visibility / Opacity'}</span>
                  <span className={`font-mono px-2 py-0.5 rounded border ${
                    isKohanMode 
                      ? 'text-amber-400 bg-amber-950/60 border-amber-500/30' 
                      : 'text-cyan-400 bg-cyan-950/60 border-cyan-500/30'
                  }`}>
                    {Math.round(opacity * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="1"
                  step="0.05"
                  value={opacity}
                  onChange={(e) => setOpacity(parseFloat(e.target.value))}
                  className={`w-full cursor-pointer h-1.5 bg-slate-800 rounded-lg appearance-none ${
                    isKohanMode ? 'accent-amber-400' : 'accent-cyan-400'
                  }`}
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-cairo">
                  <span>{isAr ? '10% (خافتة)' : '10% (Subtle)'}</span>
                  <span>{isAr ? '100% (بارزة)' : '100% (Full)'}</span>
                </div>
              </div>

              {/* Dark Overlay Tint */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-cairo font-semibold">
                  <span className="text-slate-200">{isAr ? 'تعتيم التباين لسهولة القراءة' : 'Dark Overlay Tint'}</span>
                  <span className={`font-mono px-2 py-0.5 rounded border ${
                    isKohanMode 
                      ? 'text-amber-400 bg-amber-950/60 border-amber-500/30' 
                      : 'text-cyan-400 bg-cyan-950/60 border-cyan-500/30'
                  }`}>
                    {Math.round(dim * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="0.85"
                  step="0.05"
                  value={dim}
                  onChange={(e) => setDim(parseFloat(e.target.value))}
                  className={`w-full cursor-pointer h-1.5 bg-slate-800 rounded-lg appearance-none ${
                    isKohanMode ? 'accent-amber-400' : 'accent-cyan-400'
                  }`}
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-cairo">
                  <span>{isAr ? '0% (بدون تعتيم)' : '0% (None)'}</span>
                  <span>{isAr ? '85% (تعتيم عميق للنصوص)' : '85% (Deep)'}</span>
                </div>
              </div>

              {/* Object Position */}
              <div className="space-y-2">
                <span className="text-xs font-cairo font-semibold text-slate-200 block">
                  {isAr ? 'محاذاة تموضع الصورة' : 'Image Position'}
                </span>
                <div className="flex gap-2">
                  {[
                    { id: 'top', labelAr: 'أعلى', labelEn: 'Top' },
                    { id: 'center', labelAr: 'وسط', labelEn: 'Center' },
                    { id: 'bottom', labelAr: 'أسفل', labelEn: 'Bottom' },
                  ].map((pos) => (
                    <button
                      key={pos.id}
                      type="button"
                      onClick={() => setObjectPosition(pos.id)}
                      className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-cairo font-medium border transition-colors cursor-pointer ${
                        objectPosition === pos.id
                          ? (isKohanMode 
                              ? 'bg-amber-950/70 border-amber-400 text-amber-200 font-bold' 
                              : 'bg-cyan-950/70 border-cyan-400 text-cyan-200 font-bold')
                          : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      {isAr ? pos.labelAr : pos.labelEn}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Image Selection Methods */}
            <div className="space-y-4">
              <span className="font-cairo font-semibold text-xs text-slate-300 block">
                {isAr 
                  ? `طريقة اختيار خلفية (${isKohanMode ? 'ثيم كوهان الرافديني' : 'ثيم كريتيف نيكسس'})` 
                  : `Select Image Source (${isKohanMode ? "Kohan's Theme" : 'Creative Nexus'})`}
              </span>

              {/* 1. Upload from Device */}
              <div className="flex flex-col sm:flex-row items-center gap-3">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <button
                  type="button"
                  disabled={isUploading}
                  onClick={() => fileInputRef.current?.click()}
                  className={`w-full sm:w-auto px-4 py-2.5 rounded-xl border font-cairo font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                    isKohanMode 
                      ? 'bg-amber-950/60 border-amber-500/40 text-amber-200 hover:bg-amber-900/60' 
                      : 'bg-cyan-950/60 border-cyan-500/40 text-cyan-200 hover:bg-cyan-900/60'
                  }`}
                >
                  <Upload size={15} />
                  <span>
                    {isUploading 
                      ? (isAr ? 'جارِ معالجة الصورة...' : 'Processing...') 
                      : (isAr ? `رفع صورة لثيم ${isKohanMode ? 'كوهان' : 'نيكسس'}` : 'Upload Image')}
                  </span>
                </button>

                <span className="text-xs text-slate-500 font-cairo hidden sm:inline">
                  {isAr ? 'أو أدخل رابطاً مباشراً:' : 'or direct link:'}
                </span>

                {/* 2. Direct Image URL */}
                <div className="flex-1 flex gap-2 w-full">
                  <div className="relative flex-1">
                    <input
                      type="url"
                      placeholder="https://example.com/image.jpg"
                      value={urlInput}
                      onChange={(e) => handleUrlInputChange(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleApplyUrl();
                        }
                      }}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleApplyUrl}
                    className="px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs font-cairo font-semibold text-slate-200 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer shrink-0"
                  >
                    {isAr ? 'تطبيق' : 'Apply'}
                  </button>
                </div>
              </div>

              {/* 3. Curated Presets for Current Theme */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center gap-1.5 text-xs font-cairo text-slate-400">
                  <Sparkles size={13} className={isKohanMode ? 'text-amber-400' : 'text-cyan-400'} />
                  <span>
                    {isAr 
                      ? (isKohanMode ? 'نماذج الحضارة الرافدينية والعراقية الأصيلة:' : 'نماذج كريتيف نيكسس الجاهزة:') 
                      : (isKohanMode ? 'Ancient Mesopotamian Artifact & Architecture Presets:' : 'Curated Creative Nexus Presets:')}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                  {currentPresets.map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => handleSelectPreset(preset)}
                      className={`group relative rounded-xl overflow-hidden border p-1 text-center transition-all cursor-pointer ${
                        imageUrl === preset.url
                          ? (isKohanMode ? 'border-amber-400 ring-2 ring-amber-500/30' : 'border-cyan-400 ring-2 ring-cyan-500/30')
                          : 'border-slate-800 hover:border-slate-600'
                      }`}
                    >
                      <div className="h-16 w-full rounded-lg overflow-hidden bg-slate-900 mb-1.5 relative">
                        <img
                          src={preset.previewUrl}
                          alt={preset.nameEn}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                        <div className="absolute inset-0 bg-black/20" />
                      </div>
                      <span className="text-[10px] font-cairo font-medium text-slate-300 block line-clamp-1">
                        {isAr ? preset.nameAr : preset.nameEn}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Status Message */}
            {statusMessage && (
              <div className={`p-3 rounded-xl text-xs font-cairo flex items-center gap-2 ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-950/50 border border-emerald-500/40 text-emerald-200'
                  : 'bg-rose-950/50 border border-rose-500/40 text-rose-200'
              }`}>
                {statusMessage.type === 'success' ? <Check size={14} /> : <AlertCircle size={14} />}
                <span>{statusMessage.text}</span>
              </div>
            )}
          </div>

          {/* Modal Footer */}
          <div className="px-6 py-4 border-t border-slate-800/80 bg-slate-950/60 flex flex-wrap items-center justify-between gap-3">
            <div>
              <button
                type="button"
                disabled={isDeleting || isSaving}
                onClick={handleDelete}
                className="px-3.5 py-2 rounded-xl text-xs font-cairo font-medium text-rose-400 hover:text-rose-200 hover:bg-rose-950/50 border border-rose-900/40 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 size={14} />
                <span>
                  {isDeleting 
                    ? (isAr ? 'جارِ الاستعادة...' : 'Resetting...') 
                    : (isAr ? `استعادة افتراضي (${isKohanMode ? 'كوهان' : 'نيكسس'})` : 'Reset Theme Default')}
                </span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={closeEditModal}
                className="px-4 py-2 rounded-xl text-xs font-cairo font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>

              <button
                type="button"
                disabled={isSaving || (!imageUrl && !urlInput.trim())}
                onClick={handleSave}
                className={`px-5 py-2.5 rounded-xl font-cairo font-bold text-xs shadow-lg transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                  isKohanMode
                    ? 'bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 shadow-amber-500/20'
                    : 'bg-gradient-to-r from-teal-400 to-cyan-500 hover:from-teal-300 hover:to-cyan-400 text-slate-950 shadow-cyan-500/20'
                }`}
              >
                {isSaving ? <RefreshCw size={14} className="animate-spin" /> : <Check size={14} />}
                <span>
                  {isSaving 
                    ? (isAr ? 'جارِ الحفظ...' : 'Saving...') 
                    : (isAr ? `حفظ خلفية (${isKohanMode ? 'ثيم كوهان' : 'ثيم نيكسس'})` : 'Save Theme Background')}
                </span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
