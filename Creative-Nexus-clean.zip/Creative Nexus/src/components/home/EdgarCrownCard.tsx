import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { useLanguage } from '../../context/LanguageContext';
import { CountryFlag } from '../atoms/CountryFlag';
import { Crown, Sparkles, Sun, ArrowUpRight } from 'lucide-react';
import { useOwnerCardBackgrounds } from '../../context/OwnerCardBackgroundsContext';
import { OwnerCardBackgroundLayer } from '../history/OwnerCardBackgroundLayer';
import { OwnerCardEffectLayer } from '../history/OwnerCardEffectLayer';
import { getAccentColor } from '../../utils/ownerCardStyles';
import { useScroll3DTilt } from '../../hooks/useScroll3DTilt';

export const EdgarCrownCard: React.FC = () => {
  const navigate = useNavigate();
  const { t, language } = useLanguage();
  const isRtl = language === 'ar';
  const { getCustomization } = useOwnerCardBackgrounds();

  const custom = getCustomization('owner_edgar');

  const displayName = custom?.displayName || custom?.name || t('owner.edgar.name');
  const roleTitle = custom?.roleTitle || t('owner.edgar.title');
  const roleSubtitle = custom?.badge || t('owner.edgar.role');
  const narrativeDesc = custom?.subtitle || t('owner.edgar.desc');
  const country = (custom?.country as any) || 'egypt';
  const accent = getAccentColor(custom?.accentColor || 'amber');
  const effect = custom?.effect || 'solar';
  const glowIntensity = typeof custom?.glowIntensity === 'number' ? custom.glowIntensity : 0.6;
  const borderStyle = custom?.borderStyle || 'glow';

  // 3D tilt and scroll interaction states
  const cardRef = useRef<HTMLDivElement>(null);
  const [hoverRotateX, setHoverRotateX] = useState<number>(0);
  const [hoverRotateY, setHoverRotateY] = useState<number>(0);
  const [hoverGlare, setHoverGlare] = useState<{ x: number; y: number; opacity: number }>({ x: 50, y: 50, opacity: 0 });
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState<boolean>(false);
  const lastTapRef = useRef<number>(0);

  const handleCardInteraction = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button, a, input, select')) return;
    const now = Date.now();
    const timeDiff = now - lastTapRef.current;
    if (timeDiff < 400 && timeDiff > 0) {
      navigate('/owner/owner_edgar');
      lastTapRef.current = 0;
    } else {
      lastTapRef.current = now;
    }
  };

  const handleCardDoubleClick = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button, a, input, select')) return;
    navigate('/owner/owner_edgar');
  };

  useEffect(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
      setPrefersReducedMotion(mq.matches);
      const listener = (e: MediaQueryListEvent) => setPrefersReducedMotion(e.matches);
      mq.addEventListener('change', listener);
      return () => mq.removeEventListener('change', listener);
    }
  }, []);

  // Smooth scroll 3D tilt & dynamic lighten-up (in both directions: down and up / going back)
  const scrollTilt = useScroll3DTilt({
    cardRef,
    isAlternate: false,
    isHovered,
    hoverRotateX,
    hoverRotateY,
    maxTiltX: 2.2,
    maxTiltY: 1.4,
    accentColorHex: '#f59e0b',
    glowIntensity,
    enabled: true,
  });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (prefersReducedMotion || !cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const width = rect.width;
    const height = rect.height;

    const normX = Math.max(-1, Math.min(1, (x / width) * 2 - 1));
    const normY = Math.max(-1, Math.min(1, (y / height) * 2 - 1));

    // Controlled sovereign tilt for interactive cursor hover
    setHoverRotateX(-normY * 4.0);
    setHoverRotateY(normX * 4.0);
    setHoverGlare({
      x: Math.round((x / width) * 100),
      y: Math.round((y / height) * 100),
      opacity: 0.8
    });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setHoverRotateX(0);
    setHoverRotateY(0);
    setHoverGlare(prev => ({ ...prev, opacity: 0 }));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className="relative w-full max-w-4xl mx-auto select-none"
      style={{ perspective: 1200 }}
    >
      {/* Cinematic Golden Solar Aura (Blooms and expands when scrolling through or hovering) */}
      <div 
        className="absolute -inset-1 bg-gradient-to-r from-amber-500/25 via-yellow-400/20 to-teal-500/20 rounded-[2.6rem] blur-xl pointer-events-none transition-all duration-300" 
        style={{
          opacity: isHovered ? 1.0 : (0.7 + scrollTilt.lightenProgress * 0.3),
          transform: `scale(${isHovered ? 1.02 : scrollTilt.auraScale})`,
        }}
      />
      
      {/* Outer Pharaonic Sun Radiance Pulsing */}
      <div className="absolute -top-16 start-1/2 -translate-x-1/2 rtl:translate-x-1/2 w-80 h-32 bg-radial from-amber-400/20 via-amber-500/5 to-transparent blur-xl pointer-events-none animate-solar-radiance" />

      {/* 3D Tilted Card Body */}
      <div 
        ref={cardRef}
        role="button"
        tabIndex={0}
        onClick={handleCardInteraction}
        onDoubleClick={handleCardDoubleClick}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            navigate('/owner/owner_edgar');
          }
        }}
        onMouseMove={handleMouseMove}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={handleMouseLeave}
        style={{
          transform: isHovered
            ? (prefersReducedMotion ? 'none' : `perspective(1200px) rotateX(${hoverRotateX}deg) rotateY(${hoverRotateY}deg) scale3d(1.012, 1.012, 1.012) translateY(-4px)`)
            : scrollTilt.transform,
          transformStyle: 'preserve-3d',
          transition: isHovered 
            ? 'box-shadow 0.2s ease-out, filter 0.2s ease-out' 
            : 'box-shadow 0.35s ease, filter 0.35s ease',
          boxShadow: isHovered 
            ? `${-hoverRotateY * 3}px ${hoverRotateX * 3 + 22}px 50px -10px rgba(0, 0, 0, 0.8), 0 0 35px rgba(245, 158, 11, 0.4)`
            : scrollTilt.boxShadowStyle,
          filter: isHovered ? 'brightness(1.12) contrast(1.02)' : scrollTilt.filterStyle,
        }}
        className={`group relative rounded-[2.5rem] border-2 cursor-pointer ${accent.borderClass} ${accent.hoverBorderClass} bg-gradient-to-b from-[#09161a] via-archive-dark to-[#050f12] p-8 sm:p-12 md:p-14 overflow-hidden backdrop-blur-md`}
      >
        {/* Dynamic Light Sweep Layer when scrolling through or hovering */}
        <div
          className="absolute inset-0 pointer-events-none rounded-[inherit] transition-opacity duration-300 z-15 overflow-hidden"
          style={{
            opacity: isHovered ? 0.35 : scrollTilt.lightenProgress * 0.42,
          }}
          aria-hidden="true"
        >
          <div
            className="absolute -inset-full bg-gradient-to-tr from-transparent via-amber-200/15 to-transparent pointer-events-none"
            style={{
              transform: `translateY(${(50 - scrollTilt.glarePos.y) * 1.5}%) rotate(-25deg)`,
              transition: 'transform 0.15s ease-out',
            }}
          />
        </div>

        {/* Dynamic Visual Effects Layer */}
        <div style={{ transform: 'translateZ(10px)' }}>
          <OwnerCardEffectLayer
            effect={effect}
            accentColor={custom?.accentColor || 'amber'}
            glowIntensity={glowIntensity}
            borderStyle={borderStyle}
          />
        </div>

        {/* Custom Owner Card Background Photo Layer & Owner Edit Trigger */}
        <OwnerCardBackgroundLayer
          cardId="owner_edgar"
          ownerName={displayName}
          displayName={custom?.displayName}
          roleTitle={custom?.roleTitle}
          subtitle={custom?.subtitle}
          badge={custom?.badge}
          country={country}
          defaultAccent={custom?.accentColor || 'amber'}
          buttonPosition="top-right"
        />

        {/* Subtle Egyptian Cartouche & Geometric Architectural Accents (Lightens up on scroll / hover) */}
        <div 
          className="absolute top-0 inset-x-0 h-1.5 transition-all duration-300"
          style={{
            background: (scrollTilt.isIlluminated || isHovered)
              ? 'linear-gradient(90deg, transparent 0%, rgba(251,191,36,0.95) 50%, transparent 100%)'
              : 'linear-gradient(90deg, transparent 0%, rgba(251,191,36,0.7) 50%, transparent 100%)',
            boxShadow: (scrollTilt.isIlluminated || isHovered)
              ? '0 0 20px rgba(251,191,36,0.9)'
              : '0 0 12px rgba(251,191,36,0.6)',
          }}
        />
        
        {/* Top-Right & Top-Left Pharaonic Corner Stepped Motifs */}
        <div className="absolute top-4 start-6 flex items-center gap-1.5 opacity-40">
          <div className="w-1.5 h-1.5 bg-amber-400 rotate-45" />
          <div className="w-6 h-px bg-amber-400/60" />
          <div className="w-1 h-1 bg-amber-400/50 rounded-full" />
        </div>
        <div className="absolute top-4 end-6 flex items-center gap-1.5 opacity-40">
          <div className="w-1 h-1 bg-amber-400/50 rounded-full" />
          <div className="w-6 h-px bg-amber-400/60" />
          <div className="w-1.5 h-1.5 bg-amber-400 rotate-45" />
        </div>

        {/* Faint Winged Solar Disc / Sacred Crest Watermark in Background */}
        <div className="absolute end-6 bottom-4 md:end-12 md:bottom-6 opacity-[0.045] pointer-events-none select-none text-amber-300">
          <svg width="220" height="120" viewBox="0 0 220 120" fill="currentColor">
            <circle cx="110" cy="60" r="28" />
            <path d="M110,60 C70,30 20,45 0,70 C30,75 75,70 110,65 Z" />
            <path d="M110,60 C150,30 200,45 220,70 C190,75 145,70 110,65 Z" />
            <path d="M95,65 Q85,85 100,90 Q105,80 100,70 Z" />
            <path d="M125,65 Q135,85 120,90 Q115,80 120,70 Z" />
          </svg>
        </div>

        {/* Header Badges: Sovereign Crown, Country Flag, and Presence Status */}
        <div 
          className="flex flex-wrap items-center justify-between gap-4 mb-8"
          style={{ transform: 'translateZ(35px)' }}
        >
          <div className="flex flex-wrap items-center gap-3">
            {/* Grand Sovereign Seal */}
            <span className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full ${accent.badgeBg} border ${accent.badgeBorder} ${accent.badgeText} text-xs font-bold tracking-widest uppercase shadow-[0_0_18px_rgba(251,191,36,0.25)]`}>
              <Crown size={15} className="fill-current/30" />
              <span>{roleTitle}</span>
            </span>

            {/* Egyptian Flag Badge */}
            <CountryFlag
              country={country}
              name={t(`country.${country}`)}
              className="border-amber-400/40"
            />
          </div>

          {/* Currently Present Live Pulse */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-400/40 text-xs font-semibold shadow-[0_0_15px_rgba(16,185,129,0.25)]">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400" />
            </span>
            <span>{t('history.status.present')}</span>
          </div>
        </div>

        {/* Centerpiece Content: Name & Royal Epithet */}
        <div 
          className="mb-6"
          style={{ transform: 'translateZ(45px)' }}
        >
          <div className="flex flex-col sm:flex-row sm:items-baseline gap-2 sm:gap-4 mb-3">
            <h3 className={`font-display font-black text-4xl sm:text-6xl md:text-7xl tracking-wide text-transparent bg-clip-text bg-gradient-to-r ${accent.textGradient} drop-shadow-[0_2px_20px_rgba(251,191,36,0.4)]`}>
              {displayName}
            </h3>
            <span className="text-xs sm:text-sm font-mono uppercase tracking-[0.25em] text-amber-300/80 font-semibold flex items-center gap-1.5">
              <Sparkles size={13} className="text-amber-400" />
              {roleSubtitle}
            </span>
          </div>

          {/* Golden Egyptian Spear / Sun Ray Divider */}
          <div className="flex items-center gap-3 my-5">
            <div className="h-px flex-1 bg-gradient-to-r from-amber-400/70 via-amber-400/30 to-transparent" />
            <div className="flex items-center gap-1.5 text-amber-400/90">
              <Sun size={14} className="animate-spin-slow" />
              <div className="w-1.5 h-1.5 rotate-45 bg-amber-400" />
              <Sun size={14} className="animate-spin-slow" />
            </div>
            <div className="h-px flex-1 bg-gradient-to-l from-amber-400/70 via-amber-400/30 to-transparent" />
          </div>
        </div>

        {/* Narrative Description */}
        <p 
          className="font-sans text-archive-paper/90 font-light text-base sm:text-lg md:text-xl leading-relaxed max-w-3xl"
          style={{ transform: 'translateZ(30px)' }}
        >
          {narrativeDesc}
        </p>

        {/* View Profile Action Cue */}
        <div 
          className="mt-6 pt-4 border-t border-amber-400/20 flex items-center justify-between gap-3 text-xs font-mono"
          style={{ transform: 'translateZ(35px)' }}
        >
          <span className="text-amber-300/80 group-hover:text-amber-200 flex items-center gap-1.5 transition-colors font-medium">
            <span>{isRtl ? 'عرض ملف إيدجر السيادي الكامل' : 'Open Edgar Sovereign Profile'}</span>
            <ArrowUpRight size={13} className="text-amber-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </span>
          <span className="text-amber-400/50 uppercase tracking-widest text-[11px]">
            SOVEREIGN ERA
          </span>
        </div>

        {/* Foreground 3D Dynamic Glare Sheen */}
        <div
          className="absolute inset-0 rounded-[inherit] pointer-events-none transition-opacity duration-300"
          style={{
            transform: 'translateZ(55px)',
            opacity: isHovered ? (hoverGlare.opacity || 0.4) : scrollTilt.glareOpacity,
            background: `radial-gradient(circle 350px at ${isHovered ? hoverGlare.x : scrollTilt.glarePos.x}% ${isHovered ? hoverGlare.y : scrollTilt.glarePos.y}%, rgba(255, 255, 255, 0.16) 0%, rgba(251, 191, 36, 0.08) 40%, transparent 70%)`
          }}
        />
      </div>
    </motion.div>
  );
};
