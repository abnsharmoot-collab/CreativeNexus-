import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useLanguage } from '../../context/LanguageContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../../lib/firebase';

export interface BioData {
  bioAr: string;
  bioEn: string;
}

export const DEFAULT_BIO: BioData = {
  bioAr: 'الملاذ الرقمي للمبدعين والمبتكرين وصناع الأثر. عالم سيادي تُسطر فيه أساطير المجتمع بأحرف من نور وتترسخ فيه الروابط الأخوية للأبد.',
  bioEn: 'The sovereign digital sanctuary for creators, innovators, and visionaries. A living realm where legendary chronicles are etched in starlight and community bonds are forged forever.'
};

export const LOCAL_STORAGE_KEY = 'creatine_nexus_bio_cache';

export const CreativeNexusBio: React.FC = () => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  const [bio, setBio] = useState<BioData>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      return saved ? JSON.parse(saved) : DEFAULT_BIO;
    } catch {
      return DEFAULT_BIO;
    }
  });

  // Fetch from server on mount
  useEffect(() => {
    let isMounted = true;
    const fetchBio = async () => {
      try {
        const res = await fetch('/api/settings/creative-nexus-bio');
        if (res.ok) {
          const data = await res.json();
          if (data.bio && isMounted) {
            setBio(data.bio);
            try {
              localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data.bio));
            } catch {}
          }
        }
      } catch (err) {
        console.warn('Could not fetch bio from server:', err);
      }
    };

    fetchBio();

    // Realtime Firestore synchronization if available
    if (db) {
      try {
        const unsub = onSnapshot(doc(db, 'site_settings', 'creative_nexus_bio'), (snapshot) => {
          if (snapshot.exists()) {
            const data = snapshot.data() as Partial<BioData>;
            const merged = {
              bioAr: data.bioAr || DEFAULT_BIO.bioAr,
              bioEn: data.bioEn || DEFAULT_BIO.bioEn,
            };
            if (isMounted) {
              setBio(merged);
              try {
                localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(merged));
              } catch {}
            }
          }
        });
        return () => {
          isMounted = false;
          unsub();
        };
      } catch (e) {
        // Fallback to fetch
      }
    }

    return () => {
      isMounted = false;
    };
  }, []);

  const currentBioText = isAr ? bio.bioAr : bio.bioEn;

  return (
    <div className="relative w-full max-w-2xl mx-auto mt-2 mb-2 px-4">
      {/* The Bio Paragraph */}
      <motion.p
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.5 }}
        className={`text-sm sm:text-base md:text-lg leading-relaxed text-center font-cairo font-medium transition-colors ${
          isMesopotamian
            ? 'text-amber-200/90 drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]'
            : 'text-[#8db8b1] hover:text-[#b6fff0]'
        }`}
      >
        {currentBioText}
      </motion.p>
    </div>
  );
};
