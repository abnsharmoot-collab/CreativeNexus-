import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Lock, CheckCircle2, Sparkles, Calendar, Coins, Zap, Shield, Loader2, Check, ArrowRight } from 'lucide-react';
import { UserAchievementStatus, useAchievements } from '../../context/AchievementContext';
import { useAuth } from '../../context/AuthContext';
import { AchievementIcon } from './AchievementIcon';
import { isStaffOnlyAchievement } from '../../types/achievements';
import { playColorLock } from '../../utils/cardRevealAudio';

interface AchievementCardProps {
  achievement: UserAchievementStatus;
  index: number;
  isAr?: boolean;
  onRevealComplete?: (id: string) => void;
  onClaim?: (id: string) => Promise<any>;
}

export const AchievementCard: React.FC<AchievementCardProps> = ({
  achievement,
  index,
  isAr = false,
  onRevealComplete,
  onClaim
}) => {
  const { 
    definition, 
    isUnlocked, 
    unlockedAt, 
    isNew, 
    currentProgress, 
    maxProgress, 
    progressPercent,
    isClaimed,
    claimedAt,
    coinsAwarded,
    baseReward,
    multiplier,
    calculatedReward,
    canClaim 
  } = achievement;

  const { claimReward } = useAchievements();
  const { isAuthenticated, loginWithDiscord } = useAuth();
  const [isClaiming, setIsClaiming] = useState(false);
  const [justClaimedCoins, setJustClaimedCoins] = useState<number | null>(null);

  const isStaffOnly = isStaffOnlyAchievement(definition);

  const handleClaim = async () => {
    if (isClaiming || isClaimed || !isUnlocked) return;

    if (!isAuthenticated) {
      loginWithDiscord();
      return;
    }

    setIsClaiming(true);
    try {
      let result: any;
      if (onClaim) {
        result = await onClaim(definition.id);
      } else {
        result = await claimReward(definition.id);
      }

      if (result?.success) {
        playColorLock('LEGENDARY', 0.85);
        setJustClaimedCoins(result.coinsAwarded || calculatedReward || 10);
        setTimeout(() => setJustClaimedCoins(null), 3500);
      }
    } catch (err) {
      console.error('Error claiming achievement coins:', err);
    } finally {
      setIsClaiming(false);
    }
  };

  // Color theme styling
  const getThemeClasses = () => {
    switch (definition.theme) {
      case 'white':
        return {
          border: 'border-white/30',
          bg: 'bg-gradient-to-b from-[#0a1b22] via-[#041215] to-[#020b0d]',
          iconBg: 'bg-white/10 text-white border-white/30',
          accent: '#ffffff',
          accentText: 'text-white',
          glow: 'shadow-[0_12px_30px_rgba(255,255,255,0.06)]',
          badge: 'text-white border-white/30 bg-white/10',
          progress: 'bg-white'
        };
      case 'purple':
        return {
          border: 'border-purple-500/35',
          bg: 'bg-gradient-to-b from-[#160d29] via-[#090615] to-[#04020a]',
          iconBg: 'bg-purple-500/15 text-purple-300 border-purple-500/40',
          accent: '#c084fc',
          accentText: 'text-purple-300',
          glow: 'shadow-[0_12px_30px_rgba(168,85,247,0.12)]',
          badge: 'text-purple-300 border-purple-500/40 bg-purple-500/10',
          progress: 'bg-purple-400'
        };
      case 'yellow':
        return {
          border: 'border-amber-400/40',
          bg: 'bg-gradient-to-b from-[#221606] via-[#100b03] to-[#060401]',
          iconBg: 'bg-amber-500/15 text-amber-300 border-amber-500/40',
          accent: '#f59e0b',
          accentText: 'text-amber-300',
          glow: 'shadow-[0_12px_30px_rgba(245,158,11,0.15)]',
          badge: 'text-amber-300 border-amber-500/40 bg-amber-500/10',
          progress: 'bg-amber-400'
        };
      case 'emerald':
        return {
          border: 'border-emerald-500/35',
          bg: 'bg-gradient-to-b from-[#082017] via-[#03110c] to-[#010906]',
          iconBg: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40',
          accent: '#34d399',
          accentText: 'text-emerald-300',
          glow: 'shadow-[0_12px_30px_rgba(16,185,129,0.12)]',
          badge: 'text-emerald-300 border-emerald-500/40 bg-emerald-500/10',
          progress: 'bg-emerald-400'
        };
      case 'indigo':
        return {
          border: 'border-indigo-500/35',
          bg: 'bg-gradient-to-b from-[#111630] via-[#070b1a] to-[#02040d]',
          iconBg: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/40',
          accent: '#818cf8',
          accentText: 'text-indigo-300',
          glow: 'shadow-[0_12px_30px_rgba(99,102,241,0.12)]',
          badge: 'text-indigo-300 border-indigo-500/40 bg-indigo-500/10',
          progress: 'bg-indigo-400'
        };
      case 'amber':
        return {
          border: 'border-amber-500/35',
          bg: 'bg-gradient-to-b from-[#221305] via-[#110902] to-[#060301]',
          iconBg: 'bg-amber-500/15 text-amber-300 border-amber-500/40',
          accent: '#fbbf24',
          accentText: 'text-amber-300',
          glow: 'shadow-[0_12px_30px_rgba(245,158,11,0.14)]',
          badge: 'text-amber-300 border-amber-500/40 bg-amber-500/10',
          progress: 'bg-amber-400'
        };
      default:
        return {
          border: 'border-cyan-500/35',
          bg: 'bg-gradient-to-b from-[#062022] via-[#021316] to-[#010a0c]',
          iconBg: 'bg-cyan-500/15 text-[#5eead4] border-cyan-500/40',
          accent: '#5eead4',
          accentText: 'text-[#5eead4]',
          glow: 'shadow-[0_12px_30px_rgba(6,182,212,0.12)]',
          badge: 'text-[#5eead4] border-cyan-500/40 bg-cyan-500/10',
          progress: 'bg-cyan-400'
        };
    }
  };

  const theme = getThemeClasses();

  // Format unlocked date if available
  const formattedDate = unlockedAt
    ? new Date(unlockedAt).toLocaleDateString(isAr ? 'ar-EG' : 'en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
    : null;

  return (
    <div
      id={`achievement-slot-${definition.id}`}
      className="relative rounded-2xl p-1.5 bg-[#01080a] border border-[#5eead4]/15 shadow-[inset_0_10px_28px_rgba(0,0,0,0.95),0_12px_24px_rgba(0,0,0,0.6)] overflow-hidden group"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* ========================================================================= */}
      {/* 1. ARCHITECTURAL SOCKET HOLE RECEPTACLE                                    */}
      {/* (Permanent recessed cavity behind the achievement plaque)                 */}
      {/* ========================================================================= */}
      <div className="absolute inset-1.5 rounded-xl bg-gradient-to-b from-[#010608] via-[#020b0e] to-[#010507] border border-dashed border-teal-900/40 shadow-[inset_0_8px_20px_rgba(0,0,0,0.95)] flex flex-col justify-between p-3 pointer-events-none z-0 overflow-hidden">
        {/* Alignment corner brackets */}
        <div className="flex items-center justify-between w-full opacity-40">
          <span className="w-2.5 h-2.5 border-t border-l border-teal-500/40" />
          <span className="text-[9px] font-mono tracking-widest text-teal-800/80 uppercase">
            SOCKET // #{definition.number.toString().padStart(2, '0')}
          </span>
          <span className="w-2.5 h-2.5 border-t border-r border-teal-500/40" />
        </div>

        {/* Center alignment ring */}
        <div className="w-12 h-12 mx-auto rounded-full border border-teal-950 bg-black/60 flex items-center justify-center opacity-30">
          <div className="w-5 h-5 rounded-full border border-dashed border-teal-800/60" />
        </div>

        <div className="flex items-center justify-between w-full opacity-40">
          <span className="w-2.5 h-2.5 border-b border-l border-teal-500/40" />
          <span className="text-[8px] font-mono text-teal-900 uppercase">
            SANCTUARY ARCHIVE
          </span>
          <span className="w-2.5 h-2.5 border-b border-r border-teal-500/40" />
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. THE ACHIEVEMENT TABLET                                                 */}
      {/* ANIMATION: Placed smoothly into the socket hole on first scroll through    */}
      {/* Zero violent shaking, zero blinding flares, pure tactile docking           */}
      {/* ========================================================================= */}
      <motion.div
        initial={{ opacity: 0, y: -36, scale: 0.94 }}
        whileInView={{ opacity: 1, y: 0, scale: 1 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{
          type: 'spring',
          stiffness: 240,
          damping: 24,
          mass: 0.9,
          delay: Math.min((index % 4) * 0.07, 0.28)
        }}
        onViewportEnter={() => {
          if (isNew && onRevealComplete) {
            onRevealComplete(definition.id);
          }
        }}
        className={`relative z-10 rounded-xl p-4 sm:p-5 flex flex-col justify-between min-h-[220px] transition-colors duration-200 border ${
          isUnlocked
            ? `${theme.bg} ${theme.border} ${theme.glow}`
            : 'bg-[#031013]/90 border-white/10 text-slate-400'
        }`}
      >
        {/* Floating Celebration Feedback when Coins are Claimed */}
        {justClaimedCoins && (
          <motion.div
            initial={{ opacity: 0, y: 15, scale: 0.8 }}
            animate={{ opacity: 1, y: -10, scale: 1.05 }}
            exit={{ opacity: 0, y: -25 }}
            className="absolute top-2 inset-x-4 z-30 py-1.5 px-3 rounded-xl bg-gradient-to-r from-amber-400 to-[#5eead4] text-black font-bold text-xs flex items-center justify-center gap-1.5 shadow-xl shadow-amber-500/40"
          >
            <Coins size={14} className="text-black" />
            <span>{isAr ? `+${justClaimedCoins} عملة مضافة لرصيدك!` : `+${justClaimedCoins} Coins added to balance!`}</span>
          </motion.div>
        )}

        {/* Top Header: Badge, Icon & Number */}
        <div>
          <div className="flex items-start justify-between gap-2.5 mb-2.5">
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className={`w-11 h-11 rounded-xl flex items-center justify-center border shrink-0 transition-transform ${
                  isUnlocked
                    ? `${theme.iconBg} shadow-sm group-hover:scale-105`
                    : 'bg-black/60 text-slate-500 border-white/10'
                }`}
              >
                {isUnlocked ? (
                  <AchievementIcon name={definition.iconName} size={22} />
                ) : (
                  <Lock size={18} className="text-slate-500" />
                )}
              </div>

              <div className="min-w-0 flex-1">
                {/* Clean unboxed metadata separator */}
                <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400">
                  <span className="font-bold text-[#5eead4]">#{definition.number}</span>
                  <span aria-hidden="true" className="opacity-40">·</span>
                  <span className="truncate">{definition.category}</span>
                  {isStaffOnly && (
                    <>
                      <span aria-hidden="true" className="opacity-40">·</span>
                      <span className="text-indigo-400 font-bold">{isAr ? 'إداري' : 'Staff'}</span>
                    </>
                  )}
                </div>

                <h4
                  className={`text-sm sm:text-base font-bold font-sans tracking-tight leading-snug line-clamp-1 mt-0.5 ${
                    isUnlocked ? 'text-white' : 'text-slate-300'
                  }`}
                >
                  {isAr ? definition.nameAr : definition.name}
                </h4>
              </div>
            </div>

            {/* Unlocked / Locked status indicator */}
            {isUnlocked ? (
              <span
                className={`shrink-0 text-[10px] font-mono font-bold px-2 py-0.5 rounded-md border flex items-center gap-1 ${theme.badge}`}
              >
                <CheckCircle2 size={11} />
                <span>{isAr ? 'مكتمل' : 'UNLOCKED'}</span>
              </span>
            ) : (
              <span className="shrink-0 text-[10px] font-mono font-medium px-2 py-0.5 rounded-md bg-black/40 text-slate-500 border border-white/5 flex items-center gap-1">
                <Lock size={10} />
                <span>{isAr ? 'مغلق' : 'LOCKED'}</span>
              </span>
            )}
          </div>

          {/* Description */}
          <p
            className={`text-xs leading-relaxed line-clamp-2 ${
              isUnlocked ? 'text-slate-300' : 'text-slate-500'
            }`}
          >
            {isAr ? definition.descriptionAr : definition.description}
          </p>
        </div>

        {/* Bottom Area: Progress bar, Reward & Claim Action */}
        <div className="pt-3 border-t border-white/10 mt-3 space-y-2.5">
          {/* Reward & Multiplier Bar */}
          <div className="flex items-center justify-between gap-1.5 flex-wrap">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-mono font-bold text-amber-300 flex items-center gap-1">
                <Coins size={12} className="text-amber-400" />
                <span>+{calculatedReward || baseReward || 10} 🪙</span>
              </span>

              {multiplier > 1.0 && (
                <span className="text-[10px] font-mono font-bold text-amber-300 bg-amber-500/15 border border-amber-500/30 px-1.5 py-0.2 rounded flex items-center gap-0.5">
                  <Zap size={9} />
                  <span>{multiplier.toFixed(1)}x</span>
                </span>
              )}
            </div>

            {isUnlocked && formattedDate && (
              <div className="flex items-center gap-1 text-slate-400 text-[10px] font-mono">
                <Calendar size={10} />
                <span>{formattedDate}</span>
              </div>
            )}
          </div>

          {/* Unlocked State vs Progress */}
          {isUnlocked ? (
            <div className="space-y-1.5">
              {/* Claim Action Button */}
              {isClaimed ? (
                <div className="w-full py-2 px-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-center gap-1.5 text-emerald-300 text-xs font-mono font-bold">
                  <Check size={13} className="text-emerald-400" />
                  <span>{isAr ? `تم استلام العملات (+${coinsAwarded || calculatedReward} عملة)` : `Claimed (+${coinsAwarded || calculatedReward} coins)`}</span>
                </div>
              ) : (
                <button
                  type="button"
                  disabled={isClaiming}
                  onClick={handleClaim}
                  className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-400 via-amber-300 to-[#5eead4] hover:brightness-110 active:scale-[0.98] text-[#031211] font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 transition-all cursor-pointer disabled:opacity-50"
                >
                  {isClaiming ? (
                    <Loader2 size={13} className="animate-spin text-black" />
                  ) : (
                    <Coins size={13} className="text-black" />
                  )}
                  <span>
                    {isClaiming
                      ? (isAr ? 'جاري الاستلام...' : 'Claiming...')
                      : !isAuthenticated
                      ? (isAr ? `سجل الدخول لاستلام (+${calculatedReward} عملة)` : `Log in to Claim (+${calculatedReward} coins)`)
                      : (isAr ? `استلم المكافأة (+${calculatedReward} عملة)` : `Claim Reward (+${calculatedReward} coins)`)}
                  </span>
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                <span>{isAr ? 'التقدم نحو الهدف' : 'Progress'}</span>
                <span className="font-semibold text-slate-300">
                  {currentProgress} / {maxProgress} {isAr ? definition.unitAr : definition.unit}
                </span>
              </div>
              <div className="w-full h-1.5 bg-black/60 rounded-full overflow-hidden border border-white/5">
                <div
                  className="h-full bg-slate-600 rounded-full transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
