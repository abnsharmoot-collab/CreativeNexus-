import React from 'react';
import {
  Footprints,
  Coins,
  TrendingUp,
  Sparkles,
  Shield,
  Crown,
  CheckCheck,
  Medal,
  ShieldCheck,
  Trophy,
  Award,
  Flame,
  Star,
  Zap,
  Target,
  Gem,
  Activity,
  CheckCircle2,
  ShieldAlert,
  FileText,
  CheckCircle,
  Hourglass,
  Mountain,
  Compass,
  ArrowUpRight,
  DoorOpen,
  MountainSnow,
  Lock,
  LucideProps
} from 'lucide-react';

const ICON_MAP: Record<string, React.ComponentType<LucideProps>> = {
  Footprints,
  Coins,
  TrendingUp,
  Sparkles,
  Shield,
  Crown,
  CheckCheck,
  Medal,
  ShieldCheck,
  Trophy,
  Award,
  Flame,
  Star,
  Zap,
  Target,
  Gem,
  Activity,
  CheckCircle2,
  ShieldAlert,
  FileText,
  CheckCircle,
  Hourglass,
  Mountain,
  Compass,
  ArrowUpRight,
  DoorOpen,
  MountainSnow
};

interface AchievementIconProps extends LucideProps {
  name: string;
}

export const AchievementIcon: React.FC<AchievementIconProps> = ({ name, ...props }) => {
  const IconComponent = ICON_MAP[name] || Trophy;
  return <IconComponent {...props} />;
};
