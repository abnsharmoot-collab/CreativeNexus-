import React from 'react';
import { PlayerDeck, DECK_BANNER_PRESETS } from '../../types/decks';
import { CollectibleCardData } from '../../types/cards';
import { useLanguage } from '../../context/LanguageContext';
import { Swords, Shield, Zap, Sparkles, Crown, Trash2, Edit3, CheckCircle } from 'lucide-react';

interface DeckCardProps {
  deck: PlayerDeck;
  cards: CollectibleCardData[];
  onEdit: (deck: PlayerDeck) => void;
  onSetActive: (deckId: string) => void;
  onDelete: (deckId: string) => void;
}

export const DeckCard: React.FC<DeckCardProps> = ({
  deck,
  cards,
  onEdit,
  onSetActive,
  onDelete
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const bannerPreset = DECK_BANNER_PRESETS.find(b => b.id === deck.banner) || DECK_BANNER_PRESETS[0];

  const formattedDate = new Date(deck.updatedAt || deck.createdAt).toLocaleDateString(
    isAr ? 'ar-EG' : 'en-US',
    { month: 'short', day: 'numeric', year: 'numeric' }
  );

  return (
    <div
      className={`relative rounded-3xl border transition-all duration-300 overflow-hidden flex flex-col justify-between ${
        deck.isActive
          ? 'bg-gradient-to-b from-[#062024]/95 via-[#031518]/95 to-[#010a0c]/98 border-[#5eead4]/50 shadow-[0_12px_40px_rgba(94,234,212,0.18)] ring-1 ring-[#5eead4]/30'
          : 'bg-gradient-to-b from-[#041619]/85 via-[#020e10]/90 to-[#010809]/95 hover:bg-[#072429]/90 border-[#5eead4]/15 hover:border-[#5eead4]/40 shadow-xl'
      }`}
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* Banner / Header Bar */}
      <div className={`relative px-4 py-3.5 bg-gradient-to-r ${bannerPreset.gradient} border-b border-white/10 flex items-center justify-between`}>
        <div className="flex items-center gap-2.5 min-w-0">
          {deck.isActive && (
            <span className="p-1.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-xs shrink-0">
              <Crown size={13} />
            </span>
          )}
          <h3 className="font-bold text-white text-base truncate font-sans tracking-tight">
            {deck.name}
          </h3>
        </div>

        {/* Card Count Indicator: Clearly shows 4 / 4 */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span
            className={`px-3 py-0.5 rounded-full text-xs font-mono font-bold border ${
              deck.cardIds.length === 4
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-xs'
                : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
            }`}
          >
            {deck.cardIds.length} / 4 {isAr ? 'بطاقات' : 'Cards'}
          </span>
        </div>
      </div>

      {/* Main Content Body */}
      <div className="p-4 space-y-4">
        {/* 4 Card Visual Preview Slots (Strict Max 4 Formation) */}
        <div className="grid grid-cols-4 gap-2">
          {[0, 1, 2, 3].map(slotIdx => {
            const card = cards[slotIdx];
            const roleLabels = ['VANGUARD', 'STRIKER', 'BULWARK', 'TACTICIAN'];
            const roleLabelsAr = ['طليعة', 'مهاجم', 'حصن', 'تكتيكي'];
            const roleColor = ['text-[#5eead4]', 'text-rose-400', 'text-cyan-400', 'text-amber-400'][slotIdx];

            return (
              <div
                key={slotIdx}
                className={`relative aspect-[3/4] rounded-2xl border overflow-hidden flex flex-col items-center justify-between transition-all duration-300 group ${
                  card
                    ? 'border-[#5eead4]/25 bg-black/60 shadow-inner hover:border-[#5eead4]/60 hover:scale-[1.03]'
                    : 'border-dashed border-teal-900/40 bg-black/30'
                }`}
              >
                {card ? (
                  <>
                    <img
                      src={card.imageUrl}
                      alt={card.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      loading="lazy"
                    />
                    <div className="absolute top-1 start-1 px-1.5 py-0.5 rounded-full bg-black/80 text-[8px] font-mono font-bold border border-white/10 uppercase tracking-tighter shadow-xs">
                      <span className={roleColor}>{isAr ? roleLabelsAr[slotIdx] : roleLabels[slotIdx]}</span>
                    </div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent flex flex-col justify-end p-1.5">
                      <span className="text-[9.5px] font-mono font-bold text-white truncate text-center leading-tight">
                        {card.name.split(' ')[0]}
                      </span>
                    </div>
                  </>
                ) : (
                  <div className="my-auto text-center space-y-0.5">
                    <span className={`text-[8.5px] font-mono font-bold uppercase ${roleColor}`}>
                      {isAr ? roleLabelsAr[slotIdx] : roleLabels[slotIdx]}
                    </span>
                    <span className="text-[9px] font-mono text-teal-800 block">
                      #{slotIdx + 1}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Calculated Stats Matrix */}
        <div className="grid grid-cols-4 gap-2 pt-2 border-t border-teal-950/60 text-center font-mono">
          <div className="p-2.5 rounded-2xl bg-black/40 border border-white/5">
            <div className="flex items-center justify-center gap-1 text-[10px] text-rose-400 mb-0.5">
              <Swords size={11} />
              <span>{isAr ? 'القوة' : 'PWR'}</span>
            </div>
            <span className="text-sm font-bold text-white">{deck.power}</span>
          </div>

          <div className="p-2.5 rounded-2xl bg-black/40 border border-white/5">
            <div className="flex items-center justify-center gap-1 text-[10px] text-cyan-400 mb-0.5">
              <Shield size={11} />
              <span>{isAr ? 'الدفاع' : 'DEF'}</span>
            </div>
            <span className="text-sm font-bold text-white">{deck.defense}</span>
          </div>

          <div className="p-2.5 rounded-2xl bg-black/40 border border-white/5">
            <div className="flex items-center justify-center gap-1 text-[10px] text-amber-400 mb-0.5">
              <Zap size={11} />
              <span>{isAr ? 'السرعة' : 'SPD'}</span>
            </div>
            <span className="text-sm font-bold text-white">{deck.speed}</span>
          </div>

          <div className="p-2.5 rounded-2xl bg-black/40 border border-white/5">
            <div className="flex items-center justify-center gap-1 text-[10px] text-purple-400 mb-0.5">
              <Sparkles size={11} />
              <span>{isAr ? 'تناغم' : 'SYN'}</span>
            </div>
            <span className="text-sm font-bold text-purple-300">{deck.synergy}%</span>
          </div>
        </div>
      </div>

      {/* Footer Actions */}
      <div className="px-4 py-3 bg-[#020b0d]/80 border-t border-white/5 flex items-center justify-between gap-2">
        <span className="text-[10px] font-mono text-teal-300/60">
          {formattedDate}
        </span>

        <div className="flex items-center gap-2">
          {!deck.isActive ? (
            <button
              type="button"
              onClick={() => onSetActive(deck.id)}
              className="px-3 py-1 rounded-full bg-[#5eead4]/15 hover:bg-[#5eead4]/25 text-[#5eead4] hover:text-white border border-[#5eead4]/35 text-xs font-mono font-semibold transition-all cursor-pointer shadow-xs active:scale-95"
            >
              {isAr ? 'تفعيل' : 'Set Active'}
            </button>
          ) : (
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[11px] font-mono font-bold flex items-center gap-1 shadow-xs">
              <CheckCircle size={12} />
              <span>{isAr ? 'المفعلة' : 'Active'}</span>
            </span>
          )}

          <button
            type="button"
            onClick={() => onEdit(deck)}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-all flex items-center justify-center cursor-pointer active:scale-95"
            title={isAr ? 'تعديل التشكيلة' : 'Edit Deck'}
          >
            <Edit3 size={13} />
          </button>

          <button
            type="button"
            onClick={() => onDelete(deck.id)}
            className="w-8 h-8 rounded-full bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 hover:text-rose-200 border border-rose-500/20 transition-all flex items-center justify-center cursor-pointer active:scale-95"
            title={isAr ? 'حذف التشكيلة' : 'Delete Deck'}
          >
            <Trash2 size={13} />
          </button>
        </div>
      </div>
    </div>
  );
};
