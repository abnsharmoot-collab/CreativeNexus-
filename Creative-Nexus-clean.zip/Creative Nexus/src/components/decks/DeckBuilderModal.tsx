import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PlayerDeck, MAX_DECK_CARDS, MIN_DECK_CARDS, DECK_BANNER_PRESETS, calculateDeckStats } from '../../types/decks';
import { CollectibleCardData } from '../../types/cards';
import { useLanguage } from '../../context/LanguageContext';
import { useCards } from '../../context/CardContext';
import { useItems } from '../../context/ItemContext';
import { 
  X, Swords, Shield, Zap, Sparkles, Check, AlertCircle, 
  Trash2, Plus, Search, Crown, Layers, Save, Loader2, RefreshCw, Flame, Activity, Backpack, Heart
} from 'lucide-react';

interface DeckBuilderModalProps {
  isOpen: boolean;
  deckToEdit: PlayerDeck | null;
  onClose: () => void;
  onSave: (deckData: {
    id?: string;
    name: string;
    banner?: string;
    cardIds: string[];
    itemIds?: string[];
    isActive?: boolean;
  }) => Promise<{ success: boolean; error?: string }>;
}

const RARITY_JEWEL_COLORS: Record<string, { bg: string; shadow: string; label: string }> = {
  ALL: { bg: 'bg-[#5eead4]', shadow: '#5eead4', label: 'All' },
  COMMON: { bg: 'bg-slate-400', shadow: '#94a3b8', label: 'Common' },
  UNCOMMON: { bg: 'bg-emerald-400', shadow: '#34d399', label: 'Uncommon' },
  RARE: { bg: 'bg-cyan-400', shadow: '#22d3ee', label: 'Rare' },
  EPIC: { bg: 'bg-purple-400', shadow: '#c084fc', label: 'Epic' },
  LEGENDARY: { bg: 'bg-amber-400', shadow: '#fbbf24', label: 'Legendary' },
};

export const DeckBuilderModal: React.FC<DeckBuilderModalProps> = ({
  isOpen,
  deckToEdit,
  onClose,
  onSave
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { catalog, profile } = useCards();
  const { items: allItems, inventory, inventoryMap } = useItems();

  // Local form states
  const [deckName, setDeckName] = useState(deckToEdit ? deckToEdit.name : 'Vanguard Formation');
  const [selectedBanner, setSelectedBanner] = useState(deckToEdit?.banner || 'astral_void');
  const [selectedCardIds, setSelectedCardIds] = useState<string[]>(deckToEdit?.cardIds || []);
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>(deckToEdit?.itemIds || []);
  const [isDeckActive, setIsDeckActive] = useState(deckToEdit ? deckToEdit.isActive : true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRarityFilter, setSelectedRarityFilter] = useState<string>('ALL');
  const [replacingSlotIndex, setReplacingSlotIndex] = useState<number | null>(null);
  const [replacingItemSlot, setReplacingItemSlot] = useState<number | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sync state when modal opens or deckToEdit changes
  React.useEffect(() => {
    if (deckToEdit) {
      setDeckName(deckToEdit.name);
      setSelectedBanner(deckToEdit.banner || 'astral_void');
      setSelectedCardIds(deckToEdit.cardIds || []);
      setSelectedItemIds(deckToEdit.itemIds || []);
      setIsDeckActive(deckToEdit.isActive);
    } else {
      setDeckName('Vanguard Formation');
      setSelectedBanner('astral_void');
      setSelectedCardIds([]);
      setSelectedItemIds([]);
      setIsDeckActive(true);
    }
    setReplacingSlotIndex(null);
    setReplacingItemSlot(null);
    setErrorMessage(null);
  }, [deckToEdit, isOpen]);

  // Owned cards only
  const ownedCardsList = useMemo(() => {
    if (!profile?.cards) return [];
    return Object.keys(profile.cards)
      .map(cardId => {
        const ownership = profile.cards[cardId];
        const cardDef = catalog.find(c => c.id === cardId);
        if (!cardDef || !ownership || ownership.count <= 0) return null;
        return { card: cardDef, count: ownership.count };
      })
      .filter((item): item is { card: CollectibleCardData; count: number } => Boolean(item));
  }, [catalog, profile]);

  // Filtered owned cards for browser
  const filteredOwnedCards = useMemo(() => {
    return ownedCardsList.filter(({ card }) => {
      const matchesSearch = !searchQuery || 
        card.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (card.title && card.title.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesRarity = selectedRarityFilter === 'ALL' || card.rarity === selectedRarityFilter;
      return matchesSearch && matchesRarity;
    });
  }, [ownedCardsList, searchQuery, selectedRarityFilter]);

  // Selected card definitions
  const selectedCards = useMemo(() => {
    return selectedCardIds
      .map(id => catalog.find(c => c.id === id))
      .filter((c): c is CollectibleCardData => Boolean(c));
  }, [catalog, selectedCardIds]);

  // Live calculated stats
  const calculatedStats = useMemo(() => {
    return calculateDeckStats(selectedCards);
  }, [selectedCards]);

  // Add or Replace card
  const handleCardClick = (cardId: string) => {
    setErrorMessage(null);

    // If a slot is currently in Replacement Mode
    if (replacingSlotIndex !== null) {
      // Check if this card is already in another slot
      const existingAtOtherSlot = selectedCardIds.some(
        (id, idx) => id === cardId && idx !== replacingSlotIndex
      );
      if (existingAtOtherSlot) {
        setErrorMessage(
          isAr
            ? 'البطاقة موجودة بالفعل في خانة أخرى. لا يمكن تكرار البطاقة.'
            : 'Card is already in another slot. Duplicate cards are not allowed.'
        );
        return;
      }

      const updated = [...selectedCardIds];
      updated[replacingSlotIndex] = cardId;
      setSelectedCardIds(updated);
      setReplacingSlotIndex(null);
      return;
    }

    // Normal Add Mode
    if (selectedCardIds.includes(cardId)) {
      setErrorMessage(
        isAr
          ? 'البطاقة موجودة بالفعل في التشكيلة. لا يمكن التكرار.'
          : 'Card is already in the deck.'
      );
      return;
    }

    if (selectedCardIds.length >= MAX_DECK_CARDS) {
      setErrorMessage(
        isAr
          ? 'التشكيلة مكتملة (4/4). انقر على "استبدال" في الخانة التي ترغب في تغييرها.'
          : 'Deck is full (4/4). Click "Swap" on any card slot to replace it.'
      );
      return;
    }

    setSelectedCardIds(prev => [...prev, cardId]);
  };

  // Remove card from deck
  const handleRemoveCard = (cardId: string, slotIdx: number) => {
    setErrorMessage(null);
    if (replacingSlotIndex === slotIdx) {
      setReplacingSlotIndex(null);
    }
    setSelectedCardIds(prev => prev.filter((_, idx) => idx !== slotIdx));
  };

  // Toggle Replace mode on a slot
  const handleToggleReplaceSlot = (slotIdx: number) => {
    setErrorMessage(null);
    if (replacingSlotIndex === slotIdx) {
      setReplacingSlotIndex(null);
    } else {
      setReplacingSlotIndex(slotIdx);
    }
  };

  // Consumable slots handlers
  const handleToggleReplaceItemSlot = (slotIdx: number) => {
    setErrorMessage(null);
    setReplacingItemSlot(prev => (prev === slotIdx ? null : slotIdx));
  };

  const handleSelectItemForSlot = (itemId: string) => {
    setSelectedItemIds(prev => {
      const copy = [...prev];
      if (replacingItemSlot !== null && replacingItemSlot >= 0 && replacingItemSlot < 4) {
        copy[replacingItemSlot] = itemId;
      } else {
        const nextEmpty = [0, 1, 2, 3].find(idx => !copy[idx]);
        if (nextEmpty !== undefined) {
          copy[nextEmpty] = itemId;
        } else {
          copy[0] = itemId;
        }
      }
      return copy.filter(Boolean).slice(0, 4);
    });
    setReplacingItemSlot(null);
  };

  const handleRemoveItemSlot = (slotIdx: number) => {
    setSelectedItemIds(prev => {
      const copy = [...prev];
      copy.splice(slotIdx, 1);
      return copy;
    });
    if (replacingItemSlot === slotIdx) setReplacingItemSlot(null);
  };

  // Save handler
  const handleSaveDeck = async () => {
    setErrorMessage(null);
    if (selectedCardIds.length < MIN_DECK_CARDS) {
      setErrorMessage(
        isAr
          ? 'يجب أن تحتوي التشكيلة على بطاقة واحدة على الأقل.'
          : 'A deck must contain at least 1 card.'
      );
      return;
    }
    if (selectedCardIds.length > MAX_DECK_CARDS) {
      setErrorMessage(
        isAr
          ? 'لا يمكن حفظ تشكيلة بأكثر من 4 بطاقات.'
          : 'Cannot save deck with more than 4 cards.'
      );
      return;
    }

    setIsSaving(true);
    try {
      const res = await onSave({
        id: deckToEdit?.id,
        name: deckName.trim() || 'Vanguard Formation',
        banner: selectedBanner,
        cardIds: selectedCardIds,
        itemIds: selectedItemIds.slice(0, 4),
        isActive: isDeckActive
      });

      if (!res.success) {
        setErrorMessage(res.error || 'Failed to save deck');
      } else {
        onClose();
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Error saving deck');
    } finally {
      setIsSaving(false);
    }
  };

  if (!isOpen) return null;

  const currentBanner = DECK_BANNER_PRESETS.find(b => b.id === selectedBanner) || DECK_BANNER_PRESETS[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 md:p-6 bg-black/85 backdrop-blur-2xl overflow-y-auto studio-scrollbar">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.22, ease: 'easeOut' }}
        className="relative w-full max-w-5xl bg-gradient-to-b from-[#03171b]/98 via-[#021013]/98 to-[#01080a]/98 border border-[#5eead4]/35 rounded-[32px] shadow-[0_30px_90px_rgba(0,0,0,0.95)] overflow-hidden flex flex-col max-h-[94vh] my-auto"
        dir={isAr ? 'rtl' : 'ltr'}
      >
        {/* Top Hairline Metallic Bevel Glow */}
        <div
          className="absolute top-0 inset-x-0 h-[2px] pointer-events-none z-30"
          style={{
            background: 'linear-gradient(90deg, transparent 0%, #5eead4 50%, transparent 100%)',
            boxShadow: '0 0 16px #5eead4'
          }}
        />

        {/* Tactical Header Bar */}
        <div className={`relative px-5 sm:px-8 py-4.5 bg-gradient-to-r ${currentBanner.gradient} border-b border-white/10 flex items-center justify-between shrink-0 overflow-hidden`}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-md pointer-events-none" />
          
          <div className="relative z-10 flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-black/60 border border-[#5eead4]/40 flex items-center justify-center text-[#5eead4] shadow-[0_0_15px_rgba(94,234,212,0.3)] shrink-0">
              <Swords size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono tracking-widest text-[#5eead4] uppercase font-bold">
                  TACTICAL WAR ROOM // غرفة التشكيل
                </span>
                <span className={`text-[9px] font-mono px-2 py-0.5 rounded-full font-bold uppercase ${
                  selectedCardIds.length === 4
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                }`}>
                  {selectedCardIds.length === 4 ? (isAr ? 'كتيبة مكتملة' : 'Full Formation') : `${selectedCardIds.length}/4 Active`}
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-black text-white font-sans tracking-wide mt-0.5">
                {deckToEdit
                  ? (isAr ? 'ترقية وتعديل التشكيلة التكتيكية' : 'Upgraded Tactical Formation Editor')
                  : (isAr ? 'إنشاء تشكيلة قتالية استراتيجية جديدة' : 'Forge New Battle Formation')}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="relative z-10 w-9 h-9 rounded-xl bg-black/50 hover:bg-black/80 text-stone-300 hover:text-white border border-white/10 transition-all flex items-center justify-center cursor-pointer shadow-md active:scale-95"
          >
            <X size={17} />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-7 space-y-6 studio-scrollbar">
          {/* Error Banner */}
          {errorMessage && (
            <div className="p-3.5 rounded-2xl bg-rose-950/70 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2.5 shadow-lg">
              <AlertCircle size={16} className="text-rose-400 shrink-0" />
              <span className="font-sans">{errorMessage}</span>
            </div>
          )}

          {/* Replacement Mode Alert */}
          {replacingSlotIndex !== null && (
            <div className="p-3.5 rounded-2xl bg-amber-950/70 border border-amber-500/40 text-amber-200 text-xs flex items-center justify-between gap-3 shadow-lg animate-pulse">
              <div className="flex items-center gap-2.5 min-w-0">
                <RefreshCw size={15} className="text-amber-400 animate-spin shrink-0" />
                <span className="truncate">
                  {isAr
                    ? `وضع الاستبدال نشط للخانة #${replacingSlotIndex + 1}: اختر بطاقة من المستودع بالأسفل.`
                    : `Swap Mode Active for Slot #${replacingSlotIndex + 1}: Select any card below to swap.`}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setReplacingSlotIndex(null)}
                className="px-3 py-1 rounded-xl bg-black/60 text-amber-300 hover:text-white border border-amber-500/40 text-xs font-mono font-bold cursor-pointer shrink-0 transition-colors"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
            </div>
          )}

          {/* Tactical Config Suite: Deck Name, Banner Theme & Active Toggle */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 p-4 rounded-3xl bg-black/40 border border-[#5eead4]/20 backdrop-blur-xl">
            {/* Formation Name */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-mono uppercase tracking-wider text-[#5eead4] font-bold block">
                {isAr ? 'اسم التشكيلة القتالية' : 'Formation Codename'}
              </label>
              <input
                type="text"
                value={deckName}
                maxLength={40}
                onChange={e => setDeckName(e.target.value)}
                placeholder="Vanguard Formation"
                className="w-full px-3.5 py-2.5 rounded-2xl bg-black/60 border border-white/10 text-white text-xs sm:text-sm font-semibold focus:outline-none focus:border-[#5eead4] focus:ring-1 focus:ring-[#5eead4]/50 transition-all"
              />
            </div>

            {/* Banner Theme */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-mono uppercase tracking-wider text-[#5eead4] font-bold block">
                {isAr ? 'الشعار والهوية البصرية' : 'Banner Insignia'}
              </label>
              <select
                value={selectedBanner}
                onChange={e => setSelectedBanner(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-2xl bg-black/60 border border-white/10 text-white text-xs sm:text-sm font-semibold focus:outline-none focus:border-[#5eead4] focus:ring-1 focus:ring-[#5eead4]/50 transition-all cursor-pointer"
              >
                {DECK_BANNER_PRESETS.map(b => (
                  <option key={b.id} value={b.id} className="bg-slate-900 text-white">
                    {b.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Active Deck Toggle Switch */}
            <div className="flex flex-col justify-end">
              <button
                type="button"
                onClick={() => setIsDeckActive(!isDeckActive)}
                className={`w-full p-2.5 rounded-2xl border transition-all flex items-center justify-between gap-2 cursor-pointer ${
                  isDeckActive
                    ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-md shadow-amber-500/10'
                    : 'bg-black/50 border-white/10 text-stone-400 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Crown size={16} className={isDeckActive ? 'text-amber-400' : 'text-stone-500'} />
                  <span className="text-xs font-mono font-bold">
                    {isDeckActive 
                      ? (isAr ? 'تشكيلة القتال النشطة' : 'Active Battle Formation')
                      : (isAr ? 'تشكيلة احتياطية' : 'Reserve Formation')}
                  </span>
                </div>
                <div className={`w-8 h-4.5 rounded-full p-0.5 transition-colors ${isDeckActive ? 'bg-amber-400' : 'bg-stone-700'}`}>
                  <div className={`w-3.5 h-3.5 rounded-full bg-black transition-transform ${isDeckActive ? 'translate-x-3.5 rtl:-translate-x-3.5' : 'translate-x-0'}`} />
                </div>
              </button>
            </div>
          </div>

          {/* Section: 4 Tactical Formation Docking Bays */}
          <div className="space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white font-sans tracking-wide">
                  {isAr ? 'المرابط التكتيكية الأربعة' : 'Tactical Docking Bays (4 Operatives)'}
                </h3>
                <span className="text-[11px] font-mono text-stone-400">
                  {isAr ? '(الحد الأقصى 4 بطاقات)' : '(Strict rule: 4 cards max)'}
                </span>
              </div>

              {/* Exact 4 / 4 indicator */}
              <span
                className={`px-3 py-1 rounded-full text-xs font-mono font-bold border transition-all ${
                  selectedCardIds.length === 4
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-[0_0_12px_rgba(52,211,153,0.3)]'
                    : 'bg-teal-500/10 text-[#5eead4] border-[#5eead4]/30'
                }`}
              >
                {selectedCardIds.length} / 4 {selectedCardIds.length === 4 ? (isAr ? 'مكتملة بالكامل' : 'FULL FORMATION') : (isAr ? 'بطاقات' : 'Cards')}
              </span>
            </div>

            {/* The 4 Tactical Pedestals */}
            <div className="grid grid-cols-1 xs:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-3.5">
              {[0, 1, 2, 3].map(slotIndex => {
                const card = selectedCards[slotIndex];
                const isThisSlotReplacing = replacingSlotIndex === slotIndex;
                const roleTitles = ['VANGUARD', 'STRIKER', 'BULWARK', 'TACTICIAN'];
                const roleTitlesAr = ['طليعة', 'مهاجم', 'حصن', 'تكتيكي'];
                const roleDescs = ['Initiative Lead', 'Power & Crit', 'Shield & Guard', 'Resonance Lead'];
                const roleDescsAr = ['أسبقية الهجوم', 'قوة الضربة والفتك', 'الحاجز الحركي', 'تناغم القدرات'];
                const roleColors = ['#5eead4', '#f43f5e', '#38bdf8', '#fbbf24'];
                const roleColor = roleColors[slotIndex];

                return (
                  <div
                    key={slotIndex}
                    className={`relative rounded-3xl border p-3 flex flex-col justify-between transition-all min-h-[220px] overflow-hidden group ${
                      isThisSlotReplacing
                        ? 'bg-gradient-to-b from-amber-950/60 via-black/80 to-amber-950/60 border-amber-400 ring-2 ring-amber-400/50 shadow-[0_0_25px_rgba(251,191,36,0.3)]'
                        : card
                        ? 'bg-gradient-to-b from-[#061d22]/90 via-[#031317]/95 to-[#010a0c]/98 border-[#5eead4]/40 shadow-xl'
                        : 'border-dashed border-teal-900/60 bg-black/40 hover:border-[#5eead4]/40 hover:bg-[#041a1e]/40 flex flex-col items-center justify-center text-center'
                    }`}
                  >
                    {/* Top ambient glow line */}
                    {card && (
                      <div
                        className="absolute top-0 inset-x-0 h-[2px] pointer-events-none"
                        style={{
                          background: `linear-gradient(90deg, transparent 0%, ${roleColor} 50%, transparent 100%)`,
                          boxShadow: `0 0 10px ${roleColor}`
                        }}
                      />
                    )}

                    {/* Role Header */}
                    <div className="flex items-center justify-between pb-1.5 border-b border-white/10 mb-2 text-[10px] font-mono">
                      <span className="font-bold flex items-center gap-1.5" style={{ color: roleColor }}>
                        <span className="w-1.5 h-1.5 rounded-full shadow-xs" style={{ backgroundColor: roleColor }} />
                        <span>#{slotIndex + 1} {isAr ? roleTitlesAr[slotIndex] : roleTitles[slotIndex]}</span>
                      </span>
                      <span className="text-stone-400 text-[9px]">
                        {isAr ? roleDescsAr[slotIndex] : roleDescs[slotIndex]}
                      </span>
                    </div>

                    {card ? (
                      <>
                        {/* Card Image Thumbnail with Rounded Look & Jewel Accent */}
                        <div className="relative aspect-[16/10] rounded-2xl overflow-hidden border border-white/10 mb-2 bg-black shadow-inner">
                          <img
                            src={card.imageUrl}
                            alt={card.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />

                          {/* Jewel Element Bead */}
                          <div className="absolute bottom-1.5 start-2 flex items-center gap-1 text-[9px] font-mono font-bold text-white px-2 py-0.5 rounded-full bg-black/70 border border-white/10 backdrop-blur-md">
                            <span 
                              className="w-2 h-2 rounded-full shrink-0 shadow-xs"
                              style={{ backgroundColor: card.borderColor || roleColor }}
                            />
                            <span>{card.element || 'STONE'}</span>
                          </div>

                          {/* Slot Action Triggers */}
                          <div className="absolute top-1.5 end-1.5 flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleToggleReplaceSlot(slotIndex)}
                              className={`p-1.5 rounded-xl text-white transition-all cursor-pointer shadow-md ${
                                isThisSlotReplacing ? 'bg-amber-500 scale-105' : 'bg-teal-700/80 hover:bg-teal-600'
                              }`}
                              title={isAr ? 'استبدال هذه البطاقة' : 'Swap this card'}
                            >
                              <RefreshCw size={12} className={isThisSlotReplacing ? 'animate-spin' : ''} />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRemoveCard(card.id, slotIndex)}
                              className="p-1.5 rounded-xl bg-rose-700/80 hover:bg-rose-600 text-white transition-all cursor-pointer shadow-md"
                              title={isAr ? 'إزالة' : 'Remove'}
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        </div>

                        {/* Title & Stats */}
                        <div className="space-y-1 min-w-0">
                          <h4 className="text-xs font-bold text-white truncate font-sans">
                            {card.name}
                          </h4>
                          <div className="flex items-center justify-between text-[11px] font-mono text-stone-300 pt-1 border-t border-white/5">
                            <span className="flex items-center gap-1 text-rose-300 font-bold">
                              ⚔️ {card.attack || card.power || 50}
                            </span>
                            <span className="flex items-center gap-1 text-cyan-300 font-bold">
                              🛡️ {card.defense || 50}
                            </span>
                          </div>
                        </div>

                        {/* Swap CTA trigger */}
                        <button
                          type="button"
                          onClick={() => handleToggleReplaceSlot(slotIndex)}
                          className="mt-2 w-full py-1 rounded-xl text-[10px] font-mono font-bold text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 transition-all cursor-pointer flex items-center justify-center gap-1"
                        >
                          <RefreshCw size={10} className={isThisSlotReplacing ? 'animate-spin' : ''} />
                          <span>{isThisSlotReplacing ? (isAr ? 'جارِ التبديل...' : 'Selecting...') : (isAr ? 'استبدال' : 'Swap')}</span>
                        </button>
                      </>
                    ) : (
                      <div className="p-4 text-center space-y-2 my-auto">
                        <div className="w-10 h-10 rounded-2xl border border-dashed border-[#5eead4]/40 flex items-center justify-center mx-auto text-[#5eead4] bg-[#5eead4]/5 group-hover:scale-110 transition-transform">
                          <Plus size={18} />
                        </div>
                        <div>
                          <span className="text-xs font-mono font-bold text-stone-300 block">
                            {isAr ? `الخانة #${slotIndex + 1}` : `Slot #${slotIndex + 1}`}
                          </span>
                          <span className="text-[10px] text-stone-500 font-mono block">
                            {isAr ? 'في انتظار التكليف' : 'Awaiting Operative'}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Holographic Tactical Radar / Stats Telemetry HUD */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-4 rounded-3xl bg-black/60 border border-[#5eead4]/20 backdrop-blur-xl text-center font-mono">
              <div className="p-2.5 rounded-2xl bg-black/40 border border-rose-500/20">
                <span className="text-[10px] uppercase font-bold text-rose-400 flex items-center justify-center gap-1 mb-1">
                  <Flame size={12} />
                  <span>{isAr ? 'إجمالي القوة' : 'Total Power'}</span>
                </span>
                <span className="text-lg sm:text-xl font-black text-white">{calculatedStats.power}</span>
              </div>
              <div className="p-2.5 rounded-2xl bg-black/40 border border-cyan-500/20">
                <span className="text-[10px] uppercase font-bold text-cyan-400 flex items-center justify-center gap-1 mb-1">
                  <Shield size={12} />
                  <span>{isAr ? 'إجمالي الدفاع' : 'Total Defense'}</span>
                </span>
                <span className="text-lg sm:text-xl font-black text-white">{calculatedStats.defense}</span>
              </div>
              <div className="p-2.5 rounded-2xl bg-black/40 border border-amber-500/20">
                <span className="text-[10px] uppercase font-bold text-amber-400 flex items-center justify-center gap-1 mb-1">
                  <Zap size={12} />
                  <span>{isAr ? 'إجمالي السرعة' : 'Total Speed'}</span>
                </span>
                <span className="text-lg sm:text-xl font-black text-white">{calculatedStats.speed}</span>
              </div>
              <div className="p-2.5 rounded-2xl bg-black/40 border border-purple-500/20">
                <span className="text-[10px] uppercase font-bold text-purple-400 flex items-center justify-center gap-1 mb-1">
                  <Activity size={12} />
                  <span>{isAr ? 'التناغم التكتيكي' : 'Team Synergy'}</span>
                </span>
                <span className="text-lg sm:text-xl font-black text-purple-300">{calculatedStats.synergy}%</span>
              </div>
            </div>

            {/* SECTION: 4 TACTICAL CONSUMABLES LOADOUT (BATTLE ITEMS) */}
            <div className="space-y-3 pt-4 border-t border-white/10">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
                    <Backpack size={13} />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white font-sans tracking-wide">
                      {isAr ? 'عناصر المعركة المستهلكة (الخانات الأربع)' : 'Battle Consumables (4 Tactical Item Slots)'}
                    </h3>
                    <p className="text-[11px] text-stone-400 font-mono">
                      {isAr ? 'اختر 4 جرعات أو عناصر لاستخدامها كعتاد أثناء القتال' : 'Choose 4 battle consumables to equip and tilt in combat'}
                    </p>
                  </div>
                </div>

                <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-amber-500/15 text-amber-300 border border-amber-500/40">
                  {selectedItemIds.filter(Boolean).length} / 4 {isAr ? 'عناصر مجهزة' : 'Items Equipped'}
                </span>
              </div>

              {/* The 4 Consumables Bays */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[0, 1, 2, 3].map(slotIdx => {
                  const itemId = selectedItemIds[slotIdx];
                  const item = itemId ? allItems.find(i => i.id === itemId) : null;
                  const isSlotActive = replacingItemSlot === slotIdx;
                  const ownedCount = item ? ((inventoryMap && inventoryMap[item.id]?.count) || (Array.isArray(inventory) ? inventory.find(entry => entry.itemId === item.id)?.count : 0) || 0) : 0;

                  return (
                    <div
                      key={`deck_item_slot_${slotIdx}`}
                      onClick={() => handleToggleReplaceItemSlot(slotIdx)}
                      className={`relative rounded-2xl p-3 border transition-all cursor-pointer flex flex-col justify-between min-h-[140px] group ${
                        isSlotActive
                          ? 'bg-amber-500/20 border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.3)] ring-1 ring-amber-400'
                          : item
                          ? 'bg-gradient-to-b from-[#072428]/90 via-[#041619]/90 to-black/95 border-[#5eead4]/40 hover:border-[#5eead4]'
                          : 'bg-black/40 border-2 border-dashed border-teal-900/50 hover:border-[#5eead4]/40 hover:bg-black/60'
                      }`}
                    >
                      {/* Top Header */}
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[9px] font-mono font-black px-1.5 py-0.2 rounded-full bg-black/70 text-[#5eead4] border border-[#5eead4]/30">
                          ITEM #{slotIdx + 1}
                        </span>
                        {item && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRemoveItemSlot(slotIdx);
                            }}
                            className="p-1 rounded-lg bg-black/70 hover:bg-rose-500/20 text-stone-400 hover:text-rose-300 transition-colors"
                            title={isAr ? 'إزالة' : 'Remove'}
                          >
                            <Trash2 size={11} />
                          </button>
                        )}
                      </div>

                      {/* Content */}
                      {item ? (
                        <div className="flex flex-col items-center text-center my-auto py-1">
                          <img
                            src={item.imageUrl}
                            alt={item.name}
                            className="w-12 h-12 object-contain drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)] group-hover:scale-110 transition-transform"
                            loading="lazy"
                          />
                          <span className="text-xs font-bold text-white font-sans mt-1 truncate max-w-full">
                            {isAr ? (item.nameAr || item.name) : item.name}
                          </span>
                          {item.battleEffect && (
                            <span className="text-[9.5px] font-mono text-cyan-300 mt-0.5">
                              {item.battleEffect.type === 'HEAL_HP' && `+${item.battleEffect.value} HP`}
                              {item.battleEffect.type === 'RESTORE_STAMINA' && `+${item.battleEffect.value} Stamina`}
                              {item.battleEffect.type === 'GRANT_SHIELD' && `+${item.battleEffect.value} Shield`}
                              {item.battleEffect.type === 'BUFF_ATTACK' && `+${item.battleEffect.value}% ATK`}
                              {item.battleEffect.type === 'BUFF_DEFENSE' && `+${item.battleEffect.value}% DEF`}
                            </span>
                          )}
                          <span className="text-[9px] font-mono text-stone-400 mt-0.5">
                            {isAr ? 'مخزون:' : 'Bag:'} {ownedCount}
                          </span>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center text-center my-auto py-2">
                          <div className="w-8 h-8 rounded-xl border border-dashed border-[#5eead4]/40 flex items-center justify-center text-[#5eead4] bg-[#5eead4]/5 mb-1.5 group-hover:scale-110 transition-transform">
                            <Plus size={14} />
                          </div>
                          <span className="text-[10px] font-mono text-stone-400">
                            {isSlotActive ? (isAr ? 'اختر عنصراً' : 'Select Item') : (isAr ? '+ تجهيز عنصر' : '+ Equip Item')}
                          </span>
                        </div>
                      )}

                      {/* Bottom Swap indicator */}
                      <div className="pt-1 border-t border-white/5 text-center">
                        <span className="text-[9px] font-mono font-bold text-amber-300">
                          {isSlotActive 
                            ? (isAr ? 'جارِ الاختيار...' : 'Picking...') 
                            : item 
                            ? (isAr ? 'انقر للاستبدال' : 'Tap to Swap')
                            : (isAr ? 'انقر للتعيين' : 'Tap to Assign')}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Available Battle Consumables Shelf (Shown when clicking any item slot) */}
              {replacingItemSlot !== null && (
                <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-amber-500/40 space-y-2 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-amber-300 flex items-center gap-1.5">
                      <Sparkles size={13} />
                      <span>{isAr ? `اختر عنصراً للخانة #${replacingItemSlot + 1}:` : `Choose consumable for Slot #${replacingItemSlot + 1}:`}</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setReplacingItemSlot(null)}
                      className="text-[11px] font-mono text-stone-400 hover:text-white"
                    >
                      {isAr ? 'إلغاء' : 'Close'}
                    </button>
                  </div>

                  <div className="grid grid-cols-2 xs:grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2 max-h-[180px] overflow-y-auto studio-scrollbar p-1">
                    {allItems
                      .filter(i => {
                        if (i.category !== 'BATTLE') return false;
                        const c = (inventoryMap && inventoryMap[i.id]?.count) || (Array.isArray(inventory) ? inventory.find(entry => entry.itemId === i.id)?.count : 0) || 0;
                        return c > 0;
                      })
                      .map(bItem => {
                        const isSelected = selectedItemIds.includes(bItem.id);
                        const count = (inventoryMap && inventoryMap[bItem.id]?.count) || (Array.isArray(inventory) ? inventory.find(entry => entry.itemId === bItem.id)?.count : 0) || 0;

                        return (
                          <button
                            key={bItem.id}
                            type="button"
                            onClick={() => handleSelectItemForSlot(bItem.id)}
                            className={`p-2 rounded-xl border flex flex-col items-center text-center transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-amber-500/20 border-amber-400 text-amber-200'
                                : 'bg-black/60 border-white/10 hover:border-[#5eead4]/60 hover:bg-[#052228]'
                            }`}
                          >
                            <img
                              src={bItem.imageUrl}
                              alt={bItem.name}
                              className="w-9 h-9 object-contain mb-1"
                              loading="lazy"
                            />
                            <span className="text-[10px] font-bold text-white truncate max-w-full">
                              {isAr ? (bItem.nameAr || bItem.name) : bItem.name}
                            </span>
                            <span className="text-[8.5px] font-mono text-cyan-300">
                              {bItem.battleEffect?.type === 'HEAL_HP' && `+${bItem.battleEffect.value} HP`}
                              {bItem.battleEffect?.type === 'RESTORE_STAMINA' && `+${bItem.battleEffect.value} STM`}
                              {bItem.battleEffect?.type === 'GRANT_SHIELD' && `+${bItem.battleEffect.value} SHLD`}
                              {bItem.battleEffect?.type === 'BUFF_ATTACK' && `+${bItem.battleEffect.value}% ATK`}
                            </span>
                            <span className="text-[8px] font-mono text-stone-400 mt-0.5">
                              x{count}
                            </span>
                          </button>
                        );
                      })}

                    {allItems.filter(i => {
                      if (i.category !== 'BATTLE') return false;
                      const c = (inventoryMap && inventoryMap[i.id]?.count) || (Array.isArray(inventory) ? inventory.find(entry => entry.itemId === i.id)?.count : 0) || 0;
                      return c > 0;
                    }).length === 0 && (
                      <div className="col-span-full py-6 text-center text-stone-400 font-mono text-xs">
                        {isAr ? 'لا توجد عناصر معركة في حقيبتك حالياً.' : 'No combat items in your bag.'}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Section: Card Vault Armory (Owned Cards Selection) */}
          <div className="space-y-3.5 pt-3 border-t border-white/10">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-white font-sans tracking-wide">
                  {isAr ? 'مستودع بطاقاتك المملوكة' : 'Armory: Your Owned Cards'}
                </h3>
                <p className="text-[11px] text-stone-400 font-mono">
                  {isAr ? 'انقر على البطاقة لنشرها في التشكيلة فوراً' : 'Tap any card to deploy directly into an open bay'}
                </p>
              </div>

              {/* Search & Jewel Filter Pills */}
              <div className="flex items-center gap-2 flex-wrap">
                <div className="relative">
                  <Search size={13} className="absolute start-3 top-2.5 text-stone-500" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    placeholder={isAr ? 'بحث بالاسم...' : 'Search card...'}
                    className="ps-8 pe-3 py-1.5 rounded-full bg-black/60 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-[#5eead4] w-36 sm:w-44 transition-all"
                  />
                </div>

                {/* Filter Pills with Jewel Colors (NO Text Rarity Names on cards) */}
                <div className="flex items-center gap-1 overflow-x-auto py-0.5">
                  {Object.entries(RARITY_JEWEL_COLORS).map(([key, conf]) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setSelectedRarityFilter(key)}
                      className={`px-2.5 py-1 rounded-full text-[10px] font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                        selectedRarityFilter === key
                          ? 'bg-[#5eead4] text-black shadow-md shadow-teal-500/20'
                          : 'bg-black/60 text-stone-400 hover:text-white border border-white/10'
                      }`}
                    >
                      <span className={`w-2 h-2 rounded-full ${conf.bg} shrink-0`} />
                      <span>{conf.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Armory Cards Grid */}
            {filteredOwnedCards.length === 0 ? (
              <div className="p-8 rounded-3xl bg-black/40 border border-dashed border-[#5eead4]/20 text-center text-stone-400 text-xs font-mono">
                {isAr ? 'لا توجد بطاقات مطابقة في مستودعك.' : 'No matching cards found in your armory.'}
              </div>
            ) : (
              <div className="grid grid-cols-2 xs:grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-2.5 max-h-[300px] overflow-y-auto p-1.5 studio-scrollbar">
                {filteredOwnedCards.map(({ card, count }) => {
                  const isAlreadyInDeck = selectedCardIds.includes(card.id);
                  const isDeckFull = selectedCardIds.length >= MAX_DECK_CARDS && replacingSlotIndex === null;

                  return (
                    <div
                      key={card.id}
                      className={`relative rounded-2xl border p-2 flex flex-col justify-between transition-all group overflow-hidden ${
                        isAlreadyInDeck
                          ? 'bg-black/50 border-[#5eead4]/25 opacity-70'
                          : 'bg-gradient-to-b from-[#051c20]/80 via-[#031317]/90 to-black/95 hover:from-[#082a30] border-white/10 hover:border-[#5eead4]/50 shadow-md'
                      }`}
                    >
                      <div className="relative aspect-[3/4] rounded-xl overflow-hidden border border-white/10 mb-1.5 bg-black">
                        <img
                          src={card.imageUrl}
                          alt={card.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          loading="lazy"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />

                        {/* Duplicate Copies Badge */}
                        <span className="absolute top-1 end-1 px-1.5 py-0.5 rounded-full bg-black/80 text-[9px] font-mono font-bold text-amber-300 border border-amber-500/30">
                          x{count}
                        </span>

                        {/* Jewel Element Bead */}
                        <div className="absolute bottom-1 start-1">
                          <span 
                            className="w-2 h-2 rounded-full block shadow-xs"
                            style={{ backgroundColor: card.borderColor || '#5eead4' }}
                          />
                        </div>
                      </div>

                      <div className="space-y-1 min-w-0">
                        <h5 className="text-[11px] font-bold text-white truncate font-sans leading-tight">
                          {card.name}
                        </h5>

                        <button
                          type="button"
                          disabled={isAlreadyInDeck || isDeckFull}
                          onClick={() => handleCardClick(card.id)}
                          className={`w-full py-1.5 rounded-full text-[10px] font-mono font-bold transition-all cursor-pointer flex items-center justify-center gap-1 ${
                            isAlreadyInDeck
                              ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/30'
                              : replacingSlotIndex !== null
                              ? 'bg-amber-400 hover:bg-amber-300 text-stone-950 shadow-md font-black'
                              : isDeckFull
                              ? 'bg-black/50 text-stone-600 border border-white/5 cursor-not-allowed'
                              : 'bg-gradient-to-r from-[#5eead4] to-[#2dd4bf] hover:brightness-110 text-stone-950 shadow-sm active:scale-95'
                          }`}
                        >
                          {isAlreadyInDeck
                            ? (isAr ? '✓ مجهزة' : '✓ Deployed')
                            : replacingSlotIndex !== null
                            ? (isAr ? 'استبدال ↺' : 'Swap In ↺')
                            : isDeckFull
                            ? (isAr ? 'المربط ممتلئ' : 'Full')
                            : (isAr ? '+ تجهيز' : '+ Deploy')}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Tactical Footer Controls */}
        <div className="px-5 sm:px-8 py-3.5 bg-black/85 border-t border-white/10 flex items-center justify-between gap-3 shrink-0 backdrop-blur-xl">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 text-stone-300 text-xs font-mono font-bold transition-all cursor-pointer active:scale-95"
          >
            {isAr ? 'إلغاء' : 'Cancel'}
          </button>

          <button
            type="button"
            disabled={isSaving || selectedCardIds.length === 0}
            onClick={handleSaveDeck}
            className="px-6 py-2.5 rounded-full bg-gradient-to-r from-[#5eead4] via-[#2dd4bf] to-amber-300 hover:brightness-110 active:scale-[0.98] text-[#031211] font-black text-xs font-mono flex items-center gap-2 shadow-lg shadow-teal-500/25 transition-all cursor-pointer disabled:opacity-50"
          >
            {isSaving ? (
              <Loader2 size={14} className="animate-spin text-black" />
            ) : (
              <Save size={14} className="text-black" />
            )}
            <span>{isSaving ? (isAr ? 'جارِ النشر...' : 'Deploying...') : (isAr ? 'حفظ ونشر التشكيلة' : 'Deploy Formation')}</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
};
