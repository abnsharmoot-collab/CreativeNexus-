import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { PlayerProfileData } from '../../types/progression';
import { StaffMember } from '../../types/staff';
import { RankTier } from '../../types/rankMap';
import { RARITY_THEMES } from '../cards/CollectibleCard';
import { 
  Shield, Sparkles, Edit3, Share2, Check, Award, Trophy, 
  Copy, Image as ImageIcon, Crown, ExternalLink, Zap, HardDrive, Loader2
} from 'lucide-react';
import { motion } from 'motion/react';
import { compressImageFile } from '../../utils/imageCompressor';

interface ProfileHeaderProps {
  profileData: PlayerProfileData;
  isOwnProfile: boolean;
  onOpenEdit: () => void;
  onOpenBannerSelector?: () => void;
  onDirectUploadBanner?: (bannerUrl: string | null) => Promise<void> | void;
  staffMember?: StaffMember | null;
  effectiveRole?: 'OWNER' | 'SUPER_ADMIN' | 'ADMIN' | 'MODERATOR' | 'STAFF' | 'MEMBER';
  moderatorLevel?: number;
  currentTier?: RankTier | null;
  nextTier?: RankTier | null;
  isAr?: boolean;
}

export const ProfileHeader: React.FC<ProfileHeaderProps> = ({
  profileData,
  isOwnProfile,
  onOpenEdit,
  onOpenBannerSelector,
  onDirectUploadBanner,
  staffMember,
  effectiveRole,
  moderatorLevel = 1,
  currentTier,
  nextTier,
  isAr = false,
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedId, setCopiedId] = useState(false);
  const [isUploadingFromDevice, setIsUploadingFromDevice] = useState(false);
  const deviceFileInputRef = React.useRef<HTMLInputElement>(null);

  const handleDeviceFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !onDirectUploadBanner) return;
    setIsUploadingFromDevice(true);
    try {
      const processed = await compressImageFile(file, 1600, 0.85);
      await onDirectUploadBanner(processed.dataUrl);
    } catch (err) {
      console.error('Error compressing/saving banner from device:', err);
    } finally {
      setIsUploadingFromDevice(false);
      if (e.target) e.target.value = '';
    }
  };

  const selectedTitle = profileData.selectedTitle;
  const progression = profileData.progression;
  const titleRarity = selectedTitle?.rarity || 'COMMON';
  const rarityTheme = RARITY_THEMES[titleRarity];

  // Resolve role accurately
  const isOwner = effectiveRole === 'OWNER' || profileData.isOwner || profileData.role === 'OWNER';
  const isModerator = effectiveRole === 'MODERATOR' || effectiveRole === 'ADMIN' || effectiveRole === 'SUPER_ADMIN' || profileData.isModerator || profileData.role === 'MODERATOR' || Boolean(profileData.staffInfo?.isModerator);
  const isStaff = isOwner || isModerator || effectiveRole === 'STAFF' || Boolean(staffMember) || Boolean(profileData.isStaff) || Boolean(profileData.staffInfo?.isStaff);

  const staffPoints = staffMember?.points ?? profileData.staffInfo?.points ?? (isOwner ? 9999 : 0);
  const minPoints = currentTier?.minPoints ?? profileData.staffInfo?.minPoints ?? 0;
  const maxPoints = currentTier?.maxPoints ?? profileData.staffInfo?.maxPoints ?? 100;
  const range = Math.max(1, maxPoints - minPoints);
  const staffProgressPercent = Math.min(100, Math.max(0, Math.round(((staffPoints - minPoints) / range) * 100)));

  const handleCopyLink = () => {
    const url = `${window.location.origin}/profile/${profileData.discordId}`;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleCopyDiscordId = () => {
    navigator.clipboard.writeText(profileData.discordId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const bannerBackground = profileData.bannerUrl || profileData.cosmetics?.profileBackground;

  return (
    <div className="relative rounded-2xl sm:rounded-3xl bg-[#041619]/95 border border-[rgba(158,255,230,0.2)] shadow-2xl overflow-hidden backdrop-blur-2xl w-full max-w-full box-border min-w-0">
      {/* ========================================================================= */}
      {/* 1. CUSTOM HERO BANNER (Fully responsive on 320px–430px+)                  */}
      {/* ========================================================================= */}
      <div className="relative h-32 xs:h-36 sm:h-52 md:h-64 w-full max-w-full overflow-hidden bg-gradient-to-r from-[#031d20] via-[#082a26] to-[#021315] box-border">
        {bannerBackground ? (
          <img
            src={bannerBackground}
            alt="Profile Banner"
            className="w-full h-full object-cover object-center transform scale-100 transition-transform duration-700 hover:scale-105"
          />
        ) : (
          <div className="w-full h-full relative overflow-hidden bg-gradient-to-r from-[#041c1a] via-[#0a312d] to-[#031413]">
            <div className="absolute inset-0 bg-[radial-gradient(#2dd4bf_1px,transparent_1px)] [background-size:20px_20px] sm:[background-size:24px_24px] opacity-20" />
            <div className="absolute top-1/2 start-1/2 -translate-x-1/2 -translate-y-1/2 w-72 sm:w-96 h-72 sm:h-96 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />
          </div>
        )}

        {/* Ambient Gradient Scrim */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#041619] via-[#041619]/40 to-black/30 pointer-events-none" />

        {/* Top Floating Action Buttons on Banner */}
        <div className="absolute top-2 end-2 xs:top-2.5 xs:end-2.5 sm:top-4 sm:end-4 flex items-center gap-1 xs:gap-1.5 sm:gap-2 z-20 flex-wrap justify-end max-w-[calc(100%-1rem)]">
          {/* Hidden file input for direct device button */}
          <input
            type="file"
            ref={deviceFileInputRef}
            onChange={handleDeviceFileSelect}
            accept="image/png,image/jpeg,image/webp,image/gif"
            className="hidden"
          />

          {isOwnProfile && onDirectUploadBanner && (
            <button
              type="button"
              disabled={isUploadingFromDevice}
              onClick={() => deviceFileInputRef.current?.click()}
              className="flex items-center gap-1 sm:gap-1.5 px-2 xs:px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-lg sm:rounded-xl text-[10px] xs:text-[11px] sm:text-xs font-bold text-amber-200 bg-amber-950/80 hover:bg-amber-900/90 border border-amber-400/50 hover:border-amber-300 backdrop-blur-md transition-all shadow-lg cursor-pointer active:scale-95 shrink-0 disabled:opacity-50"
              title={isAr ? 'رفع غلاف من جهازك مباشرة' : 'Upload Banner from Device'}
            >
              {isUploadingFromDevice ? (
                <Loader2 size={12} className="animate-spin text-amber-300 shrink-0 sm:w-[13px] sm:h-[13px]" />
              ) : (
                <HardDrive size={12} className="text-amber-300 shrink-0 sm:w-[13px] sm:h-[13px]" />
              )}
              <span>{isUploadingFromDevice ? (isAr ? 'جاري الرفع...' : 'Uploading...') : (isAr ? 'غلاف من الجهاز' : 'From Device')}</span>
            </button>
          )}

          {isOwnProfile && onOpenBannerSelector && (
            <button
              type="button"
              onClick={onOpenBannerSelector}
              className="flex items-center gap-1 sm:gap-1.5 px-2 xs:px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-lg sm:rounded-xl text-[10px] xs:text-[11px] sm:text-xs font-bold text-[#5eead4] bg-black/75 hover:bg-black/90 border border-[#5eead4]/40 hover:border-[#5eead4] backdrop-blur-md transition-all shadow-lg cursor-pointer active:scale-95 shrink-0"
              title={isAr ? 'تغيير غلاف الملف الشخصي' : 'Change Profile Banner'}
            >
              <ImageIcon size={12} className="text-[#5eead4] shrink-0 sm:w-[13px] sm:h-[13px]" />
              <span>{isAr ? 'معرض الأغلفة' : 'Banner Gallery'}</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleCopyLink}
            className="flex items-center gap-1 sm:gap-1.5 px-2 xs:px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-lg sm:rounded-xl text-[10px] xs:text-[11px] sm:text-xs font-medium text-white bg-black/75 hover:bg-black/90 border border-white/20 backdrop-blur-md transition-all shadow-lg cursor-pointer active:scale-95 shrink-0"
            title={isAr ? 'نسخ رابط الملف' : 'Copy profile link'}
          >
            {copiedLink ? <Check size={11} className="text-emerald-400 shrink-0 sm:w-3 sm:h-3" /> : <Share2 size={11} className="shrink-0 sm:w-3 sm:h-3" />}
            <span>{copiedLink ? (isAr ? 'تم النسخ!' : 'Copied!') : (isAr ? 'مشاركة' : 'Share')}</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. PROFILE BODY WITH PROTRUDING AVATAR & IDENTITY                         */}
      {/* ========================================================================= */}
      <div className="relative px-3 xs:px-4 sm:px-7 pb-4 xs:pb-5 sm:pb-8 pt-0 w-full max-w-full box-border min-w-0">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-3.5 sm:gap-6 -mt-10 xs:-mt-12 sm:-mt-20 w-full min-w-0">
          {/* Avatar and Identity */}
          <div className="flex flex-col sm:flex-row sm:items-end gap-3 xs:gap-3.5 sm:gap-5 w-full min-w-0 flex-1">
            {/* Avatar Container */}
            <div className="relative shrink-0 self-start">
              <div 
                className="w-18 h-18 xs:w-20 xs:h-20 sm:w-28 sm:h-28 rounded-2xl sm:rounded-3xl p-1 shadow-[0_15px_35px_rgba(0,0,0,0.8)] relative overflow-hidden bg-[#020d0f]"
                style={{
                  background: isOwner 
                    ? 'linear-gradient(135deg, #f59e0b, #78350f)' 
                    : isModerator 
                    ? 'linear-gradient(135deg, #6366f1, #312e81)' 
                    : 'linear-gradient(135deg, #5eead4, #0f766e)'
                }}
              >
                <img
                  src={profileData.avatarUrl || 'https://cdn.discordapp.com/embed/avatars/0.png'}
                  alt={profileData.displayName}
                  className="w-full h-full object-cover rounded-[13px] xs:rounded-[14px] sm:rounded-[22px] bg-[#020d0f]"
                />
              </div>

              {/* Status Indicator */}
              <span 
                className="absolute bottom-0.5 end-0.5 w-3.5 h-3.5 sm:w-5 sm:h-5 bg-emerald-400 border-2 sm:border-3 border-[#041619] rounded-full shadow-md"
                title="Online"
              />
            </div>

            {/* Names & Main Roles */}
            <div className="space-y-1.5 pb-0.5 sm:pb-1 w-full min-w-0 flex-1">
              {/* Official Role Badges */}
              <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap w-full max-w-full min-w-0">
                {isOwner ? (
                  <span className="inline-flex items-center gap-1 sm:gap-1.5 px-2 xs:px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-xl text-[10px] xs:text-[11px] sm:text-xs font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/50 shadow-[0_0_15px_rgba(245,158,11,0.25)] break-words [overflow-wrap:anywhere] max-w-full">
                    <Crown size={12} className="text-amber-400 animate-pulse shrink-0 sm:w-[13px] sm:h-[13px]" />
                    <span>{isAr ? 'المالك والمؤسس الأعلى' : 'SOVEREIGN SERVER OWNER'}</span>
                  </span>
                ) : isModerator ? (
                  <span className="inline-flex items-center gap-1 sm:gap-1.5 px-2 xs:px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-xl text-[10px] xs:text-[11px] sm:text-xs font-mono font-bold bg-indigo-500/25 text-indigo-300 border border-indigo-500/50 shadow-[0_0_15px_rgba(99,102,241,0.25)] break-words [overflow-wrap:anywhere] max-w-full">
                    <Shield size={12} className="text-indigo-400 shrink-0 sm:w-[13px] sm:h-[13px]" />
                    <span>{isAr ? `مشرف سيرفر معتمد • المستوى ${moderatorLevel}` : `VERIFIED MODERATOR • Level ${moderatorLevel}`}</span>
                  </span>
                ) : isStaff ? (
                  <span className="inline-flex items-center gap-1 sm:gap-1.5 px-2 xs:px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-xl text-[10px] xs:text-[11px] sm:text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 break-words [overflow-wrap:anywhere] max-w-full">
                    <Zap size={12} className="text-emerald-400 shrink-0 sm:w-[13px] sm:h-[13px]" />
                    <span>{isAr ? 'طاقم الإدارة الميدانية' : 'STAFF MEMBER'}</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 sm:gap-1.5 px-2 xs:px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-xl text-[10px] xs:text-[11px] sm:text-xs font-mono font-semibold bg-[#5eead4]/15 text-[#5eead4] border border-[#5eead4]/30 break-words [overflow-wrap:anywhere] max-w-full">
                    <span>👤</span>
                    <span>{isAr ? 'عضو مجتمعي معتمد' : 'COMMUNITY MEMBER'}</span>
                  </span>
                )}

                {/* Level badge */}
                <span className="inline-flex items-center gap-1 px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-xl text-[10px] xs:text-[11px] sm:text-xs font-mono font-bold bg-black/60 text-amber-300 border border-white/10 shrink-0">
                  <Trophy size={11} className="text-amber-400 shrink-0" />
                  <span>LV {progression.level}</span>
                </span>
              </div>

              {/* Display Name & Username */}
              <div className="flex items-center gap-1.5 xs:gap-2 flex-wrap w-full max-w-full min-w-0">
                <h1 className="text-lg xs:text-xl sm:text-2xl md:text-3xl font-display font-black text-white tracking-wide break-words max-w-full leading-tight [overflow-wrap:anywhere]">
                  {profileData.displayName || profileData.username}
                </h1>
                <p className="text-xs sm:text-sm font-mono text-[#5eead4]/80 break-all">
                  @{profileData.username}
                </p>

                {/* Discord ID copy pill */}
                <button
                  type="button"
                  onClick={handleCopyDiscordId}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-mono text-[#8db8b1] hover:text-[#5eead4] bg-black/50 hover:bg-black/70 border border-white/10 transition-colors cursor-pointer shrink-0"
                  title={isAr ? 'نسخ معرف ديسكورد' : 'Copy Discord ID'}
                >
                  <span>#{profileData.discordId.slice(-6)}</span>
                  {copiedId ? <Check size={10} className="text-emerald-400" /> : <Copy size={10} />}
                </button>
              </div>

              {/* Equipped Title underneath username */}
              {selectedTitle && (
                <div className="pt-0.5 flex items-center gap-1.5 sm:gap-2 flex-wrap max-w-full min-w-0">
                  <span 
                    className={`inline-flex items-center gap-1 sm:gap-1.5 px-2 xs:px-2.5 sm:px-3 py-0.5 sm:py-1 rounded-xl text-[10px] xs:text-[11px] sm:text-xs font-mono font-bold tracking-wider uppercase border shadow-md max-w-full break-words [overflow-wrap:anywhere] ${rarityTheme.badge}`}
                    style={{ borderColor: rarityTheme.accent }}
                  >
                    <Award size={12} style={{ color: rarityTheme.accent }} className="shrink-0" />
                    <span className="break-words line-clamp-1">{isAr ? selectedTitle.nameAr : selectedTitle.name}</span>
                  </span>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-[#8db8b1]/70 shrink-0">
                    [{titleRarity}]
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Right Action buttons */}
          <div className="flex items-center gap-1.5 xs:gap-2 flex-wrap w-full lg:w-auto shrink-0 pt-1 lg:pt-0">
            {isOwnProfile && (
              <button
                type="button"
                onClick={onOpenEdit}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold text-amber-200 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 hover:border-amber-300 transition-all shadow-md cursor-pointer active:scale-95 min-w-0"
              >
                <Edit3 size={13} className="text-amber-300 shrink-0" />
                <span className="truncate">{isAr ? 'تخصيص الملف' : 'Customize Profile'}</span>
              </button>
            )}

            {isOwnProfile && onOpenBannerSelector && (
              <button
                type="button"
                onClick={onOpenBannerSelector}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 sm:px-3.5 py-2 rounded-xl text-xs font-bold text-[#5eead4] bg-[#5eead4]/10 hover:bg-[#5eead4]/20 border border-[#5eead4]/30 transition-all shadow-xs cursor-pointer active:scale-95 min-w-0"
              >
                <ImageIcon size={13} className="shrink-0" />
                <span className="truncate">{isAr ? 'تغيير الغلاف' : 'Change Banner'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Dual Progress Bars Overview (Moderator & Account Progression) */}
        <div className="mt-4 xs:mt-5 sm:mt-6 pt-3.5 xs:pt-4 sm:pt-5 border-t border-white/10 grid grid-cols-1 md:grid-cols-2 gap-2.5 xs:gap-3 sm:gap-4 w-full min-w-0 box-border">
          {/* Card 1: Moderator & Staff Rank Progression (HIGH COUNCIL MANAGER / Rank Card) */}
          {isStaff ? (
            <div className="p-3 sm:p-3.5 rounded-2xl bg-black/40 border border-indigo-500/20 space-y-2 w-full max-w-full min-w-0 box-border overflow-hidden">
              <div className="flex flex-col xs:flex-row xs:items-center justify-between gap-1 xs:gap-1.5 text-xs font-mono w-full min-w-0">
                <div className="font-bold text-indigo-300 flex items-center gap-1.5 min-w-0 flex-1 flex-wrap">
                  <Shield size={13} className="text-indigo-400 shrink-0" />
                  <span className="text-[#8db8b1] shrink-0">{isAr ? 'الرتبة الميدانية:' : 'Field Rank:'}</span>
                  <span className="text-white font-bold break-words [overflow-wrap:anywhere] max-w-full">
                    {currentTier ? (isAr && currentTier.nameAr ? currentTier.nameAr : currentTier.name) : 'Moderator'}
                  </span>
                </div>
                <span className="text-amber-300 font-bold font-mono shrink-0 self-start xs:self-auto text-[11px] xs:text-xs">
                  {staffPoints.toLocaleString()} PTS
                </span>
              </div>

              {/* Responsive Progress Bar */}
              <div className="w-full max-w-full h-2 rounded-full bg-black/60 border border-white/10 overflow-hidden p-0.5 box-border">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-[#5eead4] transition-all duration-700"
                  style={{ width: `${Math.min(100, Math.max(0, staffProgressPercent))}%`, maxWidth: '100%' }}
                />
              </div>

              <div className="flex items-center justify-between gap-1 text-[10px] font-mono text-[#8db8b1] w-full min-w-0">
                <span className="truncate flex-1 min-w-0">{staffProgressPercent}% {isAr ? 'نحو' : 'to'} {nextTier ? (isAr && nextTier.nameAr ? nextTier.nameAr : nextTier.name) : (isAr ? 'القمة' : 'Summit')}</span>
                {nextTier && <span className="shrink-0">{nextTier.minPoints} PTS</span>}
              </div>
            </div>
          ) : (
            <div className="p-3 sm:p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-1.5 flex flex-wrap items-center justify-between gap-2 w-full max-w-full min-w-0 box-border overflow-hidden">
              <div className="min-w-0 flex-1">
                <p className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Sparkles size={13} className="text-[#5eead4] shrink-0" />
                  <span>{isAr ? 'عضوية مركز الإبداع الرسمية' : 'Creative Nexus Membership'}</span>
                </p>
                <p className="text-[11px] text-[#8db8b1] truncate">
                  {isAr ? 'استكشف مسار رتب المشرفين والارتقاء بالمجتمع' : 'Explore moderator ranks & earn prestige'}
                </p>
              </div>
              <Link
                to="/rank-points"
                className="px-3 py-1.5 rounded-xl text-xs font-semibold text-[#5eead4] bg-[#5eead4]/10 hover:bg-[#5eead4]/20 border border-[#5eead4]/30 transition-all shrink-0"
              >
                {isAr ? 'خريطة الرتب' : 'Rank Map'}
              </Link>
            </div>
          )}

          {/* Card 2: Collector & Account Level */}
          <div className="p-3 sm:p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-2 w-full max-w-full min-w-0 box-border overflow-hidden">
            <div className="flex flex-col xs:flex-row xs:items-center justify-between gap-1 xs:gap-1.5 text-xs font-mono w-full min-w-0">
              <span className="font-bold text-[#8db8b1] flex items-center gap-1.5 min-w-0 flex-1 flex-wrap">
                <Trophy size={13} className="text-amber-400 shrink-0" />
                <span className="shrink-0">{isAr ? 'مستوى الحساب الإجمالي:' : 'Account Progression:'}</span>
                <span className="text-white font-bold shrink-0">LEVEL {progression.level}</span>
              </span>
              <span className="text-amber-300 font-bold font-mono shrink-0 self-start xs:self-auto text-[11px] xs:text-xs">
                {progression.xpIntoLevel.toLocaleString()} / {progression.xpNeededForNextLevel.toLocaleString()} XP
              </span>
            </div>

            {/* Responsive Progress Bar */}
            <div className="w-full max-w-full h-2 rounded-full bg-black/60 border border-white/10 overflow-hidden p-0.5 box-border">
              <div
                className="h-full rounded-full bg-gradient-to-r from-amber-500 via-amber-400 to-[#5eead4] transition-all duration-700"
                style={{ width: `${Math.min(100, Math.max(0, progression.progressPercent))}%`, maxWidth: '100%' }}
              />
            </div>

            <div className="flex items-center justify-between gap-1 text-[10px] font-mono text-[#8db8b1] w-full min-w-0">
              <span className="truncate flex-1 min-w-0">{progression.progressPercent}% {isAr ? 'نحو المستوى التالي' : 'to Level'} {progression.level + 1}</span>
              <span className="shrink-0">{profileData.xp.toLocaleString()} XP</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
