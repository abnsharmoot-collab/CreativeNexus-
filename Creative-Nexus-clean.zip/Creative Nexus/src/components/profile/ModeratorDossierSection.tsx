import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Shield, Award, Clock, CheckCircle2, XCircle, Send, 
  ExternalLink, ChevronRight, Crown, FileText, Zap
} from 'lucide-react';
import { StaffMember } from '../../types/staff';
import { RankTier, RankApplication, ApplicationStatus } from '../../types/rankMap';
import { PlayerProfileData } from '../../types/progression';

interface ModeratorDossierSectionProps {
  profileData: PlayerProfileData;
  staffMember?: StaffMember | null;
  application?: RankApplication | null;
  applicationStatus: ApplicationStatus;
  currentTier: RankTier;
  nextTier?: RankTier | null;
  points: number;
  progressPercent: number;
  isOwnProfile: boolean;
  onApplyForRank?: () => Promise<void>;
  isAr?: boolean;
}

export const ModeratorDossierSection: React.FC<ModeratorDossierSectionProps> = ({
  profileData,
  staffMember,
  application,
  applicationStatus,
  currentTier,
  nextTier,
  points,
  progressPercent,
  isOwnProfile,
  onApplyForRank,
  isAr = false,
}) => {
  const [isApplying, setIsApplying] = useState(false);
  const [applyMessage, setApplyMessage] = useState<string | null>(null);

  const isOwner = profileData.isOwner || profileData.role === 'OWNER';
  const roleName = isAr && currentTier.nameAr ? currentTier.nameAr : currentTier.name;
  const nextRoleName = nextTier ? (isAr && nextTier.nameAr ? nextTier.nameAr : nextTier.name) : null;
  const pointsRemaining = nextTier ? Math.max(0, nextTier.minPoints - points) : 0;

  const handleApplyClick = async () => {
    if (!onApplyForRank || isApplying) return;
    setIsApplying(true);
    setApplyMessage(null);
    try {
      await onApplyForRank();
      setApplyMessage(isAr ? 'تم إرسال طلب الترقية بنجاح إلى القيادة العليا!' : 'Promotion application submitted successfully!');
    } catch (err: any) {
      setApplyMessage(err.message || (isAr ? 'فشل إرسال الطلب' : 'Failed to submit application'));
    } finally {
      setIsApplying(false);
    }
  };

  return (
    <div className="rounded-2xl sm:rounded-3xl bg-gradient-to-br from-[#051c20]/95 via-[#031518]/95 to-[#010c0e]/98 border border-[rgba(158,255,230,0.22)] p-3.5 xs:p-4 sm:p-7 shadow-2xl space-y-3.5 xs:space-y-4 sm:space-y-6 relative overflow-hidden backdrop-blur-xl w-full max-w-full box-border min-w-0">
      {/* Ambient background glow */}
      <div className="absolute top-0 end-0 w-64 sm:w-80 h-64 sm:h-80 rounded-full blur-3xl pointer-events-none opacity-20 bg-indigo-500" />
      <div className="absolute bottom-0 start-0 w-64 sm:w-80 h-64 sm:h-80 rounded-full blur-3xl pointer-events-none opacity-15 bg-[#5eead4]" />

      {/* Section Header */}
      <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 sm:gap-3 border-b border-white/10 pb-3 sm:pb-4 w-full min-w-0">
        <div className="flex items-start sm:items-center gap-2 xs:gap-2.5 sm:gap-3 min-w-0 flex-1">
          <div className="p-2 sm:p-2.5 rounded-xl sm:rounded-2xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-md shadow-indigo-500/10 shrink-0">
            <Shield size={16} className="text-indigo-400 sm:w-5 sm:h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap min-w-0">
              <h2 className="text-sm xs:text-base sm:text-xl font-bold text-white font-display break-words [overflow-wrap:anywhere] max-w-full leading-snug">
                {isAr ? 'الملف الإداري وبيانات المشرف' : 'Moderator Dossier & Rank Status'}
              </h2>
              {isOwner ? (
                <span className="text-[9px] xs:text-[10px] font-mono font-bold px-1.5 xs:px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 shrink-0">
                  👑 OWNER
                </span>
              ) : (
                <span className="text-[9px] xs:text-[10px] font-mono font-bold px-1.5 xs:px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shrink-0">
                  🛡️ MODERATOR
                </span>
              )}
            </div>
            <p className="text-[11px] xs:text-xs text-[#8db8b1] break-words [overflow-wrap:anywhere] mt-0.5 leading-relaxed">
              {isAr 
                ? 'تفاصيل الرتبة، نقاط النشاط الميداني، وحالة تقديم طلبات الترقية بالسيرفر' 
                : 'Current server rank, moderation points, and promotion application status'}
            </p>
          </div>
        </div>

        {/* Rank Map Button */}
        <Link
          to="/rank-points"
          className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-[#5eead4] bg-[#5eead4]/10 hover:bg-[#5eead4]/20 border border-[#5eead4]/30 transition-all shadow-xs w-full sm:w-auto shrink-0 max-w-full cursor-pointer box-border"
        >
          <span>{isAr ? 'خريطة الرتب التفاعلية' : 'Open Rank Map'}</span>
          <ChevronRight size={14} className={`shrink-0 ${isAr ? 'rotate-180' : ''}`} />
        </Link>
      </div>

      {/* Main Grid: 3 Cards */}
      <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-2.5 xs:gap-3 sm:gap-4 w-full min-w-0 box-border">
        {/* Card 1: Role That He Got */}
        <div className="p-3 xs:p-3.5 sm:p-4 rounded-2xl bg-black/45 border border-white/10 space-y-2 xs:space-y-2.5 w-full max-w-full min-w-0 box-border overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-1.5 min-w-0">
            <span className="text-[10px] xs:text-[11px] font-mono uppercase tracking-wider text-[#8db8b1] flex items-center gap-1.5 min-w-0">
              <Award size={13} className="text-[#5eead4] shrink-0" />
              <span className="truncate">{isAr ? 'الرتبة الميدانية الحالية' : 'Assigned Role & Tier'}</span>
            </span>
            <span className="px-1.5 xs:px-2 py-0.5 rounded-md text-[9px] xs:text-[10px] font-mono font-bold bg-[#5eead4]/15 text-[#5eead4] border border-[#5eead4]/30 shrink-0">
              {currentTier.pointsLabel}
            </span>
          </div>

          <div>
            <h3 className="text-sm xs:text-base sm:text-lg font-bold text-white tracking-wide break-words [overflow-wrap:anywhere] max-w-full leading-snug">
              {roleName}
            </h3>
            <p className="text-[11px] xs:text-xs text-[#8db8b1] mt-0.5 break-words [overflow-wrap:anywhere] leading-relaxed">
              {isAr && currentTier.descriptionAr ? currentTier.descriptionAr : currentTier.description}
            </p>
          </div>

          <div className="pt-2 border-t border-white/5 flex flex-wrap items-center justify-between gap-1 text-[10px] xs:text-[11px] font-mono min-w-0">
            <span className="text-stone-400 shrink-0">{isAr ? 'القسم الهيكلي:' : 'Structure Section:'}</span>
            <span className="text-indigo-300 font-bold break-words [overflow-wrap:anywhere]">{currentTier.section.toUpperCase()}</span>
          </div>
        </div>

        {/* Card 2: Moderator Points That He Got */}
        <div className="p-3 xs:p-3.5 sm:p-4 rounded-2xl bg-black/45 border border-white/10 space-y-2 xs:space-y-2.5 w-full max-w-full min-w-0 box-border overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-1.5 min-w-0">
            <span className="text-[10px] xs:text-[11px] font-mono uppercase tracking-wider text-[#8db8b1] flex items-center gap-1.5 min-w-0">
              <Zap size={13} className="text-amber-400 shrink-0" />
              <span className="truncate">{isAr ? 'رصيد نقاط المشرف' : 'Moderation Points'}</span>
            </span>
            <span className="text-xs font-mono font-black text-amber-300 shrink-0">
              {points.toLocaleString()} PTS
            </span>
          </div>

          {/* Progress Bar relative 100% to parent */}
          <div className="space-y-1.5 pt-0.5 xs:pt-1 w-full min-w-0">
            <div className="flex items-center justify-between gap-1 text-[10px] xs:text-[11px] font-mono min-w-0">
              <span className="text-stone-400 truncate">{isAr ? 'التقدم نحو الرتبة التالية:' : 'Progress to next:'}</span>
              <span className="text-amber-300 font-bold shrink-0">{progressPercent}%</span>
            </div>
            <div className="w-full max-w-full h-2 xs:h-2.5 rounded-full bg-black/70 border border-white/10 overflow-hidden p-0.5 box-border">
              <div
                className="h-full rounded-full bg-gradient-to-r from-amber-500 via-amber-400 to-[#5eead4] transition-all duration-700"
                style={{ width: `${Math.min(100, Math.max(0, progressPercent))}%`, maxWidth: '100%' }}
              />
            </div>
          </div>

          <div className="pt-1 flex flex-wrap items-center justify-between gap-1 text-[10px] xs:text-[11px] font-mono min-w-0">
            {nextTier ? (
              <>
                <span className="text-stone-400 shrink-0">{isAr ? 'المطلوب:' : 'Remaining:'}</span>
                <span className="text-[#5eead4] font-bold break-words [overflow-wrap:anywhere]">
                  {pointsRemaining} PTS {isAr ? `لـ ${nextRoleName}` : `for ${nextRoleName}`}
                </span>
              </>
            ) : (
              <span className="text-amber-300 font-bold">{isAr ? 'القمة الإدارية القصوى' : 'Highest Rank Achieved'}</span>
            )}
          </div>
        </div>

        {/* Card 3: Application Status (Did he apply or not?) */}
        <div className="p-3 xs:p-3.5 sm:p-4 rounded-2xl bg-black/45 border border-white/10 space-y-2 xs:space-y-2.5 w-full max-w-full min-w-0 box-border overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-1.5 min-w-0">
            <span className="text-[10px] xs:text-[11px] font-mono uppercase tracking-wider text-[#8db8b1] flex items-center gap-1.5 min-w-0">
              <FileText size={13} className="text-cyan-400 shrink-0" />
              <span className="truncate">{isAr ? 'حالة التقديم للرتبة' : 'Promotion Application'}</span>
            </span>
            <span className="text-[9px] xs:text-[10px] font-mono text-stone-400 shrink-0">
              {application?.appliedAt ? new Date(application.appliedAt).toLocaleDateString() : (isAr ? 'سجل مباشر' : 'Direct')}
            </span>
          </div>

          {/* Status Display */}
          <div className="pt-0.5 w-full min-w-0">
            {applicationStatus === 'APPROVED' ? (
              <div className="space-y-1.5 w-full min-w-0">
                <div className="inline-flex items-center gap-1.5 px-2.5 xs:px-3 py-1 rounded-xl text-[11px] xs:text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 max-w-full break-words [overflow-wrap:anywhere]">
                  <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                  <span>{isAr ? 'تم التقديم وقبول الطلب' : 'Applied: Approved by Owner'}</span>
                </div>
                <p className="text-[11px] text-[#8db8b1] break-words [overflow-wrap:anywhere] leading-relaxed">
                  {isAr 
                    ? `تم اعتماد ترقية الرتبة رسمياً من القيادة${application?.reviewedBy ? ` بواسطة ${application.reviewedBy}` : ''}.`
                    : `Rank application reviewed and authorized by server administration.`}
                </p>
              </div>
            ) : applicationStatus === 'PENDING' ? (
              <div className="space-y-1.5 w-full min-w-0">
                <div className="inline-flex items-center gap-1.5 px-2.5 xs:px-3 py-1 rounded-xl text-[11px] xs:text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 max-w-full break-words [overflow-wrap:anywhere]">
                  <Clock size={13} className="text-amber-400 animate-pulse shrink-0" />
                  <span>{isAr ? 'تم التقديم - قيد المراجعة الإدارية' : 'Applied: Pending Review'}</span>
                </div>
                <p className="text-[11px] text-amber-200/80 break-words [overflow-wrap:anywhere] leading-relaxed">
                  {isAr ? 'الطلب معروض حالياً على مالك السيرفر للمراجعة والاعتماد.' : 'Application is currently queued for Owner review.'}
                </p>
              </div>
            ) : applicationStatus === 'REJECTED' ? (
              <div className="space-y-1.5 w-full min-w-0">
                <div className="inline-flex items-center gap-1.5 px-2.5 xs:px-3 py-1 rounded-xl text-[11px] xs:text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 max-w-full break-words [overflow-wrap:anywhere]">
                  <XCircle size={13} className="text-rose-400 shrink-0" />
                  <span>{isAr ? 'تم التقديم - رُفض الطلب' : 'Applied: Rejected'}</span>
                </div>
                {application?.reviewNote && (
                  <p className="text-[11px] text-rose-300 font-mono italic break-words [overflow-wrap:anywhere] leading-relaxed">
                    "{application.reviewNote}"
                  </p>
                )}
              </div>
            ) : (
              <div className="space-y-2 w-full min-w-0">
                <div className="inline-flex items-center gap-1.5 px-2.5 xs:px-3 py-1 rounded-xl text-[11px] xs:text-xs font-bold bg-white/10 text-stone-300 border border-white/15 max-w-full break-words [overflow-wrap:anywhere]">
                  <Shield size={13} className="text-indigo-400 shrink-0" />
                  <span>{isAr ? 'تعيين إداري مباشر • لم يقدّم طلب' : 'Direct Appointment • Not Applied'}</span>
                </div>
                <p className="text-[11px] text-[#8db8b1] break-words [overflow-wrap:anywhere] leading-relaxed">
                  {isAr 
                    ? 'هذه الرتبة مسندة بتعيين إداري موثق دون الحاجة لطلب إلكتروني.'
                    : 'Assigned via official server administration credentials.'}
                </p>

                {isOwnProfile && staffMember && (
                  <button
                    type="button"
                    disabled={isApplying}
                    onClick={handleApplyClick}
                    className="w-full max-w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-bold text-[#031211] bg-gradient-to-r from-amber-400 via-[#5eead4] to-[#2dd4bf] hover:brightness-110 shadow-md shadow-cyan-500/20 transition-all cursor-pointer disabled:opacity-50 box-border"
                  >
                    <Send size={12} className="shrink-0" />
                    <span className="truncate">{isApplying ? (isAr ? 'جاري الإرسال...' : 'Submitting...') : (isAr ? 'تقديم طلب ترقية رتبة' : 'Apply for Promotion')}</span>
                  </button>
                )}
              </div>
            )}

            {applyMessage && (
              <p className="text-[11px] font-mono text-[#5eead4] mt-2 break-words [overflow-wrap:anywhere]">
                {applyMessage}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Quick Staff Navigation Links */}
      <div className="relative z-10 pt-1 sm:pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2 sm:gap-3 text-xs text-[#8db8b1] w-full min-w-0">
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap min-w-0">
          <Link
            to="/staff-management"
            className="flex items-center gap-1.5 text-stone-300 hover:text-[#5eead4] transition-colors"
          >
            <span>{isAr ? 'دليل الطاقم الإداري' : 'Staff Directory'}</span>
            <ExternalLink size={12} className="shrink-0" />
          </Link>
          <span>•</span>
          <Link
            to="/codex/book-rank-progression"
            className="flex items-center gap-1.5 text-stone-300 hover:text-[#5eead4] transition-colors"
          >
            <span>{isAr ? 'دليل ترقيات الرتب' : 'Rank Progression Rules'}</span>
            <ExternalLink size={12} className="shrink-0" />
          </Link>
        </div>

        <span className="text-[10px] xs:text-[11px] font-mono text-[#5eead4]/80 break-all">
          ID: {profileData.discordId}
        </span>
      </div>
    </div>
  );
};
