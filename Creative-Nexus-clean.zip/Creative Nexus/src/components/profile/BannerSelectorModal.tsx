import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Image as ImageIcon, Check, Sparkles, Link as LinkIcon, RotateCcw, Eye, Shield, UploadCloud, HardDrive, Loader2 } from 'lucide-react';
import { compressImageFile } from '../../utils/imageCompressor';
import { MESOPOTAMIAN_ASSETS } from '../../assets/mesopotamianAssets';

export interface BannerPreset {
  id: string;
  name: string;
  nameAr: string;
  category: 'historical' | 'cyber' | 'cosmic';
  url: string;
  accent: string;
}

export const BANNER_PRESETS: BannerPreset[] = [
  {
    id: 'meso_hero',
    name: 'Mesopotamian Palace & Ziggurat',
    nameAr: 'قصر بابل والزقورة التاريخية',
    category: 'historical',
    url: MESOPOTAMIAN_ASSETS.mesoHeroBg,
    accent: '#f59e0b',
  },
  {
    id: 'meso_lamassu',
    name: 'Lamassu Guardian Relief',
    nameAr: 'نحت الثور المجنح الحارس (لاماسو)',
    category: 'historical',
    url: MESOPOTAMIAN_ASSETS.lamassuRelief,
    accent: '#d97706',
  },
  {
    id: 'meso_frieze',
    name: 'Ancient Mesopotamian Frieze',
    nameAr: 'شريط النقوش والرموز المسمارية',
    category: 'historical',
    url: MESOPOTAMIAN_ASSETS.friezeBanner,
    accent: '#b45309',
  },
  {
    id: 'meso_king',
    name: 'Sovereign King Relief',
    nameAr: 'نقش الملك البابلي المعظم',
    category: 'historical',
    url: MESOPOTAMIAN_ASSETS.kingRelief,
    accent: '#fcd34d',
  },
  {
    id: 'meso_eagle',
    name: 'Winged Solar Eagle',
    nameAr: 'النسر المجنح الملكي',
    category: 'historical',
    url: MESOPOTAMIAN_ASSETS.eagleRelief,
    accent: '#fbbf24',
  },
  {
    id: 'meso_palm',
    name: 'Sacred Palm Sanctuary',
    nameAr: 'ملاذ النخيل المقدس القديم',
    category: 'historical',
    url: MESOPOTAMIAN_ASSETS.palmRelief,
    accent: '#10b981',
  },
  {
    id: 'cyber_emerald',
    name: 'Cyber Nexus Emerald',
    nameAr: 'شبكة مركز الإبداع الزمردية',
    category: 'cyber',
    url: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1600&q=80',
    accent: '#5eead4',
  },
  {
    id: 'sovereign_gold',
    name: 'Sovereign Apex Obsidian & Gold',
    nameAr: 'العرش الملكي والذهب النبيل',
    category: 'cosmic',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1600&q=80',
    accent: '#fbbf24',
  },
  {
    id: 'astral_nebula',
    name: 'Deep Astral Empress Nebula',
    nameAr: 'سديم النجوم الإمبراطوري',
    category: 'cosmic',
    url: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=1600&q=80',
    accent: '#a855f7',
  },
  {
    id: 'aegis_dawn',
    name: 'Aegis Azure Aurora',
    nameAr: 'شفق الفالكيري السماوي',
    category: 'cyber',
    url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1600&q=80',
    accent: '#38bdf8',
  }
];

interface BannerSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentBannerUrl?: string | null;
  userAvatarUrl?: string;
  displayName: string;
  onSaveBanner: (bannerUrl: string | null) => Promise<void>;
  isAr?: boolean;
}

export const BannerSelectorModal: React.FC<BannerSelectorModalProps> = ({
  isOpen,
  onClose,
  currentBannerUrl,
  userAvatarUrl,
  displayName,
  onSaveBanner,
  isAr = false,
}) => {
  const [selectedUrl, setSelectedUrl] = useState<string | null>(currentBannerUrl || null);
  const [customInputUrl, setCustomInputUrl] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);
  const [previewTab, setPreviewTab] = useState<'presets' | 'device' | 'custom'>('presets');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMsg(null);
    setIsProcessingFile(true);
    try {
      const processed = await compressImageFile(file, 1600, 0.85);
      setSelectedUrl(processed.dataUrl);
      setPreviewTab('device');
    } catch (err: any) {
      setErrorMsg(isAr ? 'فشل معالجة الصورة المختارة من جهازك: ' + (err.message || '') : 'Failed to process image from device: ' + (err.message || ''));
    } finally {
      setIsProcessingFile(false);
      if (e.target) e.target.value = '';
    }
  };

  const handleApplyCustomUrl = () => {
    setErrorMsg(null);
    const clean = customInputUrl.trim();
    if (!clean) {
      setErrorMsg(isAr ? 'يرجى إدخال رابط صورة صالح' : 'Please provide a valid image URL');
      return;
    }
    setSelectedUrl(clean);
  };

  const handleSave = async () => {
    setIsSaving(true);
    setErrorMsg(null);
    try {
      await onSaveBanner(selectedUrl);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || (isAr ? 'فشل حفظ غلاف الملف الشخصي' : 'Failed to save profile banner'));
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center p-2.5 xs:p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto box-border"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-[calc(100vw-1.25rem)] sm:max-w-2xl bg-[#031518]/95 border border-[rgba(158,255,230,0.25)] rounded-2xl sm:rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.9)] overflow-hidden my-auto max-h-[92dvh] flex flex-col text-[#eafffa] box-border min-w-0"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-3.5 xs:px-4 sm:px-5 py-3.5 sm:py-4 border-b border-white/10 bg-white/[0.02] shrink-0 min-w-0">
            <div className="flex items-center gap-2 xs:gap-2.5 min-w-0 flex-1">
              <div className="p-1.5 xs:p-2 rounded-xl bg-amber-500/15 text-amber-300 border border-amber-500/30 shrink-0">
                <ImageIcon size={16} className="xs:w-[18px] xs:h-[18px]" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-sm xs:text-base sm:text-lg font-bold text-white font-display truncate">
                  {isAr ? 'اختيار غلاف الملف الشخصي' : 'Choose Profile Banner'}
                </h3>
                <p className="text-[11px] xs:text-xs text-[#8db8b1] break-words [overflow-wrap:anywhere] mt-0.5">
                  {isAr ? 'حدد غلافاً تاريخياً أو مستقبلياً أو ضع رابط صورتك المفضلة' : 'Select a curated community banner or provide a custom image URL'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              aria-label="Close"
              className="p-1.5 xs:p-2 rounded-xl text-[#8db8b1] hover:text-white bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 transition-all cursor-pointer shrink-0 ms-2"
            >
              <X size={16} />
            </button>
          </div>

          {/* Live Preview Window */}
          <div className="p-4 sm:p-5 border-b border-white/10 bg-black/40 shrink-0">
            <div className="flex items-center justify-between text-xs font-mono text-[#8db8b1] mb-2">
              <span className="flex items-center gap-1.5 text-[#5eead4] font-bold">
                <Eye size={13} />
                <span>{isAr ? 'معاينة الغلاف الحي' : 'Live Banner Preview'}</span>
              </span>
              {selectedUrl && (
                <button
                  type="button"
                  onClick={() => setSelectedUrl(null)}
                  className="flex items-center gap-1 text-[11px] text-amber-300 hover:text-amber-200 cursor-pointer"
                >
                  <RotateCcw size={11} />
                  <span>{isAr ? 'إعادة ضبط للافتراضي' : 'Reset to Default'}</span>
                </button>
              )}
            </div>

            <div className="relative h-32 sm:h-36 rounded-2xl overflow-hidden border border-white/15 shadow-inner bg-gradient-to-r from-[#031d20] via-[#052b27] to-[#021415]">
              {selectedUrl ? (
                <img
                  src={selectedUrl}
                  alt="Banner Preview"
                  className="w-full h-full object-cover"
                  onError={() => setErrorMsg(isAr ? 'تعذر تحميل معاينة الصورة من هذا الرابط' : 'Failed to load preview for this image URL')}
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-center p-4 bg-gradient-to-r from-cyan-950/80 via-teal-900/60 to-black/80">
                  <Sparkles size={24} className="text-[#5eead4]/60 mb-1 animate-pulse" />
                  <span className="text-xs font-mono text-[#5eead4]">
                    {isAr ? 'الغلاف الافتراضي للملاذ' : 'Default Sanctuary Atmosphere'}
                  </span>
                </div>
              )}
              {/* Dark gradient overlay at bottom for readability */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent pointer-events-none" />

              {/* Avatar overlay simulator */}
              <div className="absolute bottom-3 start-4 flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl border-2 border-[#5eead4] shadow-lg overflow-hidden bg-black/80">
                  <img
                    src={userAvatarUrl || 'https://cdn.discordapp.com/embed/avatars/0.png'}
                    alt={displayName}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <p className="text-sm font-bold text-white drop-shadow-md">{displayName}</p>
                  <span className="text-[10px] font-mono text-[#5eead4] bg-black/60 px-1.5 py-0.5 rounded border border-[#5eead4]/30 backdrop-blur-xs">
                    {isAr ? 'هوية الحساب' : 'Identity'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex border-b border-white/10 px-5 pt-3 bg-white/[0.01] gap-2 shrink-0 overflow-x-auto no-scrollbar">
            <button
              type="button"
              onClick={() => setPreviewTab('presets')}
              className={`px-3.5 py-2 text-xs font-bold rounded-t-xl transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                previewTab === 'presets'
                  ? 'bg-white/10 text-[#5eead4] border-t-2 border-[#5eead4]'
                  : 'text-[#8db8b1] hover:text-white'
              }`}
            >
              <Sparkles size={13} />
              <span>{isAr ? 'أغلفة الملاذ (10)' : 'Curated Presets'}</span>
            </button>

            <button
              type="button"
              onClick={() => setPreviewTab('device')}
              className={`px-3.5 py-2 text-xs font-bold rounded-t-xl transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                previewTab === 'device'
                  ? 'bg-white/10 text-amber-300 border-t-2 border-amber-400'
                  : 'text-[#8db8b1] hover:text-white'
              }`}
            >
              <HardDrive size={13} className="text-amber-400" />
              <span>{isAr ? 'من جهازك (رفع مباشر)' : 'From Device (Upload)'}</span>
            </button>

            <button
              type="button"
              onClick={() => setPreviewTab('custom')}
              className={`px-3.5 py-2 text-xs font-bold rounded-t-xl transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                previewTab === 'custom'
                  ? 'bg-white/10 text-[#5eead4] border-t-2 border-[#5eead4]'
                  : 'text-[#8db8b1] hover:text-white'
              }`}
            >
              <LinkIcon size={13} />
              <span>{isAr ? 'رابط صورة خارجي' : 'Custom Image URL'}</span>
            </button>
          </div>

          {/* Hidden File Input for Device Upload */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/png,image/jpeg,image/webp,image/gif"
            className="hidden"
          />

          {/* Tab Content */}
          <div className="flex-1 overflow-y-auto custom-scrollbar p-5 space-y-4">
            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                <span>⚠️ {errorMsg}</span>
              </div>
            )}

            {previewTab === 'device' ? (
              <div className="space-y-4">
                <div className="p-5 rounded-2xl bg-black/60 border border-amber-500/30 text-center space-y-4 shadow-xl">
                  <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-center text-amber-300 shadow-md">
                    {isProcessingFile ? (
                      <Loader2 size={26} className="animate-spin text-amber-400" />
                    ) : (
                      <UploadCloud size={26} className="text-amber-400" />
                    )}
                  </div>

                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-white font-display">
                      {isAr ? 'اختيار غلاف مباشرة من جهازك' : 'Choose Banner Directly from Device'}
                    </h4>
                    <p className="text-xs text-[#8db8b1] max-w-md mx-auto leading-relaxed">
                      {isAr
                        ? 'اختر صورة من هاتفك أو جهاز الكمبيوتر (PNG, JPG, WebP) - سيتم معالجتها وضغطها فورياً لتكون خفيفة وسريعة التحميل.'
                        : 'Select any high-resolution image from your phone or PC. It will be compressed client-side for zero latency and persistent display.'}
                    </p>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-1">
                    <button
                      type="button"
                      disabled={isProcessingFile}
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full sm:w-auto px-6 py-3 rounded-xl text-xs font-bold text-[#031211] bg-gradient-to-r from-amber-400 via-amber-300 to-[#5eead4] hover:brightness-110 shadow-lg shadow-amber-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95 disabled:opacity-50"
                    >
                      <HardDrive size={15} className="shrink-0" />
                      <span>{isProcessingFile ? (isAr ? 'جاري معالجة الصورة...' : 'Processing...') : (isAr ? 'تصفح واختيار صورة من الجهاز' : 'Browse Image From Device')}</span>
                    </button>

                    {selectedUrl && (
                      <button
                        type="button"
                        onClick={() => setSelectedUrl(null)}
                        className="px-4 py-3 rounded-xl text-xs font-medium text-stone-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-colors cursor-pointer"
                      >
                        {isAr ? 'إلغاء التحديد' : 'Clear'}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ) : previewTab === 'presets' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {BANNER_PRESETS.map((preset) => {
                  const isSelected = selectedUrl === preset.url;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => {
                        setSelectedUrl(preset.url);
                        setErrorMsg(null);
                      }}
                      className={`group relative text-start rounded-2xl overflow-hidden border p-3 flex items-center gap-3 transition-all cursor-pointer ${
                        isSelected
                          ? 'border-[#5eead4] bg-[#5eead4]/10 shadow-[0_0_20px_rgba(94,234,212,0.25)]'
                          : 'border-white/10 bg-black/40 hover:border-white/25 hover:bg-white/[0.04]'
                      }`}
                    >
                      {/* Mini Thumbnail */}
                      <div className="relative w-20 h-14 rounded-xl overflow-hidden shrink-0 border border-white/10">
                        <img
                          src={preset.url}
                          alt={preset.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        {isSelected && (
                          <div className="absolute inset-0 bg-[#5eead4]/30 flex items-center justify-center">
                            <div className="w-6 h-6 rounded-full bg-[#5eead4] text-[#031211] flex items-center justify-center shadow-md">
                              <Check size={14} className="stroke-[3]" />
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <p className={`text-xs font-bold truncate ${isSelected ? 'text-[#5eead4]' : 'text-white'}`}>
                          {isAr ? preset.nameAr : preset.name}
                        </p>
                        <span 
                          className="inline-block text-[10px] font-mono uppercase px-1.5 py-0.5 rounded-md mt-1 border border-white/10"
                          style={{ color: preset.accent }}
                        >
                          {preset.category}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-black/50 border border-white/10 space-y-3">
                  <label className="block text-xs font-mono font-bold text-white uppercase tracking-wider">
                    {isAr ? 'رابط الصورة المباشر (Direct Image URL)' : 'Direct Image URL'}
                  </label>
                  <p className="text-xs text-[#8db8b1]">
                    {isAr
                      ? 'يمكنك وضع رابط مباشر لصورة من Discord أو Imgur أو أي موقع بصيغة JPG أو PNG أو WebP.'
                      : 'Paste any high-resolution image URL from Discord CDN, Imgur, or direct web link.'}
                  </p>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      value={customInputUrl}
                      onChange={(e) => setCustomInputUrl(e.target.value)}
                      placeholder="https://images.unsplash.com/..."
                      className="flex-1 px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 text-xs text-white placeholder-stone-500 focus:outline-hidden focus:border-[#5eead4]"
                    />
                    <button
                      type="button"
                      onClick={handleApplyCustomUrl}
                      className="px-4 py-2.5 rounded-xl bg-[#5eead4]/20 hover:bg-[#5eead4]/30 text-[#5eead4] border border-[#5eead4]/40 font-bold text-xs cursor-pointer transition-all shrink-0"
                    >
                      {isAr ? 'تطبيق للمعاينة' : 'Preview'}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer Action Bar */}
          <div className="px-5 py-3.5 bg-black/60 border-t border-white/10 flex items-center justify-between gap-3 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-[#8db8b1] hover:text-white bg-white/[0.04] hover:bg-white/[0.08] transition-all cursor-pointer"
            >
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>

            <button
              type="button"
              disabled={isSaving}
              onClick={handleSave}
              className="px-6 py-2.5 rounded-xl text-xs font-bold text-[#031211] bg-gradient-to-r from-amber-400 via-[#5eead4] to-[#2dd4bf] hover:brightness-110 shadow-lg shadow-cyan-500/25 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Check size={14} className="stroke-[3]" />
              <span>{isSaving ? (isAr ? 'جاري الحفظ...' : 'Saving...') : (isAr ? 'حفظ الغلاف' : 'Save Banner')}</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
