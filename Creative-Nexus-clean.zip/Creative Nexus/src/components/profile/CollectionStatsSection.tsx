import React from 'react';
import { CollectionStatistics } from '../../types/progression';
import { RARITY_THEMES } from '../cards/CollectibleCard';
import { BarChart3, Package, Coins, Trophy, Layers, Copy, Sparkles, CheckCircle2 } from 'lucide-react';

interface CollectionStatsSectionProps {
  stats: CollectionStatistics;
  isAr?: boolean;
}

export const CollectionStatsSection: React.FC<CollectionStatsSectionProps> = ({
  stats,
  isAr = false,
}) => {
  const rarities = [
    { key: 'LEGENDARY', label: 'LEGENDARY', labelAr: 'أسطوري', count: stats.legendaryCount, color: RARITY_THEMES.LEGENDARY.accent, bg: 'bg-amber-500/10', border: 'border-amber-500/30' },
    { key: 'EPIC', label: 'EPIC', labelAr: 'ملحمي', count: stats.epicCount, color: RARITY_THEMES.EPIC.accent, bg: 'bg-purple-500/10', border: 'border-purple-500/30' },
    { key: 'RARE', label: 'RARE', labelAr: 'نادر', count: stats.rareCount, color: RARITY_THEMES.RARE.accent, bg: 'bg-cyan-500/10', border: 'border-cyan-500/30' },
    { key: 'UNCOMMON', label: 'UNCOMMON', labelAr: 'غير شائع', count: stats.uncommonCount, color: RARITY_THEMES.UNCOMMON.accent, bg: 'bg-emerald-500/10', border: 'border-emerald-500/30' },
    { key: 'COMMON', label: 'COMMON', labelAr: 'شائع', count: stats.commonCount, color: RARITY_THEMES.COMMON.accent, bg: 'bg-zinc-500/10', border: 'border-zinc-500/30' },
  ];

  const primaryStats = [
    {
      id: 'total_cards',
      label: isAr ? 'إجمالي البطاقات' : 'TOTAL CARDS',
      value: stats.totalCards.toLocaleString(),
      subtext: isAr ? 'شامل النسخ المكررة' : 'All acquired copies',
      icon: Layers,
      color: 'text-[#5eead4]',
      bg: 'bg-cyan-500/10',
      border: 'border-cyan-500/30'
    },
    {
      id: 'unique_cards',
      label: isAr ? 'البطاقات الفريدة' : 'UNIQUE CARDS',
      value: stats.uniqueCards.toLocaleString(),
      subtext: isAr ? 'بطاقات متميزة بدون تكرار' : 'Distinct card catalog IDs',
      icon: Copy,
      color: 'text-amber-300',
      bg: 'bg-amber-500/10',
      border: 'border-amber-500/30'
    },
    {
      id: 'packs_opened',
      label: isAr ? 'الحزم المفتوحة' : 'PACKS OPENED',
      value: stats.packsOpened.toLocaleString(),
      subtext: isAr ? 'حزم مختومة تم فكها' : 'Sealed booster unboxings',
      icon: Package,
      color: 'text-purple-300',
      bg: 'bg-purple-500/10',
      border: 'border-purple-500/30'
    },
    {
      id: 'sets_completed',
      label: isAr ? 'المجموعات المكتملة' : 'SETS COMPLETED',
      value: stats.setsCompleted.toLocaleString(),
      subtext: isAr ? 'مجموعات بطاقات منتهية' : 'Future card sets mastery',
      icon: CheckCircle2,
      color: 'text-emerald-300',
      bg: 'bg-emerald-500/10',
      border: 'border-emerald-500/30'
    },
    {
      id: 'coins_balance',
      label: isAr ? 'رصيد العملات' : 'COINS BALANCE',
      value: stats.coinsEarned.toLocaleString(),
      subtext: isAr ? 'عملات الخزينة المتاحة' : 'Vault coin reserve',
      icon: Coins,
      color: 'text-amber-400',
      bg: 'bg-amber-500/10',
      border: 'border-amber-500/30'
    },
    {
      id: 'account_level',
      label: isAr ? 'مستوى الحساب' : 'ACCOUNT LEVEL',
      value: `LV ${stats.accountLevel}`,
      subtext: isAr ? 'رتبة التقدم العام' : 'Progression matrix rank',
      icon: Trophy,
      color: 'text-[#eafffa]',
      bg: 'bg-teal-500/10',
      border: 'border-teal-500/30'
    }
  ];

  return (
    <div className="space-y-4 sm:space-y-6 w-full max-w-full min-w-0">
      {/* 1. Primary Collection Metrics */}
      <div className="rounded-2xl sm:rounded-3xl bg-gradient-to-b from-[#061c1a]/90 via-[#031312]/95 to-[#020b0a]/98 border border-[rgba(158,255,230,0.16)] p-3.5 xs:p-4 sm:p-7 shadow-xl w-full max-w-full min-w-0 box-border overflow-hidden">
        <div className="flex items-center gap-2 xs:gap-2.5 mb-4 sm:mb-6 min-w-0">
          <div className="p-1.5 xs:p-2 rounded-xl bg-teal-500/15 text-[#5eead4] border border-teal-500/30 shrink-0">
            <BarChart3 size={16} className="xs:w-[18px] xs:h-[18px]" />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-base sm:text-xl font-display font-bold text-white tracking-wide truncate">
              {isAr ? 'إحصائيات المقتنيات' : 'COLLECTION STATISTICS'}
            </h2>
            <p className="text-[11px] xs:text-xs text-[#8db8b1] break-words [overflow-wrap:anywhere] mt-0.5">
              {isAr ? 'بيانات حية وموثقة من قاعدة بيانات بطاقاتك' : 'Authoritative database records of your inventory and milestones'}
            </p>
          </div>
        </div>

        {/* Primary Stat Grid */}
        <div className="grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 xs:gap-3 sm:gap-4 w-full min-w-0">
          {primaryStats.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                className={`p-3 xs:p-3.5 sm:p-4 rounded-2xl bg-black/40 border ${item.border} flex flex-col justify-between space-y-2 backdrop-blur-sm transition-all hover:bg-black/60 min-w-0`}
              >
                <div className="flex items-center justify-between gap-1 min-w-0">
                  <span className="text-[10px] sm:text-[11px] font-mono font-bold uppercase tracking-wider text-[#8db8b1] truncate">
                    {item.label}
                  </span>
                  <div className={`p-1.5 rounded-lg ${item.bg} ${item.color} shrink-0`}>
                    <Icon size={14} />
                  </div>
                </div>

                <div className="min-w-0">
                  <p className={`text-lg xs:text-xl sm:text-2xl font-mono font-black ${item.color} truncate`}>
                    {item.value}
                  </p>
                  <p className="text-[10px] text-[#8db8b1]/70 truncate mt-0.5">
                    {item.subtext}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. Dynamic Rarity Breakdown */}
      <div className="rounded-2xl sm:rounded-3xl bg-gradient-to-b from-[#061c1a]/90 via-[#031312]/95 to-[#020b0a]/98 border border-[rgba(158,255,230,0.16)] p-3.5 xs:p-4 sm:p-7 shadow-xl w-full max-w-full min-w-0 box-border overflow-hidden">
        <div className="flex items-center gap-2 xs:gap-2.5 mb-4 sm:mb-6 min-w-0">
          <div className="p-1.5 xs:p-2 rounded-xl bg-amber-500/15 text-amber-300 border border-amber-500/30 shrink-0">
            <Sparkles size={16} className="xs:w-[18px] xs:h-[18px]" />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-base sm:text-xl font-display font-bold text-white tracking-wide truncate">
              {isAr ? 'توزيع الندرة' : 'RARITY STATISTICS'}
            </h2>
            <p className="text-[11px] xs:text-xs text-[#8db8b1] break-words [overflow-wrap:anywhere] mt-0.5">
              {isAr ? 'تعداد البطاقات المملوكة مصنفة حسب درجات الندرة' : 'Dynamic breakdown of card copies owned across all rarity tiers'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5 xs:gap-3 sm:gap-4 w-full min-w-0">
          {rarities.map((r) => {
            const pct = stats.totalCards > 0 ? Math.round((r.count / stats.totalCards) * 100) : 0;
            return (
              <div
                key={r.key}
                className={`p-3 xs:p-3.5 sm:p-4 rounded-2xl bg-black/45 border ${r.border} space-y-2 relative overflow-hidden min-w-0`}
              >
                <div className="flex items-center justify-between gap-1 min-w-0">
                  <span
                    className="text-[11px] xs:text-xs font-mono font-bold tracking-wider uppercase truncate"
                    style={{ color: r.color }}
                  >
                    {isAr ? r.labelAr : r.label}
                  </span>
                  <span className="text-[10px] font-mono text-[#8db8b1]/80 shrink-0">
                    {pct}%
                  </span>
                </div>

                <div className="flex items-baseline gap-1.5 min-w-0">
                  <span className="text-xl xs:text-2xl font-mono font-black text-white truncate">
                    {r.count.toLocaleString()}
                  </span>
                  <span className="text-[11px] font-mono text-[#8db8b1] shrink-0">
                    {isAr ? 'بطاقة' : 'cards'}
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full max-w-full h-1.5 rounded-full bg-black/60 overflow-hidden box-border">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${pct}%`,
                      maxWidth: '100%',
                      background: r.color
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
