import React, { useState, useMemo, useRef } from 'react';
import { PlayerProfileData, PlayerTitle, PlayerBadge } from '../../types/progression';
import { CollectibleCardData, CardRarity } from '../../types/cards';
import { RARITY_THEMES } from '../cards/CollectibleCard';
import { 
  X, Star, Layers, Award, Sparkles, Check, ArrowUp, ArrowDown, 
  Trash2, Plus, Search, Filter, AlertCircle, Save, Loader2, Image as ImageIcon, Link as LinkIcon, RotateCcw,
  HardDrive, UploadCloud
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { BANNER_PRESETS } from './BannerSelectorModal';
import { compressImageFile } from '../../utils/imageCompressor';

interface ProfileCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  profileData: PlayerProfileData;
  catalog: CollectibleCardData[];
  onSave: (payload: {
    favoriteCardId?: string | null;
    showcaseCardIds?: string[];
    selectedTitleId?: string | null;
    featuredBadgeIds?: string[];
    bannerUrl?: string | null;
  }) => Promise<any>;
  isAr?: boolean;
}

type CustomizerTab = 'banner' | 'favorite' | 'showcase' | 'title' | 'badges';

export const ProfileCustomizerModal: React.FC<ProfileCustomizerModalProps> = ({
  isOpen,
  onClose,
  profileData,
  catalog,
  onSave,
  isAr = false,
}) => {
  const [activeTab, setActiveTab] = useState<CustomizerTab>('banner');

  // Form states initialized from current profile
  const [bannerUrl, setBannerUrl] = useState<string | null>(profileData.bannerUrl || null);
  const [customBannerInput, setCustomBannerInput] = useState<string>('');
  const [favoriteCardId, setFavoriteCardId] = useState<string | null>(profileData.favoriteCardId || null);
  const [showcaseCardIds, setShowcaseCardIds] = useState<string[]>(profileData.showcaseCardIds || []);
  const [selectedTitleId, setSelectedTitleId] = useState<string | null>(profileData.selectedTitleId || null);
  const [featuredBadgeIds, setFeaturedBadgeIds] = useState<string[]>(profileData.featuredBadgeIds || []);
  const [isProcessingBannerFile, setIsProcessingBannerFile] = useState(false);
  const bannerFileInputRef = useRef<HTMLInputElement>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [rarityFilter, setRarityFilter] = useState<string>('ALL');
  const [isSaving, setIsSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleBannerFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMsg(null);
    setIsProcessingBannerFile(true);
    try {
      const processed = await compressImageFile(file, 1600, 0.85);
      setBannerUrl(processed.dataUrl);
    } catch (err: any) {
      setErrorMsg(isAr ? 'فشل معالجة الصورة المختارة من جهازك' : 'Failed to process image from device');
    } finally {
      setIsProcessingBannerFile(false);
      if (e.target) e.target.value = '';
    }
  };

  // Compute all owned card objects
  const ownedCards = useMemo(() => {
    return catalog.filter(c => {
      // In profileData, stats and owned cards can be cross-referenced
      return true; // We filter against owned IDs below
    });
  }, [catalog]);

  // Card lookup map
  const cardLookup = useMemo(() => {
    return new Map<string, CollectibleCardData>(catalog.map(c => [c.id, c]));
  }, [catalog]);

  // Unlocked title set
  const unlockedTitleIds = useMemo(() => {
    return new Set(profileData.unlockedTitles.map(t => t.id));
  }, [profileData.unlockedTitles]);

  // Unlocked badge set
  const unlockedBadgeIds = useMemo(() => {
    return new Set(profileData.unlockedBadges.map(b => b.id));
  }, [profileData.unlockedBadges]);

  if (!isOpen) return null;

  // Filtered cards for search in Favorite and Showcase pickers
  const filteredCards = catalog.filter((card) => {
    if (rarityFilter !== 'ALL' && card.rarity !== rarityFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = card.name.toLowerCase().includes(q);
      const matchTitle = card.title?.toLowerCase().includes(q);
      return matchName || matchTitle;
    }
    return true;
  });

  const handleToggleShowcaseCard = (cardId: string) => {
    setErrorMsg(null);
    if (showcaseCardIds.includes(cardId)) {
      setShowcaseCardIds(prev => prev.filter(id => id !== cardId));
    } else {
      if (showcaseCardIds.length >= 5) {
        setErrorMsg(isAr ? 'يمكنك تحديد 5 بطاقات كحد أقصى للمعرض.' : 'You can showcase at most 5 cards.');
        return;
      }
      setShowcaseCardIds(prev => [...prev, cardId]);
    }
  };

  const handleMoveShowcaseCard = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= showcaseCardIds.length) return;
    const reordered = [...showcaseCardIds];
    const temp = reordered[index];
    reordered[index] = reordered[targetIndex];
    reordered[targetIndex] = temp;
    setShowcaseCardIds(reordered);
  };

  const handleToggleBadge = (badgeId: string) => {
    setErrorMsg(null);
    if (featuredBadgeIds.includes(badgeId)) {
      setFeaturedBadgeIds(prev => prev.filter(id => id !== badgeId));
    } else {
      if (featuredBadgeIds.length >= 4) {
        setErrorMsg(isAr ? 'يمكنك تمييز 4 أوسمة كحد أقصى.' : 'You can feature at most 4 badges.');
        return;
      }
      setFeaturedBadgeIds(prev => [...prev, badgeId]);
    }
  };

  const handleSaveAll = async () => {
    setIsSaving(true);
    setErrorMsg(null);
    try {
      await onSave({
        favoriteCardId,
        showcaseCardIds,
        selectedTitleId,
        featuredBadgeIds,
        bannerUrl,
      });
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to save profile customization');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center p-2.5 xs:p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto box-border"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2 }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-[calc(100vw-1.25rem)] sm:max-w-4xl bg-[#031518]/98 border border-[rgba(158,255,230,0.22)] rounded-2xl sm:rounded-3xl shadow-2xl shadow-black/90 overflow-hidden my-auto max-h-[92dvh] flex flex-col box-border min-w-0"
        >
          {/* Top Header */}
          <div className="flex items-center justify-between p-3.5 xs:p-4 sm:p-6 border-b border-[rgba(158,255,230,0.15)] bg-gradient-to-r from-teal-950/60 via-[#031518] to-cyan-950/40 shrink-0 min-w-0">
            <div className="flex items-center gap-2 xs:gap-2.5 min-w-0 flex-1">
              <div className="p-1.5 xs:p-2 rounded-xl bg-amber-500/15 text-amber-300 border border-amber-500/30 shrink-0">
                <Sparkles size={16} className="xs:w-[18px] xs:h-[18px]" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-base sm:text-xl font-display font-bold text-white tracking-wide truncate">
                  {isAr ? 'تخصيص ملف اللاعب' : 'Customize Player Profile'}
                </h3>
                <p className="text-[11px] xs:text-xs text-[#8db8b1] break-words [overflow-wrap:anywhere] mt-0.5">
                  {isAr ? 'تعديل غلاف الملف، البطاقة المفضلة، المعرض، اللقب الملكي والأوسمة' : 'Configure banner, favorite relic, showcase slots, title and featured badges'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 xs:p-2 rounded-xl text-[#8db8b1] hover:text-white bg-black/40 hover:bg-black/60 border border-white/10 transition-colors cursor-pointer shrink-0 ms-2"
            >
              <X size={16} />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-1.5 px-3 xs:px-4 sm:px-6 pt-3 border-b border-white/5 bg-black/40 overflow-x-auto no-scrollbar shrink-0 touch-pan-x w-full min-w-0">
            {[
              { id: 'banner', label: isAr ? 'غلاف الملف' : 'Banner', icon: ImageIcon },
              { id: 'favorite', label: isAr ? 'البطاقة المفضلة' : 'Favorite Card', icon: Star },
              { id: 'showcase', label: isAr ? 'المعرض (3-5)' : 'Showcase (3-5)', icon: Layers },
              { id: 'title', label: isAr ? 'اللقب الملكي' : 'Title', icon: Award },
              { id: 'badges', label: isAr ? 'الأوسمة البارزة' : 'Featured Badges', icon: Sparkles },
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id as CustomizerTab);
                    setErrorMsg(null);
                  }}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'bg-[#031518] text-[#5eead4] border-t-2 border-[#5eead4] shadow-sm'
                      : 'text-[#8db8b1] hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon size={14} className={isActive ? 'text-[#5eead4]' : 'opacity-70'} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Error Feedback */}
          {errorMsg && (
            <div className="mx-6 mt-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center gap-2 text-xs text-rose-300 shrink-0">
              <AlertCircle size={15} className="shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Tab Content Body */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 custom-scrollbar space-y-6">
            {/* 0. BANNER TAB */}
            {activeTab === 'banner' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div>
                    <h4 className="text-sm font-bold text-white">
                      {isAr ? 'غلاف الملف الشخصي المخصص' : 'Custom Profile Banner'}
                    </h4>
                    <p className="text-xs text-[#8db8b1]">
                      {isAr ? 'اختر من الأغلفة الجاهزة أو ضع رابط صورة من اختيارك.' : 'Select a ready-made community banner or paste any image URL.'}
                    </p>
                  </div>

                  {bannerUrl && (
                    <button
                      type="button"
                      onClick={() => setBannerUrl(null)}
                      className="text-xs font-mono text-amber-300 hover:text-amber-200 flex items-center gap-1 cursor-pointer"
                    >
                      <RotateCcw size={12} />
                      <span>{isAr ? 'استعادة الافتراضي' : 'Reset Default'}</span>
                    </button>
                  )}
                </div>

                {/* Banner Live Preview */}
                <div className="relative h-32 sm:h-40 rounded-2xl overflow-hidden border border-white/15 bg-gradient-to-r from-[#031d20] to-[#021315]">
                  {bannerUrl ? (
                    <img src={bannerUrl} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-xs font-mono text-[#5eead4]">
                      {isAr ? 'الغلاف الافتراضي للملاذ' : 'Default Sanctuary Atmosphere'}
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent pointer-events-none" />
                </div>

                {/* Hidden Device File Input */}
                <input
                  type="file"
                  ref={bannerFileInputRef}
                  onChange={handleBannerFileChange}
                  accept="image/png,image/jpeg,image/webp,image/gif"
                  className="hidden"
                />

                {/* Device Upload Bar */}
                <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md">
                  <div className="flex items-center gap-2.5 min-w-0 flex-1">
                    <div className="p-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 shrink-0">
                      <HardDrive size={16} />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-white font-display">
                        {isAr ? 'اختيار غلاف مباشرة من جهازك' : 'Upload Banner from Device'}
                      </p>
                      <p className="text-[10px] text-[#8db8b1]">
                        {isAr ? 'رفع ملف صورة من هاتفك أو حاسوبك (PNG, JPG, WebP)' : 'Select image file directly from your local phone or PC'}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={isProcessingBannerFile}
                    onClick={() => bannerFileInputRef.current?.click()}
                    className="w-full sm:w-auto px-4 py-2 rounded-xl text-xs font-bold text-[#031211] bg-gradient-to-r from-amber-400 to-[#5eead4] hover:brightness-110 shadow-md shadow-amber-500/20 transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 disabled:opacity-50 shrink-0"
                  >
                    {isProcessingBannerFile ? (
                      <Loader2 size={13} className="animate-spin" />
                    ) : (
                      <UploadCloud size={13} />
                    )}
                    <span>{isProcessingBannerFile ? (isAr ? 'جاري المعالجة...' : 'Processing...') : (isAr ? 'رفع من جهازك' : 'Upload from Device')}</span>
                  </button>
                </div>

                {/* Custom URL Input */}
                <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-2">
                  <label className="text-xs font-mono font-bold text-stone-300 uppercase">
                    {isAr ? 'رابط صورة مخصص' : 'Custom Image URL'}
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      value={customBannerInput}
                      onChange={(e) => setCustomBannerInput(e.target.value)}
                      placeholder="https://..."
                      className="flex-1 px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-xs text-white placeholder-stone-500 focus:outline-hidden focus:border-[#5eead4]"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (customBannerInput.trim()) {
                          setBannerUrl(customBannerInput.trim());
                        }
                      }}
                      className="px-3.5 py-2 rounded-xl bg-[#5eead4]/20 hover:bg-[#5eead4]/30 text-[#5eead4] border border-[#5eead4]/40 font-bold text-xs cursor-pointer"
                    >
                      {isAr ? 'تطبيق' : 'Apply'}
                    </button>
                  </div>
                </div>

                {/* Presets Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
                  {BANNER_PRESETS.map((preset) => {
                    const isSelected = bannerUrl === preset.url;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => setBannerUrl(preset.url)}
                        className={`rounded-xl border p-2 text-start transition-all cursor-pointer ${
                          isSelected
                            ? 'border-[#5eead4] bg-[#5eead4]/15 shadow-md shadow-cyan-500/20'
                            : 'border-white/10 bg-black/40 hover:border-white/20'
                        }`}
                      >
                        <div className="relative h-16 rounded-lg overflow-hidden mb-1.5 border border-white/10">
                          <img src={preset.url} alt={preset.name} className="w-full h-full object-cover" />
                          {isSelected && (
                            <div className="absolute inset-0 bg-[#5eead4]/30 flex items-center justify-center">
                              <Check size={16} className="text-[#031211] bg-[#5eead4] rounded-full p-0.5" />
                            </div>
                          )}
                        </div>
                        <p className={`text-[11px] font-bold truncate ${isSelected ? 'text-[#5eead4]' : 'text-white'}`}>
                          {isAr ? preset.nameAr : preset.name}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 1. FAVORITE CARD TAB */}
            {activeTab === 'favorite' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div>
                    <h4 className="text-sm font-bold text-white">
                      {isAr ? 'اختر بطاقتك المفضلة' : 'Select Your Favorite Card'}
                    </h4>
                    <p className="text-xs text-[#8db8b1]">
                      {isAr ? 'ستظهر هذه البطاقة بشكل بارز أعلى ملفك الشخصي.' : 'This card will be featured prominently at the head of your profile.'}
                    </p>
                  </div>

                  {favoriteCardId && (
                    <button
                      onClick={() => setFavoriteCardId(null)}
                      className="px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-400 bg-rose-500/10 border border-rose-500/30 hover:bg-rose-500/20 transition-all cursor-pointer"
                    >
                      {isAr ? 'إلغاء التفضيل' : 'Clear Favorite Card'}
                    </button>
                  )}
                </div>

                {/* Filter and Search controls */}
                <div className="flex flex-col sm:flex-row gap-2.5">
                  <div className="relative flex-1">
                    <Search size={14} className="absolute start-3 top-1/2 -translate-y-1/2 text-[#8db8b1]" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder={isAr ? 'بحث عن بطاقة بالاسم...' : 'Search owned cards...'}
                      className="w-full ps-9 pe-3 py-2 rounded-xl text-xs bg-black/40 border border-white/10 text-white placeholder-[#8db8b1]/60 focus:border-[#5eead4] focus:outline-none"
                    />
                  </div>

                  <select
                    value={rarityFilter}
                    onChange={(e) => setRarityFilter(e.target.value)}
                    className="px-3 py-2 rounded-xl text-xs bg-black/40 border border-white/10 text-white focus:border-[#5eead4] focus:outline-none"
                  >
                    <option value="ALL">{isAr ? 'كافة الندرات' : 'All Rarities'}</option>
                    <option value="LEGENDARY">LEGENDARY</option>
                    <option value="EPIC">EPIC</option>
                    <option value="RARE">RARE</option>
                    <option value="UNCOMMON">UNCOMMON</option>
                    <option value="COMMON">COMMON</option>
                  </select>
                </div>

                {/* Card Selection Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 max-h-96 overflow-y-auto custom-scrollbar p-1">
                  {filteredCards.map((card) => {
                    const isSelected = favoriteCardId === card.id;
                    const theme = RARITY_THEMES[card.rarity];
                    return (
                      <div
                        key={card.id}
                        onClick={() => setFavoriteCardId(card.id)}
                        className={`p-2 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between relative overflow-hidden group ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-400 ring-2 ring-amber-400/50 shadow-xl'
                            : 'bg-black/40 hover:bg-black/60 border-white/10'
                        }`}
                      >
                        {isSelected && (
                          <div className="absolute top-2 end-2 z-10 w-6 h-6 rounded-full bg-amber-400 text-black flex items-center justify-center font-bold shadow-md">
                            <Check size={14} />
                          </div>
                        )}

                        <div className="w-full aspect-[3/4] rounded-xl overflow-hidden bg-black/60 mb-2 relative">
                          <img
                            src={card.imageUrl}
                            alt={card.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        </div>

                        <div>
                          <div className="flex items-center justify-between">
                            <span 
                              className="w-2 h-2 rounded-full shrink-0 shadow-xs"
                              style={{ backgroundColor: theme.accent, boxShadow: `0 0 6px ${theme.accent}` }}
                            />
                            <span className="text-[10px] font-mono text-[#8db8b1]">
                              OVR {card.overallRating || 75}
                            </span>
                          </div>
                          <p className="text-xs font-bold text-white truncate mt-1">
                            {card.name}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 2. SHOWCASE TAB */}
            {activeTab === 'showcase' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div>
                    <h4 className="text-sm font-bold text-white">
                      {isAr ? 'إدارة معرض البطاقات (3-5 بطاقات)' : 'Manage Showcase (3–5 Cards)'}
                    </h4>
                    <p className="text-xs text-[#8db8b1]">
                      {isAr ? 'حدد من 3 إلى 5 بطاقات، ويمكنك إعادة ترتيبها لتظهر بالترتيب المطلوب.' : 'Select 3 to 5 cards and adjust their display order using the controls.'}
                    </p>
                  </div>
                  <span className="text-xs font-mono font-bold text-[#5eead4] bg-black/60 px-3 py-1 rounded-full border border-cyan-500/30">
                    {showcaseCardIds.length} / 5 {isAr ? 'محددة' : 'Selected'}
                  </span>
                </div>

                {/* Currently Selected Showcase Order */}
                {showcaseCardIds.length > 0 && (
                  <div className="p-3.5 rounded-2xl bg-black/50 border border-cyan-500/30 space-y-2">
                    <p className="text-[11px] font-mono font-bold uppercase text-[#5eead4] flex items-center gap-1.5">
                      <Layers size={13} />
                      <span>{isAr ? 'الترتيب الحالي للمعرض' : 'CURRENT SHOWCASE SEQUENCE'}</span>
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
                      {showcaseCardIds.map((cid, idx) => {
                        const card = cardLookup.get(cid);
                        if (!card) return null;
                        const theme = RARITY_THEMES[card.rarity];
                        return (
                          <div
                            key={cid}
                            className="p-2 rounded-xl bg-black/60 border flex flex-col justify-between relative group"
                            style={{ borderColor: theme.accent }}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-[10px] font-mono font-bold text-[#8db8b1]">
                                Slot 0{idx + 1}
                              </span>
                              <button
                                onClick={() => handleToggleShowcaseCard(cid)}
                                className="text-rose-400 hover:text-rose-300 p-1 cursor-pointer"
                                title="Remove from showcase"
                              >
                                <Trash2 size={12} />
                              </button>
                            </div>

                            <div className="w-full aspect-[4/3] rounded-lg overflow-hidden bg-black/40 mb-1.5">
                              <img src={card.imageUrl} alt={card.name} className="w-full h-full object-cover" />
                            </div>

                            <p className="text-[11px] font-bold text-white truncate">{card.name}</p>

                            {/* Order Controls */}
                            <div className="flex items-center justify-between pt-1 border-t border-white/5 mt-1">
                              <button
                                onClick={() => handleMoveShowcaseCard(idx, 'up')}
                                disabled={idx === 0}
                                className="p-1 rounded text-[#8db8b1] hover:text-white disabled:opacity-30 cursor-pointer"
                              >
                                <ArrowUp size={12} />
                              </button>
                              <span className="text-[10px] font-mono text-[#8db8b1]">{idx + 1}</span>
                              <button
                                onClick={() => handleMoveShowcaseCard(idx, 'down')}
                                disabled={idx === showcaseCardIds.length - 1}
                                className="p-1 rounded text-[#8db8b1] hover:text-white disabled:opacity-30 cursor-pointer"
                              >
                                <ArrowDown size={12} />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Card Selection Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 max-h-80 overflow-y-auto custom-scrollbar p-1">
                  {catalog.map((card) => {
                    const isSelected = showcaseCardIds.includes(card.id);
                    const theme = RARITY_THEMES[card.rarity];
                    return (
                      <div
                        key={card.id}
                        onClick={() => handleToggleShowcaseCard(card.id)}
                        className={`p-2 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between relative overflow-hidden group ${
                          isSelected
                            ? 'bg-cyan-500/20 border-cyan-400 ring-2 ring-cyan-400/50 shadow-xl'
                            : 'bg-black/40 hover:bg-black/60 border-white/10'
                        }`}
                      >
                        {isSelected && (
                          <div className="absolute top-2 end-2 z-10 w-6 h-6 rounded-full bg-cyan-400 text-black flex items-center justify-center font-bold shadow-md">
                            <Check size={14} />
                          </div>
                        )}

                        <div className="w-full aspect-[3/4] rounded-xl overflow-hidden bg-black/60 mb-2 relative">
                          <img
                            src={card.imageUrl}
                            alt={card.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        </div>

                        <div>
                          <div className="flex items-center justify-between">
                            <span 
                              className="w-2 h-2 rounded-full shrink-0 shadow-xs"
                              style={{ backgroundColor: theme.accent, boxShadow: `0 0 6px ${theme.accent}` }}
                            />
                            <span className="text-[10px] font-mono text-[#8db8b1]">
                              OVR {card.overallRating || 75}
                            </span>
                          </div>
                          <p className="text-xs font-bold text-white truncate mt-1">
                            {card.name}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 3. TITLE TAB */}
            {activeTab === 'title' && (
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-bold text-white">
                    {isAr ? 'اختر لقبك الملكي المفضل' : 'Choose Your Active Title'}
                  </h4>
                  <p className="text-xs text-[#8db8b1]">
                    {isAr ? 'يمكنك تفعيل أي لقب قمت بإلغاء قفله ليظهر تحت اسمك مباشرة.' : 'Only unlocked titles can be equipped. Locked titles display their milestone condition.'}
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {profileData.allTitles.map((title) => {
                    const isUnlocked = unlockedTitleIds.has(title.id);
                    const isSelected = selectedTitleId === title.id;
                    const theme = RARITY_THEMES[title.rarity];

                    return (
                      <div
                        key={title.id}
                        onClick={() => {
                          if (isUnlocked) {
                            setSelectedTitleId(title.id);
                          }
                        }}
                        className={`p-4 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-400 ring-2 ring-amber-400/40 shadow-lg'
                            : isUnlocked
                            ? 'bg-black/45 hover:bg-black/65 border-[rgba(158,255,230,0.18)] cursor-pointer'
                            : 'bg-black/20 border-white/5 opacity-50 cursor-not-allowed'
                        }`}
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span
                              className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-md"
                              style={{
                                background: isUnlocked ? `${theme.accent}20` : '#27272a',
                                color: isUnlocked ? theme.accent : '#71717a'
                              }}
                            >
                              {title.rarity}
                            </span>
                            <span className="text-xs font-bold text-white">
                              {isAr ? title.nameAr : title.name}
                            </span>
                          </div>
                          <p className="text-xs text-[#8db8b1]">
                            {isAr ? title.descriptionAr : title.description}
                          </p>
                        </div>

                        {isSelected ? (
                          <div className="w-6 h-6 rounded-full bg-amber-400 text-black flex items-center justify-center font-bold shrink-0">
                            <Check size={14} />
                          </div>
                        ) : !isUnlocked ? (
                          <span className="text-[10px] font-mono text-zinc-500 shrink-0">
                            {isAr ? 'مقفل' : 'LOCKED'}
                          </span>
                        ) : null}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 4. BADGES TAB */}
            {activeTab === 'badges' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div>
                    <h4 className="text-sm font-bold text-white">
                      {isAr ? 'تحديد الأوسمة المميزة (حتى 4 أوسمة)' : 'Feature Badges (Up to 4)'}
                    </h4>
                    <p className="text-xs text-[#8db8b1]">
                      {isAr ? 'اختر الأوسمة المفتوحة التي تود إبرازها في ملفك الشخصي.' : 'Highlight your proudest unlocked collector badges on your profile header.'}
                    </p>
                  </div>
                  <span className="text-xs font-mono font-bold text-purple-300 bg-black/60 px-3 py-1 rounded-full border border-purple-500/30">
                    {featuredBadgeIds.length} / 4 {isAr ? 'محددة' : 'Featured'}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {profileData.allBadges.map((badge) => {
                    const isUnlocked = unlockedBadgeIds.has(badge.id);
                    const isFeatured = featuredBadgeIds.includes(badge.id);
                    const theme = RARITY_THEMES[badge.rarity];

                    return (
                      <div
                        key={badge.id}
                        onClick={() => {
                          if (isUnlocked) {
                            handleToggleBadge(badge.id);
                          }
                        }}
                        className={`p-3.5 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                          isFeatured
                            ? 'bg-purple-500/20 border-purple-400 ring-2 ring-purple-400/40 shadow-lg'
                            : isUnlocked
                            ? 'bg-black/45 hover:bg-black/65 border-[rgba(158,255,230,0.18)] cursor-pointer'
                            : 'bg-black/20 border-white/5 opacity-50 cursor-not-allowed'
                        }`}
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span 
                              className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-md"
                              style={{ color: theme.accent, background: `${theme.accent}15` }}
                            >
                              {badge.rarity}
                            </span>
                            <span className="text-xs font-bold text-white">
                              {isAr ? badge.nameAr : badge.name}
                            </span>
                          </div>
                          <p className="text-xs text-[#8db8b1]">
                            {isAr ? badge.descriptionAr : badge.description}
                          </p>
                        </div>

                        {isFeatured ? (
                          <div className="w-6 h-6 rounded-full bg-purple-400 text-black flex items-center justify-center font-bold shrink-0">
                            <Check size={14} />
                          </div>
                        ) : !isUnlocked ? (
                          <span className="text-[10px] font-mono text-zinc-500 shrink-0">
                            {isAr ? 'مقفل' : 'LOCKED'}
                          </span>
                        ) : null}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Bottom Actions Bar */}
          <div className="p-4 sm:p-5 border-t border-[rgba(158,255,230,0.15)] bg-black/60 flex items-center justify-between gap-3 shrink-0">
            <button
              onClick={onClose}
              disabled={isSaving}
              className="px-4 py-2 rounded-xl text-xs font-medium text-[#8db8b1] hover:text-white bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
            >
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>

            <button
              onClick={handleSaveAll}
              disabled={isSaving}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold text-[#031211] bg-gradient-to-r from-amber-400 via-amber-300 to-[#5eead4] hover:brightness-110 shadow-lg shadow-amber-500/20 transition-all cursor-pointer disabled:opacity-50"
            >
              {isSaving ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />}
              <span>{isSaving ? (isAr ? 'جاري الحفظ...' : 'Saving...') : (isAr ? 'حفظ التغييرات' : 'Save Changes')}</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
