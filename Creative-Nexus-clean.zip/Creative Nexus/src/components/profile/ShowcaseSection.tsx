import React from 'react';
import { CollectibleCardData } from '../../types/cards';
import { CollectibleCard } from '../cards/CollectibleCard';
import { Layers, Edit3, Plus, Sparkles } from 'lucide-react';

interface ShowcaseSectionProps {
  showcaseCards: CollectibleCardData[];
  isOwnProfile: boolean;
  onOpenEdit: () => void;
  onClickDetail: (card: CollectibleCardData) => void;
  isAr?: boolean;
}

export const ShowcaseSection: React.FC<ShowcaseSectionProps> = ({
  showcaseCards,
  isOwnProfile,
  onOpenEdit,
  onClickDetail,
  isAr = false,
}) => {
  const maxSlots = 5;
  const cardsCount = showcaseCards.length;

  return (
    <div className="relative rounded-2xl sm:rounded-3xl bg-gradient-to-b from-[#061c1a]/90 via-[#031312]/95 to-[#020b0a]/98 border border-[rgba(158,255,230,0.16)] p-3.5 xs:p-4 sm:p-7 shadow-xl overflow-hidden w-full max-w-full min-w-0 box-border">
      {/* Header */}
      <div className="flex items-center justify-between gap-2.5 sm:gap-3 mb-4 sm:mb-6 relative z-10 flex-wrap min-w-0">
        <div className="flex items-center gap-2 xs:gap-2.5 min-w-0 flex-1">
          <div className="p-1.5 xs:p-2 rounded-xl bg-cyan-500/15 text-[#5eead4] border border-cyan-500/30 shrink-0">
            <Layers size={16} className="xs:w-[18px] xs:h-[18px]" />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-base sm:text-xl font-display font-bold text-white tracking-wide flex items-center gap-1.5 sm:gap-2 flex-wrap min-w-0">
              <span className="truncate">{isAr ? 'معرض البطاقات الملكي' : 'MY SHOWCASE'}</span>
              <span className="text-[10px] sm:text-xs font-mono font-bold text-[#5eead4] bg-black/60 px-2 py-0.5 rounded-full border border-cyan-500/30 shrink-0">
                {cardsCount} / {maxSlots}
              </span>
            </h2>
            <p className="text-[11px] xs:text-xs text-[#8db8b1] break-words [overflow-wrap:anywhere] mt-0.5">
              {isAr ? 'عرض 3 إلى 5 بطاقات استثنائية من مقتنياتك' : 'Display 3–5 featured relics from your owned collection'}
            </p>
          </div>
        </div>

        {isOwnProfile && (
          <button
            onClick={onOpenEdit}
            className="flex items-center gap-1.5 px-2.5 xs:px-3 py-1.5 rounded-xl text-xs font-semibold text-[#5eead4] bg-[#5eead4]/10 hover:bg-[#5eead4]/20 border border-[#5eead4]/30 transition-all cursor-pointer shrink-0"
          >
            <Edit3 size={12} className="shrink-0" />
            <span>{isAr ? 'إدارة المعرض' : 'Manage Showcase'}</span>
          </button>
        )}
      </div>

      {/* Cards Showcase Grid */}
      {cardsCount > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3.5 sm:gap-5 justify-items-center relative z-10 w-full min-w-0">
          {showcaseCards.map((card, idx) => (
            <div key={card.id} className="flex flex-col items-center w-full max-w-[240px] min-w-0">
              {/* Slot Index Tag */}
              <div className="mb-2 text-[10px] font-mono uppercase tracking-wider text-[#8db8b1]/80 px-2 py-0.5 rounded-md bg-black/40 border border-white/5">
                {isAr ? `الخانة ${idx + 1}` : `Slot 0${idx + 1}`}
              </div>

              {/* Reused CollectibleCard component */}
              <CollectibleCard
                card={card}
                isOwned={true}
                isShowcased={true}
                onClickDetail={onClickDetail}
                size="normal"
                disableScrollTilt={true}
              />
            </div>
          ))}

          {/* If fewer than 5 cards and is own profile, show subtle add slot */}
          {isOwnProfile && cardsCount < maxSlots && (
            <button
              onClick={onOpenEdit}
              className="flex flex-col items-center justify-center w-full max-w-[240px] h-[340px] rounded-2xl border-2 border-dashed border-[rgba(158,255,230,0.18)] hover:border-[#5eead4]/50 bg-black/20 hover:bg-black/40 transition-all p-4 text-center group cursor-pointer box-border"
            >
              <div className="w-12 h-12 rounded-xl bg-[#0a2624] border border-[#5eead4]/20 flex items-center justify-center text-[#5eead4] group-hover:scale-110 transition-transform mb-3">
                <Plus size={20} />
              </div>
              <p className="text-xs font-bold text-[#eafffa]">
                {isAr ? 'إضافة بطاقة للمعرض' : 'Add Showcase Card'}
              </p>
              <p className="text-[10px] text-[#8db8b1] mt-1">
                {isAr ? `الخانة ${cardsCount + 1}` : `Slot 0${cardsCount + 1}`}
              </p>
            </button>
          )}
        </div>
      ) : (
        /* Empty Showcase State */
        <div className="py-12 px-4 rounded-2xl border-2 border-dashed border-[rgba(158,255,230,0.18)] bg-black/30 flex flex-col items-center justify-center text-center space-y-3 relative z-10">
          <div className="w-14 h-14 rounded-2xl bg-[#0a2624] border border-[#5eead4]/25 flex items-center justify-center text-[#5eead4]">
            <Sparkles size={24} className="opacity-70" />
          </div>
          <div className="space-y-1">
            <p className="text-sm font-bold text-white">
              {isAr ? 'معرض البطاقات فارغ' : 'Showcase is Empty'}
            </p>
            <p className="text-xs text-[#8db8b1] max-w-sm">
              {isAr
                ? 'اختر من 3 إلى 5 بطاقات من مقتنياتك لعرضها في ملفك الشخصي.'
                : 'Select 3 to 5 cards from your collection to feature them on your public showcase.'}
            </p>
          </div>
          {isOwnProfile && (
            <button
              onClick={onOpenEdit}
              className="mt-2 flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-[#031211] bg-[#5eead4] hover:bg-[#2dd4bf] transition-all cursor-pointer shadow-lg shadow-cyan-500/20"
            >
              <Plus size={14} />
              <span>{isAr ? 'تخصيص المعرض' : 'Customize Showcase'}</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};
