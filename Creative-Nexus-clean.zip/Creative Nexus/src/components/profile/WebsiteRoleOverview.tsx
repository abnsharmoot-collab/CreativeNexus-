import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { PlayerProfileData } from '../../types/progression';
import { StaffMember } from '../../types/staff';
import { RankTier } from '../../types/rankMap';
import { UserAchievementStatus, AchievementStats } from '../../context/AchievementContext';
import { 
  Shield, Award, Trophy, Sparkles, ExternalLink, Copy, Check, 
  User, Crown, Activity, BookOpen, Megaphone, LayoutDashboard, 
  Coins, Star, ChevronRight, Compass, ShieldCheck, Zap
} from 'lucide-react';
import { motion } from 'motion/react';

interface WebsiteRoleOverviewProps {
  profileData: PlayerProfileData;
  staffMember?: StaffMember | null;
  effectiveRole: 'OWNER' | 'SUPER_ADMIN' | 'ADMIN' | 'MODERATOR' | 'STAFF' | 'MEMBER';
  moderatorLevel: number;
  currentTier?: RankTier | null;
  nextTier?: RankTier | null;
  serverAchievements?: UserAchievementStatus[];
  achievementStats?: AchievementStats;
  isOwnProfile: boolean;
  isAr?: boolean;
}

export const WebsiteRoleOverview: React.FC<WebsiteRoleOverviewProps> = ({
  profileData,
  staffMember,
  effectiveRole,
  moderatorLevel,
  currentTier,
  nextTier,
  serverAchievements = [],
  achievementStats,
  isOwnProfile,
  isAr = false,
}) => {
  const navigate = useNavigate();
  const [copiedId, setCopiedId] = useState(false);

  const isOwner = effectiveRole === 'OWNER';
  const isModerator = effectiveRole === 'MODERATOR' || effectiveRole === 'ADMIN' || effectiveRole === 'SUPER_ADMIN';
  const isStaff = effectiveRole === 'STAFF' || Boolean(staffMember) || isModerator || isOwner;

  const staffPoints = staffMember?.points ?? profileData.staffInfo?.points ?? (isOwner ? 9999 : 0);
  const minPoints = currentTier?.minPoints ?? 0;
  const maxPoints = currentTier?.maxPoints ?? 100;
  const range = Math.max(1, maxPoints - minPoints);
  const tierProgress = Math.min(100, Math.max(0, Math.round(((staffPoints - minPoints) / range) * 100)));
  const pointsToNext = nextTier ? Math.max(0, nextTier.minPoints - staffPoints) : 0;

  const unlockedAchievements = serverAchievements.filter(a => a.isUnlocked);
  const totalAchievementsCount = achievementStats?.total || serverAchievements.length || 24;
  const unlockedCount = achievementStats?.unlockedCount ?? unlockedAchievements.length;
  const achievementPercent = achievementStats?.completionPercent ?? Math.round((unlockedCount / Math.max(1, totalAchievementsCount)) * 100);

  const handleCopyDiscordId = () => {
    navigator.clipboard.writeText(profileData.discordId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* 1. PRIMARY ROLE & WEBSITE AUTHORITY HERO BANNER */}
      <div className={`relative rounded-3xl p-6 sm:p-8 overflow-hidden border backdrop-blur-xl shadow-2xl transition-all ${
        isOwner
          ? 'bg-gradient-to-br from-amber-950/40 via-[#0a1f1d]/90 to-[#020e0d] border-amber-500/40 shadow-amber-500/10'
          : isModerator
          ? 'bg-gradient-to-br from-indigo-950/45 via-[#061817]/90 to-[#020e0d] border-indigo-500/40 shadow-indigo-500/10'
          : isStaff
          ? 'bg-gradient-to-br from-emerald-950/35 via-[#061817]/90 to-[#020e0d] border-emerald-500/35 shadow-emerald-500/10'
          : 'bg-gradient-to-br from-cyan-950/30 via-[#061817]/90 to-[#020e0d] border-[rgba(158,255,230,0.22)]'
      }`}>
        {/* Ambient background glow */}
        <div className={`absolute top-0 end-0 w-96 h-96 rounded-full blur-3xl pointer-events-none opacity-20 ${
          isOwner ? 'bg-amber-400' : isModerator ? 'bg-indigo-500' : isStaff ? 'bg-emerald-400' : 'bg-cyan-400'
        }`} />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            {/* Role Header Badge */}
            <div className="flex items-center gap-2.5 flex-wrap">
              {isOwner ? (
                <span className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-mono font-black uppercase tracking-wider bg-gradient-to-r from-amber-500/25 to-yellow-500/10 text-amber-300 border border-amber-500/50 shadow-[0_0_15px_rgba(245,158,11,0.3)]">
                  <Crown size={15} className="text-amber-400 animate-pulse" />
                  <span>{isAr ? 'المالك والمؤسس الأعلى' : 'SOVEREIGN SERVER OWNER'}</span>
                </span>
              ) : isModerator ? (
                <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-mono font-black uppercase tracking-wider bg-gradient-to-r from-indigo-500/30 to-purple-500/15 text-indigo-200 border border-indigo-500/50 shadow-[0_0_18px_rgba(99,102,241,0.35)]">
                  <ShieldCheck size={16} className="text-indigo-400" />
                  <span>{isAr ? 'مشرف سيرفر معتمد' : 'VERIFIED SERVER MODERATOR'}</span>
                </span>
              ) : isStaff ? (
                <span className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-mono font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  <Zap size={14} className="text-emerald-400" />
                  <span>{isAr ? 'طاقم الإدارة الميدانية' : 'STAFF MEMBER'}</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-mono font-bold uppercase tracking-wider bg-[#5eead4]/15 text-[#5eead4] border border-[#5eead4]/30">
                  <User size={14} className="text-[#5eead4]" />
                  <span>{isAr ? 'عضو مجتمع موثق' : 'VERIFIED COMMUNITY MEMBER'}</span>
                </span>
              )}

              {/* Prominent Moderator Level Badge */}
              {isModerator && (
                <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-mono font-black bg-indigo-900/60 text-indigo-300 border border-indigo-400/50 shadow-md">
                  <Star size={13} className="text-indigo-400 fill-indigo-400" />
                  <span>{isAr ? `المستوى الإشرافي ${moderatorLevel}` : `MODERATOR LEVEL ${moderatorLevel}`}</span>
                </span>
              )}

              {currentTier && (
                <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-mono font-semibold bg-black/40 text-amber-300 border border-white/10">
                  <Award size={13} className="text-amber-400" />
                  <span>{isAr && currentTier.nameAr ? currentTier.nameAr : currentTier.name}</span>
                </span>
              )}
            </div>

            {/* Role Title & Bio */}
            <div>
              <h2 className="text-2xl sm:text-3xl font-display font-black text-white tracking-wide">
                {isOwner 
                  ? (isAr ? 'الإشراف والقيادة العليا للملاذ' : 'Supreme Sovereign & Nexus Authority')
                  : isModerator 
                  ? (isAr ? `مشرف السيرفر • المستوى ${moderatorLevel}` : `Server Moderator • Level ${moderatorLevel}`)
                  : isStaff 
                  ? (isAr ? 'طاقم إدارة CREATINE NEXUS' : 'CREATINE NEXUS Staff Team')
                  : (isAr ? 'عضو مجتمعي معتمد في CREATINE NEXUS' : 'Verified Community Citizen')}
              </h2>
              <p className="text-sm text-[#8db8b1] leading-relaxed pt-1.5 max-w-xl">
                {isOwner
                  ? (isAr 
                      ? 'يمتلك كافة الصلاحيات الإدارية والتشغيلية العليا لسيرفر ديسكورد والمنصة، وإدارة طاقم العمل وخزائن البطاقات.'
                      : 'Holds supreme operational and sovereign privileges across the Discord server, web app, staff management, and card treasury.')
                  : isModerator
                  ? (isAr
                      ? `عضو إشرافي معتمد بمستوى إشرافي ${moderatorLevel}. مسؤول عن إدارة المحادثات، ضبط النظام، مساعدة الأعضاء والتنسيق الميداني.`
                      : `Recognized server moderator operating at Moderator Level ${moderatorLevel}. Responsible for chat oversight, server rule enforcement, and community care.`)
                  : isStaff
                  ? (isAr
                      ? 'أحد كوادر طاقم الإدارة المعتمدين في الملاذ مع تقدم نشط في سلم الرتب والنقاط الميدانية.'
                      : 'Recognized operational staff member actively advancing through the server rank hierarchy.')
                  : (isAr
                      ? 'عضو موثق في مجتمع CREATINE NEXUS. يشارك في الأنشطة، جمع بطاقات الملاذ وتحديات الإنجازات.'
                      : 'Verified member of the CREATINE NEXUS community participating in activities, card collecting, and achievements.')}
              </p>
            </div>

            {/* Moderation Duties & Badges (if moderator or staff) */}
            {isModerator && (
              <div className="pt-2 flex items-center gap-2 flex-wrap text-[11px] font-mono">
                <span className="px-2.5 py-1 rounded-lg bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
                  🛡️ {isAr ? 'ضبط النظام والنزاعات' : 'Dispute Resolution'}
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
                  ⚖️ {isAr ? 'تطبيق القوانين' : 'Rule Enforcement'}
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
                  👥 {isAr ? 'مساعدة الأعضاء' : 'Member Care'}
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
                  🎫 {isAr ? 'دعم التذاكر' : 'Ticket Operations'}
                </span>
              </div>
            )}
          </div>

          {/* Action Callout Box */}
          <div className="flex flex-col sm:flex-row lg:flex-col gap-3 shrink-0">
            {isStaff && (
              <button
                onClick={() => navigate(`/staff-management${staffMember ? `/${staffMember.id}` : ''}`)}
                className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-2xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 border border-indigo-400/40 shadow-lg shadow-indigo-600/30 transition-all cursor-pointer active:scale-95"
              >
                <Shield size={15} />
                <span>{isAr ? 'فتح السجل الإداري' : 'Staff Dossier'}</span>
                <ExternalLink size={13} />
              </button>
            )}

            <button
              onClick={() => navigate('/rank-points')}
              className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-2xl text-xs font-bold text-amber-300 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 transition-all cursor-pointer shadow-sm active:scale-95"
            >
              <Award size={15} />
              <span>{isAr ? 'خريطة رتب السيرفر' : 'Server Rank Map'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. MODERATOR LEVEL PROGRESSION CARD (Special prominent display for Moderators) */}
      {isModerator && (
        <div className="rounded-3xl bg-gradient-to-br from-[#0c1229]/95 via-[#08181b]/95 to-[#031211]/98 border border-indigo-500/30 p-5 sm:p-7 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-[0_0_15px_rgba(99,102,241,0.25)]">
                <ShieldCheck size={26} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg sm:text-xl font-bold font-display text-white">
                    {isAr ? 'المستوى الإشرافي ورصيد النقاط' : 'Moderator Level & Rank Progression'}
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-black bg-indigo-500/25 text-indigo-300 border border-indigo-500/40">
                    LV {moderatorLevel}
                  </span>
                </div>
                <p className="text-xs text-[#8db8b1] font-mono">
                  {currentTier ? `${currentTier.name} (${currentTier.pointsLabel})` : 'Active Staff Standing'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 self-start sm:self-auto">
              <div className="text-end font-mono">
                <span className="text-2xl font-black text-amber-300">{staffPoints}</span>
                <span className="text-xs text-[#8db8b1] ms-1">PTS</span>
              </div>
            </div>
          </div>

          {/* Progress towards next rank tier */}
          <div className="space-y-2 pt-1">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-indigo-300 font-bold">
                {currentTier?.name || 'Current Rank'}
              </span>
              {nextTier ? (
                <span className="text-[#8db8b1]">
                  {isAr 
                    ? `متبقي ${pointsToNext} نقطة لبلوغ ${nextTier.name}` 
                    : `${pointsToNext} PTS needed to reach ${nextTier.name}`}
                </span>
              ) : (
                <span className="text-amber-300 font-bold">
                  {isAr ? 'الرتبة القصوى محققة' : 'Maximum Rank Tier Achieved'}
                </span>
              )}
            </div>

            <div className="relative w-full h-3 rounded-full bg-black/70 border border-white/10 overflow-hidden p-0.5">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${tierProgress}%` }}
                transition={{ duration: 0.8, ease: 'easeOut' }}
                className="h-full rounded-full bg-gradient-to-r from-indigo-500 via-indigo-400 to-cyan-400 shadow-[0_0_12px_rgba(99,102,241,0.6)]"
              />
            </div>

            <div className="flex items-center justify-between text-[11px] font-mono text-[#8db8b1]">
              <span>{tierProgress}% {isAr ? 'اكتمال الرتبة الحالية' : 'Tier Completion'}</span>
              <span>{nextTier ? `${nextTier.minPoints} PTS [${nextTier.name}]` : 'Apex Standing'}</span>
            </div>
          </div>
        </div>
      )}

      {/* 3. WEBSITE-WIDE TELEMETRY & ACCOUNT METRICS GRID */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Discord ID */}
        <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-1.5 backdrop-blur-md">
          <div className="flex items-center justify-between text-[#8db8b1] text-xs font-mono">
            <span>Discord ID</span>
            <button
              onClick={handleCopyDiscordId}
              className="p-1 rounded hover:bg-white/10 hover:text-white transition-colors cursor-pointer"
              title="Copy Discord ID"
            >
              {copiedId ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
            </button>
          </div>
          <p className="text-xs sm:text-sm font-mono font-bold text-white truncate select-all">
            {profileData.discordId}
          </p>
        </div>

        {/* Server Achievements */}
        <div 
          onClick={() => navigate('/achievements')}
          className="p-4 rounded-2xl bg-black/40 hover:bg-white/[0.04] border border-white/10 hover:border-amber-500/30 transition-all cursor-pointer space-y-1.5 backdrop-blur-md group"
        >
          <div className="flex items-center justify-between text-[#8db8b1] text-xs font-mono">
            <span className="group-hover:text-amber-300 transition-colors">{isAr ? 'الإنجازات' : 'Achievements'}</span>
            <Trophy size={14} className="text-amber-400" />
          </div>
          <p className="text-sm sm:text-base font-mono font-black text-amber-300">
            {unlockedCount} / {totalAchievementsCount}
          </p>
          <p className="text-[10px] text-[#8db8b1] font-mono">
            {achievementPercent}% {isAr ? 'مكتمل' : 'Unlocked'}
          </p>
        </div>

        {/* Coin Balance */}
        <div 
          onClick={() => navigate('/cards')}
          className="p-4 rounded-2xl bg-black/40 hover:bg-white/[0.04] border border-white/10 hover:border-amber-500/30 transition-all cursor-pointer space-y-1.5 backdrop-blur-md group"
        >
          <div className="flex items-center justify-between text-[#8db8b1] text-xs font-mono">
            <span className="group-hover:text-amber-300 transition-colors">{isAr ? 'رصيد العملات' : 'Vault Coins'}</span>
            <Coins size={14} className="text-amber-400" />
          </div>
          <p className="text-sm sm:text-base font-mono font-black text-amber-300 truncate">
            {profileData.coins.toLocaleString()} 🪙
          </p>
          <p className="text-[10px] text-[#8db8b1] font-mono">
            {isAr ? 'متجر البطاقات والحزم' : 'Card Shop & Packs'}
          </p>
        </div>

        {/* Account Level */}
        <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-1.5 backdrop-blur-md">
          <div className="flex items-center justify-between text-[#8db8b1] text-xs font-mono">
            <span>{isAr ? 'مستوى الحساب' : 'Account Level'}</span>
            <Star size={14} className="text-[#5eead4]" />
          </div>
          <p className="text-sm sm:text-base font-mono font-black text-[#5eead4]">
            LEVEL {profileData.level}
          </p>
          <p className="text-[10px] text-[#8db8b1] font-mono">
            {profileData.xp.toLocaleString()} XP
          </p>
        </div>
      </div>

      {/* 4. SERVER ACHIEVEMENTS CABINET SNAPSHOT */}
      <div className="rounded-3xl bg-black/45 border border-white/10 p-5 sm:p-7 space-y-4 backdrop-blur-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
              <Trophy size={18} />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold font-display text-white">
                {isAr ? 'إنجازات الموقع والسيرفر' : 'Server Achievements & Trophies'}
              </h3>
              <p className="text-xs text-[#8db8b1] font-mono">
                {unlockedCount} {isAr ? 'من أصل' : 'of'} {totalAchievementsCount} {isAr ? 'إنجازات مكتسبة' : 'achievements unlocked'} ({achievementPercent}%)
              </p>
            </div>
          </div>

          <button
            onClick={() => navigate('/achievements')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 transition-all cursor-pointer"
          >
            <span>{isAr ? 'استعراض الكل' : 'View All'}</span>
            <ChevronRight size={14} />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="relative w-full h-2 rounded-full bg-black/60 border border-white/10 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-amber-500 to-[#5eead4] transition-all duration-500"
            style={{ width: `${achievementPercent}%` }}
          />
        </div>

        {/* Top Unlocked Achievement Badges */}
        {unlockedAchievements.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
            {unlockedAchievements.slice(0, 6).map((ach) => (
              <div 
                key={ach.definition.id}
                className="p-3 rounded-2xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/5 hover:border-amber-500/30 transition-all flex items-center gap-3"
              >
                <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xl shrink-0">
                  {ach.definition.icon || '🏆'}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-white truncate font-display">
                    {isAr ? ach.definition.titleAr : ach.definition.title}
                  </p>
                  <p className="text-[10px] text-[#8db8b1] truncate">
                    {isAr ? ach.definition.descriptionAr : ach.definition.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-black/30 border border-white/5 text-center text-xs text-[#8db8b1]">
            {isAr 
              ? 'لم يتم فتح أي إنجازات بعد. تصفح الموقع وخزينة البطاقات للمشاركة في فتح الإنجازات!'
              : 'No achievements unlocked yet. Explore the website and Card Vault to earn achievements!'}
          </div>
        )}
      </div>

      {/* 5. WEBSITE QUICK ACCESS HUBS */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <Link
          to="/server-dashboard"
          className="p-3.5 rounded-2xl bg-black/40 hover:bg-white/[0.05] border border-white/10 hover:border-[#5eead4]/40 transition-all flex flex-col items-center justify-center text-center space-y-2 group"
        >
          <div className="p-2 rounded-xl bg-[#5eead4]/10 text-[#5eead4] group-hover:scale-110 transition-transform">
            <LayoutDashboard size={18} />
          </div>
          <span className="text-xs font-bold text-white group-hover:text-[#5eead4] transition-colors">
            {isAr ? 'لوحة السيرفر' : 'Server Dashboard'}
          </span>
        </Link>

        <Link
          to="/announcements"
          className="p-3.5 rounded-2xl bg-black/40 hover:bg-white/[0.05] border border-white/10 hover:border-[#5eead4]/40 transition-all flex flex-col items-center justify-center text-center space-y-2 group"
        >
          <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 group-hover:scale-110 transition-transform">
            <Megaphone size={18} />
          </div>
          <span className="text-xs font-bold text-white group-hover:text-[#5eead4] transition-colors">
            {isAr ? 'الإعلانات' : 'Announcements'}
          </span>
        </Link>

        <Link
          to="/guidebook"
          className="p-3.5 rounded-2xl bg-black/40 hover:bg-white/[0.05] border border-white/10 hover:border-[#5eead4]/40 transition-all flex flex-col items-center justify-center text-center space-y-2 group"
        >
          <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 group-hover:scale-110 transition-transform">
            <BookOpen size={18} />
          </div>
          <span className="text-xs font-bold text-white group-hover:text-[#5eead4] transition-colors">
            {isAr ? 'الكتيبات الإرشادية' : 'Codex & Guides'}
          </span>
        </Link>

        <Link
          to="/history"
          className="p-3.5 rounded-2xl bg-black/40 hover:bg-white/[0.05] border border-white/10 hover:border-[#5eead4]/40 transition-all flex flex-col items-center justify-center text-center space-y-2 group"
        >
          <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 group-hover:scale-110 transition-transform">
            <Activity size={18} />
          </div>
          <span className="text-xs font-bold text-white group-hover:text-amber-300 transition-colors">
            {isAr ? 'أرشيف التاريخ' : 'History Archive'}
          </span>
        </Link>

        <Link
          to="/cards"
          className="p-3.5 rounded-2xl bg-black/40 hover:bg-white/[0.05] border border-white/10 hover:border-amber-500/40 transition-all flex flex-col items-center justify-center text-center space-y-2 group col-span-2 sm:col-span-1"
        >
          <div className="p-2 rounded-xl bg-amber-500/15 text-amber-300 group-hover:scale-110 transition-transform">
            <Coins size={18} />
          </div>
          <span className="text-xs font-bold text-amber-300 transition-colors">
            {isAr ? 'خزينة البطاقات' : 'Card Vault'}
          </span>
        </Link>
      </div>
    </div>
  );
};
