import React from 'react';
import { PlayerBadge } from '../../types/progression';
import { RARITY_THEMES } from '../cards/CollectibleCard';
import { 
  Award, Lock, Sparkles, Check, Package, Clock, Layers, 
  Coins, BookOpen, Crown, Trophy, ExternalLink, Shield, Zap, CheckCircle2, ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAchievements } from '../../context/AchievementContext';
import { isStaffOnlyAchievement } from '../../types/achievements';

interface BadgesSectionProps {
  unlockedBadges: PlayerBadge[];
  allBadges: PlayerBadge[];
  featuredBadgeIds: string[];
  isOwnProfile: boolean;
  onOpenEdit: () => void;
  isAr?: boolean;
}

const BADGE_ICONS: Record<string, React.FC<{ size?: number; className?: string }>> = {
  Package,
  Clock,
  Layers,
  Coins,
  BookOpen,
  Crown,
  Sparkles,
  Trophy,
  Award,
};

export const BadgesSection: React.FC<BadgesSectionProps> = ({
  unlockedBadges,
  allBadges,
  featuredBadgeIds,
  isOwnProfile,
  onOpenEdit,
  isAr = false,
}) => {
  const { achievements, stats, isStaff, roleMultiplier, claimReward } = useAchievements();
  const featuredBadges = allBadges.filter(b => featuredBadgeIds.includes(b.id));

  // Determine unlocked badge IDs accurately
  const unlockedBadgeIdsSet = new Set(unlockedBadges.map(b => b.id));

  // Separate achievements: staff achievements for staff only, user achievements for everyone
  const visibleAchievements = achievements.filter(a => {
    const isStaffOnly = isStaffOnlyAchievement(a.definition);
    if (isStaffOnly && !isStaff) return false;
    return true;
  });

  const unlockedCount = visibleAchievements.filter(a => a.isUnlocked).length;
  const totalCount = visibleAchievements.length;

  return (
    <div className="rounded-2xl sm:rounded-3xl bg-gradient-to-b from-[#061c1a]/90 via-[#031312]/95 to-[#020b0a]/98 border border-[rgba(158,255,230,0.16)] p-3.5 xs:p-4 sm:p-7 shadow-xl space-y-5 sm:space-y-7 w-full max-w-full min-w-0 box-border overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between gap-2.5 sm:gap-3 flex-wrap min-w-0">
        <div className="flex items-center gap-2 xs:gap-2.5 min-w-0 flex-1">
          <div className="p-1.5 xs:p-2 rounded-xl bg-purple-500/15 text-purple-300 border border-purple-500/30 shrink-0">
            <Award size={16} className="xs:w-[18px] xs:h-[18px]" />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-base sm:text-xl font-display font-bold text-white tracking-wide flex items-center gap-1.5 sm:gap-2 flex-wrap min-w-0">
              <span className="truncate">{isAr ? 'الأوسمة والإنجازات' : 'BADGES & ACHIEVEMENTS'}</span>
              <span className="text-[10px] sm:text-xs font-mono font-bold text-purple-300 bg-black/60 px-2.5 py-0.5 rounded-full border border-purple-500/30 shrink-0">
                {unlockedCount} / {totalCount}
              </span>
            </h2>
            <p className="text-[11px] xs:text-xs text-[#8db8b1] break-words [overflow-wrap:anywhere] mt-0.5">
              {isAr ? 'متزامنة فورياً مع تصرفاتك بالموقع وحزم البطاقات وتمنح عملات عند الاستلام' : 'Synced live with your website actions, card packs, and rewards coins upon claiming'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Link
            to="/achievements"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-[#5eead4] bg-[#5eead4]/10 hover:bg-[#5eead4]/20 border border-[#5eead4]/30 transition-all cursor-pointer shrink-0"
          >
            <Trophy size={13} className="shrink-0" />
            <span>{isAr ? 'لوحة الإنجازات الكاملة' : 'Full Showcase'}</span>
            <ArrowRight size={12} className={isAr ? 'rotate-180' : ''} />
          </Link>

          {isOwnProfile && (
            <button
              onClick={onOpenEdit}
              className="flex items-center gap-1.5 px-2.5 xs:px-3 py-1.5 rounded-xl text-xs font-semibold text-purple-300 bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 transition-all cursor-pointer shrink-0"
            >
              <Sparkles size={12} className="shrink-0" />
              <span>{isAr ? 'تحديد الأوسمة' : 'Feature'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Featured Badges Showcase */}
      {featuredBadges.length > 0 && (
        <div className="space-y-2.5 w-full min-w-0">
          <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
            <Sparkles size={12} className="shrink-0" />
            <span>{isAr ? 'الأوسمة المميزة على الملف' : 'FEATURED BADGES'}</span>
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 xs:gap-3 w-full min-w-0">
            {featuredBadges.map((badge) => {
              const theme = RARITY_THEMES[badge.rarity];
              const IconComponent = BADGE_ICONS[badge.icon] || Award;
              return (
                <div
                  key={badge.id}
                  className="p-3.5 rounded-2xl bg-black/50 border flex items-center gap-3 shadow-lg relative overflow-hidden group"
                  style={{ borderColor: theme.accent }}
                >
                  <div 
                    className="p-2.5 rounded-xl shrink-0 border"
                    style={{
                      background: `linear-gradient(135deg, ${theme.accent}20, transparent)`,
                      borderColor: `${theme.accent}60`,
                      color: theme.accent
                    }}
                  >
                    <IconComponent size={20} />
                  </div>

                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-white truncate">
                      {isAr ? badge.nameAr : badge.name}
                    </p>
                    <p className="text-[10px] text-[#8db8b1] line-clamp-1">
                      {isAr ? badge.descriptionAr : badge.description}
                    </p>
                    <span 
                      className="text-[9px] font-mono font-bold uppercase tracking-wider mt-0.5 inline-block"
                      style={{ color: theme.accent }}
                    >
                      {badge.rarity}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Synchronized Community & Card Vault Achievements Preview */}
      <div className="space-y-3 pt-1">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-[#5eead4] flex items-center gap-1.5">
            <Trophy size={13} />
            <span>{isAr ? 'الإنجازات المفتوحة والمكافآت المتزامنة' : 'SYNCED ACHIEVEMENTS & COIN REWARDS'}</span>
          </span>
          <span className="text-[10px] font-mono text-stone-400">
            {stats.totalClaimableCount > 0 ? (
              <span className="text-amber-300 font-bold bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-full">
                {stats.totalClaimableCount} {isAr ? 'مكافأة قابلة للاستلام' : 'Claimable'}
              </span>
            ) : null}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {visibleAchievements.slice(0, 9).map((ach) => {
            const isUnlocked = ach.isUnlocked;
            const isClaimed = ach.isClaimed;
            const reward = ach.calculatedReward || ach.baseReward;

            return (
              <div
                key={ach.definition.id}
                className={`p-3.5 rounded-2xl border transition-all flex flex-col justify-between gap-2.5 relative overflow-hidden ${
                  isUnlocked
                    ? 'bg-black/50 border-cyan-500/30 shadow-lg'
                    : 'bg-black/25 border-white/5 opacity-60'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className={`p-2 rounded-xl shrink-0 ${isUnlocked ? 'bg-cyan-500/15 text-[#5eead4] border border-cyan-500/30' : 'bg-stone-900 text-stone-600 border border-stone-800'}`}>
                      {isUnlocked ? <Trophy size={16} /> : <Lock size={16} />}
                    </div>
                    <div className="min-w-0">
                      <p className={`text-xs font-bold truncate ${isUnlocked ? 'text-white' : 'text-stone-400'}`}>
                        {isAr ? ach.definition.nameAr : ach.definition.name}
                      </p>
                      <p className="text-[10px] text-[#8db8b1] line-clamp-1">
                        {isAr ? ach.definition.descriptionAr : ach.definition.description}
                      </p>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30 shrink-0">
                    +{reward} 🪙
                  </span>
                </div>

                {/* Status Bar */}
                <div className="flex items-center justify-between pt-1 border-t border-white/5 text-[10px] font-mono">
                  {isUnlocked ? (
                    isClaimed ? (
                      <span className="text-emerald-400 flex items-center gap-1 font-bold">
                        <Check size={11} /> {isAr ? 'تم استلام العملات' : 'Coins Claimed'}
                      </span>
                    ) : isOwnProfile ? (
                      <button
                        type="button"
                        onClick={async (e) => {
                          e.preventDefault();
                          await claimReward(ach.definition.id);
                        }}
                        className="text-amber-300 hover:text-amber-200 flex items-center gap-1 font-bold px-2 py-0.5 rounded bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 cursor-pointer active:scale-95 transition-all"
                      >
                        <Coins size={11} />
                        <span>{isAr ? 'استلم العملات' : 'Claim Coins'}</span>
                      </button>
                    ) : (
                      <span className="text-amber-300 flex items-center gap-1 font-bold">
                        <Sparkles size={11} /> {isAr ? 'مفتوح' : 'Unlocked'}
                      </span>
                    )
                  ) : (
                    <span className="text-stone-500 flex items-center gap-1">
                      <Lock size={10} /> {ach.currentProgress} / {ach.maxProgress} {isAr ? ach.definition.unitAr : ach.definition.unit}
                    </span>
                  )}

                  <Link to="/achievements" className="text-cyan-400 hover:text-cyan-300 text-[10px] underline">
                    {isAr ? 'عرض' : 'View'}
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* All Badges Catalog */}
      <div className="space-y-2.5 pt-2">
        <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-[#8db8b1]">
          {isAr ? 'سجل أوسمة الملاذ' : 'ALL SANCTUARY EMBLEMS'}
        </span>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {allBadges.map((badge) => {
            const isUnlocked = unlockedBadgeIdsSet.has(badge.id);
            const theme = RARITY_THEMES[badge.rarity];
            const IconComponent = BADGE_ICONS[badge.icon] || Award;
            const isFeatured = featuredBadgeIds.includes(badge.id);

            return (
              <div
                key={badge.id}
                className={`p-3 rounded-2xl border transition-all flex items-start gap-3 relative overflow-hidden ${
                  isUnlocked
                    ? 'bg-black/40 hover:bg-black/60 border-[rgba(158,255,230,0.18)]'
                    : 'bg-black/20 border-white/5 opacity-50'
                }`}
              >
                <div 
                  className={`p-2 rounded-xl shrink-0 border ${
                    isUnlocked ? 'text-white' : 'text-zinc-600 bg-zinc-900 border-zinc-800'
                  }`}
                  style={isUnlocked ? {
                    background: `${theme.accent}15`,
                    borderColor: `${theme.accent}40`,
                    color: theme.accent
                  } : undefined}
                >
                  {isUnlocked ? <IconComponent size={18} /> : <Lock size={18} />}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1">
                    <p className="text-xs font-bold text-white truncate">
                      {isAr ? badge.nameAr : badge.name}
                    </p>
                    {isFeatured && (
                      <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                        {isAr ? 'مميز' : 'STAR'}
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-[#8db8b1] leading-relaxed mt-0.5">
                    {isAr ? badge.descriptionAr : badge.description}
                  </p>
                  <span 
                    className="text-[9px] font-mono font-bold uppercase tracking-wider mt-1 inline-block"
                    style={{ color: isUnlocked ? theme.accent : '#71717a' }}
                  >
                    {badge.rarity}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
