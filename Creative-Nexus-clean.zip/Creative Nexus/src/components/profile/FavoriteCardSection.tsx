import React from 'react';
import { CollectibleCardData } from '../../types/cards';
import { CollectibleCard, RARITY_THEMES } from '../cards/CollectibleCard';
import { Star, Sparkles, Plus, Edit2 } from 'lucide-react';
import { motion } from 'motion/react';

interface FavoriteCardSectionProps {
  favoriteCard: CollectibleCardData | null;
  isOwnProfile: boolean;
  onOpenEdit: () => void;
  onClickDetail: (card: CollectibleCardData) => void;
  isAr?: boolean;
}

export const FavoriteCardSection: React.FC<FavoriteCardSectionProps> = ({
  favoriteCard,
  isOwnProfile,
  onOpenEdit,
  onClickDetail,
  isAr = false,
}) => {
  const rarityTheme = favoriteCard ? RARITY_THEMES[favoriteCard.rarity] : null;

  return (
    <div className="relative rounded-2xl sm:rounded-3xl bg-gradient-to-b from-[#061c1a]/90 via-[#031312]/95 to-[#020b0a]/98 border border-[rgba(158,255,230,0.16)] p-3.5 xs:p-4 sm:p-7 shadow-xl overflow-hidden w-full max-w-full min-w-0 box-border">
      {/* Subtle ambient aura */}
      {rarityTheme && (
        <div 
          className="absolute top-1/2 start-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full blur-[100px] pointer-events-none opacity-20"
          style={{ background: rarityTheme.accent }}
        />
      )}

      {/* Section Header */}
      <div className="flex items-center justify-between gap-2.5 sm:gap-3 mb-4 sm:mb-6 relative z-10 flex-wrap min-w-0">
        <div className="flex items-center gap-2 xs:gap-2.5 min-w-0 flex-1">
          <div className="p-1.5 xs:p-2 rounded-xl bg-amber-500/15 text-amber-300 border border-amber-500/30 shrink-0">
            <Star size={16} className="fill-amber-400 text-amber-400 xs:w-[18px] xs:h-[18px]" />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-base sm:text-xl font-display font-bold text-white tracking-wide flex items-center gap-1.5 sm:gap-2 flex-wrap min-w-0">
              <span className="truncate">{isAr ? 'البطاقة المفضلة' : 'FAVORITE CARD'}</span>
              {favoriteCard && (
                <span 
                  className={`text-[9px] xs:text-[10px] font-mono font-bold px-1.5 xs:px-2 py-0.5 rounded-full border shrink-0 ${rarityTheme?.badge}`}
                >
                  {favoriteCard.rarity}
                </span>
              )}
            </h2>
            <p className="text-[11px] xs:text-xs text-[#8db8b1] break-words [overflow-wrap:anywhere] mt-0.5">
              {isAr ? 'البطاقة الرمزية المتوجة لهوية اللاعب' : 'The pinnacle relic representing your collector identity'}
            </p>
          </div>
        </div>

        {isOwnProfile && (
          <button
            onClick={onOpenEdit}
            className="flex items-center gap-1.5 px-2.5 xs:px-3 py-1.5 rounded-xl text-xs font-semibold text-[#5eead4] bg-[#5eead4]/10 hover:bg-[#5eead4]/20 border border-[#5eead4]/30 transition-all cursor-pointer shrink-0"
          >
            <Edit2 size={12} className="shrink-0" />
            <span>{favoriteCard ? (isAr ? 'تغيير' : 'Change') : (isAr ? 'اختيار' : 'Select')}</span>
          </button>
        )}
      </div>

      {/* Card Container */}
      <div className="relative z-10 flex flex-col md:flex-row items-center justify-center gap-5 sm:gap-6 py-1 sm:py-2 w-full min-w-0">
        {favoriteCard ? (
          <div className="flex flex-col sm:flex-row items-center gap-5 sm:gap-6 max-w-2xl w-full min-w-0 justify-center">
            {/* The actual CollectibleCard component reused */}
            <div className="w-full max-w-[270px] xs:max-w-[285px] sm:max-w-[300px] shrink-0 transition-transform duration-300 hover:scale-[1.02]">
              <CollectibleCard
                card={favoriteCard}
                isOwned={true}
                onClickDetail={onClickDetail}
                size="large"
                disableScrollTilt={true}
              />
            </div>

            {/* Flavor lore and details column */}
            <div className="space-y-2.5 sm:space-y-3.5 text-center sm:text-start max-w-md w-full min-w-0">
              <div className="inline-flex items-center gap-1.5 px-2.5 xs:px-3 py-1 rounded-full text-[10px] xs:text-[11px] font-mono font-bold bg-black/60 text-amber-300 border border-amber-500/30 max-w-full break-words">
                <Sparkles size={12} className="shrink-0" />
                <span className="truncate">{favoriteCard.title || favoriteCard.name}</span>
              </div>

              <h3 className="text-lg xs:text-xl sm:text-2xl font-display font-black text-white break-words [overflow-wrap:anywhere]">
                {favoriteCard.name}
              </h3>

              {favoriteCard.lore ? (
                <p className="text-xs sm:text-sm text-[#8db8b1] leading-relaxed italic border-s-2 border-amber-500/40 ps-3 break-words [overflow-wrap:anywhere]">
                  "{favoriteCard.lore}"
                </p>
              ) : favoriteCard.description ? (
                <p className="text-xs sm:text-sm text-[#8db8b1] leading-relaxed break-words [overflow-wrap:anywhere]">
                  {favoriteCard.description}
                </p>
              ) : null}

              <div className="pt-2 flex flex-wrap items-center justify-center sm:justify-start gap-2 w-full min-w-0">
                <button
                  onClick={() => onClickDetail(favoriteCard)}
                  className="w-full sm:w-auto px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-teal-700/60 to-cyan-700/60 hover:from-teal-600/70 hover:to-cyan-600/70 border border-cyan-500/30 transition-all shadow-md cursor-pointer"
                >
                  {isAr ? 'عرض تفاصيل البطاقة' : 'Inspect Card Details'}
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Empty placeholder state */
          <div className="w-full py-12 px-4 rounded-2xl border-2 border-dashed border-[rgba(158,255,230,0.18)] bg-black/30 flex flex-col items-center justify-center text-center space-y-3">
            <div className="w-16 h-16 rounded-2xl bg-[#0a2624] border border-[#5eead4]/25 flex items-center justify-center text-amber-300">
              <Star size={28} className="opacity-60" />
            </div>
            <div className="space-y-1">
              <p className="text-sm font-bold text-white">
                {isAr ? 'لم يتم تعيين بطاقة مفضلة بعد' : 'No Favorite Card Selected'}
              </p>
              <p className="text-xs text-[#8db8b1] max-w-sm">
                {isAr 
                  ? 'اختر بطاقتك الأثمن من مجموعتك لتتصدر ملفك الشخصي أمام الجميع.'
                  : 'Crown your favorite owned card to showcase it prominently at the top of your player identity.'}
              </p>
            </div>
            {isOwnProfile && (
              <button
                onClick={onOpenEdit}
                className="mt-2 flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-amber-200 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 transition-all cursor-pointer shadow-lg"
              >
                <Plus size={14} />
                <span>{isAr ? 'اختر من مجموعتك الآن' : 'Choose from Collection'}</span>
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
