import React from 'react';
import { PlayerTitle } from '../../types/progression';
import { RARITY_THEMES } from '../cards/CollectibleCard';
import { Award, Check, Lock } from 'lucide-react';

interface TitlesSectionProps {
  unlockedTitles: PlayerTitle[];
  allTitles: PlayerTitle[];
  selectedTitleId: string | null;
  isOwnProfile: boolean;
  onSelectTitle?: (titleId: string) => void;
  isAr?: boolean;
}

export const TitlesSection: React.FC<TitlesSectionProps> = ({
  unlockedTitles,
  allTitles,
  selectedTitleId,
  isOwnProfile,
  onSelectTitle,
  isAr = false,
}) => {
  const unlockedIds = new Set(unlockedTitles.map(t => t.id));

  return (
    <div className="rounded-2xl sm:rounded-3xl bg-gradient-to-b from-[#061c1a]/90 via-[#031312]/95 to-[#020b0a]/98 border border-[rgba(158,255,230,0.16)] p-3.5 xs:p-4 sm:p-7 shadow-xl space-y-4 sm:space-y-6 w-full max-w-full min-w-0 box-border overflow-hidden">
      <div className="flex items-center justify-between gap-2.5 sm:gap-3 flex-wrap min-w-0">
        <div className="flex items-center gap-2 xs:gap-2.5 min-w-0 flex-1">
          <div className="p-1.5 xs:p-2 rounded-xl bg-amber-500/15 text-amber-300 border border-amber-500/30 shrink-0">
            <Award size={16} className="xs:w-[18px] xs:h-[18px]" />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-base sm:text-xl font-display font-bold text-white tracking-wide flex items-center gap-1.5 sm:gap-2 flex-wrap min-w-0">
              <span className="truncate">{isAr ? 'الألقاب الملكية المكتسبة' : 'UNLOCKED TITLES'}</span>
              <span className="text-[10px] sm:text-xs font-mono font-bold text-amber-300 bg-black/60 px-2 py-0.5 rounded-full border border-amber-500/30 shrink-0">
                {unlockedTitles.length} / {allTitles.length}
              </span>
            </h2>
            <p className="text-[11px] xs:text-xs text-[#8db8b1] break-words [overflow-wrap:anywhere] mt-0.5">
              {isAr ? 'الألقاب المتاحة للعرض أسفل اسمك في جميع أنحاء الموقع' : 'Honorary titles unlockable and selectable to crown your name'}
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 xs:gap-3 sm:gap-4 w-full min-w-0">
        {allTitles.map((title) => {
          const isUnlocked = unlockedIds.has(title.id);
          const isSelected = selectedTitleId === title.id;
          const theme = RARITY_THEMES[title.rarity];

          return (
            <div
              key={title.id}
              className={`p-4 rounded-2xl border transition-all flex flex-col justify-between space-y-3 relative overflow-hidden ${
                isSelected
                  ? 'bg-gradient-to-br from-amber-500/15 to-black/60 shadow-lg shadow-amber-500/10'
                  : isUnlocked
                  ? 'bg-black/45 hover:bg-black/65 border-[rgba(158,255,230,0.18)]'
                  : 'bg-black/20 border-white/5 opacity-55'
              }`}
              style={{
                borderColor: isSelected ? theme.accent : undefined
              }}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span
                    className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-md"
                    style={{
                      background: isUnlocked ? `${theme.accent}20` : '#27272a',
                      color: isUnlocked ? theme.accent : '#71717a'
                    }}
                  >
                    {title.rarity}
                  </span>

                  {isSelected ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/40">
                      <Check size={10} />
                      <span>{isAr ? 'مفعل' : 'EQUIPPED'}</span>
                    </span>
                  ) : !isUnlocked ? (
                    <span className="text-[10px] font-mono text-zinc-500 flex items-center gap-1">
                      <Lock size={11} />
                      <span>{isAr ? 'مقفل' : 'LOCKED'}</span>
                    </span>
                  ) : null}
                </div>

                <h3 className="text-sm font-bold text-white tracking-wide">
                  {isAr ? title.nameAr : title.name}
                </h3>

                <p className="text-xs text-[#8db8b1] mt-1 leading-relaxed">
                  {isAr ? title.descriptionAr : title.description}
                </p>
              </div>

              {/* Equip Action button if own profile and unlocked */}
              {isOwnProfile && isUnlocked && !isSelected && onSelectTitle && (
                <button
                  onClick={() => onSelectTitle(title.id)}
                  className="w-full mt-2 py-1.5 px-3 rounded-xl text-xs font-semibold text-[#5eead4] bg-[#5eead4]/10 hover:bg-[#5eead4]/20 border border-[#5eead4]/30 transition-all cursor-pointer text-center"
                >
                  {isAr ? 'اختيار هذا اللقب' : 'Equip Title'}
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
