import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  Crown, 
  ShieldCheck, 
  Sparkles, 
  Check, 
  RefreshCw, 
  ArrowRight, 
  UserCheck, 
  AlertCircle,
  HelpCircle,
  Settings
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const OwnerModeratorRoleSelector: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const { 
    user, 
    role, 
    moderatorRoleConfig, 
    updateModeratorRoleConfig, 
    setIsLoginModalOpen,
    hasPermission 
  } = useAuth();

  const isOwner = role === 'OWNER' || user?.isGuildOwner || user?.discordId === '871043296280076308';
  
  const currentConfiguredRole = moderatorRoleConfig?.moderatorRoleName || 'admin';
  const [selectedRole, setSelectedRole] = useState(currentConfiguredRole);
  const [isCustom, setIsCustom] = useState(false);
  const [customInput, setCustomInput] = useState('');
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Live Simulator state
  const [simulatorRoleInput, setSimulatorRoleInput] = useState('admin');
  const [simulatedAccountName, setSimulatedAccountName] = useState('Yousef');

  useEffect(() => {
    if (moderatorRoleConfig?.moderatorRoleName) {
      setSelectedRole(moderatorRoleConfig.moderatorRoleName);
    }
  }, [moderatorRoleConfig?.moderatorRoleName]);

  const handleSaveRole = async (roleNameToSave: string) => {
    const roleToSet = roleNameToSave.trim().toLowerCase();
    if (!roleToSet) return;

    setSaving(true);
    setFeedback(null);
    try {
      const res = await updateModeratorRoleConfig(roleToSet);
      if (res.success) {
        setSelectedRole(roleToSet);
        setFeedback({
          type: 'success',
          message: `Success! Discord role "${roleToSet}" is now configured. Any account with this role (e.g. Yousef) will receive the Moderator view.`
        });
      } else {
        setFeedback({
          type: 'error',
          message: res.message || 'Failed to update role configuration'
        });
      }
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: err.message || 'Error updating configuration'
      });
    } finally {
      setSaving(false);
    }
  };

  // Evaluate simulator live
  const normalizedSimInput = simulatorRoleInput.trim().toLowerCase();
  const normalizedConfigured = currentConfiguredRole.trim().toLowerCase();
  const isSimulatedModerator = normalizedSimInput === normalizedConfigured || 
    (moderatorRoleConfig?.moderatorRoleNames || []).map(r => r.toLowerCase()).includes(normalizedSimInput);

  return (
    <div id="owner-moderator-role-selector" className="w-full rounded-2xl border border-amber-500/30 bg-archive-dark/80 backdrop-blur-xl p-5 shadow-xl relative overflow-hidden">
      {/* Subtle sovereign ambient glow */}
      <div className="absolute top-0 end-0 w-64 h-32 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-amber-500/20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
            <Crown size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-archive-paper">
                Owner Control: Choose Moderator Discord Role
              </h3>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                SOVEREIGN
              </span>
            </div>
            <p className="text-xs text-archive-paper-muted">
              Choose which Discord role grants the account logging in the <span className="text-indigo-400 font-semibold">Moderator view</span> of the website.
            </p>
          </div>
        </div>

        {/* Current Active Badge */}
        <div className="flex items-center gap-2 self-start sm:self-auto px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30">
          <span className="text-[11px] text-archive-paper-muted">Active Moderator Role:</span>
          <span className="text-xs font-mono font-bold text-amber-300 px-2 py-0.5 rounded-md bg-amber-500/20 border border-amber-500/30">
            {currentConfiguredRole}
          </span>
        </div>
      </div>

      {/* Role Selection Options */}
      <div className="mt-4 space-y-4">
        <div>
          <label className="block text-xs font-medium text-archive-paper mb-2">
            Select or enter the Discord role that unlocks Moderator permissions:
          </label>
          
          <div className="flex flex-wrap gap-2">
            {/* 1. admin (Yousef's role - the explicit example) */}
            <button
              id="role-preset-admin"
              type="button"
              disabled={saving}
              onClick={() => {
                setSelectedRole('admin');
                setIsCustom(false);
                handleSaveRole('admin');
              }}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${
                selectedRole === 'admin'
                  ? 'bg-amber-500 text-archive-dark font-bold shadow-lg shadow-amber-500/20'
                  : 'bg-archive-dark/60 text-archive-paper border border-archive-cyan/20 hover:border-amber-500/50 hover:bg-amber-500/10'
              }`}
            >
              <ShieldCheck size={15} />
              <span>admin</span>
              <span className="text-[10px] opacity-80 font-normal">
                (Yousef's role)
              </span>
              {selectedRole === 'admin' && <Check size={14} className="ms-1" />}
            </button>

            {/* 2. moderator */}
            <button
              id="role-preset-moderator"
              type="button"
              disabled={saving}
              onClick={() => {
                setSelectedRole('moderator');
                setIsCustom(false);
                handleSaveRole('moderator');
              }}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${
                selectedRole === 'moderator'
                  ? 'bg-amber-500 text-archive-dark font-bold shadow-lg shadow-amber-500/20'
                  : 'bg-archive-dark/60 text-archive-paper border border-archive-cyan/20 hover:border-amber-500/50 hover:bg-amber-500/10'
              }`}
            >
              <ShieldCheck size={15} />
              <span>moderator</span>
              {selectedRole === 'moderator' && <Check size={14} className="ms-1" />}
            </button>

            {/* 3. staff */}
            <button
              id="role-preset-staff"
              type="button"
              disabled={saving}
              onClick={() => {
                setSelectedRole('staff');
                setIsCustom(false);
                handleSaveRole('staff');
              }}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${
                selectedRole === 'staff'
                  ? 'bg-amber-500 text-archive-dark font-bold shadow-lg shadow-amber-500/20'
                  : 'bg-archive-dark/60 text-archive-paper border border-archive-cyan/20 hover:border-amber-500/50 hover:bg-amber-500/10'
              }`}
            >
              <ShieldCheck size={15} />
              <span>staff</span>
              {selectedRole === 'staff' && <Check size={14} className="ms-1" />}
            </button>

            {/* Custom Input Toggle */}
            <button
              id="role-preset-custom-toggle"
              type="button"
              onClick={() => setIsCustom(!isCustom)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${
                isCustom || (!['admin', 'moderator', 'staff'].includes(selectedRole))
                  ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                  : 'bg-archive-dark/60 text-archive-paper-muted border border-archive-cyan/20 hover:text-archive-paper'
              }`}
            >
              <Settings size={14} />
              <span>Custom Role Name...</span>
            </button>
          </div>
        </div>

        {/* Custom Role Input Field */}
        <AnimatePresence>
          {(isCustom || (!['admin', 'moderator', 'staff'].includes(selectedRole))) && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="flex items-center gap-2 pt-1"
            >
              <input
                id="custom-moderator-role-input"
                type="text"
                placeholder="e.g. trial_mod, senior_staff, guard..."
                value={customInput}
                onChange={(e) => setCustomInput(e.target.value)}
                className="flex-1 max-w-sm px-3.5 py-2 rounded-xl bg-archive-dark/90 border border-amber-500/40 text-archive-paper text-xs placeholder:text-archive-paper-muted/50 focus:outline-none focus:border-amber-400 font-mono"
              />
              <button
                id="save-custom-role-btn"
                type="button"
                disabled={saving || !customInput.trim()}
                onClick={() => {
                  if (customInput.trim()) {
                    handleSaveRole(customInput.trim());
                  }
                }}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-archive-dark font-bold text-xs flex items-center gap-1.5 transition-all disabled:opacity-50"
              >
                {saving ? <RefreshCw size={14} className="animate-spin" /> : <Check size={14} />}
                <span>Set as Moderator Role</span>
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Feedback Alert */}
        {feedback && (
          <div className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
            feedback.type === 'success' 
              ? 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-300' 
              : 'bg-rose-500/15 border border-rose-500/30 text-rose-300'
          }`}>
            <AlertCircle size={15} className="shrink-0" />
            <span>{feedback.message}</span>
          </div>
        )}

        {/* Live Discovery Simulator & Interactive Testing */}
        <div className="mt-4 pt-4 border-t border-amber-500/15 bg-archive-dark/50 rounded-xl p-4 border border-archive-cyan/10">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Sparkles size={16} className="text-amber-400" />
              <span className="text-xs font-bold text-archive-paper uppercase tracking-wider">
                Live Login Discovery Simulator
              </span>
            </div>
            <span className="text-[11px] text-archive-paper-muted">
              Simulate any Discord login against the Owner's choice
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
            {/* Left: Input tester */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-xs text-archive-paper-muted w-24">Discord User:</span>
                <input
                  id="sim-user-name"
                  type="text"
                  value={simulatedAccountName}
                  onChange={(e) => setSimulatedAccountName(e.target.value)}
                  className="flex-1 px-3 py-1.5 rounded-lg bg-archive-dark border border-archive-cyan/20 text-archive-paper text-xs"
                  placeholder="e.g. Yousef"
                />
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-archive-paper-muted w-24">Discord Role:</span>
                <input
                  id="sim-role-name"
                  type="text"
                  value={simulatorRoleInput}
                  onChange={(e) => setSimulatorRoleInput(e.target.value)}
                  className="flex-1 px-3 py-1.5 rounded-lg bg-archive-dark border border-archive-cyan/20 text-archive-paper text-xs font-mono"
                  placeholder="e.g. admin"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <span className="text-[10px] text-archive-paper-muted">Quick test:</span>
                <button
                  type="button"
                  onClick={() => {
                    setSimulatedAccountName('Yousef');
                    setSimulatorRoleInput('admin');
                  }}
                  className="text-[10px] px-2 py-0.5 rounded bg-archive-cyan/10 hover:bg-archive-cyan/20 text-archive-cyan"
                >
                  Yousef (admin)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSimulatedAccountName('Omar');
                    setSimulatorRoleInput('moderator');
                  }}
                  className="text-[10px] px-2 py-0.5 rounded bg-archive-cyan/10 hover:bg-archive-cyan/20 text-archive-cyan"
                >
                  Omar (moderator)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSimulatedAccountName('Citizen');
                    setSimulatorRoleInput('member');
                  }}
                  className="text-[10px] px-2 py-0.5 rounded bg-archive-cyan/10 hover:bg-archive-cyan/20 text-archive-cyan"
                >
                  Citizen (member)
                </button>
              </div>
            </div>

            {/* Right: Discovered Result Card */}
            <div className={`p-3.5 rounded-xl border transition-all ${
              isSimulatedModerator
                ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-200'
                : 'bg-emerald-500/10 border-emerald-500/40 text-emerald-200'
            }`}>
              <div className="text-[10px] uppercase font-bold tracking-wider mb-1 opacity-70">
                Discovery Outcome for {simulatedAccountName}:
              </div>
              <div className="flex items-center gap-2 mb-1.5">
                {isSimulatedModerator ? (
                  <>
                    <span className="px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 font-bold font-mono text-xs border border-indigo-500/40">
                      🛡️ A MODERATOR
                    </span>
                    <span className="text-xs font-semibold text-archive-paper">
                      Gets Moderator View
                    </span>
                  </>
                ) : (
                  <>
                    <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 font-bold font-mono text-xs border border-emerald-500/40">
                      👤 A NORMAL MEMBER
                    </span>
                    <span className="text-xs font-semibold text-archive-paper">
                      Gets Normal Member View
                    </span>
                  </>
                )}
              </div>
              <p className="text-[11px] leading-relaxed text-archive-paper-muted">
                {isSimulatedModerator ? (
                  <>
                    Role <strong className="text-archive-paper font-mono">"{simulatorRoleInput}"</strong> matches the Owner's chosen role <strong className="text-amber-300 font-mono">"{currentConfiguredRole}"</strong>. Full moderator and point controls granted.
                  </>
                ) : (
                  <>
                    Role <strong className="text-archive-paper font-mono">"{simulatorRoleInput}"</strong> does NOT match Owner's chosen role <strong className="text-amber-300 font-mono">"{currentConfiguredRole}"</strong>. Account is discovered as a normal verified citizen.
                  </>
                )}
              </p>
            </div>
          </div>

          {/* Discord OAuth2 Login verification */}
          <div className="mt-3 pt-3 border-t border-archive-cyan/10 flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs text-archive-paper-muted">
              Authenticate via Discord OAuth2 to test the configured moderator view:
            </span>
            <button
              id="test-login-yousef-btn"
              type="button"
              onClick={() => setIsLoginModalOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/40 text-xs font-medium flex items-center gap-1.5 transition-all"
            >
              <UserCheck size={14} />
              <span>Login with Discord (OAuth2)</span>
              <ArrowRight size={13} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
