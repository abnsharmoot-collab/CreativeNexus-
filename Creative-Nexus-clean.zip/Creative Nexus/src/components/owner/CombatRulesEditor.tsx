import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useCombat } from '../../context/CombatContext';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { 
  CombatActionType, 
  CombatSkillDefinition, 
  DEFAULT_COMBAT_SKILLS, 
  MatchupCellRule,
  COMBAT_PRESETS
} from '../../types/combatRules';
import { 
  Shield, 
  Swords, 
  Flame, 
  Zap, 
  Sparkles, 
  Sliders, 
  Grid3X3, 
  Plus, 
  Trash2, 
  RotateCcw, 
  Save, 
  AlertTriangle, 
  Check, 
  Layers, 
  Lock, 
  Eye, 
  X,
  Gauge,
  HelpCircle
} from 'lucide-react';

interface CombatRulesEditorProps {
  onClose?: () => void;
}

export const CombatRulesEditor: React.FC<CombatRulesEditorProps> = ({ onClose }) => {
  const { rules, updateRules, applyPreset, saveSkill, deleteSkill, resetToDefaults, activePreset } = useCombat();
  const { isOwner, isAdmin, user } = useAuth();
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const [activeTab, setActiveTab] = useState<'ACTIONS' | 'MATRIX' | 'SKILLS' | 'RESOURCES'>('ACTIONS');
  const [selectedCellKey, setSelectedCellKey] = useState<string | null>(null);
  const [isEditingSkill, setIsEditingSkill] = useState(false);
  const [skillForm, setSkillForm] = useState<CombatSkillDefinition>(DEFAULT_COMBAT_SKILLS[0]);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Permission level check
  const permissionLevel = useMemo(() => {
    if (isOwner) return 'OWNER';
    if (isAdmin) return 'ADMIN';
    return 'PLAYER';
  }, [isOwner, isAdmin]);

  const canEdit = permissionLevel === 'OWNER' || permissionLevel === 'ADMIN';

  // Anti-Overpower system validation for current skill in editor
  const antiOverpowerWarnings = useMemo(() => {
    const warnings: string[] = [];
    if (skillForm.damage > 60) {
      warnings.push(isAr ? 'تنبيه: الضرر يتجاوز الحد الموصى به (60 نقطة)' : '⚠ HIGH DAMAGE: Ability damage exceeds recommended maximum (60).');
    }
    if (skillForm.cooldown <= 0 && skillForm.damage > 15) {
      warnings.push(isAr ? 'تنبيه: قدرة هجومية بدون فترة انتظار (Cooldown 0)' : '⚠ NO COOLDOWN: Damaging skills must have at least 1 turn cooldown.');
    }
    if (skillForm.energyCost <= 0 && skillForm.damage > 20) {
      warnings.push(isAr ? 'تنبيه: مهارة قوية بدون استهلاك طاقة' : '⚠ FREE ENERGY: High damage skills must consume energy.');
    }
    if (skillForm.priority === 3 && skillForm.energyCost < 30) {
      warnings.push(isAr ? 'تنبيه: المهارات الخارقة (Priority 3) تتطلب 30 طاقة على الأقل' : '⚠ UNDERPRICED ULTIMATE: Priority 3 ultimates require 30+ energy.');
    }
    if (skillForm.effects.stun && skillForm.damage > 30) {
      warnings.push(isAr ? 'تنبيه: تجميد + ضرر مرتفع قد يكسر التوازن' : '⚠ OVERPOWERED COMBO: Stun + High Damage exceeds balance threshold.');
    }
    return warnings;
  }, [skillForm, isAr]);

  const handleApplyPreset = async (preset: string) => {
    if (!canEdit) return;
    setIsSaving(true);
    await applyPreset(preset);
    setIsSaving(false);
  };

  const handleSaveActionSetting = async (action: 'STRIKE' | 'HEAVY' | 'DEFENSE', field: string, val: number) => {
    if (!canEdit) return;
    const currentAction = { ...rules.actions[action], [field]: val };
    await updateRules({
      actions: {
        ...rules.actions,
        [action]: currentAction
      }
    });
  };

  const handleUpdateMatrixCell = async (cellKey: string, rule: MatchupCellRule) => {
    if (!canEdit) return;
    const updatedMatrix = {
      ...rules.matchupMatrix,
      [cellKey]: rule
    };
    await updateRules({ matchupMatrix: updatedMatrix as any });
    setSelectedCellKey(null);
  };

  const handleSaveSkillForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canEdit) return;
    setIsSaving(true);
    await saveSkill(skillForm);
    setIsSaving(false);
    setIsEditingSkill(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  return (
    <div className="w-full max-w-6xl mx-auto p-3 sm:p-6 space-y-6 select-none" dir={isAr ? 'rtl' : 'ltr'}>
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl bg-slate-900/90 border border-cyan-500/30 shadow-2xl backdrop-blur-xl">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="text-cyan-400" size={24} />
            <h1 className="text-xl sm:text-2xl font-black font-sans text-white tracking-wide">
              {isAr ? 'لوحة المالك · نظام القتال التكتيكي' : 'Owner Dashboard · Combat System'}
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            {isAr 
              ? 'تخصيص قواعد الاشتباك الـ 4، منظومة الـ RPS، استهلاك التحمل والطاقة، والمهارات الخارقة' 
              : 'Customize the 4-action combat model, circular counters, stamina & energy, and skill editor.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Permission badge */}
          <span className={`px-2.5 py-1 rounded-full text-[10px] font-mono font-bold flex items-center gap-1 border ${
            permissionLevel === 'OWNER' 
              ? 'bg-amber-950/80 border-amber-400 text-amber-200' 
              : permissionLevel === 'ADMIN' 
                ? 'bg-purple-950/80 border-purple-400 text-purple-200' 
                : 'bg-slate-800 border-slate-700 text-slate-400'
          }`}>
            <Lock size={11} />
            <span>{permissionLevel}</span>
          </span>

          {/* Reset to defaults (Owner only) */}
          {isOwner && (
            <button
              onClick={() => {
                if (window.confirm(isAr ? 'هل تريد استعادة الإعدادات الافتراضية للقتال؟' : 'Reset all combat rules to default?')) {
                  resetToDefaults();
                }
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-xs font-mono text-slate-300 flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <RotateCcw size={12} />
              <span>{isAr ? 'استعادة الافتراضي' : 'Reset'}</span>
            </button>
          )}

          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer"
            >
              <X size={18} />
            </button>
          )}
        </div>
      </div>

      {/* Preset Selector Banner */}
      <div className="p-3.5 rounded-xl bg-slate-950/80 border border-cyan-500/20 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs font-mono font-bold text-cyan-300">
          <Layers size={15} />
          <span>{isAr ? 'أنماط التوازن الجاهزة (Presets):' : 'Combat Balance Presets:'}</span>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {Object.keys(COMBAT_PRESETS).map(preset => (
            <button
              key={preset}
              disabled={!canEdit || isSaving}
              onClick={() => handleApplyPreset(preset)}
              className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
                activePreset === preset
                  ? 'bg-cyan-500 text-slate-950 shadow-[0_0_12px_rgba(94,234,212,0.8)]'
                  : 'bg-slate-900 border border-slate-700 text-slate-300 hover:border-cyan-400/60'
              }`}
            >
              {preset}
            </button>
          ))}
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-white/10 gap-2 pb-1 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab('ACTIONS')}
          className={`px-4 py-2 rounded-t-xl text-xs sm:text-sm font-mono font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'ACTIONS'
              ? 'bg-cyan-950/70 border-b-2 border-cyan-400 text-cyan-200'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Swords size={16} />
          <span>{isAr ? '1. إعدادات الحركات (Actions)' : '1. Action Settings'}</span>
        </button>

        <button
          onClick={() => setActiveTab('MATRIX')}
          className={`px-4 py-2 rounded-t-xl text-xs sm:text-sm font-mono font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'MATRIX'
              ? 'bg-cyan-950/70 border-b-2 border-cyan-400 text-cyan-200'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Grid3X3 size={16} />
          <span>{isAr ? '2. مصفوفة الاشتباك (Matrix)' : '2. Matchup Matrix'}</span>
        </button>

        <button
          onClick={() => setActiveTab('SKILLS')}
          className={`px-4 py-2 rounded-t-xl text-xs sm:text-sm font-mono font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'SKILLS'
              ? 'bg-cyan-950/70 border-b-2 border-cyan-400 text-cyan-200'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Sparkles size={16} />
          <span>{isAr ? '3. صانع المهارات (Skill Creator)' : '3. Skill Creator'}</span>
        </button>

        <button
          onClick={() => setActiveTab('RESOURCES')}
          className={`px-4 py-2 rounded-t-xl text-xs sm:text-sm font-mono font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'RESOURCES'
              ? 'bg-cyan-950/70 border-b-2 border-cyan-400 text-cyan-200'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Gauge size={16} />
          <span>{isAr ? '4. التحمل والطاقة (Stamina & Energy)' : '4. Stamina & Energy'}</span>
        </button>
      </div>

      {/* 
        ========================================================================
        TAB 1: ACTION SETTINGS (STRIKE, HEAVY, DEFENSE)
        ========================================================================
      */}
      {activeTab === 'ACTIONS' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* STRIKE CARD */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-cyan-500/40 space-y-3 shadow-xl">
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Swords className="text-cyan-400" size={20} />
                <span className="font-black text-sm text-cyan-200">STRIKE</span>
              </div>
              <span className="text-[10px] font-mono text-cyan-300/80">Fast · Low Cost · Interrupts Heavy</span>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div>
                <label className="text-slate-400 block mb-0.5">Base Damage (HP)</label>
                <input
                  type="number"
                  disabled={!canEdit}
                  value={rules.actions.STRIKE.damage}
                  onChange={(e) => handleSaveActionSetting('STRIKE', 'damage', Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-0.5">Stamina Cost</label>
                <input
                  type="number"
                  disabled={!canEdit}
                  value={rules.actions.STRIKE.staminaCost}
                  onChange={(e) => handleSaveActionSetting('STRIKE', 'staminaCost', Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-0.5">Energy Generated (+NRG)</label>
                <input
                  type="number"
                  disabled={!canEdit}
                  value={rules.actions.STRIKE.energyDelta}
                  onChange={(e) => handleSaveActionSetting('STRIKE', 'energyDelta', Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-0.5">Startup Duration (seconds)</label>
                <input
                  type="number"
                  step="0.05"
                  disabled={!canEdit}
                  value={rules.actions.STRIKE.startupSeconds}
                  onChange={(e) => handleSaveActionSetting('STRIKE', 'startupSeconds', Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>
            </div>
          </div>

          {/* HEAVY CARD */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-amber-500/40 space-y-3 shadow-xl">
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Flame className="text-amber-400" size={20} />
                <span className="font-black text-sm text-amber-200">HEAVY</span>
              </div>
              <span className="text-[10px] font-mono text-amber-300/80">High Dmg · Breaks Defense</span>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div>
                <label className="text-slate-400 block mb-0.5">Base Damage (HP)</label>
                <input
                  type="number"
                  disabled={!canEdit}
                  value={rules.actions.HEAVY.damage}
                  onChange={(e) => handleSaveActionSetting('HEAVY', 'damage', Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-0.5">Stamina Cost</label>
                <input
                  type="number"
                  disabled={!canEdit}
                  value={rules.actions.HEAVY.staminaCost}
                  onChange={(e) => handleSaveActionSetting('HEAVY', 'staminaCost', Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-0.5">Energy Generated (+NRG)</label>
                <input
                  type="number"
                  disabled={!canEdit}
                  value={rules.actions.HEAVY.energyDelta}
                  onChange={(e) => handleSaveActionSetting('HEAVY', 'energyDelta', Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-0.5">Stagger Duration (seconds)</label>
                <input
                  type="number"
                  step="0.1"
                  disabled={!canEdit}
                  value={rules.actions.HEAVY.staggerDurationSeconds || 0.8}
                  onChange={(e) => handleSaveActionSetting('HEAVY', 'staggerDurationSeconds', Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>
            </div>
          </div>

          {/* DEFENSE CARD */}
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-blue-500/40 space-y-3 shadow-xl">
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Shield className="text-blue-400" size={20} />
                <span className="font-black text-sm text-blue-200">DEFENSE</span>
              </div>
              <span className="text-[10px] font-mono text-blue-300/80">Blocks Strike · Counter Window</span>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div>
                <label className="text-slate-400 block mb-0.5">Strike Reduction % (0.90 = 90%)</label>
                <input
                  type="number"
                  step="0.05"
                  disabled={!canEdit}
                  value={rules.actions.DEFENSE.strikeDamageReduction || 0.90}
                  onChange={(e) => handleSaveActionSetting('DEFENSE', 'strikeDamageReduction', Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-0.5">Heavy Reduction % (0.35 = 35%)</label>
                <input
                  type="number"
                  step="0.05"
                  disabled={!canEdit}
                  value={rules.actions.DEFENSE.heavyDamageReduction || 0.35}
                  onChange={(e) => handleSaveActionSetting('DEFENSE', 'heavyDamageReduction', Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-0.5">Block Stamina Cost</label>
                <input
                  type="number"
                  disabled={!canEdit}
                  value={rules.actions.DEFENSE.staminaCost}
                  onChange={(e) => handleSaveActionSetting('DEFENSE', 'staminaCost', Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-0.5">Counter Bonus Damage</label>
                <input
                  type="number"
                  disabled={!canEdit}
                  value={rules.actions.DEFENSE.counterBonusDamage || 20}
                  onChange={(e) => handleSaveActionSetting('DEFENSE', 'counterBonusDamage', Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 
        ========================================================================
        TAB 2: MATCHUP MATRIX VISUAL GRID
        ========================================================================
      */}
      {activeTab === 'MATRIX' && (
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-cyan-500/30 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <h2 className="text-sm font-mono font-bold text-white flex items-center gap-2">
              <Grid3X3 size={16} className="text-cyan-400" />
              <span>{isAr ? 'مصفوفة التفاعلات المتبادلة (Click cell to edit outcome)' : 'Interactive Matchup Matrix (Click cell to customize)'}</span>
            </h2>
            <span className="text-[11px] font-mono text-slate-400">RPS Circular Counters</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-center border-collapse text-xs font-mono">
              <thead>
                <tr>
                  <th className="p-2 border border-slate-800 bg-slate-950 text-slate-400">YOU ↓ / OPPONENT →</th>
                  <th className="p-2 border border-slate-800 bg-cyan-950/40 text-cyan-300 font-bold">STRIKE</th>
                  <th className="p-2 border border-slate-800 bg-amber-950/40 text-amber-300 font-bold">HEAVY</th>
                  <th className="p-2 border border-slate-800 bg-blue-950/40 text-blue-300 font-bold">DEFENSE</th>
                  <th className="p-2 border border-slate-800 bg-purple-950/40 text-purple-300 font-bold">SKILL</th>
                </tr>
              </thead>
              <tbody>
                {(['STRIKE', 'HEAVY', 'DEFENSE', 'SKILL'] as CombatActionType[]).map(pAct => (
                  <tr key={pAct}>
                    <td className="p-2 border border-slate-800 bg-slate-950/60 font-black text-white">{pAct}</td>
                    {(['STRIKE', 'HEAVY', 'DEFENSE', 'SKILL'] as CombatActionType[]).map(oAct => {
                      const cellKey = `${pAct}_vs_${oAct}`;
                      const cell = rules.matchupMatrix[cellKey as keyof typeof rules.matchupMatrix];
                      if (!cell) return <td key={cellKey} className="border border-slate-800">-</td>;

                      const isWin = cell.winner === 'PLAYER';
                      const isLoss = cell.winner === 'OPPONENT';

                      return (
                        <td 
                          key={cellKey}
                          onClick={() => canEdit && setSelectedCellKey(cellKey)}
                          className={`p-2.5 border border-slate-800 cursor-pointer transition-all hover:brightness-125 ${
                            isWin 
                              ? 'bg-emerald-950/40 text-emerald-300 border-emerald-500/30' 
                              : isLoss 
                                ? 'bg-rose-950/40 text-rose-300 border-rose-500/30' 
                                : 'bg-slate-950/50 text-amber-300 border-amber-500/20'
                          }`}
                        >
                          <div className="font-black text-[11px]">{cell.bannerText}</div>
                          <div className="text-[9px] text-slate-400 mt-0.5">
                            {cell.winner === 'PLAYER' ? 'YOU WIN' : cell.winner === 'OPPONENT' ? 'OPPONENT WINS' : 'TIE'}
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Cell Rule Editor Drawer */}
          {selectedCellKey && rules.matchupMatrix[selectedCellKey as keyof typeof rules.matchupMatrix] && (
            <div className="mt-4 p-4 rounded-xl bg-slate-950 border border-cyan-400/50 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="font-mono font-bold text-sm text-cyan-200">
                  Editing Matchup: <span className="text-white">{selectedCellKey.replace('_vs_', ' VS ')}</span>
                </span>
                <button 
                  onClick={() => setSelectedCellKey(null)}
                  className="text-slate-400 hover:text-white"
                >
                  <X size={16} />
                </button>
              </div>

              {(() => {
                const cell = rules.matchupMatrix[selectedCellKey as keyof typeof rules.matchupMatrix];
                return (
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
                    <div>
                      <label className="text-slate-400 block mb-0.5">Winner</label>
                      <select
                        value={cell.winner}
                        onChange={(e) => handleUpdateMatrixCell(selectedCellKey, { ...cell, winner: e.target.value as any })}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-white"
                      >
                        <option value="PLAYER">PLAYER</option>
                        <option value="OPPONENT">OPPONENT</option>
                        <option value="TIE">TIE</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-slate-400 block mb-0.5">Result Label</label>
                      <input
                        type="text"
                        value={cell.bannerText}
                        onChange={(e) => handleUpdateMatrixCell(selectedCellKey, { ...cell, bannerText: e.target.value })}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-white font-bold"
                      />
                    </div>

                    <div>
                      <label className="text-slate-400 block mb-0.5">Player Dmg Multiplier</label>
                      <input
                        type="number"
                        step="0.1"
                        value={cell.playerDamageMultiplier}
                        onChange={(e) => handleUpdateMatrixCell(selectedCellKey, { ...cell, playerDamageMultiplier: Number(e.target.value) })}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-white"
                      />
                    </div>

                    <div>
                      <label className="text-slate-400 block mb-0.5">Opponent Dmg Multiplier</label>
                      <input
                        type="number"
                        step="0.1"
                        value={cell.opponentDamageMultiplier}
                        onChange={(e) => handleUpdateMatrixCell(selectedCellKey, { ...cell, opponentDamageMultiplier: Number(e.target.value) })}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-white"
                      />
                    </div>

                    <div className="flex items-center gap-2 pt-4">
                      <input
                        type="checkbox"
                        id="gb"
                        checked={cell.guardBreak}
                        onChange={(e) => handleUpdateMatrixCell(selectedCellKey, { ...cell, guardBreak: e.target.checked })}
                      />
                      <label htmlFor="gb" className="text-amber-300 font-bold">Triggers Guard Break</label>
                    </div>

                    <div className="flex items-center gap-2 pt-4">
                      <input
                        type="checkbox"
                        id="oppStagger"
                        checked={cell.opponentStagger}
                        onChange={(e) => handleUpdateMatrixCell(selectedCellKey, { ...cell, opponentStagger: e.target.checked })}
                      />
                      <label htmlFor="oppStagger" className="text-cyan-300 font-bold">Staggers Opponent</label>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}
        </div>
      )}

      {/* 
        ========================================================================
        TAB 3: SKILL CREATOR & MANAGER
        ========================================================================
      */}
      {activeTab === 'SKILLS' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/80 border border-purple-500/30">
            <div className="flex items-center gap-2 text-xs font-mono text-purple-300">
              <Sparkles size={16} />
              <span>{isAr ? 'قائمة المهارات التكتيكية المخصصة' : 'Custom Tactical Skills Registry'}</span>
            </div>

            {canEdit && (
              <button
                onClick={() => {
                  setSkillForm({
                    ...DEFAULT_COMBAT_SKILLS[0],
                    id: `custom_skill_${Date.now()}`,
                    name: 'New Custom Skill',
                    nameAr: 'مهارة مخصصة جديدة'
                  });
                  setIsEditingSkill(true);
                }}
                className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-mono font-bold text-white flex items-center gap-1.5 transition-all cursor-pointer shadow-lg"
              >
                <Plus size={14} />
                <span>{isAr ? 'إنشاء مهارة جديدة' : 'Create New Skill'}</span>
              </button>
            )}
          </div>

          {/* Anti-Overpower Warning Banner */}
          {antiOverpowerWarnings.length > 0 && isEditingSkill && (
            <div className="p-3.5 rounded-xl bg-amber-950/80 border border-amber-500/60 text-amber-200 text-xs font-mono space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-amber-300">
                <AlertTriangle size={15} />
                <span>{isAr ? 'نظام الحماية من الإفراط بالقوة (Anti-Overpower Warning):' : 'Anti-Overpower Safety Warnings:'}</span>
              </div>
              <ul className="list-disc list-inside space-y-0.5 pl-2 text-[11px]">
                {antiOverpowerWarnings.map((w, idx) => (
                  <li key={idx}>{w}</li>
                ))}
              </ul>
              {isOwner && (
                <p className="text-[10px] text-amber-400/80 italic mt-1">
                  {isAr ? '* بصفتك المالك (Owner)، يمكنك حفظ المهارة وتجاوز هذه التحذيرات.' : '* As OWNER, you may override warnings if deliberate.'}
                </p>
              )}
            </div>
          )}

          {/* Skill Form Modal */}
          {isEditingSkill && (
            <form onSubmit={handleSaveSkillForm} className="p-4 rounded-2xl bg-slate-900 border border-purple-500/50 space-y-4 shadow-2xl">
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <h3 className="font-mono font-bold text-sm text-purple-200">
                  {isAr ? 'تعديل / إنشاء مهارة' : 'Create or Edit Combat Skill'}
                </h3>
                <button type="button" onClick={() => setIsEditingSkill(false)} className="text-slate-400 hover:text-white">
                  <X size={16} />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
                <div>
                  <label className="text-slate-400 block mb-0.5">Skill ID</label>
                  <input
                    type="text"
                    required
                    value={skillForm.id}
                    onChange={(e) => setSkillForm({ ...skillForm, id: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-0.5">Name (English)</label>
                  <input
                    type="text"
                    required
                    value={skillForm.name}
                    onChange={(e) => setSkillForm({ ...skillForm, name: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-0.5">Name (Arabic)</label>
                  <input
                    type="text"
                    value={skillForm.nameAr || ''}
                    onChange={(e) => setSkillForm({ ...skillForm, nameAr: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-0.5">Category</label>
                  <select
                    value={skillForm.category}
                    onChange={(e) => setSkillForm({ ...skillForm, category: e.target.value as any })}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white"
                  >
                    <option value="BERSERKER">BERSERKER</option>
                    <option value="ASSASSIN">ASSASSIN</option>
                    <option value="GUARDIAN">GUARDIAN</option>
                    <option value="MAGE">MAGE</option>
                    <option value="VAMPIRE">VAMPIRE</option>
                    <option value="UNIVERSAL">UNIVERSAL</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 block mb-0.5">Damage (HP)</label>
                  <input
                    type="number"
                    value={skillForm.damage}
                    onChange={(e) => setSkillForm({ ...skillForm, damage: Number(e.target.value) })}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-0.5">Energy Cost (NRG)</label>
                  <input
                    type="number"
                    value={skillForm.energyCost}
                    onChange={(e) => setSkillForm({ ...skillForm, energyCost: Number(e.target.value) })}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-0.5">Stamina Cost</label>
                  <input
                    type="number"
                    value={skillForm.staminaCost}
                    onChange={(e) => setSkillForm({ ...skillForm, staminaCost: Number(e.target.value) })}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-0.5">Cooldown (Turns)</label>
                  <input
                    type="number"
                    value={skillForm.cooldown}
                    onChange={(e) => setSkillForm({ ...skillForm, cooldown: Number(e.target.value) })}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-0.5">Priority (0-3)</label>
                  <select
                    value={skillForm.priority}
                    onChange={(e) => setSkillForm({ ...skillForm, priority: Number(e.target.value) as any })}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white"
                  >
                    <option value={0}>0 (Normal)</option>
                    <option value={1}>1 (Fast)</option>
                    <option value={2}>2 (Special)</option>
                    <option value={3}>3 (Ultimate)</option>
                  </select>
                </div>
              </div>

              {/* Effects Checkboxes */}
              <div>
                <label className="text-slate-400 block text-xs mb-1">Status & Tactical Effects</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                  {[
                    { key: 'stun', label: 'Stun' },
                    { key: 'stagger', label: 'Stagger' },
                    { key: 'guardBreak', label: 'Guard Break' },
                    { key: 'counter', label: 'Counter' },
                    { key: 'dodge', label: 'Dodge' },
                    { key: 'heal', label: 'Heal' },
                    { key: 'lifesteal', label: 'Lifesteal' },
                    { key: 'buff', label: 'Buff Next Heavy' }
                  ].map(({ key, label }) => (
                    <label key={key} className="flex items-center gap-1.5 text-slate-300">
                      <input
                        type="checkbox"
                        checked={Boolean((skillForm.effects as any)[key])}
                        onChange={(e) => setSkillForm({
                          ...skillForm,
                          effects: {
                            ...skillForm.effects,
                            [key]: e.target.checked
                          }
                        })}
                      />
                      <span>{label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsEditingSkill(false)}
                  className="px-4 py-1.5 rounded-xl bg-slate-800 text-xs font-mono text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-4 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-xs font-mono font-bold text-white flex items-center gap-1.5"
                >
                  <Save size={14} />
                  <span>Save Skill</span>
                </button>
              </div>
            </form>
          )}

          {/* Skills Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {rules.skills.map(sk => (
              <div 
                key={sk.id}
                className="p-3 rounded-2xl bg-slate-900/90 border border-slate-700/60 hover:border-purple-400/60 transition-all flex flex-col justify-between space-y-2 shadow-lg"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-purple-200">{sk.name}</span>
                    <span className="px-2 py-0.5 rounded-full text-[9px] font-mono bg-purple-950 border border-purple-500/40 text-purple-300">
                      {sk.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">{isAr && sk.descriptionAr ? sk.descriptionAr : sk.description}</p>
                </div>

                <div className="flex items-center justify-between text-[10.5px] font-mono text-slate-300 pt-2 border-t border-white/10">
                  <span>Dmg: {sk.damage}</span>
                  <span>NRG: {sk.energyCost}</span>
                  <span>CD: {sk.cooldown}T</span>
                  {canEdit && (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => {
                          setSkillForm(sk);
                          setIsEditingSkill(true);
                        }}
                        className="text-cyan-400 hover:text-cyan-300 text-[10px]"
                      >
                        Edit
                      </button>
                      {isOwner && (
                        <button
                          onClick={() => {
                            if (window.confirm(`Delete skill "${sk.name}"?`)) {
                              deleteSkill(sk.id);
                            }
                          }}
                          className="text-rose-400 hover:text-rose-300 ml-1"
                        >
                          <Trash2 size={12} />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 
        ========================================================================
        TAB 4: RESOURCE SYSTEMS (STAMINA & ENERGY)
        ========================================================================
      */}
      {activeTab === 'RESOURCES' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-amber-500/30 space-y-3">
            <h3 className="font-mono font-bold text-sm text-amber-300 flex items-center gap-2">
              <Gauge size={16} />
              <span>{isAr ? 'نظام طاقة التحمل (Stamina System & Exhaustion)' : 'Stamina System & Exhaustion'}</span>
            </h3>
            <p className="text-xs text-slate-400">
              When stamina reaches 0, fighter becomes EXHAUSTED: Heavy attack is disabled, Strike deals -20% damage, and defense is impaired.
            </p>

            <div className="space-y-2 text-xs font-mono">
              <div>
                <label className="text-slate-400 block mb-0.5">Maximum Stamina</label>
                <input
                  type="number"
                  disabled={!canEdit}
                  value={rules.staminaConfig.maxStamina}
                  onChange={(e) => updateRules({
                    staminaConfig: { ...rules.staminaConfig, maxStamina: Number(e.target.value) }
                  })}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-0.5">Stamina Recovery Per Turn (Passive)</label>
                <input
                  type="number"
                  disabled={!canEdit}
                  value={rules.staminaConfig.staminaRegenPerTurn}
                  onChange={(e) => updateRules({
                    staminaConfig: { ...rules.staminaConfig, staminaRegenPerTurn: Number(e.target.value) }
                  })}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="disHeavy"
                  disabled={!canEdit}
                  checked={rules.staminaConfig.exhaustionDisablesHeavy}
                  onChange={(e) => updateRules({
                    staminaConfig: { ...rules.staminaConfig, exhaustionDisablesHeavy: e.target.checked }
                  })}
                />
                <label htmlFor="disHeavy" className="text-amber-200 font-bold">
                  Exhaustion Completely Disables Heavy Action
                </label>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/90 border border-cyan-500/30 space-y-3">
            <h3 className="font-mono font-bold text-sm text-cyan-300 flex items-center gap-2">
              <Zap size={16} />
              <span>{isAr ? 'نظام الطاقة الخارقة (Energy Generation)' : 'Energy Generation System'}</span>
            </h3>
            <p className="text-xs text-slate-400">
              Basic actions generate energy towards executing high-priority special skills.
            </p>

            <div className="space-y-2 text-xs font-mono">
              <div>
                <label className="text-slate-400 block mb-0.5">Maximum Energy Capacity</label>
                <input
                  type="number"
                  disabled={!canEdit}
                  value={rules.energyConfig.maxEnergy}
                  onChange={(e) => updateRules({
                    energyConfig: { ...rules.energyConfig, maxEnergy: Number(e.target.value) }
                  })}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-0.5">Strike Energy Gain (+NRG)</label>
                <input
                  type="number"
                  disabled={!canEdit}
                  value={rules.energyConfig.strikeGain}
                  onChange={(e) => updateRules({
                    energyConfig: { ...rules.energyConfig, strikeGain: Number(e.target.value) }
                  })}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-0.5">Heavy Energy Gain (+NRG)</label>
                <input
                  type="number"
                  disabled={!canEdit}
                  value={rules.energyConfig.heavyGain}
                  onChange={(e) => updateRules({
                    energyConfig: { ...rules.energyConfig, heavyGain: Number(e.target.value) }
                  })}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white font-bold"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
