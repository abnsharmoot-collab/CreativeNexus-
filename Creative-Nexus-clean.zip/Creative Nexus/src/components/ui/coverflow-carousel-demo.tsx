export * from '@/components/ui/coverflow-carousel-demo';
export { default } from '@/components/ui/coverflow-carousel-demo';
