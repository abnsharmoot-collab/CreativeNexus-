export * from '@/components/ui/smooth-button';
export { default } from '@/components/ui/smooth-button';
