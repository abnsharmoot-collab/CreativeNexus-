import React from 'react';
import { motion } from 'motion/react';
import { useEasterEggs } from '../../context/EasterEggContext';
import { MesopotamianCornerBrackets } from '../atoms/MesopotamianCornerBrackets';

interface StatCardProps {
  key?: React.Key;
  label: string;
  value: string | number;
  delay?: number;
  subtitle?: string;
  badge?: string;
  isLive?: boolean;
  categoryLabel?: string;
}

export function StatCard({ 
  label, 
  value, 
  delay = 0, 
  subtitle, 
  badge, 
  isLive,
  categoryLabel
}: StatCardProps) {
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  if (isMesopotamian) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 25 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay }}
        whileHover={{ y: -3 }}
        className="relative flex items-center justify-between p-6 sm:p-7 rounded-2xl bg-gradient-to-br from-[#1e1208]/70 via-[#140b05]/65 to-[#0b0502]/75 backdrop-blur-md border border-amber-500/50 hover:border-amber-400/90 shadow-[0_12px_40px_rgba(0,0,0,0.7),inset_0_1px_2px_rgba(245,158,11,0.35)] hover:shadow-[0_16px_50px_rgba(245,158,11,0.25)] overflow-hidden group min-h-[140px] transition-all duration-300"
      >
        {/* Ornate Stepped Corner Brackets */}
        <MesopotamianCornerBrackets />

        {/* Live Badge in Mesopotamian Mode */}
        {isLive && (
          <div className="absolute top-2.5 end-3 flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-500/50 shadow-[0_0_10px_rgba(16,185,129,0.3)] z-20">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
            </span>
            <span className="text-[10px] font-serif font-bold text-emerald-300 uppercase tracking-widest">LIVE</span>
          </div>
        )}

        {/* Text Content - Floating cleanly over the legendary ancient background */}
        <div className="flex-1 flex flex-col text-start">
          {(categoryLabel || badge) && (
            <span className="text-[10px] sm:text-xs font-serif tracking-[0.2em] uppercase text-amber-400/90 font-bold mb-1 drop-shadow-sm">
              {categoryLabel || badge}
            </span>
          )}

          <span className="font-meso-serif font-black text-3xl sm:text-4xl lg:text-5xl mesopotamian-gold-text mb-1 drop-shadow-md">
            {value}
          </span>

          <span className="font-serif text-xs sm:text-sm tracking-[0.16em] uppercase text-amber-200/95 font-bold drop-shadow-sm">
            {label}
          </span>

          {subtitle && (
            <span className="font-serif text-[11px] text-amber-400/70 mt-1">
              {subtitle}
            </span>
          )}
        </div>
      </motion.div>
    );
  }

  // Standard Theme StatCard - Rich Glassmorphic Gradients & Arabic-English Typography
  const isArabicText = (text?: string) => text && /[\u0600-\u06FF]/.test(text);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ y: -6, scale: 1.02 }}
      className="relative flex flex-col items-center justify-center p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-[#062624]/60 via-[#031d1b]/45 to-[#011110]/60 backdrop-blur-md border border-[#5eead4]/30 hover:border-[#5eead4]/75 shadow-[0_10px_35px_rgba(0,0,0,0.6),inset_0_1px_2px_rgba(94,234,212,0.35)] hover:shadow-[0_16px_50px_rgba(45,212,191,0.25),inset_0_1px_3px_rgba(94,234,212,0.6)] group overflow-hidden transition-all duration-300"
    >
      {/* Dynamic Specular Hover Radial Aura */}
      <div className="absolute inset-0 bg-gradient-to-tr from-[#5eead4]/15 via-teal-500/10 to-transparent opacity-60 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
      <div className="absolute -top-16 -right-16 w-36 h-36 bg-[#5eead4]/15 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700 pointer-events-none" />

      {/* Live status indicator */}
      {isLive && (
        <div className="absolute top-3.5 end-3.5 flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-400/50 shadow-[0_0_15px_rgba(16,185,129,0.4)] z-20">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400" />
          </span>
          <span className="text-[10px] font-mono text-emerald-300 uppercase tracking-widest font-bold">LIVE</span>
        </div>
      )}

      {/* Category / Super-label Tag */}
      {categoryLabel && (
        <span className={`text-[10px] sm:text-xs uppercase tracking-[0.22em] text-[#5eead4]/90 font-bold mb-2 transition-colors group-hover:text-white drop-shadow-sm ${
          isArabicText(categoryLabel) ? 'font-cairo' : 'font-mono'
        }`}>
          {categoryLabel}
        </span>
      )}

      {/* Big Value Counter with Radiant Gradient */}
      <span className="font-display font-black text-4xl sm:text-5xl lg:text-6xl text-transparent bg-clip-text bg-gradient-to-b from-white via-[#f0fdfa] to-[#5eead4] tracking-tight drop-shadow-[0_2px_22px_rgba(45,212,191,0.4)] mb-2 group-hover:scale-105 transition-transform duration-300">
        {value}
      </span>

      {/* Main Metric Label */}
      <span className={`text-xs sm:text-sm uppercase tracking-[0.15em] text-[#eafffa]/95 font-bold text-center drop-shadow-sm ${
        isArabicText(label) ? 'font-cairo text-sm sm:text-base' : 'font-outfit'
      }`}>
        {label}
      </span>

      {/* Explanatory Subtitle */}
      {subtitle && (
        <span className={`text-xs text-[#99b8b2] mt-1.5 text-center font-normal group-hover:text-[#c4eae3] transition-colors ${
          isArabicText(subtitle) ? 'font-cairo' : 'font-sans'
        }`}>
          {subtitle}
        </span>
      )}
    </motion.div>
  );
}
