import React from 'react';
import { motion } from 'motion/react';
import { useLanguage } from '../../context/LanguageContext';
import { Sparkles, Compass, Gem, Crown, Flame, Award } from 'lucide-react';

interface TimelineItemProps {
  key?: React.Key;
  year: string;
  title: string;
  description: string;
  isStart?: boolean;
}

export function TimelineItem({ year, title, description, isStart = true }: TimelineItemProps) {
  const { language } = useLanguage();
  const isRtl = language === 'ar';

  const getEraIcon = () => {
    if (year.includes('2021')) {
      return <Gem size={14} className="text-archive-cyan" />;
    }
    if (year.includes('2023')) {
      return <Flame size={14} className="text-orange-400" />;
    }
    return <Crown size={14} className="text-amber-300" />;
  };

  const getMilestoneTags = () => {
    if (year.includes('2021')) {
      return isRtl 
        ? ['تأسيس السيرفر', 'اللبنة الأولى', 'بداية المجتمع']
        : ['Server Founded', 'Foundation Stone', 'Community Genesis'];
    }
    if (year.includes('2023')) {
      return isRtl
        ? ['الحقبة الذهبية', 'فعاليات صوتية ملحمية', 'توسع المجتمع']
        : ['Golden Epoch', 'Epic Voice Nights', 'Great Expansion'];
    }
    return isRtl
      ? ['التوثيق الشامل', 'النهضة السيادية', 'الخلود الرقمي']
      : ['Archival Rebirth', 'Sovereign Zenith', 'Digital Immortality'];
  };

  return (
    <div className={`relative flex flex-col md:flex-row items-center justify-between w-full mb-16 md:mb-20 ${isStart ? 'md:flex-row-reverse' : ''}`}>
      {/* Center timeline dot (Desktop) */}
      <div className="hidden md:flex absolute start-1/2 -translate-x-1/2 rtl:translate-x-1/2 w-11 h-11 rounded-2xl border-2 border-archive-cyan/60 bg-archive-dark items-center justify-center z-20 shadow-[0_0_20px_rgba(6,182,212,0.5)] transition-transform duration-300 hover:scale-110 gpu-60fps">
        {getEraIcon()}
      </div>

      {/* Empty space for alternating sides on desktop */}
      <div className="hidden md:block w-5/12" />

      {/* Timeline Content */}
      <motion.div 
        initial={{ opacity: 0, y: 18 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-40px" }}
        transition={{ duration: 0.55 }}
        className="w-full md:w-5/12 relative group gpu-60fps"
      >
        {/* Decorative connecting line for mobile */}
        <div className="md:hidden absolute -start-6 top-8 w-6 h-[2px] bg-gradient-to-r from-archive-cyan/50 to-transparent" />
        {/* Mobile timeline dot */}
        <div className="md:hidden absolute -start-9 top-6 w-6 h-6 rounded-xl border-2 border-archive-cyan bg-archive-dark z-20 flex items-center justify-center shadow-[0_0_12px_rgba(6,182,212,0.5)]">
          <div className="w-1.5 h-1.5 rounded-full bg-archive-cyan" />
        </div>

        <div className="relative p-7 sm:p-9 border border-archive-cyan/25 bg-gradient-to-br from-[#06181b]/95 via-archive-dark/95 to-archive-dark rounded-[2.2rem] hover:border-archive-cyan/55 hover:shadow-[0_0_35px_rgba(6,182,212,0.22)] transition-all duration-300 shadow-[0_15px_40px_rgba(0,0,0,0.5)] overflow-hidden gpu-60fps">
          {/* Subtle top sheen border line */}
          <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-archive-cyan/40 to-transparent" />

          {/* Stamp/Seal badge */}
          <div className="absolute top-6 end-6 px-3.5 py-1 rounded-full border border-archive-cyan/35 flex items-center gap-1.5 bg-archive-dark/90 backdrop-blur-sm shadow-[0_0_15px_rgba(6,182,212,0.2)]">
            {getEraIcon()}
            <span className="font-mono text-xs font-semibold text-archive-cyan tracking-wider">{year}</span>
          </div>

          <div className="font-display font-black text-5xl text-archive-cyan/10 mb-1 select-none pointer-events-none">{year}</div>
          <h3 className="font-display font-bold text-2xl sm:text-3xl text-transparent bg-clip-text bg-gradient-to-r from-white via-archive-paper to-archive-cyan mb-3 tracking-wide">{title}</h3>
          
          <div className="w-14 h-[2px] bg-gradient-to-r from-archive-cyan to-transparent mb-5" />
          
          <p className="font-sans text-archive-paper-muted leading-relaxed font-light text-sm md:text-base mb-6">
            {description}
          </p>

          {/* Milestone tags */}
          <div className="flex flex-wrap gap-2 pt-4 border-t border-archive-cyan/15">
            {getMilestoneTags().map((tag, idx) => (
              <span 
                key={idx} 
                className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-archive-teal-light/30 text-archive-cyan font-medium border border-archive-cyan/25 shadow-xs"
              >
                ✦ {tag}
              </span>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
