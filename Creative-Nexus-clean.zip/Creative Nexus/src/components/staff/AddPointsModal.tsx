import React from 'react';
import { StaffMember } from '../../types/staff';
import { PointsModal } from './PointsModal';

export function AddPointsModal({ 
  member, 
  onClose, 
  onSuccess 
}: { 
  member: StaffMember; 
  onClose: () => void; 
  onSuccess: () => void;
}) {
  return (
    <PointsModal
      isOpen={true}
      member={member}
      initialType="ADD"
      onClose={onClose}
      onSuccess={onSuccess}
    />
  );
}
