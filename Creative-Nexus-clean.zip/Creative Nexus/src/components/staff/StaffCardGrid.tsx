import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';
import { 
  Shield, Star, MoreVertical, Copy, Check, Eye, Edit3, 
  Plus, Minus, UserX, UserCheck, Trash2, ExternalLink, Calendar 
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useStaff } from '../../context/StaffContext';
import { useAuth } from '../../context/AuthContext';
import { StaffMember } from '../../types/staff';
import { getRankBadgeConfig, getStatusBadgeConfig, formatRelativeTime } from '../../utils/staffHelpers';
import { PointsModal } from './PointsModal';
import { EditStaffModal } from './EditStaffModal';
import { StaffDetailModal } from './StaffDetailModal';

interface StaffCardGridProps {
  staff: StaffMember[];
  onStaffUpdated?: () => void;
}

export function StaffCardGrid({ staff, onStaffUpdated }: StaffCardGridProps) {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { suspendStaff, reactivateStaff, removeStaff } = useStaff();
  const { hasPermission } = useAuth();

  const [activeMenuId, setActiveMenuId] = useState<string | number | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Modals state
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);
  const [isPointsModalOpen, setIsPointsModalOpen] = useState(false);
  const [pointsModalType, setPointsModalType] = useState<'ADD' | 'REMOVE'>('ADD');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  // Permissions
  const canEdit = hasPermission('EDIT_STAFF');
  const canSuspend = hasPermission('SUSPEND_STAFF');
  const canRemove = hasPermission('REMOVE_STAFF');
  const canManagePoints = hasPermission('MANAGE_POINTS') || hasPermission('ADD_POINTS');

  const handleCopyId = (discordId: string) => {
    navigator.clipboard.writeText(discordId);
    setCopiedId(discordId);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleStatusToggle = async (member: StaffMember) => {
    setActiveMenuId(null);
    try {
      if (member.status === 'ACTIVE') {
        await suspendStaff(member.id);
      } else {
        await reactivateStaff(member.id);
      }
      if (onStaffUpdated) onStaffUpdated();
    } catch (e: any) {
      alert(e?.message || 'Failed to update status');
    }
  };

  const handleRemove = async (member: StaffMember) => {
    setActiveMenuId(null);
    if (!confirm(isAr ? 'هل أنت متأكد من رغبتك في إزالة هذا الإداري من الطاقم؟' : 'Are you sure you want to remove this staff member?')) return;
    try {
      await removeStaff(member.id);
      if (onStaffUpdated) onStaffUpdated();
    } catch (e: any) {
      alert(e?.message || 'Failed to remove staff member');
    }
  };

  const openPoints = (member: StaffMember, type: 'ADD' | 'REMOVE') => {
    setSelectedStaff(member);
    setPointsModalType(type);
    setIsPointsModalOpen(true);
    setActiveMenuId(null);
  };

  const openEdit = (member: StaffMember) => {
    setSelectedStaff(member);
    setIsEditModalOpen(true);
    setActiveMenuId(null);
  };

  const openDetail = (member: StaffMember) => {
    setSelectedStaff(member);
    setIsDetailModalOpen(true);
    setActiveMenuId(null);
  };

  return (
    <>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {staff.map((member, index) => {
          const rankCfg = getRankBadgeConfig(member.rank);
          const statusCfg = getStatusBadgeConfig(member.status);
          const isMenuOpen = activeMenuId === member.id;

          return (
            <motion.div
              key={member.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25, delay: index * 0.03 }}
              className={`group relative rounded-2xl bg-slate-900/70 border ${
                member.status === 'SUSPENDED' ? 'border-rose-500/20' : 'border-slate-800'
              } hover:border-slate-700 p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:shadow-cyan-500/5`}
            >
              {/* Card Top: Avatar, Names, Rank & Menu */}
              <div>
                <div className="flex items-start justify-between gap-3 mb-3.5">
                  <div className="flex items-center gap-3">
                    <div className="relative cursor-pointer" onClick={() => openDetail(member)}>
                      <img
                        src={member.avatarUrl}
                        alt={member.displayName}
                        className="w-12 h-12 rounded-2xl border-2 border-slate-800 object-cover group-hover:border-slate-700 transition-colors"
                      />
                      <span
                        className={`absolute -bottom-1 -end-1 w-3.5 h-3.5 rounded-full border-2 border-slate-900 ${statusCfg.dotClass}`}
                        title={statusCfg.label}
                      />
                    </div>

                    <div className="min-w-0">
                      <h3 
                        onClick={() => openDetail(member)}
                        className="font-display font-semibold text-white text-base truncate hover:text-cyan-400 cursor-pointer transition-colors"
                      >
                        {member.displayName}
                      </h3>
                      <div className="text-xs text-slate-400 font-sans truncate">
                        @{member.username}
                      </div>
                    </div>
                  </div>

                  {/* Context Menu Button */}
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setActiveMenuId(isMenuOpen ? null : member.id)}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                    >
                      <MoreVertical size={16} />
                    </button>

                    <AnimatePresence>
                      {isMenuOpen && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.95, y: -5 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.95, y: -5 }}
                          transition={{ duration: 0.15 }}
                          className="absolute end-0 top-8 z-30 w-48 rounded-xl bg-slate-950 border border-slate-800 shadow-2xl py-1.5 overflow-hidden text-xs font-sans text-start"
                        >
                          <button
                            onClick={() => openDetail(member)}
                            className="w-full px-3.5 py-2 text-slate-300 hover:bg-slate-800/80 hover:text-white flex items-center gap-2 transition-colors text-start"
                          >
                            <Eye size={13} />
                            <span>{isAr ? 'معاينة سريعة' : 'Quick Preview'}</span>
                          </button>

                          <Link
                            to={`/staff-management/${member.id}`}
                            className="w-full px-3.5 py-2 text-slate-300 hover:bg-slate-800/80 hover:text-white flex items-center gap-2 transition-colors text-start"
                            onClick={() => setActiveMenuId(null)}
                          >
                            <ExternalLink size={13} />
                            <span>{isAr ? 'الملف الكامل' : 'Full Profile'}</span>
                          </Link>

                          {canManagePoints && (
                            <>
                              <div className="h-px bg-slate-800 my-1" />
                              <button
                                onClick={() => openPoints(member, 'ADD')}
                                className="w-full px-3.5 py-2 text-emerald-400 hover:bg-emerald-500/10 flex items-center gap-2 transition-colors text-start"
                              >
                                <Plus size={13} />
                                <span>{isAr ? 'إضافة نقاط' : 'Add Points'}</span>
                              </button>
                              <button
                                onClick={() => openPoints(member, 'REMOVE')}
                                className="w-full px-3.5 py-2 text-rose-400 hover:bg-rose-500/10 flex items-center gap-2 transition-colors text-start"
                              >
                                <Minus size={13} />
                                <span>{isAr ? 'خصم نقاط' : 'Deduct Points'}</span>
                              </button>
                            </>
                          )}

                          {canEdit && (
                            <>
                              <div className="h-px bg-slate-800 my-1" />
                              <button
                                onClick={() => openEdit(member)}
                                className="w-full px-3.5 py-2 text-cyan-400 hover:bg-cyan-500/10 flex items-center gap-2 transition-colors text-start"
                              >
                                <Edit3 size={13} />
                                <span>{isAr ? 'تعديل البيانات' : 'Edit Staff'}</span>
                              </button>
                            </>
                          )}

                          {canSuspend && (
                            <button
                              onClick={() => handleStatusToggle(member)}
                              className="w-full px-3.5 py-2 text-amber-400 hover:bg-amber-500/10 flex items-center gap-2 transition-colors text-start"
                            >
                              {member.status === 'ACTIVE' ? (
                                <>
                                  <UserX size={13} />
                                  <span>{isAr ? 'إيقاف مؤقت' : 'Suspend'}</span>
                                </>
                              ) : (
                                <>
                                  <UserCheck size={13} />
                                  <span>{isAr ? 'إلغاء الإيقاف' : 'Reactivate'}</span>
                                </>
                              )}
                            </button>
                          )}

                          {canRemove && (
                            <>
                              <div className="h-px bg-slate-800 my-1" />
                              <button
                                onClick={() => handleRemove(member)}
                                className="w-full px-3.5 py-2 text-red-400 hover:bg-red-500/10 flex items-center gap-2 transition-colors text-start"
                              >
                                <Trash2 size={13} />
                                <span>{isAr ? 'استبعاد من الطاقم' : 'Remove Staff'}</span>
                              </button>
                            </>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                {/* Rank Pill & Discord ID */}
                <div className="flex flex-wrap items-center gap-2 mb-3">
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${rankCfg.bgClass} ${rankCfg.textClass} ${rankCfg.borderClass}`}>
                    <Shield size={12} />
                    <span>{isAr ? rankCfg.labelAr : rankCfg.label}</span>
                  </span>

                  <button
                    type="button"
                    onClick={() => handleCopyId(member.discordId)}
                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200 font-mono text-[11px] transition-colors"
                    title={isAr ? 'نسخ معرف الديسكورد' : 'Copy Discord Snowflake'}
                  >
                    <span>ID: {member.discordId.slice(0, 7)}...</span>
                    {copiedId === member.discordId ? (
                      <Check size={10} className="text-emerald-400" />
                    ) : (
                      <Copy size={10} />
                    )}
                  </button>
                </div>

                {/* Notes (if any) */}
                {member.notes && (
                  <p className="text-xs text-slate-400/90 line-clamp-2 mb-3 bg-slate-950/40 p-2.5 rounded-xl border border-slate-800/60 font-sans">
                    {member.notes}
                  </p>
                )}
              </div>

              {/* Card Bottom: Points Counter & Quick Actions */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <div className="p-1 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
                    <Star size={13} />
                  </div>
                  <span className="font-display font-bold text-white text-base">
                    {member.points.toLocaleString()}
                  </span>
                  <span className="text-[11px] text-slate-400 font-sans">
                    {isAr ? 'نقطة' : 'pts'}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {canManagePoints && (
                    <button
                      type="button"
                      onClick={() => openPoints(member, 'ADD')}
                      className="p-1.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 transition-colors text-xs font-medium"
                      title={isAr ? 'إضافة نقاط' : 'Grant points'}
                    >
                      <Plus size={14} />
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => openDetail(member)}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 transition-colors text-xs font-medium flex items-center gap-1"
                  >
                    <Eye size={12} />
                    <span>{isAr ? 'معاينة' : 'Inspect'}</span>
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Submodals */}
      <PointsModal
        isOpen={isPointsModalOpen}
        member={selectedStaff}
        initialType={pointsModalType}
        onClose={() => setIsPointsModalOpen(false)}
        onSuccess={onStaffUpdated}
      />

      <EditStaffModal
        isOpen={isEditModalOpen}
        member={selectedStaff}
        onClose={() => setIsEditModalOpen(false)}
        onSuccess={onStaffUpdated}
      />

      <StaffDetailModal
        isOpen={isDetailModalOpen}
        member={selectedStaff}
        onClose={() => setIsDetailModalOpen(false)}
        onUpdated={onStaffUpdated}
      />
    </>
  );
}
