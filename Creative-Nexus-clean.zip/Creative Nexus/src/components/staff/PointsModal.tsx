import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Star, Plus, Minus, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useStaff } from '../../context/StaffContext';
import { StaffMember, PointTransactionType } from '../../types/staff';
import { Button } from '../atoms/Button';

interface PointsModalProps {
  isOpen: boolean;
  member: StaffMember | null;
  initialType?: PointTransactionType;
  onClose: () => void;
  onSuccess?: () => void;
}

const ADD_PRESETS = [
  'Event Hosting',
  'Active Chat Moderation',
  'Community Support',
  'Server Boosting',
  'Rules Enforcement',
  'Special Achievement'
];

const REMOVE_PRESETS = [
  'Inactivity Deduction',
  'Moderation Guidelines Breach',
  'Administrative Correction',
  'Disciplinary Penalty'
];

const QUICK_AMOUNTS = [25, 50, 100, 250, 500];

export function PointsModal({
  isOpen,
  member,
  initialType = 'ADD',
  onClose,
  onSuccess
}: PointsModalProps) {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { updateStaffPoints } = useStaff();

  const [type, setType] = useState<PointTransactionType>(initialType);
  const [amount, setAmount] = useState<number>(50);
  const [reason, setReason] = useState<string>('');
  const [note, setNote] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sync initial type when opened
  React.useEffect(() => {
    if (isOpen) {
      setType(initialType);
      setError('');
      setAmount(50);
      setReason('');
      setNote('');
    }
  }, [isOpen, initialType]);

  if (!isOpen || !member) return null;

  const currentPoints = member.points || 0;
  const newBalance = type === 'ADD'
    ? currentPoints + (Number(amount) || 0)
    : Math.max(0, currentPoints - (Number(amount) || 0));

  const isDeductExceeding = type === 'REMOVE' && (Number(amount) || 0) > currentPoints;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const numAmount = Number(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setError(isAr ? 'يجب أن تكون النقاط أكبر من الصفر' : 'Points amount must be greater than 0');
      return;
    }

    if (!reason.trim()) {
      setError(isAr ? 'يرجى كتابة أو اختيار سبب العملية' : 'Please provide or select a reason for this point adjustment');
      return;
    }

    if (type === 'REMOVE' && numAmount > currentPoints) {
      setError(isAr ? 'رصيد الإداري الحالي أقل من المبلغ المراد خصمه' : 'Staff balance is lower than deduction amount');
      return;
    }

    try {
      setIsSubmitting(true);
      await updateStaffPoints(member.id, numAmount, reason.trim(), type, note.trim() || undefined);
      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      setError(err?.message || (isAr ? 'فشل تحديث النقاط' : 'Failed to update points'));
    } finally {
      setIsSubmitting(false);
    }
  };

  const currentPresets = type === 'ADD' ? ADD_PRESETS : REMOVE_PRESETS;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm"
          onClick={onClose}
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden z-10 flex flex-col max-h-[90vh]"
          dir={isAr ? 'rtl' : 'ltr'}
        >
          {/* Header */}
          <div className="p-5 sm:p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
            <div className="flex items-center gap-3">
              <img
                src={member.avatarUrl}
                alt={member.displayName}
                className="w-11 h-11 rounded-full border border-slate-700 object-cover"
              />
              <div>
                <h3 className="font-display font-semibold text-lg text-white">
                  {isAr ? 'تعديل نقاط التقدير' : 'Adjust Staff Points'}
                </h3>
                <p className="text-xs text-slate-400 font-sans">
                  {member.displayName} (@{member.username})
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X size={18} />
            </button>
          </div>

          {/* Body */}
          <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-5 overflow-y-auto font-sans text-sm">
            {/* Type Switcher */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950/60 rounded-2xl border border-slate-800">
              <button
                type="button"
                onClick={() => setType('ADD')}
                className={`flex items-center justify-center gap-2 py-2.5 rounded-xl font-medium text-xs sm:text-sm transition-all ${
                  type === 'ADD'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Plus size={15} />
                <span>{isAr ? 'إضافة نقاط' : 'Grant Points (+)'}</span>
              </button>

              <button
                type="button"
                onClick={() => setType('REMOVE')}
                className={`flex items-center justify-center gap-2 py-2.5 rounded-xl font-medium text-xs sm:text-sm transition-all ${
                  type === 'REMOVE'
                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Minus size={15} />
                <span>{isAr ? 'خصم نقاط' : 'Deduct Points (-)'}</span>
              </button>
            </div>

            {/* Balance Preview Card */}
            <div className="p-4 rounded-2xl bg-slate-950/40 border border-slate-800/80 flex items-center justify-between">
              <div>
                <div className="text-xs text-slate-400 uppercase tracking-wider font-mono">
                  {isAr ? 'الرصيد الحالي' : 'Current Balance'}
                </div>
                <div className="text-xl font-bold text-white font-display flex items-center gap-1.5 mt-0.5">
                  <Star size={16} className="text-amber-400" />
                  <span>{currentPoints.toLocaleString()}</span>
                </div>
              </div>

              <div className="text-end">
                <div className="text-xs text-slate-400 uppercase tracking-wider font-mono">
                  {isAr ? 'الرصيد الجديد المتوقع' : 'Projected Balance'}
                </div>
                <div className={`text-xl font-bold font-display flex items-center justify-end gap-1.5 mt-0.5 ${
                  type === 'ADD' ? 'text-emerald-400' : 'text-rose-400'
                }`}>
                  <Star size={16} />
                  <span>{newBalance.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Amount Input & Quick Chips */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                {isAr ? 'عدد النقاط' : 'Points Amount'}
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="1"
                  value={amount || ''}
                  onChange={(e) => setAmount(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-4 py-2.5 text-white font-mono text-base focus:outline-none focus:border-cyan-500/50"
                  placeholder="50"
                  required
                />
              </div>

              {/* Quick Amount Chips */}
              <div className="flex flex-wrap gap-2 pt-1">
                {QUICK_AMOUNTS.map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setAmount(val)}
                    className={`px-3 py-1 rounded-lg text-xs font-mono border transition-colors ${
                      amount === val
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                        : 'bg-slate-800/60 text-slate-400 border-slate-700/60 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    +{val}
                  </button>
                ))}
              </div>
            </div>

            {/* Reason Input & Preset Chips */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                {isAr ? 'سبب العملية (مطلوب)' : 'Reason (Required)'}
              </label>
              <input
                type="text"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder={isAr ? 'اكتب أو اختر سبباً أدناه...' : 'e.g., Active event host or moderation shift'}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-cyan-500/50"
                required
              />

              {/* Preset Reason Chips */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {currentPresets.map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setReason(preset)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-sans border transition-colors ${
                      reason === preset
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                        : 'bg-slate-800/50 text-slate-400 border-slate-700/50 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            {/* Internal Note (Optional) */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
                {isAr ? 'ملاحظة إضافية (اختياري)' : 'Admin Note (Optional)'}
              </label>
              <textarea
                rows={2}
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder={isAr ? 'تفاصيل إضافية لسجل الرقابة...' : 'Additional details for the audit log...'}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-4 py-2 text-white text-sm focus:outline-none focus:border-cyan-500/50 resize-none"
              />
            </div>

            {/* Error banner */}
            {error && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center gap-2 text-xs text-rose-400">
                <AlertCircle size={15} className="shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Warning if deducting more than balance */}
            {isDeductExceeding && (
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-2 text-xs text-amber-400">
                <AlertCircle size={15} className="shrink-0" />
                <span>
                  {isAr 
                    ? 'تحذير: لا يمكن خصم نقاط تفوق رصيد الإداري الحالي' 
                    : 'Warning: Cannot deduct more points than the staff member currently possesses'}
                </span>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors text-xs font-medium"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>

              <Button
                variant="primary"
                type="submit"
                disabled={isSubmitting || isDeductExceeding || !reason.trim() || amount <= 0}
                className="px-5 py-2.5 text-xs font-semibold"
              >
                {isSubmitting 
                  ? (isAr ? 'جاري المعالجة...' : 'Processing...') 
                  : type === 'ADD' 
                    ? (isAr ? `إضافة ${amount} نقطة` : `Grant ${amount} Points`)
                    : (isAr ? `خصم ${amount} نقطة` : `Deduct ${amount} Points`)
                }
              </Button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
