import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, 
  Check, 
  Search, 
  Save, 
  RefreshCw, 
  Copy, 
  CheckCheck, 
  AlertCircle, 
  CheckCircle2, 
  X, 
  Info,
  Layers,
  Crown
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { Button } from '../atoms/Button';

export interface DiscordServerRole {
  id: string;
  name: string;
  color: number;
  colorHex: string;
  position: number;
  permissions: string;
  isMock?: boolean;
}

interface StaffRoleConfigResponse {
  success: boolean;
  guildId: string;
  guildOwnerId: string;
  serverName: string;
  staffRoleIds: string[];
  ownerRoleIds?: string[];
  availableRoles: DiscordServerRole[];
  botConnected: boolean;
  isOwner?: boolean;
  sourceOfTruth: string;
}

interface OwnerRoleConfigResponse {
  success: boolean;
  guildId: string;
  serverName: string;
  ownerRoleIds: string[];
  availableRoles: DiscordServerRole[];
  botConnected: boolean;
  isOwner?: boolean;
  sourceOfTruth: string;
}

interface StaffRoleSelectionProps {
  isOpen: boolean;
  onClose?: () => void;
  onRolesUpdated?: (newRoleIds: string[]) => void;
  initialTab?: 'staff' | 'owner' | 'both';
}

export const StaffRoleSelection: React.FC<StaffRoleSelectionProps> = ({
  isOpen,
  onClose,
  onRolesUpdated,
  initialTab = 'staff'
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const [activeTab, setActiveTab] = useState<'staff' | 'owner' | 'both'>(initialTab);
  const [loading, setLoading] = useState(true);
  const [availableRoles, setAvailableRoles] = useState<DiscordServerRole[]>([]);
  const [botConnected, setBotConnected] = useState(false);
  const [serverName, setServerName] = useState('CREATINE NEXUS');
  const [guildId, setGuildId] = useState('');
  const [copiedRoleId, setCopiedRoleId] = useState<string | null>(null);

  // Staff Roles State
  const [staffSaving, setStaffSaving] = useState(false);
  const [savedStaffRoleIds, setSavedStaffRoleIds] = useState<string[]>([]);
  const [selectedStaffRoleIds, setSelectedStaffRoleIds] = useState<Set<string>>(new Set());
  const [staffSearchQuery, setStaffSearchQuery] = useState('');
  const [staffFilterMode, setStaffFilterMode] = useState<'all' | 'selected' | 'unselected'>('all');

  // Owner Roles State
  const [ownerSaving, setOwnerSaving] = useState(false);
  const [savedOwnerRoleIds, setSavedOwnerRoleIds] = useState<string[]>([]);
  const [selectedOwnerRoleIds, setSelectedOwnerRoleIds] = useState<Set<string>>(new Set());
  const [ownerSearchQuery, setOwnerSearchQuery] = useState('');
  const [ownerFilterMode, setOwnerFilterMode] = useState<'all' | 'selected' | 'unselected'>('all');

  // Feedback notifications
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string; section?: 'staff' | 'owner' } | null>(null);

  // Sync activeTab when initialTab changes
  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  // Fetch real roles and configurations from backend
  const fetchConfig = useCallback(async () => {
    setLoading(true);
    setFeedback(null);
    try {
      // 1. Fetch staff roles config
      const staffRes = await fetch('/api/staff-roles/config?asOwner=true', {
        headers: { 'Accept': 'application/json' }
      });
      if (!staffRes.ok) {
        throw new Error(isAr ? 'فشل جلب رتب السيرفر من ديسكورد' : 'Failed to fetch server roles from Discord');
      }
      const staffData: StaffRoleConfigResponse = await staffRes.json();
      if (staffData.success) {
        setAvailableRoles(staffData.availableRoles || []);
        const activeStaff = staffData.staffRoleIds || [];
        setSavedStaffRoleIds(activeStaff);
        setSelectedStaffRoleIds(new Set(activeStaff));
        setBotConnected(Boolean(staffData.botConnected));
        if (staffData.serverName) setServerName(staffData.serverName);
        if (staffData.guildId) setGuildId(staffData.guildId);

        if (Array.isArray(staffData.ownerRoleIds)) {
          setSavedOwnerRoleIds(staffData.ownerRoleIds);
          setSelectedOwnerRoleIds(new Set(staffData.ownerRoleIds));
        }
      }

      // 2. Fetch owner roles config
      try {
        const ownerRes = await fetch('/api/owner-roles/config?asOwner=true', {
          headers: { 'Accept': 'application/json' }
        });
        if (ownerRes.ok) {
          const ownerData: OwnerRoleConfigResponse = await ownerRes.json();
          if (ownerData.success && Array.isArray(ownerData.ownerRoleIds)) {
            setSavedOwnerRoleIds(ownerData.ownerRoleIds);
            setSelectedOwnerRoleIds(new Set(ownerData.ownerRoleIds));
          }
        }
      } catch (ownerErr) {
        // Fallback silently if owner endpoint not ready
      }
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: err.message || (isAr ? 'خطأ في الاتصال بالخادم' : 'Error communicating with server')
      });
    } finally {
      setLoading(false);
    }
  }, [isAr]);

  useEffect(() => {
    if (isOpen) {
      fetchConfig();
    }
  }, [isOpen, fetchConfig]);

  // Toggle Staff Role
  const toggleStaffRole = (roleId: string) => {
    setSelectedStaffRoleIds(prev => {
      const next = new Set(prev);
      if (next.has(roleId)) {
        next.delete(roleId);
      } else {
        next.add(roleId);
      }
      return next;
    });
  };

  // Toggle Owner Role
  const toggleOwnerRole = (roleId: string) => {
    setSelectedOwnerRoleIds(prev => {
      const next = new Set(prev);
      if (next.has(roleId)) {
        next.delete(roleId);
      } else {
        next.add(roleId);
      }
      return next;
    });
  };

  // Copy role ID to clipboard
  const handleCopyRoleId = (e: React.MouseEvent, roleId: string) => {
    e.stopPropagation();
    navigator.clipboard.writeText(roleId);
    setCopiedRoleId(roleId);
    setTimeout(() => setCopiedRoleId(null), 2000);
  };

  // Check unsaved changes for Staff Roles
  const hasUnsavedStaffChanges = useMemo(() => {
    if (selectedStaffRoleIds.size !== savedStaffRoleIds.length) return true;
    for (const id of savedStaffRoleIds) {
      if (!selectedStaffRoleIds.has(id)) return true;
    }
    return false;
  }, [selectedStaffRoleIds, savedStaffRoleIds]);

  // Check unsaved changes for Owner Roles
  const hasUnsavedOwnerChanges = useMemo(() => {
    if (selectedOwnerRoleIds.size !== savedOwnerRoleIds.length) return true;
    for (const id of savedOwnerRoleIds) {
      if (!selectedOwnerRoleIds.has(id)) return true;
    }
    return false;
  }, [selectedOwnerRoleIds, savedOwnerRoleIds]);

  // Save Staff Roles
  const handleSaveStaffRoles = async () => {
    setStaffSaving(true);
    setFeedback(null);
    const roleIdsArray = Array.from(selectedStaffRoleIds);
    try {
      const res = await fetch('/api/staff-roles/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          staffRoleIds: roleIdsArray,
          asOwner: true
        })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || (isAr ? 'فشل حفظ رتب الإدارة' : 'Failed to save staff roles'));
      }

      setSavedStaffRoleIds(roleIdsArray);
      if (onRolesUpdated) {
        onRolesUpdated(roleIdsArray);
      }

      setFeedback({
        type: 'success',
        section: 'staff',
        message: isAr
          ? `تم حفظ ${roleIdsArray.length} رتبة كطاقم عمل رسمي ومزامنة الدليل بنجاح.`
          : `Successfully saved ${roleIdsArray.length} staff roles and synchronized staff directory.`
      });
      setTimeout(() => setFeedback(null), 6000);
    } catch (err: any) {
      setFeedback({
        type: 'error',
        section: 'staff',
        message: err.message || (isAr ? 'حدث خطأ أثناء حفظ رتب الإدارة' : 'An error occurred while saving staff roles')
      });
    } finally {
      setStaffSaving(false);
    }
  };

  // Save Owner Roles
  const handleSaveOwnerRoles = async () => {
    setOwnerSaving(true);
    setFeedback(null);
    const roleIdsArray = Array.from(selectedOwnerRoleIds);
    try {
      const res = await fetch('/api/owner-roles/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          ownerRoleIds: roleIdsArray,
          asOwner: true
        })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || (isAr ? 'فشل حفظ رتب المالك' : 'Failed to save owner roles'));
      }

      setSavedOwnerRoleIds(roleIdsArray);
      setFeedback({
        type: 'success',
        section: 'owner',
        message: isAr
          ? `تم حفظ ${roleIdsArray.length} رتبة ديسكورد كـ (Owner Access). سيتم منح حاملي هذه الرتب كامل صلاحيات المالك تلقائياً.`
          : `Successfully saved ${roleIdsArray.length} Discord roles with Owner Access. Users with these roles now receive full Owner permissions.`
      });
      setTimeout(() => setFeedback(null), 6000);
    } catch (err: any) {
      setFeedback({
        type: 'error',
        section: 'owner',
        message: err.message || (isAr ? 'حدث خطأ أثناء حفظ رتب المالك' : 'An error occurred while saving owner roles')
      });
    } finally {
      setOwnerSaving(false);
    }
  };

  // Filtered roles for Staff list
  const filteredStaffRoles = useMemo(() => {
    let list = availableRoles.filter(role => role.name !== '@everyone' && role.id !== guildId);

    if (staffSearchQuery.trim()) {
      const q = staffSearchQuery.toLowerCase().trim();
      list = list.filter(role => 
        role.name.toLowerCase().includes(q) || 
        role.id.includes(q)
      );
    }

    if (staffFilterMode === 'selected') {
      list = list.filter(role => selectedStaffRoleIds.has(role.id));
    } else if (staffFilterMode === 'unselected') {
      list = list.filter(role => !selectedStaffRoleIds.has(role.id));
    }

    return list;
  }, [availableRoles, staffSearchQuery, staffFilterMode, selectedStaffRoleIds, guildId]);

  // Filtered roles for Owner list
  const filteredOwnerRoles = useMemo(() => {
    let list = availableRoles.filter(role => role.name !== '@everyone' && role.id !== guildId);

    if (ownerSearchQuery.trim()) {
      const q = ownerSearchQuery.toLowerCase().trim();
      list = list.filter(role => 
        role.name.toLowerCase().includes(q) || 
        role.id.includes(q)
      );
    }

    if (ownerFilterMode === 'selected') {
      list = list.filter(role => selectedOwnerRoleIds.has(role.id));
    } else if (ownerFilterMode === 'unselected') {
      list = list.filter(role => !selectedOwnerRoleIds.has(role.id));
    }

    return list;
  }, [availableRoles, ownerSearchQuery, ownerFilterMode, selectedOwnerRoleIds, guildId]);

  if (!isOpen) return null;

  return (
    <motion.div
      id="role-selection-section"
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.25, ease: 'easeInOut' }}
      className="w-full bg-slate-900/90 border border-slate-700/60 rounded-3xl p-5 sm:p-6 shadow-2xl relative overflow-hidden backdrop-blur-xl space-y-6"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* Background Accent Gradients */}
      <div className="absolute top-0 end-0 w-80 h-40 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 start-0 w-80 h-40 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Right Close Button */}
      {onClose && (
        <button
          onClick={onClose}
          className="absolute top-4 right-4 sm:top-5 sm:right-5 z-20 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 bg-slate-900/80 border border-slate-700/60 transition-colors shadow-lg cursor-pointer"
          title={isAr ? 'إغلاق' : 'Close'}
          aria-label={isAr ? 'إغلاق' : 'Close'}
        >
          <X size={18} />
        </button>
      )}

      {/* Navigation & Section Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800 pr-12">
        <div className="flex items-center gap-2 p-1 bg-slate-950/80 rounded-2xl border border-slate-800">
          <button
            onClick={() => setActiveTab('staff')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              activeTab === 'staff'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Shield size={16} className="text-cyan-400" />
            <span>{isAr ? 'رتب الإدارة (Staff Roles)' : 'Staff Roles'}</span>
            <span className="text-[11px] font-mono px-1.5 py-0.2 rounded-md bg-cyan-950/60 border border-cyan-500/30 text-cyan-400">
              {selectedStaffRoleIds.size}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('owner')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              activeTab === 'owner'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Crown size={16} className="text-amber-400" />
            <span>{isAr ? 'رتب المالك (Owner Roles)' : 'Owner Roles'}</span>
            <span className="text-[11px] font-mono px-1.5 py-0.2 rounded-md bg-amber-950/60 border border-amber-500/30 text-amber-400">
              {selectedOwnerRoleIds.size}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('both')}
            className={`hidden md:flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all ${
              activeTab === 'both'
                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers size={15} className="text-purple-400" />
            <span>{isAr ? 'عرض القسمين معاً' : 'Both Sections'}</span>
          </button>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            onClick={fetchConfig}
            disabled={loading}
            className="text-xs py-1.5 px-3 h-8 border-slate-800 text-slate-400 hover:text-white"
          >
            <RefreshCw size={13} className={loading ? 'animate-spin text-cyan-400' : ''} />
            <span>{isAr ? 'تحديث الرتب' : 'Refresh Roles'}</span>
          </Button>
        </div>
      </div>

      {/* Feedback Toast */}
      <AnimatePresence>
        {feedback && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className={`p-3.5 rounded-2xl flex items-center justify-between gap-3 text-xs font-sans ${
              feedback.type === 'success'
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
            }`}
          >
            <div className="flex items-center gap-2">
              {feedback.type === 'success' ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
              <span className="font-medium">{feedback.message}</span>
            </div>
            <button
              onClick={() => setFeedback(null)}
              className="text-slate-400 hover:text-white text-xs underline"
            >
              {isAr ? 'إغلاق' : 'Dismiss'}
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ==================================================== */}
      {/* SECTION 1: STAFF ROLES CONFIGURATION */}
      {/* ==================================================== */}
      {(activeTab === 'staff' || activeTab === 'both') && (
        <section id="staff-roles-subpanel" className="space-y-4 pt-2">
          {/* Section Header */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
              <Shield size={20} />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold font-display text-white">
                {isAr ? 'تحديد رتب الإدارة المعتمدة (Staff Roles)' : 'Staff Roles Configuration'}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {isAr
                  ? 'اختر رتب ديسكورد التي يُعتبر أصحابها ضمن طاقم الإدارة الرسمي. يُستخدم Discord Role ID كمصدر وحيد للحقيقة.'
                  : 'Select Discord server roles that count as official staff. Discord Snowflake Role IDs are the persistent source of truth.'}
              </p>
            </div>
          </div>

          {/* Controls Bar for Staff Roles */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <Search size={15} className={`absolute top-1/2 -translate-y-1/2 text-slate-400 ${isAr ? 'right-3' : 'left-3'}`} />
              <input
                type="text"
                value={staffSearchQuery}
                onChange={(e) => setStaffSearchQuery(e.target.value)}
                placeholder={isAr ? 'ابحث باسم رتبة الإدارة أو الـ Role ID...' : 'Search staff role name or Snowflake ID...'}
                className={`w-full bg-slate-950/80 border border-slate-700/80 rounded-xl py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors ${
                  isAr ? 'pr-9 pl-4' : 'pl-9 pr-4'
                }`}
              />
              {staffSearchQuery && (
                <button
                  onClick={() => setStaffSearchQuery('')}
                  className={`absolute top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 text-xs ${isAr ? 'left-3' : 'right-3'}`}
                >
                  <X size={14} />
                </button>
              )}
            </div>

            {/* Filter Mode Chips */}
            <div className="flex items-center gap-1.5 p-1 bg-slate-950/80 rounded-xl border border-slate-800 shrink-0">
              <button
                onClick={() => setStaffFilterMode('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  staffFilterMode === 'all'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {isAr ? `الكل (${availableRoles.length})` : `All (${availableRoles.length})`}
              </button>
              <button
                onClick={() => setStaffFilterMode('selected')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  staffFilterMode === 'selected'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {isAr ? `المحدد كإدارة (${selectedStaffRoleIds.size})` : `Staff (${selectedStaffRoleIds.size})`}
              </button>
              <button
                onClick={() => setStaffFilterMode('unselected')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  staffFilterMode === 'unselected'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {isAr ? 'غير محدد' : 'Unselected'}
              </button>
            </div>

            {/* Save / Reset Actions */}
            <div className="flex items-center gap-2 shrink-0">
              {hasUnsavedStaffChanges && (
                <Button
                  variant="outline"
                  onClick={() => setSelectedStaffRoleIds(new Set(savedStaffRoleIds))}
                  disabled={staffSaving}
                  className="text-xs py-2 px-3 border-slate-700 text-slate-300 hover:bg-slate-800"
                >
                  {isAr ? 'إلغاء' : 'Reset'}
                </Button>
              )}

              <Button
                variant="primary"
                onClick={handleSaveStaffRoles}
                disabled={staffSaving || !hasUnsavedStaffChanges}
                className={`text-xs py-2 px-4 gap-2 font-semibold ${
                  hasUnsavedStaffChanges 
                    ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 ring-2 ring-cyan-400/40 ring-offset-2 ring-offset-slate-900' 
                    : 'opacity-60 cursor-not-allowed'
                }`}
              >
                {staffSaving ? (
                  <>
                    <RefreshCw size={14} className="animate-spin" />
                    <span>{isAr ? 'جاري الحفظ...' : 'Saving...'}</span>
                  </>
                ) : (
                  <>
                    <Save size={14} />
                    <span>
                      {hasUnsavedStaffChanges
                        ? (isAr ? `حفظ رتب الإدارة (${selectedStaffRoleIds.size})` : `Save Staff (${selectedStaffRoleIds.size})`)
                        : (isAr ? 'تم الحفظ' : 'Saved')}
                    </span>
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Roles Grid for Staff */}
          {loading ? (
            <div className="py-12 text-center space-y-2">
              <RefreshCw size={24} className="animate-spin text-cyan-400 mx-auto" />
              <p className="text-xs text-slate-400">
                {isAr ? 'جاري تحميل رتب الإدارة من ديسكورد...' : 'Loading roles from Discord...'}
              </p>
            </div>
          ) : filteredStaffRoles.length === 0 ? (
            <div className="py-8 text-center rounded-2xl bg-slate-950/40 border border-slate-800/80 p-4 space-y-1">
              <Layers size={28} className="text-slate-600 mx-auto" />
              <h4 className="text-xs font-semibold text-white">
                {isAr ? 'لم يتم العثور على رتب مطابقة' : 'No matching roles found'}
              </h4>
            </div>
          ) : (
            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1 select-none custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                {filteredStaffRoles.map((role) => {
                  const isSelected = selectedStaffRoleIds.has(role.id);
                  const isCopied = copiedRoleId === role.id;

                  return (
                    <div
                      key={`staff-role-${role.id}`}
                      onClick={() => toggleStaffRole(role.id)}
                      className={`group relative p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                        isSelected
                          ? 'bg-cyan-950/30 border-cyan-500/50 hover:border-cyan-400 shadow-sm shadow-cyan-950/20'
                          : 'bg-slate-950/50 border-slate-800 hover:border-slate-700 hover:bg-slate-950/80'
                      }`}
                    >
                      {/* Left: Checkbox + Color + Name & ID */}
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div
                          className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-colors shrink-0 ${
                            isSelected
                              ? 'bg-cyan-500 border-cyan-400 text-slate-950'
                              : 'border-slate-700 group-hover:border-slate-600 bg-slate-900'
                          }`}
                        >
                          {isSelected && <Check size={13} className="stroke-[3]" />}
                        </div>

                        <div
                          className="w-3 h-3 rounded-full shrink-0 border border-white/20"
                          style={{ backgroundColor: role.colorHex || '#64748b' }}
                          title={`Color: ${role.colorHex}`}
                        />

                        <div className="min-w-0">
                          <span className="font-semibold text-xs sm:text-sm text-white truncate group-hover:text-cyan-300 transition-colors block">
                            {role.name}
                          </span>
                          <div className="flex items-center gap-1 mt-0.5">
                            <span className="text-[10px] text-slate-500 font-mono">ID:</span>
                            <code className="text-[10px] font-mono text-slate-400 bg-slate-900/90 px-1 py-0.2 rounded border border-slate-800">
                              {role.id}
                            </code>
                          </div>
                        </div>
                      </div>

                      {/* Right: Copy ID + Status */}
                      <div className="flex items-center gap-1.5 shrink-0" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={(e) => handleCopyRoleId(e, role.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800/80 transition-colors"
                          title={isAr ? 'نسخ معرّف الرتبة' : 'Copy Snowflake ID'}
                        >
                          {isCopied ? <CheckCheck size={13} className="text-emerald-400" /> : <Copy size={13} />}
                        </button>

                        {isSelected && (
                          <span className="text-[10px] font-semibold font-mono text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-2 py-0.5 rounded-full">
                            {isAr ? 'طاقم معتمد' : 'Staff'}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </section>
      )}

      {/* Divider when both sections are shown stacked */}
      {activeTab === 'both' && (
        <div className="relative py-2">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-800" />
          </div>
          <div className="relative flex justify-center text-xs">
            <span className="bg-slate-900 px-3 text-slate-500 font-mono">
              {isAr ? 'صلاحيات المالك الإضافية' : 'High Authority Configuration'}
            </span>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* SECTION 2: OWNER ROLES CONFIGURATION (OWNER ACCESS) */}
      {/* ==================================================== */}
      {(activeTab === 'owner' || activeTab === 'both') && (
        <section id="owner-roles-subpanel" className="space-y-4 pt-2">
          {/* Section Header */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
              <Crown size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold font-display text-white">
                  {isAr ? 'تحديد رتب المالك (Owner Roles)' : 'Owner Roles Configuration'}
                </h3>
                <span className="text-[10px] font-bold font-mono tracking-wider text-amber-300 bg-amber-500/15 border border-amber-500/40 px-2 py-0.5 rounded-full uppercase">
                  Owner Access
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {isAr
                  ? 'حدد رتب ديسكورد التي تمنح صلاحيات المالك الكاملة. يحصل أصحاب هذه الرتب على نفس صلاحيات وإمكانيات المالك الأساسي في كافة الصفحات والعمليات.'
                  : 'Select Discord server roles that grant full Owner-level access. Users holding any of these role IDs receive the same authority and permissions as the Primary Owner.'}
              </p>
            </div>
          </div>

          {/* Controls Bar for Owner Roles */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            {/* Search Input */}
            <div className="relative flex-1 max-w-md">
              <Search size={15} className={`absolute top-1/2 -translate-y-1/2 text-slate-400 ${isAr ? 'right-3' : 'left-3'}`} />
              <input
                type="text"
                value={ownerSearchQuery}
                onChange={(e) => setOwnerSearchQuery(e.target.value)}
                placeholder={isAr ? 'ابحث باسم رتبة المالك أو الـ Role ID...' : 'Search owner role name or Snowflake ID...'}
                className={`w-full bg-slate-950/80 border border-slate-700/80 rounded-xl py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors ${
                  isAr ? 'pr-9 pl-4' : 'pl-9 pr-4'
                }`}
              />
              {ownerSearchQuery && (
                <button
                  onClick={() => setOwnerSearchQuery('')}
                  className={`absolute top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 text-xs ${isAr ? 'left-3' : 'right-3'}`}
                >
                  <X size={14} />
                </button>
              )}
            </div>

            {/* Filter Mode Chips */}
            <div className="flex items-center gap-1.5 p-1 bg-slate-950/80 rounded-xl border border-slate-800 shrink-0">
              <button
                onClick={() => setOwnerFilterMode('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  ownerFilterMode === 'all'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {isAr ? `الكل (${availableRoles.length})` : `All (${availableRoles.length})`}
              </button>
              <button
                onClick={() => setOwnerFilterMode('selected')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  ownerFilterMode === 'selected'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {isAr ? `صلاحيات المالك (${selectedOwnerRoleIds.size})` : `Owner Access (${selectedOwnerRoleIds.size})`}
              </button>
              <button
                onClick={() => setOwnerFilterMode('unselected')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  ownerFilterMode === 'unselected'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {isAr ? 'غير محدد' : 'Unselected'}
              </button>
            </div>

            {/* Save / Reset Actions */}
            <div className="flex items-center gap-2 shrink-0">
              {hasUnsavedOwnerChanges && (
                <Button
                  variant="outline"
                  onClick={() => setSelectedOwnerRoleIds(new Set(savedOwnerRoleIds))}
                  disabled={ownerSaving}
                  className="text-xs py-2 px-3 border-slate-700 text-slate-300 hover:bg-slate-800"
                >
                  {isAr ? 'إلغاء' : 'Reset'}
                </Button>
              )}

              <Button
                variant="primary"
                onClick={handleSaveOwnerRoles}
                disabled={ownerSaving || !hasUnsavedOwnerChanges}
                className={`text-xs py-2 px-4 gap-2 font-semibold ${
                  hasUnsavedOwnerChanges 
                    ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 ring-2 ring-amber-400/40 ring-offset-2 ring-offset-slate-900' 
                    : 'opacity-60 cursor-not-allowed'
                }`}
              >
                {ownerSaving ? (
                  <>
                    <RefreshCw size={14} className="animate-spin" />
                    <span>{isAr ? 'جاري الحفظ...' : 'Saving...'}</span>
                  </>
                ) : (
                  <>
                    <Crown size={14} />
                    <span>
                      {hasUnsavedOwnerChanges
                        ? (isAr ? `حفظ رتب المالك (${selectedOwnerRoleIds.size})` : `Save Owner Roles (${selectedOwnerRoleIds.size})`)
                        : (isAr ? 'تم الحفظ' : 'Saved')}
                    </span>
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Roles Grid for Owner Roles */}
          {loading ? (
            <div className="py-12 text-center space-y-2">
              <RefreshCw size={24} className="animate-spin text-amber-400 mx-auto" />
              <p className="text-xs text-slate-400">
                {isAr ? 'جاري جلب رتب السيرفر من ديسكورد...' : 'Loading roles from Discord...'}
              </p>
            </div>
          ) : filteredOwnerRoles.length === 0 ? (
            <div className="py-8 text-center rounded-2xl bg-slate-950/40 border border-slate-800/80 p-4 space-y-1">
              <Crown size={28} className="text-slate-600 mx-auto" />
              <h4 className="text-xs font-semibold text-white">
                {isAr ? 'لم يتم العثور على رتب مطابقة' : 'No matching roles found'}
              </h4>
            </div>
          ) : (
            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1 select-none custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                {filteredOwnerRoles.map((role) => {
                  const isSelected = selectedOwnerRoleIds.has(role.id);
                  const isCopied = copiedRoleId === role.id;

                  return (
                    <div
                      key={`owner-role-${role.id}`}
                      onClick={() => toggleOwnerRole(role.id)}
                      className={`group relative p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                        isSelected
                          ? 'bg-amber-950/30 border-amber-500/50 hover:border-amber-400 shadow-sm shadow-amber-950/20'
                          : 'bg-slate-950/50 border-slate-800 hover:border-slate-700 hover:bg-slate-950/80'
                      }`}
                    >
                      {/* Left: Checkbox + Color + Name & ID */}
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div
                          className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-colors shrink-0 ${
                            isSelected
                              ? 'bg-amber-500 border-amber-400 text-slate-950'
                              : 'border-slate-700 group-hover:border-slate-600 bg-slate-900'
                          }`}
                        >
                          {isSelected && <Check size={13} className="stroke-[3]" />}
                        </div>

                        <div
                          className="w-3 h-3 rounded-full shrink-0 border border-white/20"
                          style={{ backgroundColor: role.colorHex || '#64748b' }}
                          title={`Color: ${role.colorHex}`}
                        />

                        <div className="min-w-0">
                          <span className="font-semibold text-xs sm:text-sm text-white truncate group-hover:text-amber-300 transition-colors block">
                            {role.name}
                          </span>
                          <div className="flex items-center gap-1 mt-0.5">
                            <span className="text-[10px] text-slate-500 font-mono">ID:</span>
                            <code className="text-[10px] font-mono text-slate-400 bg-slate-900/90 px-1 py-0.2 rounded border border-slate-800">
                              {role.id}
                            </code>
                          </div>
                        </div>
                      </div>

                      {/* Right: Copy ID + Owner Access Badge */}
                      <div className="flex items-center gap-1.5 shrink-0" onClick={(e) => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={(e) => handleCopyRoleId(e, role.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-amber-300 hover:bg-slate-800/80 transition-colors"
                          title={isAr ? 'نسخ معرّف الرتبة' : 'Copy Snowflake ID'}
                        >
                          {isCopied ? <CheckCheck size={13} className="text-emerald-400" /> : <Copy size={13} />}
                        </button>

                        {isSelected && (
                          <span className="text-[10px] font-bold font-mono tracking-wide text-amber-300 bg-amber-500/15 border border-amber-500/40 px-2 py-0.5 rounded-full flex items-center gap-1">
                            <Crown size={10} className="text-amber-400" />
                            <span>{isAr ? 'صلاحيات المالك' : 'Owner Access'}</span>
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </section>
      )}

      {/* Footer Info Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-slate-800/80 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <Info size={14} className="text-slate-400 shrink-0" />
          <span>
            {isAr
              ? `تم تحديد ${selectedStaffRoleIds.size} رتبة كطاقم عمل رسمي، و ${selectedOwnerRoleIds.size} رتبة بصلاحيات المالك (Owner Access).`
              : `${selectedStaffRoleIds.size} staff roles and ${selectedOwnerRoleIds.size} Owner Access roles configured.`}
          </span>
        </div>

        <div className="flex items-center gap-2 text-[11px] font-mono text-slate-500">
          <span>Guild ID: {guildId || '1337616297432842252'}</span>
          <span>•</span>
          <span className="text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            {botConnected ? (isAr ? 'البوت متصل' : 'Bot Connected') : (isAr ? 'الخادم متصل' : 'Server Connected')}
          </span>
        </div>
      </div>
    </motion.div>
  );
};
