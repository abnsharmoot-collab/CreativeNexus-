import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Shield, User, FileText, AlertCircle, UserCheck, UserX } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useStaff } from '../../context/StaffContext';
import { StaffMember, StaffRank, StaffStatus } from '../../types/staff';
import { Button } from '../atoms/Button';
import { getRankBadgeConfig } from '../../utils/staffHelpers';

interface EditStaffModalProps {
  isOpen: boolean;
  member: StaffMember | null;
  onClose: () => void;
  onSuccess?: () => void;
}

const RANKS: StaffRank[] = [
  'SUPER_ADMIN',
  'SENIOR_ADMINISTRATOR',
  'ADMINISTRATOR',
  'SENIOR_MODERATOR',
  'MODERATOR'
];

export function EditStaffModal({
  isOpen,
  member,
  onClose,
  onSuccess
}: EditStaffModalProps) {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { updateStaff } = useStaff();

  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [rank, setRank] = useState<StaffRank>('MODERATOR');
  const [status, setStatus] = useState<StaffStatus>('ACTIVE');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen && member) {
      setDisplayName(member.displayName || '');
      setUsername(member.username || '');
      setRank(member.rank || 'MODERATOR');
      setStatus(member.status || 'ACTIVE');
      setNotes(member.notes || '');
      setError('');
    }
  }, [isOpen, member]);

  if (!isOpen || !member) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!displayName.trim() || !username.trim()) {
      setError(isAr ? 'الاسم المعروض واسم المستخدم مطلوبان' : 'Display name and username are required');
      return;
    }

    try {
      setIsSubmitting(true);
      await updateStaff(member.id, {
        displayName: displayName.trim(),
        username: username.trim(),
        rank,
        status,
        notes: notes.trim()
      });
      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      setError(err?.message || (isAr ? 'فشل تحديث بيانات الإداري' : 'Failed to update staff member'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm"
          onClick={onClose}
        />

        {/* Modal Dialog */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden z-10 flex flex-col max-h-[90vh]"
          dir={isAr ? 'rtl' : 'ltr'}
        >
          {/* Header */}
          <div className="p-5 sm:p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
            <div className="flex items-center gap-3">
              <img
                src={member.avatarUrl}
                alt={member.displayName}
                className="w-11 h-11 rounded-full border border-slate-700 object-cover"
              />
              <div>
                <h3 className="font-display font-semibold text-lg text-white">
                  {isAr ? 'تعديل بيانات الإداري' : 'Edit Staff Profile'}
                </h3>
                <p className="text-xs text-slate-400 font-mono">
                  ID: {member.discordId}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X size={18} />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 overflow-y-auto font-sans text-sm">
            {/* Display Name */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                {isAr ? 'الاسم المعروض' : 'Display Name'}
              </label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-cyan-500/50"
                required
              />
            </div>

            {/* Username */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                {isAr ? 'اسم المستخدم (Discord Username)' : 'Discord Username'}
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 start-0 ps-3.5 flex items-center pointer-events-none text-slate-500 text-sm">
                  @
                </span>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-slate-950/80 border border-slate-800 rounded-xl py-2.5 ps-8 pe-4 text-white text-sm focus:outline-none focus:border-cyan-500/50"
                  required
                />
              </div>
            </div>

            {/* Rank Selection */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                {isAr ? 'رتبة الإدارة' : 'Staff Rank'}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {RANKS.map((r) => {
                  const cfg = getRankBadgeConfig(r);
                  const isSelected = rank === r;
                  return (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRank(r)}
                      className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs font-medium text-start transition-all ${
                        isSelected
                          ? `${cfg.bgClass} ${cfg.textClass} ${cfg.borderClass} ring-1 ring-cyan-500/30`
                          : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:bg-slate-950 hover:text-slate-200'
                      }`}
                    >
                      <Shield size={14} className="shrink-0" />
                      <span className="truncate">{isAr ? cfg.labelAr : cfg.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Status Selection */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                {isAr ? 'الحالة الإدارية' : 'Administrative Status'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setStatus('ACTIVE')}
                  className={`flex items-center justify-center gap-2 py-2.5 rounded-xl border text-xs font-medium transition-all ${
                    status === 'ACTIVE'
                      ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30 ring-1 ring-emerald-500/20'
                      : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <UserCheck size={14} />
                  <span>{isAr ? 'نشط (على رأس العمل)' : 'Active Duty'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setStatus('SUSPENDED')}
                  className={`flex items-center justify-center gap-2 py-2.5 rounded-xl border text-xs font-medium transition-all ${
                    status === 'SUSPENDED'
                      ? 'bg-rose-500/20 text-rose-400 border-rose-500/30 ring-1 ring-rose-500/20'
                      : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <UserX size={14} />
                  <span>{isAr ? 'موقوف مؤقتاً' : 'Suspended'}</span>
                </button>
              </div>
            </div>

            {/* Notes */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
                {isAr ? 'ملاحظات إدارية' : 'Admin Notes / Remarks'}
              </label>
              <textarea
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={isAr ? 'ملاحظات داخلية حول المهام، التخصص، أو سبب الحالة...' : 'Internal notes, specializations, or remarks...'}
                className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-cyan-500/50 resize-none"
              />
            </div>

            {/* Error */}
            {error && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center gap-2 text-xs text-rose-400">
                <AlertCircle size={15} className="shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors text-xs font-medium"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>

              <Button
                variant="primary"
                type="submit"
                disabled={isSubmitting || !displayName.trim() || !username.trim()}
                className="px-5 py-2.5 text-xs font-semibold"
              >
                {isSubmitting ? (isAr ? 'جاري الحفظ...' : 'Saving...') : (isAr ? 'حفظ التعديلات' : 'Save Changes')}
              </Button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
