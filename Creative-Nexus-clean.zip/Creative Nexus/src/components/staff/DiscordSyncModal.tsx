import React, { useState, useEffect } from 'react';
import { useStaff } from '../../context/StaffContext';
import { 
  X, 
  Radio, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  Sliders, 
  Users, 
  ShieldCheck, 
  Layers, 
  ExternalLink,
  Bot,
  Hash,
  Crown
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { OwnerModeratorRoleSelector } from '../owner/OwnerModeratorRoleSelector';

interface DiscordSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DiscordSyncModal: React.FC<DiscordSyncModalProps> = ({ isOpen, onClose }) => {
  const { staff, syncWithDiscord, isSyncing, lastSyncedAt } = useStaff();

  const [activeTab, setActiveTab] = useState<'sync' | 'settings' | 'role'>('sync');
  const [guildId, setGuildId] = useState('1080000000000000000');

  const [botToken, setBotToken] = useState('');
  const [syncStatusStep, setSyncStatusStep] = useState<string | null>(null);
  const [syncFeedback, setSyncFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [serverInfo, setServerInfo] = useState<any>(null);
  const [testingConnection, setTestingConnection] = useState(false);

  // Fetch initial server status
  useEffect(() => {
    if (isOpen) {
      fetchServerStatus();
    }
  }, [isOpen]);

  const fetchServerStatus = async () => {
    try {
      const res = await fetch(`/api/discord/server-status?guildId=${encodeURIComponent(guildId)}`);
      if (res.ok) {
        const data = await res.json();
        setServerInfo(data);
        if (data.guildId) setGuildId(data.guildId);
      }
    } catch (err) {
      console.warn('Error fetching Discord server status:', err);
    }
  };

  const handleTestConnection = async () => {
    setTestingConnection(true);
    setSyncFeedback(null);
    try {
      const res = await fetch(`/api/discord/server-status?guildId=${encodeURIComponent(guildId)}`);
      const data = await res.json();
      setServerInfo(data);
      setSyncFeedback({
        type: 'success',
        message: `Connected to "${data.serverName || 'Discord Server'}". ${data.onlineCount || 0} members active now.`
      });
    } catch (err: any) {
      setSyncFeedback({
        type: 'error',
        message: err?.message || 'Failed to reach Discord Gateway'
      });
    } finally {
      setTestingConnection(false);
    }
  };

  const handleExecuteSync = async () => {
    setSyncFeedback(null);
    setSyncStatusStep('1/3: Connecting to Discord Gateway...');
    
    try {
      setTimeout(() => {
        setSyncStatusStep('2/3: Fetching latest Discord avatars & nicknames...');
      }, 700);

      setTimeout(() => {
        setSyncStatusStep('3/3: Updating Firestore records and audit logs...');
      }, 1400);

      const res = await syncWithDiscord({ guildId, botToken: botToken || undefined });
      
      setSyncFeedback({
        type: 'success',
        message: res.message || `Successfully synchronized ${res.syncedCount} staff profiles with Discord.`
      });
      fetchServerStatus();
    } catch (err: any) {
      setSyncFeedback({
        type: 'error',
        message: err?.message || 'Failed to complete Discord roster sync'
      });
    } finally {
      setSyncStatusStep(null);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-archive-dark/85 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-2xl bg-archive-card border border-archive-cyan/25 rounded-2xl p-6 shadow-2xl shadow-archive-cyan/10 overflow-hidden max-h-[90vh] flex flex-col"
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 end-4 p-1.5 rounded-lg text-archive-paper-muted hover:text-archive-paper hover:bg-archive-dark/60 transition-colors"
          >
            <X size={18} />
          </button>

          {/* Modal Header */}
          <div className="flex items-center gap-3 mb-5">
            <div className="w-12 h-12 rounded-2xl bg-[#5865F2]/15 border border-[#5865F2]/30 flex items-center justify-center text-[#5865F2]">
              <Radio size={24} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-archive-paper flex items-center gap-2">
                <span>Discord Server Synchronization</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 font-mono border border-emerald-500/20">
                  LIVE GATEWAY
                </span>
              </h3>
              <p className="text-xs text-archive-paper-muted">
                Synchronize staff avatars, usernames, and server presence with Discord
              </p>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex items-center gap-2 border-b border-archive-cyan/15 pb-3 mb-5">
            <button
              onClick={() => setActiveTab('sync')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'sync'
                  ? 'bg-archive-cyan/20 text-archive-cyan border border-archive-cyan/30'
                  : 'text-archive-paper-muted hover:text-archive-paper'
              }`}
            >
              <RefreshCw size={14} className={isSyncing ? 'animate-spin' : ''} />
              <span>Roster Sync & Live Server</span>
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'settings'
                  ? 'bg-archive-cyan/20 text-archive-cyan border border-archive-cyan/30'
                  : 'text-archive-paper-muted hover:text-archive-paper'
              }`}
            >
              <Sliders size={14} />
              <span>Server & Bot Credentials</span>
            </button>
            <button
              id="sync-modal-role-tab"
              onClick={() => setActiveTab('role')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all ${
                activeTab === 'role'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                  : 'text-archive-paper-muted hover:text-archive-paper'
              }`}
            >
              <Crown size={14} className="text-amber-400" />
              <span>Moderator Role (Owner Choice)</span>
            </button>
          </div>

          {/* Feedback message */}
          {syncFeedback && (
            <div className={`p-3 rounded-xl mb-4 text-xs flex items-center gap-2 border ${
              syncFeedback.type === 'success'
                ? 'bg-emerald-500/10 border-emerald-500/25 text-emerald-300'
                : 'bg-rose-500/10 border-rose-500/25 text-rose-300'
            }`}>
              {syncFeedback.type === 'success' ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
              <span>{syncFeedback.message}</span>
            </div>
          )}

          {/* Tab 1: Sync & Live Server */}
          {activeTab === 'sync' && (
            <div className="space-y-4 overflow-y-auto pe-1">
              {/* Server Live Stats Card */}
              <div className="p-4 rounded-xl bg-archive-dark/60 border border-archive-cyan/15 grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-2.5 rounded-lg bg-black/30 border border-archive-cyan/10">
                  <div className="text-[10px] font-mono uppercase text-archive-paper-muted">Community Server</div>
                  <div className="text-xs font-bold text-archive-paper truncate mt-0.5">
                    {serverInfo?.serverName || 'CREATINE NEXUS'}
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-black/30 border border-archive-cyan/10">
                  <div className="text-[10px] font-mono uppercase text-archive-paper-muted">Total Citizens</div>
                  <div className="text-xs font-bold text-archive-cyan mt-0.5">
                    {serverInfo?.totalMembers || 540} Members
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-black/30 border border-archive-cyan/10">
                  <div className="text-[10px] font-mono uppercase text-archive-paper-muted">Live Presence</div>
                  <div className="text-xs font-bold text-emerald-400 mt-0.5">
                    {serverInfo?.onlineCount || 42} Online
                  </div>
                </div>
                <div className="p-2.5 rounded-lg bg-black/30 border border-archive-cyan/10">
                  <div className="text-[10px] font-mono uppercase text-archive-paper-muted">Staff on Roster</div>
                  <div className="text-xs font-bold text-amber-400 mt-0.5">
                    {staff.length} Recorded
                  </div>
                </div>
              </div>

              {/* Sync Trigger Section */}
              <div className="p-4 rounded-xl bg-gradient-to-br from-[#5865F2]/10 via-archive-dark to-archive-dark border border-[#5865F2]/25 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-archive-paper flex items-center gap-2">
                    <Radio size={14} className="text-[#5865F2]" />
                    <span>Synchronize Staff with Discord Server</span>
                  </div>
                  {lastSyncedAt && (
                    <span className="text-[11px] font-mono text-archive-paper-muted">
                      Last: {new Date(lastSyncedAt).toLocaleTimeString()}
                    </span>
                  )}
                </div>

                <p className="text-xs text-archive-paper-muted leading-relaxed">
                  Queries the official Discord CDN and Guild Gateway for all registered staff members. 
                  Updates avatar imagery, verifies usernames, and syncs status in real-time.
                </p>

                {syncStatusStep && (
                  <div className="py-2 px-3 rounded-lg bg-archive-dark/80 border border-archive-cyan/20 text-xs font-mono text-archive-cyan flex items-center gap-2">
                    <RefreshCw size={13} className="animate-spin" />
                    <span>{syncStatusStep}</span>
                  </div>
                )}

                <button
                  onClick={handleExecuteSync}
                  disabled={isSyncing}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-xs font-bold text-white bg-[#5865F2] hover:bg-[#4752C4] shadow-lg shadow-[#5865F2]/20 transition-all disabled:opacity-60"
                >
                  <RefreshCw size={15} className={isSyncing ? 'animate-spin' : ''} />
                  <span>{isSyncing ? 'Running Synchronization...' : 'Run Full Discord Roster Sync Now'}</span>
                </button>
              </div>

              {/* Staff Members Sync Table Preview */}
              <div>
                <div className="text-xs font-bold text-archive-paper mb-2 flex items-center justify-between">
                  <span>Registered Staff & Discord Links</span>
                  <span className="text-[11px] font-normal text-archive-paper-muted">
                    {staff.length} profiles linked
                  </span>
                </div>

                <div className="divide-y divide-archive-cyan/10 border border-archive-cyan/15 rounded-xl overflow-hidden bg-archive-dark/40 max-h-48 overflow-y-auto">
                  {staff.map((member) => (
                    <div key={member.id} className="p-2.5 flex items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={member.avatarUrl}
                          alt={member.displayName}
                          className="w-7 h-7 rounded-full border border-archive-cyan/30 object-cover"
                        />
                        <div>
                          <div className="font-semibold text-archive-paper flex items-center gap-1.5">
                            <span>{member.displayName}</span>
                            <span className="text-[10px] text-archive-paper-muted font-mono">@{member.username}</span>
                          </div>
                          <div className="text-[10px] font-mono text-archive-paper-muted">
                            ID: {member.discordId}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-archive-cyan/10 text-archive-cyan border border-archive-cyan/20">
                          {member.rank.replace(/_/g, ' ')}
                        </span>
                        <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">
                          Synced
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Server Settings */}
          {activeTab === 'settings' && (
            <div className="space-y-4 overflow-y-auto pe-1">
              <div className="p-4 rounded-xl bg-archive-dark/60 border border-archive-cyan/15 space-y-3">
                <div className="text-xs font-bold text-archive-paper">
                  Discord Server & Guild Parameters
                </div>

                <div>
                  <label className="block text-[11px] font-mono uppercase text-archive-cyan/80 mb-1">
                    Discord Guild (Server) ID
                  </label>
                  <input
                    type="text"
                    value={guildId}
                    onChange={(e) => setGuildId(e.target.value)}
                    placeholder="e.g. 1080000000000000000"
                    className="w-full bg-archive-dark/80 border border-archive-cyan/20 rounded-xl px-3.5 py-2.5 text-xs font-mono text-archive-paper focus:outline-none focus:border-archive-cyan"
                  />
                  <p className="text-[11px] text-archive-paper-muted mt-1">
                    Found in Discord under Server Settings &gt; Widget, or right click Server icon &gt; Copy Server ID.
                  </p>
                </div>

                <div>
                  <label className="block text-[11px] font-mono uppercase text-archive-cyan/80 mb-1">
                    Discord Bot Token (Optional)
                  </label>
                  <input
                    type="password"
                    value={botToken}
                    onChange={(e) => setBotToken(e.target.value)}
                    placeholder="DISCORD_BOT_TOKEN for member enumeration"
                    className="w-full bg-archive-dark/80 border border-archive-cyan/20 rounded-xl px-3.5 py-2.5 text-xs font-mono text-archive-paper focus:outline-none focus:border-archive-cyan"
                  />
                  <p className="text-[11px] text-archive-paper-muted mt-1">
                    Can also be provided via <code>DISCORD_BOT_TOKEN</code> in project secrets.
                  </p>
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={handleTestConnection}
                    disabled={testingConnection}
                    className="py-2 px-4 rounded-xl text-xs font-semibold bg-archive-cyan/20 text-archive-cyan border border-archive-cyan/30 hover:bg-archive-cyan/30 transition-all flex items-center gap-1.5"
                  >
                    <Radio size={14} className={testingConnection ? 'animate-spin' : ''} />
                    <span>{testingConnection ? 'Testing Connection...' : 'Test Discord Connection'}</span>
                  </button>

                  <a
                    href="https://discord.com/developers/applications"
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs text-archive-cyan hover:underline flex items-center gap-1"
                  >
                    Discord Dev Portal <ExternalLink size={12} />
                  </a>
                </div>
              </div>

              {/* Channels list if available */}
              {serverInfo?.channels && serverInfo.channels.length > 0 && (
                <div className="p-4 rounded-xl bg-archive-dark/40 border border-archive-cyan/10">
                  <div className="text-xs font-bold text-archive-paper mb-2 flex items-center gap-1.5">
                    <Hash size={14} className="text-archive-cyan" />
                    <span>Live Server Channels ({serverInfo.channels.length})</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {serverInfo.channels.map((ch: any) => (
                      <span key={ch.id} className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-black/40 border border-archive-cyan/15 text-archive-paper">
                        #{ch.name}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Tab 3: Owner Moderator Role Configuration */}
          {activeTab === 'role' && (
            <div className="space-y-4">
              <OwnerModeratorRoleSelector compact />
            </div>
          )}

          {/* Footer */}
          <div className="mt-5 pt-3 border-t border-archive-cyan/15 flex items-center justify-end">
            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl text-xs font-semibold bg-archive-cyan/20 text-archive-cyan border border-archive-cyan/30 hover:bg-archive-cyan/30 transition-all"
            >
              Done
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
