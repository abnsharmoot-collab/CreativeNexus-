import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Search, CheckCircle2, RefreshCw, Shield, AlertCircle } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useStaff } from '../../context/StaffContext';
import { StaffRank } from '../../types/staff';
import { Button } from '../atoms/Button';
import { getRankBadgeConfig } from '../../utils/staffHelpers';

interface AddStaffModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

const RANKS: StaffRank[] = [
  'SUPER_ADMIN',
  'SENIOR_ADMINISTRATOR',
  'ADMINISTRATOR',
  'SENIOR_MODERATOR',
  'MODERATOR'
];

export function AddStaffModal({ isOpen, onClose, onSuccess }: AddStaffModalProps) {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { addStaff } = useStaff();

  const [formData, setFormData] = useState({
    discordId: '',
    displayName: '',
    username: '',
    avatarUrl: '',
    rank: 'MODERATOR' as StaffRank,
    points: 0,
    notes: '',
  });
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [fetchingDiscord, setFetchingDiscord] = useState(false);
  const [discordResolved, setDiscordResolved] = useState(false);

  const handleFetchDiscord = async () => {
    const id = formData.discordId.trim();
    if (!id) {
      setError(isAr ? 'يرجى إدخال معرف الديسكورد أولاً' : 'Please enter a Discord ID first');
      return;
    }
    setError('');
    setFetchingDiscord(true);
    try {
      const res = await fetch(`/api/discord/user-lookup/${id}`);
      const text = await res.text();
      let data: any = {};
      if (text && text.trim()) {
        try {
          data = JSON.parse(text);
        } catch {
          data = {};
        }
      }
      if (res.ok) {
        if (data.found) {
          setFormData(prev => ({
            ...prev,
            displayName: data.displayName || prev.displayName || data.username,
            username: data.username || prev.username,
            avatarUrl: data.avatarUrl || prev.avatarUrl
          }));
          setDiscordResolved(true);
        }
      } else {
        setError(data.error || (isAr ? 'تعذر جلب بيانات المستخدم من الديسكورد' : 'Could not resolve Discord user'));
      }
    } catch (err: any) {
      setError(err?.message || (isAr ? 'فشل الاتصال بخادم الديسكورد' : 'Failed to query Discord Gateway'));
    } finally {
      setFetchingDiscord(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!formData.discordId.trim() || !formData.displayName.trim() || !formData.username.trim()) {
      setError(isAr ? 'يرجى ملء كافة الحقول الإلزامية' : 'Please fill out all required fields');
      return;
    }

    try {
      setIsSubmitting(true);
      await addStaff({
        ...formData,
        status: 'ACTIVE',
      });
      
      // Reset form
      setFormData({
        discordId: '',
        displayName: '',
        username: '',
        avatarUrl: '',
        rank: 'MODERATOR',
        points: 0,
        notes: '',
      });
      setDiscordResolved(false);
      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || (isAr ? 'فشل إضافة عضو الإدارة' : 'Failed to add staff member'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            onClick={onClose}
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ duration: 0.2 }}
            className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden z-10 flex flex-col max-h-[90vh]"
            dir={isAr ? 'rtl' : 'ltr'}
          >
            {/* Header */}
            <div className="p-5 sm:p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
              <div>
                <h3 className="font-display font-semibold text-lg text-white">
                  {isAr ? 'إضافة عضو جديد لطاقم الإدارة' : 'Enroll New Staff Member'}
                </h3>
                <p className="text-xs text-slate-400 font-sans mt-0.5">
                  {isAr ? 'تسجيل إداري جديد في سجل CREATINE NEXUS' : 'Register a staff member in the official CREATINE NEXUS roster'}
                </p>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {/* Form */}
            <div className="p-5 sm:p-6 overflow-y-auto font-sans text-sm">
              <form id="add-staff-form" onSubmit={handleSubmit} className="space-y-4">
                {error && (
                  <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center gap-2 text-xs text-rose-400">
                    <AlertCircle size={15} className="shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                {/* Discord Snowflake ID with Auto-fetch */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                    {isAr ? 'معرف الديسكورد (Discord Snowflake ID)' : 'Discord Snowflake ID'}
                  </label>
                  <div className="flex gap-2">
                    <input
                      required
                      type="text"
                      value={formData.discordId}
                      onChange={e => {
                        setFormData({ ...formData, discordId: e.target.value });
                        setDiscordResolved(false);
                      }}
                      className="flex-1 bg-slate-950/80 border border-slate-800 rounded-xl px-4 py-2.5 text-white font-mono text-xs sm:text-sm focus:outline-none focus:border-cyan-500/50"
                      placeholder="e.g. 871043296280076308"
                    />
                    <button
                      type="button"
                      onClick={handleFetchDiscord}
                      disabled={fetchingDiscord || !formData.discordId.trim()}
                      className="px-3.5 py-2.5 bg-[#5865F2]/20 hover:bg-[#5865F2]/30 text-[#8ea1e1] border border-[#5865F2]/40 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all disabled:opacity-50 shrink-0"
                    >
                      {fetchingDiscord ? <RefreshCw size={13} className="animate-spin" /> : <Search size={13} />}
                      <span>{isAr ? 'استعلام ديسكورد' : 'Sync Discord'}</span>
                    </button>
                  </div>

                  {discordResolved && (
                    <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-2.5">
                      {formData.avatarUrl && (
                        <img
                          src={formData.avatarUrl}
                          alt=""
                          className="w-8 h-8 rounded-full border border-emerald-500/40 object-cover shrink-0"
                        />
                      )}
                      <div className="text-xs text-emerald-400 font-sans">
                        <span className="font-semibold">{formData.displayName}</span>
                        <span className="text-emerald-500/80 ms-1">(@{formData.username})</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Display Name and Username */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                      {isAr ? 'الاسم المعروض' : 'Display Name'}
                    </label>
                    <input
                      required
                      type="text"
                      value={formData.displayName}
                      onChange={e => setFormData({ ...formData, displayName: e.target.value })}
                      className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-4 py-2.5 text-white text-xs sm:text-sm focus:outline-none focus:border-cyan-500/50"
                      placeholder="e.g. Ahmed"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                      {isAr ? 'اسم المستخدم' : 'Username'}
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 start-0 ps-3.5 flex items-center pointer-events-none text-slate-500 text-xs">
                        @
                      </span>
                      <input
                        required
                        type="text"
                        value={formData.username}
                        onChange={e => setFormData({ ...formData, username: e.target.value })}
                        className="w-full bg-slate-950/80 border border-slate-800 rounded-xl py-2.5 ps-7 pe-4 text-white text-xs sm:text-sm focus:outline-none focus:border-cyan-500/50 font-mono"
                        placeholder="ahmed_mod"
                      />
                    </div>
                  </div>
                </div>

                {/* Rank Selection */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                    {isAr ? 'رتبة الإدارة' : 'Staff Rank'}
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {RANKS.map((r) => {
                      const cfg = getRankBadgeConfig(r);
                      const isSelected = formData.rank === r;
                      return (
                        <button
                          key={r}
                          type="button"
                          onClick={() => setFormData({ ...formData, rank: r })}
                          className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs font-medium text-start transition-all ${
                            isSelected
                              ? `${cfg.bgClass} ${cfg.textClass} ${cfg.borderClass} ring-1 ring-cyan-500/30`
                              : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:bg-slate-950 hover:text-slate-200'
                          }`}
                        >
                          <Shield size={14} className="shrink-0" />
                          <span className="truncate">{isAr ? cfg.labelAr : cfg.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Initial Points */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                    {isAr ? 'النقاط الافتتاحية' : 'Initial Points'}
                  </label>
                  <input
                    required
                    type="number"
                    min="0"
                    value={formData.points}
                    onChange={e => setFormData({ ...formData, points: Math.max(0, parseInt(e.target.value) || 0) })}
                    className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-4 py-2.5 text-white font-mono text-sm focus:outline-none focus:border-cyan-500/50"
                  />
                </div>

                {/* Notes */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    {isAr ? 'ملاحظات إدارية (اختياري)' : 'Notes (Optional)'}
                  </label>
                  <textarea
                    rows={2}
                    value={formData.notes}
                    onChange={e => setFormData({ ...formData, notes: e.target.value })}
                    className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-4 py-2 text-white text-xs sm:text-sm focus:outline-none focus:border-cyan-500/50 resize-none"
                    placeholder={isAr ? 'مهام الإداري، قسم الإشراف، أو أي معلومات هامة...' : 'Assigned roles, departments, or reference details...'}
                  />
                </div>
              </form>
            </div>

            {/* Footer */}
            <div className="p-5 sm:p-6 border-t border-slate-800 bg-slate-950 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors text-xs font-medium"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <Button
                variant="primary"
                type="submit"
                form="add-staff-form"
                disabled={isSubmitting || !formData.discordId.trim() || !formData.displayName.trim() || !formData.username.trim()}
                className="px-5 py-2.5 text-xs font-semibold"
              >
                {isSubmitting ? (isAr ? 'جاري التسجيل...' : 'Enrolling...') : (isAr ? 'تسجيل الإداري' : 'Enroll Staff')}
              </Button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
