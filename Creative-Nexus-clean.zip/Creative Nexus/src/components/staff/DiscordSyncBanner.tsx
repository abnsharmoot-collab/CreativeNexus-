import React, { useState, useEffect } from 'react';
import { useStaff } from '../../context/StaffContext';
import { 
  RefreshCw, 
  Radio, 
  Settings, 
  CheckCircle2, 
  Users, 
  ShieldCheck, 
  ExternalLink,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface DiscordSyncBannerProps {
  onOpenSyncSettings: () => void;
}

export const DiscordSyncBanner: React.FC<DiscordSyncBannerProps> = ({ onOpenSyncSettings }) => {
  const { staff, syncWithDiscord, isSyncing, lastSyncedAt } = useStaff();
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);
  const [serverStats, setServerStats] = useState<{
    serverName: string;
    onlineCount: number;
    totalMembers: number;
    instantInvite?: string;
  }>({
    serverName: 'CREATINE NEXUS',
    onlineCount: 42,
    totalMembers: 540
  });

  // Fetch quick server stats on mount
  useEffect(() => {
    fetch('/api/discord/server-status')
      .then(res => res.json())
      .then(data => {
        if (data.serverName) {
          setServerStats({
            serverName: data.serverName,
            onlineCount: data.onlineCount || 42,
            totalMembers: data.totalMembers || 540,
            instantInvite: data.instantInvite
          });
        }
      })
      .catch(() => {});
  }, []);

  const handleQuickSync = async () => {
    try {
      const res = await syncWithDiscord();
      setSyncFeedback(res.message);
      setTimeout(() => setSyncFeedback(null), 4000);
    } catch (err: any) {
      setSyncFeedback(err?.message || 'Sync failed');
      setTimeout(() => setSyncFeedback(null), 4000);
    }
  };

  const formatLastSync = (isoString: string | null) => {
    if (!isoString) return 'Not yet synced';
    const date = new Date(isoString);
    const now = new Date();
    const diffSec = Math.floor((now.getTime() - date.getTime()) / 1000);
    if (diffSec < 60) return 'Just now';
    if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const activeStaffCount = staff.filter(s => s.status === 'ACTIVE').length;

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-archive-dark via-[#101e28] to-archive-dark border border-archive-cyan/20 p-4 md:p-5 shadow-lg shadow-black/40 mb-8">
      {/* Background ambient accent */}
      <div className="absolute -top-16 -end-16 w-48 h-48 bg-archive-cyan/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-16 -start-16 w-48 h-48 bg-[#5865F2]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        {/* Left: Server Status & Metadata */}
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-12 h-12 rounded-2xl bg-[#5865F2]/15 border border-[#5865F2]/30 flex items-center justify-center text-[#5865F2] shadow-[0_0_15px_rgba(88,101,242,0.2)]">
              <Radio size={22} className={isSyncing ? 'animate-pulse' : ''} />
            </div>
            <span className="absolute -bottom-1 -end-1 flex h-3.5 w-3.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 border-2 border-archive-dark" />
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h3 className="font-bold text-base text-archive-paper flex items-center gap-2">
                <span>{serverStats.serverName}</span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-[#5865F2]/20 text-[#8ea1e1] border border-[#5865F2]/30">
                  Discord Server
                </span>
              </h3>
            </div>

            <div className="flex items-center gap-4 mt-1 text-xs text-archive-paper-muted flex-wrap">
              <span className="flex items-center gap-1.5">
                <Users size={13} className="text-archive-cyan" />
                <strong className="text-archive-paper font-semibold">{serverStats.totalMembers}</strong> Citizens
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
                <strong className="text-archive-paper font-semibold">{serverStats.onlineCount}</strong> Online
              </span>
              <span className="flex items-center gap-1.5">
                <ShieldCheck size={13} className="text-archive-cyan" />
                <strong className="text-archive-paper font-semibold">{activeStaffCount}</strong> Staff Members
              </span>
              <span className="text-archive-cyan/70 font-mono text-[11px]">
                Last Sync: {formatLastSync(lastSyncedAt)}
              </span>
            </div>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2.5 w-full lg:w-auto justify-end flex-wrap">
          {syncFeedback && (
            <motion.div
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0 }}
              className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-1.5"
            >
              <CheckCircle2 size={14} />
              <span>{syncFeedback}</span>
            </motion.div>
          )}

          <button
            onClick={handleQuickSync}
            disabled={isSyncing}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#5865F2] to-[#4752C4] hover:from-[#4752C4] hover:to-[#3b43a9] shadow-md shadow-[#5865F2]/20 transition-all disabled:opacity-60"
          >
            <RefreshCw size={14} className={isSyncing ? 'animate-spin' : ''} />
            <span>{isSyncing ? 'Syncing with Discord...' : 'Sync Server Roster'}</span>
          </button>

          <button
            onClick={onOpenSyncSettings}
            className="flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-medium text-archive-paper-muted hover:text-archive-paper bg-archive-dark/60 hover:bg-archive-dark border border-archive-cyan/20 transition-all"
            title="Configure Server Guild & Sync Options"
          >
            <Settings size={14} />
            <span className="hidden sm:inline">Sync Hub</span>
          </button>
        </div>
      </div>
    </div>
  );
};
