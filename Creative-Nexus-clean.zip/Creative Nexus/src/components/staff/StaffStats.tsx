import React from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { Users, UserCheck, UserX, Star, Trophy, Award } from 'lucide-react';
import { motion } from 'motion/react';
import { useStaff } from '../../context/StaffContext';

export function StaffStats() {
  const { t, language } = useLanguage();
  const { staff } = useStaff();
  const isAr = language === 'ar';

  const activeStaffList = staff.filter(s => s.status !== 'REMOVED');
  
  const totalStaff = activeStaffList.length;
  const activeStaff = activeStaffList.filter(s => s.status === 'ACTIVE').length;
  const suspendedStaff = activeStaffList.filter(s => s.status === 'SUSPENDED').length;
  const totalPoints = activeStaffList.reduce((sum, s) => sum + s.points, 0);

  // Highest point earner
  const topMember = activeStaffList.length > 0
    ? [...activeStaffList].sort((a, b) => b.points - a.points)[0]
    : null;

  const stats = [
    { 
      label: isAr ? 'إجمالي طاقم العمل' : 'Total Staff', 
      value: totalStaff, 
      subtext: isAr ? `${activeStaff} نشط • ${suspendedStaff} موقوف` : `${activeStaff} active • ${suspendedStaff} suspended`,
      icon: Users, 
      color: 'text-cyan-400',
      bgGrad: 'from-cyan-500/10 to-transparent',
      borderColor: 'border-cyan-500/20'
    },
    { 
      label: isAr ? 'على رأس العمل' : 'Active Duty', 
      value: activeStaff, 
      subtext: isAr ? 'جاهزون للمهام والرقابة' : 'Operational & in service',
      icon: UserCheck, 
      color: 'text-emerald-400',
      bgGrad: 'from-emerald-500/10 to-transparent',
      borderColor: 'border-emerald-500/20'
    },
    { 
      label: isAr ? 'إجمالي نقاط التقدير' : 'Total Points Awarded', 
      value: totalPoints.toLocaleString(), 
      subtext: isAr ? 'مجموع نقاط الإنجاز' : 'Cumulative merit balance',
      icon: Star, 
      color: 'text-amber-400',
      bgGrad: 'from-amber-500/10 to-transparent',
      borderColor: 'border-amber-500/20'
    },
    { 
      label: isAr ? 'المتصدر بالإنجاز' : 'Top Contributor', 
      value: topMember ? topMember.displayName : (isAr ? 'لا يوجد' : 'None'), 
      subtext: topMember ? `${topMember.points.toLocaleString()} ${isAr ? 'نقطة' : 'pts'} • @${topMember.username}` : (isAr ? 'قائمة فارغة' : 'Roster empty'),
      icon: Trophy, 
      color: 'text-purple-400',
      bgGrad: 'from-purple-500/10 to-transparent',
      borderColor: 'border-purple-500/20',
      avatar: topMember?.avatarUrl
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: i * 0.05 }}
          className={`relative overflow-hidden rounded-2xl bg-slate-900/60 backdrop-blur-xl border ${stat.borderColor} p-5 transition-all duration-300 hover:border-slate-700/80 hover:bg-slate-900/80`}
        >
          {/* Subtle Ambient Background Gradient */}
          <div className={`absolute top-0 end-0 -mt-8 -me-8 w-32 h-32 bg-gradient-to-br ${stat.bgGrad} rounded-full blur-2xl pointer-events-none opacity-60`} />

          <div className="flex items-center justify-between gap-3 mb-3">
            <span className="text-xs font-medium uppercase tracking-wider text-slate-400 font-sans">
              {stat.label}
            </span>
            <div className={`p-2 rounded-xl bg-slate-800/80 border border-slate-700/50 ${stat.color}`}>
              <stat.icon size={17} />
            </div>
          </div>

          <div className="flex items-baseline justify-between gap-2">
            <div className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-display truncate">
              {stat.value}
            </div>
            {stat.avatar && (
              <img 
                src={stat.avatar} 
                alt="" 
                className="w-7 h-7 rounded-full border border-purple-400/40 object-cover shrink-0" 
              />
            )}
          </div>

          <p className="mt-2 text-xs text-slate-400/90 font-sans truncate">
            {stat.subtext}
          </p>
        </motion.div>
      ))}
    </div>
  );
}
