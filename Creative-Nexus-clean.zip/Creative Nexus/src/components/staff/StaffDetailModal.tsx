import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Shield, Star, Calendar, Clock, Copy, Check, ExternalLink, 
  Plus, Minus, Edit3, UserX, UserCheck, Trash2, History, Award, AlertCircle 
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../context/LanguageContext';
import { useStaff } from '../../context/StaffContext';
import { useAuth } from '../../context/AuthContext';
import { StaffMember, StaffHistoryEvent, StaffPointTransaction } from '../../types/staff';
import { getRankBadgeConfig, getStatusBadgeConfig, formatRelativeTime } from '../../utils/staffHelpers';
import { PointsModal } from './PointsModal';
import { EditStaffModal } from './EditStaffModal';

interface StaffDetailModalProps {
  isOpen: boolean;
  member: StaffMember | null;
  onClose: () => void;
  onUpdated?: () => void;
}

export function StaffDetailModal({
  isOpen,
  member,
  onClose,
  onUpdated
}: StaffDetailModalProps) {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { getStaffDetails, suspendStaff, reactivateStaff, removeStaff } = useStaff();
  const { hasPermission } = useAuth();

  const [details, setDetails] = useState<{
    history: StaffHistoryEvent[];
    pointTransactions: StaffPointTransaction[];
  }>({ history: [], pointTransactions: [] });
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [copiedId, setCopiedId] = useState(false);

  // Submodals
  const [isPointsOpen, setIsPointsOpen] = useState(false);
  const [pointsType, setPointsType] = useState<'ADD' | 'REMOVE'>('ADD');
  const [isEditOpen, setIsEditOpen] = useState(false);

  // Permissions
  const canEdit = hasPermission('EDIT_STAFF');
  const canSuspend = hasPermission('SUSPEND_STAFF');
  const canRemove = hasPermission('REMOVE_STAFF');
  const canManagePoints = hasPermission('MANAGE_POINTS') || hasPermission('ADD_POINTS');

  useEffect(() => {
    if (isOpen && member) {
      setLoadingDetails(true);
      getStaffDetails(member.id)
        .then(res => {
          setDetails({
            history: res.history || [],
            pointTransactions: res.pointTransactions || []
          });
        })
        .catch(err => console.warn('Could not fetch detail logs:', err))
        .finally(() => setLoadingDetails(false));
    }
  }, [isOpen, member?.id, getStaffDetails]);

  if (!isOpen || !member) return null;

  const rankCfg = getRankBadgeConfig(member.rank);
  const statusCfg = getStatusBadgeConfig(member.status);

  const handleCopyId = () => {
    navigator.clipboard.writeText(member.discordId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleToggleStatus = async () => {
    try {
      if (member.status === 'ACTIVE') {
        await suspendStaff(member.id);
      } else {
        await reactivateStaff(member.id);
      }
      if (onUpdated) onUpdated();
    } catch (e: any) {
      alert(e?.message || 'Failed to update status');
    }
  };

  const handleRemove = async () => {
    if (!confirm(isAr ? 'هل أنت متأكد من رغبتك في إزالة هذا الإداري من الطاقم؟' : 'Are you sure you want to remove this staff member?')) return;
    try {
      await removeStaff(member.id);
      if (onUpdated) onUpdated();
      onClose();
    } catch (e: any) {
      alert(e?.message || 'Failed to remove staff member');
    }
  };

  return (
    <>
      <AnimatePresence>
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            onClick={onClose}
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 15 }}
            transition={{ duration: 0.2 }}
            className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden z-10 flex flex-col max-h-[90vh]"
            dir={isAr ? 'rtl' : 'ltr'}
          >
            {/* Top Banner Accent */}
            <div className={`h-24 bg-gradient-to-r ${rankCfg.gradientClass} relative`}>
              <div className="absolute inset-0 bg-slate-950/40" />
              <button
                onClick={onClose}
                className="absolute top-4 end-4 p-2 rounded-xl bg-black/40 hover:bg-black/60 text-white/80 hover:text-white transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {/* Profile Header */}
            <div className="px-6 -mt-12 relative flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 pb-4 border-b border-slate-800">
              <div className="flex items-end gap-4">
                <div className="relative">
                  <img
                    src={member.avatarUrl}
                    alt={member.displayName}
                    className="w-20 h-20 rounded-2xl border-4 border-slate-900 bg-slate-950 object-cover shadow-xl"
                  />
                  <span className={`absolute bottom-1 end-1 w-4 h-4 rounded-full border-2 border-slate-900 ${statusCfg.dotClass}`} />
                </div>

                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="text-xl font-bold text-white font-display">
                      {member.displayName}
                    </h2>
                    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold border ${rankCfg.bgClass} ${rankCfg.textClass} ${rankCfg.borderClass}`}>
                      <Shield size={12} />
                      <span>{isAr ? rankCfg.labelAr : rankCfg.label}</span>
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-2.5 mt-1 text-xs text-slate-400 font-sans">
                    <span>@{member.username}</span>
                    <span>•</span>
                    <button
                      onClick={handleCopyId}
                      className="inline-flex items-center gap-1 font-mono text-[11px] bg-slate-800/80 hover:bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md border border-slate-700/60 transition-colors"
                      title={isAr ? 'نسخ معرف الديسكورد' : 'Copy Discord ID'}
                    >
                      <span>{member.discordId}</span>
                      {copiedId ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Status Badge & Link to full page */}
              <div className="flex items-center gap-2 shrink-0">
                <Link
                  to={`/staff-management/${member.id}`}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
                >
                  <ExternalLink size={13} />
                  <span>{isAr ? 'الملف الكامل' : 'Full Profile'}</span>
                </Link>
              </div>
            </div>

            {/* Quick Action Toolbar */}
            <div className="px-6 py-3 bg-slate-950/50 border-b border-slate-800 flex flex-wrap items-center gap-2">
              {canManagePoints && (
                <>
                  <button
                    onClick={() => { setPointsType('ADD'); setIsPointsOpen(true); }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 transition-colors"
                  >
                    <Plus size={14} />
                    <span>{isAr ? 'إضافة نقاط' : 'Grant Points'}</span>
                  </button>

                  <button
                    onClick={() => { setPointsType('REMOVE'); setIsPointsOpen(true); }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 border border-rose-500/30 transition-colors"
                  >
                    <Minus size={14} />
                    <span>{isAr ? 'خصم نقاط' : 'Deduct Points'}</span>
                  </button>
                </>
              )}

              {canEdit && (
                <button
                  onClick={() => setIsEditOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-400 border border-cyan-500/30 transition-colors"
                >
                  <Edit3 size={14} />
                  <span>{isAr ? 'تعديل البيانات' : 'Edit Info'}</span>
                </button>
              )}

              {canSuspend && (
                <button
                  onClick={handleToggleStatus}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-amber-500/15 hover:bg-amber-500/25 text-amber-400 border border-amber-500/30 transition-colors"
                >
                  {member.status === 'ACTIVE' ? (
                    <>
                      <UserX size={14} />
                      <span>{isAr ? 'إيقاف مؤقت' : 'Suspend'}</span>
                    </>
                  ) : (
                    <>
                      <UserCheck size={14} />
                      <span>{isAr ? 'إلغاء الإيقاف' : 'Reactivate'}</span>
                    </>
                  )}
                </button>
              )}

              {canRemove && (
                <button
                  onClick={handleRemove}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 transition-colors ms-auto"
                >
                  <Trash2 size={14} />
                  <span>{isAr ? 'استبعاد' : 'Remove'}</span>
                </button>
              )}
            </div>

            {/* Scrollable Content */}
            <div className="p-6 overflow-y-auto space-y-6 font-sans text-sm">
              {/* Stats Overview Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <Star size={14} className="text-amber-400" />
                    <span>{isAr ? 'رصيد النقاط' : 'Current Points'}</span>
                  </div>
                  <div className="text-xl font-bold text-white font-display mt-1">
                    {member.points.toLocaleString()}
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <Calendar size={14} className="text-cyan-400" />
                    <span>{isAr ? 'تاريخ الانضمام' : 'Enrolled'}</span>
                  </div>
                  <div className="text-xs font-medium text-slate-200 mt-1.5 truncate">
                    {formatRelativeTime(member.joinedAt, isAr)}
                  </div>
                </div>

                <div className="col-span-2 sm:col-span-1 p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <Clock size={14} className="text-purple-400" />
                    <span>{isAr ? 'آخر تحديث' : 'Last Updated'}</span>
                  </div>
                  <div className="text-xs font-medium text-slate-200 mt-1.5 truncate">
                    {formatRelativeTime(member.updatedAt, isAr)}
                  </div>
                </div>
              </div>

              {/* Notes */}
              {member.notes && (
                <div className="p-4 rounded-2xl bg-slate-950/40 border border-slate-800/80">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                    {isAr ? 'ملاحظات الإدارة' : 'Administrative Notes'}
                  </h4>
                  <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">
                    {member.notes}
                  </p>
                </div>
              )}

              {/* Recent Points Ledger */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <Award size={14} className="text-amber-400" />
                    <span>{isAr ? 'سجل النقاط الأخير' : 'Recent Point Ledger'}</span>
                  </h4>
                  <span className="text-[11px] text-slate-500 font-mono">
                    {details.pointTransactions.length} {isAr ? 'عملية' : 'transactions'}
                  </span>
                </div>

                {details.pointTransactions.length === 0 ? (
                  <div className="p-4 rounded-xl bg-slate-950/30 border border-slate-800/60 text-center text-xs text-slate-500">
                    {isAr ? 'لا توجد عمليات نقاط مسجلة بعد.' : 'No point transactions recorded yet.'}
                  </div>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto pe-1">
                    {details.pointTransactions.slice(0, 5).map((pt, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-xl bg-slate-950/50 border border-slate-800/60 flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2.5">
                          <span className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-[11px] ${
                            pt.type === 'ADD' 
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20' 
                              : 'bg-rose-500/15 text-rose-400 border border-rose-500/20'
                          }`}>
                            {pt.type === 'ADD' ? '+' : '-'}
                          </span>
                          <div>
                            <div className="font-medium text-slate-200">{pt.reason}</div>
                            <div className="text-[10px] text-slate-500">
                              {formatRelativeTime(pt.createdAt, isAr)} • by {pt.performedBy}
                            </div>
                          </div>
                        </div>
                        <div className={`font-mono font-bold ${pt.type === 'ADD' ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {pt.type === 'ADD' ? `+${pt.amount}` : `-${pt.amount}`}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Audit History Timeline */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <History size={14} className="text-cyan-400" />
                    <span>{isAr ? 'السجل الرقابي' : 'Audit Trail'}</span>
                  </h4>
                  <span className="text-[11px] text-slate-500 font-mono">
                    {details.history.length} {isAr ? 'حدث' : 'events'}
                  </span>
                </div>

                {details.history.length === 0 ? (
                  <div className="p-4 rounded-xl bg-slate-950/30 border border-slate-800/60 text-center text-xs text-slate-500">
                    {isAr ? 'لا توجد سجلات رقابية مسجلة.' : 'No audit history events logged.'}
                  </div>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto pe-1">
                    {details.history.slice(0, 5).map((evt, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-xl bg-slate-950/40 border border-slate-800/50 flex items-start justify-between gap-3 text-xs"
                      >
                        <div>
                          <span className="font-mono text-[10px] uppercase px-1.5 py-0.5 rounded bg-slate-800 text-cyan-400 border border-slate-700/60 me-2">
                            {evt.action}
                          </span>
                          <span className="text-slate-300">{evt.description}</span>
                          <div className="text-[10px] text-slate-500 mt-1">
                            {formatRelativeTime(evt.createdAt, isAr)} • {evt.performedBy}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      </AnimatePresence>

      {/* Submodals */}
      <PointsModal
        isOpen={isPointsOpen}
        member={member}
        initialType={pointsType}
        onClose={() => setIsPointsOpen(false)}
        onSuccess={() => {
          if (onUpdated) onUpdated();
        }}
      />

      <EditStaffModal
        isOpen={isEditOpen}
        member={member}
        onClose={() => setIsEditOpen(false)}
        onSuccess={() => {
          if (onUpdated) onUpdated();
        }}
      />
    </>
  );
}
