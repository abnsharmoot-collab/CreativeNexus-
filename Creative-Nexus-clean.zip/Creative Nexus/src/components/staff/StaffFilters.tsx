import React from 'react';
import { Search, X, LayoutGrid, List, ArrowUpDown, Filter, RotateCcw } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { StaffRank, StaffStatus, StaffSortOption, StaffViewMode } from '../../types/staff';

interface StaffFiltersProps {
  searchQuery: string;
  setSearchQuery: (val: string) => void;
  statusFilter: StaffStatus | 'All';
  setStatusFilter: (val: StaffStatus | 'All') => void;
  rankFilter: StaffRank | 'All';
  setRankFilter: (val: StaffRank | 'All') => void;
  sortBy: StaffSortOption;
  setSortBy: (val: StaffSortOption) => void;
  viewMode: StaffViewMode;
  setViewMode: (val: StaffViewMode) => void;
  totalCount: number;
  filteredCount: number;
}

export function StaffFilters({
  searchQuery,
  setSearchQuery,
  statusFilter,
  setStatusFilter,
  rankFilter,
  setRankFilter,
  sortBy,
  setSortBy,
  viewMode,
  setViewMode,
  totalCount,
  filteredCount
}: StaffFiltersProps) {
  const { t, language } = useLanguage();
  const isAr = language === 'ar';

  const hasActiveFilters = searchQuery !== '' || statusFilter !== 'All' || rankFilter !== 'All';

  const handleReset = () => {
    setSearchQuery('');
    setStatusFilter('All');
    setRankFilter('All');
    setSortBy('POINTS_DESC');
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-col lg:flex-row gap-3 items-stretch lg:items-center justify-between">
        {/* Search Bar */}
        <div className="relative flex-1 min-w-[240px]">
          <div className="absolute inset-y-0 start-0 ps-3.5 flex items-center pointer-events-none text-slate-400">
            <Search size={16} />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isAr ? 'البحث بالاسم، المعرف، اليوزر أو الملاحظات...' : 'Search by name, @username, or Discord ID...'}
            className="w-full bg-slate-900/70 border border-slate-800 rounded-xl py-2.5 ps-10 pe-10 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/30 transition-all font-sans"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 end-0 pe-3 flex items-center text-slate-400 hover:text-white transition-colors"
            >
              <X size={15} />
            </button>
          )}
        </div>

        {/* Filter Controls Row */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Status Select */}
          <div className="relative">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as StaffStatus | 'All')}
              className="bg-slate-900/80 border border-slate-800 hover:border-slate-700 rounded-xl py-2.5 px-3.5 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-cyan-500/50 appearance-none cursor-pointer pe-8 transition-colors"
            >
              <option value="All" className="bg-slate-900 text-slate-200">
                {isAr ? 'كل الحالات' : 'All Statuses'}
              </option>
              <option value="ACTIVE" className="bg-slate-900 text-emerald-400">
                {isAr ? 'نشط فقط' : 'Active Only'}
              </option>
              <option value="SUSPENDED" className="bg-slate-900 text-rose-400">
                {isAr ? 'موقوف فقط' : 'Suspended Only'}
              </option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 end-0 flex items-center pe-2.5 text-slate-500">
              <Filter size={13} />
            </div>
          </div>

          {/* Rank Select */}
          <div className="relative">
            <select
              value={rankFilter}
              onChange={(e) => setRankFilter(e.target.value as StaffRank | 'All')}
              className="bg-slate-900/80 border border-slate-800 hover:border-slate-700 rounded-xl py-2.5 px-3.5 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-cyan-500/50 appearance-none cursor-pointer pe-8 transition-colors"
            >
              <option value="All" className="bg-slate-900 text-slate-200">
                {isAr ? 'كل الرتب' : 'All Ranks'}
              </option>
              <option value="SUPER_ADMIN" className="bg-slate-900 text-amber-400">Super Admin</option>
              <option value="SENIOR_ADMINISTRATOR" className="bg-slate-900 text-purple-400">Senior Administrator</option>
              <option value="ADMINISTRATOR" className="bg-slate-900 text-indigo-400">Administrator</option>
              <option value="SENIOR_MODERATOR" className="bg-slate-900 text-cyan-400">Senior Moderator</option>
              <option value="MODERATOR" className="bg-slate-900 text-emerald-400">Moderator</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 end-0 flex items-center pe-2.5 text-slate-500">
              <Filter size={13} />
            </div>
          </div>

          {/* Sort By Select */}
          <div className="relative">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as StaffSortOption)}
              className="bg-slate-900/80 border border-slate-800 hover:border-slate-700 rounded-xl py-2.5 px-3.5 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-cyan-500/50 appearance-none cursor-pointer pe-8 transition-colors"
            >
              <option value="POINTS_DESC" className="bg-slate-900 text-slate-200">
                {isAr ? 'النقاط: من الأعلى' : 'Points: High to Low'}
              </option>
              <option value="POINTS_ASC" className="bg-slate-900 text-slate-200">
                {isAr ? 'النقاط: من الأقل' : 'Points: Low to High'}
              </option>
              <option value="NAME_ASC" className="bg-slate-900 text-slate-200">
                {isAr ? 'الاسم: أ - ي' : 'Name: A - Z'}
              </option>
              <option value="JOINED_DESC" className="bg-slate-900 text-slate-200">
                {isAr ? 'تاريخ الانضمام: الأحدث' : 'Joined: Newest'}
              </option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 end-0 flex items-center pe-2.5 text-slate-500">
              <ArrowUpDown size={13} />
            </div>
          </div>

          {/* View Mode Switcher */}
          <div className="flex items-center bg-slate-900/90 border border-slate-800 p-0.5 rounded-xl shrink-0">
            <button
              type="button"
              onClick={() => setViewMode('grid')}
              title={isAr ? 'عرض البطاقات' : 'Grid View'}
              className={`p-2 rounded-lg transition-colors ${
                viewMode === 'grid'
                  ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <LayoutGrid size={16} />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              title={isAr ? 'عرض الجدول' : 'Table View'}
              className={`p-2 rounded-lg transition-colors ${
                viewMode === 'table'
                  ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <List size={16} />
            </button>
          </div>

          {/* Reset Filters Button */}
          {hasActiveFilters && (
            <button
              type="button"
              onClick={handleReset}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 transition-colors"
            >
              <RotateCcw size={13} />
              <span>{isAr ? 'إعادة التعيين' : 'Reset'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Summary row */}
      <div className="flex items-center justify-between text-xs text-slate-400 font-sans px-1">
        <div>
          {isAr ? (
            <span>عرض {filteredCount} من أصل {totalCount} إداري</span>
          ) : (
            <span>Showing {filteredCount} of {totalCount} staff members</span>
          )}
        </div>
      </div>
    </div>
  );
}
