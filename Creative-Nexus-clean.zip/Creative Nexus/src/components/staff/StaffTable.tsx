import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';
import { 
  Shield, Star, MoreVertical, Copy, Check, Eye, Edit3, 
  Plus, Minus, UserX, UserCheck, Trash2, ExternalLink, ArrowUpDown 
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useStaff } from '../../context/StaffContext';
import { useAuth } from '../../context/AuthContext';
import { StaffMember } from '../../types/staff';
import { getRankBadgeConfig, getStatusBadgeConfig, formatRelativeTime } from '../../utils/staffHelpers';
import { PointsModal } from './PointsModal';
import { EditStaffModal } from './EditStaffModal';
import { StaffDetailModal } from './StaffDetailModal';

interface StaffTableProps {
  staff: StaffMember[];
  onStaffUpdated?: () => void;
}

export function StaffTable({ staff, onStaffUpdated }: StaffTableProps) {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { suspendStaff, reactivateStaff, removeStaff } = useStaff();
  const { hasPermission } = useAuth();

  const [activeMenuId, setActiveMenuId] = useState<string | number | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Modals state
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);
  const [isPointsModalOpen, setIsPointsModalOpen] = useState(false);
  const [pointsModalType, setPointsModalType] = useState<'ADD' | 'REMOVE'>('ADD');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  // Permissions
  const canEdit = hasPermission('EDIT_STAFF');
  const canSuspend = hasPermission('SUSPEND_STAFF');
  const canRemove = hasPermission('REMOVE_STAFF');
  const canManagePoints = hasPermission('MANAGE_POINTS') || hasPermission('ADD_POINTS');

  const handleCopyId = (discordId: string) => {
    navigator.clipboard.writeText(discordId);
    setCopiedId(discordId);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleStatusToggle = async (member: StaffMember) => {
    setActiveMenuId(null);
    try {
      if (member.status === 'ACTIVE') {
        await suspendStaff(member.id);
      } else {
        await reactivateStaff(member.id);
      }
      if (onStaffUpdated) onStaffUpdated();
    } catch (e: any) {
      alert(e?.message || 'Failed to update status');
    }
  };

  const handleRemove = async (member: StaffMember) => {
    setActiveMenuId(null);
    if (!confirm(isAr ? 'هل أنت متأكد من رغبتك في إزالة هذا الإداري من الطاقم؟' : 'Are you sure you want to remove this staff member?')) return;
    try {
      await removeStaff(member.id);
      if (onStaffUpdated) onStaffUpdated();
    } catch (e: any) {
      alert(e?.message || 'Failed to remove staff member');
    }
  };

  const openPoints = (member: StaffMember, type: 'ADD' | 'REMOVE') => {
    setSelectedStaff(member);
    setPointsModalType(type);
    setIsPointsModalOpen(true);
    setActiveMenuId(null);
  };

  const openEdit = (member: StaffMember) => {
    setSelectedStaff(member);
    setIsEditModalOpen(true);
    setActiveMenuId(null);
  };

  const openDetail = (member: StaffMember) => {
    setSelectedStaff(member);
    setIsDetailModalOpen(true);
    setActiveMenuId(null);
  };

  return (
    <>
      <div className="w-full overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/60 backdrop-blur-xl shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-start border-collapse">
            <thead>
              <tr className="border-b border-slate-800/80 bg-slate-950/70 text-slate-400 font-sans text-xs uppercase tracking-wider">
                <th className="py-3.5 px-4 text-start font-semibold">
                  <span>{isAr ? 'عضو الإدارة' : 'Staff Member'}</span>
                </th>
                <th className="py-3.5 px-4 text-start font-semibold">
                  {isAr ? 'الرتبة' : 'Rank'}
                </th>
                <th className="py-3.5 px-4 text-center font-semibold">
                  {isAr ? 'النقاط' : 'Points'}
                </th>
                <th className="py-3.5 px-4 text-center font-semibold">
                  {isAr ? 'الحالة' : 'Status'}
                </th>
                <th className="py-3.5 px-4 text-start font-semibold hidden lg:table-cell">
                  {isAr ? 'الانضمام' : 'Joined'}
                </th>
                <th className="py-3.5 px-4 text-end font-semibold">
                  {isAr ? 'الإجراءات' : 'Actions'}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-sm font-sans">
              {staff.map((member, index) => {
                const rankCfg = getRankBadgeConfig(member.rank);
                const statusCfg = getStatusBadgeConfig(member.status);
                const isMenuOpen = activeMenuId === member.id;

                return (
                  <motion.tr
                    key={member.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2, delay: index * 0.02 }}
                    className="hover:bg-slate-800/40 transition-colors group"
                  >
                    {/* Member Info */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <div 
                          className="relative cursor-pointer shrink-0" 
                          onClick={() => openDetail(member)}
                        >
                          <img
                            src={member.avatarUrl}
                            alt={member.displayName}
                            className="w-10 h-10 rounded-xl border border-slate-800 object-cover group-hover:border-slate-700 transition-colors"
                          />
                          <span
                            className={`absolute -bottom-0.5 -end-0.5 w-3 h-3 rounded-full border-2 border-slate-900 ${statusCfg.dotClass}`}
                          />
                        </div>

                        <div className="min-w-0">
                          <button
                            type="button"
                            onClick={() => openDetail(member)}
                            className="font-display font-semibold text-white hover:text-cyan-400 text-start block truncate transition-colors text-sm"
                          >
                            {member.displayName}
                          </button>
                          <div className="flex items-center gap-1.5 text-xs text-slate-400">
                            <span className="truncate">@{member.username}</span>
                            <span className="text-slate-600">•</span>
                            <button
                              type="button"
                              onClick={() => handleCopyId(member.discordId)}
                              className="font-mono text-[10px] text-slate-500 hover:text-slate-300 transition-colors inline-flex items-center gap-0.5"
                              title="Copy Snowflake"
                            >
                              <span>{member.discordId.slice(0, 6)}...</span>
                              {copiedId === member.discordId ? (
                                <Check size={9} className="text-emerald-400" />
                              ) : (
                                <Copy size={9} />
                              )}
                            </button>
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Rank */}
                    <td className="py-3.5 px-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${rankCfg.bgClass} ${rankCfg.textClass} ${rankCfg.borderClass} whitespace-nowrap`}>
                        <Shield size={12} />
                        <span>{isAr ? rankCfg.labelAr : rankCfg.label}</span>
                      </span>
                    </td>

                    {/* Points */}
                    <td className="py-3.5 px-4 text-center">
                      <div className="inline-flex items-center gap-1 font-display font-bold text-white text-sm bg-slate-950/50 px-2.5 py-1 rounded-lg border border-slate-800">
                        <Star size={13} className="text-amber-400" />
                        <span>{member.points.toLocaleString()}</span>
                      </div>
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-4 text-center">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border ${statusCfg.bgClass} ${statusCfg.textClass} ${statusCfg.borderClass} whitespace-nowrap`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${statusCfg.dotClass}`} />
                        <span>{isAr ? statusCfg.labelAr : statusCfg.label}</span>
                      </span>
                    </td>

                    {/* Joined */}
                    <td className="py-3.5 px-4 text-xs text-slate-400 hidden lg:table-cell whitespace-nowrap">
                      {formatRelativeTime(member.joinedAt, isAr)}
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-end">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* Quick Points Grant */}
                        {canManagePoints && (
                          <button
                            type="button"
                            onClick={() => openPoints(member, 'ADD')}
                            className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 transition-colors"
                            title={isAr ? 'إضافة نقاط' : 'Grant Points'}
                          >
                            <Plus size={14} />
                          </button>
                        )}

                        {/* Inspect detail */}
                        <button
                          type="button"
                          onClick={() => openDetail(member)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 transition-colors"
                          title={isAr ? 'معاينة سريعة' : 'Inspect'}
                        >
                          <Eye size={14} />
                        </button>

                        {/* Context Menu */}
                        <div className="relative">
                          <button
                            type="button"
                            onClick={() => setActiveMenuId(isMenuOpen ? null : member.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                          >
                            <MoreVertical size={16} />
                          </button>

                          <AnimatePresence>
                            {isMenuOpen && (
                              <motion.div
                                initial={{ opacity: 0, scale: 0.95, y: -5 }}
                                animate={{ opacity: 1, scale: 1, y: 0 }}
                                exit={{ opacity: 0, scale: 0.95, y: -5 }}
                                transition={{ duration: 0.15 }}
                                className="absolute end-0 top-8 z-30 w-48 rounded-xl bg-slate-950 border border-slate-800 shadow-2xl py-1.5 overflow-hidden text-xs font-sans text-start"
                              >
                                <Link
                                  to={`/staff-management/${member.id}`}
                                  className="w-full px-3.5 py-2 text-slate-300 hover:bg-slate-800/80 hover:text-white flex items-center gap-2 transition-colors text-start"
                                  onClick={() => setActiveMenuId(null)}
                                >
                                  <ExternalLink size={13} />
                                  <span>{isAr ? 'الملف الكامل' : 'Full Profile'}</span>
                                </Link>

                                {canManagePoints && (
                                  <>
                                    <div className="h-px bg-slate-800 my-1" />
                                    <button
                                      onClick={() => openPoints(member, 'ADD')}
                                      className="w-full px-3.5 py-2 text-emerald-400 hover:bg-emerald-500/10 flex items-center gap-2 transition-colors text-start"
                                    >
                                      <Plus size={13} />
                                      <span>{isAr ? 'إضافة نقاط' : 'Add Points'}</span>
                                    </button>
                                    <button
                                      onClick={() => openPoints(member, 'REMOVE')}
                                      className="w-full px-3.5 py-2 text-rose-400 hover:bg-rose-500/10 flex items-center gap-2 transition-colors text-start"
                                    >
                                      <Minus size={13} />
                                      <span>{isAr ? 'خصم نقاط' : 'Deduct Points'}</span>
                                    </button>
                                  </>
                                )}

                                {canEdit && (
                                  <>
                                    <div className="h-px bg-slate-800 my-1" />
                                    <button
                                      onClick={() => openEdit(member)}
                                      className="w-full px-3.5 py-2 text-cyan-400 hover:bg-cyan-500/10 flex items-center gap-2 transition-colors text-start"
                                    >
                                      <Edit3 size={13} />
                                      <span>{isAr ? 'تعديل البيانات' : 'Edit Staff'}</span>
                                    </button>
                                  </>
                                )}

                                {canSuspend && (
                                  <button
                                    onClick={() => handleStatusToggle(member)}
                                    className="w-full px-3.5 py-2 text-amber-400 hover:bg-amber-500/10 flex items-center gap-2 transition-colors text-start"
                                  >
                                    {member.status === 'ACTIVE' ? (
                                      <>
                                        <UserX size={13} />
                                        <span>{isAr ? 'إيقاف مؤقت' : 'Suspend'}</span>
                                      </>
                                    ) : (
                                      <>
                                        <UserCheck size={13} />
                                        <span>{isAr ? 'إلغاء الإيقاف' : 'Reactivate'}</span>
                                      </>
                                    )}
                                  </button>
                                )}

                                {canRemove && (
                                  <>
                                    <div className="h-px bg-slate-800 my-1" />
                                    <button
                                      onClick={() => handleRemove(member)}
                                      className="w-full px-3.5 py-2 text-red-400 hover:bg-red-500/10 flex items-center gap-2 transition-colors text-start"
                                    >
                                      <Trash2 size={13} />
                                      <span>{isAr ? 'استبعاد من الطاقم' : 'Remove Staff'}</span>
                                    </button>
                                  </>
                                )}
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Submodals */}
      <PointsModal
        isOpen={isPointsModalOpen}
        member={selectedStaff}
        initialType={pointsModalType}
        onClose={() => setIsPointsModalOpen(false)}
        onSuccess={onStaffUpdated}
      />

      <EditStaffModal
        isOpen={isEditModalOpen}
        member={selectedStaff}
        onClose={() => setIsEditModalOpen(false)}
        onSuccess={onStaffUpdated}
      />

      <StaffDetailModal
        isOpen={isDetailModalOpen}
        member={selectedStaff}
        onClose={() => setIsDetailModalOpen(false)}
        onUpdated={onStaffUpdated}
      />
    </>
  );
}
