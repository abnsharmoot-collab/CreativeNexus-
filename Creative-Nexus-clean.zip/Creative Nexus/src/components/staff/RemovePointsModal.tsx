import React from 'react';
import { StaffMember } from '../../types/staff';
import { PointsModal } from './PointsModal';

export function RemovePointsModal({ 
  member, 
  onClose, 
  onSuccess 
}: { 
  member: StaffMember; 
  onClose: () => void; 
  onSuccess: () => void;
}) {
  return (
    <PointsModal
      isOpen={true}
      member={member}
      initialType="REMOVE"
      onClose={onClose}
      onSuccess={onSuccess}
    />
  );
}
