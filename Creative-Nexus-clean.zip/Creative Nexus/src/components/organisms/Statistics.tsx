import React from 'react';
import { StatCard } from '../molecules/StatCard';
import { useLanguage } from '../../context/LanguageContext';
import { useDiscordServer } from '../../context/DiscordServerContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { motion } from 'motion/react';
import { Radio } from 'lucide-react';
import { HiddenIraqiFlag } from '../easterEggs/HiddenIraqiFlag';
import { AncientTorchBrazier } from '../atoms/AncientTorchBrazier';
import { CrowdCanvas } from '../atoms/CrowdCanvas';

export function Statistics() {
  const { t, language } = useLanguage();
  const { serverInfo, isLive } = useDiscordServer();
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';
  
  const isRtl = language === 'ar';

  return (
    <section className="relative pt-12 pb-32 md:pt-16 md:pb-40 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Background Ambience */}
      {isMesopotamian ? (
        <>
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#100b07]/60 to-[#080503] pointer-events-none" />
          <div className="absolute top-1/2 start-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[350px] bg-amber-600/10 blur-[150px] pointer-events-none" />
        </>
      ) : (
        <>
          {/* Deep luminous ambient gradient mesh */}
          <div className="absolute inset-0 bg-radial from-teal-950/40 via-transparent to-transparent pointer-events-none" />
          <div className="absolute top-1/2 start-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[450px] bg-gradient-to-r from-teal-500/25 via-[#5eead4]/20 to-cyan-500/25 blur-[160px] pointer-events-none rounded-full" />
          <div className="absolute -top-10 start-1/3 w-[500px] h-[300px] bg-gradient-to-b from-cyan-400/20 via-teal-600/15 to-transparent blur-[140px] pointer-events-none rounded-full" />
          <div className="absolute bottom-0 end-1/4 w-[450px] h-[260px] bg-gradient-to-t from-emerald-500/20 via-teal-500/15 to-transparent blur-[130px] pointer-events-none rounded-full" />
          <div className="absolute top-0 inset-x-0 h-40 bg-gradient-to-b from-[#031211] via-transparent to-transparent pointer-events-none" />
        </>
      )}

      {/* Animated CrowdCanvas reflecting live Discord server community members */}
      <CrowdCanvas
        memberCount={serverInfo?.totalMembers ?? 580}
        isMesopotamian={isMesopotamian}
      />

      {/* Burning Torch Braziers on Left and Right in Mesopotamian Sovereign Theme */}
      {isMesopotamian && (
        <>
          <AncientTorchBrazier side="left" className="hidden xl:flex absolute start-4 2xl:start-12 bottom-24 z-20" />
          <AncientTorchBrazier side="right" className="hidden xl:flex absolute end-4 2xl:end-12 bottom-24 z-20" />
        </>
      )}
      
      <div className="relative z-10 max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-14">
          {isMesopotamian ? (
            /* Ancient Mesopotamian Cuneiform Glyph Header Line */
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex items-center justify-center gap-3 sm:gap-4 text-amber-500/80 mb-3 select-none"
            >
              <div className="h-px w-12 sm:w-20 bg-gradient-to-r from-transparent to-amber-500/80" />
              <span className="font-serif tracking-[0.25em] text-sm sm:text-base font-bold text-amber-400">
                — 𒀭 𒆠 𒈗 𒂍 —
              </span>
              <div className="h-px w-12 sm:w-20 bg-gradient-to-l from-transparent to-amber-500/80" />
              <HiddenIraqiFlag flagId="flag-home-stats" title="Guild registry watermark" />
            </motion.div>
          ) : (
            <div className="flex flex-col items-center mb-2">
              <HiddenIraqiFlag flagId="flag-home-stats" title="Guild registry watermark" />
            </div>
          )}

          <h2
            className={`font-bold text-3xl sm:text-4xl lg:text-5xl tracking-tight mb-3 ${
              isMesopotamian ? 'font-meso-serif mesopotamian-chiseled-title' : 'text-[#f0fdfa]'
            }`}
          >
            {isRtl ? 'إحصائيات السيرفر المباشرة' : 'Live Server Statistics'}
          </h2>

          <p
            className={`text-sm sm:text-base font-normal max-w-xl mx-auto leading-relaxed ${
              isMesopotamian ? 'font-serif text-amber-200/70' : 'text-[#99b8b2]'
            }`}
          >
            {isRtl 
              ? 'الأرقام متزامنة لحظياً ومباشرة مع سيرفر ديسكورد الرسمي ومعرف السيرفر' 
              : 'All community numbers and metrics synchronized in real time with Discord servers'}
          </p>
        </div>

        {/* 4 Synchronized Metric Cards (2x2 Grid matching reference screenshot) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6 lg:gap-7 max-w-5xl mx-auto">
          {/* Card 1: Sanctuary Members */}
          <StatCard 
            label={isRtl ? 'أعضاء السيرفر' : 'SANCTUARY MEMBERS'}
            value={(serverInfo?.totalMembers ?? 580).toLocaleString()}
            subtitle="Creative Nexus | سرفر السين"
            delay={0}
            categoryLabel="CATEGORIES"
            badge="Citizens"
          />

          {/* Card 2: Active Online with Live Badge */}
          <StatCard 
            label={isRtl ? 'الأعضاء المتصلين الآن' : 'ACTIVE ONLINE'}
            value={(serverInfo?.onlineCount ?? 78).toLocaleString()}
            subtitle={isLive ? 'Live Discord Presence' : 'Gateway Presence'}
            isLive={true}
            delay={0.1}
          />

          {/* Card 3: Community Guardians */}
          <StatCard 
            label={isRtl ? 'حراس المجتمع' : 'COMMUNITY GUARDIANS'}
            value={(serverInfo.staffCount && serverInfo.staffCount > 0 && serverInfo.staffCount !== 24 ? serverInfo.staffCount : 11).toString()}
            subtitle={isRtl ? '11 حارس معتمد' : 'Verified Guardians'}
            delay={0.2}
            categoryLabel="SECURITY"
            badge="Security"
          />

          {/* Card 4: Active Hubs & Rooms */}
          <StatCard 
            label={isRtl ? 'قنوات ورومات السيرفر' : 'ACTIVE HUBS & ROOMS'}
            value={serverInfo.channelsCount.toString()}
            subtitle={isRtl ? 'القمة: CHAT' : 'Top: CHAT'}
            delay={0.3}
            categoryLabel="CHANNELS"
            badge="Channels"
          />
        </div>
      </div>
    </section>
  );
}

