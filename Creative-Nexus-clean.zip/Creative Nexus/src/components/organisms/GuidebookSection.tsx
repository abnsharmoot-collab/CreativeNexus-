import React from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight, ArrowLeft } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { MesopotamianCornerBrackets } from '../atoms/MesopotamianCornerBrackets';

export function GuidebookSection() {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  return (
    <section className="relative py-6 sm:py-8 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {!isMesopotamian && (
        <div className="w-px h-8 bg-gradient-to-b from-archive-cyan/25 via-archive-cyan/10 to-transparent mx-auto mb-6 pointer-events-none" aria-hidden="true" />
      )}

      {/* Shared ambient glow */}
      <div 
        className={`absolute top-1/2 start-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[220px] blur-[110px] pointer-events-none rounded-full ${
          isMesopotamian ? 'bg-amber-500/10' : 'bg-gradient-to-r from-cyan-500/10 via-teal-500/5 to-purple-500/5'
        }`} 
      />

      <div className="relative z-10 max-w-5xl mx-auto">
        <div
          className={`relative rounded-2xl p-6 sm:p-8 transition-all duration-150 overflow-hidden ${
            isMesopotamian
              ? 'mesopotamian-stone-bg border border-amber-600/50 shadow-[0_12px_40px_rgba(0,0,0,0.8)]'
              : 'bg-[#0b1c1a] border border-[rgba(45,212,191,0.16)] shadow-[0_4px_24px_rgba(0,0,0,0.4)]'
          }`}
        >
          {/* Ornate Stepped Corner Brackets in Mesopotamian Mode */}
          {isMesopotamian && <MesopotamianCornerBrackets />}

          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5 sm:gap-7">
            {/* Content Side */}
            <div className="space-y-2 flex-1 max-w-2xl">
              <span className="text-xs font-mono tracking-widest uppercase text-[#2dd4bf] font-medium block">
                {isAr ? 'دليل الإرشادات والقوانين' : 'GUIDEBOOK & CODEX'}
              </span>
              
              {/* Main Description */}
              <h2 
                className={`text-lg sm:text-xl lg:text-2xl font-bold tracking-tight leading-snug ${
                  isMesopotamian ? 'font-serif text-amber-100 drop-shadow-md' : 'text-[#f0fdfa]'
                }`}
              >
                {isAr
                  ? 'دليل شامل يساعدك على فهم مجتمع CREATIVE NEXUS وأهم أنظمته.'
                  : 'A quick guide to help you understand Creative Nexus and its core systems.'}
              </h2>

              {/* Sub-prompt */}
              <p 
                className={`text-sm sm:text-base ${
                  isMesopotamian ? 'font-serif text-amber-400 drop-shadow-sm' : 'text-[#99b8b2]'
                }`}
              >
                {isAr ? 'استكشف الرتب ونقاط الترقية واللوائح التنظيمية الرسمية.' : 'Explore ranks, promotion requirements, and official guidelines.'}
              </p>
            </div>

            {/* Action Button */}
            <div className="shrink-0 flex items-center">
              <Link
                to="/guidebook"
                id="btn-homepage-enter-guidebook"
                className={`w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all duration-150 group/btn ${
                  isMesopotamian
                    ? 'mesopotamian-btn-gold font-serif text-amber-950 shadow-md hover:brightness-105'
                    : 'btn-nexus-primary'
                }`}
              >
                <span>{isAr ? 'ادخل الدليل' : 'Enter Guidebook'}</span>
                {isAr ? (
                  <ArrowLeft size={16} className="group-hover/btn:-translate-x-0.5 transition-transform" />
                ) : (
                  <ArrowRight size={16} className="group-hover/btn:translate-x-0.5 transition-transform" />
                )}
              </Link>
            </div>
          </div>
        </div>
      </div>

      {!isMesopotamian && (
        <div className="w-px h-10 bg-gradient-to-b from-archive-cyan/20 via-archive-cyan/35 to-transparent mx-auto mt-10 pointer-events-none" aria-hidden="true" />
      )}
    </section>
  );
}

