import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Logo } from '../atoms/Logo';
import { 
  Menu, X, Globe, LogIn, LogOut, User as UserIcon, LayoutDashboard, 
  ChevronDown, Bot, Award, Trophy, BookOpen, Copy, Check, 
  Shield, Sparkles, ChevronRight, Home, History as HistoryIcon, Megaphone, Bell,
  Settings as SettingsIcon, Activity, Hash, Volume2, Palette, Radio, Crown,
  Compass, MessageSquare, ExternalLink, Layers, Swords, Coins, Infinity as InfinityIcon, Heart, Download
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { useStaff } from '../../context/StaffContext';
import { useDiscordServer } from '../../context/DiscordServerContext';
import { useAchievements } from '../../context/AchievementContext';
import { useNotifications } from '../../context/NotificationContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { useCards } from '../../context/CardContext';
import { NotificationBell } from '../notifications/NotificationBell';
import { getTierForPoints } from '../../types/rankMap';
import { UserProfileModal } from '../auth/UserProfileModal';

const NAV_LINKS = ['Home', 'Announcements', 'History', 'Codex', 'Dashboard', 'Staff', 'Events', 'Archive'];

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [copiedDrawerId, setCopiedDrawerId] = useState(false);
  
  const userMenuRef = useRef<HTMLDivElement>(null);
  const location = useLocation();
  const navigate = useNavigate();
  const { language, setLanguage, t } = useLanguage();
  const isAr = language === 'ar';
  const { user, isAuthenticated, role, logout, loginWithDiscord } = useAuth();
  const { staff } = useStaff();
  const { serverInfo } = useDiscordServer();
  const { stats, evaluateMemberAchievements } = useAchievements();
  const { unreadCount } = useNotifications();
  const { coins, isUnlimitedCoins } = useCards();
  const { 
    flagsCount, 
    totalFlags, 
    setIsSecretProgressOpen, 
    saddamGameGoalReached, 
    saddamBestTime, 
    iraqiThemeUnlocked, 
    isSecretArchiveRevealed,
    activeTheme 
  } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';
  const isSecretFinished = Boolean(saddamGameGoalReached || (saddamBestTime && saddamBestTime >= 120) || iraqiThemeUnlocked);
  const isOwnerUser = Boolean(
    role === 'OWNER' || 
    user?.isOwner || 
    user?.isGuildOwner || 
    user?.discordId === '871043296280076308'
  );

  // Find staff dossier if logged-in user is staff
  const staffMember = user 
    ? staff.find((s) => s.discordId === user.discordId || String(s.id) === user.discordId)
    : null;
  const currentTier = staffMember ? getTierForPoints(staffMember.points) : null;
  const memberAchievements = staffMember ? evaluateMemberAchievements(staffMember) : [];
  const unlockedCount = staffMember
    ? memberAchievements.filter((a) => a.isUnlocked).length
    : stats.unlockedCount;

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);
      const h = document.documentElement;
      const st = h.scrollTop || document.body.scrollTop;
      const sh = h.scrollHeight - h.clientHeight;
      const pct = sh > 0 ? Math.min(1, Math.max(0, st / sh)) : 0;
      setScrollProgress(pct);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Lock body scroll when drawer is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMobileMenuOpen]);

  // Close drawer on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsMobileMenuOpen(false);
        setIsUserMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Close user dropdown and secret menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const copyDrawerId = () => {
    if (!user) return;
    navigator.clipboard.writeText(user.discordId);
    setCopiedDrawerId(true);
    setTimeout(() => setCopiedDrawerId(false), 2000);
  };

  const getLinkTo = (link: string) => {
    if (link === 'Home') return '/';
    if (link === 'Announcements') return '/announcements';
    if (link === 'History') return '/history';
    if (link === 'Codex') return '/guidebook';
    if (link === 'Staff') return '/staff-management';
    if (link === 'Dashboard') return '/server-dashboard';
    return `/#${link.toLowerCase()}`;
  };

  return (
    <>
      <header 
        style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}
        className={`fixed top-0 start-0 w-full z-40 transition-all duration-300 flex items-center justify-center ${
          isMesopotamian
            ? isScrolled 
              ? 'mesopotamian-stone-bg border-b border-amber-500/40 h-13 sm:h-14 shadow-xl backdrop-blur-2xl' 
              : 'bg-[#0e0804]/96 border-b border-amber-500/35 h-14 sm:h-16 backdrop-blur-xl shadow-lg'
            : isScrolled 
              ? 'bg-[#020709]/96 backdrop-blur-2xl h-13 sm:h-14 shadow-[0_8px_30px_rgba(0,0,0,0.85)] border-b border-[#5eead4]/25' 
              : 'bg-gradient-to-b from-[#020709]/96 via-[#02090c]/94 to-[#01080a]/96 backdrop-blur-2xl h-14 sm:h-16 border-b border-[#5eead4]/20 shadow-[0_8px_25px_rgba(0,0,0,0.7)]'
        }`}
      >
        {/* Specular Top Rim Lighting Line */}
        <div 
          className={`absolute top-0 inset-x-0 h-[1.5px] pointer-events-none ${
            isMesopotamian
              ? 'bg-gradient-to-r from-transparent via-amber-400/60 via-yellow-200/80 to-transparent shadow-[0_0_12px_rgba(245,158,11,0.6)]'
              : 'bg-gradient-to-r from-transparent via-[#5eead4]/55 via-cyan-300/75 to-transparent shadow-[0_0_12px_rgba(94,234,212,0.6)]'
          }`}
          aria-hidden="true" 
        />

        {/* Delicate Archival Micro-Texture Pattern */}
        <div 
          className={`absolute inset-0 [background-size:24px_24px] pointer-events-none ${
            isMesopotamian
              ? 'bg-[radial-gradient(#f59e0b_1px,transparent_1px)] opacity-[0.04]'
              : 'bg-[radial-gradient(#5eead4_1px,transparent_1px)] opacity-[0.03]'
          }`}
          aria-hidden="true" 
        />

        {/* Ambient Corner Glow Accents - Left (Logo) & Right (Actions) */}
        {!isMesopotamian && (
          <>
            <div 
              className="absolute top-0 start-0 w-80 h-full bg-radial from-[#5eead4]/[0.08] to-transparent pointer-events-none -z-10" 
              aria-hidden="true" 
            />
            <div 
              className="absolute top-0 end-0 w-80 h-full bg-radial from-cyan-400/[0.06] to-transparent pointer-events-none -z-10" 
              aria-hidden="true" 
            />
          </>
        )}

        {/* Luminous Dynamic Ambient Top Aurora */}
        {!isMesopotamian && (
          <div className="absolute top-0 inset-x-0 h-14 pointer-events-none -z-10 overflow-hidden" aria-hidden="true">
            <div className="absolute top-0 start-1/2 -translate-x-1/2 w-full max-w-5xl h-12 bg-gradient-to-b from-[#5eead4]/[0.08] via-teal-500/[0.02] to-transparent blur-lg" />
          </div>
        )}

        {/* Luminous Scrolling Bar Accent along the bottom of the extended Navbar */}
        <div 
          className={`absolute bottom-0 inset-x-0 h-[2px] ${isMesopotamian ? 'bg-amber-500/20' : 'bg-[#5eead4]/15'} pointer-events-none overflow-hidden`} 
          aria-hidden="true" 
        >
          {/* Active Scroll Progress Indicator */}
          <div 
            id="navbar-scroll-progress-line"
            className={`h-full w-full ${isMesopotamian ? 'bg-gradient-to-r from-amber-500 via-yellow-400 via-amber-300 to-amber-600 shadow-[0_0_12px_rgba(245,158,11,0.95)]' : 'bg-gradient-to-r from-[#5eead4] via-teal-300 via-cyan-400 to-[#7c8cff] shadow-[0_0_12px_rgba(94,234,212,0.95)]'} transition-transform duration-75 ease-out origin-left rtl:origin-right`}
            style={{ transform: `scaleX(${scrollProgress})` }}
          />
        </div>

        {/* Faint static bottom hairline accent */}
        <div 
          className={`absolute bottom-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent ${isMesopotamian ? 'via-amber-400/40 via-yellow-400/30 shadow-[0_0_8px_rgba(245,158,11,0.4)]' : 'via-[#5eead4]/35 via-teal-400/25 shadow-[0_0_8px_rgba(94,234,212,0.3)]'} to-transparent pointer-events-none`} 
          aria-hidden="true" 
        />

        <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 md:px-8 h-full flex items-center justify-between box-border min-w-0 relative z-10">
          {/* Left Side: Brand Logo */}
          <div className="flex items-center min-w-0 shrink-0 my-auto">
            <Link 
              to="/" 
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} 
              className="shrink-0 min-w-0 transition-all duration-300 hover:scale-[1.02] active:scale-95 group relative flex items-center p-1 -m-1 rounded-xl hover:drop-shadow-[0_0_12px_rgba(94,234,212,0.4)]"
            >
              <Logo />
            </Link>
          </div>

          {/* Right Side: Compact, Balanced Buttons */}
          <div className="flex items-center justify-center gap-2 sm:gap-2.5 shrink-0 my-auto">
            {/* 1. Language Toggle Button */}
            <div className={`flex items-center h-7 sm:h-7.5 p-0.5 rounded-full shadow-inner transition-colors shrink-0 ${
              isMesopotamian
                ? 'bg-[#160f0a]/95 border border-amber-500/35'
                : 'bg-[#021316]/95 border border-[#5eead4]/30'
            }`}>
              <button 
                onClick={() => setLanguage('ar')}
                className={`h-5.5 sm:h-6 px-2 sm:px-2.5 rounded-full text-[10px] sm:text-[11px] font-bold tracking-tight flex items-center justify-center transition-all duration-200 cursor-pointer ${
                  language === 'ar'
                    ? isMesopotamian
                      ? 'bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 text-stone-950 font-extrabold shadow-[0_0_10px_rgba(245,158,11,0.5)] scale-[1.02]'
                      : 'bg-gradient-to-r from-[#5eead4] via-teal-300 to-[#2dd4bf] text-[#021e1a] font-extrabold shadow-[0_0_10px_rgba(94,234,212,0.6)] scale-[1.02]'
                    : isMesopotamian
                    ? 'text-amber-200/70 hover:text-amber-300 hover:bg-amber-500/10'
                    : 'text-teal-200/70 hover:text-[#5eead4] hover:bg-[#5eead4]/10'
                }`}
                title="العربية"
              >
                عربي
              </button>
              <button 
                onClick={() => setLanguage('en')}
                className={`h-5.5 sm:h-6 px-2 sm:px-2.5 rounded-full text-[10px] sm:text-[11px] font-bold tracking-tight flex items-center justify-center transition-all duration-200 cursor-pointer ${
                  language === 'en'
                    ? isMesopotamian
                      ? 'bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 text-stone-950 font-bold shadow-[0_0_10px_rgba(245,158,11,0.5)] scale-[1.02]'
                      : 'bg-gradient-to-r from-[#5eead4] via-teal-300 to-[#2dd4bf] text-[#021e1a] font-extrabold shadow-[0_0_10px_rgba(94,234,212,0.6)] scale-[1.02]'
                    : isMesopotamian
                    ? 'text-amber-200/70 hover:text-amber-300 hover:bg-amber-500/10'
                    : 'text-teal-200/70 hover:text-[#5eead4] hover:bg-[#5eead4]/10'
                }`}
                title="English"
              >
                EN
              </button>
            </div>

            {/* 2. Notification Center Bell */}
            <NotificationBell className="shrink-0" />

            {/* 3. Auth / User Dropdown / Login */}
            <div className="hidden md:flex items-center">
              {isAuthenticated && user ? (
                <div className="relative" ref={userMenuRef}>
                  <button
                    onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                    className={`flex items-center gap-1.5 sm:gap-2 h-7.5 sm:h-8 px-2.5 sm:px-3 pe-3 rounded-lg sm:rounded-xl transition-all duration-300 group cursor-pointer border active:scale-95 ${
                      isMesopotamian
                        ? 'bg-gradient-to-r from-[#1c120a] to-[#26180d] border-amber-600/50 hover:border-amber-400/80 shadow-[0_2px_8px_rgba(0,0,0,0.5),inset_0_1px_0_rgba(245,158,11,0.2)]'
                        : 'bg-gradient-to-r from-[#06242c]/95 via-[#0a323c]/90 to-[#06242c]/95 hover:from-[#093540] hover:via-[#0c404c] hover:to-[#093540] border-[#5eead4]/35 hover:border-[#5eead4]/75 shadow-[0_2px_8px_rgba(0,0,0,0.5),inset_0_1px_0_rgba(94,234,212,0.2)] hover:shadow-[0_0_14px_rgba(94,234,212,0.35)]'
                    }`}
                  >
                    <div className="relative">
                      <img
                        src={user.avatarUrl}
                        alt={user.displayName}
                        className={`w-5.5 h-5.5 sm:w-6 sm:h-6 rounded-full object-cover transition-all duration-300 shadow-xs ${
                          isMesopotamian
                            ? 'ring-2 ring-amber-500/50 group-hover:ring-amber-400'
                            : 'ring-2 ring-[#5eead4]/50 group-hover:ring-[#5eead4]'
                        }`}
                      />
                    </div>
                    <span className={`text-[11px] sm:text-xs font-semibold group-hover:text-white transition-colors max-w-[110px] truncate ${
                      isMesopotamian ? 'text-amber-100' : 'text-teal-100'
                    }`}>
                      {user.displayName}
                    </span>
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full border ${
                      role === 'OWNER'
                        ? 'bg-gradient-to-r from-amber-500/30 via-yellow-400/20 to-amber-600/30 text-amber-200 border-amber-400/40 shadow-[0_0_8px_rgba(245,158,11,0.3)]'
                        : role === 'MODERATOR'
                        ? isMesopotamian
                          ? 'bg-gradient-to-r from-amber-600/30 via-yellow-500/20 to-amber-700/30 text-amber-200 border-amber-500/40 shadow-[0_0_8px_rgba(245,158,11,0.25)]'
                          : 'bg-gradient-to-r from-indigo-500/30 via-blue-500/20 to-indigo-600/30 text-indigo-200 border-indigo-400/40 shadow-[0_0_8px_rgba(99,102,241,0.25)]'
                        : isMesopotamian
                        ? 'bg-gradient-to-r from-amber-500/20 to-yellow-500/20 text-amber-200 border-amber-500/30'
                        : 'bg-gradient-to-r from-emerald-500/30 via-teal-500/20 to-emerald-600/30 text-emerald-200 border-emerald-400/40 shadow-[0_0_8px_rgba(16,185,129,0.25)]'
                    }`}>
                      {role === 'OWNER' ? (isAr ? 'المالك' : 'Owner') : role === 'MODERATOR' ? (isAr ? 'مشرف' : 'Mod') : (isAr ? 'عضو' : 'Member')}
                    </span>
                    <ChevronDown
                      size={12}
                      className={`transition-transform duration-300 ${
                        isMesopotamian
                          ? (isUserMenuOpen ? 'rotate-180 text-amber-400' : 'text-amber-300/80 group-hover:text-white')
                          : (isUserMenuOpen ? 'rotate-180 text-[#5eead4]' : 'text-teal-300/80 group-hover:text-white')
                      }`}
                    />
                  </button>

                  {/* Modern Luxury Dropdown Menu with Colors & Gradients */}
                  <AnimatePresence>
                    {isUserMenuOpen && (
                      <motion.div
                        initial={{ opacity: 0, y: 8, scale: 0.96 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 6, scale: 0.96 }}
                        transition={{ duration: 0.18, ease: 'easeOut' }}
                        className="absolute end-0 mt-2.5 w-68 rounded-2xl bg-gradient-to-b from-[#071d22]/98 via-[#041215]/98 to-[#02090b]/98 backdrop-blur-2xl border border-[#5eead4]/25 p-2.5 shadow-[0_20px_50px_rgba(0,0,0,0.9)] z-50 overflow-hidden text-xs"
                      >
                        {/* Ambient top light */}
                        <div className="absolute top-0 inset-x-0 h-16 bg-gradient-to-b from-[#5eead4]/20 via-teal-500/[0.05] to-transparent pointer-events-none" />

                        {/* User Header */}
                        <button
                          onClick={() => {
                            setIsUserMenuOpen(false);
                            navigate(`/profile/${user.discordId}`);
                          }}
                          className="relative w-full text-start p-2.5 rounded-xl bg-gradient-to-br from-[#0b2b32]/80 via-[#071f24]/80 to-[#041216]/80 hover:from-[#0f3740] hover:to-[#07242a] border border-[#5eead4]/25 hover:border-[#5eead4]/60 mb-2 cursor-pointer transition-all duration-200 group shadow-inner"
                        >
                          <div className="flex items-center justify-between gap-1.5 mb-1">
                            <p className="text-xs font-bold text-white truncate group-hover:text-[#5eead4] transition-colors">
                              {user.displayName}
                            </p>
                            <span className="text-[10px] text-amber-300 font-mono font-bold bg-gradient-to-r from-amber-500/25 to-yellow-500/15 border border-amber-400/40 px-2 py-0.5 rounded-full shadow-[0_0_10px_rgba(245,158,11,0.25)] flex items-center gap-1">
                              <span>🪙</span>
                              {isUnlimitedCoins ? (
                                <span className="flex items-center gap-1 font-bold text-amber-200">
                                  <InfinityIcon size={13} className="text-amber-300 inline" />
                                  <span className="text-[9px] uppercase tracking-wider">{isAr ? 'لا نهائي' : 'UNLIMITED'}</span>
                                </span>
                              ) : (
                                <span>{coins.toLocaleString()}</span>
                              )}
                            </span>
                          </div>
                          <p className="text-[11px] text-teal-200/60 font-mono truncate">
                            @{user.username}
                          </p>
                        </button>

                        {/* Menu Options with Rich Gradients & Colors */}
                        <div className="space-y-1">
                          {[
                            {
                              to: `/profile/${user.discordId}`,
                              label: t('auth.profile'),
                              icon: UserIcon,
                              iconColor: 'text-[#5eead4] filter drop-shadow-[0_0_6px_rgba(94,234,212,0.7)]',
                              glow: 'hover:from-[#5eead4]/15 hover:via-teal-500/10',
                              id: 'navbar-profile-btn'
                            },
                            {
                              to: '/notifications',
                              label: t('nav.notifications'),
                              icon: Bell,
                              iconColor: 'text-sky-300 filter drop-shadow-[0_0_6px_rgba(56,189,248,0.7)]',
                              glow: 'hover:from-sky-500/15 hover:via-teal-500/10',
                              badge: unreadCount > 0 ? unreadCount : undefined,
                              id: 'btn-user-menu-notifications'
                            },
                            {
                              to: '/cards',
                              label: isAr ? 'خزانة ومتجر البطاقات' : 'Card Vault & Shop',
                              icon: Coins,
                              iconColor: 'text-amber-300 filter drop-shadow-[0_0_8px_rgba(245,158,11,0.8)]',
                              glow: 'hover:from-amber-500/15 hover:via-yellow-500/10',
                              id: 'btn-user-menu-card-vault'
                            },
                            {
                              to: '/decks',
                              label: isAr ? 'التشكيلات القتالية والحقيبة' : 'Battle Decks & Inventory',
                              icon: Layers,
                              iconColor: 'text-cyan-300 filter drop-shadow-[0_0_6px_rgba(34,211,238,0.7)]',
                              glow: 'hover:from-cyan-500/15 hover:via-blue-500/10',
                              id: 'btn-user-menu-decks'
                            },
                            {
                              to: '/story',
                              label: isAr ? 'طور القصة والمعارك' : 'Story Mode',
                              icon: Swords,
                              iconColor: 'text-rose-400 filter drop-shadow-[0_0_8px_rgba(244,63,94,0.8)]',
                              glow: 'hover:from-rose-500/15 hover:via-red-500/10',
                              id: 'btn-user-menu-story-mode'
                            },
                            {
                              to: '/characters',
                              label: isAr ? 'محراب المحبة والرفقاء' : 'Companions & Love',
                              icon: Heart,
                              iconColor: 'text-pink-400 filter drop-shadow-[0_0_8px_rgba(244,63,94,0.9)]',
                              glow: 'hover:from-rose-500/15 hover:via-pink-500/10',
                              id: 'btn-user-menu-characters'
                            },
                            {
                              to: '/server-dashboard',
                              label: t('nav.dashboard'),
                              icon: LayoutDashboard,
                              iconColor: 'text-emerald-300 filter drop-shadow-[0_0_6px_rgba(52,211,153,0.7)]',
                              glow: 'hover:from-emerald-500/15 hover:via-teal-500/10'
                            },
                            {
                              to: '/staff-management',
                              label: t('auth.dashboard'),
                              icon: Shield,
                              iconColor: 'text-blue-300 filter drop-shadow-[0_0_6px_rgba(96,165,250,0.7)]',
                              glow: 'hover:from-blue-500/15 hover:via-indigo-500/10'
                            },
                            {
                              to: '/rank-points',
                              label: language === 'ar' ? 'نقاط الرتب' : 'Rank Points',
                              icon: Award,
                              iconColor: 'text-indigo-300 filter drop-shadow-[0_0_6px_rgba(129,140,248,0.7)]',
                              glow: 'hover:from-indigo-500/15 hover:via-violet-500/10'
                            },
                            {
                              to: '/guidebook',
                              label: language === 'ar' ? 'الكتيبات الإرشادية' : 'Guidebooks',
                              icon: BookOpen,
                              iconColor: 'text-purple-300 filter drop-shadow-[0_0_6px_rgba(192,132,252,0.7)]',
                              glow: 'hover:from-purple-500/15 hover:via-pink-500/10'
                            },
                            {
                              to: '/achievements',
                              label: language === 'ar' ? 'الإنجازات' : 'Achievements',
                              icon: Trophy,
                              iconColor: 'text-yellow-300 filter drop-shadow-[0_0_8px_rgba(250,204,21,0.8)]',
                              glow: 'hover:from-yellow-500/15 hover:via-amber-500/10',
                              badge: stats.unseenCount > 0 ? `+${stats.unseenCount}` : undefined
                            },
                            {
                              to: '/settings',
                              label: isAr ? 'الإعدادات والمظهر' : 'Settings',
                              icon: SettingsIcon,
                              iconColor: 'text-teal-300 filter drop-shadow-[0_0_6px_rgba(94,234,212,0.6)]',
                              glow: 'hover:from-teal-500/15 hover:via-emerald-500/10'
                            },
                          ].map((item) => {
                            const Icon = item.icon;
                            return (
                              <button
                                key={item.to}
                                id={item.id}
                                onClick={() => {
                                  setIsUserMenuOpen(false);
                                  navigate(item.to);
                                }}
                                className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl hover:bg-gradient-to-r ${item.glow} hover:to-transparent transition-all duration-200 text-start cursor-pointer group`}
                              >
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <Icon size={15} className={`shrink-0 transition-transform duration-200 group-hover:scale-110 ${item.iconColor}`} />
                                  <span className="text-teal-100/80 group-hover:text-white font-medium truncate">{item.label}</span>
                                </div>
                                {item.badge && (
                                  <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-[#5eead4] text-[#031211] font-mono shadow-[0_0_8px_rgba(94,234,212,0.6)]">
                                    {item.badge}
                                  </span>
                                )}
                              </button>
                            );
                          })}

                          {/* Owner Tools */}
                          {(role === 'OWNER' || user?.isOwner || user?.isGuildOwner || user?.discordId === '871043296280076308') && (
                            <>
                              <div className="h-px bg-gradient-to-r from-transparent via-amber-500/40 to-transparent my-1.5" />
                              <button
                                id="btn-navbar-owner-card-management"
                                onClick={() => {
                                  setIsUserMenuOpen(false);
                                  navigate('/card-management');
                                }}
                                className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl hover:bg-gradient-to-r hover:from-amber-500/15 hover:to-transparent text-xs font-semibold text-amber-300 transition-all text-start cursor-pointer group"
                              >
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <Crown size={15} className="shrink-0 text-amber-400 group-hover:text-yellow-300 filter drop-shadow-[0_0_8px_rgba(245,158,11,0.8)] transition-transform duration-200 group-hover:scale-110" />
                                  <span className="truncate">{isAr ? 'استوديو البطاقات الملكي' : 'Card Studio'}</span>
                                </div>
                              </button>

                              <button
                                id="btn-navbar-owner-audit"
                                onClick={() => {
                                  setIsUserMenuOpen(false);
                                  navigate('/audit-log');
                                }}
                                className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl hover:bg-gradient-to-r hover:from-purple-500/15 hover:to-transparent text-xs font-semibold text-purple-300 transition-all text-start cursor-pointer group"
                              >
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <Activity size={15} className="shrink-0 text-purple-400 group-hover:text-fuchsia-300 filter drop-shadow-[0_0_8px_rgba(192,132,252,0.8)] transition-transform duration-200 group-hover:scale-110" />
                                  <span className="truncate">{isAr ? 'سجل تدقيق العمليات' : 'Audit Log'}</span>
                                </div>
                              </button>
                            </>
                          )}

                          <div className="h-px bg-gradient-to-r from-transparent via-[#5eead4]/25 to-transparent my-1.5" />

                          <a
                            href="/standalone.html"
                            download="index.html"
                            onClick={() => setIsUserMenuOpen(false)}
                            className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl hover:bg-gradient-to-r hover:from-teal-500/20 hover:to-transparent text-xs font-semibold text-[#5eead4] hover:text-white transition-all text-start cursor-pointer group"
                            title={isAr ? 'تحميل الموقع كملف HTML مستقل كامل يعمل بدون خادم' : 'Download website as standalone single-file index.html'}
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <Download size={15} className="shrink-0 text-[#5eead4] group-hover:scale-110 transition-transform filter drop-shadow-[0_0_8px_rgba(94,234,212,0.8)]" />
                              <span className="truncate">{isAr ? 'تحميل ملف HTML المستقل' : 'Export Standalone HTML'}</span>
                            </div>
                            <span className="px-1.5 py-0.5 rounded text-[8.5px] font-mono bg-teal-500/20 text-teal-300 border border-teal-500/30">
                              .HTML
                            </span>
                          </a>

                          <div className="h-px bg-gradient-to-r from-transparent via-[#5eead4]/25 to-transparent my-1.5" />

                          <button
                            onClick={() => {
                              setIsUserMenuOpen(false);
                              logout();
                            }}
                            className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-xl text-rose-300 hover:text-rose-200 hover:bg-rose-500/15 transition-all text-start cursor-pointer group"
                          >
                            <LogOut size={15} className="shrink-0 text-rose-400 transition-transform duration-200 group-hover:scale-110" />
                            <span className="font-medium">{t('auth.logout')}</span>
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <button
                  id="navbar-discord-login-btn"
                  onClick={() => {
                    loginWithDiscord();
                  }}
                  className="group relative flex items-center gap-2 h-7.5 sm:h-8 px-3 sm:px-3.5 rounded-lg sm:rounded-xl text-[11px] sm:text-xs font-bold text-white bg-gradient-to-r from-[#5865F2] via-[#6370f7] to-[#4e5bd9] hover:from-[#4752c4] hover:via-[#5865F2] hover:to-[#6370f7] shadow-[0_2px_12px_rgba(88,101,242,0.45),inset_0_1px_1px_rgba(255,255,255,0.35)] hover:shadow-[0_0_18px_rgba(88,101,242,0.7),inset_0_1px_1px_rgba(255,255,255,0.5)] border border-[#8592ff]/60 hover:border-white/50 transition-all duration-300 transform active:scale-95 cursor-pointer shrink-0"
                >
                  <svg className="w-3.5 h-3.5 fill-current shrink-0 transition-transform duration-200 group-hover:scale-110 drop-shadow-[0_1px_2px_rgba(0,0,0,0.5)]" viewBox="0 0 24 24">
                    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.893.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
                  </svg>
                  <span className="tracking-wide drop-shadow-[0_1px_2px_rgba(0,0,0,0.5)]">{t('auth.login')}</span>
                </button>
              )}
            </div>

            {/* 4. Menu Toggle (Upgraded for Kohan's Theme with Ancient Gold & Obsidian Stone) */}
            <button 
              id="nexus-three-lines-menu-btn"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label={isAr ? 'القائمة الرئيسية' : 'Main Menu'}
              title={isAr ? 'القائمة الرئيسية' : 'Menu'}
              className={`group relative flex flex-col justify-center items-center w-7.5 sm:w-8 h-7.5 sm:h-8 rounded-lg sm:rounded-xl backdrop-blur-md transition-all duration-300 cursor-pointer active:scale-95 shrink-0 ${
                isMesopotamian
                  ? 'bg-gradient-to-b from-[#1f140b]/95 to-[#120b06]/95 hover:from-[#2a1b0e] hover:to-[#170e08] border border-amber-500/40 hover:border-amber-400/90 shadow-[0_2px_8px_rgba(0,0,0,0.6),inset_0_1px_0_rgba(245,158,11,0.25)] hover:shadow-[0_0_16px_rgba(245,158,11,0.45)]'
                  : 'bg-gradient-to-b from-[#051c22]/95 to-[#021216]/95 hover:from-[#082a33] hover:to-[#041a1f] border border-[#5eead4]/35 hover:border-[#5eead4]/80 shadow-[0_2px_8px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(94,234,212,0.2)] hover:shadow-[0_0_16px_rgba(94,234,212,0.4)]'
              }`}
            >
              <div className="relative w-4 h-3.5 flex flex-col justify-between items-center pointer-events-none">
                <span className={`h-[2px] rounded-full transition-all duration-300 ease-out origin-center ${
                  isMobileMenuOpen 
                    ? isMesopotamian
                      ? 'w-4 rotate-45 translate-y-[6px] bg-gradient-to-r from-amber-400 to-yellow-300 shadow-[0_0_8px_rgba(245,158,11,0.9)]'
                      : 'w-4 rotate-45 translate-y-[6px] bg-gradient-to-r from-[#5eead4] to-teal-300 shadow-[0_0_8px_rgba(94,234,212,0.9)]' 
                    : isMesopotamian
                    ? 'w-4 bg-gradient-to-r from-amber-400 to-yellow-300 shadow-[0_0_6px_rgba(245,158,11,0.7)]'
                    : 'w-4 bg-gradient-to-r from-[#5eead4] to-teal-300 shadow-[0_0_6px_rgba(94,234,212,0.6)]'
                }`} />
                <span className={`h-[2px] rounded-full transition-all duration-200 ease-out ${
                  isMobileMenuOpen 
                    ? 'w-0 opacity-0' 
                    : isMesopotamian
                    ? 'w-3 group-hover:w-4 bg-gradient-to-r from-amber-400 to-yellow-300 self-start rtl:self-end shadow-[0_0_6px_rgba(245,158,11,0.7)]'
                    : 'w-3 group-hover:w-4 bg-gradient-to-r from-[#5eead4] to-teal-300 self-start rtl:self-end shadow-[0_0_6px_rgba(94,234,212,0.5)]'
                }`} />
                <span className={`h-[2px] rounded-full transition-all duration-300 ease-out origin-center ${
                  isMobileMenuOpen 
                    ? isMesopotamian
                      ? 'w-4 -rotate-45 -translate-y-[6px] bg-gradient-to-r from-amber-400 to-yellow-300 shadow-[0_0_8px_rgba(245,158,11,0.9)]'
                      : 'w-4 -rotate-45 -translate-y-[6px] bg-gradient-to-r from-[#5eead4] to-teal-300 shadow-[0_0_8px_rgba(94,234,212,0.9)]' 
                    : isMesopotamian
                    ? 'w-4 bg-gradient-to-r from-amber-400 to-yellow-300 shadow-[0_0_6px_rgba(245,158,11,0.7)]'
                    : 'w-4 bg-gradient-to-r from-[#5eead4] to-teal-300 shadow-[0_0_6px_rgba(94,234,212,0.6)]'
                }`} />
              </div>
            </button>
          </div>
        </div>
      </header>

      {/* Upgraded Premium Creative Menu Drawer with Unboxed Floating Design & Rich Gradients */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <div className="fixed inset-0 z-50 overflow-hidden">
            {/* Ambient Backdrop Scrim */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/80 backdrop-blur-md cursor-pointer"
            />

            {/* Sleek Creative Luxury Slide-Over Menu with Website Colors, Semi-Transparent Glassmorphism & Less Round Structure */}
            <motion.aside
              initial={{ x: isAr ? '-100%' : '100%', opacity: 0.95 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: isAr ? '-100%' : '100%', opacity: 0.95 }}
              transition={{ type: 'spring', damping: 32, stiffness: 280 }}
              className={`fixed top-0 end-0 bottom-0 z-50 h-[100dvh] w-[84vw] max-w-[310px] backdrop-blur-2xl flex flex-col overflow-hidden rounded-s-xl ${
                isMesopotamian
                  ? 'bg-gradient-to-b from-[#160e08]/96 via-[#100a06]/98 to-[#0a0604] border-s border-amber-500/35 shadow-[-25px_0_60px_rgba(0,0,0,0.95)] text-amber-100 font-serif'
                  : 'bg-gradient-to-b from-[#03171b]/82 via-[#021013]/85 to-[#010a0c]/88 border-s border-[#5eead4]/30 shadow-[-25px_0_60px_rgba(0,0,0,0.9)] text-[#eafffa]'
              }`}
            >
              {/* Multi-Stop Ambient Light Orbs - Theme Matched */}
              {isMesopotamian ? (
                <>
                  <div className="absolute top-0 inset-x-0 h-40 bg-gradient-to-b from-amber-500/15 via-yellow-500/[0.04] to-transparent pointer-events-none" />
                  <div className="absolute top-1/2 -end-16 w-36 h-36 rounded-full bg-amber-500/12 blur-3xl pointer-events-none" />
                  <div className="absolute bottom-10 -start-16 w-36 h-36 rounded-full bg-yellow-600/10 blur-3xl pointer-events-none" />
                </>
              ) : (
                <>
                  <div className="absolute top-0 inset-x-0 h-40 bg-gradient-to-b from-[#5eead4]/15 via-teal-500/[0.04] to-transparent pointer-events-none" />
                  <div className="absolute top-1/2 -end-16 w-36 h-36 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />
                  <div className="absolute bottom-10 -start-16 w-36 h-36 rounded-full bg-teal-500/10 blur-3xl pointer-events-none" />
                </>
              )}

              {/* Minimalist Creative Menu Header with Website Colors */}
              <div className={`relative z-10 shrink-0 pt-4 pb-3 px-4 border-b backdrop-blur-md flex items-center justify-between ${
                isMesopotamian
                  ? 'border-amber-500/25 bg-gradient-to-r from-[#1c120a]/85 to-[#130b06]/85'
                  : 'border-[#5eead4]/20 bg-gradient-to-r from-[#06242c]/75 to-[#03171a]/75'
              }`}>
                <Link to="/" onClick={() => setIsMobileMenuOpen(false)} className="shrink-0 flex items-center gap-2 group transition-transform hover:scale-[1.02]">
                  <Logo />
                </Link>

                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  aria-label="Close Menu"
                  className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all cursor-pointer active:scale-95 shadow-xs ${
                    isMesopotamian
                      ? 'text-amber-300 hover:text-white hover:bg-amber-500/20'
                      : 'text-teal-300 hover:text-white hover:bg-[#5eead4]/20'
                  }`}
                >
                  <X size={17} />
                </button>
              </div>

              {/* Scrollable Navigation Body */}
              <div className="relative z-10 flex-1 overflow-y-auto overscroll-contain px-3 py-3 space-y-4 custom-scrollbar text-xs">

                {/* Minimalist Floating User Profile with Website Colors */}
                {isAuthenticated && user ? (
                  <div className={`relative px-3 py-2.5 rounded-xl transition-all flex items-center justify-between gap-3 group ${
                    isMesopotamian
                      ? 'bg-gradient-to-r from-[#22160d]/80 via-[#170e08]/60 to-transparent hover:from-[#2e1d11]/90 border border-amber-500/25'
                      : 'bg-gradient-to-r from-[#06262e]/65 via-[#041d23]/50 to-transparent hover:from-[#093540]/80 border border-[#5eead4]/15'
                  }`}>
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="relative shrink-0">
                        <img
                          src={user.avatarUrl}
                          alt={user.displayName}
                          className={`w-9 h-9 rounded-full object-cover transition-all ${
                            isMesopotamian
                              ? 'ring-2 ring-amber-500/50 group-hover:ring-amber-400 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                              : 'ring-2 ring-[#5eead4]/40 group-hover:ring-[#5eead4] shadow-[0_0_12px_rgba(94,234,212,0.3)]'
                          }`}
                        />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 mb-0.5">
                          <p className="text-xs font-bold text-white truncate max-w-[110px]">
                            {user.displayName}
                          </p>
                          <span className={`text-[8px] font-semibold px-2 py-0.5 rounded-full shrink-0 shadow-xs ${
                            role === 'OWNER' 
                              ? 'bg-gradient-to-r from-amber-500/30 to-yellow-500/20 text-amber-200 border border-amber-400/40' 
                              : role === 'MODERATOR' 
                              ? 'bg-gradient-to-r from-indigo-500/30 to-blue-500/20 text-indigo-200 border border-indigo-400/40' 
                              : 'bg-gradient-to-r from-teal-500/30 to-emerald-500/20 text-teal-200 border border-teal-400/40'
                          }`}>
                            {role === 'OWNER' ? (isAr ? 'المالك' : 'Owner') : role === 'MODERATOR' ? (isAr ? 'مشرف' : 'Mod') : (isAr ? 'عضو' : 'Member')}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 text-[10px] text-amber-300 font-mono">
                          <span className="flex items-center gap-1 font-semibold">
                            <span>🪙</span>
                            {isUnlimitedCoins ? (
                              <span className="flex items-center gap-1 font-bold text-amber-200">
                                <InfinityIcon size={12} className="text-amber-300 inline" />
                                <span className="text-[9px] uppercase tracking-wider">{isAr ? 'لا نهائي' : 'UNLIMITED'}</span>
                              </span>
                            ) : (
                              <span>{coins.toLocaleString()}</span>
                            )}
                          </span>
                          <span className={isMesopotamian ? 'text-amber-600' : 'text-teal-700'}>·</span>
                          <span className={`${isMesopotamian ? 'text-amber-200/70' : 'text-teal-300/60'} truncate`}>@{user.username}</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setIsMobileMenuOpen(false);
                        navigate(`/profile/${user.discordId}`);
                      }}
                      title={isAr ? 'عرض الملف الشخصي' : 'View Profile'}
                      className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all cursor-pointer shrink-0 active:scale-95 ${
                        isMesopotamian
                          ? 'text-amber-300 hover:text-white hover:bg-amber-500/20'
                          : 'text-teal-300 hover:text-[#5eead4] hover:bg-[#5eead4]/15'
                      }`}
                    >
                      <UserIcon size={15} />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      loginWithDiscord();
                    }}
                    className="w-full py-2.5 px-3.5 rounded-xl bg-gradient-to-r from-[#5865F2] via-[#6370f7] to-[#7983f5] hover:from-[#4b58e3] hover:to-[#5865F2] text-white flex items-center justify-between text-xs font-semibold shadow-[0_4px_20px_rgba(88,101,242,0.45)] hover:shadow-[0_4px_28px_rgba(88,101,242,0.65)] transition-all cursor-pointer active:scale-95"
                  >
                    <div className="flex items-center gap-2">
                      <svg className="w-4 h-4 fill-current text-white shrink-0" viewBox="0 0 24 24">
                        <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.893.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
                      </svg>
                      <span>{isAr ? 'الانضمام عبر ديسكورد' : 'Connect Discord'}</span>
                    </div>
                    <ChevronRight size={14} className="text-white/80 rtl:rotate-180" />
                  </button>
                )}

                {/* Section: Explore / الرئيسية والمحتوى */}
                <div className="space-y-1">
                  <div className={`px-2.5 pt-1.5 pb-1 text-[10px] tracking-wider uppercase flex items-center gap-2 ${
                    isMesopotamian ? 'font-serif text-amber-400 font-bold' : 'font-mono text-teal-300/80'
                  }`}>
                    <span className="tracking-wide">{isAr ? 'الرئيسية والمحتوى' : 'Explore'}</span>
                    <span className={`h-px flex-1 ${
                      isMesopotamian ? 'bg-gradient-to-r from-amber-500/40 to-transparent' : 'bg-gradient-to-r from-teal-500/35 to-transparent'
                    }`} />
                  </div>

                  {[
                    { 
                      to: '/', 
                      labelAr: 'الرئيسية', 
                      labelEn: 'Home', 
                      icon: Home, 
                      exact: true,
                      iconColor: isMesopotamian ? 'text-amber-400 group-hover:text-yellow-300' : 'text-emerald-400 group-hover:text-emerald-300 filter drop-shadow-[0_0_8px_rgba(52,211,153,0.7)]',
                      glow: isMesopotamian ? 'from-amber-500/20 via-yellow-500/10' : 'from-emerald-500/20 via-teal-500/10'
                    },
                    { 
                      to: '/history', 
                      labelAr: 'تاريخ الملاذ والرؤساء', 
                      labelEn: 'Server History', 
                      icon: HistoryIcon,
                      iconColor: isMesopotamian ? 'text-amber-400 group-hover:text-yellow-300' : 'text-amber-400 group-hover:text-amber-300 filter drop-shadow-[0_0_8px_rgba(251,191,36,0.7)]',
                      glow: 'from-amber-500/20 via-yellow-500/10'
                    },
                    { 
                      to: '/announcements', 
                      labelAr: 'الإعلانات الرسمية', 
                      labelEn: 'Announcements', 
                      icon: Megaphone,
                      iconColor: isMesopotamian ? 'text-amber-400 group-hover:text-yellow-300' : 'text-sky-400 group-hover:text-sky-300 filter drop-shadow-[0_0_8px_rgba(56,189,248,0.7)]',
                      glow: isMesopotamian ? 'from-amber-500/20 via-yellow-500/10' : 'from-sky-500/20 via-blue-500/10'
                    },
                    { 
                      to: '/guidebook', 
                      labelAr: 'الكتيبات الإرشادية', 
                      labelEn: 'Guidebooks (Codex)', 
                      icon: BookOpen,
                      iconColor: isMesopotamian ? 'text-amber-400 group-hover:text-yellow-300' : 'text-purple-400 group-hover:text-purple-300 filter drop-shadow-[0_0_8px_rgba(192,132,252,0.7)]',
                      glow: isMesopotamian ? 'from-amber-500/20 via-yellow-500/10' : 'from-purple-500/20 via-fuchsia-500/10'
                    },
                  ].map((item) => {
                    const isActive = item.exact ? location.pathname === item.to : location.pathname.startsWith(item.to);
                    const Icon = item.icon;
                    return (
                      <Link
                        key={item.to}
                        to={item.to}
                        onClick={() => setIsMobileMenuOpen(false)}
                        className={`relative w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs transition-all duration-300 cursor-pointer group ${
                          isActive
                            ? isMesopotamian
                              ? 'bg-gradient-to-r from-amber-500/25 via-amber-600/15 to-transparent text-amber-200 font-bold border-s-2 border-amber-400 shadow-[0_0_18px_rgba(245,158,11,0.2)]'
                              : 'bg-gradient-to-r from-[#5eead4]/20 via-teal-500/15 to-transparent text-white font-semibold shadow-[0_0_20px_rgba(94,234,212,0.12)]'
                            : isMesopotamian
                            ? 'text-amber-100/85 hover:text-white hover:bg-gradient-to-r hover:from-amber-500/20 hover:to-transparent'
                            : `text-teal-100/75 hover:text-white hover:bg-gradient-to-r ${item.glow} hover:to-transparent`
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <Icon size={17} className={`shrink-0 transition-transform duration-300 group-hover:scale-115 ${item.iconColor}`} />
                          <span className="truncate group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform">
                            {isAr ? item.labelAr : item.labelEn}
                          </span>
                        </div>
                      </Link>
                    );
                  })}
                </div>

                {/* Section: Vault, Cards & Combat / الخزانة والأنشطة */}
                <div className="space-y-1 pt-1.5">
                  <div className={`px-2.5 pt-1.5 pb-1 text-[10px] tracking-wider uppercase flex items-center gap-2 ${
                    isMesopotamian ? 'font-serif text-amber-400 font-bold' : 'font-mono text-amber-300/85'
                  }`}>
                    <span className="tracking-wide">{isAr ? 'الخزانة والأنشطة' : 'Vault & Games'}</span>
                    <span className="h-px flex-1 bg-gradient-to-r from-amber-500/35 to-transparent" />
                  </div>

                  {[
                    { 
                      to: '/cards', 
                      labelAr: 'خزانة ومتجر البطاقات', 
                      labelEn: 'Card Vault & Shop', 
                      icon: Coins,
                      iconColor: 'text-amber-400 group-hover:text-amber-300 filter drop-shadow-[0_0_8px_rgba(245,158,11,0.8)]',
                      glow: 'from-amber-500/20 via-yellow-500/10'
                    },
                    { 
                      to: '/decks', 
                      labelAr: 'التشكيلات القتالية والحقيبة', 
                      labelEn: 'Battle Decks & Inventory', 
                      icon: Layers,
                      iconColor: isMesopotamian ? 'text-amber-400 group-hover:text-yellow-300' : 'text-cyan-400 group-hover:text-cyan-300 filter drop-shadow-[0_0_8px_rgba(34,211,238,0.7)]',
                      glow: isMesopotamian ? 'from-amber-500/20 via-yellow-500/10' : 'from-cyan-500/20 via-blue-500/10'
                    },
                    { 
                      to: '/story', 
                      labelAr: 'طور القصة والمعارك', 
                      labelEn: 'Story Mode', 
                      icon: Swords,
                      iconColor: isMesopotamian ? 'text-amber-400 group-hover:text-yellow-300' : 'text-rose-400 group-hover:text-rose-300 filter drop-shadow-[0_0_8px_rgba(244,63,94,0.8)]',
                      glow: isMesopotamian ? 'from-amber-500/20 via-yellow-500/10' : 'from-rose-500/20 via-red-500/10'
                    },
                    { 
                      to: '/characters', 
                      labelAr: 'محراب المحبة والرفقاء', 
                      labelEn: 'Companions & Love', 
                      icon: Heart,
                      iconColor: isMesopotamian ? 'text-amber-400 group-hover:text-yellow-300' : 'text-pink-400 group-hover:text-pink-300 filter drop-shadow-[0_0_8px_rgba(244,63,94,0.8)]',
                      glow: isMesopotamian ? 'from-amber-500/20 via-yellow-500/10' : 'from-rose-500/20 via-pink-500/10'
                    },
                    { 
                      to: '/rank-points', 
                      labelAr: 'مسار الرتب والترقيات', 
                      labelEn: 'Rank Roadmap', 
                      icon: Award,
                      iconColor: isMesopotamian ? 'text-amber-400 group-hover:text-yellow-300' : 'text-indigo-400 group-hover:text-indigo-300 filter drop-shadow-[0_0_8px_rgba(129,140,248,0.7)]',
                      glow: isMesopotamian ? 'from-amber-500/20 via-yellow-500/10' : 'from-indigo-500/20 via-violet-500/10'
                    },
                    { 
                      to: '/achievements', 
                      labelAr: 'سجل الإنجازات', 
                      labelEn: 'Achievements', 
                      icon: Trophy, 
                      badge: stats.unseenCount > 0 ? `+${stats.unseenCount}` : undefined,
                      iconColor: 'text-yellow-400 group-hover:text-yellow-300 filter drop-shadow-[0_0_8px_rgba(250,204,21,0.8)]',
                      glow: 'from-yellow-500/20 via-amber-500/10'
                    },
                    { 
                      to: '/server-dashboard', 
                      labelAr: 'لوحة نبض السيرفر', 
                      labelEn: 'Server Dashboard', 
                      icon: LayoutDashboard,
                      iconColor: isMesopotamian ? 'text-amber-400 group-hover:text-yellow-300' : 'text-teal-400 group-hover:text-teal-300 filter drop-shadow-[0_0_8px_rgba(45,212,191,0.7)]',
                      glow: isMesopotamian ? 'from-amber-500/20 via-yellow-500/10' : 'from-teal-500/20 via-emerald-500/10'
                    },
                  ].map((item) => {
                    const isActive = location.pathname.startsWith(item.to) && !(item.to === '/cards' && location.pathname.includes('/management'));
                    const Icon = item.icon;
                    return (
                      <Link
                        key={item.to}
                        to={item.to}
                        onClick={() => setIsMobileMenuOpen(false)}
                        className={`relative w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs transition-all duration-300 cursor-pointer group ${
                          isActive
                            ? isMesopotamian
                              ? 'bg-gradient-to-r from-amber-500/25 via-amber-600/15 to-transparent text-amber-200 font-bold border-s-2 border-amber-400 shadow-[0_0_18px_rgba(245,158,11,0.2)]'
                              : 'bg-gradient-to-r from-[#5eead4]/20 via-teal-500/15 to-transparent text-[#eafffa] font-semibold shadow-[0_0_20px_rgba(94,234,212,0.12)]'
                            : isMesopotamian
                            ? 'text-amber-100/85 hover:text-white hover:bg-gradient-to-r hover:from-amber-500/20 hover:to-transparent'
                            : `text-teal-100/75 hover:text-white hover:bg-gradient-to-r ${item.glow} hover:to-transparent`
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <Icon size={17} className={`shrink-0 transition-transform duration-300 group-hover:scale-115 ${item.iconColor}`} />
                          <span className="truncate group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform">
                            {isAr ? item.labelAr : item.labelEn}
                          </span>
                        </div>

                        {item.badge ? (
                          <span className="text-[9px] font-bold text-amber-200 bg-amber-500/20 border border-amber-400/40 px-2 py-0.5 rounded-full font-mono shadow-[0_0_8px_rgba(245,158,11,0.3)]">
                            {item.badge}
                          </span>
                        ) : null}
                      </Link>
                    );
                  })}
                </div>

                {/* Section: Administration & Governance / الإدارة والتحكم */}
                <div className="space-y-1 pt-1.5">
                  <div className={`px-2.5 pt-1.5 pb-1 text-[10px] tracking-wider uppercase flex items-center gap-2 ${
                    isMesopotamian ? 'font-serif text-amber-400 font-bold' : 'font-mono text-purple-300/85'
                  }`}>
                    <span className="tracking-wide">{isAr ? 'الإدارة والتحكم' : 'Management'}</span>
                    <span className={`h-px flex-1 ${
                      isMesopotamian ? 'bg-gradient-to-r from-amber-500/40 to-transparent' : 'bg-gradient-to-r from-purple-500/35 to-transparent'
                    }`} />
                  </div>

                  <Link
                    to="/staff-management"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`relative w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs transition-all duration-300 cursor-pointer group ${
                      location.pathname.startsWith('/staff-management')
                        ? isMesopotamian
                          ? 'bg-gradient-to-r from-amber-500/25 via-amber-600/15 to-transparent text-amber-200 font-bold border-s-2 border-amber-400 shadow-[0_0_18px_rgba(245,158,11,0.2)]'
                          : 'bg-gradient-to-r from-blue-500/20 via-indigo-500/15 to-transparent text-blue-200 font-semibold shadow-[0_0_20px_rgba(96,165,250,0.12)]'
                        : isMesopotamian
                        ? 'text-amber-100/85 hover:text-white hover:bg-gradient-to-r hover:from-amber-500/20 hover:to-transparent'
                        : 'text-teal-100/75 hover:text-white hover:bg-gradient-to-r hover:from-blue-500/20 hover:via-indigo-500/10 hover:to-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <Shield size={17} className={`shrink-0 transition-transform duration-300 group-hover:scale-115 ${
                        isMesopotamian ? 'text-amber-400 group-hover:text-yellow-300' : 'text-blue-400 group-hover:text-blue-300 filter drop-shadow-[0_0_8px_rgba(96,165,250,0.7)]'
                      }`} />
                      <span className="truncate group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform">{isAr ? 'طاقم الإدارة والحراس' : 'Staff Directory'}</span>
                    </div>
                  </Link>

                  {/* Owner Tools */}
                  {(role === 'OWNER' || user?.isOwner || user?.isGuildOwner || user?.discordId === '871043296280076308') && (
                    <>
                      <Link
                        to="/card-management"
                        onClick={() => setIsMobileMenuOpen(false)}
                        className={`relative w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs transition-all duration-300 cursor-pointer group ${
                          location.pathname.startsWith('/card-management')
                            ? 'bg-gradient-to-r from-amber-500/25 via-amber-600/15 to-transparent text-amber-200 font-bold border-s-2 border-amber-400 shadow-[0_0_18px_rgba(245,158,11,0.2)]'
                            : 'text-amber-300/85 hover:text-amber-200 hover:bg-gradient-to-r hover:from-amber-500/20 hover:to-transparent'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <Crown size={17} className="shrink-0 text-amber-400 group-hover:text-yellow-300 filter drop-shadow-[0_0_10px_rgba(245,158,11,0.8)] transition-transform duration-300 group-hover:scale-115" />
                          <span className="truncate font-semibold group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform">{isAr ? 'استوديو البطاقات الملكي' : 'Card Studio'}</span>
                        </div>
                      </Link>

                      <Link
                        to="/audit-log"
                        onClick={() => setIsMobileMenuOpen(false)}
                        className={`relative w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs transition-all duration-300 cursor-pointer group ${
                          location.pathname.startsWith('/audit-log')
                            ? isMesopotamian
                              ? 'bg-gradient-to-r from-amber-500/25 via-amber-600/15 to-transparent text-amber-200 font-bold border-s-2 border-amber-400 shadow-[0_0_18px_rgba(245,158,11,0.2)]'
                              : 'bg-gradient-to-r from-purple-500/20 via-fuchsia-500/15 to-transparent text-purple-200 font-semibold shadow-[0_0_20px_rgba(192,132,252,0.12)]'
                            : isMesopotamian
                            ? 'text-amber-100/85 hover:text-white hover:bg-gradient-to-r hover:from-amber-500/20 hover:to-transparent'
                            : 'text-purple-300/85 hover:text-purple-200 hover:bg-gradient-to-r hover:from-purple-500/20 hover:to-transparent'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <Activity size={17} className={`shrink-0 transition-transform duration-300 group-hover:scale-115 ${
                            isMesopotamian ? 'text-amber-400 group-hover:text-yellow-300' : 'text-purple-400 group-hover:text-fuchsia-300 filter drop-shadow-[0_0_8px_rgba(192,132,252,0.8)]'
                          }`} />
                          <span className="truncate font-semibold group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform">{isAr ? 'سجل تدقيق العمليات' : 'Audit Log'}</span>
                        </div>
                      </Link>
                    </>
                  )}

                  <Link
                    to="/notifications"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`relative w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs transition-all duration-300 cursor-pointer group ${
                      location.pathname.startsWith('/notifications')
                        ? isMesopotamian
                          ? 'bg-gradient-to-r from-amber-500/25 via-amber-600/15 to-transparent text-amber-200 font-bold border-s-2 border-amber-400 shadow-[0_0_18px_rgba(245,158,11,0.2)]'
                          : 'bg-gradient-to-r from-sky-500/20 via-teal-500/15 to-transparent text-sky-200 font-semibold shadow-[0_0_20px_rgba(56,189,248,0.12)]'
                        : isMesopotamian
                        ? 'text-amber-100/85 hover:text-white hover:bg-gradient-to-r hover:from-amber-500/20 hover:to-transparent'
                        : 'text-teal-100/75 hover:text-white hover:bg-gradient-to-r hover:from-sky-500/20 hover:to-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <Bell size={17} className={`shrink-0 transition-transform duration-300 group-hover:scale-115 ${
                        isMesopotamian ? 'text-amber-400 group-hover:text-yellow-300' : 'text-sky-400 group-hover:text-sky-300 filter drop-shadow-[0_0_8px_rgba(56,189,248,0.7)]'
                      }`} />
                      <span className="truncate group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform">{t('nav.notifications')}</span>
                    </div>
                    {unreadCount > 0 && (
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold font-mono shadow-xs ${
                        isMesopotamian
                          ? 'bg-gradient-to-r from-amber-400 to-yellow-400 text-stone-950 font-bold'
                          : 'bg-gradient-to-r from-[#5eead4] to-[#2dd4bf] text-[#031211]'
                      }`}>
                        {unreadCount}
                      </span>
                    )}
                  </Link>

                  <Link
                    to="/settings"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`relative w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs transition-all duration-300 cursor-pointer group ${
                      location.pathname.startsWith('/settings')
                        ? isMesopotamian
                          ? 'bg-gradient-to-r from-amber-500/25 via-amber-600/15 to-transparent text-amber-200 font-bold border-s-2 border-amber-400 shadow-[0_0_18px_rgba(245,158,11,0.2)]'
                          : 'bg-gradient-to-r from-teal-500/20 via-emerald-500/15 to-transparent text-teal-200 font-semibold shadow-[0_0_20px_rgba(45,212,191,0.12)]'
                        : isMesopotamian
                        ? 'text-amber-100/85 hover:text-white hover:bg-gradient-to-r hover:from-amber-500/20 hover:to-transparent'
                        : 'text-teal-100/75 hover:text-white hover:bg-gradient-to-r hover:from-teal-500/20 hover:to-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <SettingsIcon size={17} className={`shrink-0 transition-transform duration-300 group-hover:scale-115 ${
                        isMesopotamian ? 'text-amber-400 group-hover:text-yellow-300' : 'text-teal-300 group-hover:text-white filter drop-shadow-[0_0_8px_rgba(94,234,212,0.6)]'
                      }`} />
                      <span className="truncate group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform">{isAr ? 'الإعدادات والمظهر' : 'Settings'}</span>
                    </div>
                  </Link>

                  {/* Secret Room Link (if revealed) */}
                  {isAuthenticated && isSecretArchiveRevealed && !isSecretFinished && (
                    <button
                      onClick={() => {
                        setIsMobileMenuOpen(false);
                        setIsSecretProgressOpen(true);
                      }}
                      className="relative w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs text-amber-300 bg-gradient-to-r from-amber-500/15 via-yellow-500/10 to-transparent hover:from-amber-500/25 transition-all cursor-pointer group"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-base filter drop-shadow-[0_0_8px_rgba(245,158,11,0.8)] transition-transform duration-300 group-hover:scale-115">🔐</span>
                        <span className="font-semibold">{isAr ? 'الغرفة السرية' : 'Secret Chamber'}</span>
                      </div>
                      <span className="text-[9px] font-mono bg-amber-500/20 px-2 py-0.5 rounded-full text-amber-200 border border-amber-400/40">
                        {flagsCount}/{totalFlags}
                      </span>
                    </button>
                  )}
                </div>
              </div>

              {/* Minimalist Modern Floating Footer with Theme Colors */}
              <div className={`relative z-10 px-4 py-3 border-t shrink-0 flex items-center justify-between gap-3 text-xs ${
                isMesopotamian
                  ? 'bg-gradient-to-r from-[#19100a]/95 to-[#100905]/95 border-amber-500/25'
                  : 'bg-gradient-to-r from-[#051c22]/90 to-[#020e11]/92 border-[#5eead4]/20'
              }`}>
                {/* Language Switch Floating Segment */}
                <div className={`flex items-center p-1 rounded-full shadow-inner ${
                  isMesopotamian
                    ? 'bg-[#150d07] border border-amber-500/30'
                    : 'bg-[#072027]/80 border border-[#5eead4]/25'
                }`}>
                  <button
                    onClick={() => setLanguage('ar')}
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold transition-all cursor-pointer ${
                      language === 'ar' 
                        ? isMesopotamian
                          ? 'bg-gradient-to-r from-amber-400 to-yellow-400 text-stone-950 font-bold shadow-[0_0_10px_rgba(251,191,36,0.6)]'
                          : 'bg-gradient-to-r from-[#5eead4] to-[#2dd4bf] text-[#031d1a] font-bold shadow-[0_0_12px_rgba(94,234,212,0.5)]'
                        : isMesopotamian
                        ? 'text-amber-200/70 hover:text-white'
                        : 'text-teal-200/70 hover:text-white'
                    }`}
                  >
                    عربي
                  </button>
                  <button
                    onClick={() => setLanguage('en')}
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold transition-all cursor-pointer ${
                      language === 'en' 
                        ? isMesopotamian
                          ? 'bg-gradient-to-r from-amber-400 to-yellow-400 text-stone-950 font-bold shadow-[0_0_10px_rgba(251,191,36,0.6)]'
                          : 'bg-gradient-to-r from-[#5eead4] to-[#2dd4bf] text-[#031d1a] font-bold shadow-[0_0_12px_rgba(94,234,212,0.5)]'
                        : isMesopotamian
                        ? 'text-amber-200/70 hover:text-white'
                        : 'text-teal-200/70 hover:text-white'
                    }`}
                  >
                    EN
                  </button>
                </div>

                {isAuthenticated && user ? (
                  <button
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      logout();
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold text-rose-300 hover:text-white bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 hover:border-rose-400/50 shadow-xs transition-all cursor-pointer active:scale-95"
                  >
                    <LogOut size={13} className="text-rose-400" />
                    <span>{t('auth.logout')}</span>
                  </button>
                ) : (
                  <a
                    href="https://discord.gg/7wEm4bhc"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold text-white bg-gradient-to-r from-[#5865F2] to-[#7983f5] hover:from-[#4b58e3] hover:to-[#5865F2] shadow-[0_2px_14px_rgba(88,101,242,0.4)] transition-all"
                  >
                    <span>Discord</span>
                    <ExternalLink size={12} />
                  </a>
                )}
              </div>
            </motion.aside>
          </div>
        )}
      </AnimatePresence>

      {/* Enhanced User Profile Modal */}
      <UserProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />
    </>
  );
}


