import React from 'react';
import { motion } from 'motion/react';
import { useLanguage } from '../../context/LanguageContext';
import { Sparkles, Palette, Radio, Gamepad2, Users, Heart, ArrowRight } from 'lucide-react';

export function Introduction() {
  const { t, language } = useLanguage();
  const isRtl = language === 'ar';

  const PILLARS = [
    {
      icon: Palette,
      title: t('intro.feature.creativity'),
      desc: t('intro.feature.creativity.desc'),
      gradient: 'from-cyan-500/20 to-teal-500/10',
      border: 'border-cyan-500/30 hover:border-cyan-400/60',
      iconColor: 'text-cyan-400',
    },
    {
      icon: Radio,
      title: t('intro.feature.streams'),
      desc: t('intro.feature.streams.desc'),
      gradient: 'from-amber-500/20 to-orange-500/10',
      border: 'border-amber-500/30 hover:border-amber-400/60',
      iconColor: 'text-amber-400',
      badge: isRtl ? 'بثوث مباشرة' : 'Live Streams',
    },
    {
      icon: Gamepad2,
      title: t('intro.feature.fun'),
      desc: t('intro.feature.fun.desc'),
      gradient: 'from-emerald-500/20 to-teal-500/10',
      border: 'border-emerald-500/30 hover:border-emerald-400/60',
      iconColor: 'text-emerald-400',
    },
    {
      icon: Users,
      title: t('intro.feature.edgar'),
      desc: t('intro.feature.edgar.desc'),
      gradient: 'from-rose-500/20 to-amber-500/10',
      border: 'border-rose-500/30 hover:border-rose-400/60',
      iconColor: 'text-rose-400',
    },
  ];

  return (
    <section className="relative py-20 md:py-28 px-4 sm:px-6 md:px-12 overflow-hidden">
      <div className="max-w-5xl mx-auto relative z-10">
        
        {/* Main Community Centerpiece Card */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="relative rounded-[2.5rem] border border-archive-cyan/25 bg-gradient-to-b from-[#071c21]/90 via-archive-dark/95 to-archive-dark p-8 sm:p-12 md:p-16 shadow-[0_20px_60px_rgba(0,0,0,0.6)] backdrop-blur-md overflow-hidden gpu-60fps group"
        >
          {/* Subtle Corner Accents & Top Glow */}
          <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-archive-cyan/60 to-transparent" />
          <div className="absolute -top-24 start-1/2 -translate-x-1/2 rtl:translate-x-1/2 w-96 h-48 bg-archive-cyan/15 rounded-full blur-3xl pointer-events-none" />

          {/* Subtitle Badge */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-archive-cyan/15 border border-archive-cyan/35 text-archive-cyan text-xs font-semibold tracking-widest uppercase shadow-[0_0_20px_rgba(6,182,212,0.2)]">
              <Sparkles size={13} className="text-archive-cyan" />
              <span>{t('intro.badge')}</span>
              <Sparkles size={13} className="text-amber-400" />
            </div>
          </div>

          {/* Main Headline */}
          <h2 className="font-display font-black text-3xl sm:text-5xl md:text-6xl text-center text-transparent bg-clip-text bg-gradient-to-r from-white via-archive-paper to-archive-cyan mb-8 tracking-wide drop-shadow-md">
            {t('intro.title')}
          </h2>

          {/* Rich Description */}
          <p className="font-sans text-base sm:text-lg md:text-xl text-archive-paper-muted text-center leading-relaxed font-light max-w-3xl mx-auto mb-14">
            {t('intro.desc')}
          </p>

          {/* 4 Interactive Feature Pillars */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 mb-12">
            {PILLARS.map((pillar, idx) => {
              const Icon = pillar.icon;
              return (
                <div
                  key={idx}
                  className={`relative p-6 rounded-2xl border ${pillar.border} bg-gradient-to-br ${pillar.gradient} backdrop-blur-sm transition-all duration-300 hover:scale-[1.02] shadow-lg gpu-60fps flex flex-col justify-between`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-3 mb-3">
                      <div className={`p-2.5 rounded-xl bg-archive-dark/80 border border-archive-cyan/20 ${pillar.iconColor} shadow-sm`}>
                        <Icon size={20} />
                      </div>
                      {pillar.badge && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/40 text-[11px] font-semibold font-mono animate-pulse">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                          {pillar.badge}
                        </span>
                      )}
                    </div>
                    <h3 className="font-display font-bold text-lg sm:text-xl text-white mb-2">
                      {pillar.title}
                    </h3>
                    <p className="font-sans text-archive-paper-muted text-xs sm:text-sm leading-relaxed font-light">
                      {pillar.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Community Call-to-Action Bar */}
          <div className="pt-8 border-t border-archive-cyan/15 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2.5 text-xs text-archive-paper-muted/80">
              <Heart size={15} className="text-rose-400 fill-rose-400/40" />
              <span>{isRtl ? 'المجتمع الرسمي للفنان والستريمر Edgar' : 'The Official Community of Artist & Streamer Edgar'}</span>
            </div>

            <a
              href="https://discord.gg"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-archive-cyan to-teal-500 text-archive-dark font-display font-bold text-sm hover:shadow-[0_0_25px_rgba(6,182,212,0.5)] transition-all hover:scale-105 active:scale-95 shadow-md"
            >
              <span>{t('footer.enter')}</span>
              <ArrowRight size={16} className={isRtl ? 'rotate-180' : ''} />
            </a>
          </div>

        </motion.div>
      </div>
    </section>
  );
}
