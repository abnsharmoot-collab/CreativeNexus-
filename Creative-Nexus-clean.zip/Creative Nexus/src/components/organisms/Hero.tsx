import React, { useRef } from 'react';
import { motion, useScroll, useTransform, useReducedMotion, useMotionValue, useSpring } from 'motion/react';
import { useLanguage } from '../../context/LanguageContext';
import { useDiscordServer } from '../../context/DiscordServerContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { useNavigate } from 'react-router-dom';
import { ChevronDown, BookOpen, LayoutDashboard } from 'lucide-react';
import { HiddenIraqiFlag } from '../easterEggs/HiddenIraqiFlag';
import { WingedSolarDisc } from '../atoms/WingedSolarDisc';
import { MainMenuBackgroundLayer } from '../home/MainMenuBackgroundLayer';
import { CreativeNexusBio } from '../home/CreativeNexusBio';
import { CreativeNexusHeadline } from '../home/CreativeNexusHeadline';
import SingularityHorizon from '@/components/ui/singularity-horizon';

export function Hero() {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { serverInfo } = useDiscordServer();
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';
  const navigate = useNavigate();
  const ref = useRef<HTMLElement>(null);
  const prefersReducedMotion = useReducedMotion();

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"]
  });

  const bgYRaw = useTransform(scrollYProgress, [0, 1], ['0%', '40%']);
  const bgOpacityRaw = useTransform(scrollYProgress, [0, 0.85], [1, 0]);
  const textYRaw = useTransform(scrollYProgress, [0, 1], ['0%', '20%']);
  const textOpacityRaw = useTransform(scrollYProgress, [0, 0.85], [1, 0]);

  const bgY = prefersReducedMotion ? '0%' : bgYRaw;
  const bgOpacity = prefersReducedMotion ? 1 : bgOpacityRaw;
  const textY = prefersReducedMotion ? '0%' : textYRaw;
  const textOpacity = prefersReducedMotion ? 1 : textOpacityRaw;

  // Interactive 3D Perspective Motion
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const springConfig = { damping: 22, stiffness: 180 };
  const rotateX = useSpring(useTransform(mouseY, [-0.5, 0.5], [14, -14]), springConfig);
  const rotateY = useSpring(useTransform(mouseX, [-0.5, 0.5], [-16, 16]), springConfig);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (prefersReducedMotion) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    mouseX.set(x);
    mouseY.set(y);
  };

  const handleMouseLeave = () => {
    mouseX.set(0);
    mouseY.set(0);
  };

  const scrollToNext = () => {
    const nextEl = document.getElementById('why') || document.getElementById('vibe') || document.getElementById('guidebook');
    if (nextEl) {
      nextEl.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollTo({
        top: window.innerHeight * 0.85,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section ref={ref} className="relative min-h-[calc(100dvh-var(--header-height))] flex flex-col items-center justify-start pt-8 sm:pt-12 md:pt-16 pb-8 sm:pb-12 overflow-x-clip">
      {/* Background Lighting & Singularity Horizon Parallax Layer */}
      <motion.div 
        className="absolute inset-0 z-0 flex items-center justify-center overflow-hidden"
        style={{ y: bgY, opacity: bgOpacity }}
      >
        {/* Custom Owner Main Menu Hero Background Layer */}
        <MainMenuBackgroundLayer scope="hero" />

        {!isMesopotamian ? (
          <div className="absolute inset-0 w-full h-full flex items-center justify-center pointer-events-auto overflow-hidden">
            {/* Live WebGL2 Singularity Horizon - Shifted down on mobile to reside in the blank area below the menu buttons */}
            <div className="absolute inset-0 w-full h-full translate-y-[22%] sm:translate-y-0 opacity-75 sm:opacity-85 transition-all duration-700">
              <SingularityHorizon 
                height="100%"
                className="w-full h-full"
                hud={false}
                showCenterTitle={false}
                interactive={true}
                particles={4500}
              />
            </div>

            {/* Seamless Vignettes & Edge Blends */}
            <div className="absolute inset-x-0 bottom-0 h-44 bg-gradient-to-t from-[#010807] via-[#010807]/75 to-transparent pointer-events-none" />
            <div className="absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-[#031211]/85 via-transparent to-transparent pointer-events-none" />

            {/* Subtle Celestial Ambient Aura matching the mobile position */}
            <div className="absolute top-1/2 start-1/2 -translate-x-1/2 -translate-y-1/2 translate-y-[22%] sm:translate-y-0 w-[540px] h-[540px] rounded-full bg-[#5eead4]/6 blur-[150px] pointer-events-none" />
          </div>
        ) : (
          <div className="relative w-full h-full flex items-center justify-center pointer-events-none">
            {/* Rebuilt Ancient Mesopotamian Sacred Gold Celestial Rings behind Server Name */}
            <div className="ring-celestial-meso w-[280px] h-[280px] sm:w-[460px] sm:h-[460px] lg:w-[640px] lg:h-[640px] max-w-[88vw] max-h-[88vw]" />
            <div className="ring-celestial-meso-outer w-[210px] h-[210px] sm:w-[330px] sm:h-[330px] lg:w-[480px] lg:h-[480px] max-w-[74vw] max-h-[74vw]" />
          </div>
        )}
      </motion.div>

      {/* Main Content Area - Generously spaced with distinct breathing room below header */}
      <motion.div 
        className="relative z-20 max-w-5xl mx-auto px-4 sm:px-6 text-center w-full flex flex-col items-center pt-6 sm:pt-10 md:pt-14"
        style={{ y: textY, opacity: textOpacity }}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="w-full flex flex-col items-center"
        >
          {/* 3D Animated Server Name Headline Container with ample space on mobile & desktop */}
          <div 
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            className="perspective-1000 select-none pt-4 sm:pt-8 md:pt-10 pb-1 flex flex-col items-center justify-center cursor-default max-w-full w-full"
          >
            {/* 3D Entry Animation when first entering the website */}
            <motion.div
              initial={{
                opacity: 0,
                scale: 0.58,
                rotateX: 42,
                y: 65,
                filter: 'blur(16px)',
              }}
              animate={{
                opacity: 1,
                scale: 1,
                rotateX: 0,
                y: 0,
                filter: 'blur(0px)',
              }}
              transition={{
                duration: 1.2,
                delay: 0.1,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="relative w-full flex flex-col items-center"
              style={{
                transformStyle: 'preserve-3d',
              }}
            >
              {/* Continuous Levitation & Interactive Tilt */}
              <motion.div
                style={{
                  rotateX: prefersReducedMotion ? 0 : rotateX,
                  rotateY: prefersReducedMotion ? 0 : rotateY,
                  transformStyle: 'preserve-3d',
                }}
                animate={prefersReducedMotion ? {} : {
                  y: [0, -9, 0],
                  rotateZ: [-0.3, 0.3, -0.3],
                }}
                transition={{
                  repeat: Infinity,
                  duration: 5.2,
                  ease: "easeInOut"
                }}
                className="relative group flex flex-col items-center max-w-full w-full"
              >
                <CreativeNexusHeadline />
              </motion.div>
            </motion.div>
          </div>

          {/* Adjustable Bio under CREATIVE NEXUS */}
          <CreativeNexusBio />

          {/* Winged Solar Disc Relief in Mesopotamian Mode */}
          {isMesopotamian && (
            <WingedSolarDisc className="mb-6" />
          )}

          {/* Three Action Buttons - Repositioned with Animated Entrance & Micro-Interactions */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 sm:gap-4 md:gap-5 mt-6 sm:mt-8 w-full max-w-sm sm:max-w-none mx-auto">
            {/* 1. Primary Action: Join Server */}
            <motion.a
              href={serverInfo.instantInvite || 'https://discord.gg'}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15, duration: 0.5 }}
              whileHover={{ y: -3, scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="btn-nexus-primary relative overflow-hidden group w-full sm:w-auto text-xs sm:text-sm md:text-base py-3.5 px-7 sm:px-8 shadow-xl shadow-[#5eead4]/20 border border-white/40 cursor-pointer"
            >
              {/* Shimmer light sweep animation */}
              <span className="absolute inset-0 w-1/2 h-full bg-gradient-to-r from-transparent via-white/35 to-transparent -skew-x-12 -translate-x-full group-hover:translate-x-[300%] transition-transform duration-1000 ease-in-out pointer-events-none" />
              <svg className="w-4 h-4 sm:w-5 sm:h-5 fill-current shrink-0" viewBox="0 0 24 24">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.893.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
              </svg>
              <span className="font-cairo font-bold">{isAr ? 'انضم للمجتمع' : 'Join Server'}</span>
            </motion.a>

            {/* 2. Secondary Action: Explore History */}
            <motion.button
              onClick={() => navigate('/history')}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25, duration: 0.5 }}
              whileHover={{ y: -3, scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="btn-nexus-glass w-full sm:w-auto text-xs sm:text-sm md:text-base py-3.5 px-6 sm:px-7 border border-white/10 hover:border-cyan-400/50 hover:shadow-[0_0_20px_rgba(94,234,212,0.2)] transition-all flex items-center justify-center gap-2 group cursor-pointer"
            >
              <BookOpen size={16} className="text-[#5eead4]/80 group-hover:text-[#5eead4] transition-colors shrink-0" />
              <span className="font-cairo font-semibold">{isAr ? 'استكشف التاريخ' : 'Explore History'}</span>
            </motion.button>

            {/* 3. Secondary Action: Server Dashboard */}
            <motion.button
              onClick={() => navigate('/server-dashboard')}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.35, duration: 0.5 }}
              whileHover={{ y: -3, scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="btn-nexus-glass w-full sm:w-auto text-xs sm:text-sm md:text-base py-3.5 px-6 sm:px-7 border border-white/10 hover:border-cyan-400/50 hover:shadow-[0_0_20px_rgba(94,234,212,0.2)] transition-all flex items-center justify-center gap-2 group cursor-pointer"
            >
              <LayoutDashboard size={16} className="text-[#5eead4]/80 group-hover:text-[#5eead4] transition-colors shrink-0" />
              <span className="font-cairo font-semibold">{isAr ? 'لوحة السيرفر' : 'Server Dashboard'}</span>
            </motion.button>
          </div>
        </motion.div>
      </motion.div>

      {/* Scroll Down Hint & Hidden Easter Egg */}
      <div className="relative z-20 mt-6 sm:mt-8 pt-2 pb-2 flex flex-col items-center">
        <div className="relative flex items-center justify-center">
          <motion.button
            onClick={scrollToNext}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: [0, 6, 0] }}
            transition={{ 
              opacity: { delay: 1, duration: 0.6 },
              y: { repeat: Infinity, duration: 2.2, ease: "easeInOut" }
            }}
            className="p-2 cursor-pointer text-[#5eead4]/70 hover:text-[#5eead4] transition-colors"
            aria-label="Scroll to content"
          >
            <ChevronDown size={22} />
          </motion.button>
          
          <div className="absolute -end-8 top-1/2 -translate-y-1/2">
            <HiddenIraqiFlag flagId="flag-home-hero" title="Archival registry stamp" />
          </div>
        </div>
      </div>
    </section>
  );
}
