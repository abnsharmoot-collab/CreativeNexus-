import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useSiteLogo, DEFAULT_SITE_LOGO, SiteLogoSettings } from '../../context/SiteLogoContext';
import { useLanguage } from '../../context/LanguageContext';
import {
  X, Sparkles, Check, RotateCcw, Image as ImageIcon,
  Palette, Upload, Type, Eye, Shield, Crown, Flame, Star
} from 'lucide-react';

interface OwnerLogoCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const COLOR_PRESETS = [
  { name: 'Teal Nexus (Default)', accent: '#5eead4', from: '#ffffff', to: '#2dd4bf' },
  { name: 'Imperial Gold', accent: '#f59e0b', from: '#fffbeb', to: '#d97706' },
  { name: 'Cosmic Amethyst', accent: '#c084fc', from: '#faf5ff', to: '#9333ea' },
  { name: 'Cyber Neon Cyan', accent: '#38bdf8', from: '#f0f9ff', to: '#0284c7' },
  { name: 'Blood Crimson', accent: '#f43f5e', from: '#fff1f2', to: '#e11d48' },
  { name: 'Emerald Jade', accent: '#34d399', from: '#ecfdf5', to: '#059669' },
  { name: 'Rose Quartz', accent: '#fb7185', from: '#fff1f2', to: '#e11d48' },
];

const ICON_TYPES: Array<{ id: SiteLogoSettings['iconType']; label: string; icon: any }> = [
  { id: 'dual_star', label: 'Dual Star (Classic)', icon: Star },
  { id: 'nexus_core', label: 'Nexus Core', icon: Sparkles },
  { id: 'crown', label: 'Sovereign Crown', icon: Crown },
  { id: 'dragon', label: 'Mythic Flame', icon: Flame },
  { id: 'shield', label: 'Aegis Shield', icon: Shield },
];

export const OwnerLogoCustomizerModal: React.FC<OwnerLogoCustomizerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { logoSettings, updateLogoSettings, resetLogoSettings, isLoading } = useSiteLogo();
  const { isRtl } = useLanguage();

  const [mode, setMode] = useState<'vector' | 'image'>(logoSettings.mode || 'vector');
  const [titleEn, setTitleEn] = useState(logoSettings.titleEn || DEFAULT_SITE_LOGO.titleEn);
  const [titleAr, setTitleAr] = useState(logoSettings.titleAr || DEFAULT_SITE_LOGO.titleAr);
  const [subtitleEn, setSubtitleEn] = useState(logoSettings.subtitleEn || DEFAULT_SITE_LOGO.subtitleEn);
  const [subtitleAr, setSubtitleAr] = useState(logoSettings.subtitleAr || DEFAULT_SITE_LOGO.subtitleAr);
  const [showSubtitle, setShowSubtitle] = useState(logoSettings.showSubtitle !== false);
  const [imageUrl, setImageUrl] = useState(logoSettings.imageUrl || '');
  const [iconType, setIconType] = useState<SiteLogoSettings['iconType']>(logoSettings.iconType || 'dual_star');
  const [accentColor, setAccentColor] = useState(logoSettings.accentColor || DEFAULT_SITE_LOGO.accentColor);
  const [gradientFrom, setGradientFrom] = useState(logoSettings.gradientFrom || DEFAULT_SITE_LOGO.gradientFrom);
  const [gradientTo, setGradientTo] = useState(logoSettings.gradientTo || DEFAULT_SITE_LOGO.gradientTo);
  const [glowIntensity, setGlowIntensity] = useState<SiteLogoSettings['glowIntensity']>(logoSettings.glowIntensity || 'radiant');

  const [feedback, setFeedback] = useState<string | null>(null);
  const [feedbackType, setFeedbackType] = useState<'success' | 'error'>('success');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync state whenever modal opens or settings change
  useEffect(() => {
    if (isOpen) {
      setMode(logoSettings.mode || 'vector');
      setTitleEn(logoSettings.titleEn || DEFAULT_SITE_LOGO.titleEn);
      setTitleAr(logoSettings.titleAr || DEFAULT_SITE_LOGO.titleAr);
      setSubtitleEn(logoSettings.subtitleEn || DEFAULT_SITE_LOGO.subtitleEn);
      setSubtitleAr(logoSettings.subtitleAr || DEFAULT_SITE_LOGO.subtitleAr);
      setShowSubtitle(logoSettings.showSubtitle !== false);
      setImageUrl(logoSettings.imageUrl || '');
      setIconType(logoSettings.iconType || 'dual_star');
      setAccentColor(logoSettings.accentColor || DEFAULT_SITE_LOGO.accentColor);
      setGradientFrom(logoSettings.gradientFrom || DEFAULT_SITE_LOGO.gradientFrom);
      setGradientTo(logoSettings.gradientTo || DEFAULT_SITE_LOGO.gradientTo);
      setGlowIntensity(logoSettings.glowIntensity || 'radiant');
      setFeedback(null);
    }
  }, [isOpen, logoSettings]);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setFeedback('Please upload a valid image file (PNG, JPG, SVG, WebP).');
      setFeedbackType('error');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setFeedback('Image file is too large (max 5MB).');
      setFeedbackType('error');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setImageUrl(reader.result);
        setMode('image');
        setFeedback('Custom logo image loaded! Click Save to apply.');
        setFeedbackType('success');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    setFeedback(null);
    const success = await updateLogoSettings({
      mode,
      titleEn: titleEn.trim() || DEFAULT_SITE_LOGO.titleEn,
      titleAr: titleAr.trim() || DEFAULT_SITE_LOGO.titleAr,
      subtitleEn: subtitleEn.trim() || DEFAULT_SITE_LOGO.subtitleEn,
      subtitleAr: subtitleAr.trim() || DEFAULT_SITE_LOGO.subtitleAr,
      showSubtitle,
      imageUrl: imageUrl.trim(),
      iconType,
      accentColor,
      gradientFrom,
      gradientTo,
      glowIntensity,
    });

    if (success) {
      setFeedback(isRtl ? 'تم حفظ شعار وهوية الموقع بنجاح!' : 'Website logo & brand name saved successfully!');
      setFeedbackType('success');
      setTimeout(() => {
        onClose();
      }, 1000);
    } else {
      setFeedback(isRtl ? 'تعذر الحفظ، يرجى المحاولة مرة أخرى.' : 'Failed to save logo settings. Please try again.');
      setFeedbackType('error');
    }
  };

  const handleReset = async () => {
    if (window.confirm(isRtl ? 'هل تريد استعادة الشعار الافتراضي للموقع؟' : 'Reset website logo to default?')) {
      const success = await resetLogoSettings();
      if (success) {
        setFeedback('Reset to default logo successfully!');
        setFeedbackType('success');
        setTimeout(() => onClose(), 1000);
      }
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.24, ease: 'easeOut' }}
          className="relative w-full max-w-2xl bg-gradient-to-b from-[#081a20] via-[#040e13] to-[#02070a] border border-[#5eead4]/40 rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.95),0_0_35px_rgba(94,234,212,0.15)] flex flex-col max-h-[92vh] overflow-hidden text-white"
        >
          {/* Header */}
          <div className="px-5 py-3.5 border-b border-white/10 flex items-center justify-between shrink-0 bg-slate-950/60">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#5eead4]/30 to-teal-500/20 border border-[#5eead4]/50 flex items-center justify-center shadow-[0_0_12px_rgba(94,234,212,0.3)]">
                <Palette size={16} className="text-[#5eead4]" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-black font-display tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-white via-teal-100 to-[#5eead4]">
                  {isRtl ? 'تخصيص شعار الموقع (المالك فقط)' : 'Customize Website Logo (Owners Only)'}
                </h3>
                <p className="text-[10px] text-teal-300/70 font-mono">
                  {isRtl ? 'تحكم في اسم وشعار وهوية القائمة العلوية' : 'Configure upper menu brandmark, title, & styling'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>

          {/* Feedback banner */}
          {feedback && (
            <div className={`px-4 py-2 text-xs font-mono font-bold flex items-center justify-between shrink-0 ${
              feedbackType === 'success' ? 'bg-emerald-950/80 text-emerald-300 border-b border-emerald-500/40' : 'bg-rose-950/80 text-rose-300 border-b border-rose-500/40'
            }`}>
              <span>{feedback}</span>
              <button type="button" onClick={() => setFeedback(null)} className="text-xs opacity-70 hover:opacity-100">✕</button>
            </div>
          )}

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5">
            {/* REAL-TIME PREVIEW IN UPPER MENU FRAME */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-mono font-bold text-teal-200">
                <span className="flex items-center gap-1.5">
                  <Eye size={13} className="text-[#5eead4]" />
                  <span>{isRtl ? 'معاينة الشعار الحية في القائمة العلوية' : 'Live Upper Menu Logo Preview'}</span>
                </span>
                <span className="text-[10px] text-slate-400">
                  {mode === 'image' ? 'Image Mode' : 'Vector 3D Mode'}
                </span>
              </div>

              <div className="p-4 rounded-xl bg-[#030708]/90 border border-[#5eead4]/30 shadow-inner flex flex-col items-center justify-center min-h-[90px] relative overflow-hidden">
                <div className="absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#5eead4]/60 to-transparent pointer-events-none" />
                
                {/* Live Preview Element */}
                <div className="inline-flex items-center gap-3">
                  {mode === 'image' && imageUrl ? (
                    <div className="relative shrink-0 flex items-center justify-center border-0 bg-transparent p-0 shadow-none">
                      <img src={imageUrl} alt="Logo" className="h-10 sm:h-11 w-auto max-w-[130px] object-contain select-none border-0 rounded-none drop-shadow-sm" />
                    </div>
                  ) : (
                    <div className="relative w-9 h-9 sm:w-10 sm:h-10 flex items-center justify-center shrink-0">
                      <div className="relative z-10 w-full h-full flex items-center justify-center">
                        <Sparkles size={24} style={{ color: accentColor }} className="drop-shadow-[0_0_8px_currentColor]" />
                      </div>
                    </div>
                  )}

                  <div className="flex flex-col leading-tight">
                    <span 
                      className="text-lg sm:text-xl font-black font-display tracking-tight"
                      style={{
                        backgroundImage: `linear-gradient(120deg, ${gradientFrom}, ${accentColor}, ${gradientTo})`,
                        WebkitBackgroundClip: 'text',
                        backgroundClip: 'text',
                        WebkitTextFillColor: 'transparent',
                        color: 'transparent',
                      }}
                    >
                      {titleEn}
                    </span>
                    {showSubtitle && (
                      <span className="text-[9px] font-mono tracking-widest uppercase text-teal-300/80">
                        {subtitleEn}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Mode Selector */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-black/40 border border-white/10 rounded-xl">
              <button
                type="button"
                onClick={() => setMode('vector')}
                className={`py-2 px-3 rounded-lg text-xs font-mono font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  mode === 'vector'
                    ? 'bg-gradient-to-r from-[#5eead4]/25 to-teal-500/25 border border-[#5eead4]/60 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Type size={14} />
                <span>{isRtl ? 'شعار نصي ورمزي 3D' : '3D Vector & Title'}</span>
              </button>

              <button
                type="button"
                onClick={() => setMode('image')}
                className={`py-2 px-3 rounded-lg text-xs font-mono font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  mode === 'image'
                    ? 'bg-gradient-to-r from-[#5eead4]/25 to-teal-500/25 border border-[#5eead4]/60 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <ImageIcon size={14} />
                <span>{isRtl ? 'صورة شعار مخصصة' : 'Custom Image / Badge'}</span>
              </button>
            </div>

            {/* If Mode is Image */}
            {mode === 'image' && (
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-cyan-500/20 space-y-3">
                <label className="block text-xs font-mono font-bold text-teal-200">
                  {isRtl ? 'رابط صورة الشعار أو رفع ملف' : 'Logo Image URL or Upload File'}
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="https://.../my-logo.png"
                    className="flex-1 bg-black/60 border border-white/15 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#5eead4]"
                  />
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-2 rounded-lg bg-teal-500/20 hover:bg-teal-500/30 border border-teal-400/40 text-teal-200 text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Upload size={13} />
                    <span>{isRtl ? 'رفع' : 'Upload'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-teal-300/80 font-mono mt-1.5 flex items-center gap-1.5">
                  <Check size={12} className="text-[#5eead4] shrink-0" />
                  <span>
                    {isRtl 
                      ? 'يتم عرض الشعار بدون حدود دائرية أو إطارات مصطنعة — الحدود تأتي من حدود الصورة نفسها فقط.' 
                      : 'The logo renders borderless with no circular frame or box — boundaries come strictly from the image itself.'}
                  </span>
                </p>
              </div>
            )}

            {/* Title & Brand Name Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-mono text-slate-300 mb-1">
                  {isRtl ? 'اسم الموقع (إنجليزي)' : 'Brand Title (English)'}
                </label>
                <input
                  type="text"
                  value={titleEn}
                  onChange={(e) => setTitleEn(e.target.value)}
                  placeholder="Creative Nexus"
                  className="w-full bg-black/60 border border-white/15 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#5eead4]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-300 mb-1">
                  {isRtl ? 'اسم الموقع (عربي)' : 'Brand Title (Arabic)'}
                </label>
                <input
                  type="text"
                  value={titleAr}
                  onChange={(e) => setTitleAr(e.target.value)}
                  placeholder="مركز الإبداع"
                  className="w-full bg-black/60 border border-white/15 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#5eead4]"
                  dir="rtl"
                />
              </div>
            </div>

            {/* Subtitle Fields */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-slate-300">
                  {isRtl ? 'النص الفرعي للشعار' : 'Logo Subtitle / Tagline'}
                </span>
                <label className="flex items-center gap-1.5 text-xs text-teal-300 font-mono cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showSubtitle}
                    onChange={(e) => setShowSubtitle(e.target.checked)}
                    className="rounded bg-black/60 border-white/20 text-teal-500"
                  />
                  <span>{isRtl ? 'إظهار النص الفرعي' : 'Show Subtitle'}</span>
                </label>
              </div>

              {showSubtitle && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    value={subtitleEn}
                    onChange={(e) => setSubtitleEn(e.target.value)}
                    placeholder="COMMUNITY PORTAL // NEXUS"
                    className="w-full bg-black/60 border border-white/15 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#5eead4]"
                  />
                  <input
                    type="text"
                    value={subtitleAr}
                    onChange={(e) => setSubtitleAr(e.target.value)}
                    placeholder="CREATIVE NEXUS // شبكة الإبداع"
                    className="w-full bg-black/60 border border-white/15 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#5eead4]"
                    dir="rtl"
                  />
                </div>
              )}
            </div>

            {/* Vector Emblem Icon Selector */}
            {mode === 'vector' && (
              <div className="space-y-2">
                <label className="block text-xs font-mono text-slate-300">
                  {isRtl ? 'أيقونة الشعار الرمزية' : 'Emblem Icon Type'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {ICON_TYPES.map((it) => {
                    const IconComp = it.icon;
                    const isSelected = iconType === it.id;
                    return (
                      <button
                        key={it.id}
                        type="button"
                        onClick={() => setIconType(it.id)}
                        className={`p-2 rounded-xl border text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-teal-500/20 border-[#5eead4] text-[#5eead4] shadow-[0_0_12px_rgba(94,234,212,0.3)]'
                            : 'bg-black/40 border-white/10 text-slate-400 hover:text-white hover:border-white/20'
                        }`}
                      >
                        <IconComp size={15} />
                        <span className="truncate">{it.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Color Palette Presets */}
            <div className="space-y-2">
              <label className="block text-xs font-mono text-slate-300">
                {isRtl ? 'الألوان والتوهج' : 'Color Theme & Gradient'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {COLOR_PRESETS.map((p) => {
                  const isSelected = accentColor === p.accent;
                  return (
                    <button
                      key={p.name}
                      type="button"
                      onClick={() => {
                        setAccentColor(p.accent);
                        setGradientFrom(p.from);
                        setGradientTo(p.to);
                      }}
                      className={`p-2 rounded-xl border text-[11px] font-mono flex items-center gap-2 transition-all cursor-pointer ${
                        isSelected
                          ? 'border-white bg-white/10 text-white shadow-md'
                          : 'border-white/10 bg-black/40 text-slate-400 hover:text-white'
                      }`}
                    >
                      <span 
                        className="w-3.5 h-3.5 rounded-full shrink-0 shadow-sm"
                        style={{ background: p.accent }}
                      />
                      <span className="truncate">{p.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="px-5 py-3 border-t border-white/10 flex items-center justify-between shrink-0 bg-slate-950/80">
            <button
              type="button"
              onClick={handleReset}
              disabled={isLoading}
              className="px-3 py-1.5 rounded-xl border border-white/15 hover:border-white/30 text-slate-300 hover:text-white text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <RotateCcw size={12} />
              <span>{isRtl ? 'استعادة الافتراضي' : 'Reset to Default'}</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                disabled={isLoading}
                className="px-3 py-1.5 rounded-xl text-slate-400 hover:text-white text-xs font-mono transition-colors cursor-pointer"
              >
                {isRtl ? 'إلغاء' : 'Cancel'}
              </button>

              <button
                type="button"
                onClick={handleSave}
                disabled={isLoading}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#5eead4] via-teal-400 to-[#2dd4bf] hover:brightness-110 text-stone-950 text-xs font-mono font-black flex items-center gap-1.5 transition-all shadow-[0_0_15px_rgba(94,234,212,0.4)] cursor-pointer active:scale-95"
              >
                <Check size={14} />
                <span>{isLoading ? (isRtl ? 'جارِ الحفظ...' : 'Saving...') : (isRtl ? 'حفظ الشعار' : 'Save Logo')}</span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
