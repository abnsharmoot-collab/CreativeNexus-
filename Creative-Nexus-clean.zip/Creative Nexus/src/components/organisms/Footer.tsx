import React from 'react';
import { Link } from 'react-router-dom';
import { Logo } from '../atoms/Logo';
import { Button } from '../atoms/Button';
import { useLanguage } from '../../context/LanguageContext';
import { useDiscordServer } from '../../context/DiscordServerContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { HiddenIraqiFlag } from '../easterEggs/HiddenIraqiFlag';
import { Lock } from 'lucide-react';
import { DownloadHtmlButton } from '../export/DownloadHtmlButton';

export function Footer() {
  const { t } = useLanguage();
  const { serverInfo } = useDiscordServer();
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  return (
    <footer className={`relative pt-16 pb-12 px-6 overflow-hidden ${
      isMesopotamian
        ? 'mesopotamian-stone-bg border-t-2 border-amber-600/50'
        : 'bg-[#020d0c] border-t border-[rgba(158,255,230,0.14)] text-[#8db8b1]'
    }`}>
      {/* Decorative top border glow */}
      {isMesopotamian ? (
        <div className="absolute top-0 start-1/2 -translate-x-1/2 rtl:translate-x-1/2 w-3/4 max-w-4xl h-[2px] bg-gradient-to-r from-transparent via-amber-400/70 to-transparent shadow-[0_0_25px_rgba(245,158,11,0.6)]" />
      ) : (
        <div className="absolute top-0 start-1/2 -translate-x-1/2 rtl:translate-x-1/2 w-3/4 max-w-4xl h-[2px] bg-gradient-to-r from-transparent via-[#5eead4]/70 to-transparent shadow-[0_0_25px_rgba(94,234,212,0.6)]" />
      )}
      
      {/* Soft footer ambient radial glow */}
      <div 
        className={`absolute bottom-0 start-1/2 -translate-x-1/2 rtl:translate-x-1/2 w-[600px] h-[250px] blur-[130px] pointer-events-none ${
          isMesopotamian ? 'bg-amber-600/10' : 'bg-[#5eead4]/10'
        }`} 
      />

      <div className="relative z-10 max-w-7xl mx-auto flex flex-col items-center">
        <Logo className="mb-10 scale-110" />
        
        <div className={`flex flex-wrap items-center justify-center gap-4 sm:gap-8 mb-10 text-xs sm:text-sm font-medium tracking-wide ${
          isMesopotamian ? 'text-amber-200/80' : 'text-[#8db8b1]'
        }`}>
          <Link 
            to="/" 
            className={`transition-colors ${isMesopotamian ? 'hover:text-amber-300' : 'hover:text-[#5eead4]'}`}
          >
            {t('nav.home')}
          </Link>
          <span className={`w-1.5 h-1.5 rounded-full ${isMesopotamian ? 'bg-amber-500/40' : 'bg-[rgba(158,255,230,0.3)]'}`} />
          <Link 
            to="/history" 
            className={`transition-colors ${isMesopotamian ? 'hover:text-amber-300' : 'hover:text-[#5eead4]'}`}
          >
            {t('nav.history')}
          </Link>
          <span className={`w-1.5 h-1.5 rounded-full ${isMesopotamian ? 'bg-amber-500/40' : 'bg-[rgba(158,255,230,0.3)]'}`} />
          <Link 
            to="/guidebook" 
            className={`transition-colors ${isMesopotamian ? 'hover:text-amber-300' : 'hover:text-[#5eead4]'}`}
          >
            {t('footer.manifesto')}
          </Link>
          <span className={`w-1.5 h-1.5 rounded-full ${isMesopotamian ? 'bg-amber-500/40' : 'bg-[rgba(158,255,230,0.3)]'}`} />
          <Link 
            to="/guidebook/book-rules-procedures" 
            className={`transition-colors ${isMesopotamian ? 'hover:text-amber-300' : 'hover:text-[#5eead4]'}`}
          >
            {t('footer.rules')}
          </Link>
          <span className={`w-1.5 h-1.5 rounded-full ${isMesopotamian ? 'bg-amber-500/40' : 'bg-[rgba(158,255,230,0.3)]'}`} />
          <Link 
            to="/server-dashboard" 
            className={`transition-colors ${isMesopotamian ? 'hover:text-amber-300' : 'hover:text-[#5eead4]'}`}
          >
            {t('nav.dashboard')}
          </Link>
        </div>
        
        <div className="flex flex-wrap items-center justify-center gap-4 mb-12">
          <button 
            className="btn-nexus-primary text-sm py-3 px-8"
            onClick={() => window.open(serverInfo.instantInvite || 'https://discord.gg', '_blank', 'noopener,noreferrer')}
          >
            {isMesopotamian ? "Join Edgar's Server" : t('footer.enter')}
          </button>

          <DownloadHtmlButton variant="footer" />
        </div>

        <div className={`w-full flex flex-col md:flex-row justify-between items-center gap-4 pt-8 text-xs tracking-wider ${
          isMesopotamian 
            ? 'border-t border-amber-600/25 font-serif text-amber-400/60' 
            : 'border-t border-[rgba(158,255,230,0.12)] font-sans text-[#8db8b1]/70'
        }`}>
          <div className="flex items-center gap-2">
            <p>{t('footer.copyright')}</p>
            <HiddenIraqiFlag flagId="flag-footer-archive" title="Deep archival seal" />
          </div>

          <div className={`flex items-center gap-2 mt-2 md:mt-0 font-medium ${
            isMesopotamian ? 'text-amber-300/80' : 'text-[#5eead4]/80'
          }`}>
            <span>{t('footer.est')}</span>
            <Lock size={12} className={isMesopotamian ? 'text-amber-400' : 'text-[#5eead4]'} />
          </div>
        </div>
      </div>
    </footer>
  );
}

