import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, 
  ChevronRight, 
  ChevronLeft, 
  Clock, 
  BookOpen, 
  List, 
  X,
  Compass,
  ArrowLeft
} from 'lucide-react';
import { HandbookBook, HandbookChapter } from '../../types/handbook';
import { useLanguage } from '../../context/LanguageContext';

interface ReadingProgressBarProps {
  book: HandbookBook;
  activeChapterId: string;
  onSelectChapter: (chapterId: string) => void;
  onBackToLibrary: () => void;
  readingProgress: number; // 0 to 100
}

export const ReadingProgressBar: React.FC<ReadingProgressBarProps> = ({
  book,
  activeChapterId,
  onSelectChapter,
  onBackToLibrary,
  readingProgress
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const [scrollPercent, setScrollPercent] = useState<number>(0);
  const [isMobileTocOpen, setIsMobileTocOpen] = useState<boolean>(false);

  // Active chapter index and details
  const activeChapterIndex = book.chapters.findIndex((c) => c.id === activeChapterId);
  const currentChapter = activeChapterIndex >= 0 ? book.chapters[activeChapterIndex] : null;
  const isAllChapters = activeChapterId === 'all';

  // Listen to window scroll to calculate reading depth
  useEffect(() => {
    let ticking = false;
    let rafId: number | null = null;

    const handleScroll = () => {
      if (!ticking) {
        rafId = window.requestAnimationFrame(() => {
          const scrollTop = window.scrollY;
          const docHeight = document.documentElement.scrollHeight - window.innerHeight;
          if (docHeight > 0) {
            const pct = Math.min(100, Math.max(0, Math.round((scrollTop / docHeight) * 100)));
            setScrollPercent((prev) => (prev === pct ? prev : pct));
          } else {
            setScrollPercent((prev) => (prev === 100 ? prev : 100));
          }
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (rafId) window.cancelAnimationFrame(rafId);
    };
  }, [activeChapterId]);

  // Overall effective progress: blend of chapter completion and scroll depth
  const effectiveProgress = isAllChapters 
    ? scrollPercent 
    : Math.round(((activeChapterIndex + (scrollPercent / 100)) / book.chapters.length) * 100);

  return (
    <>
      {/* ──────────────────────────────────────────────
          TOP STICKY PROGRESS CONTAINER
      ────────────────────────────────────────────── */}
      <div className="sticky top-16 z-40 -mx-4 sm:-mx-6 lg:-mx-8 bg-slate-950/95 backdrop-blur-xl border-b border-slate-800 shadow-md">
        {/* Continuous dynamic scroll fill line */}
        <div className="relative h-[3px] w-full bg-slate-900 overflow-hidden">
          <motion.div
            className="absolute top-0 bottom-0 start-0 bg-gradient-to-r from-cyan-500 via-teal-400 to-indigo-500 transition-all duration-150 ease-out"
            style={{ width: `${effectiveProgress}%` }}
          />
          {/* Subtle glow point at current position */}
          <div 
            className="absolute top-0 bottom-0 w-8 bg-white/40 blur-[2px] transition-all duration-150"
            style={{ 
              left: isAr ? undefined : `calc(${effectiveProgress}% - 16px)`,
              right: isAr ? `calc(${effectiveProgress}% - 16px)` : undefined
            }}
          />
        </div>

        {/* Action & Metadata Bar */}
        <div className="px-4 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between gap-3">
          {/* Left: Back & Book Identity */}
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              onClick={onBackToLibrary}
              title={isAr ? 'العودة للمكتبة' : 'Back to Library'}
              className="p-1.5 sm:px-2.5 sm:py-1 rounded-xl bg-slate-900/80 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all shrink-0 group"
            >
              <ArrowLeft size={14} className="rtl:rotate-180 group-hover:-translate-x-0.5 rtl:group-hover:translate-x-0.5 transition-transform" />
              <span className="hidden sm:inline">{isAr ? 'المكتبة' : 'Library'}</span>
            </button>

            <div className="h-4 w-[1px] bg-slate-800 hidden sm:block shrink-0" />

            <div className="flex items-center gap-2 truncate">
              <span className="px-2 py-0.5 rounded-md bg-cyan-500/10 border border-cyan-500/25 text-cyan-400 font-mono text-[11px] font-bold shrink-0">
                {book.bookNumber}
              </span>
              <span className="text-xs font-bold text-white truncate hidden md:inline font-sans">
                {isAr ? book.titleAr : book.titleEn}
              </span>
              <span className="text-slate-600 hidden md:inline">•</span>
              <span className="text-xs text-slate-300 font-medium truncate">
                {isAllChapters 
                  ? (isAr ? 'كامل المجلد' : 'Full Volume') 
                  : (currentChapter ? (isAr ? currentChapter.titleAr : currentChapter.titleEn) : '')}
              </span>
            </div>
          </div>

          {/* Center: Desktop Segmented Chapter Stepper */}
          <div className="hidden lg:flex items-center gap-1 flex-1 max-w-xl mx-4">
            <button
              onClick={() => onSelectChapter('all')}
              title={isAr ? 'عرض كامل المجلد' : 'View Full Volume'}
              className={`px-2 py-1 rounded-lg text-[10px] font-mono transition-all shrink-0 ${
                isAllChapters
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                  : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 border border-slate-800/80'
              }`}
            >
              {isAr ? 'الكل' : 'ALL'}
            </button>

            {/* Chapter Segments */}
            <div className="grid grid-flow-col auto-cols-fr gap-1 flex-1">
              {book.chapters.map((ch, idx) => {
                const isActive = activeChapterId === ch.id;
                const isPassed = !isAllChapters && activeChapterIndex > idx;
                
                return (
                  <button
                    key={ch.id}
                    onClick={() => onSelectChapter(ch.id)}
                    className={`relative group p-1 rounded-lg text-start transition-all border ${
                      isActive
                        ? 'bg-cyan-500/15 border-cyan-500/50 shadow-sm'
                        : isPassed
                        ? 'bg-slate-900/90 border-teal-500/30 text-teal-300'
                        : 'bg-slate-900/50 border-slate-800/70 hover:border-slate-700 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span className="font-mono text-[10px] font-bold text-cyan-400">
                        {ch.chapterNumber}
                      </span>
                      {isPassed ? (
                        <CheckCircle2 size={11} className="text-teal-400 shrink-0" />
                      ) : (
                        <span className="text-[9px] font-mono text-slate-500">
                          {ch.readingTimeMinutes}m
                        </span>
                      )}
                    </div>
                    
                    {/* Active pulsing bottom indicator */}
                    {isActive && (
                      <div className="absolute -bottom-[2px] inset-x-1 h-[2px] bg-cyan-400 rounded-full" />
                    )}

                    {/* Desktop Tooltip */}
                    <div className="absolute bottom-full mb-2 start-1/2 -translate-x-1/2 rtl:translate-x-1/2 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-200 z-50 whitespace-nowrap px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 text-white text-[11px] shadow-xl">
                      <span className="font-mono text-cyan-400 font-bold me-1">{ch.chapterNumber}.</span>
                      {isAr ? ch.titleAr : ch.titleEn}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right: Progress Meter & Mobile TOC Trigger */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Percentage Badge */}
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-900/90 border border-slate-800 font-mono text-xs text-slate-300">
              <span className="text-cyan-400 font-bold">{effectiveProgress}%</span>
              <span className="text-[10px] text-slate-500 hidden sm:inline">
                {isAr ? 'مكتمل' : 'Read'}
              </span>
            </div>

            {/* Mobile TOC Drawer Button */}
            <button
              onClick={() => setIsMobileTocOpen(true)}
              className="lg:hidden px-2.5 py-1 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center gap-1.5 transition-all"
            >
              <List size={14} />
              <span>{isAr ? 'الفصول' : 'Chapters'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* ──────────────────────────────────────────────
          MOBILE CHAPTERS BOTTOM SHEET / MODAL
      ────────────────────────────────────────────── */}
      <AnimatePresence>
        {isMobileTocOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex flex-col justify-end bg-black/70 backdrop-blur-sm">
            {/* Backdrop click */}
            <div 
              className="flex-1" 
              onClick={() => setIsMobileTocOpen(false)} 
            />

            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 280 }}
              className="w-full bg-slate-950 border-t border-slate-800 rounded-t-3xl p-5 space-y-4 max-h-[80vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <BookOpen size={16} className="text-cyan-400" />
                  <h3 className="text-sm font-bold text-white font-display">
                    {book.bookNumber} — {isAr ? book.titleAr : book.titleEn}
                  </h3>
                </div>
                <button
                  onClick={() => setIsMobileTocOpen(false)}
                  className="p-1 rounded-lg bg-slate-900 text-slate-400 hover:text-white"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="space-y-2">
                <button
                  onClick={() => {
                    onSelectChapter('all');
                    setIsMobileTocOpen(false);
                  }}
                  className={`w-full p-3 rounded-2xl text-start text-xs font-bold transition-all flex items-center justify-between ${
                    isAllChapters
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                      : 'bg-slate-900/60 text-slate-300 border border-slate-800'
                  }`}
                >
                  <span>{isAr ? 'قراءة كافة الفصول (كامل المجلد)' : 'Read Full Volume (All Chapters)'}</span>
                  <BookOpen size={14} className="text-slate-500" />
                </button>

                {book.chapters.map((ch, idx) => {
                  const isActive = activeChapterId === ch.id;
                  const isPassed = !isAllChapters && activeChapterIndex > idx;

                  return (
                    <button
                      key={ch.id}
                      onClick={() => {
                        onSelectChapter(ch.id);
                        setIsMobileTocOpen(false);
                      }}
                      className={`w-full p-3.5 rounded-2xl text-start transition-all flex items-center justify-between gap-3 ${
                        isActive
                          ? 'bg-cyan-500/20 border border-cyan-500/50 text-white'
                          : 'bg-slate-900/60 border border-slate-800/80 text-slate-300 hover:bg-slate-900'
                      }`}
                    >
                      <div className="space-y-0.5 truncate">
                        <div className="flex items-center gap-2 text-xs font-semibold">
                          <span className="font-mono text-cyan-400 font-bold">{ch.chapterNumber}</span>
                          <span className="truncate">{isAr ? ch.titleAr : ch.titleEn}</span>
                        </div>
                        {ch.subtitleEn && (
                          <div className="text-[11px] text-slate-400 truncate ps-6">
                            {isAr ? ch.subtitleAr : ch.subtitleEn}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0 text-xs font-mono text-slate-500">
                        {isPassed && <CheckCircle2 size={13} className="text-teal-400" />}
                        <span>{ch.readingTimeMinutes}m</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
