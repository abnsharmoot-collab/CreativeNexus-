import React from 'react';
import {
  Layers,
  ShieldCheck,
  Award,
  ScrollText,
  Trophy,
  Crown,
  BookOpen,
  Users,
  Star,
  Key,
  Shield,
  Zap,
  Scale,
  Sparkles,
  Lock,
  UserCheck,
  AlertTriangle,
  CheckCircle2,
  FileText,
  Clock,
  Compass,
  User,
  TrendingUp,
  ClipboardList,
  Bell,
  Megaphone,
  Archive,
  History,
  BookMarked
} from 'lucide-react';

interface HandbookIconProps {
  name: string;
  className?: string;
  size?: number;
}

export const HandbookIcon: React.FC<HandbookIconProps> = ({ name, className = '', size = 20 }) => {
  switch (name) {
    case 'Compass':
      return <Compass size={size} className={className} />;
    case 'User':
      return <User size={size} className={className} />;
    case 'TrendingUp':
      return <TrendingUp size={size} className={className} />;
    case 'ClipboardList':
      return <ClipboardList size={size} className={className} />;
    case 'Bell':
      return <Bell size={size} className={className} />;
    case 'Megaphone':
      return <Megaphone size={size} className={className} />;
    case 'Archive':
      return <Archive size={size} className={className} />;
    case 'History':
      return <History size={size} className={className} />;
    case 'BookMarked':
      return <BookMarked size={size} className={className} />;
    case 'Layers':
      return <Layers size={size} className={className} />;
    case 'ShieldCheck':
      return <ShieldCheck size={size} className={className} />;
    case 'Award':
      return <Award size={size} className={className} />;
    case 'ScrollText':
      return <ScrollText size={size} className={className} />;
    case 'Trophy':
      return <Trophy size={size} className={className} />;
    case 'Crown':
      return <Crown size={size} className={className} />;
    case 'Users':
      return <Users size={size} className={className} />;
    case 'Star':
      return <Star size={size} className={className} />;
    case 'Key':
      return <Key size={size} className={className} />;
    case 'Shield':
      return <Shield size={size} className={className} />;
    case 'Zap':
      return <Zap size={size} className={className} />;
    case 'Scale':
      return <Scale size={size} className={className} />;
    case 'Sparkles':
      return <Sparkles size={size} className={className} />;
    case 'Lock':
      return <Lock size={size} className={className} />;
    case 'UserCheck':
      return <UserCheck size={size} className={className} />;
    case 'AlertTriangle':
      return <AlertTriangle size={size} className={className} />;
    case 'CheckCircle2':
      return <CheckCircle2 size={size} className={className} />;
    case 'Clock':
      return <Clock size={size} className={className} />;
    case 'FileText':
      return <FileText size={size} className={className} />;
    default:
      return <BookOpen size={size} className={className} />;
  }
};
