import React from 'react';
import { 
  Bell, 
  CheckCheck, 
  ShieldCheck, 
  Award, 
  Megaphone, 
  ArrowRight,
  Sparkles,
  Inbox
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../../context/LanguageContext';

interface ChapterProps {
  activeChapterId: string;
}

export const GuideNotificationsContent: React.FC<ChapterProps> = ({ activeChapterId }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  return (
    <div className="space-y-10">
      {/* ──────────────────────────────────────────────
          CHAPTER 1: NOTIFICATION HUB & ACTIONS
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-notif-center' || activeChapterId === 'ch-notif-unread') && (
        <section id="ch-notif-center" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-sky-500/10 border border-sky-500/30 text-sky-400 font-mono text-xs font-bold">
              01
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'مركز الإشعارات وشارة التنبيه' : 'Notification Hub & Unread Badges'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/80 border border-sky-500/25 space-y-5 text-slate-300 text-sm leading-relaxed">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-2xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400 shrink-0 mt-0.5">
                <Bell size={20} />
              </div>
              <div className="space-y-1">
                <h3 className="text-base sm:text-lg font-bold text-white">
                  {isAr ? 'تنبيهات فورية لكل ما يخص حسابك' : 'Real-time Account Alerts & Dispatches'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300">
                  {isAr
                    ? 'أيقونة الجرس في الشريط العلوي تظهر لك عداداً لحظياً بالتنبيهات الجديدة، وتتيح لك معاينة أحدث الإشعارات أو فتح صفحة التنبيهات الكاملة.'
                    : 'The bell icon in the top navbar provides live unread counters, quick dropdown previews, and a dedicated inbox page.'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="text-xs font-mono font-bold text-sky-400">
                  {isAr ? 'عداد غير المقروء' : 'Unread Counter'}
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'دائرة حمراء بارزة توضح عدد التنبيهات الجديدة.' : 'Displays your exact number of pending new alerts.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="text-xs font-mono font-bold text-emerald-400">
                  {isAr ? 'قراءة الإشعار' : 'Read on Click'}
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'النقر على أي تنبيه يزيل شارة غير المقروء عنه.' : 'Clicking an alert clears its unread highlight.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="text-xs font-mono font-bold text-purple-400">
                  {isAr ? 'تحديد الكل كمقروء' : 'Mark All as Read'}
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'زر مباشر لتصفير عداد التنبيهات بنقرة واحدة.' : 'Bulk button to clear all pending unread indicators.'}
                </p>
              </div>
            </div>

            <div className="pt-1">
              <Link
                to="/notifications"
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/30 text-sky-300 text-xs font-semibold transition-colors"
              >
                <span>{isAr ? 'فتح صفحة الإشعارات' : 'Open Notification Inbox'}</span>
                <ArrowRight size={13} className="rtl:rotate-180" />
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 2: NOTIFICATION TYPES & DISPATCHES
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-notif-events') && (
        <section id="ch-notif-events" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-sky-500/10 border border-sky-500/30 text-sky-400 font-mono text-xs font-bold">
              02
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'أنواع التنبيهات الصادرة' : 'Notification Types & Dispatches'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/80 border border-slate-800 space-y-4 text-slate-300 text-sm leading-relaxed">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-3">
                <ShieldCheck size={18} className="text-emerald-400 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-300 space-y-0.5">
                  <strong className="text-white block font-bold">{isAr ? 'قرارات الترقية والطلبات' : 'Rank Decision Alerts'}</strong>
                  <p className="text-slate-400">{isAr ? 'تنبيه فوري عند مراجعة واعتماد المالك Edgar لطلب ترقيتك.' : 'Instant notification when Edgar reviews your promotion request.'}</p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
                <Award size={18} className="text-amber-400 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-300 space-y-0.5">
                  <strong className="text-white block font-bold">{isAr ? 'تحديثات النقاط المعتمدة' : 'Merit Point Updates'}</strong>
                  <p className="text-slate-400">{isAr ? 'إشعار فوري عند منحك نقاط استحقاق لمساندة البث أو التميز الإداري.' : 'Sent whenever operational merit points are awarded.'}</p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-start gap-3">
                <Sparkles size={18} className="text-purple-400 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-300 space-y-0.5">
                  <strong className="text-white block font-bold">{isAr ? 'فتح أوسمة جديدة' : 'Achievement Unlocks'}</strong>
                  <p className="text-slate-400">{isAr ? 'تنبيه احتفالي يوضح اسم الوسام الجديد ونقاط الندرة المكتسبة.' : 'Celebrates new badges earned with their rarity points.'}</p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-start gap-3">
                <Megaphone size={18} className="text-rose-400 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-300 space-y-0.5">
                  <strong className="text-white block font-bold">{isAr ? 'الإعلانات الإدارية العامة' : 'Official Broadcasts'}</strong>
                  <p className="text-slate-400">{isAr ? 'تنبيهات فورية بأهم مواعيد البث والفعاليات المنشورة في الإعلانات.' : 'Alerts for high-priority stream marathons and events.'}</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
