import React from 'react';
import { 
  Compass, 
  LogIn, 
  Layers, 
  ShieldCheck, 
  Users, 
  ArrowRight, 
  Sparkles,
  ExternalLink,
  CheckCircle2,
  Lock,
  Globe,
  Radio
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../../context/LanguageContext';
import { useAuth } from '../../../context/AuthContext';

interface ChapterProps {
  activeChapterId: string;
}

export const GuideGettingStartedContent: React.FC<ChapterProps> = ({ activeChapterId }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { isAuthenticated, user, login } = useAuth();

  return (
    <div className="space-y-10">
      {/* ──────────────────────────────────────────────
          CHAPTER 1: WELCOME & OVERVIEW
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-gs-welcome' || activeChapterId === 'ch-gs-what-is') && (
        <section id="ch-gs-welcome" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-mono text-xs font-bold">
              01
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'مرحباً بك في CREATINE NEXUS' : 'Welcome to CREATINE NEXUS'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/80 border border-cyan-500/25 space-y-5 text-slate-300 text-sm leading-relaxed">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 mt-0.5">
                <Compass size={20} />
              </div>
              <div className="space-y-1">
                <h3 className="text-base sm:text-lg font-bold text-white">
                  {isAr ? 'المنصة الرقمية الموحدة لمجتمع Edgar' : 'The Unified Hub for Edgar’s Community'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300">
                  {isAr
                    ? 'منصة رسمية تجمع مواعيد البثوث المباشرة، الأوسمة التفاعلية، ورتب الطاقم الإداري بمراجعة واعتماد المالك Edgar.'
                    : 'The official platform bringing together live stream schedules, 40 unlockable badges, and a merit-based 34-tier rank system directly reviewed by Edgar.'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs uppercase font-mono">
                  <Radio size={14} />
                  <span>{isAr ? 'البثوث والإعلانات' : 'Streams & News'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'متابعة مواعيد البث المباشر والإعلانات الرسمية.' : 'Live stream schedules and verified community announcements.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-purple-400 font-bold text-xs uppercase font-mono">
                  <Sparkles size={14} />
                  <span>{isAr ? '40 وساماً تذكارياً' : '40 Badges'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'أوسمة تُمنح تقديراً لنشاطك وتفاعلك في السيرفر.' : 'Earn milestone badges tracked by your activity.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase font-mono">
                  <ShieldCheck size={14} />
                  <span>{isAr ? '34 رتبة إدارية' : '34 Rank Tiers'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'نظام ترقيات ونقاط بمراجعة واعتماد المالك.' : 'Staff merit progression with direct Sovereign approval.'}
                </p>
              </div>
            </div>

            {/* Access tiers summary */}
            <div className="space-y-2 pt-1">
              <h4 className="font-bold text-white text-xs uppercase font-mono tracking-wider">
                {isAr ? 'مستويات الوصول والصلاحيات:' : 'Platform Access Levels:'}
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800">
                  <span className="text-slate-400 block font-mono text-[10px]">TIER 1</span>
                  <strong className="text-white text-xs">{isAr ? 'الزوار' : 'Visitors'}</strong>
                  <p className="text-[11px] text-slate-400 mt-0.5">{isAr ? 'تصفح الإعلانات والدليل والتاريخ' : 'Public news & guides'}</p>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-blue-500/30">
                  <span className="text-blue-400 block font-mono text-[10px]">TIER 2</span>
                  <strong className="text-white text-xs">{isAr ? 'الأعضاء' : 'Members'}</strong>
                  <p className="text-[11px] text-slate-400 mt-0.5">{isAr ? 'الملف الشخصي، الأوسمة، الإشعارات' : 'Profile, badges, alerts'}</p>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-emerald-500/30">
                  <span className="text-emerald-400 block font-mono text-[10px]">TIER 3</span>
                  <strong className="text-white text-xs">{isAr ? 'الإداريون' : 'Staff'}</strong>
                  <p className="text-[11px] text-slate-400 mt-0.5">{isAr ? 'طلبات الترقية، دليل الإدارة، القوائم' : 'Rank requests & handbook'}</p>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900/60 border border-amber-500/30">
                  <span className="text-amber-400 block font-mono text-[10px]">TIER 4</span>
                  <strong className="text-white text-xs">{isAr ? 'المالك والقيادة' : 'Admins & Edgar'}</strong>
                  <p className="text-[11px] text-slate-400 mt-0.5">{isAr ? 'اعتماد الرتب، ضبط النقاط، السجلات' : 'Approvals & audit log'}</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 2: SIGN-IN WITH DISCORD
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-gs-login' || activeChapterId === 'ch-gs-signin') && (
        <section id="ch-gs-login" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-mono text-xs font-bold">
              02
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'تسجيل الدخول عبر ديسكورد' : 'Discord Sign-in & Authentication'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/80 border border-slate-800 space-y-5 text-slate-300 text-sm leading-relaxed">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/25">
              <div className="space-y-0.5">
                <div className="text-xs font-mono font-bold text-indigo-400 uppercase">
                  DISCORD OAUTH2 SINGLE SIGN-ON
                </div>
                <div className="text-sm font-bold text-white">
                  {isAr ? 'دخول فوري وآمن بنقرة واحدة' : 'One-Click Fast & Secure Sign-in'}
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'لا حاجة لكلمات مرور جديدة — استخدام مباشر لحساب ديسكورد الخاص بك.' : 'No passwords needed — authenticate directly with your Discord account.'}
                </p>
              </div>

              {!isAuthenticated ? (
                <button
                  onClick={login}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-colors shrink-0 flex items-center gap-2"
                >
                  <LogIn size={14} />
                  <span>{isAr ? 'تسجيل الدخول الآن' : 'Sign in Now'}</span>
                </button>
              ) : (
                <div className="px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-mono text-xs flex items-center gap-1.5 shrink-0">
                  <CheckCircle2 size={13} />
                  <span>{isAr ? 'أنت مسجل الدخول' : 'Signed In'}</span>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <h4 className="font-bold text-white text-xs uppercase font-mono tracking-wider">
                {isAr ? 'خطوات الدخول السريعة:' : '3 Quick Steps:'}
              </h4>
              <ol className="space-y-1.5 text-xs text-slate-300 list-decimal list-inside">
                <li><strong className="text-white">{isAr ? 'انقر على زر الدخول: ' : 'Click Sign In: '}</strong>{isAr ? 'في الشريط العلوي للموقع.' : 'In the top navbar.'}</li>
                <li><strong className="text-white">{isAr ? 'تأكيد الصلاحية: ' : 'Authorize on Discord: '}</strong>{isAr ? 'نافذة آمنة للتحقق من هويتك ورتبتك.' : 'Discord confirms your username, avatar, and roles.'}</li>
                <li><strong className="text-white">{isAr ? 'المزامنة الفورية: ' : 'Instant Guild Sync: '}</strong>{isAr ? 'تفعيل ملفك الشخصي وأوسمتك ونقاطك فورياً.' : 'Your profile, badges, and permissions activate immediately.'}</li>
              </ol>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 3: NAVIGATION & KEY PORTALS
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-gs-navigation' || activeChapterId === 'ch-gs-access') && (
        <section id="ch-gs-navigation" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-mono text-xs font-bold">
              03
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'التنقل وأقسام الموقع الرئيسية' : 'Navigation & Key Portals'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/80 border border-slate-800 space-y-4 text-slate-300 text-sm leading-relaxed">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div className="p-3.5 rounded-2xl bg-slate-900/50 border border-slate-800 space-y-1">
                <h4 className="font-bold text-white text-xs flex items-center gap-2">
                  <span className="w-5 h-5 rounded-md bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-mono text-[10px]">1</span>
                  {isAr ? 'الشريط العلوي (Navbar)' : 'Top Navigation Bar'}
                </h4>
                <p className="text-xs text-slate-400">
                  {isAr ? 'وصول فوري للرئيسية، الإعلانات، التاريخ، الدليل، الإشعارات، والدخول.' : 'Instant access to Home, News, History, Guidebook, Notifications, and Profile.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/50 border border-slate-800 space-y-1">
                <h4 className="font-bold text-white text-xs flex items-center gap-2">
                  <span className="w-5 h-5 rounded-md bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-mono text-[10px]">2</span>
                  {isAr ? 'محول اللغة (EN / AR)' : 'Bilingual Toggle'}
                </h4>
                <p className="text-xs text-slate-400">
                  {isAr ? 'تبديل فوري بنقرة واحدة بين العربية والإنجليزية مع دعم كامل لاتجاه RTL.' : 'One-click toggle between English and Arabic with full native RTL alignment.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/50 border border-slate-800 space-y-1">
                <h4 className="font-bold text-white text-xs flex items-center gap-2">
                  <span className="w-5 h-5 rounded-md bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-mono text-[10px]">3</span>
                  {isAr ? 'مركز الإشعارات' : 'Notification Bell'}
                </h4>
                <p className="text-xs text-slate-400">
                  {isAr ? 'ينبهك فور اعتماد ترقيتك، منحك نقاط استحقاق، أو نشر إعلان جديد.' : 'Real-time alerts when promotions are reviewed or points are awarded.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/50 border border-slate-800 space-y-1">
                <h4 className="font-bold text-white text-xs flex items-center gap-2">
                  <span className="w-5 h-5 rounded-md bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-mono text-[10px]">4</span>
                  {isAr ? 'القائمة الجانبية للجوال' : 'Mobile Drawer'}
                </h4>
                <p className="text-xs text-slate-400">
                  {isAr ? 'على الهواتف، تنفتح قائمة جانبية مريحة للمس تضم كافة الروابط.' : 'On mobile, a smooth slide-out drawer houses all sections with 44px touch targets.'}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
