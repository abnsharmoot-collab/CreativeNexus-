import React from 'react';
import { Crown, Scale, Shield, Users, Sparkles, Heart, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '../../../context/LanguageContext';

interface ChapterProps {
  activeChapterId: string;
}

export const BookServerStructureContent: React.FC<ChapterProps> = ({ activeChapterId }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  return (
    <div className="space-y-10">
      {/* ──────────────────────────────────────────────
          CHAPTER 1: ABOUT CREATINE NEXUS
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-intro') && (
        <section id="ch-intro" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-mono text-xs font-bold">
              01
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'عن السيرفر والمجتمع' : 'About CREATINE NEXUS'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/70 border border-slate-800 space-y-4 leading-relaxed text-sm sm:text-base text-slate-300">
            <p>
              {isAr
                ? 'سيرفر CREATINE NEXUS هو المجتمع الرسمي للفنان وصانع المحتوى Edgar. أُسس هذا المكان ليكون بيئة ودية وممتعة تجمع المتابعين وعشاق الرسم والألعاب، ومساحة تفاعلية لمتابعة البثوث المباشرة والأنشطة المشتركة.'
                : 'CREATINE NEXUS is the official community sanctuary for artist and streamer Edgar. Created to bring together fans, artists, and gamers in a friendly and welcoming environment for live streams, creative discussions, and community events.'}
            </p>
            <p>
              {isAr
                ? 'الهدف هنا بسيط: توفير بيئة مريحة ومرتبة للجميع. القوانين والتنظيمات موجودة فقط لحفظ الاحترام المتبادل وسلامة الأعضاء، ليبقى المجتمع مكاناً إيجابياً يستمتع فيه الجميع.'
                : 'The goal is simple: provide a fun, fair, and organized home for everyone. Rules and moderation exist solely to protect mutual respect and keep the environment positive for all members.'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800/80 space-y-1">
                <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs">
                  <Heart size={14} />
                  <span>{isAr ? 'بيئة ودية' : 'Friendly Atmosphere'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'ترحيب بالجميع واحترام متبادل بين كافة الأعضاء دون تمييز.' : 'Warm welcome and mutual respect for everyone without exception.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800/80 space-y-1">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                  <Sparkles size={14} />
                  <span>{isAr ? 'إبداع وبثوث' : 'Art & Streams'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'مشاركة الرسومات والمواهب ومتابعة بثوث إدغار المباشرة.' : 'Art sharing, creative talks, and live broadcast interactions.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800/80 space-y-1">
                <div className="flex items-center gap-2 text-purple-400 font-bold text-xs">
                  <Shield size={14} />
                  <span>{isAr ? 'أمان ونظام' : 'Safety & Order'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'حماية من الإزعاج والسبام والروابط المشبوهة لراحة الجميع.' : 'Protection against spam, toxicity, and harmful links.'}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 2: SERVER STRUCTURE & LEADERSHIP
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-hierarchy') && (
        <section id="ch-hierarchy" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-mono text-xs font-bold">
              02
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'الهيكل التنظيمي والقيادة' : 'Server Structure & Leadership'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/70 border border-slate-800 space-y-5">
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              {isAr
                ? 'يعمل السيرفر بنظام بسيط ومباشر يضمن سرعة مساعدة الأعضاء والتواصل السلس بين القيادة والطاقم الإداري:'
                : 'The server operates with a straightforward structure to ensure prompt assistance for members and clear teamwork between leadership and staff:'}
            </p>

            <div className="space-y-3">
              {/* Level 1: Owner Edgar */}
              <div className="p-4 sm:p-5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300 shrink-0">
                    <Crown size={20} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-amber-400 uppercase">TIER 1</span>
                      <h4 className="text-sm font-bold text-white">
                        {isAr ? 'مالك السيرفر ومؤسس المجتمع (Edgar)' : 'Server Owner & Community Founder (Edgar)'}
                      </h4>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {isAr ? 'صاحب الرؤية والمشرف العام على السيرفر، والمسؤول عن اعتماد الترقيات والقرارات الكبرى.' : 'Founder and general overseer, responsible for major server decisions and promotion approvals.'}
                    </p>
                  </div>
                </div>
                <span className="px-3 py-1 rounded-full text-[11px] font-mono font-semibold bg-amber-400/15 text-amber-200 border border-amber-400/30 shrink-0">
                  Owner
                </span>
              </div>

              {/* Level 2: Leadership Council */}
              <div className="p-4 sm:p-5 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-300 shrink-0">
                    <Scale size={20} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-purple-400 uppercase">TIER 2</span>
                      <h4 className="text-sm font-bold text-white">
                        {isAr ? 'مجلس القيادة العليا (High Council & Management)' : 'High Council & Senior Management'}
                      </h4>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {isAr ? 'إدارة السيرفر العليا المعاونة للمالك في التوجيه والتطوير ومتابعة الطاقم الإداري.' : 'Senior leadership assisting the owner with server management, staff oversight, and events.'}
                    </p>
                  </div>
                </div>
                <span className="px-3 py-1 rounded-full text-[11px] font-mono font-semibold bg-purple-500/15 text-purple-200 border border-purple-500/30 shrink-0">
                  Leadership
                </span>
              </div>

              {/* Level 3: Staff & Moderators */}
              <div className="p-4 sm:p-5 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300 shrink-0">
                    <Shield size={20} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-cyan-400 uppercase">TIER 3</span>
                      <h4 className="text-sm font-bold text-white">
                        {isAr ? 'طاقم الإشراف والمودريتورز (Staff Team)' : 'Moderators & Active Staff'}
                      </h4>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {isAr ? 'مساعدة الأعضاء، الحفاظ على هدوء الدردشة، ومساندة الستريمر Edgar أثناء البثوث المباشرة.' : 'Welcoming members, keeping chats respectful, and moderating during live streams.'}
                    </p>
                  </div>
                </div>
                <span className="px-3 py-1 rounded-full text-[11px] font-mono font-semibold bg-cyan-500/15 text-cyan-200 border border-cyan-500/30 shrink-0">
                  Staff
                </span>
              </div>

              {/* Level 4: Members */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 shrink-0">
                    <Users size={20} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-slate-400 uppercase">TIER 4</span>
                      <h4 className="text-sm font-bold text-white">
                        {isAr ? 'أعضاء المجتمع (Community Members)' : 'Community Members'}
                      </h4>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {isAr ? 'قلب المجتمع من المتابعين والمبدعين والمشاركين في الفعاليات والأنشطة.' : 'The heart of our sanctuary: fans, artists, gamers, and viewers.'}
                    </p>
                  </div>
                </div>
                <span className="px-3 py-1 rounded-full text-[11px] font-mono font-semibold bg-slate-800 text-slate-300 border border-slate-700 shrink-0">
                  Community
                </span>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 3: CORE PRINCIPLES & SPACES
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-values') && (
        <section id="ch-values" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-mono text-xs font-bold">
              03
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'ركائز وقيم المجتمع' : 'Core Community Principles'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/70 border border-slate-800 space-y-5 text-sm sm:text-base text-slate-300">
            <p className="leading-relaxed">
              {isAr
                ? 'يقوم السيرفر على قواعد بديهية وبسيطة تضمن استمتاع الجميع دون أي تعقيد:'
                : 'Our community thrives on simple, sensible principles that ensure everyone has a great experience:'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs uppercase font-mono">
                  <CheckCircle2 size={16} />
                  <span>{isAr ? 'الاحترام واللباقة' : 'Respect & Courtesy'}</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {isAr
                    ? 'التعامل مع الآخرين بلطف واحترام، وتجنب الخلافات الشخصية والتجريح أو الإساءة لأي عضو.'
                    : 'Treating all members with kindness and patience, avoiding personal attacks or hostility.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase font-mono">
                  <CheckCircle2 size={16} />
                  <span>{isAr ? 'المشاركة الإيجابية' : 'Positive Engagement'}</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {isAr
                    ? 'مشاركة الرسومات والتفاعل أثناء البثوث المباشرة وإبداء الملاحظات بروح رياضية ومشجعة.'
                    : 'Sharing artwork, chatting during streams, and encouraging fellow creators.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-purple-400 font-bold text-xs uppercase font-mono">
                  <CheckCircle2 size={16} />
                  <span>{isAr ? 'أقسام السيرفر المنظمة' : 'Organized Spaces'}</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {isAr
                    ? 'قنوات مخصصة للرسم، وغرف لمتابعة البثوث، ومحادثات عامة ليبقى كل محتوى في مكانه المناسب.'
                    : 'Dedicated channels for art, streams, and general chat keep conversations focused and fun.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase font-mono">
                  <CheckCircle2 size={16} />
                  <span>{isAr ? 'الدعم والمساعدة المباشرة' : 'Direct Support'}</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {isAr
                    ? 'إذا واجهت أي مشكلة أو كان لديك استفسار، طاقم المشرفين جاهز دائماً عبر نظام التذاكر الرسمي.'
                    : 'Have an issue or question? Our staff team is always ready to assist via the official ticket system.'}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
