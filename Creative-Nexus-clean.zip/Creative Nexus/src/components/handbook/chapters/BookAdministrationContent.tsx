import React from 'react';
import { 
  Crown, 
  Settings, 
  ShieldCheck, 
  RefreshCw, 
  Users, 
  Lock, 
  FileText, 
  Database, 
  CheckCircle2, 
  AlertTriangle,
  ShieldAlert
} from 'lucide-react';
import { useLanguage } from '../../../context/LanguageContext';
import { useAuth } from '../../../context/AuthContext';

interface ChapterProps {
  activeChapterId: string;
}

export const BookAdministrationContent: React.FC<ChapterProps> = ({ activeChapterId }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { isStaff, isOwner, isAuthenticated } = useAuth();
  const isAuthorized = isStaff || isOwner;

  return (
    <div className="space-y-10">
      {/* ──────────────────────────────────────────────
          CHAPTER 1: OWNER SYSTEM & AUTHORITY
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-admin-owner') && (
        <section id="ch-admin-owner" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs font-bold">
              01
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'منظومة المالك وصلاحيات القيادة' : 'Owner Authority & Review Policy'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/80 border border-slate-800 space-y-5 text-sm text-slate-300 leading-relaxed">
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-300 shrink-0">
                  <Crown size={20} />
                </div>
                <div>
                  <div className="text-[11px] font-mono font-bold text-amber-400 uppercase">
                    PRIMARY OWNER
                  </div>
                  <h4 className="text-sm font-bold text-white">
                    Edgar
                  </h4>
                  <div className="text-[11px] text-slate-400 font-mono">
                    Snowflake: <span className="text-amber-300 font-bold select-all">871043296280076308</span>
                  </div>
                </div>
              </div>

              <span className="px-3 py-1 rounded-xl text-xs font-mono font-bold bg-amber-500/20 text-amber-200 border border-amber-500/30 shrink-0">
                Full Veto Authority
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <span className="text-xs font-mono font-bold text-cyan-400 uppercase block">
                  {isAr ? 'اعتماد الترقيات الإلزامي' : 'Mandatory Review'}
                </span>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'لا تصدر أي ترقية دون مصادقة المالك Edgar عبر لوحة طلبات الرتب.'
                    : 'No rank advancement is finalized without approval from Edgar in the review portal.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <span className="text-xs font-mono font-bold text-purple-400 uppercase block">
                  {isAr ? 'حق النقض النهائي' : 'Sovereign Veto'}
                </span>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'للمالك حق نقض أي قرار تنظيمي أو سحب رتب لضمان مصلحة المجتمع.'
                    : 'The owner reserves the authority to revert any moderation decision.'}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 2: DISCORD ROLES & RBAC
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-admin-roles') && (
        <section id="ch-admin-roles" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs font-bold">
              02
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'رتب ديسكورد والصلاحيات الإدارية' : 'Discord Roles & RBAC Configuration'}
            </h2>
          </div>

          {!isAuthorized ? (
            <div className="p-5 sm:p-6 rounded-3xl bg-slate-950/80 border border-slate-800">
              <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-start gap-3">
                <Lock size={16} className="text-emerald-400 shrink-0 mt-0.5" />
                <div className="space-y-0.5 text-xs">
                  <strong className="text-white block font-bold">
                    {isAr ? 'بيانات الرتب مقصورة على الطاقم الإداري' : 'Restricted to Verified Staff'}
                  </strong>
                  <p className="text-slate-400">
                    {isAr
                      ? 'تُحفظ معرفات رتب الإشراف في Firestore ومزامنة الجلسة متاحة لأعضاء الطاقم فقط.'
                      : 'Role mappings and server configuration endpoints are restricted to staff to maintain security.'}
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-5 sm:p-6 rounded-3xl bg-slate-950/80 border border-slate-800 space-y-4 text-xs text-slate-300">
              <div className="space-y-2 font-mono">
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-cyan-400" />
                    <span className="text-white font-bold">Primary Owner Role</span>
                  </div>
                  <span className="text-cyan-300 select-all font-semibold">1355959576679153744</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-purple-400" />
                    <span className="text-white font-bold">Sovereign Authority Role</span>
                  </div>
                  <span className="text-purple-300 select-all font-semibold">1357733742210453564</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                    <span className="text-white font-bold">Co-Owner Bridge Role</span>
                  </div>
                  <span className="text-amber-300 select-all font-semibold">1455871440254533706</span>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-start gap-2.5">
                <Settings size={16} className="text-emerald-400 shrink-0 mt-0.5" />
                <p className="text-slate-400">
                  {isAr
                    ? 'يستطيع المالك تعديل هذه المعرفات في أي وقت عبر لوحة الإعدادات دون الحاجة لإعادة نشر الكود.'
                    : 'The owner can update role IDs anytime via the settings tab without redeployment.'}
                </p>
              </div>
            </div>
          )}
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 3: STAFF OPERATIONS
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-admin-staff-management') && (
        <section id="ch-admin-staff-management" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs font-bold">
              03
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'إدارة الطاقم والعمليات' : 'Staff Operations & Management'}
            </h2>
          </div>

          <div className="p-5 sm:p-6 rounded-3xl bg-slate-950/80 border border-slate-800 space-y-4 text-xs text-slate-300">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-cyan-400 font-bold uppercase font-mono">
                  <Users size={14} />
                  <span>{isAr ? 'ضم إداري جديد' : 'Roster Induction'}</span>
                </div>
                <p className="text-slate-400">
                  {isAr ? 'إضافة عضو جديد لطاقم العمل وتعيين رتبته ورصيد نقاطه الأولي.' : 'Enrolling new staff into Firestore with initial rank and points.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-amber-400 font-bold uppercase font-mono">
                  <FileText size={14} />
                  <span>{isAr ? 'تسجيل الملاحظات' : 'Performance Notes'}</span>
                </div>
                <p className="text-slate-400">
                  {isAr ? 'تدوين تقييمات الأداء وسجلات التميز أو التنبيهات الإدارية.' : 'Logging performance evaluations and conduct remarks.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-purple-400 font-bold uppercase font-mono">
                  <Lock size={14} />
                  <span>{isAr ? 'تجميد الصلاحيات' : 'Temporary Suspension'}</span>
                </div>
                <p className="text-slate-400">
                  {isAr ? 'إيقاف النشاط مؤقتاً لحين انتهاء ظرف غياب أو تحقيق.' : 'Freezing permissions during absence or investigation.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-rose-400 font-bold uppercase font-mono">
                  <AlertTriangle size={14} />
                  <span>{isAr ? 'الاستبعاد من الطاقم' : 'Roster Removal'}</span>
                </div>
                <p className="text-slate-400">
                  {isAr ? 'سحب رتب الإشراف مع حفظ سجل التدقيق التاريخي للعمليات.' : 'Revoking staff standing while archiving audit history.'}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 4: DISCORD SYNC & AUDIT
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-admin-sync') && (
        <section id="ch-admin-sync" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs font-bold">
              04
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'المزامنة مع ديسكورد وسجل التدقيق' : 'Discord Sync & Audit Integrity'}
            </h2>
          </div>

          <div className="p-5 sm:p-6 rounded-3xl bg-slate-950/80 border border-slate-800 space-y-3 font-mono text-xs text-slate-300">
            <div className="flex items-center gap-2 text-cyan-400 font-bold uppercase">
              <Database size={15} />
              <span>{isAr ? 'ضمانات الأمان وحماية السجلات' : 'Audit Security Guarantees'}</span>
            </div>
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <CheckCircle2 size={14} className="text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Immutable Audit Log:</strong> {isAr ? 'كل تعديل في النقاط أو الرتب يوثق بسجل محمي لا يمكن تعديله أو حذفه.' : 'Every point adjustment and rank change is permanently logged.'}
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 size={14} className="text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Token Verification:</strong> {isAr ? 'التحقق الصارم من صحة جلسة ديسكورد المشفرة في كل عملية.' : 'Rigorous Discord OAuth2 session verification on all operations.'}
                </span>
              </li>
            </ul>
          </div>
        </section>
      )}
    </div>
  );
};
