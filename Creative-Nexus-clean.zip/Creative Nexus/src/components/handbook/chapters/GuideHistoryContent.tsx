import React from 'react';
import { 
  History, 
  Calendar, 
  Sparkles, 
  ArrowRight,
  Flame,
  Award,
  Video
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../../context/LanguageContext';

interface ChapterProps {
  activeChapterId: string;
}

export const GuideHistoryContent: React.FC<ChapterProps> = ({ activeChapterId }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  return (
    <div className="space-y-12">
      {/* ──────────────────────────────────────────────
          CHAPTER 1: SERVER ORIGINS
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-hist-origins') && (
        <section id="ch-hist-origins" className="scroll-mt-28 space-y-6">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 font-mono text-xs font-bold">
              01
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'نشأة السيرفر ومجتمع Edgar' : 'Server Origins & Edgar’s Community'}
            </h2>
          </div>

          <div className="p-6 sm:p-8 rounded-3xl bg-slate-950/80 border border-blue-500/25 space-y-6 text-slate-300 text-sm leading-relaxed">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0 mt-1">
                <History size={24} />
              </div>
              <div className="space-y-2">
                <h3 className="text-lg sm:text-xl font-bold text-white">
                  {isAr ? 'قصة تأسيس CREATINE NEXUS' : 'The Inception of CREATINE NEXUS'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300">
                  {isAr
                    ? 'بدأ سيرفر CREATINE NEXUS كمساحة جامعة لعشاق البثوث والألعاب ومحبي المحتوى الإبداعي للفنان والستريمر Edgar. منذ الأيام الأولى، ارتكز المجتمع على روح الأخوة، المرح اللامحدود، وتقديم بيئة نظيفة ومحترمة تحتضن المبدعين.'
                    : 'CREATINE NEXUS was founded as a vibrant community hub uniting gaming fans, stream watchers, and supporters of artist & creator Edgar. From its genesis, the guild has championed positive engagement, creative self-expression, and clean, respectful community banter.'}
                </p>
              </div>
            </div>

            <div className="pt-2">
              <Link
                to="/history"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-500/15 hover:bg-blue-500/25 border border-blue-500/30 text-blue-300 text-xs font-semibold transition-colors"
              >
                <span>{isAr ? 'استعراض خط التاريخ الزمني الكامل' : 'Explore Interactive Server Timeline'}</span>
                <ArrowRight size={14} className="rtl:rotate-180" />
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 2: HISTORICAL ERAS
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-hist-eras') && (
        <section id="ch-hist-eras" className="scroll-mt-28 space-y-6">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 font-mono text-xs font-bold">
              02
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'الحقب التاريخية ومحطات النمو' : 'Historical Eras & Major Milestones'}
            </h2>
          </div>

          <div className="p-6 sm:p-8 rounded-3xl bg-slate-950/80 border border-slate-800 space-y-6 text-slate-300 text-sm leading-relaxed">
            <p>
              {isAr
                ? 'مر السيرفر بأربع حقب تاريخية مميزة توثق تطوره من بدايات متواضعة إلى مجتمع متكامل:'
                : 'The community’s historical journey is chronicled through four landmark epochs:'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
                <span className="px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 text-[10px] font-mono font-bold">ERA 01</span>
                <h4 className="font-bold text-white text-sm">{isAr ? 'حقبة التأسيس والانطلاقة' : 'The Genesis Epoch'}</h4>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'إطلاق السيرفر، تجمع الأصدقاء الأوائل، ووضع القوانين الأساسية الأولى.'
                    : 'The launch of the server, gathering of initial core members, and drafting foundational rules.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
                <span className="px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 text-[10px] font-mono font-bold">ERA 02</span>
                <h4 className="font-bold text-white text-sm">{isAr ? 'عصر التوسع والفعاليات' : 'The Golden Expansion'}</h4>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'ازدهار البثوث المباشرة، تنظيم أولى بطولات الألعاب، واستقطاب آلاف المتابعين الجدد.'
                    : 'Expansion of live streaming marathons, first server gaming tournaments, and massive community influx.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
                <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 text-[10px] font-mono font-bold">ERA 03</span>
                <h4 className="font-bold text-white text-sm">{isAr ? 'مرحلة المأسسة والتنظيم الإداري' : 'Institutional Organization'}</h4>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'تأسيس نظام الرتب الـ 34، تدريب طاقم المشرفين، وبناء ميثاق السلوك والانضباط.'
                    : 'Establishment of the 34-tier rank map, formal staff training, and transparent disciplinary protocols.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
                <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 text-[10px] font-mono font-bold">ERA 04</span>
                <h4 className="font-bold text-white text-sm">{isAr ? 'عصر المنظومة الرقمية الحديثة' : 'The Modern Digital Sanctuary'}</h4>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'تدشين منصة الويب الموحدة، مصفوفة الأوسمة التفاعلية، ومركز الإشعارات اللحظي.'
                    : 'Launch of the unified web portal, live achievement matrix, and real-time operational notifications.'}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
