import React from 'react';
import { 
  Megaphone, 
  Pin, 
  BookOpen, 
  Image as ImageIcon, 
  Calendar, 
  UserCheck, 
  ArrowRight,
  Share2
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../../context/LanguageContext';

interface ChapterProps {
  activeChapterId: string;
}

export const GuideAnnouncementsContent: React.FC<ChapterProps> = ({ activeChapterId }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  return (
    <div className="space-y-10">
      {/* ──────────────────────────────────────────────
          CHAPTER 1: OFFICIAL ANNOUNCEMENTS & PINNED ALERTS
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-ann-official' || activeChapterId === 'ch-ann-pinned') && (
        <section id="ch-ann-official" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400 font-mono text-xs font-bold">
              01
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'الإعلانات الرسمية والتنبيهات المثبتة' : 'Official Broadcasts & Pinned Alerts'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/80 border border-rose-500/25 space-y-5 text-slate-300 text-sm leading-relaxed">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0 mt-0.5">
                <Megaphone size={20} />
              </div>
              <div className="space-y-1">
                <h3 className="text-base sm:text-lg font-bold text-white">
                  {isAr ? 'المصدر الموثق لأخبار السيرفر وبثوث Edgar' : 'Verified Community Broadcasts'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300">
                  {isAr
                    ? 'تصدر المنشورات حصرياً عن المالك Edgar أو القيادة العليا لتغطية مواعيد البث، التحديثات الإدارية، وإعلانات الفعاليات.'
                    : 'All articles are published exclusively by Edgar and approved server leadership, covering stream schedules and community dispatches.'}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
              <Pin size={18} className="text-amber-400 shrink-0 mt-0.5 rotate-45" />
              <div className="text-xs text-slate-300 space-y-0.5">
                <strong className="text-white block font-bold">
                  {isAr ? 'الإعلانات المثبتة (Pinned)' : 'Pinned Top Priority'}
                </strong>
                <p className="text-slate-400">
                  {isAr
                    ? 'الإعلانات الهامة مثل الفعاليات الكبرى تثبت في قمة القائمة بإطار كهرماني مميز لضمان رؤيتها فوراً.'
                    : 'Critical announcements are pinned to the top of the feed with an amber accent border and pin icon.'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-rose-400">
                  <UserCheck size={14} />
                  <span>{isAr ? 'شارة الناشر الموثق' : 'Verified Author'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'توضيح هوية الناشر ورتبته الإدارية.' : 'Displays the author’s avatar and leadership role.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-cyan-400">
                  <Calendar size={14} />
                  <span>{isAr ? 'التاريخ والوقت' : 'Timestamps'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'توثيق زمني دقيق لكل إعلان منشور.' : 'Chronological ordering with publication timestamps.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-amber-400">
                  <Share2 size={14} />
                  <span>{isAr ? 'مشاركة الإعلان' : 'Quick Sharing'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'نسخ رابط مباشر للمشاركة في قنوات ديسكورد.' : 'Copyable direct links for sharing in Discord.'}
                </p>
              </div>
            </div>

            <div className="pt-1">
              <Link
                to="/announcements"
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-xs font-semibold transition-colors"
              >
                <span>{isAr ? 'تصفح قسم الإعلانات' : 'Browse Announcements Feed'}</span>
                <ArrowRight size={13} className="rtl:rotate-180" />
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 2: READING ARTICLES & MEDIA
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-ann-reading') && (
        <section id="ch-ann-reading" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400 font-mono text-xs font-bold">
              02
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'قراءة المقالات وعرض الوسائط' : 'Reading Articles & Media Lightbox'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/80 border border-slate-800 space-y-4 text-slate-300 text-sm leading-relaxed">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-2 text-rose-400 font-bold text-xs font-mono uppercase">
                  <BookOpen size={16} />
                  <span>{isAr ? 'تنسيق المقالات' : 'Markdown Layout'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'عناوين وقوائم وروابط واضحة وسهلة القراءة على الهواتف والشاشات الكبيرة.'
                    : 'Clear headings, lists, and links designed for readability on both desktop and mobile.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs font-mono uppercase">
                  <ImageIcon size={16} />
                  <span>{isAr ? 'تكبير الصور (Lightbox)' : 'Media Lightbox'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'انقر على أي بوستر أو لقطة شاشة لتكبيرها واستعراضها بملء الشاشة بدقة كاملة.'
                    : 'Click any graphic or screenshot to zoom into full-screen view.'}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
