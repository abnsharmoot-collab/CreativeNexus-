import React, { useState } from 'react';
import { 
  Award, 
  ChevronRight, 
  Lock, 
  CheckCircle2, 
  ShieldAlert, 
  Crown, 
  ArrowRight, 
  Sparkles,
  Layers,
  ArrowUpRight,
  PlusCircle,
  MinusCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { RANK_SECTIONS, RANK_TIERS, RankSectionId } from '../../../types/rankMap';
import { useLanguage } from '../../../context/LanguageContext';

interface ChapterProps {
  activeChapterId: string;
}

export const BookRankProgressionContent: React.FC<ChapterProps> = ({ activeChapterId }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const [selectedSection, setSelectedSection] = useState<RankSectionId>('staff');

  const currentSectionData = RANK_SECTIONS.find((s) => s.id === selectedSection) || RANK_SECTIONS[0];
  const currentSectionTiers = RANK_TIERS.filter((t) => t.section === selectedSection);

  return (
    <div className="space-y-12">
      {/* ──────────────────────────────────────────────
          CHAPTER 1: STAFF POINTS & AWARDING CRITERIA
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-rnk-points' || activeChapterId === 'ch-points-ledger') && (
        <section id="ch-rnk-points" className="scroll-mt-28 space-y-6">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono text-xs font-bold">
              01
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'نقاط الاستحقاق الإداري وكيفية منحها' : 'Staff Points & Awarding Criteria'}
            </h2>
          </div>

          <div className="p-6 sm:p-8 rounded-3xl bg-slate-950/70 border border-slate-800 space-y-5 text-sm text-slate-300">
            <p className="leading-relaxed">
              {isAr
                ? 'النقاط هي المقياس الرقمي المعتمد لنشاط الطاقم الإداري وتُمنح أو تُخصم وفق ضوابط واضحة:'
                : 'Staff points represent the official measure of administrative contribution and are adjusted under transparent rules:'}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-emerald-400 uppercase">
                  <PlusCircle size={14} />
                  <span>{isAr ? 'منح النقاط (إضافة)' : 'Earning Points (+)'}</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {isAr
                    ? 'تُمنح النقاط تقديراً للمهام الإشرافية النشطة، مساندة بثوث Edgar المباشرة، وحل تذاكر الأعضاء.'
                    : 'Awarded for active chat moderation, assisting during Edgar’s live streams, and helping community members.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-rose-400 uppercase">
                  <MinusCircle size={14} />
                  <span>{isAr ? 'خصم النقاط (تأديبي)' : 'Deducting Points (-)'}</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {isAr
                    ? 'يُمنع الخصم العشوائي نهائياً؛ أي خصم يتطلب سبباً معلناً، ولا ينزل الرصيد تحت الصفر.'
                    : 'Arbitrary deductions are forbidden. Every penalty requires a recorded reason, and points never drop below zero.'}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 2: 4 SECTIONS & 34 TIERS MAP
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-rnk-map' || activeChapterId === 'ch-rank-overview' || activeChapterId === 'ch-sections-explorer') && (
        <section id="ch-rnk-map" className="scroll-mt-28 space-y-6">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <span className="px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono text-xs font-bold">
                02
              </span>
              <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
                {isAr ? 'الأقسام الأربعة وخريطة الرتب' : 'The 4 Sections & 34 Ranks'}
              </h2>
            </div>

            <Link
              to="/rank-points"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-xs font-semibold transition-all"
            >
              <span>{isAr ? 'الخريطة الكاملة' : 'Full Rank Map'}</span>
              <ArrowUpRight size={13} />
            </Link>
          </div>

          <div className="p-6 sm:p-8 rounded-3xl bg-slate-950/70 border border-slate-800 space-y-5">
            <p className="text-sm text-slate-300 leading-relaxed">
              {isAr
                ? 'تمتد مسيرة الإدارة عبر 34 رتبة موزعة على أربعة أقسام متتالية تبدأ من 0 وحتى 280+ نقطة:'
                : 'Progression spans 34 calibrated tiers organized across four sequential sections from 0 to 280+ PTS:'}
            </p>

            {/* Quick 4-section selector */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
              {RANK_SECTIONS.map((sec, idx) => (
                <button
                  key={sec.id}
                  onClick={() => setSelectedSection(sec.id)}
                  className={`p-3 rounded-xl border text-start transition-all ${
                    selectedSection === sec.id
                      ? 'bg-amber-500/15 border-amber-500/50'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="text-[10px] font-mono text-amber-400 font-bold">
                    0{idx + 1} • {sec.pointRange}
                  </div>
                  <div className="text-xs font-bold text-white mt-1">
                    {isAr ? sec.nameAr : sec.name}
                  </div>
                </button>
              ))}
            </div>

            {/* Selected Section preview */}
            <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-white">
                  {isAr ? currentSectionData.nameAr : currentSectionData.name} ({currentSectionTiers.length} {isAr ? 'رتب' : 'tiers'})
                </span>
                <span className="font-mono text-amber-400 text-xs">
                  {currentSectionData.pointRange}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {currentSectionTiers.slice(0, 6).map((tier) => (
                  <div
                    key={tier.id}
                    className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center justify-between gap-2 text-xs"
                  >
                    <span className="font-semibold text-slate-200">
                      {isAr ? tier.nameAr : tier.name}
                    </span>
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-slate-900 text-amber-300 border border-slate-800 shrink-0">
                      {tier.pointsLabel}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 3: APPLICATIONS & APPROVAL
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-rnk-thresholds' || activeChapterId === 'ch-rnk-applications' || activeChapterId === 'ch-applications-workflow') && (
        <section id="ch-rnk-applications" className="scroll-mt-28 space-y-6">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono text-xs font-bold">
              03
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'تقديم طلب الترقية واعتماد المالك' : 'Rank Applications & Approval'}
            </h2>
          </div>

          <div className="p-6 sm:p-8 rounded-3xl bg-slate-950/70 border border-slate-800 space-y-5 text-sm text-slate-300">
            <p className="leading-relaxed">
              {isAr
                ? 'بلوغ عتبة النقاط يؤهلك للتقديم، لكن الترقية لا تُمنح تلقائياً بل تتطلب مراجعة المالك Edgar:'
                : 'Reaching points qualifies you to apply, but promotions require review and approval by Owner Edgar:'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                <div className="text-xs font-bold text-slate-200">
                  {isAr ? '1. بلوغ النصاب' : '1. Meet Threshold'}
                </div>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'يجب أن يصل رصيد نقاطك إلى الحد الأدنى المطلوب للرتبة المستهدفة.'
                    : 'Your verified points must reach the required points threshold.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                <div className="text-xs font-bold text-slate-200">
                  {isAr ? '2. إرسال الطلب' : '2. Submit Application'}
                </div>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'انقر على "تقديم طلب الترقية" في صفحة الرتب واكتب ملاحظة مختصرة.'
                    : 'Click "Apply for Promotion" in the Rank Map and write an optional note.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                <div className="text-xs font-bold text-slate-200">
                  {isAr ? '3. قرار المالك' : '3. Owner Review'}
                </div>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'يراجع Edgar نشاطك وتصلك رسالة إشعار فور اعتماد الترقية.'
                    : 'Owner Edgar reviews your activity and a notification confirms the decision.'}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 4: DISCORD ROLES CLARIFICATION
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-rnk-discord-note') && (
        <section id="ch-rnk-discord-note" className="scroll-mt-28 space-y-6">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono text-xs font-bold">
              04
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'توضيح مهم: رتب ديسكورد لا تتغير تلقائياً' : 'Important: Discord Roles Do Not Change Automatically'}
            </h2>
          </div>

          <div className="p-6 sm:p-8 rounded-3xl bg-slate-950/70 border border-amber-500/30 space-y-5 text-sm text-slate-300">
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
              <ShieldAlert size={20} className="text-amber-400 shrink-0 mt-0.5" />
              <div className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                <strong className="text-white block mb-0.5">
                  {isAr ? 'فصل منظومة الموقع عن رتب سيرفر ديسكورد' : 'Platform Progression Is Independent of Discord Roles'}
                </strong>
                {isAr
                  ? 'ترقيات الموقع ونقاط الاستحقاق هي نظام تنظيمي رقمي خاص بالمنصة، ولا تغير رتب حسابك في تطبيق ديسكورد تلقائياً. رتب ديسكورد وصلاحيات القنوات يمنحها المالك Edgar يدوياً بشكل مستقل.'
                  : 'Advancing in rank on this website is an internal platform tracker and does not automatically alter your roles in Discord. Discord roles and permissions remain exclusively managed by Owner Edgar.'}
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
