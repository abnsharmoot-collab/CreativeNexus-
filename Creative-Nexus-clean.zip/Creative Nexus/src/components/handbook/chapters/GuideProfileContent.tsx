import React from 'react';
import { 
  User, 
  ShieldCheck, 
  Trophy, 
  Lock, 
  CheckCircle2, 
  ExternalLink,
  Copy,
  Sparkles,
  Info
} from 'lucide-react';
import { useLanguage } from '../../../context/LanguageContext';
import { useAuth } from '../../../context/AuthContext';

interface ChapterProps {
  activeChapterId: string;
}

export const GuideProfileContent: React.FC<ChapterProps> = ({ activeChapterId }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { user, isAuthenticated } = useAuth();

  return (
    <div className="space-y-10">
      {/* ──────────────────────────────────────────────
          CHAPTER 1: PROFILE & DISCORD IDENTITY
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-prof-card' || activeChapterId === 'ch-prof-discord') && (
        <section id="ch-prof-card" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 font-mono text-xs font-bold">
              01
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'الملف الشخصي وهوية ديسكورد' : 'Profile Drawer & Discord Identity'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/80 border border-blue-500/25 space-y-5 text-slate-300 text-sm leading-relaxed">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-2xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0 mt-0.5">
                <User size={20} />
              </div>
              <div className="space-y-1">
                <h3 className="text-base sm:text-lg font-bold text-white">
                  {isAr ? 'بطاقة ملفك الشخصي المنسدلة' : 'Your Live Discord Profile Drawer'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300">
                  {isAr
                    ? 'بالنقر على صورتك الرمزية في الشريط العلوي، تفتح بطاقة ملفك الشخصي لتعطيك ملخصاً فورياً عن حسابك ورتبتك ونقاطك وإنجازاتك دون مغادرة الصفحة.'
                    : 'Clicking your avatar in the top navbar opens your profile drawer for an instant summary of your rank tier, verified points, and unlocked achievements.'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="text-blue-400 font-bold text-xs uppercase font-mono">
                  {isAr ? 'الصورة واسم المستخدم' : 'Avatar & Username'}
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'مزامنة مباشرة لاسمك وصورتك من ديسكورد.' : 'Live synchronized Discord avatar and username.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="text-amber-400 font-bold text-xs uppercase font-mono">
                  {isAr ? 'الرتبة والنقاط' : 'Rank Tier & Points'}
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'استعراض رتبتك الحالية ورصيد نقاطك المعتمدة.' : 'Shows your current staff tier and approved points.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="text-emerald-400 font-bold text-xs uppercase font-mono">
                  {isAr ? 'معرّف الحساب (ID)' : 'Immutable Discord ID'}
                </div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'رقم حسابك الثابت في ديسكورد لحفظ أوسمتك وسجلاتك.' : 'Your permanent numeric ID, safeguarding your progress.'}
                </p>
              </div>
            </div>

            {isAuthenticated && user && (
              <div className="pt-1 flex items-center gap-2 text-xs">
                <span className="text-slate-400 font-mono">{isAr ? 'معرّفك الحالي في ديسكورد:' : 'Your Discord ID:'}</span>
                <code className="px-2 py-0.5 rounded-md bg-slate-900 border border-slate-700 font-mono text-cyan-300">
                  {user.discordId || user.id}
                </code>
              </div>
            )}
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 2: ACHIEVEMENTS ON YOUR PROFILE
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-prof-achieve') && (
        <section id="ch-prof-achieve" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 font-mono text-xs font-bold">
              02
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'الأوسمة ونسبة الإكمال' : 'Achievements & Progress'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/80 border border-slate-800 space-y-5 text-slate-300 text-sm leading-relaxed">
            <p>
              {isAr
                ? 'يوفر ملفك الشخصي متابعة دقيقة لنسبة تقدمك نحو فتح أوسمة السيرفر الأربعين:'
                : 'Your profile drawer tracks your progress across all 40 official server achievements:'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-purple-500/30 space-y-1.5">
                <div className="flex items-center gap-2 text-purple-400 font-bold text-xs uppercase font-mono">
                  <Trophy size={16} />
                  <span>{isAr ? 'شريط نسبة الإنجاز' : 'Completion Tracker'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'عداد يوضح عدد الأوسمة المكتسبة من أصل 40 وساماً مع النسبة المئوية.'
                    : 'Shows your exact count and percentage of unlocked badges out of 40.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-cyan-500/30 space-y-1.5">
                <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs uppercase font-mono">
                  <Sparkles size={16} />
                  <span>{isAr ? 'رابط مصفوفة الأوسمة' : 'Achievements Matrix'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'زر سريع ينقلك إلى صفحة الأوسمة للتعرف على متطلبات الأوسمة المتبقية.'
                    : 'A fast shortcut to the full achievements page to review badge requirements.'}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 3: PRIVACY & DATA SAFETY
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-prof-data') && (
        <section id="ch-prof-data" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 font-mono text-xs font-bold">
              03
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'الخصوصية وأمان البيانات' : 'Account Privacy & Data Safety'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/80 border border-slate-800 space-y-5 text-slate-300 text-sm leading-relaxed">
            <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-3">
              <Lock size={18} className="text-emerald-400 shrink-0 mt-0.5" />
              <div className="text-xs text-slate-300 space-y-1">
                <strong className="text-white block">{isAr ? 'أمان تام ومصادقة مشفرة' : 'Encrypted OAuth2 Authentication'}</strong>
                <p>
                  {isAr
                    ? 'الموقع لا يطلب ولا يخزن أي كلمات مرور. تسجيل الدخول يتم مباشرة عبر خوادم Discord الرسمية المشفرة.'
                    : 'We never ask for or store passwords. Sign-in is handled securely through Discord’s official OAuth2 service.'}
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-bold text-white text-xs uppercase font-mono tracking-wider">
                {isAr ? 'البيانات المحفوظة في الموقع:' : 'Information Stored by the Platform:'}
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-300 list-disc list-inside">
                <li><strong className="text-white">Discord ID:</strong> {isAr ? 'لربط رتبتك وسجلاتك بشكل فريد.' : 'To link your profile, rank, and badges.'}</li>
                <li><strong className="text-white">{isAr ? 'الاسم والصورة: ' : 'Username & Avatar: '}</strong> {isAr ? 'لعرض هويتك في الشريط العلوي وقوائم الإدارة.' : 'To display your identity in the navbar and rosters.'}</li>
                <li><strong className="text-white">{isAr ? 'رتب السيرفر: ' : 'Guild Roles: '}</strong> {isAr ? 'للتحقق من صلاحيات الإشراف المعتمدة.' : 'To verify your staff standing.'}</li>
                <li><strong className="text-white">{isAr ? 'رصيد النقاط والطلبات: ' : 'Points & Requests: '}</strong> {isAr ? 'النقاط الممنوحة لك وتاريخ مراجعة طلبات الترقية.' : 'Your verified points and rank promotion tickets.'}</li>
              </ul>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
