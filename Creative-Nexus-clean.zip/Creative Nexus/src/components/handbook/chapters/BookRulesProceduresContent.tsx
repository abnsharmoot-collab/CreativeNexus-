import React, { useState } from 'react';
import { 
  ScrollText, 
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  UserX,
  Ban
} from 'lucide-react';
import { OFFICIAL_SERVER_RULES } from '../../../data/handbookData';
import { useLanguage } from '../../../context/LanguageContext';

interface ChapterProps {
  activeChapterId: string;
}

export const BookRulesProceduresContent: React.FC<ChapterProps> = ({ activeChapterId }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const [filterCategory, setFilterCategory] = useState<'all' | 'community' | 'safety' | 'moderation'>('all');
  const [ruleSearch, setRuleSearch] = useState('');

  const filteredRules = OFFICIAL_SERVER_RULES.filter((rule) => {
    const matchesCategory = filterCategory === 'all' || rule.category === filterCategory;
    const matchesSearch = 
      !ruleSearch || 
      rule.title.includes(ruleSearch) || 
      rule.body.includes(ruleSearch) || 
      rule.id.toString() === ruleSearch.trim();
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-10">
      {/* ──────────────────────────────────────────────
          CHAPTER 1: THE 20 OFFICIAL RULES
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-rules-list') && (
        <section id="ch-rules-list" className="scroll-mt-28 space-y-6">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400 font-mono text-xs font-bold">
              01
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'القوانين الرسمية العشرون' : 'The 20 Official Rules'}
            </h2>
          </div>

          {/* Quick Overview & Filters */}
          <div className="p-5 sm:p-6 rounded-3xl bg-slate-950/80 border border-rose-500/30 space-y-4">
            <div className="flex items-start gap-3.5">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0 mt-0.5">
                <ScrollText size={20} />
              </div>
              <div className="space-y-1 text-sm text-slate-300 leading-relaxed">
                <h3 className="text-sm sm:text-base font-bold text-white">
                  {isAr ? 'دستور وقوانين سيرفر CREATINE NEXUS' : 'CREATINE NEXUS Server Rules'}
                </h3>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'هذه القوانين العشرون ملزمة لجميع الأعضاء والمشرفين لضمان بيئة آمنة ومريحة للجميع.'
                    : 'These 20 official rules apply to all members and staff to keep the sanctuary respectful and safe.'}
                </p>
              </div>
            </div>

            {/* Filter and search toolbar */}
            <div className="pt-2 border-t border-slate-800/80 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                <button
                  onClick={() => setFilterCategory('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono transition-all shrink-0 ${
                    filterCategory === 'all'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold'
                      : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {isAr ? 'الكل (20)' : 'All (20)'}
                </button>
                <button
                  onClick={() => setFilterCategory('community')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono transition-all shrink-0 ${
                    filterCategory === 'community'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold'
                      : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {isAr ? 'السلوك (8)' : 'Conduct (8)'}
                </button>
                <button
                  onClick={() => setFilterCategory('safety')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono transition-all shrink-0 ${
                    filterCategory === 'safety'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold'
                      : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {isAr ? 'الأمان (9)' : 'Safety (9)'}
                </button>
                <button
                  onClick={() => setFilterCategory('moderation')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono transition-all shrink-0 ${
                    filterCategory === 'moderation'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold'
                      : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {isAr ? 'الإدارة (3)' : 'Authority (3)'}
                </button>
              </div>

              <div className="relative">
                <Search size={14} className="absolute start-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  value={ruleSearch}
                  onChange={(e) => setRuleSearch(e.target.value)}
                  placeholder={isAr ? 'ابحث برقم أو نص القانون...' : 'Search rule # or text...'}
                  className="w-full sm:w-52 ps-9 pe-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500/50 transition-colors"
                />
              </div>
            </div>
          </div>

          {/* Rules Grid */}
          <div className="space-y-4" dir="rtl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {filteredRules.map((rule) => {
                const borderGlow =
                  rule.id === 1 || rule.id === 15 || rule.id === 19
                    ? 'border-amber-500/30 hover:border-amber-500/60 bg-slate-900/80'
                    : rule.id === 2 || rule.id === 3 || rule.id === 7 || rule.id === 12 || rule.id === 16 || rule.id === 20
                    ? 'border-rose-500/30 hover:border-rose-500/60 bg-slate-900/70'
                    : 'border-slate-800 hover:border-cyan-500/50 bg-slate-900/60';

                return (
                  <div
                    key={rule.id}
                    className={`p-4 sm:p-5 rounded-2xl border transition-all duration-300 flex flex-col justify-between text-right ${borderGlow}`}
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <h4 className="text-sm sm:text-base font-bold text-white font-sans">
                          {rule.id}. {rule.title}
                        </h4>
                        <span className="w-7 h-7 rounded-xl bg-slate-950 border border-slate-800 text-rose-300 font-mono text-xs font-bold flex items-center justify-center shrink-0">
                          {rule.id}
                        </span>
                      </div>
                      <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans font-normal">
                        {rule.body}
                      </p>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                      <span>{isAr ? rule.categoryLabelAr : rule.categoryLabelEn}</span>
                      <span className="text-slate-500">#{rule.id}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 2: DISCIPLINARY ESCALATION STEPS
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-rules-escalation') && (
        <section id="ch-rules-escalation" className="scroll-mt-28 space-y-5">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400 font-mono text-xs font-bold">
              02
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'خطوات التعامل مع المخالفات' : 'Disciplinary Escalation Steps'}
            </h2>
          </div>

          <div className="p-6 sm:p-7 rounded-3xl bg-slate-950/70 border border-slate-800 space-y-5 text-sm text-slate-300">
            <p className="leading-relaxed">
              {isAr
                ? 'تتعامل إدارة السيرفر بحكمة وتدرج مع أي سلوك غير لائق وفق مراحل واضحة لحفظ النظام دون تعسف:'
                : 'Moderators handle infractions through clear progressive stages designed to correct behavior and preserve server harmony:'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-1">
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1.5 text-center">
                <div className="w-8 h-8 mx-auto rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                  <CheckCircle2 size={16} />
                </div>
                <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase block">STEP 1</span>
                <div className="text-xs font-bold text-white">
                  {isAr ? 'تنبيه ودي' : 'Friendly Reminder'}
                </div>
                <p className="text-[11px] text-slate-400">
                  {isAr ? 'للهفوات غير المقصودة وتنبيه العضو بلطف.' : 'Gentle note in chat for accidental or first-time slips.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1.5 text-center">
                <div className="w-8 h-8 mx-auto rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                  <Clock size={16} />
                </div>
                <span className="text-[10px] font-mono font-bold text-amber-400 uppercase block">STEP 2</span>
                <div className="text-xs font-bold text-white">
                  {isAr ? 'كتم مؤقت (Timeout)' : 'Timeout / Mute'}
                </div>
                <p className="text-[11px] text-slate-400">
                  {isAr ? 'إيقاف الكتابة مؤقتاً عند تكرار الجدال أو الإزعاج.' : 'Temporary cooldown for heated arguments or spam.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1.5 text-center">
                <div className="w-8 h-8 mx-auto rounded-xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400">
                  <UserX size={16} />
                </div>
                <span className="text-[10px] font-mono font-bold text-orange-400 uppercase block">STEP 3</span>
                <div className="text-xs font-bold text-white">
                  {isAr ? 'طرد من السيرفر (Kick)' : 'Server Kick'}
                </div>
                <p className="text-[11px] text-slate-400">
                  {isAr ? 'إخراج العضو مع إمكانية عودته إذا التزم بالقوانين.' : 'Removal with the ability to rejoin if rules are respected.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 space-y-1.5 text-center">
                <div className="w-8 h-8 mx-auto rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-300">
                  <Ban size={16} />
                </div>
                <span className="text-[10px] font-mono font-bold text-rose-300 uppercase block">STEP 4</span>
                <div className="text-xs font-bold text-white">
                  {isAr ? 'حظر نهائي (Ban)' : 'Permanent Ban'}
                </div>
                <p className="text-[11px] text-rose-200/80">
                  {isAr ? 'للمخالفات الجسيمة كالسبام، الروابط الخبيثة، والتخريب.' : 'For malicious links, raids, or severe violations.'}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
