import React from 'react';
import { 
  ClipboardList, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  ArrowRight,
  Crown,
  Layers
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../../../context/LanguageContext';

interface ChapterProps {
  activeChapterId: string;
}

export const GuideApplicationsContent: React.FC<ChapterProps> = ({ activeChapterId }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  return (
    <div className="space-y-12">
      {/* ──────────────────────────────────────────────
          CHAPTER 1: HOW RANK APPLICATIONS WORK
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-app-submit') && (
        <section id="ch-app-submit" className="scroll-mt-28 space-y-6">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 font-mono text-xs font-bold">
              01
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'كيفية تقديم طلب ترقية' : 'Submitting a Rank Application'}
            </h2>
          </div>

          <div className="p-6 sm:p-8 rounded-3xl bg-slate-950/80 border border-indigo-500/25 space-y-5 text-slate-300 text-sm leading-relaxed">
            <p>
              {isAr
                ? 'عند بلوغ رصيد نقاطك النصاب المطلوب للرتبة التالية، يتفعل زر التقديم في صفحة الرتب لتتمكن من رفع طلبك:'
                : 'When your points reach the threshold for the next rank, the application button unlocks on the Rank page:'}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                <div className="text-xs font-mono font-bold text-indigo-400">1. {isAr ? 'بلوغ عتبة النقاط' : 'Reach Threshold'}</div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'تأكد من اكتمال النقاط المطلوبة للرتبة التالية.' : 'Verify your verified points meet the rank requirement.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                <div className="text-xs font-mono font-bold text-cyan-400">2. {isAr ? 'تقديم الطلب' : 'Submit Note'}</div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'انقر على "تقديم الطلب" واكتب ملخصاً سريعاً لنشاطك.' : 'Click Apply and write a brief summary of your contributions.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                <div className="text-xs font-mono font-bold text-amber-400">3. {isAr ? 'مراجعة المالك' : 'Owner Review'}</div>
                <p className="text-xs text-slate-400">
                  {isAr ? 'يراجع Edgar الطلب ويصدر قراره مع إشعار مباشر بحسابك.' : 'Owner Edgar reviews the ticket and you receive an alert.'}
                </p>
              </div>
            </div>

            <div className="pt-2">
              <Link
                to="/rank-points"
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-indigo-500/15 hover:bg-indigo-500/25 border border-indigo-500/30 text-indigo-300 text-xs font-semibold transition-colors"
              >
                <span>{isAr ? 'فتح صفحة الرتب والتقديم' : 'Open Rank & Points Page'}</span>
                <ArrowRight size={13} className="rtl:rotate-180" />
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 2: APPLICATION STATUSES
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-app-status') && (
        <section id="ch-app-status" className="scroll-mt-28 space-y-6">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 font-mono text-xs font-bold">
              02
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'حالات الطلب' : 'Application Statuses'}
            </h2>
          </div>

          <div className="p-6 sm:p-8 rounded-3xl bg-slate-950/80 border border-slate-800 space-y-4 text-slate-300 text-sm leading-relaxed">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
                <Clock size={16} className="text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-amber-300 font-mono">PENDING ({isAr ? 'قيد المراجعة' : 'Pending'})</div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {isAr ? 'الطلب بانتظار مراجعة وقرار المالك Edgar.' : 'Your application is awaiting Edgar’s review.'}
                  </p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-3">
                <CheckCircle2 size={16} className="text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-emerald-300 font-mono">APPROVED ({isAr ? 'معتمد' : 'Approved'})</div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {isAr ? 'تمت الموافقة وتحديث رتبتك وشارتك في الموقع فوراً.' : 'Promotion granted; rank badge updates on your profile.'}
                  </p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-start gap-3">
                <XCircle size={16} className="text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-rose-300 font-mono">REJECTED ({isAr ? 'مرفوض' : 'Rejected'})</div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {isAr ? 'يتطلب نشاطاً إضافياً قبل إعادة التقديم.' : 'Needs more activity or attendance before re-applying.'}
                  </p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-start gap-3">
                <AlertCircle size={16} className="text-slate-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-slate-300 font-mono">NOT_APPLIED ({isAr ? 'متاح للتقديم' : 'Ready to Apply'})</div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {isAr ? 'نقاطك كافية ولكن لم تقدم الطلب بعد.' : 'You have enough points, ready to submit a request.'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 3: OWNER REVIEW & CONTINUOUS ADVANCEMENT
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-app-review' || activeChapterId === 'ch-app-next') && (
        <section id="ch-app-review" className="scroll-mt-28 space-y-6">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 font-mono text-xs font-bold">
              03
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'اعتماد المالك والترقية التالية' : 'Owner Approval & Subsequent Ranks'}
            </h2>
          </div>

          <div className="p-6 sm:p-8 rounded-3xl bg-slate-950/80 border border-slate-800 space-y-4 text-slate-300 text-sm leading-relaxed">
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
              <Crown size={18} className="text-amber-400 shrink-0 mt-0.5" />
              <div className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                <strong className="text-white block mb-0.5">
                  {isAr ? 'الموافقة الحصرية لمالك السيرفر Edgar' : 'Sole Owner Approval'}
                </strong>
                {isAr
                  ? 'لا يمكن لأي مشرف أو إداري ترقية نفسه؛ جميع الترقيات يراجعها ويعتمدها حصرياً المالك Edgar.'
                  : 'Self-promotion is impossible. All advancements are reviewed exclusively by Owner Edgar.'}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-start gap-3">
              <Layers size={18} className="text-cyan-400 shrink-0 mt-0.5" />
              <div className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                <strong className="text-white block mb-0.5">
                  {isAr ? 'كل رتبة تتطلب طلباً مستقلاً' : 'Each Rank Requires a Fresh Application'}
                </strong>
                {isAr
                  ? 'اعتماد رتبة معينة لا يرقيك للرتب التالية تلقائياً؛ عند الوصول لنصاب الرتبة التالية، يجب تقديم طلب جديد.'
                  : 'Approvals are per-rank. Once you earn enough points for the subsequent rank, submit a new application.'}
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
