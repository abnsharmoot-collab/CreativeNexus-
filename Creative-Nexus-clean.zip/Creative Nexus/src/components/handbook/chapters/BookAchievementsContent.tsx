import React, { useState } from 'react';
import { 
  Trophy, 
  Sparkles, 
  ArrowUpRight,
  ShieldCheck,
  Zap,
  CheckCircle2
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { 
  ACHIEVEMENT_CATEGORIES, 
  ALL_ACHIEVEMENTS, 
  AchievementCategory 
} from '../../../types/achievements';
import { useLanguage } from '../../../context/LanguageContext';

interface ChapterProps {
  activeChapterId: string;
}

export const BookAchievementsContent: React.FC<ChapterProps> = ({ activeChapterId }) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const [selectedCategory, setSelectedCategory] = useState<AchievementCategory | 'all'>('all');

  return (
    <div className="space-y-12">
      {/* ──────────────────────────────────────────────
          CHAPTER 1: SYSTEM OVERVIEW & UNLOCK MECHANIC
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-achieve-overview' || activeChapterId === 'ch-ach-concept') && (
        <section id="ch-ach-concept" className="scroll-mt-28 space-y-6">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <span className="px-2.5 py-1 rounded-lg bg-purple-500/10 border border-purple-500/30 text-purple-400 font-mono text-xs font-bold">
                01
              </span>
              <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
                {isAr ? 'نظام الأوسمة وطريقة فتحها' : 'Achievement System & Unlocks'}
              </h2>
            </div>

            <Link
              to="/achievements"
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/30 text-purple-300 text-xs font-semibold transition-all"
            >
              <span>{isAr ? 'صفحة الأوسمة' : 'Achievements Page'}</span>
              <ArrowUpRight size={14} />
            </Link>
          </div>

          <div className="p-6 sm:p-8 rounded-3xl bg-slate-950/70 border border-slate-800 space-y-6 text-sm text-slate-300 leading-relaxed">
            <p className="text-xs text-slate-400">
              {isAr
                ? 'يضم مجتمعنا 40 وساماً تكافئ نشاطك المستمر، وتفاعلك في السيرفر، وتطورك الإداري:'
                : 'Features 40 collectible badges celebrating activity, moderation milestones, and server participation:'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 pt-1">
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400 font-mono uppercase">
                  <Zap size={14} />
                  <span>{isAr ? 'احتساب تلقائي' : 'Auto-Calculated'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'يتم فحص أهليتك لكل وسام تلقائياً عند تحديث نقاطك أو ترقيتك.'
                    : 'Milestones unlock automatically whenever your points or ranks are updated.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-purple-400 font-mono uppercase">
                  <Trophy size={14} />
                  <span>{isAr ? 'مقبس العرض الحركي' : 'Card Socket Drop'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'الأوسمة الجديدة تسقط داخل مقبس البطاقة بحركة فيزيائية وتأثير بصري أنيق.'
                    : 'Newly unlocked badges animate into place with a physical socket drop effect.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400 font-mono uppercase">
                  <ShieldCheck size={14} />
                  <span>{isAr ? 'حفظ دائم' : 'Permanent Sync'}</span>
                </div>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'أوسمتك مرتبطة بمعرّف ديسكورد الخاص بك ومحفوظة دائماً على السحابة.'
                    : 'Earned honors are tied to your Discord ID and securely preserved in cloud storage.'}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 2: THE 7 ACHIEVEMENT CATEGORIES
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-achieve-categories' || activeChapterId === 'ch-achieve-progress' || activeChapterId === 'ch-ach-progress') && (
        <section id="ch-ach-progress" className="scroll-mt-28 space-y-6">
          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 rounded-lg bg-purple-500/10 border border-purple-500/30 text-purple-400 font-mono text-xs font-bold">
              02
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              {isAr ? 'فئات الأوسمة السبع' : 'The 7 Achievement Categories'}
            </h2>
          </div>

          <div className="p-6 sm:p-8 rounded-3xl bg-slate-950/70 border border-slate-800 space-y-5">
            <p className="text-sm text-slate-300 leading-relaxed">
              {isAr
                ? 'تنقسم الأوسمة إلى سبع فئات وظيفية تغطي جميع جوانب التفاعل والمجتمع:'
                : 'All 40 badges are organized into seven focused categories across community life:'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {ACHIEVEMENT_CATEGORIES.map((cat) => {
                const count = ALL_ACHIEVEMENTS.filter((a) => a.category === cat.id).length;
                return (
                  <div
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                      selectedCategory === cat.id
                        ? 'bg-purple-500/15 border-purple-500/50'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-lg">{cat.icon}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-400">
                        {count} {isAr ? 'أوسمة' : 'Badges'}
                      </span>
                    </div>
                    <h4 className="text-xs font-bold text-white">
                      {isAr ? cat.nameAr : cat.name}
                    </h4>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* ──────────────────────────────────────────────
          CHAPTER 3: HOW ACHIEVEMENTS ARE DISPLAYED
      ────────────────────────────────────────────── */}
      {(activeChapterId === 'all' || activeChapterId === 'ch-achieve-progression' || activeChapterId === 'ch-achieve-promotions' || activeChapterId === 'ch-achieve-display' || activeChapterId === 'ch-ach-display') && (
        <section id="ch-ach-display" className="scroll-mt-28 space-y-6">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <span className="px-2.5 py-1 rounded-lg bg-purple-500/10 border border-purple-500/30 text-purple-400 font-mono text-xs font-bold">
                03
              </span>
              <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
                {isAr ? 'كيفية استعراض الأوسمة' : 'How Badges Are Displayed'}
              </h2>
            </div>

            <Link
              to="/achievements"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-xs font-semibold transition-all"
            >
              <span>{isAr ? 'فتح المعرض الكامل' : 'Full Showcase'}</span>
              <ArrowUpRight size={13} />
            </Link>
          </div>

          <div className="p-6 sm:p-8 rounded-3xl bg-slate-950/70 border border-slate-800 space-y-5 text-sm text-slate-300 leading-relaxed">
            <p>
              {isAr
                ? 'يمكنك استعراض تفاصيل جميع الأوسمة ومتطلبات الحصول عليها مباشرة من صفحة الأوسمة:'
                : 'You can explore all badge requirements, filters, and unlocked statuses on the main Achievements page:'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              <div className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800 space-y-1.5">
                <div className="text-xs font-bold text-slate-200">
                  {isAr ? '1. فلترة الفئات' : '1. Category Filters'}
                </div>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'تصفية الأوسمة بسهولة بحسب فئتها لمعرفة الأوسمة المتبقية لك.'
                    : 'Filter honors by operational area to see what you have left to earn.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800 space-y-1.5">
                <div className="text-xs font-bold text-slate-200">
                  {isAr ? '2. شرط الاستحقاق' : '2. Clear Requirements'}
                </div>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'لكل وسام هدف رقمي محدد (مثل نقاط، أيام عضوية، أو رتبة).'
                    : 'Each badge shows its exact required target (points, days, or rank).'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800 space-y-1.5">
                <div className="text-xs font-bold text-slate-200">
                  {isAr ? '3. حالة الفتح' : '3. Unlocked Status'}
                </div>
                <p className="text-xs text-slate-400">
                  {isAr
                    ? 'الأوسمة المكتسبة تظهر مضيئة مع تاريخ الحصول عليها بدقة.'
                    : 'Earned honors glow with a border and show your exact unlock date.'}
                </p>
              </div>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
