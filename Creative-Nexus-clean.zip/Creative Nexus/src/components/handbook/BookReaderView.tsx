import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  ArrowRight, 
  Clock, 
  List,
  ExternalLink
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { HandbookBook } from '../../types/handbook';
import { HANDBOOK_BOOKS } from '../../data/handbookData';
import { useLanguage } from '../../context/LanguageContext';
import { useEasterEggs } from '../../context/EasterEggContext';

// Chapter content components
import { GuideGettingStartedContent } from './chapters/GuideGettingStartedContent';
import { GuideProfileContent } from './chapters/GuideProfileContent';
import { BookAchievementsContent } from './chapters/BookAchievementsContent';
import { BookRankProgressionContent } from './chapters/BookRankProgressionContent';
import { GuideApplicationsContent } from './chapters/GuideApplicationsContent';
import { GuideNotificationsContent } from './chapters/GuideNotificationsContent';
import { GuideAnnouncementsContent } from './chapters/GuideAnnouncementsContent';
import { GuideHistoryContent } from './chapters/GuideHistoryContent';
import { BookRulesProceduresContent } from './chapters/BookRulesProceduresContent';
import { BookAdministrationContent } from './chapters/BookAdministrationContent';
import { BookServerStructureContent } from './chapters/BookServerStructureContent';

interface BookReaderViewProps {
  book: HandbookBook;
  initialChapterId?: string;
  onBackToLibrary: () => void;
  onSelectBook: (bookId: string, chapterId?: string) => void;
  onUpdateProgress?: (bookId: string, percent: number) => void;
}

export const BookReaderView: React.FC<BookReaderViewProps> = ({
  book,
  initialChapterId,
  onBackToLibrary,
  onSelectBook,
  onUpdateProgress
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  const [activeChapterId, setActiveChapterId] = useState<string>(
    initialChapterId || book.chapters[0]?.id || 'all'
  );

  // Sync when initialChapterId changes without unnecessary state churn
  useEffect(() => {
    const target = initialChapterId || book.chapters[0]?.id || 'all';
    setActiveChapterId((prev) => (prev === target ? prev : target));
  }, [initialChapterId, book.id]);

  // Find previous and next books in the library
  const currentBookIndex = HANDBOOK_BOOKS.findIndex((b) => b.id === book.id);
  const prevBook = currentBookIndex > 0 ? HANDBOOK_BOOKS[currentBookIndex - 1] : null;
  const nextBook = currentBookIndex < HANDBOOK_BOOKS.length - 1 ? HANDBOOK_BOOKS[currentBookIndex + 1] : null;

  // Find active chapter index
  const currentChapterIndex = book.chapters.findIndex((c) => c.id === activeChapterId);
  const prevChapter = currentChapterIndex > 0 ? book.chapters[currentChapterIndex - 1] : null;
  const nextChapter = currentChapterIndex >= 0 && currentChapterIndex < book.chapters.length - 1 
    ? book.chapters[currentChapterIndex + 1] 
    : null;

  // Calculate reading progress purely as a memoized value
  const readingProgress = useMemo(() => {
    if (activeChapterId === 'all') {
      return 100;
    }
    if (currentChapterIndex >= 0 && book.chapters.length > 0) {
      return Math.round(((currentChapterIndex + 1) / book.chapters.length) * 100);
    }
    return 0;
  }, [activeChapterId, currentChapterIndex, book.chapters.length]);

  // Notify parent only when book or reading progress actually changes
  const lastReportedRef = React.useRef<string>('');
  useEffect(() => {
    const key = `${book.id}-${readingProgress}`;
    if (onUpdateProgress && lastReportedRef.current !== key) {
      lastReportedRef.current = key;
      onUpdateProgress(book.id, readingProgress);
    }
  }, [book.id, readingProgress, onUpdateProgress]);

  // Scroll to top on chapter change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeChapterId, book.id]);

  const totalReadingTime = useMemo(() => {
    return book.chapters.reduce((acc, c) => acc + c.readingTimeMinutes, 0);
  }, [book.chapters]);

  return (
    <div className="space-y-6 sm:space-y-8 pb-20 w-full overflow-x-hidden">
      {/* ──────────────────────────────────────────────
          CLEAN TOP NAVIGATION HEADER
      ────────────────────────────────────────────── */}
      <div className="flex items-center justify-between gap-4 py-2">
        <button
          onClick={onBackToLibrary}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#041a18] hover:bg-[#072522] border border-[rgba(158,255,230,0.18)] hover:border-[#5eead4]/40 text-xs font-medium text-[#8db8b1] hover:text-white transition-all shadow-sm cursor-pointer"
        >
          {isAr ? <ArrowRight size={14} /> : <ArrowLeft size={14} />}
          <span>{isAr ? 'العودة للمكتبة' : 'Back to Library'}</span>
        </button>

        <div className="flex items-center gap-3 text-xs font-mono text-[#8db8b1]">
          <span className="hidden sm:inline text-[#8db8b1]/60">
            CREATIVE NEXUS • {book.bookNumber}
          </span>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#041a18] border border-[rgba(158,255,230,0.15)] text-[#5eead4]">
            <Clock size={12} className="text-[#5eead4]" />
            <span>~{totalReadingTime} {isAr ? 'د' : 'min'}</span>
          </span>
        </div>
      </div>

      {/* ──────────────────────────────────────────────
          BOOK HERO BANNER
      ────────────────────────────────────────────── */}
      <div className={`relative rounded-3xl p-5 sm:p-8 border shadow-xl overflow-hidden backdrop-blur-md ${
        isMesopotamian
          ? 'mesopotamian-stone-bg border-amber-600/40'
          : `bg-[#06201e]/85 border-[rgba(158,255,230,0.18)]`
      }`}>
        {/* Gradient accent */}
        <div className={`absolute top-0 inset-x-0 h-40 bg-gradient-to-b ${book.gradient} pointer-events-none opacity-60`} />

        <div className="relative z-10 space-y-3 sm:space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2.5">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-xl bg-[#031413] border border-[rgba(158,255,230,0.2)] text-[#5eead4] font-mono text-xs font-bold">
                {book.bookNumber}
              </span>
              <span className="text-xs font-mono text-[#8db8b1] uppercase tracking-wider">
                {isAr ? book.tagAr : book.tagEn}
              </span>
            </div>

            <div className="flex items-center gap-2.5 text-xs font-mono text-[#8db8b1]">
              <span className="flex items-center gap-1">
                <Clock size={13} className="text-[#5eead4]" />
                <span>~{totalReadingTime} {isAr ? 'دقيقة' : 'min'}</span>
              </span>
              <span>•</span>
              <span>{book.chapters.length} {isAr ? 'فصول' : 'Chapters'}</span>
            </div>
          </div>

          <h1 className="text-xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight font-display">
            {isAr ? book.titleAr : book.titleEn}
          </h1>

          <p className="text-xs sm:text-sm font-medium text-[#5eead4] font-sans">
            {isAr ? book.subtitleAr : book.subtitleEn}
          </p>

          <p className="text-xs sm:text-sm text-[#8db8b1] leading-relaxed max-w-4xl">
            {isAr ? book.descriptionAr : book.descriptionEn}
          </p>

          {book.relatedPath && (
            <div className="pt-2">
              <Link
                to={book.relatedPath}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-[#2dd4bf]/15 hover:bg-[#2dd4bf]/25 border border-[#2dd4bf]/30 text-[#5eead4] text-xs font-semibold transition-colors"
              >
                <span>{isAr ? 'الانتقال للصفحة المباشرة ذات الصلة' : 'Open Related Live Page'}</span>
                <ExternalLink size={13} />
              </Link>
            </div>
          )}
        </div>
      </div>

      {/* ──────────────────────────────────────────────
          MOBILE CHAPTER SELECTOR
      ────────────────────────────────────────────── */}
      <div className="lg:hidden flex items-center justify-between gap-3 p-3 rounded-2xl bg-[#06201e]/85 border border-[rgba(158,255,230,0.18)]">
        <div className="flex items-center gap-2 text-xs text-[#8db8b1] font-mono shrink-0">
          <List size={14} className="text-[#5eead4]" />
          <span>{isAr ? 'عرض الفصل:' : 'View Chapter:'}</span>
        </div>
        <select
          value={activeChapterId}
          onChange={(e) => setActiveChapterId(e.target.value)}
          className="bg-[#031413] text-xs text-white border border-[rgba(158,255,230,0.2)] rounded-xl px-3 py-2 focus:outline-none focus:border-[#5eead4] max-w-[200px] truncate"
        >
          <option value="all">{isAr ? 'كامل المجلد (جميع الفصول)' : 'All Chapters'}</option>
          {book.chapters.map((ch) => (
            <option key={ch.id} value={ch.id}>
              {ch.chapterNumber}. {isAr ? ch.titleAr : ch.titleEn}
            </option>
          ))}
        </select>
      </div>

      {/* ──────────────────────────────────────────────
          MAIN TWO-COLUMN LAYOUT: DESKTOP TOC & CONTENT
      ────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* ──────────────────────────────────────────────
            TABLE OF CONTENTS (TOC) SIDEBAR (Desktop Only)
        ────────────────────────────────────────────── */}
        <aside className="hidden lg:block lg:col-span-4 space-y-4 lg:sticky lg:top-24">
          <div className="p-5 rounded-3xl bg-[#06201e]/85 border border-[rgba(158,255,230,0.18)] backdrop-blur-md space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[rgba(158,255,230,0.12)]">
              <div className="flex items-center gap-2">
                <List size={16} className="text-[#5eead4]" />
                <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wider">
                  {isAr ? 'فهرس الفصول' : 'Table of Contents'}
                </h3>
              </div>
              <button
                onClick={() => setActiveChapterId('all')}
                className={`text-[11px] font-mono px-2 py-1 rounded-lg transition-colors cursor-pointer ${
                  activeChapterId === 'all'
                    ? 'bg-[#2dd4bf]/20 text-[#5eead4] font-bold'
                    : 'text-[#8db8b1] hover:text-white'
                }`}
              >
                {isAr ? 'عرض الكل' : 'View All'}
              </button>
            </div>

            {/* Chapter list */}
            <div className="space-y-1.5">
              {book.chapters.map((chapter) => {
                const isActive = activeChapterId === chapter.id;
                return (
                  <button
                    key={chapter.id}
                    onClick={() => setActiveChapterId(chapter.id)}
                    className={`w-full p-3 rounded-2xl text-start transition-all flex items-center justify-between gap-3 group cursor-pointer ${
                      isActive
                        ? 'bg-[#2dd4bf]/15 border border-[#2dd4bf]/40 text-[#5eead4] shadow-sm'
                        : 'bg-[#031413]/50 hover:bg-[#072422] border border-transparent hover:border-[rgba(158,255,230,0.14)] text-[#8db8b1] hover:text-[#eafffa]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span
                        className={`w-6 h-6 rounded-lg text-xs font-mono font-bold flex items-center justify-center shrink-0 ${
                          isActive
                            ? 'bg-[#5eead4]/30 text-white'
                            : 'bg-[#041a18] text-[#8db8b1] group-hover:text-white'
                        }`}
                      >
                        {chapter.chapterNumber}
                      </span>
                      <div className="min-w-0">
                        <div className="text-xs font-semibold truncate text-[#eafffa]">
                          {isAr ? chapter.titleAr : chapter.titleEn}
                        </div>
                        {chapter.subtitleEn && (
                          <div className="text-[10px] text-[#8db8b1]/70 truncate">
                            {isAr ? chapter.subtitleAr : chapter.subtitleEn}
                          </div>
                        )}
                      </div>
                    </div>

                    <span className="text-[10px] font-mono text-[#8db8b1]/60 shrink-0">
                      ~{chapter.readingTimeMinutes}m
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Other books in library */}
            <div className="pt-3 border-t border-[rgba(158,255,230,0.12)] space-y-2">
              <div className="text-[10px] font-mono text-[#8db8b1] uppercase">
                {isAr ? 'المجلدات الأخرى' : 'Other Guides'}
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {HANDBOOK_BOOKS.filter((b) => b.id !== book.id).map((other) => (
                  <button
                    key={other.id}
                    onClick={() => onSelectBook(other.id)}
                    className="p-2.5 rounded-xl bg-[#031413]/70 hover:bg-[#072422] border border-[rgba(158,255,230,0.12)] hover:border-[#5eead4]/40 text-start text-[11px] font-mono text-[#8db8b1] hover:text-white truncate transition-colors cursor-pointer"
                  >
                    <span className="text-[#5eead4] block font-bold text-[10px]">{other.bookNumber}</span>
                    <span className="truncate block">{isAr ? other.titleAr : other.titleEn}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </aside>

        {/* ──────────────────────────────────────────────
            MAIN CHAPTER READING CONTENT
        ────────────────────────────────────────────── */}
        <main className="lg:col-span-8 space-y-8 w-full min-w-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={`${book.id}-${activeChapterId}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="w-full min-w-0 overflow-hidden"
            >
              {book.id === 'guide-getting-started' && (
                <GuideGettingStartedContent activeChapterId={activeChapterId} />
              )}
              {book.id === 'guide-profile' && (
                <GuideProfileContent activeChapterId={activeChapterId} />
              )}
              {(book.id === 'guide-achievements' || book.id === 'book-achievements') && (
                <BookAchievementsContent activeChapterId={activeChapterId} />
              )}
              {(book.id === 'guide-rank-points' || book.id === 'book-rank-progression') && (
                <BookRankProgressionContent activeChapterId={activeChapterId} />
              )}
              {book.id === 'guide-applications' && (
                <GuideApplicationsContent activeChapterId={activeChapterId} />
              )}
              {book.id === 'guide-notifications' && (
                <GuideNotificationsContent activeChapterId={activeChapterId} />
              )}
              {book.id === 'guide-announcements' && (
                <GuideAnnouncementsContent activeChapterId={activeChapterId} />
              )}
              {book.id === 'guide-history' && (
                <GuideHistoryContent activeChapterId={activeChapterId} />
              )}
              {(book.id === 'guide-rules' || book.id === 'book-rules-procedures') && (
                <BookRulesProceduresContent activeChapterId={activeChapterId} />
              )}
              {(book.id === 'guide-administration' || book.id === 'book-administration') && (
                <BookAdministrationContent activeChapterId={activeChapterId} />
              )}
              {book.id === 'book-server-structure' && (
                <BookServerStructureContent activeChapterId={activeChapterId} />
              )}
            </motion.div>
          </AnimatePresence>

          {/* ──────────────────────────────────────────────
              CHAPTER & BOOK BOTTOM NAVIGATION
          ────────────────────────────────────────────── */}
          <div className="pt-8 border-t border-[rgba(158,255,230,0.14)] space-y-4">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              {/* Prev Chapter or Prev Book */}
              {prevChapter ? (
                <button
                  onClick={() => setActiveChapterId(prevChapter.id)}
                  className="min-h-[52px] p-4 rounded-2xl bg-[#06201e]/85 hover:bg-[#082a27] border border-[rgba(158,255,230,0.16)] hover:border-[#5eead4]/40 text-start transition-all group flex-1 cursor-pointer"
                >
                  <div className="flex items-center gap-2 text-[11px] font-mono text-[#8db8b1] mb-1">
                    <ArrowLeft size={14} className="rtl:rotate-180 text-[#5eead4] group-hover:-translate-x-1 rtl:group-hover:translate-x-1 transition-transform" />
                    <span>{isAr ? 'الفصل السابق' : 'Previous Chapter'}</span>
                  </div>
                  <div className="text-xs sm:text-sm font-bold text-white truncate">
                    {prevChapter.chapterNumber}. {isAr ? prevChapter.titleAr : prevChapter.titleEn}
                  </div>
                </button>
              ) : prevBook ? (
                <button
                  onClick={() => onSelectBook(prevBook.id)}
                  className="min-h-[52px] p-4 rounded-2xl bg-[#06201e]/85 hover:bg-[#082a27] border border-[rgba(158,255,230,0.16)] hover:border-[#5eead4]/40 text-start transition-all group flex-1 cursor-pointer"
                >
                  <div className="flex items-center gap-2 text-[11px] font-mono text-[#8db8b1] mb-1">
                    <ArrowLeft size={14} className="rtl:rotate-180 text-[#5eead4] group-hover:-translate-x-1 rtl:group-hover:translate-x-1 transition-transform" />
                    <span>{isAr ? 'المجلد السابق' : 'Previous Book'}</span>
                  </div>
                  <div className="text-xs sm:text-sm font-bold text-white truncate">
                    {prevBook.bookNumber} — {isAr ? prevBook.titleAr : prevBook.titleEn}
                  </div>
                </button>
              ) : (
                <div className="hidden sm:block flex-1" />
              )}

              {/* Next Chapter or Next Book */}
              {nextChapter ? (
                <button
                  onClick={() => setActiveChapterId(nextChapter.id)}
                  className="min-h-[52px] p-4 rounded-2xl bg-[#06201e]/85 hover:bg-[#082a27] border border-[rgba(158,255,230,0.16)] hover:border-[#5eead4]/40 text-end transition-all group flex-1 cursor-pointer"
                >
                  <div className="flex items-center justify-end gap-2 text-[11px] font-mono text-[#8db8b1] mb-1">
                    <span>{isAr ? 'الفصل التالي' : 'Next Chapter'}</span>
                    <ArrowRight size={14} className="rtl:rotate-180 text-[#5eead4] group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" />
                  </div>
                  <div className="text-xs sm:text-sm font-bold text-white truncate">
                    {nextChapter.chapterNumber}. {isAr ? nextChapter.titleAr : nextChapter.titleEn}
                  </div>
                </button>
              ) : nextBook ? (
                <button
                  onClick={() => onSelectBook(nextBook.id)}
                  className="min-h-[52px] p-4 rounded-2xl bg-[#06201e]/85 hover:bg-[#082a27] border border-[rgba(158,255,230,0.16)] hover:border-[#5eead4]/40 text-end transition-all group flex-1 cursor-pointer"
                >
                  <div className="flex items-center justify-end gap-2 text-[11px] font-mono text-[#8db8b1] mb-1">
                    <span>{isAr ? 'المجلد التالي' : 'Next Book'}</span>
                    <ArrowRight size={14} className="rtl:rotate-180 text-[#5eead4] group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" />
                  </div>
                  <div className="text-xs sm:text-sm font-bold text-white truncate">
                    {nextBook.bookNumber} — {isAr ? nextBook.titleAr : nextBook.titleEn}
                  </div>
                </button>
              ) : (
                <div className="hidden sm:block flex-1" />
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};
