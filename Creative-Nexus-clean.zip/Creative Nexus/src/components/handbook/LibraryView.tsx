import React, { useState, useMemo, useRef } from 'react';
import { 
  Search, 
  X,
  Clock, 
  ArrowRight, 
  BookOpen, 
  CheckCircle2, 
  ScrollText, 
  ShieldCheck, 
  Sparkles,
  BookMarked,
  Layers,
  Compass
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { HandbookBook, HandbookChapter } from '../../types/handbook';
import { HANDBOOK_BOOKS } from '../../data/handbookData';
import { useLanguage } from '../../context/LanguageContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { HiddenIraqiFlag } from '../easterEggs/HiddenIraqiFlag';

interface LibraryViewProps {
  onSelectBook: (bookId: string, chapterId?: string) => void;
  readProgressMap?: Record<string, number>;
}

interface MatchingChapterItem {
  chapter: HandbookChapter;
  book: HandbookBook;
  isDirectTitleMatch: boolean;
}

export const LibraryView: React.FC<LibraryViewProps> = ({ 
  onSelectBook,
  readProgressMap = {}
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';
  const [searchQuery, setSearchQuery] = useState('');
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Quick search filter presets
  const quickFilters = useMemo(() => [
    { labelEn: 'All', labelAr: 'الكل', query: '' },
    { labelEn: 'Official Rules', labelAr: 'القوانين الرسمية', query: isAr ? 'قوانين' : 'rules' },
    { labelEn: 'Ranks & Points', labelAr: 'الرتب والنقاط', query: isAr ? 'رتب' : 'rank' },
    { labelEn: 'Achievements', labelAr: 'الأوسمة', query: isAr ? 'أوسمة' : 'achievement' },
    { labelEn: 'Staff & Guardians', labelAr: 'طاقم الإدارة', query: isAr ? 'إدارة' : 'staff' },
    { labelEn: 'Getting Started', labelAr: 'البداية والتنقل', query: isAr ? 'البداية' : 'getting started' },
    { labelEn: 'History & Archive', labelAr: 'التاريخ والأرشيف', query: isAr ? 'تاريخ' : 'history' },
  ], [isAr]);

  const cleanQuery = searchQuery.toLowerCase().trim();

  // 1. Filter matching chapters across all books
  const matchingChapters = useMemo<MatchingChapterItem[]>(() => {
    if (!cleanQuery) return [];

    const results: MatchingChapterItem[] = [];

    HANDBOOK_BOOKS.forEach((book) => {
      const bookMatches = 
        book.titleEn.toLowerCase().includes(cleanQuery) ||
        book.titleAr.includes(cleanQuery) ||
        book.subtitleEn.toLowerCase().includes(cleanQuery) ||
        book.subtitleAr.includes(cleanQuery) ||
        book.tagEn.toLowerCase().includes(cleanQuery) ||
        book.tagAr.includes(cleanQuery);

      book.chapters.forEach((ch) => {
        const titleEnMatch = ch.titleEn.toLowerCase().includes(cleanQuery);
        const titleArMatch = ch.titleAr.includes(cleanQuery);
        const subtitleEnMatch = ch.subtitleEn?.toLowerCase().includes(cleanQuery) || false;
        const subtitleArMatch = ch.subtitleAr?.includes(cleanQuery) || false;

        if (titleEnMatch || titleArMatch || subtitleEnMatch || subtitleArMatch) {
          results.push({
            chapter: ch,
            book,
            isDirectTitleMatch: titleEnMatch || titleArMatch
          });
        } else if (bookMatches) {
          results.push({
            chapter: ch,
            book,
            isDirectTitleMatch: false
          });
        }
      });
    });

    return results;
  }, [cleanQuery]);

  // 2. Filter matching books (guides)
  const filteredBooks = useMemo(() => {
    if (!cleanQuery) return HANDBOOK_BOOKS;

    return HANDBOOK_BOOKS.filter((book) => {
      const bookMatches =
        book.titleEn.toLowerCase().includes(cleanQuery) ||
        book.titleAr.includes(cleanQuery) ||
        book.subtitleEn.toLowerCase().includes(cleanQuery) ||
        book.subtitleAr.includes(cleanQuery) ||
        book.descriptionEn.toLowerCase().includes(cleanQuery) ||
        book.descriptionAr.includes(cleanQuery) ||
        book.tagEn.toLowerCase().includes(cleanQuery) ||
        book.tagAr.includes(cleanQuery);

      const chapterMatches = book.chapters.some(
        (ch) =>
          ch.titleEn.toLowerCase().includes(cleanQuery) ||
          ch.titleAr.includes(cleanQuery) ||
          (ch.subtitleEn && ch.subtitleEn.toLowerCase().includes(cleanQuery)) ||
          (ch.subtitleAr && ch.subtitleAr.includes(cleanQuery))
      );

      return bookMatches || chapterMatches;
    });
  }, [cleanQuery]);

  const totalReadingMinutes = useMemo(() => {
    return HANDBOOK_BOOKS.reduce((sum, b) => 
      sum + b.chapters.reduce((cSum, ch) => cSum + ch.readingTimeMinutes, 0), 0
    );
  }, []);

  const totalChaptersCount = useMemo(() => {
    return HANDBOOK_BOOKS.reduce((sum, b) => sum + b.chapters.length, 0);
  }, []);

  const handleClearSearch = () => {
    setSearchQuery('');
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  };

  return (
    <div className="space-y-8 sm:space-y-10">
      {/* ──────────────────────────────────────────────
          TOP REAL-TIME SEARCH BAR & QUICK FILTERS
      ────────────────────────────────────────────── */}
      <section 
        id="guidebook-top-search-section"
        aria-label="Real-time Guidebook Search"
        className={`relative rounded-3xl p-5 sm:p-7 border shadow-[0_12px_40px_rgba(0,0,0,0.6)] backdrop-blur-xl overflow-hidden ${
          isMesopotamian
            ? 'mesopotamian-stone-bg border-amber-600/40'
            : 'bg-[#06201e]/90 border-[rgba(158,255,230,0.18)]'
        }`}
      >
        {/* Subtle decorative edge line */}
        <div className={`absolute top-0 inset-x-0 h-[2px] ${
          isMesopotamian
            ? 'bg-gradient-to-r from-transparent via-amber-400/80 to-transparent'
            : 'bg-gradient-to-r from-transparent via-[#5eead4]/80 to-transparent'
        }`} />
        <div className="absolute -top-16 -start-16 w-52 h-52 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-4">
          {/* Header row with search title and counter */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-[#2dd4bf]/15 border border-[#2dd4bf]/30 flex items-center justify-center text-[#5eead4]">
                <Search size={16} />
              </div>
              <div>
                <h2 className="text-sm sm:text-base font-bold text-[#eafffa] tracking-tight">
                  {isAr ? 'البحث اللحظي في فصول وأدلة السيرفر' : 'Real-Time Guidebook & Chapter Search'}
                </h2>
                <p className="text-[11px] text-[#8db8b1] font-sans">
                  {isAr 
                    ? 'اكتب للبحث المباشر في جميع عناوين الأدلة والفصول والأنظمة' 
                    : 'Search instantly across all guide titles, chapter headings, and system docs'}
                </p>
              </div>
            </div>

            {/* Results counter pill */}
            <div className="shrink-0">
              {cleanQuery ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#2dd4bf]/15 border border-[#2dd4bf]/30 text-xs font-mono font-semibold text-[#5eead4]">
                  <span className="w-2 h-2 rounded-full bg-[#5eead4] animate-pulse" />
                  {isAr
                    ? `تم العثور على ${matchingChapters.length} فصلاً في ${filteredBooks.length} أدلة`
                    : `Found ${matchingChapters.length} chapters across ${filteredBooks.length} guides`}
                </span>
              ) : (
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#031413] border border-[rgba(158,255,230,0.15)] text-xs font-mono text-[#8db8b1]">
                    <Layers size={12} className="text-[#5eead4]" />
                    <span>{HANDBOOK_BOOKS.length} {isAr ? 'أدلة' : 'Guides'}</span>
                    <span>•</span>
                    <span>{totalChaptersCount} {isAr ? 'فصلاً' : 'Chapters'}</span>
                  </span>
                  <HiddenIraqiFlag flagId="flag-codex-scroll" title="Codex marginalia seal" />
                </div>
              )}
            </div>
          </div>

          {/* Interactive Search Input */}
          <div className="relative">
            <Search 
              size={18} 
              className="absolute start-4 top-1/2 -translate-y-1/2 text-[#5eead4]/80 pointer-events-none" 
            />
            <input
              ref={searchInputRef}
              id="guidebook-realtime-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Escape') handleClearSearch();
              }}
              placeholder={
                isAr
                  ? 'ابحث بالاسم أو الموضوع (مثل: القوانين، نقاط الترقية، الأوسمة، الرتب، ديسكورد، الإدارة)...'
                  : 'Filter by title or topic (e.g., rules, rank points, achievements, staff, discord)...'
              }
              className="w-full ps-12 pe-24 py-3.5 sm:py-4 rounded-2xl bg-[#031413] border border-[rgba(158,255,230,0.2)] hover:border-[#5eead4]/40 focus:border-[#5eead4] text-sm sm:text-base text-[#eafffa] placeholder-[#8db8b1]/50 focus:outline-none focus:ring-2 focus:ring-[#5eead4]/20 transition-all shadow-inner"
            />

            {/* Clear button and keyboard shortcut cue */}
            <div className="absolute end-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
              {searchQuery && (
                <button
                  type="button"
                  onClick={handleClearSearch}
                  aria-label={isAr ? 'مسح البحث' : 'Clear search'}
                  className="p-1.5 rounded-lg bg-[#06201e] hover:bg-[#0a2e2a] text-[#8db8b1] hover:text-white transition-colors cursor-pointer"
                >
                  <X size={15} />
                </button>
              )}
              <span className="hidden sm:inline-block px-2 py-1 rounded-md bg-[#041a18] border border-[rgba(158,255,230,0.15)] text-[10px] font-mono text-[#8db8b1] select-none">
                ESC
              </span>
            </div>
          </div>

          {/* Quick Filter Tag Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-1 scrollbar-none">
            <span className="text-[11px] font-mono uppercase tracking-wider text-[#8db8b1] shrink-0 flex items-center gap-1">
              <Sparkles size={11} className="text-[#5eead4]" />
              <span>{isAr ? 'تصنيفات سريعة:' : 'Quick Filters:'}</span>
            </span>
            {quickFilters.map((filter, index) => {
              const isActive = (filter.query === '' && cleanQuery === '') || 
                (filter.query !== '' && cleanQuery.includes(filter.query.toLowerCase()));

              return (
                <button
                  key={index}
                  type="button"
                  onClick={() => {
                    if (isActive && filter.query !== '') {
                      setSearchQuery('');
                    } else {
                      setSearchQuery(filter.query);
                    }
                  }}
                  className={`shrink-0 px-3 py-1 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#2dd4bf]/25 text-[#5eead4] border border-[#5eead4]/60 shadow-[0_0_12px_rgba(94,234,212,0.25)] font-bold'
                      : 'bg-[#041a18] hover:bg-[#072422] text-[#8db8b1] hover:text-[#eafffa] border border-[rgba(158,255,230,0.12)] hover:border-[#2dd4bf]/30'
                  }`}
                >
                  {isAr ? filter.labelAr : filter.labelEn}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* ──────────────────────────────────────────────
          DIRECT MATCHING CHAPTERS RESULTS (When searching)
      ────────────────────────────────────────────── */}
      <AnimatePresence>
        {cleanQuery && (
          <motion.section
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            id="guidebook-matching-chapters-section"
            className="space-y-3"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BookOpen size={16} className="text-[#5eead4]" />
                <h3 className="text-sm sm:text-base font-bold text-[#eafffa] font-display tracking-tight">
                  {isAr ? 'الفصول المطابقة للبحث المباشر' : 'Matching Chapter Results'}
                </h3>
              </div>
              <span className="text-xs font-mono text-[#5eead4]">
                {matchingChapters.length} {isAr ? 'فصل' : 'chapters'}
              </span>
            </div>

            {matchingChapters.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {matchingChapters.map(({ chapter, book }) => (
                  <button
                    key={`${book.id}-${chapter.id}`}
                    onClick={() => onSelectBook(book.id, chapter.id)}
                    className="p-4 rounded-2xl bg-[#06201e]/90 hover:bg-[#082a27] border border-[rgba(158,255,230,0.16)] hover:border-[#5eead4]/50 transition-all text-start group flex flex-col justify-between gap-3 shadow-md relative overflow-hidden cursor-pointer"
                  >
                    <div className="space-y-2 relative z-10 w-full">
                      {/* Parent Guide Badge */}
                      <div className="flex items-center justify-between gap-2">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-[#2dd4bf]/15 border border-[#2dd4bf]/30 text-[10px] font-mono font-bold text-[#5eead4] truncate max-w-[75%]">
                          <span className="truncate">{isAr ? book.titleAr : book.titleEn}</span>
                        </span>
                        <span className="text-[10px] font-mono text-[#8db8b1] shrink-0">
                          {chapter.chapterNumber}
                        </span>
                      </div>

                      {/* Chapter Title */}
                      <h4 className="text-sm font-bold text-[#eafffa] group-hover:text-[#5eead4] transition-colors line-clamp-1">
                        {isAr ? chapter.titleAr : chapter.titleEn}
                      </h4>

                      {/* Subtitle / Excerpt */}
                      {(chapter.subtitleAr || chapter.subtitleEn) && (
                        <p className="text-xs text-[#8db8b1] font-sans line-clamp-1">
                          {isAr ? chapter.subtitleAr : chapter.subtitleEn}
                        </p>
                      )}
                    </div>

                    {/* Footer: Read time & jump action */}
                    <div className="pt-2 border-t border-[rgba(158,255,230,0.12)] flex items-center justify-between text-xs w-full">
                      <span className="inline-flex items-center gap-1 text-[11px] font-mono text-[#8db8b1]">
                        <Clock size={11} className="text-[#5eead4]" />
                        <span>~{chapter.readingTimeMinutes}m</span>
                      </span>
                      <span className="inline-flex items-center gap-1 text-[#5eead4] group-hover:text-white font-semibold text-xs">
                        <span>{isAr ? 'فتح الفصل' : 'Open Chapter'}</span>
                        <ArrowRight size={12} className="rtl:rotate-180 group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform" />
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="p-6 rounded-2xl bg-[#041a18]/70 border border-[rgba(158,255,230,0.14)] text-center space-y-2">
                <p className="text-sm text-[#8db8b1]">
                  {isAr 
                    ? `لم يتم العثور على فصول تحتوي مباشرة على "${searchQuery}". تفقد عناوين الأدلة أدناه.` 
                    : `No chapters directly match "${searchQuery}". Check the guide titles below.`}
                </p>
              </div>
            )}
          </motion.section>
        )}
      </AnimatePresence>

      {/* ──────────────────────────────────────────────
          HERO & PURPOSE BANNER (Collapsible / Compact when searching)
      ────────────────────────────────────────────── */}
      {!cleanQuery && (
        <div className={`relative rounded-3xl p-6 sm:p-10 border shadow-[0_12px_40px_rgba(0,0,0,0.6)] backdrop-blur-md overflow-hidden ${
          isMesopotamian
            ? 'mesopotamian-stone-bg border-amber-600/40'
            : 'bg-[#06201e]/85 border-[rgba(158,255,230,0.18)]'
        }`}>
          {/* Subtle accent border line */}
          <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-[#5eead4]/60 to-transparent" />
          
          <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
            <div className="space-y-4 max-w-3xl">
              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#2dd4bf]/15 border border-[#2dd4bf]/30 text-[#5eead4] text-xs font-semibold tracking-wider uppercase">
                <BookMarked size={14} className="text-[#5eead4]" />
                <span>{isAr ? 'دليل الموقع الرسمي' : 'OFFICIAL WEBSITE GUIDEBOOK'}</span>
              </div>

              <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight font-display">
                {isAr ? 'دليل مركز الإبداع — CN GUIDEBOOK' : 'CN GUIDEBOOK'}
              </h1>

              <p className="text-[#5eead4] font-medium text-sm sm:text-base font-sans">
                {isAr ? 'دليلك الشامل لموقع ومجتمع مركز الإبداع (CREATIVE NEXUS)' : 'Your guide to the CREATIVE NEXUS website'}
              </p>

              <p className="text-[#8db8b1] text-xs sm:text-sm leading-relaxed font-sans max-w-3xl">
                {isAr
                  ? 'الدليل الشامل لموقع ومجتمع مركز الإبداع (CREATIVE NEXUS). نظرة عامة واضحة ومباشرة تساعدك على استكشاف جميع أقسام الموقع وفهم كيفية تسجيل الدخول والملف الشخصي والأوسمة ونظام الرتب والنقاط والإعلانات وتاريخ المجتمع والقوانين الرسمية.'
                  : 'A comprehensive knowledge guide designed to help you understand and navigate the entire CREATIVE NEXUS website. Explore everything from getting started and member profiles to ranks, achievements, announcements, server history, and official guidelines.'}
              </p>

              {/* Quick Metrics Bar */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#041a18] border border-[rgba(158,255,230,0.15)] text-xs text-[#8db8b1] font-mono">
                  <ScrollText size={13} className="text-amber-400" />
                  <span>20 {isAr ? 'قانوناً رسمياً' : 'Official Rules'}</span>
                </span>
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#041a18] border border-[rgba(158,255,230,0.15)] text-xs text-[#8db8b1] font-mono">
                  <Clock size={13} className="text-emerald-400" />
                  <span>~{totalReadingMinutes} {isAr ? 'دقيقة قراءة' : 'min read'}</span>
                </span>
              </div>
            </div>

            {/* Quick Shortcuts to live features */}
            <div className="flex flex-col sm:flex-row lg:flex-col gap-2.5 w-full lg:w-72 shrink-0">
              <Link
                to="/rank-points"
                className="p-3.5 rounded-2xl bg-[#041a18] hover:bg-[#072522] border border-[rgba(158,255,230,0.14)] hover:border-amber-500/50 transition-all flex items-center justify-between group shadow-sm"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
                    <ShieldCheck size={16} />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white group-hover:text-amber-300 transition-colors">
                      {isAr ? 'خريطة تدرج الرتب' : 'Rank Progression'}
                    </div>
                    <div className="text-[10px] text-[#8db8b1] font-mono">Interactive 34 Ranks</div>
                  </div>
                </div>
                <ArrowRight size={14} className="text-[#8db8b1] group-hover:text-amber-400 transition-colors" />
              </Link>

              <Link
                to="/achievements"
                className="p-3.5 rounded-2xl bg-[#041a18] hover:bg-[#072522] border border-[rgba(158,255,230,0.14)] hover:border-[#5eead4]/50 transition-all flex items-center justify-between group shadow-sm"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-[#5eead4]">
                    <Sparkles size={16} />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white group-hover:text-[#5eead4] transition-colors">
                      {isAr ? 'مصفوفة الأوسمة' : 'Achievements'}
                    </div>
                    <div className="text-[10px] text-[#8db8b1] font-mono">40 Badges Matrix</div>
                  </div>
                </div>
                <ArrowRight size={14} className="text-[#8db8b1] group-hover:text-[#5eead4] transition-colors" />
              </Link>

              <button
                onClick={() => onSelectBook('guide-rules')}
                className="p-3.5 rounded-2xl bg-[#041a18] hover:bg-[#072522] border border-[rgba(158,255,230,0.14)] hover:border-rose-500/50 transition-all flex items-center justify-between group shadow-sm text-start cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
                    <ScrollText size={16} />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white group-hover:text-rose-300 transition-colors">
                      {isAr ? 'القوانين الرسمية العشرين' : 'The 20 Official Rules'}
                    </div>
                    <div className="text-[10px] text-[#8db8b1] font-mono">Direct & Clear</div>
                  </div>
                </div>
                <ArrowRight size={14} className="text-[#8db8b1] group-hover:text-rose-400 transition-colors" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ──────────────────────────────────────────────
          THE DIGITAL BOOK LIBRARY
      ────────────────────────────────────────────── */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Compass size={18} className="text-[#5eead4]" />
            <h2 className="text-lg sm:text-xl font-bold text-white font-display tracking-tight">
              {cleanQuery
                ? (isAr ? `الأدلة المطابقة للبحث (${filteredBooks.length})` : `Matching Guides (${filteredBooks.length})`)
                : (isAr ? 'المجلدات والأدلة الإرشادية' : 'All Guidebook Volumes')}
            </h2>
          </div>
          {cleanQuery && (
            <button
              onClick={handleClearSearch}
              className="text-xs text-[#5eead4] hover:text-white font-medium underline cursor-pointer"
            >
              {isAr ? 'عرض كافة الأدلة' : 'Show all guides'}
            </button>
          )}
        </div>

        {filteredBooks.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBooks.map((book) => {
              const bookTotalChapters = book.chapters.length;
              const bookReadTime = book.chapters.reduce((acc, ch) => acc + ch.readingTimeMinutes, 0);
              const progressPercent = readProgressMap[book.id] || 0;

              return (
                <div
                  key={book.id}
                  className={`group relative rounded-3xl p-6 border shadow-xl hover:shadow-[0_20px_50px_rgba(0,0,0,0.7)] transition-all duration-300 flex flex-col justify-between overflow-hidden backdrop-blur-md ${
                    isMesopotamian
                      ? 'mesopotamian-stone-bg border-amber-600/40'
                      : `bg-[#06201e]/85 border-[rgba(158,255,230,0.18)] hover:border-[#5eead4]/50`
                  }`}
                >
                  {/* Top ambient color glow */}
                  <div className={`absolute top-0 inset-x-0 h-28 bg-gradient-to-b ${book.gradient} pointer-events-none opacity-50 group-hover:opacity-90 transition-opacity`} />

                  <div className="relative z-10 space-y-4">
                    {/* Header: Book Number + Tag + Progress */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-1 rounded-xl bg-[#031413] border border-[rgba(158,255,230,0.2)] text-[#5eead4] font-mono text-xs font-bold">
                          {book.bookNumber}
                        </span>
                        <span className="text-[11px] font-mono text-[#8db8b1] uppercase tracking-wider">
                          {isAr ? book.tagAr : book.tagEn}
                        </span>
                      </div>

                      {progressPercent > 0 && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-mono text-[#5eead4]">
                          <CheckCircle2 size={12} />
                          <span>{progressPercent}%</span>
                        </span>
                      )}
                    </div>

                    {/* Title & Subtitle */}
                    <div className="space-y-1">
                      <h3 className="text-xl font-black text-white group-hover:text-[#5eead4] transition-colors font-display tracking-tight">
                        {isAr ? book.titleAr : book.titleEn}
                      </h3>
                      <p className="text-xs font-medium text-[#8db8b1] font-sans line-clamp-1">
                        {isAr ? book.subtitleAr : book.subtitleEn}
                      </p>
                    </div>

                    {/* Description */}
                    <p className="text-xs sm:text-sm text-[#eafffa]/80 leading-relaxed line-clamp-3">
                      {isAr ? book.descriptionAr : book.descriptionEn}
                    </p>

                    {/* Chapter Previews */}
                    <div className="space-y-1.5 pt-2 border-t border-[rgba(158,255,230,0.12)]">
                      <div className="text-[10px] font-mono uppercase tracking-wider text-[#8db8b1] pb-1">
                        {isAr ? 'فصول المجلد:' : 'Chapters:'}
                      </div>
                      {book.chapters.map((ch) => {
                        const isChapterMatched = cleanQuery && (
                          ch.titleEn.toLowerCase().includes(cleanQuery) ||
                          ch.titleAr.includes(cleanQuery) ||
                          (ch.subtitleEn && ch.subtitleEn.toLowerCase().includes(cleanQuery)) ||
                          (ch.subtitleAr && ch.subtitleAr.includes(cleanQuery))
                        );

                        return (
                          <button
                            key={ch.id}
                            onClick={() => onSelectBook(book.id, ch.id)}
                            className={`w-full text-start p-2 rounded-xl border flex items-center justify-between gap-2 text-xs transition-colors group/ch cursor-pointer ${
                              isChapterMatched
                                ? 'bg-[#2dd4bf]/20 border-[#5eead4]/50 text-white font-medium shadow-sm'
                                : 'bg-[#031413]/70 hover:bg-[#072422] border-transparent hover:border-[rgba(158,255,230,0.15)] text-[#8db8b1] hover:text-[#eafffa]'
                            }`}
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <span className={`text-[10px] font-mono shrink-0 ${isChapterMatched ? 'text-[#5eead4] font-bold' : 'text-[#5eead4]'}`}>
                                {ch.chapterNumber}
                              </span>
                              <span className={`truncate ${isChapterMatched ? 'text-white font-semibold' : 'text-[#8db8b1] group-hover/ch:text-white'}`}>
                                {isAr ? ch.titleAr : ch.titleEn}
                              </span>
                            </div>
                            <div className="flex items-center gap-1.5 shrink-0">
                              {isChapterMatched && (
                                <span className="px-1.5 py-0.5 rounded bg-[#5eead4]/20 text-[#5eead4] text-[9px] font-mono">
                                  {isAr ? 'مطابق' : 'Match'}
                                </span>
                              )}
                              <span className="text-[10px] font-mono text-[#8db8b1]">~{ch.readingTimeMinutes}m</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Footer: Read time & Enter button */}
                  <div className="relative z-10 pt-5 mt-5 border-t border-[rgba(158,255,230,0.12)] flex items-center justify-between gap-3">
                    <div className="flex items-center gap-1.5 text-xs font-mono text-[#8db8b1]">
                      <Clock size={13} className="text-[#5eead4]" />
                      <span>{bookTotalChapters} {isAr ? 'فصول' : 'sections'} • ~{bookReadTime}m</span>
                    </div>

                    <button
                      onClick={() => onSelectBook(book.id)}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#2dd4bf]/15 hover:bg-[#2dd4bf]/25 border border-[#2dd4bf]/30 text-[#5eead4] hover:text-white text-xs font-semibold transition-all group-hover:border-[#5eead4]/60 cursor-pointer"
                    >
                      <span>{isAr ? 'قراءة المجلد' : 'Read Guide'}</span>
                      <ArrowRight size={13} className="rtl:rotate-180 group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5 transition-transform" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-12 rounded-3xl bg-[#06201e]/80 border border-[rgba(158,255,230,0.16)] text-center space-y-4 max-w-lg mx-auto">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mx-auto">
              <Search size={24} />
            </div>
            <p className="text-sm text-[#8db8b1]">
              {isAr ? `لم يتم العثور على أي أدلة تطابق "${searchQuery}"` : `No guides found matching "${searchQuery}"`}
            </p>
            <button
              onClick={handleClearSearch}
              className="px-4 py-2 rounded-xl bg-[#2dd4bf]/15 text-[#5eead4] text-xs font-bold hover:bg-[#2dd4bf]/25 transition-colors cursor-pointer"
            >
              {isAr ? 'مسح البحث' : 'Clear search'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
