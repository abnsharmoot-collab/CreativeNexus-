import React from 'react';
import { Download, FileCode } from 'lucide-react';
import { useDownloadHtml } from '../../context/DownloadHtmlContext';
import { useLanguage } from '../../context/LanguageContext';
import { useEasterEggs } from '../../context/EasterEggContext';

interface DownloadHtmlButtonProps {
  variant?: 'nav' | 'footer' | 'prominent' | 'compact' | 'iconOnly';
  className?: string;
  showIcon?: boolean;
}

export const DownloadHtmlButton: React.FC<DownloadHtmlButtonProps> = ({
  variant = 'nav',
  className = '',
  showIcon = true,
}) => {
  const { openDownloadModal } = useDownloadHtml();
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  if (variant === 'nav') {
    return (
      <button
        type="button"
        onClick={openDownloadModal}
        title={isAr ? 'تحميل نسخة HTML للموقع (أوفلاين)' : 'Download Offline HTML Website Edition'}
        className={`h-7 sm:h-7.5 px-2.5 sm:px-3 rounded-full text-[10px] sm:text-[11px] font-bold tracking-tight flex items-center gap-1.5 transition-all duration-200 cursor-pointer border shadow-sm active:scale-95 group shrink-0 ${
          isMesopotamian
            ? 'bg-[#1a110a]/90 border-amber-500/40 text-amber-300 hover:text-white hover:border-amber-400 hover:bg-amber-500/20'
            : 'bg-[#021817]/90 border-teal-500/35 text-teal-300 hover:text-white hover:border-[#5eead4] hover:bg-[#5eead4]/15'
        } ${className}`}
      >
        {showIcon && <FileCode size={13} className="transition-transform group-hover:scale-110 shrink-0" />}
        <span className="whitespace-nowrap">{isAr ? 'نسخة HTML' : 'HTML Edition'}</span>
        <Download size={11} className="opacity-70 group-hover:opacity-100 shrink-0" />
      </button>
    );
  }

  if (variant === 'footer') {
    return (
      <button
        type="button"
        onClick={openDownloadModal}
        className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 border transition-all cursor-pointer shadow-sm active:scale-95 ${
          isMesopotamian
            ? 'bg-amber-950/40 border-amber-500/30 text-amber-300 hover:bg-amber-500/20 hover:border-amber-400'
            : 'bg-teal-950/40 border-teal-500/30 text-teal-300 hover:bg-teal-500/20 hover:border-[#5eead4]'
        } ${className}`}
      >
        <FileCode size={14} className="shrink-0" />
        <span>{isAr ? 'تحميل نسخة HTML المستقلة' : 'Download Standalone HTML Edition'}</span>
        <Download size={13} className="opacity-80 shrink-0" />
      </button>
    );
  }

  if (variant === 'prominent') {
    return (
      <button
        type="button"
        onClick={openDownloadModal}
        className={`px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg active:scale-95 ${
          isMesopotamian
            ? 'bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-500 text-stone-950 hover:brightness-110 shadow-[0_0_20px_rgba(245,158,11,0.35)]'
            : 'bg-gradient-to-r from-[#5eead4] via-teal-300 to-cyan-400 text-[#021817] hover:brightness-110 shadow-[0_0_20px_rgba(94,234,212,0.4)]'
        } ${className}`}
      >
        <FileCode size={16} className="shrink-0" />
        <span>{isAr ? 'تحميل نسخة HTML للموقع' : 'Download HTML Website'}</span>
        <Download size={14} className="shrink-0" />
      </button>
    );
  }

  if (variant === 'iconOnly') {
    return (
      <button
        type="button"
        onClick={openDownloadModal}
        title={isAr ? 'تحميل نسخة HTML للموقع' : 'Download HTML Website Edition'}
        className={`w-7.5 h-7.5 rounded-full border flex items-center justify-center transition-all cursor-pointer active:scale-95 ${
          isMesopotamian
            ? 'border-amber-500/40 text-amber-300 hover:text-white hover:bg-amber-500/20'
            : 'border-teal-500/40 text-teal-300 hover:text-white hover:bg-[#5eead4]/20'
        } ${className}`}
      >
        <FileCode size={13} />
      </button>
    );
  }

  // default / compact
  return (
    <button
      type="button"
      onClick={openDownloadModal}
      className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition-all cursor-pointer active:scale-95 ${
        isMesopotamian
          ? 'bg-amber-950/50 border-amber-500/40 text-amber-300 hover:bg-amber-500/20'
          : 'bg-teal-950/50 border-teal-500/40 text-teal-300 hover:bg-teal-500/20'
      } ${className}`}
    >
      <FileCode size={13} />
      <span>{isAr ? 'نسخة HTML' : 'HTML Version'}</span>
      <Download size={11} />
    </button>
  );
};
