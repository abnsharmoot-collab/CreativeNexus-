import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Download, 
  FileCode, 
  ExternalLink, 
  Copy, 
  Check, 
  X, 
  Sparkles, 
  Layers, 
  Globe, 
  ShieldCheck, 
  Palette,
  Flame,
  CheckCircle2
} from 'lucide-react';
import { useDownloadHtml } from '../../context/DownloadHtmlContext';
import { useLanguage } from '../../context/LanguageContext';
import { useCards } from '../../context/CardContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { 
  generateWebsiteHtml, 
  downloadWebsiteHtmlFile, 
  openWebsiteHtmlPreview 
} from '../../utils/htmlWebsiteGenerator';

export const DownloadHtmlModal: React.FC = () => {
  const { isDownloadModalOpen, closeDownloadModal } = useDownloadHtml();
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { allCards } = useCards();
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  const [selectedLang, setSelectedLang] = useState<'ar' | 'en'>(isAr ? 'ar' : 'en');
  const [selectedTheme, setSelectedTheme] = useState<'teal' | 'gold'>(isMesopotamian ? 'gold' : 'teal');
  const [isCopied, setIsCopied] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  if (!isDownloadModalOpen) return null;

  const handleDownload = () => {
    try {
      const link = document.createElement('a');
      link.href = '/api/download/index.html';
      link.setAttribute('download', 'index.html');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setDownloadSuccess('index.html');
      setTimeout(() => setDownloadSuccess(null), 5000);
    } catch (err) {
      console.warn('Direct download notice, using fallback generator:', err);
      const res = downloadWebsiteHtmlFile({
        language: selectedLang,
        theme: selectedTheme,
        customCards: allCards && allCards.length > 0 ? allCards : undefined,
      });
      setDownloadSuccess(res.filename);
      setTimeout(() => setDownloadSuccess(null), 5000);
    }
  };

  const handlePreview = () => {
    try {
      window.open('/standalone.html', '_blank');
    } catch {
      openWebsiteHtmlPreview({
        language: selectedLang,
        theme: selectedTheme,
        customCards: allCards && allCards.length > 0 ? allCards : undefined,
      });
    }
  };

  const handleCopyCode = async () => {
    try {
      const html = generateWebsiteHtml({
        language: selectedLang,
        theme: selectedTheme,
        customCards: allCards && allCards.length > 0 ? allCards : undefined,
      });
      await navigator.clipboard.writeText(html);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2500);
    } catch (err) {
      console.error('Copy error:', err);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={closeDownloadModal}
          className="fixed inset-0 bg-black/85 backdrop-blur-xl"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 15 }}
          transition={{ duration: 0.22, ease: 'easeOut' }}
          className={`relative w-full max-w-2xl rounded-3xl border shadow-2xl overflow-hidden p-6 sm:p-8 z-10 ${
            isMesopotamian
              ? 'bg-[#140c06]/98 border-amber-500/40 text-amber-100 shadow-[0_20px_70px_rgba(245,158,11,0.2)]'
              : 'bg-[#031514]/98 border-teal-500/35 text-teal-100 shadow-[0_20px_70px_rgba(94,234,212,0.18)]'
          }`}
        >
          {/* Top ambient illumination line */}
          <div 
            className={`absolute top-0 inset-x-0 h-1 bg-gradient-to-r ${
              isMesopotamian
                ? 'from-transparent via-amber-400 via-yellow-200 to-transparent'
                : 'from-transparent via-[#5eead4] via-cyan-300 to-transparent'
            }`} 
          />

          {/* Close button */}
          <button
            onClick={closeDownloadModal}
            className="absolute top-5 end-5 w-8 h-8 rounded-full border border-white/10 bg-white/5 hover:bg-white/15 text-slate-300 hover:text-white flex items-center justify-center transition-all cursor-pointer"
            aria-label="Close"
          >
            <X size={16} />
          </button>

          {/* Header */}
          <div className="flex items-start gap-4 mb-6">
            <div 
              className={`w-13 h-13 rounded-2xl flex items-center justify-center shrink-0 border ${
                isMesopotamian
                  ? 'bg-amber-950/70 border-amber-500/50 text-amber-300 shadow-[0_0_20px_rgba(245,158,11,0.3)]'
                  : 'bg-teal-950/70 border-teal-500/50 text-[#5eead4] shadow-[0_0_20px_rgba(94,234,212,0.3)]'
              }`}
            >
              <FileCode size={26} />
            </div>

            <div>
              <div className="flex items-center gap-2 mb-1">
                <span 
                  className={`text-[10px] font-mono uppercase tracking-widest px-2.5 py-0.5 rounded-full border font-bold ${
                    isMesopotamian 
                      ? 'bg-amber-500/15 border-amber-500/40 text-amber-300' 
                      : 'bg-teal-500/15 border-teal-500/40 text-[#5eead4]'
                  }`}
                >
                  {isAr ? 'نسخة الأرشيف المستقلة الكاملة' : 'Standalone Master Archive'}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">HTML5 / Single File</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                {isAr ? 'تحميل نسخة HTML للموقع' : 'Download HTML Website Edition'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-400 mt-1 leading-relaxed">
                {isAr 
                  ? 'ملف HTML كامل ومستقل 100% يضم كافة صفحات وأقسام الموقع، التاريخ، خزانة البطاقات، وفاحص البطاقات ثلاثي الأبعاد. يعمل فوراً بمجرد فتحه في أي متصفح دون اتصال بالإنترنت ودون الحاجة لأي خادم!'
                  : 'A 100% self-contained, standalone single-file HTML version containing all pages, server history, the complete card vault, and interactive 3D inspect modal. Works anywhere without an internet connection or server!'}
              </p>
            </div>
          </div>

          {/* Feature Highlights Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mb-6">
            <div className="p-3 rounded-2xl bg-black/40 border border-white/5 flex items-center gap-2.5">
              <ShieldCheck size={18} className="text-emerald-400 shrink-0" />
              <div className="text-[11px] leading-tight">
                <div className="font-bold text-white">{isAr ? 'يعمل بدون إنترنت' : '100% Offline'}</div>
                <div className="text-slate-400 text-[10px]">{isAr ? 'لا يحتاج خادم' : 'Zero server needed'}</div>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-black/40 border border-white/5 flex items-center gap-2.5">
              <Globe size={18} className="text-cyan-400 shrink-0" />
              <div className="text-[11px] leading-tight">
                <div className="font-bold text-white">{isAr ? 'ثنائي اللغة' : 'Bilingual'}</div>
                <div className="text-slate-400 text-[10px]">{isAr ? 'عربي و English' : 'Arabic & English'}</div>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-black/40 border border-white/5 flex items-center gap-2.5 col-span-2 sm:col-span-1">
              <Layers size={18} className="text-amber-400 shrink-0" />
              <div className="text-[11px] leading-tight">
                <div className="font-bold text-white">{isAr ? 'فاحص 3D تفاعلي' : '3D Card Inspector'}</div>
                <div className="text-slate-400 text-[10px]">{isAr ? 'قلب البطاقات والقدرات' : 'Interactive flips & stats'}</div>
              </div>
            </div>
          </div>

          {/* Customization Controls */}
          <div className="p-4 rounded-2xl bg-black/50 border border-white/10 mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            {/* Language Selection */}
            <div className="w-full sm:w-auto flex items-center justify-between sm:justify-start gap-3">
              <span className="text-xs font-bold text-slate-300">
                {isAr ? 'اللغة الافتراضية:' : 'Default Language:'}
              </span>
              <div className="flex rounded-xl p-0.5 bg-black/60 border border-white/10">
                <button
                  type="button"
                  onClick={() => setSelectedLang('ar')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    selectedLang === 'ar'
                      ? 'bg-amber-400 text-stone-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  العربية
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedLang('en')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    selectedLang === 'en'
                      ? 'bg-amber-400 text-stone-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  English
                </button>
              </div>
            </div>

            {/* Theme Selection */}
            <div className="w-full sm:w-auto flex items-center justify-between sm:justify-start gap-3">
              <span className="text-xs font-bold text-slate-300">
                {isAr ? 'المظهر الافتراضي:' : 'Default Theme:'}
              </span>
              <div className="flex rounded-xl p-0.5 bg-black/60 border border-white/10">
                <button
                  type="button"
                  onClick={() => setSelectedTheme('teal')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                    selectedTheme === 'teal'
                      ? 'bg-teal-400 text-stone-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-teal-400 border border-black" />
                  <span>{isAr ? 'زمردي' : 'Teal'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedTheme('gold')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                    selectedTheme === 'gold'
                      ? 'bg-amber-400 text-stone-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-amber-400 border border-black" />
                  <span>{isAr ? 'ذهب بابلي' : 'Gold'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Success Notification */}
          {downloadSuccess && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2"
            >
              <CheckCircle2 size={16} className="shrink-0" />
              <span>
                {isAr 
                  ? `تم تنزيل الملف بنجاح (${downloadSuccess})! يمكنك الآن فتحه مباشرة في أي متصفح.` 
                  : `Successfully downloaded (${downloadSuccess})! You can now double-click to open it in any browser.`}
              </span>
            </motion.div>
          )}

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            {/* Primary Download Button */}
            <button
              type="button"
              onClick={handleDownload}
              className={`flex-1 py-3 px-5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-98 cursor-pointer ${
                isMesopotamian
                  ? 'bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-500 text-stone-950 hover:brightness-110 shadow-[0_0_25px_rgba(245,158,11,0.4)]'
                  : 'bg-gradient-to-r from-[#5eead4] via-teal-300 to-cyan-400 text-[#021a17] hover:brightness-110 shadow-[0_0_25px_rgba(94,234,212,0.45)]'
              }`}
            >
              <Download size={18} />
              <span>{isAr ? 'تحميل ملف HTML الآن (.html)' : 'Download HTML File (.html)'}</span>
            </button>

            {/* Instant Live Preview Button */}
            <button
              type="button"
              onClick={handlePreview}
              className="py-3 px-4 rounded-2xl font-bold text-xs bg-white/10 hover:bg-white/15 border border-white/15 text-white flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-98"
              title="Preview in new tab without downloading"
            >
              <ExternalLink size={15} />
              <span>{isAr ? 'معاينة فورية' : 'Live Preview'}</span>
            </button>

            {/* Copy HTML Source */}
            <button
              type="button"
              onClick={handleCopyCode}
              className="py-3 px-4 rounded-2xl font-bold text-xs bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-98"
              title="Copy entire HTML code to clipboard"
            >
              {isCopied ? <Check size={15} className="text-emerald-400" /> : <Copy size={15} />}
              <span>{isCopied ? (isAr ? 'تم النسخ!' : 'Copied!') : (isAr ? 'نسخ الكود' : 'Copy Code')}</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
