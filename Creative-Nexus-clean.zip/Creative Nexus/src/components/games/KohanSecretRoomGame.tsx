import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Wind, 
  Droplet, 
  Apple, 
  X, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  AlertTriangle,
  ShieldAlert,
  ShieldCheck,
  DoorOpen,
  ArrowDown,
  Sparkles,
  Trophy,
  Brush,
  Clock,
  CheckCircle,
  CheckCircle2,
  PackageCheck
} from 'lucide-react';
import { easterEggSound } from '../../utils/easterEggAudio';
import { useLanguage } from '../../context/LanguageContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { useAuth } from '../../context/AuthContext';

interface KohanSecretRoomGameProps {
  isOpen: boolean;
  onClose: () => void;
}

type GameScene = 'UNDERGROUND' | 'OUTSIDE';
type GameStatus = 'START' | 'PLAYING' | 'CAUGHT' | 'GAME_OVER';

type ActionType = 
  | 'COLLECTING_WATER' 
  | 'WATER_COLLECTED'
  | 'TRANSPORTING_WATER' 
  | 'WATER_SECURED'
  | 'COLLECTING_FOOD' 
  | 'FOOD_COLLECTED'
  | 'TRANSPORTING_FOOD' 
  | 'FOOD_SECURED'
  | 'CLEANING_AIR' 
  | 'AIR_PATH_CLEANED'
  | null;

interface FloatingFeedback {
  id: number;
  text: string;
  color: string;
}

const STORAGE_KEY_BEST = 'kohan_saddam_survival_best_time';
const STORAGE_KEY_GAMES = 'kohan_saddam_survival_games';

// Hidden Progressive Difficulty System (Stages 1 to 5)
export type DifficultyStage = 1 | 2 | 3 | 4 | 5;

export interface StageConfig {
  stage: DifficultyStage;
  thresholdTime: number; // in seconds
  nameEn: string;
  nameAr: string;
  badgeColor: string;
  statusMoodEn: string;
  statusMoodAr: string;
  // Resource multipliers
  waterDrainMultiplier: number;
  foodDrainMultiplier: number;
  airDrainMultiplier: number;
  airflowDegradeRate: number; // % per 100ms - continuously decays, NEVER increases
  // Outside air recovery dynamics (diminishing returns, limited soft cap)
  outsideAirCeiling: number;  // max % air recoverable outside
  outsideAirGainRate: number; // base % per 100ms gain when far from ceiling
  // Clean air path temporary effectiveness (slows air drain while active)
  cleanEffectivenessDurationMin: number;
  cleanEffectivenessDurationMax: number;
  // Police behavior windows
  outsidePoliceWindowMin: number;
  outsidePoliceWindowMax: number;
  outsidePoliceSkew: number;              // Power-law skew towards min (higher = more fast surprise arrivals)
  outsidePoliceQuickAmbushChance: number; // Probability of immediate snap ambush roll
  undergroundClearMin: number;
  undergroundClearMax: number;
  undergroundClearSkew: number;           // Power-law skew towards min (higher = patrols return sooner)
  undergroundClearQuickChance: number;    // Probability of rapid back-to-back patrol return
  undergroundSearchMin: number;
  undergroundSearchMax: number;
  undergroundSearchSkew: number;          // Skew towards max (higher = police linger searching longer)
  escapeWindowMin: number;
  escapeWindowMax: number;
  escapeWindowSkew: number;               // Skew towards min (tighter emergency reaction window)
  // Resource replenishment times
  waterRegenMin: number;
  waterRegenMax: number;
  foodRegenMin: number;
  foodRegenMax: number;
  // Dynamic action duration adjustments (seconds added)
  actionDurationPadding: number;
}

export const STAGE_CONFIGS: Record<DifficultyStage, StageConfig> = {
  1: {
    stage: 1,
    thresholdTime: 0,
    nameEn: 'STAGE 1 — START',
    nameAr: 'المرحلة 1 — البداية',
    badgeColor: 'text-emerald-400 border-emerald-500/40 bg-emerald-950/60',
    statusMoodEn: 'STABLE CONDITIONS',
    statusMoodAr: 'أوضاع مستقرة',
    waterDrainMultiplier: 1.0,
    foodDrainMultiplier: 1.0,
    airDrainMultiplier: 1.0,
    airflowDegradeRate: 0.05,
    outsideAirCeiling: 65,
    outsideAirGainRate: 0.035,
    cleanEffectivenessDurationMin: 18,
    cleanEffectivenessDurationMax: 24,
    outsidePoliceWindowMin: 7.0,
    outsidePoliceWindowMax: 14.5,
    outsidePoliceSkew: 0.95,
    outsidePoliceQuickAmbushChance: 0.05,
    undergroundClearMin: 9.0,
    undergroundClearMax: 15.5,
    undergroundClearSkew: 0.95,
    undergroundClearQuickChance: 0.04,
    undergroundSearchMin: 3.5,
    undergroundSearchMax: 6.2,
    undergroundSearchSkew: 1.1,
    escapeWindowMin: 2.5,
    escapeWindowMax: 3.0,
    escapeWindowSkew: 1.05,
    waterRegenMin: 13,
    waterRegenMax: 19,
    foodRegenMin: 14,
    foodRegenMax: 21,
    actionDurationPadding: 0,
  },
  2: {
    stage: 2,
    thresholdTime: 45,
    nameEn: 'STAGE 2 — PRESSURE',
    nameAr: 'المرحلة 2 — تصاعد الضغط',
    badgeColor: 'text-amber-400 border-amber-500/40 bg-amber-950/60',
    statusMoodEn: 'PRESSURE IS RISING',
    statusMoodAr: 'الضغط يتصاعد',
    waterDrainMultiplier: 1.15,
    foodDrainMultiplier: 1.12,
    airDrainMultiplier: 1.15,
    airflowDegradeRate: 0.07,
    outsideAirCeiling: 60,
    outsideAirGainRate: 0.030,
    cleanEffectivenessDurationMin: 15,
    cleanEffectivenessDurationMax: 20,
    outsidePoliceWindowMin: 5.2,
    outsidePoliceWindowMax: 11.0,
    outsidePoliceSkew: 1.35,
    outsidePoliceQuickAmbushChance: 0.14,
    undergroundClearMin: 7.0,
    undergroundClearMax: 12.5,
    undergroundClearSkew: 1.25,
    undergroundClearQuickChance: 0.10,
    undergroundSearchMin: 4.0,
    undergroundSearchMax: 7.2,
    undergroundSearchSkew: 1.35,
    escapeWindowMin: 2.25,
    escapeWindowMax: 2.75,
    escapeWindowSkew: 1.25,
    waterRegenMin: 15,
    waterRegenMax: 22,
    foodRegenMin: 16,
    foodRegenMax: 24,
    actionDurationPadding: 0.15,
  },
  3: {
    stage: 3,
    thresholdTime: 95,
    nameEn: 'STAGE 3 — DANGER',
    nameAr: 'المرحلة 3 — خطر داهم',
    badgeColor: 'text-orange-400 border-orange-500/40 bg-orange-950/60',
    statusMoodEn: 'HIGH DANGER',
    statusMoodAr: 'خطر متزايد',
    waterDrainMultiplier: 1.30,
    foodDrainMultiplier: 1.25,
    airDrainMultiplier: 1.30,
    airflowDegradeRate: 0.09,
    outsideAirCeiling: 55,
    outsideAirGainRate: 0.025,
    cleanEffectivenessDurationMin: 12,
    cleanEffectivenessDurationMax: 16,
    outsidePoliceWindowMin: 3.8,
    outsidePoliceWindowMax: 8.5,
    outsidePoliceSkew: 1.75,
    outsidePoliceQuickAmbushChance: 0.24,
    undergroundClearMin: 5.2,
    undergroundClearMax: 10.0,
    undergroundClearSkew: 1.60,
    undergroundClearQuickChance: 0.18,
    undergroundSearchMin: 4.8,
    undergroundSearchMax: 8.4,
    undergroundSearchSkew: 1.65,
    escapeWindowMin: 2.05,
    escapeWindowMax: 2.50,
    escapeWindowSkew: 1.45,
    waterRegenMin: 17,
    waterRegenMax: 25,
    foodRegenMin: 18,
    foodRegenMax: 27,
    actionDurationPadding: 0.3,
  },
  4: {
    stage: 4,
    thresholdTime: 155,
    nameEn: 'STAGE 4 — CRITICAL',
    nameAr: 'المرحلة 4 — وضع حرج',
    badgeColor: 'text-rose-400 border-rose-500/40 bg-rose-950/60',
    statusMoodEn: 'CRITICAL THREAT',
    statusMoodAr: 'تهديد حرج',
    waterDrainMultiplier: 1.45,
    foodDrainMultiplier: 1.38,
    airDrainMultiplier: 1.45,
    airflowDegradeRate: 0.12,
    outsideAirCeiling: 50,
    outsideAirGainRate: 0.020,
    cleanEffectivenessDurationMin: 9,
    cleanEffectivenessDurationMax: 13,
    outsidePoliceWindowMin: 3.0,
    outsidePoliceWindowMax: 6.8,
    outsidePoliceSkew: 2.15,
    outsidePoliceQuickAmbushChance: 0.34,
    undergroundClearMin: 4.0,
    undergroundClearMax: 7.8,
    undergroundClearSkew: 2.00,
    undergroundClearQuickChance: 0.28,
    undergroundSearchMin: 5.5,
    undergroundSearchMax: 9.4,
    undergroundSearchSkew: 1.95,
    escapeWindowMin: 1.85,
    escapeWindowMax: 2.30,
    escapeWindowSkew: 1.65,
    waterRegenMin: 19,
    waterRegenMax: 28,
    foodRegenMin: 20,
    foodRegenMax: 30,
    actionDurationPadding: 0.45,
  },
  5: {
    stage: 5,
    thresholdTime: 225,
    nameEn: 'STAGE 5 — EXTREME',
    nameAr: 'المرحلة 5 — أقصى درجات الخطر',
    badgeColor: 'text-red-300 border-red-500/60 bg-red-950/80 animate-pulse',
    statusMoodEn: 'EXTREME PERIL',
    statusMoodAr: 'حصار خانق',
    waterDrainMultiplier: 1.60,
    foodDrainMultiplier: 1.50,
    airDrainMultiplier: 1.60,
    airflowDegradeRate: 0.15,
    outsideAirCeiling: 45,
    outsideAirGainRate: 0.018,
    cleanEffectivenessDurationMin: 7,
    cleanEffectivenessDurationMax: 10,
    outsidePoliceWindowMin: 2.5,
    outsidePoliceWindowMax: 5.2,
    outsidePoliceSkew: 2.65,
    outsidePoliceQuickAmbushChance: 0.44,
    undergroundClearMin: 3.0,
    undergroundClearMax: 6.0,
    undergroundClearSkew: 2.40,
    undergroundClearQuickChance: 0.38,
    undergroundSearchMin: 6.0,
    undergroundSearchMax: 10.5,
    undergroundSearchSkew: 2.30,
    escapeWindowMin: 1.70,
    escapeWindowMax: 2.10,
    escapeWindowSkew: 1.85,
    waterRegenMin: 22,
    waterRegenMax: 32,
    foodRegenMin: 23,
    foodRegenMax: 34,
    actionDurationPadding: 0.6,
  },
};

export const getStageConfig = (time: number): StageConfig => {
  if (time < 45) return STAGE_CONFIGS[1];
  if (time < 95) return STAGE_CONFIGS[2];
  if (time < 155) return STAGE_CONFIGS[3];
  if (time < 225) return STAGE_CONFIGS[4];
  return STAGE_CONFIGS[5];
};

/**
 * Samples a weighted random interval between [min, max].
 * - `skew`: Power-curve exponent for non-linear probability density.
 *   - skew = 1.0: Uniform distribution
 *   - skew > 1.0: Biased towards `min` (shorter intervals more frequent)
 *   - skew < 1.0: Biased towards `max` (longer intervals more frequent)
 * - `quickChance`: Probability [0, 1] of an unpredictable snap/rush arrival in the bottom 18% of [min, max].
 */
export const sampleWeightedInterval = (
  min: number,
  max: number,
  skew: number = 1.0,
  quickChance: number = 0
): number => {
  // Check for sudden rapid encounter / ambush roll
  if (quickChance > 0 && Math.random() < quickChance) {
    const ambushCeiling = min + (max - min) * 0.18;
    const val = min + Math.random() * (ambushCeiling - min);
    return Math.round(val * 100) / 100;
  }

  // Non-linear power distribution
  const u = Math.random();
  const factor = Math.pow(u, skew);
  const val = min + factor * (max - min);
  return Math.round(val * 100) / 100;
};

/**
 * Samples an interval weighted towards the upper bound (`max`).
 * Used for police search duration lingering longer in critical/extreme stages.
 */
export const sampleWeightedIntervalTowardsMax = (
  min: number,
  max: number,
  skew: number = 1.0
): number => {
  const u = Math.random();
  const factor = 1 - Math.pow(1 - u, skew);
  const val = min + factor * (max - min);
  return Math.round(val * 100) / 100;
};

// Base Balance Configuration
const CONFIG = {
  water: {
    maxCharges: 3,
    collectionDuration: 2.7, // seconds to harvest
    transportDuration: 3.1,  // seconds to haul underground
    amountAwarded: 28,       // +28% water
  },
  food: {
    maxCharges: 2,
    collectionDuration: 2.7, // seconds to harvest
    transportDuration: 3.1,  // seconds to haul underground
    amountAwarded: 28,       // +28% food
  },
  airClean: {
    cleanDuration: 4.6,      // seconds to clean
    minCooldown: 18,         // seconds before next clean allowed
    maxCooldown: 26,
  },
};

export const KohanSecretRoomGame: React.FC<KohanSecretRoomGameProps> = ({
  isOpen,
  onClose,
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { isAuthenticated, isOwner } = useAuth();
  const { recordGameBestSurvival, saddamBestTime, revealSecretArchive } = useEasterEggs();

  // Server authorization check
  const [isServerAuthorized, setIsServerAuthorized] = useState<boolean>(false);

  useEffect(() => {
    if (!isOpen) {
      setIsServerAuthorized(false);
      return;
    }

    if (isOwner) {
      setIsServerAuthorized(true);
      revealSecretArchive();
      return;
    }

    if (!isAuthenticated) {
      setIsServerAuthorized(false);
      return;
    }

    let isMounted = true;
    revealSecretArchive();

    fetch('/api/secret-game/access')
      .then((res) => {
        if (!res.ok) throw new Error('Unauthorized');
        return res.json();
      })
      .then((data) => {
        if (isMounted) {
          if (data.allowed) {
            setIsServerAuthorized(true);
          } else {
            onClose();
          }
        }
      })
      .catch(() => {
        if (isMounted) {
          onClose();
        }
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen, isAuthenticated, revealSecretArchive, onClose]);

  // If not authenticated or modal closed, render nothing
  if (!isAuthenticated || !isOpen) {
    return null;
  }

  // Audio mute state
  const [isMuted, setIsMuted] = useState(false);

  // Game state
  const [gameStatus, setGameStatus] = useState<GameStatus>('START');
  const [scene, setScene] = useState<GameScene>('UNDERGROUND');
  const [isPoliceSearching, setIsPoliceSearching] = useState(false);

  // Resources (0 - 100)
  const [air, setAir] = useState(100);
  const [water, setWater] = useState(100);
  const [food, setFood] = useState(100);
  const [airflow, setAirflow] = useState(100); // 0 - 100% condition of underground vent; decays over time, restored to 100% by cleaning
  const [cleanAirEffectivenessRemaining, setCleanAirEffectivenessRemaining] = useState(0);
  const [cleanAirEffectivenessTotal, setCleanAirEffectivenessTotal] = useState(20);

  // Resource availability & cooldowns
  const [waterCharges, setWaterCharges] = useState(CONFIG.water.maxCharges);
  const [waterRegenTotal, setWaterRegenTotal] = useState(20);
  const [waterRegenRemaining, setWaterRegenRemaining] = useState(0);

  const [foodCharges, setFoodCharges] = useState(CONFIG.food.maxCharges);
  const [foodRegenTotal, setFoodRegenTotal] = useState(24);
  const [foodRegenRemaining, setFoodRegenRemaining] = useState(0);

  const [airCleanCooldownTotal, setAirCleanCooldownTotal] = useState(24);
  const [airCleanCooldownRemaining, setAirCleanCooldownRemaining] = useState(0);

  // Hidden Police Arrival state (unpredictable, no visible countdown or warning timer)
  const [isBriefPoliceWarning, setIsBriefPoliceWarning] = useState(false);

  // Time-based Action State (visual progress only, NO numbers or seconds)
  const [currentAction, setCurrentAction] = useState<ActionType>(null);
  const [actionRemaining, setActionRemaining] = useState<number>(0);
  const [actionTotal, setActionTotal] = useState<number>(1);

  // Timers & Hidden Progressive Difficulty Stage
  const [survivalTime, setSurvivalTime] = useState(0); // in seconds
  const [difficultyStage, setDifficultyStage] = useState<DifficultyStage>(1);
  const [bestTime, setBestTime] = useState(0);
  const [gameOverReason, setGameOverReason] = useState<'air' | 'water' | 'food' | 'caught'>('air');

  // Floating notifications for feedback
  const [feedbacks, setFeedbacks] = useState<FloatingFeedback[]>([]);

  // Refs for loop tracking
  const survivalTimeRef = useRef(survivalTime);
  survivalTimeRef.current = survivalTime;
  const difficultyStageRef = useRef<DifficultyStage>(1);
  difficultyStageRef.current = difficultyStage;
  const currentActionRef = useRef(currentAction);
  currentActionRef.current = currentAction;
  const isPoliceSearchingRef = useRef(isPoliceSearching);
  isPoliceSearchingRef.current = isPoliceSearching;
  const isBriefPoliceWarningRef = useRef(isBriefPoliceWarning);
  isBriefPoliceWarningRef.current = isBriefPoliceWarning;
  const sceneRef = useRef(scene);
  sceneRef.current = scene;
  const cleanAirEffectivenessRemainingRef = useRef<number>(0);
  cleanAirEffectivenessRemainingRef.current = cleanAirEffectivenessRemaining;

  const outsidePoliceArrivalRef = useRef<number>(8);
  const undergroundPoliceTimerRef = useRef<number>(8);
  const undergroundPoliceDurationRef = useRef<number>(6);
  const briefWarningTimeoutRef = useRef<number | null>(null);
  const emergencyIntervalRef = useRef<number | null>(null);

  // Load best time on mount
  useEffect(() => {
    try {
      const savedBest = parseInt(localStorage.getItem(STORAGE_KEY_BEST) || '0', 10);
      const higher = Math.max(savedBest, saddamBestTime || 0);
      if (higher > 0) {
        setBestTime(higher);
      }
    } catch {
      // Non-blocking
    }
  }, [saddamBestTime]);

  // Reveal secret archive when opened
  useEffect(() => {
    if (isOpen) {
      try {
        revealSecretArchive();
      } catch {
        // Non-blocking
      }
    }
  }, [isOpen, revealSecretArchive]);

  // Audio helper
  const playSound = useCallback((fn: () => void) => {
    if (!isMuted) {
      try {
        fn();
      } catch {
        // Non-blocking
      }
    }
  }, [isMuted]);

  // Format seconds to MM:SS
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Add floating feedback animation
  const showFeedback = useCallback((text: string, color: string) => {
    const id = Date.now() + Math.random();
    setFeedbacks(prev => [...prev.slice(-3), { id, text, color }]);
    setTimeout(() => {
      setFeedbacks(prev => prev.filter(f => f.id !== id));
    }, 1300);
  }, []);

  // End game handler
  const triggerGameOver = useCallback((reason: 'air' | 'water' | 'food' | 'caught') => {
    setGameOverReason(reason);
    setGameStatus(reason === 'caught' ? 'CAUGHT' : 'GAME_OVER');
    setCurrentAction(null);
    playSound(() => easterEggSound.playGameOverSound());

    // Update best time if beaten
    const finalSecs = Math.floor(survivalTimeRef.current);
    if (finalSecs > 0) {
      recordGameBestSurvival(finalSecs);
    }
    setBestTime(prev => {
      if (finalSecs > prev) {
        try {
          localStorage.setItem(STORAGE_KEY_BEST, finalSecs.toString());
        } catch {
          // Ignore
        }
        return finalSecs;
      }
      return prev;
    });

    // Clear active emergency and warning timers
    if (emergencyIntervalRef.current) {
      window.clearInterval(emergencyIntervalRef.current);
      emergencyIntervalRef.current = null;
    }
    if (briefWarningTimeoutRef.current) {
      window.clearTimeout(briefWarningTimeoutRef.current);
      briefWarningTimeoutRef.current = null;
    }
    setIsBriefPoliceWarning(false);
  }, [playSound]);

  // Start / Restart Game
  const handleStartGame = () => {
    if (emergencyIntervalRef.current) {
      window.clearInterval(emergencyIntervalRef.current);
      emergencyIntervalRef.current = null;
    }
    if (briefWarningTimeoutRef.current) {
      window.clearTimeout(briefWarningTimeoutRef.current);
      briefWarningTimeoutRef.current = null;
    }

    setAir(100);
    setWater(100);
    setFood(100);
    setAirflow(100);
    setCleanAirEffectivenessRemaining(0);
    cleanAirEffectivenessRemainingRef.current = 0;

    setWaterCharges(CONFIG.water.maxCharges);
    setWaterRegenTotal(20);
    setWaterRegenRemaining(0);

    setFoodCharges(CONFIG.food.maxCharges);
    setFoodRegenTotal(24);
    setFoodRegenRemaining(0);

    setAirCleanCooldownTotal(24);
    setAirCleanCooldownRemaining(0);

    setSurvivalTime(0);
    setDifficultyStage(1);
    difficultyStageRef.current = 1;
    setScene('UNDERGROUND');
    setIsPoliceSearching(false);
    setIsBriefPoliceWarning(false);

    // Hidden weighted randomized initial timers based on Stage 1 (START)
    const initialStage = STAGE_CONFIGS[1];
    outsidePoliceArrivalRef.current = sampleWeightedInterval(
      initialStage.outsidePoliceWindowMin,
      initialStage.outsidePoliceWindowMax,
      initialStage.outsidePoliceSkew,
      initialStage.outsidePoliceQuickAmbushChance
    );
    undergroundPoliceTimerRef.current = sampleWeightedInterval(
      initialStage.undergroundClearMin,
      initialStage.undergroundClearMax,
      initialStage.undergroundClearSkew,
      initialStage.undergroundClearQuickChance
    );
    undergroundPoliceDurationRef.current = sampleWeightedIntervalTowardsMax(
      initialStage.undergroundSearchMin,
      initialStage.undergroundSearchMax,
      initialStage.undergroundSearchSkew
    );

    setCurrentAction(null);
    setActionRemaining(0);
    setFeedbacks([]);
    setGameStatus('PLAYING');
    playSound(() => easterEggSound.playPickupSound());

    try {
      const games = parseInt(localStorage.getItem(STORAGE_KEY_GAMES) || '0', 10);
      localStorage.setItem(STORAGE_KEY_GAMES, (games + 1).toString());
    } catch {
      // Non-blocking
    }
  };

  // Trigger sudden unexpected police event while outside (Unpredictable, no visible countdown or warning timer)
  const triggerPoliceEventOutside = useCallback(() => {
    // 1. Immediately cancel any running player action
    setCurrentAction(null);
    setActionRemaining(0);

    // 2. Very brief reaction cue warning: ⚠️ POLICE! (~500ms, no progress bar, no timer)
    setIsBriefPoliceWarning(true);
    playSound(() => easterEggSound.playAlertSound());

    // 3. Immediately after the brief warning: 🚨 POLICE SEARCHING
    if (briefWarningTimeoutRef.current) {
      window.clearTimeout(briefWarningTimeoutRef.current);
    }
    briefWarningTimeoutRef.current = window.setTimeout(() => {
      setIsBriefPoliceWarning(false);
      setIsPoliceSearching(true);

      // 4. Start caught emergency escape window (scaled by progressive difficulty stage with weighted urgency)
      const stageCfg = getStageConfig(survivalTimeRef.current);
      const escapeWindow = sampleWeightedInterval(
        stageCfg.escapeWindowMin,
        stageCfg.escapeWindowMax,
        stageCfg.escapeWindowSkew
      );
      const startTime = Date.now();
      if (emergencyIntervalRef.current) {
        window.clearInterval(emergencyIntervalRef.current);
      }
      emergencyIntervalRef.current = window.setInterval(() => {
        const elapsed = (Date.now() - startTime) / 1000;
        if (elapsed >= escapeWindow) {
          if (emergencyIntervalRef.current) {
            window.clearInterval(emergencyIntervalRef.current);
            emergencyIntervalRef.current = null;
          }
          triggerGameOver('caught');
        }
      }, 50);
    }, 500);
  }, [playSound, triggerGameOver]);

  // Main Survival & Police Simulation Tick (Every 100ms when PLAYING)
  useEffect(() => {
    if (gameStatus !== 'PLAYING') return;

    const interval = window.setInterval(() => {
      // Advance survival time & evaluate progressive difficulty stages
      setSurvivalTime(prevTime => {
        const nextTime = prevTime + 0.1;

        // Check if difficulty stage advances
        const newStageCfg = getStageConfig(nextTime);
        if (newStageCfg.stage !== difficultyStageRef.current) {
          const nextStage = newStageCfg.stage;
          difficultyStageRef.current = nextStage;
          setDifficultyStage(nextStage);

          playSound(() => easterEggSound.playAlertSound());
          if (nextStage === 2) {
            showFeedback(isAr ? '⚠️ الضغط يتصاعد... وتيرة التفتيش تزداد' : '⚠️ PRESSURE IS RISING... Patrols tightening', '#F59E0B');
          } else if (nextStage === 3) {
            showFeedback(isAr ? '⚠️ خطر داهم! دوريات مكثفة واستهلاك أسرع' : '⚠️ HIGH DANGER! Intensified patrols & drain', '#F97316');
          } else if (nextStage === 4) {
            showFeedback(isAr ? '🚨 وضع حرج! تقلص فترات الأمان بالخارج' : '🚨 CRITICAL THREAT! Safe windows shrinking', '#EF4444');
          } else if (nextStage === 5) {
            showFeedback(isAr ? '⚡ أقصى درجات الخطر! حصار خانق مستمر' : '⚡ EXTREME PERIL! Relentless pursuit', '#DC2626');
          }
        }

        if (Math.floor(nextTime) === 120 && Math.floor(prevTime) < 120) {
          recordGameBestSurvival(120);
          showFeedback(isAr ? '🏆 تم تحقيق هدف النجاة! (دقيقتان)' : '🏆 SURVIVAL GOAL ACHIEVED! (2:00)', '#FBBF24');
        }

        return nextTime;
      });

      const stageCfg = getStageConfig(survivalTimeRef.current);

      // --- 1. AIRFLOW CONTINUOUS DECAY ---
      // Airflow steadily decays over time as the ventilation pipe collects dust/debris.
      // Cleaning the airway restores airflow back to 100%.
      setAirflow(prev => Math.max(0, prev - stageCfg.airflowDegradeRate));

      // --- 2. CLEAN AIR PATH EFFECTIVENESS STATE ---
      if (cleanAirEffectivenessRemainingRef.current > 0) {
        cleanAirEffectivenessRemainingRef.current = Math.max(0, cleanAirEffectivenessRemainingRef.current - 0.1);
        setCleanAirEffectivenessRemaining(cleanAirEffectivenessRemainingRef.current);
      }

      // --- 3. AIR DYNAMICS ---
      if (sceneRef.current === 'OUTSIDE') {
        // When OUTSIDE: directly breathing open fresh air, air recovers
        setAir(prevAir => Math.min(100, prevAir + 0.3));
      } else {
        // When UNDERGROUND (Bunker):
        // 1) AIRFLOW > 75%: Clean airway allows fresh air to enter the bunker, making it increase slowly!
        // 2) AIRFLOW == 75%: Air stops moving (balanced/steady, delta = 0).
        // 3) AIRFLOW < 75%: Airflow insufficient, air starts getting lower (depleting), accelerating as airflow drops!
        setAir(prevAir => {
          if (airflow > 75) {
            // Air entering the place, making it increase slowly
            const headroom = (100 - prevAir) / 100;
            const flowRatioAbove = (airflow - 75) / 25; // 0 at 75%, 1 at 100%
            const airGain = (0.08 + flowRatioAbove * 0.14) * Math.max(0.15, headroom);
            return Math.min(100, prevAir + airGain);
          } else if (Math.abs(airflow - 75) < 0.2) {
            // When airflow gets to 75%: the air stops moving!
            return prevAir;
          } else {
            // When airflow gets lower than 75%: the air starts getting lower
            const flowDeficit = (75 - airflow) / 75; // 0 at 75%, 1.0 at 0%
            // Starts slow near 70% and accelerates as airflow drops towards 0%
            const baseAirDrain = (0.04 + Math.pow(flowDeficit, 1.35) * 0.34) * stageCfg.airDrainMultiplier;
            const next = prevAir - baseAirDrain;
            if (next <= 0) {
              triggerGameOver('air');
              return 0;
            }
            return next;
          }
        });
      }

      // --- WATER & FOOD DEPLETION ---
      setWater(prevWater => {
        const next = prevWater - 0.13 * stageCfg.waterDrainMultiplier;
        if (next <= 0) {
          triggerGameOver('water');
          return 0;
        }
        return next;
      });

      setFood(prevFood => {
        const next = prevFood - 0.10 * stageCfg.foodDrainMultiplier;
        if (next <= 0) {
          triggerGameOver('food');
          return 0;
        }
        return next;
      });

      // --- RESOURCE REGENERATION ---
      if (waterCharges === 0) {
        setWaterRegenRemaining(prevTime => {
          if (prevTime > 0.1) {
            return prevTime - 0.1;
          } else if (prevTime > 0) {
            setWaterCharges(CONFIG.water.maxCharges);
            playSound(() => easterEggSound.playPickupSound());
            showFeedback(isAr ? '💧 الماء متاح الآن في الخارج' : '💧 WATER REPLENISHED', '#38BDF8');
            return 0;
          }
          return 0;
        });
      }

      if (foodCharges === 0) {
        setFoodRegenRemaining(prevTime => {
          if (prevTime > 0.1) {
            return prevTime - 0.1;
          } else if (prevTime > 0) {
            setFoodCharges(CONFIG.food.maxCharges);
            playSound(() => easterEggSound.playPickupSound());
            showFeedback(isAr ? '🍎 الطعام متاح الآن في الخارج' : '🍎 FOOD REPLENISHED', '#F87171');
            return 0;
          }
          return 0;
        });
      }

      // Air cleaning cooldown tick
      setAirCleanCooldownRemaining(prev => Math.max(0, prev - 0.1));

      // --- POLICE SIMULATION ---
      if (sceneRef.current === 'OUTSIDE') {
        // Outside police trigger
        if (!isPoliceSearchingRef.current && !isBriefPoliceWarningRef.current) {
          outsidePoliceArrivalRef.current -= 0.1;
          if (outsidePoliceArrivalRef.current <= 0) {
            triggerPoliceEventOutside();
          }
        }
      } else {
        // Underground police simulation (patrols outside)
        if (isPoliceSearchingRef.current) {
          undergroundPoliceDurationRef.current -= 0.1;
          if (undergroundPoliceDurationRef.current <= 0) {
            setIsPoliceSearching(false);
            undergroundPoliceTimerRef.current = sampleWeightedInterval(
              stageCfg.undergroundClearMin,
              stageCfg.undergroundClearMax,
              stageCfg.undergroundClearSkew,
              stageCfg.undergroundClearQuickChance
            );
            playSound(() => easterEggSound.playPickupSound());
            showFeedback(isAr ? '🟢 غادرت دورية الشرطة، المنطقة آمنة' : '🟢 Police patrol cleared, area safe', '#10B981');
          }
        } else {
          undergroundPoliceTimerRef.current -= 0.1;
          if (undergroundPoliceTimerRef.current <= 0) {
            setIsPoliceSearching(true);
            undergroundPoliceDurationRef.current = sampleWeightedIntervalTowardsMax(
              stageCfg.undergroundSearchMin,
              stageCfg.undergroundSearchMax,
              stageCfg.undergroundSearchSkew
            );
            playSound(() => easterEggSound.playAlertSound());
          }
        }
      }
    }, 100);

    return () => window.clearInterval(interval);
  }, [gameStatus, airflow, waterCharges, foodCharges, isAr, playSound, showFeedback, triggerGameOver, triggerPoliceEventOutside]);

  // Start regeneration timers when charges hit 0 (Scaled by progressive difficulty)
  useEffect(() => {
    if (waterCharges === 0 && waterRegenRemaining === 0) {
      const stageCfg = getStageConfig(survivalTimeRef.current);
      const randDuration = stageCfg.waterRegenMin + Math.random() * (stageCfg.waterRegenMax - stageCfg.waterRegenMin);
      setWaterRegenTotal(randDuration);
      setWaterRegenRemaining(randDuration);
    }
  }, [waterCharges, waterRegenRemaining]);

  useEffect(() => {
    if (foodCharges === 0 && foodRegenRemaining === 0) {
      const stageCfg = getStageConfig(survivalTimeRef.current);
      const randDuration = stageCfg.foodRegenMin + Math.random() * (stageCfg.foodRegenMax - stageCfg.foodRegenMin);
      setFoodRegenTotal(randDuration);
      setFoodRegenRemaining(randDuration);
    }
  }, [foodCharges, foodRegenRemaining]);

  // Active Action Progress Loop (Tick every 100ms when an action is active and not interrupted by police)
  useEffect(() => {
    if (gameStatus !== 'PLAYING' || !currentAction || isPoliceSearching || isBriefPoliceWarning) return;

    const interval = window.setInterval(() => {
      setActionRemaining(prev => {
        const next = prev - 0.1;
        if (next <= 0) {
          // Action Phase Complete!
          handleActionPhaseComplete(currentActionRef.current);
          return 0;
        }
        return next;
      });
    }, 100);

    return () => window.clearInterval(interval);
  }, [gameStatus, currentAction, isPoliceSearching, isBriefPoliceWarning]);

  // Handle phase progression for player actions (With discrete visual phases & replayable jitter)
  const handleActionPhaseComplete = (action: ActionType) => {
    if (action === 'COLLECTING_WATER') {
      // 1. Water collection complete -> show brief WATER COLLECTED feedback -> Begin Transport!
      setCurrentAction('WATER_COLLECTED');
      playSound(() => easterEggSound.playPickupSound());
      showFeedback(isAr ? '💧 تم جمع الماء! جارٍ النقل للمخبأ...' : '💧 WATER COLLECTED! Taking inside...', '#38BDF8');
      
      setTimeout(() => {
        if (!isPoliceSearchingRef.current && !isBriefPoliceWarningRef.current && sceneRef.current === 'OUTSIDE') {
          const stageCfg = getStageConfig(survivalTimeRef.current);
          const duration = CONFIG.water.transportDuration + stageCfg.actionDurationPadding + (Math.random() * 0.3 - 0.15);
          setCurrentAction('TRANSPORTING_WATER');
          setActionTotal(duration);
          setActionRemaining(duration);
        }
      }, 350);
    } 
    else if (action === 'TRANSPORTING_WATER') {
      // 2. Transport finished -> WATER SECURED! Award water!
      setCurrentAction('WATER_SECURED');
      setWater(prev => Math.min(100, prev + CONFIG.water.amountAwarded));
      playSound(() => easterEggSound.playPickupSound());
      showFeedback(isAr ? `💧 تم تأمين الماء (+${CONFIG.water.amountAwarded})` : `💧 WATER SECURED (+${CONFIG.water.amountAwarded})`, '#38BDF8');
      
      setTimeout(() => {
        setCurrentAction(null);
        setActionRemaining(0);
      }, 400);
    } 
    else if (action === 'COLLECTING_FOOD') {
      // 1. Food collection complete -> show brief FOOD COLLECTED feedback -> Begin Transport!
      setCurrentAction('FOOD_COLLECTED');
      playSound(() => easterEggSound.playPickupSound());
      showFeedback(isAr ? '🍎 تم جمع الطعام! جارٍ النقل للمخبأ...' : '🍎 FOOD COLLECTED! Taking inside...', '#F87171');
      
      setTimeout(() => {
        if (!isPoliceSearchingRef.current && !isBriefPoliceWarningRef.current && sceneRef.current === 'OUTSIDE') {
          const stageCfg = getStageConfig(survivalTimeRef.current);
          const duration = CONFIG.food.transportDuration + stageCfg.actionDurationPadding + (Math.random() * 0.3 - 0.15);
          setCurrentAction('TRANSPORTING_FOOD');
          setActionTotal(duration);
          setActionRemaining(duration);
        }
      }, 350);
    } 
    else if (action === 'TRANSPORTING_FOOD') {
      // 2. Transport finished -> FOOD SECURED! Award food!
      setCurrentAction('FOOD_SECURED');
      setFood(prev => Math.min(100, prev + CONFIG.food.amountAwarded));
      playSound(() => easterEggSound.playPickupSound());
      showFeedback(isAr ? `🍎 تم تأمين الطعام (+${CONFIG.food.amountAwarded})` : `🍎 FOOD SECURED (+${CONFIG.food.amountAwarded})`, '#F87171');
      
      setTimeout(() => {
        setCurrentAction(null);
        setActionRemaining(0);
      }, 400);
    } 
    else if (action === 'CLEANING_AIR') {
      // Cleaning finished -> Airway restored to 100%!
      // Fresh air will now enter the bunker and slowly increase the air level.
      setCurrentAction('AIR_PATH_CLEANED');
      setAirflow(100);

      const stageCfg = getStageConfig(survivalTimeRef.current);
      const cleanDuration = stageCfg.cleanEffectivenessDurationMin + 
        Math.random() * (stageCfg.cleanEffectivenessDurationMax - stageCfg.cleanEffectivenessDurationMin);
      setCleanAirEffectivenessTotal(cleanDuration);
      setCleanAirEffectivenessRemaining(cleanDuration);
      cleanAirEffectivenessRemainingRef.current = cleanDuration;

      const randCooldown = CONFIG.airClean.minCooldown + (stageCfg.stage - 1) * 1.5 + 
        Math.random() * (CONFIG.airClean.maxCooldown - CONFIG.airClean.minCooldown);
      setAirCleanCooldownTotal(randCooldown);
      setAirCleanCooldownRemaining(randCooldown);
      playSound(() => easterEggSound.playCleanSound());
      showFeedback(
        isAr 
          ? '💨 تم تنظيف مسار الهواء! تدفق الهواء 100% والهواء يدخل الآن ويرتفع ببطء' 
          : '💨 AIRWAY CLEANED! Airflow 100% — fresh air entering and increasing slowly',
        '#34D399'
      );
      
      setTimeout(() => {
        setCurrentAction(null);
        setActionRemaining(0);
      }, 450);
    }
  };

  // Action: Go Out (Underground -> Outside)
  const handleGoOut = () => {
    if (isPoliceSearching || isBriefPoliceWarning) {
      showFeedback(isAr ? '⚠️ الشرطة في الخارج! لا يمكنك الخروج' : '⚠️ POLICE OUTSIDE! CANNOT EXIT', '#EF4444');
      playSound(() => easterEggSound.playAlertSound());
      return;
    }
    setScene('OUTSIDE');
    setCurrentAction(null);
    setActionRemaining(0);
    setIsBriefPoliceWarning(false);

    // Set hidden unpredictable outside search timer based on current difficulty stage using weighted random intervals
    const stageCfg = getStageConfig(survivalTimeRef.current);
    outsidePoliceArrivalRef.current = sampleWeightedInterval(
      stageCfg.outsidePoliceWindowMin,
      stageCfg.outsidePoliceWindowMax,
      stageCfg.outsidePoliceSkew,
      stageCfg.outsidePoliceQuickAmbushChance
    );

    showFeedback(isAr ? 'أنت على السطح • تعافٍ تدريجي محدود للهواء' : 'On Surface • Gradual air recovery', '#38BDF8');
    playSound(() => easterEggSound.playJumpSound());
  };

  // Action: Return Inside (Outside -> Underground)
  // Cancels any running action without awarding incomplete resources
  const handleReturnInside = () => {
    if (emergencyIntervalRef.current) {
      window.clearInterval(emergencyIntervalRef.current);
      emergencyIntervalRef.current = null;
    }
    if (briefWarningTimeoutRef.current) {
      window.clearTimeout(briefWarningTimeoutRef.current);
      briefWarningTimeoutRef.current = null;
    }

    const wasThreat = isPoliceSearching || isBriefPoliceWarning;
    setIsBriefPoliceWarning(false);
    const stageCfg = getStageConfig(survivalTimeRef.current);

    // If escaping from police, police keep searching outside for a randomized hidden duration (longer in higher stages)
    if (wasThreat) {
      setIsPoliceSearching(true);
      undergroundPoliceDurationRef.current = sampleWeightedIntervalTowardsMax(
        stageCfg.undergroundSearchMin,
        stageCfg.undergroundSearchMax,
        stageCfg.undergroundSearchSkew
      );
      showFeedback(
        isAr ? 'نجوت في اللحظة الأخيرة!' : 'Escaped in the nick of time!',
        '#10B981'
      );
    } else {
      setIsPoliceSearching(false);
      undergroundPoliceTimerRef.current = sampleWeightedInterval(
        stageCfg.undergroundClearMin,
        stageCfg.undergroundClearMax,
        stageCfg.undergroundClearSkew,
        stageCfg.undergroundClearQuickChance
      );
      if (currentAction) {
        showFeedback(
          isAr ? 'تم إلغاء المهمة والعودة بأمان' : 'Action cancelled. Returned safely',
          '#F59E0B'
        );
      } else {
        showFeedback(isAr ? 'تم النزول بأمان للمخبأ' : 'Safely Underground', '#10B981');
      }
    }

    setCurrentAction(null);
    setActionRemaining(0);
    setScene('UNDERGROUND');
    playSound(() => easterEggSound.playJumpSound());
  };

  // Start Collecting Water (Time-based, Limited uses, scaled with difficulty & slight random jitter)
  const handleStartGetWater = () => {
    if (currentAction || waterCharges <= 0 || isPoliceSearching || isBriefPoliceWarning) return;

    // Deduct 1 available use
    setWaterCharges(prev => Math.max(0, prev - 1));
    setCurrentAction('COLLECTING_WATER');
    const stageCfg = getStageConfig(survivalTimeRef.current);
    const duration = CONFIG.water.collectionDuration + stageCfg.actionDurationPadding + (Math.random() * 0.3 - 0.15);
    setActionTotal(duration);
    setActionRemaining(duration);
    playSound(() => easterEggSound.playPickupSound());
  };

  // Start Collecting Food (Time-based, Limited uses, scaled with difficulty & slight random jitter)
  const handleStartGetFood = () => {
    if (currentAction || foodCharges <= 0 || isPoliceSearching || isBriefPoliceWarning) return;

    // Deduct 1 available use
    setFoodCharges(prev => Math.max(0, prev - 1));
    setCurrentAction('COLLECTING_FOOD');
    const stageCfg = getStageConfig(survivalTimeRef.current);
    const duration = CONFIG.food.collectionDuration + stageCfg.actionDurationPadding + (Math.random() * 0.3 - 0.15);
    setActionTotal(duration);
    setActionRemaining(duration);
    playSound(() => easterEggSound.playPickupSound());
  };

  // Start Cleaning Air Path (Time-based, Cooldown-based, scaled with difficulty & slight random jitter)
  const handleStartCleanAirPath = () => {
    if (currentAction || airCleanCooldownRemaining > 0 || isPoliceSearching || isBriefPoliceWarning) return;

    setCurrentAction('CLEANING_AIR');
    const stageCfg = getStageConfig(survivalTimeRef.current);
    const duration = CONFIG.airClean.cleanDuration + stageCfg.actionDurationPadding * 1.2 + (Math.random() * 0.4 - 0.2);
    setActionTotal(duration);
    setActionRemaining(duration);
    playSound(() => easterEggSound.playCleanSound());
  };

  if (!isOpen) return null;

  const currentStageConfig = STAGE_CONFIGS[difficultyStage];

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-md overflow-hidden select-none"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-3xl mesopotamian-stone-bg border-2 border-amber-600/50 rounded-3xl shadow-[0_25px_80px_rgba(0,0,0,0.95),0_0_50px_rgba(217,119,6,0.18)] overflow-hidden flex flex-col max-h-[96vh]"
        onClick={e => e.stopPropagation()}
        dir={isAr ? 'rtl' : 'ltr'}
      >
        {/* Subtle decorative antique gold inner border */}
        <div className="absolute inset-1 rounded-[22px] border border-amber-500/15 pointer-events-none z-30" />

        {/* Top Header Bar */}
        <div className="relative flex items-center justify-between px-3.5 py-2.5 bg-[#170f0a] border-b border-amber-600/40 text-xs font-mono z-20">
          <div className="flex items-center gap-2">
            <span className="text-amber-500/70 text-sm hidden sm:inline select-none">𒀭</span>
            <span className="font-bold mesopotamian-gold-text tracking-widest text-xs sm:text-sm font-serif">
              {isAr ? 'لعبة سرية // خزانة بابل' : 'SECRET GAME // BABYLON VAULT'}
            </span>
            {gameStatus !== 'START' && (
              <span className="px-2 py-0.5 rounded-md bg-[#24170d] border border-amber-500/40 text-amber-300 font-bold text-xs ms-1 shadow-inner">
                {formatTime(survivalTime)}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {isBriefPoliceWarning ? (
              <span className="px-2.5 py-0.5 rounded-md bg-red-950/90 border border-amber-400 text-amber-300 font-bold text-[10px] animate-pulse shadow-md">
                {isAr ? '⚠️ الشرطة!' : '⚠️ POLICE!'}
              </span>
            ) : isPoliceSearching ? (
              <span className="px-2.5 py-0.5 rounded-md bg-red-950/90 border border-red-500 text-red-300 font-bold text-[10px] animate-pulse shadow-md">
                {isAr ? '🚨 تفتيش' : '🚨 POLICE'}
              </span>
            ) : null}

            <button
              type="button"
              onClick={() => setIsMuted(!isMuted)}
              className="p-1.5 rounded-lg bg-[#22160d] border border-amber-600/30 text-amber-300/80 hover:text-amber-100 hover:border-amber-500/60 transition-colors cursor-pointer"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg bg-[#22160d] border border-amber-600/30 text-amber-300/80 hover:text-red-400 hover:border-red-500/60 transition-colors cursor-pointer"
              title="Close"
            >
              <X size={15} />
            </button>
          </div>
        </div>

        {/* 4 Survival Resource Bars: AIR, WATER, FOOD, AIRFLOW */}
        {gameStatus !== 'START' && (
          <div className="bg-[#120c08] border-b border-amber-600/30 px-3.5 py-2.5 z-20">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-w-2xl mx-auto">
              {/* AIR */}
              <div className="flex flex-col gap-1 font-mono">
                <div className="flex justify-between text-[11px] font-bold">
                  <span className="text-sky-300 flex items-center gap-1">
                    <span>{isAr ? 'هواء' : 'AIR'}</span>
                    {scene === 'UNDERGROUND' && (
                      <span className={`text-[9px] font-bold ${airflow > 75 ? 'text-emerald-400' : Math.abs(airflow - 75) < 0.2 ? 'text-amber-300' : 'text-red-400'}`}>
                        {airflow > 75 ? '▲' : Math.abs(airflow - 75) < 0.2 ? '■' : '▼'}
                      </span>
                    )}
                  </span>
                  <span className="text-amber-200/80">{Math.round(air)}%</span>
                </div>
                <div className="w-full bg-[#080503] h-2.5 rounded-full overflow-hidden p-0.5 border border-amber-600/30 shadow-inner">
                  <div 
                    className={`h-full rounded-full transition-all duration-150 ${
                      air > 35 ? 'bg-gradient-to-r from-sky-600 to-cyan-400' : air > 15 ? 'bg-gradient-to-r from-amber-600 to-amber-400' : 'bg-red-500 animate-pulse'
                    }`}
                    style={{ width: `${Math.max(0, air)}%` }}
                  />
                </div>
              </div>

              {/* WATER */}
              <div className="flex flex-col gap-1 font-mono">
                <div className="flex justify-between text-[11px] font-bold">
                  <span className="text-cyan-300">{isAr ? 'ماء' : 'WATER'}</span>
                  <span className="text-amber-200/80">{Math.round(water)}%</span>
                </div>
                <div className="w-full bg-[#080503] h-2.5 rounded-full overflow-hidden p-0.5 border border-amber-600/30 shadow-inner">
                  <div 
                    className={`h-full rounded-full transition-all duration-150 ${
                      water > 35 ? 'bg-gradient-to-r from-cyan-600 to-teal-400' : water > 15 ? 'bg-gradient-to-r from-amber-600 to-amber-400' : 'bg-red-500 animate-pulse'
                    }`}
                    style={{ width: `${Math.max(0, water)}%` }}
                  />
                </div>
              </div>

              {/* FOOD */}
              <div className="flex flex-col gap-1 font-mono">
                <div className="flex justify-between text-[11px] font-bold">
                  <span className="text-amber-300">{isAr ? 'طعام' : 'FOOD'}</span>
                  <span className="text-amber-200/80">{Math.round(food)}%</span>
                </div>
                <div className="w-full bg-[#080503] h-2.5 rounded-full overflow-hidden p-0.5 border border-amber-600/30 shadow-inner">
                  <div 
                    className={`h-full rounded-full transition-all duration-150 ${
                      food > 35 ? 'bg-gradient-to-r from-amber-600 to-yellow-400' : food > 15 ? 'bg-gradient-to-r from-amber-700 to-amber-500' : 'bg-red-500 animate-pulse'
                    }`}
                    style={{ width: `${Math.max(0, food)}%` }}
                  />
                </div>
              </div>

              {/* AIRFLOW */}
              <div className="flex flex-col gap-1 font-mono">
                <div className="flex justify-between text-[11px] font-bold">
                  <span className="text-emerald-300 flex items-center gap-1">
                    <span>{isAr ? 'تهوية' : 'AIRFLOW'}</span>
                    <span className="text-[9px] font-normal text-amber-200/70">
                      {airflow > 75 
                        ? (isAr ? '(يدخل ↑)' : '(In ↑)') 
                        : Math.abs(airflow - 75) < 0.2 
                        ? (isAr ? '(متوقف)' : '(Stop)') 
                        : (isAr ? '(ينخفض ↓)' : '(Down ↓)')}
                    </span>
                  </span>
                  <span className={`${airflow > 75 ? 'text-emerald-300' : airflow >= 50 ? 'text-amber-300' : 'text-red-400'}`}>
                    {Math.round(airflow)}%
                  </span>
                </div>
                <div className="w-full bg-[#080503] h-2.5 rounded-full overflow-hidden p-0.5 border border-amber-600/30 shadow-inner">
                  <div 
                    className={`h-full rounded-full transition-all duration-150 ${
                      airflow > 75 ? 'bg-gradient-to-r from-emerald-600 to-teal-400' : airflow >= 50 ? 'bg-gradient-to-r from-amber-600 to-amber-400' : 'bg-red-500'
                    }`}
                    style={{ width: `${Math.max(0, airflow)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Main Visual Display Area */}
        <div className="relative flex-1 bg-black min-h-[360px] sm:min-h-[420px] flex items-center justify-center overflow-hidden">
          {/* Floating Feedbacks */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 pointer-events-none flex flex-col items-center gap-1">
            <AnimatePresence>
              {feedbacks.map(f => (
                <motion.div
                  key={f.id}
                  initial={{ opacity: 0, y: 15, scale: 0.8 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -20, scale: 0.9 }}
                  className="px-3 py-1 rounded-full text-xs font-bold font-mono shadow-lg border border-white/20 backdrop-blur-xs"
                  style={{ backgroundColor: `${f.color}25`, color: f.color }}
                >
                  {f.text}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {/* SCENE: UNDERGROUND (Iconic Cross-Section Diagram) */}
          {scene === 'UNDERGROUND' && (
            <div className="relative w-full h-full flex items-center justify-center p-2">
              <svg 
                viewBox="0 0 800 520" 
                className="w-full h-full max-h-[460px] select-none"
                preserveAspectRatio="xMidYMid meet"
              >
                <defs>
                  {/* Soil Texture & Patterns */}
                  <pattern id="soilPattern" width="40" height="40" patternUnits="userSpaceOnUse">
                    <rect width="40" height="40" fill="#5A3A1F" />
                    <circle cx="10" cy="12" r="1.5" fill="#422912" />
                    <circle cx="28" cy="8" r="2" fill="#38210C" />
                    <circle cx="20" cy="26" r="1.8" fill="#422912" />
                    <circle cx="34" cy="32" r="1.2" fill="#38210C" />
                    <circle cx="6" cy="34" r="1.5" fill="#714A29" />
                    <path d="M 0,20 Q 20,22 40,20" stroke="#4B2F17" strokeWidth="1" fill="none" opacity="0.4" />
                  </pattern>

                  {/* Rubble & Bricks Pattern */}
                  <pattern id="brickPattern" width="30" height="15" patternUnits="userSpaceOnUse">
                    <rect width="30" height="15" fill="#9C512F" />
                    <rect x="1" y="1" width="13" height="6" fill="#B3633E" />
                    <rect x="16" y="1" width="13" height="6" fill="#884222" />
                    <rect x="8" y="8" width="14" height="6" fill="#B3633E" />
                    <rect x="23" y="8" width="6" height="6" fill="#783A1E" />
                    <rect x="1" y="8" width="6" height="6" fill="#783A1E" />
                  </pattern>

                  {/* Arrow marker for technical callouts */}
                  <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                    <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#FBBF24" />
                  </marker>
                  <marker id="arrowRed" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                    <path d="M 0 1.5 L 8 5 L 0 8.5 z" fill="#EF4444" />
                  </marker>
                </defs>

                {/* 1. Sky & Surface Horizon with Mesopotamian dusk and date palms */}
                <rect x="0" y="0" width="800" height="110" fill="#1C1008" />
                {/* Distant dusk glow */}
                <ellipse cx="400" cy="110" rx="350" ry="60" fill="#451A03" opacity="0.6" />
                <path d="M 0,110 Q 200,105 400,110 T 800,110 L 800,120 L 0,120 Z" fill="#6B3410" />
                <rect x="0" y="105" width="800" height="6" fill="#4D2A0E" />

                {/* Mesopotamian date palms on surface */}
                {/* Left Palm */}
                <path d="M 124,106 Q 123,80 120,60" stroke="#3D200A" strokeWidth="4" strokeLinecap="round" fill="none" />
                <path d="M 120,60 Q 95,50 85,65 M 120,60 Q 105,40 100,50 M 120,60 Q 135,38 145,50 M 120,60 Q 148,50 155,65 M 120,60 Q 120,35 122,45" stroke="#364919" strokeWidth="2.5" fill="none" />
                
                {/* Right Palm */}
                <path d="M 686,106 Q 688,80 692,58" stroke="#3D200A" strokeWidth="4" strokeLinecap="round" fill="none" />
                <path d="M 692,58 Q 665,48 655,62 M 692,58 Q 675,38 670,48 M 692,58 Q 708,36 718,48 M 692,58 Q 722,48 730,62 M 692,58 Q 694,33 695,43" stroke="#364919" strokeWidth="2.5" fill="none" />

                {/* 2. Earth / Soil Cutaway */}
                <rect x="0" y="111" width="800" height="409" fill="url(#soilPattern)" />
                <path d="M 0,210 Q 300,200 800,215" stroke="#381D0A" strokeWidth="2" strokeDasharray="6,8" fill="none" opacity="0.6" />
                <path d="M 0,330 Q 500,320 800,340" stroke="#381D0A" strokeWidth="2" strokeDasharray="6,8" fill="none" opacity="0.6" />

                {/* 3. Entrance Shaft & Rubble Mound */}
                <ellipse cx="260" cy="108" rx="65" ry="18" fill="#6E2E11" />
                <path d="M 205,108 Q 260,82 315,108 Z" fill="url(#brickPattern)" stroke="#4A1C08" strokeWidth="1.5" />

                <rect x="232" y="110" width="56" height="150" fill="#140B05" stroke="#381D0A" strokeWidth="2" />
                <line x1="235" y1="140" x2="285" y2="140" stroke="#6E2E11" strokeWidth="3" />
                <line x1="235" y1="170" x2="285" y2="170" stroke="#6E2E11" strokeWidth="3" />
                <line x1="235" y1="200" x2="285" y2="200" stroke="#6E2E11" strokeWidth="3" />
                <line x1="235" y1="230" x2="285" y2="230" stroke="#6E2E11" strokeWidth="3" />

                {/* 4. Air Vent Pipe */}
                <path 
                  d="M 520,95 L 520,170 L 485,250" 
                  stroke="#78350F" 
                  strokeWidth="10" 
                  strokeLinecap="round" 
                  fill="none" 
                />
                <path 
                  d="M 520,95 L 520,170 L 485,250" 
                  stroke="#B45309" 
                  strokeWidth="6" 
                  strokeLinecap="round" 
                  fill="none" 
                />
                <rect x="510" y="90" width="20" height="7" rx="2" fill="#D97706" stroke="#451A03" />
                <path 
                  d="M 520,98 L 520,170 L 485,250" 
                  stroke="#38BDF8" 
                  strokeWidth="2" 
                  strokeDasharray="4,6" 
                  fill="none" 
                  className="animate-pulse"
                />

                {/* 5. Subterranean Excavated Room */}
                <rect 
                  x="200" 
                  y="260" 
                  width="330" 
                  height="170" 
                  rx="14" 
                  fill="#0F0804" 
                  stroke="#6E2E11" 
                  strokeWidth="4" 
                />
                <radialGradient id="roomLight" cx="60%" cy="40%" r="70%">
                  <stop offset="0%" stopColor="#451A03" stopOpacity="0.85" />
                  <stop offset="100%" stopColor="#0A0502" stopOpacity="0.98" />
                </radialGradient>
                <rect x="202" y="262" width="326" height="166" rx="12" fill="url(#roomLight)" />

                {/* Sleeping mat / cot on floor */}
                <rect x="220" y="390" width="210" height="12" rx="3" fill="#2E170A" stroke="#4D2811" strokeWidth="1" />
                <rect x="225" y="386" width="30" height="8" rx="2" fill="#4D2811" />

                {/* 6. CHARACTER: SADDAM HUSSEIN (Iconic Solid Red Silhouette Lying Horizontally) */}
                <g id="saddam-silhouette" className="transition-transform duration-300">
                  <ellipse cx="242" cy="382" rx="14" ry="7" fill="#6B4423" />
                  <circle cx="244" cy="372" r="10" fill="#EF4444" />
                  <path d="M 248,373 L 253,375 L 249,380 Z" fill="#EF4444" />
                  <rect x="252" y="370" width="55" height="17" rx="5" fill="#EF4444" />
                  <ellipse cx="270" cy="378" rx="26" ry="10" fill="#EF4444" />
                  <rect x="302" y="373" width="70" height="13" rx="4" fill="#EF4444" />
                  <polygon points="370,373 376,365 379,373" fill="#EF4444" />
                  <animateTransform 
                    attributeName="transform" 
                    type="translate" 
                    values="0 0; 0 -1.5; 0 0" 
                    dur="3s" 
                    repeatCount="indefinite" 
                  />
                </g>

                {/* 7. Fan on a Stand near the Vent Inlet */}
                <g id="vent-fan" transform="translate(470, 320)">
                  <line x1="15" y1="30" x2="15" y2="80" stroke="#64748B" strokeWidth="3" />
                  <line x1="15" y1="80" x2="0" y2="100" stroke="#64748B" strokeWidth="3" />
                  <line x1="15" y1="80" x2="30" y2="100" stroke="#64748B" strokeWidth="3" />
                  <circle cx="15" cy="30" r="22" fill="#1E293B" stroke="#94A3B8" strokeWidth="2" />
                  <circle cx="15" cy="30" r="4" fill="#E2E8F0" />
                  <g className={airflow > 10 ? 'origin-[15px_30px] animate-spin' : ''} style={{ animationDuration: '0.8s' }}>
                    <line x1="15" y1="12" x2="15" y2="48" stroke="#38BDF8" strokeWidth="3" strokeLinecap="round" />
                    <line x1="2" y1="30" x2="28" y2="30" stroke="#38BDF8" strokeWidth="3" strokeLinecap="round" />
                  </g>
                  {airflow > 20 && (
                    <g opacity="0.6">
                      <path d="M 0,25 Q -40,20 -90,35" stroke="#38BDF8" strokeWidth="1.5" strokeDasharray="4,6" fill="none" />
                      <path d="M 0,35 Q -50,35 -110,40" stroke="#38BDF8" strokeWidth="1.5" strokeDasharray="4,6" fill="none" />
                    </g>
                  )}
                </g>

                {/* 8. Depth Measurement Indicator */}
                <line x1="170" y1="110" x2="170" y2="260" stroke="#D97706" strokeWidth="2" />
                <line x1="162" y1="110" x2="178" y2="110" stroke="#D97706" strokeWidth="2" />
                <line x1="162" y1="260" x2="178" y2="260" stroke="#D97706" strokeWidth="2" />
                <polygon points="170,111 166,119 174,119" fill="#D97706" />
                <polygon points="170,259 166,251 174,251" fill="#D97706" />
                <rect x="120" y="172" width="60" height="24" rx="4" fill="#1C120B" stroke="#D97706" strokeWidth="1.2" />
                <text x="150" y="188" fill="#FEF3C7" fontSize="10" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                  {isAr ? 'سرداب' : 'VAULT'}
                </text>

                {/* 9. Technical Callout Labels from the Reference Diagram */}
                {/* Callout A: "Entrance hidden by bricks and dirt" */}
                <g>
                  <polyline 
                    points="80,50 200,50 245,85" 
                    fill="none" 
                    stroke="#D97706" 
                    strokeWidth="1.5" 
                    markerEnd="url(#arrow)" 
                  />
                  <rect x="15" y="34" width={isAr ? 190 : 205} height="28" rx="4" fill="#18110B" stroke="#D97706" strokeWidth="1.2" />
                  <text x="22" y="52" fill="#FEF3C7" fontSize="11" fontWeight="bold" fontFamily="monospace">
                    {isAr ? 'المدخل مخفي بالطوب والتراب' : 'Entrance hidden by bricks & dirt'}
                  </text>
                </g>

                {/* Callout B: "Air vent" */}
                <g>
                  <polyline 
                    points="680,140 590,140 528,140" 
                    fill="none" 
                    stroke="#D97706" 
                    strokeWidth="1.5" 
                    markerEnd="url(#arrow)" 
                  />
                  <rect x="685" y="125" width={isAr ? 85 : 80} height="26" rx="4" fill="#18110B" stroke="#D97706" strokeWidth="1.2" />
                  <text x="692" y="142" fill="#FEF3C7" fontSize="11" fontWeight="bold" fontFamily="monospace">
                    {isAr ? 'مسار الهواء' : 'Air vent'}
                  </text>
                </g>

                {/* Callout C: "Fan" */}
                <g>
                  <polyline 
                    points="680,310 570,310 500,320" 
                    fill="none" 
                    stroke="#D97706" 
                    strokeWidth="1.5" 
                    markerEnd="url(#arrow)" 
                  />
                  <rect x="685" y="296" width={isAr ? 65 : 55} height="26" rx="4" fill="#18110B" stroke="#D97706" strokeWidth="1.2" />
                  <text x="693" y="313" fill="#FEF3C7" fontSize="11" fontWeight="bold" fontFamily="monospace">
                    {isAr ? 'مروحة' : 'Fan'}
                  </text>
                </g>

                {/* Callout D: "Saddam Hussein" */}
                <g>
                  <polyline 
                    points="120,460 250,460 280,395" 
                    fill="none" 
                    stroke="#EF4444" 
                    strokeWidth="2" 
                    markerEnd="url(#arrowRed)" 
                  />
                  <rect x="25" y="445" width={isAr ? 120 : 135} height="28" rx="4" fill="#240E0E" stroke="#EF4444" strokeWidth="1.5" />
                  <text x="32" y="463" fill="#FCA5A5" fontSize="12" fontWeight="bold" fontFamily="monospace">
                    {isAr ? 'صدام حسين' : 'Saddam Hussein'}
                  </text>
                </g>

                {/* Police Search Red Spotlights (sweeping when police searching underground) */}
                {isPoliceSearching && (
                  <g opacity="0.45" className="animate-pulse">
                    <polygon points="260,108 180,500 340,500" fill="#EF4444" opacity="0.3" />
                    <rect x="0" y="0" width="800" height="520" fill="#EF4444" opacity="0.12" />
                  </g>
                )}
              </svg>
            </div>
          )}

          {/* SCENE: OUTSIDE (Surface Scavenging Area) */}
          {scene === 'OUTSIDE' && (
            <div className="relative w-full h-full flex flex-col items-center justify-between p-3 sm:p-4 bg-gradient-to-b from-[#180e07] via-[#24140a] to-[#0c0805]">
              
              {/* Quick Screen Flash during brief warning */}
              {isBriefPoliceWarning && (
                <div className="absolute inset-0 bg-red-600/25 z-30 pointer-events-none animate-pulse" />
              )}

              {/* TOP PANEL: Alerts or Action Progress only */}
              <div className="w-full max-w-sm flex flex-col items-center gap-1 z-20 min-h-[36px]">
                {isBriefPoliceWarning ? (
                  <div className="px-3 py-1 rounded-full bg-red-950 border-2 border-amber-400 text-amber-300 font-mono font-bold text-xs animate-shake-alert shadow-[0_0_20px_rgba(245,158,11,0.3)]">
                    {isAr ? '⚠️ الشرطة!' : '⚠️ POLICE!'}
                  </div>
                ) : isPoliceSearching ? (
                  <div className="px-3 py-1 rounded-full bg-red-950 border-2 border-red-500 text-white font-mono font-bold text-xs animate-pulse shadow-[0_0_20px_rgba(239,68,68,0.4)]">
                    {isAr ? '🚨 الشرطة تفتش!' : '🚨 POLICE SEARCHING'}
                  </div>
                ) : currentAction ? (
                  <div className="w-full flex flex-col items-center gap-1">
                    <span className="text-[11px] font-mono text-amber-200/90 font-semibold">
                      {currentAction.includes('WATER') ? (isAr ? 'جلب الماء...' : 'Getting water...') :
                       currentAction.includes('FOOD') ? (isAr ? 'جلب الطعام...' : 'Getting food...') :
                       (isAr ? 'تنظيف مسار الهواء...' : 'Cleaning air path...')}
                    </span>
                    <div className="w-full bg-[#080503] h-2 rounded-full overflow-hidden p-0.5 border border-amber-600/30 shadow-inner">
                      <div 
                        className="bg-gradient-to-r from-amber-600 to-amber-400 h-full rounded-full transition-all duration-100"
                        style={{ width: `${Math.min(100, Math.max(5, ((actionTotal - actionRemaining) / actionTotal) * 100))}%` }}
                      />
                    </div>
                  </div>
                ) : null}
              </div>

              {/* Surface Visual Illustration */}
              <div className="w-full max-w-lg my-auto flex items-center justify-center">
                <svg viewBox="0 0 500 170" className="w-full h-36 select-none">
                  {/* Mesopotamian Dusk Sky */}
                  <rect x="0" y="0" width="500" height="120" fill="#180F08" />
                  <path d="M 0,110 Q 120,70 240,105 T 500,100 L 500,130 L 0,130 Z" fill="#2E170C" />
                  
                  {/* Subtle distant Mesopotamian city wall silhouette */}
                  <rect x="110" y="90" width="40" height="20" fill="#201007" />
                  <polygon points="110,90 120,80 140,80 150,90" fill="#201007" />
                  <rect x="360" y="88" width="50" height="22" fill="#201007" />
                  <polygon points="360,88 375,76 395,76 410,88" fill="#201007" />

                  {/* Ground surface */}
                  <rect x="0" y="115" width="500" height="55" fill="#3D2311" />
                  <rect x="0" y="113" width="500" height="4" fill="#6B3410" />

                  {/* Surface Entrance Hatch */}
                  <g transform="translate(180, 80)">
                    <ellipse cx="70" cy="38" rx="60" ry="14" fill="#24140A" />
                    <rect x="35" y="24" width="70" height="18" rx="4" fill="#783A1E" stroke="#381D0A" strokeWidth="2" />
                    <circle cx="70" cy="33" r="4" fill="#D97706" />
                    <text x="70" y="18" fill="#FEF3C7" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                      {isAr ? 'فتحة المخبأ' : 'BUNKER ENTRANCE'}
                    </text>
                  </g>

                  {/* Water Barrel Station (Ancient Bronze Cistern) */}
                  <g transform="translate(60, 75)">
                    <rect x="10" y="15" width="30" height="35" rx="3" fill="#0C4A6E" stroke="#0284C7" strokeWidth="2" />
                    <ellipse cx="25" cy="15" rx="15" ry="4" fill="#0369A1" />
                    <text x="25" y="35" fill="#FFFFFF" fontSize="12" textAnchor="middle">💧</text>
                    {/* Floating Uses Badge */}
                    <rect x="5" y="2" width="40" height="12" rx="3" fill="#1C120B" stroke="#D97706" strokeWidth="1" />
                    <text x="25" y="11" fill="#FEF3C7" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                      {waterCharges > 0 ? `${waterCharges} LEFT` : 'EMPTY'}
                    </text>
                  </g>

                  {/* Food Supply Crate (Ancient Cedar Chest) */}
                  <g transform="translate(380, 80)">
                    <rect x="10" y="10" width="36" height="32" rx="2" fill="#5C2E14" stroke="#78350F" strokeWidth="2" />
                    <line x1="10" y1="26" x2="46" y2="26" stroke="#D97706" strokeWidth="1.5" />
                    <line x1="28" y1="10" x2="28" y2="42" stroke="#D97706" strokeWidth="1.5" />
                    <text x="28" y="28" fill="#FFFFFF" fontSize="12" textAnchor="middle">🍎</text>
                    {/* Floating Uses Badge */}
                    <rect x="8" y="-2" width="40" height="12" rx="3" fill="#1C120B" stroke="#D97706" strokeWidth="1" />
                    <text x="28" y="7" fill="#FEF3C7" fontSize="8" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                      {foodCharges > 0 ? `${foodCharges} LEFT` : 'EMPTY'}
                    </text>
                  </g>

                  {/* Air Vent Top Intake (Hammered Copper Turret) */}
                  <g transform="translate(310, 55)">
                    <path d="M 20,60 L 20,15 L 35,15" stroke="#78350F" strokeWidth="8" fill="none" />
                    <rect x="28" y="10" width="16" height="10" rx="2" fill="#B45309" stroke="#451A03" strokeWidth="1" />
                    <text x="36" y="8" fill="#34D399" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                      {isAr ? 'فتحة التهوية' : 'AIR VENT'}
                    </text>
                  </g>

                  {/* Distant Police Patrol Lights sweep if police searching or warning */}
                  {(isPoliceSearching || isBriefPoliceWarning) && (
                    <g opacity="0.6" className="animate-pulse">
                      <polygon points="50,20 180,120 20,120" fill="#EF4444" opacity="0.4" />
                      <polygon points="450,20 480,120 320,120" fill="#EF4444" opacity="0.4" />
                    </g>
                  )}
                </svg>
              </div>

              {/* Outside Action Buttons: Ancient Carved Stone & Bronze Slabs */}
              <div className="w-full max-w-lg grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
                {/* 1. GET WATER */}
                <button
                  type="button"
                  disabled={currentAction !== null || waterCharges <= 0 || isPoliceSearching || isBriefPoliceWarning}
                  onClick={handleStartGetWater}
                  className={`py-2.5 px-2 rounded-xl font-mono font-bold text-xs transition-all text-center select-none ${
                    waterCharges > 0 && !currentAction && !isPoliceSearching && !isBriefPoliceWarning
                      ? 'mesopotamian-btn-stone border-sky-500/50 text-sky-200 cursor-pointer'
                      : 'bg-[#18100a]/80 text-white/30 cursor-not-allowed border border-[#2e1d11]'
                  }`}
                >
                  {waterCharges > 0 ? (isAr ? 'جلب ماء' : 'GET WATER') : (isAr ? 'نفد الماء' : 'EMPTY')}
                </button>

                {/* 2. GET FOOD */}
                <button
                  type="button"
                  disabled={currentAction !== null || foodCharges <= 0 || isPoliceSearching || isBriefPoliceWarning}
                  onClick={handleStartGetFood}
                  className={`py-2.5 px-2 rounded-xl font-mono font-bold text-xs transition-all text-center select-none ${
                    foodCharges > 0 && !currentAction && !isPoliceSearching && !isBriefPoliceWarning
                      ? 'mesopotamian-btn-stone border-amber-500/50 text-amber-200 cursor-pointer'
                      : 'bg-[#18100a]/80 text-white/30 cursor-not-allowed border border-[#2e1d11]'
                  }`}
                >
                  {foodCharges > 0 ? (isAr ? 'جلب طعام' : 'GET FOOD') : (isAr ? 'نفد الطعام' : 'EMPTY')}
                </button>

                {/* 3. CLEAN AIR PATH */}
                <button
                  type="button"
                  disabled={currentAction !== null || airCleanCooldownRemaining > 0 || isPoliceSearching || isBriefPoliceWarning}
                  onClick={handleStartCleanAirPath}
                  className={`py-2.5 px-2 rounded-xl font-mono font-bold text-xs transition-all text-center select-none ${
                    airCleanCooldownRemaining <= 0 && !currentAction && !isPoliceSearching && !isBriefPoliceWarning
                      ? 'mesopotamian-btn-stone border-emerald-500/50 text-emerald-200 cursor-pointer'
                      : 'bg-[#18100a]/80 text-white/30 cursor-not-allowed border border-[#2e1d11]'
                  }`}
                >
                  {airCleanCooldownRemaining > 0 ? (isAr ? 'نظيف' : 'AIR CLEAN') : (isAr ? 'تنظيف مسار' : 'CLEAN AIR PATH')}
                </button>

                {/* 4. GO BACK */}
                <button
                  type="button"
                  onClick={handleReturnInside}
                  className={`py-2.5 px-2 rounded-xl font-mono font-bold text-xs transition-all text-center select-none cursor-pointer ${
                    isPoliceSearching || isBriefPoliceWarning
                      ? 'bg-red-600 hover:bg-red-500 text-white shadow-[0_3px_0_0_#991b1b] animate-pulse'
                      : 'mesopotamian-btn-gold'
                  }`}
                >
                  {isAr ? 'عودة' : 'GO BACK'}
                </button>
              </div>
            </div>
          )}

          {/* OVERLAY: START SCREEN */}
          {gameStatus === 'START' && (
            <div className="absolute inset-0 mesopotamian-stone-bg flex flex-col items-center justify-center p-6 text-center z-40 border border-amber-600/30">
              {/* Subtle top Mesopotamian cuneiform inscription */}
              <div className="text-amber-500/60 text-xs font-mono tracking-[0.3em] mb-2 select-none">
                𒀭 𒆠 𒈗 𒂍 𒂗
              </div>

              <span className="text-3xl mb-2 filter drop-shadow-[0_2px_12px_rgba(245,158,11,0.5)]">🦅</span>
              
              <h2 className="text-2xl sm:text-3xl font-extrabold font-serif mesopotamian-gold-text tracking-widest uppercase mb-1">
                {isAr ? 'اللعبة السرية // خزانة كوهان' : 'SECRET GAME // KOHAN VAULT'}
              </h2>
              
              <p className="text-[11px] font-mono text-amber-300/70 tracking-widest uppercase mb-4">
                {isAr ? 'العملية السرية تحت الأرض // حضارة الرافدين' : 'MESOPOTAMIAN CLASSIFIED SURVIVAL'}
              </p>

              {bestTime > 0 && (
                <div className="text-xs font-mono text-amber-300 mb-6 flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#24170d] border border-amber-500/40 shadow-inner">
                  <Trophy size={14} className="text-amber-400" />
                  <span>{isAr ? `أفضل وقت: ${formatTime(bestTime)}` : `BEST: ${formatTime(bestTime)}`}</span>
                </div>
              )}

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 w-full max-w-sm mx-auto">
                <button
                  type="button"
                  onClick={handleStartGame}
                  className="w-full sm:w-auto px-8 py-3.5 rounded-xl mesopotamian-btn-gold font-mono font-bold text-sm tracking-wider uppercase transition-all cursor-pointer shadow-lg"
                >
                  {isAr ? 'ابدأ المهمة' : 'START MISSION'}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    window.location.href = '/classified-archive';
                  }}
                  className="w-full sm:w-auto px-6 py-3 rounded-xl mesopotamian-btn-stone font-mono font-bold text-xs tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <ShieldAlert size={14} className="text-amber-400" />
                  <span>{isAr ? 'الأرشيف السري' : 'SECRET ARCHIVE'}</span>
                </button>
              </div>
            </div>
          )}

          {/* OVERLAY: CAUGHT SCREEN */}
          {gameStatus === 'CAUGHT' && (
            <div className="absolute inset-0 bg-[#1a0808]/96 flex flex-col items-center justify-center p-6 text-center z-40 border-2 border-red-700/60 shadow-[0_0_60px_rgba(185,28,28,0.4)]">
              <span className="text-3xl mb-2">🚨</span>
              <h2 className="text-xl sm:text-2xl font-bold font-serif text-red-200 mb-2 tracking-widest uppercase">
                {isAr ? 'تم القبض عليك' : 'CAUGHT BY POLICE'}
              </h2>
              <div className="text-sm font-mono text-amber-300 font-bold mb-5">
                {formatTime(survivalTime)}
                {bestTime > 0 && (
                  <span className="text-xs text-amber-200/60 block font-normal mt-0.5">
                    {isAr ? `أفضل: ${formatTime(bestTime)}` : `BEST: ${formatTime(bestTime)}`}
                  </span>
                )}
              </div>
              <button
                type="button"
                onClick={handleStartGame}
                className="px-8 py-3 rounded-xl mesopotamian-btn-gold font-mono font-bold text-xs tracking-wider uppercase transition-all cursor-pointer shadow-lg"
              >
                {isAr ? 'إعادة المحاولة' : 'TRY AGAIN'}
              </button>
            </div>
          )}

          {/* OVERLAY: RESOURCE GAME OVER SCREEN */}
          {gameStatus === 'GAME_OVER' && (
            <div className="absolute inset-0 bg-[#120a06]/96 flex flex-col items-center justify-center p-6 text-center z-40 border-2 border-amber-700/60 shadow-[0_0_60px_rgba(217,119,6,0.3)]">
              <span className="text-3xl mb-2">💀</span>
              <h2 className="text-xl sm:text-2xl font-bold font-serif mesopotamian-gold-text mb-2 tracking-widest uppercase">
                {gameOverReason === 'air' && (isAr ? 'نفد الهواء' : 'NO AIR')}
                {gameOverReason === 'water' && (isAr ? 'نفد الماء' : 'NO WATER')}
                {gameOverReason === 'food' && (isAr ? 'نفد الطعام' : 'NO FOOD')}
              </h2>
              <div className="text-sm font-mono text-amber-300 font-bold mb-5">
                {formatTime(survivalTime)}
                {bestTime > 0 && (
                  <span className="text-xs text-amber-200/60 block font-normal mt-0.5">
                    {isAr ? `أفضل: ${formatTime(bestTime)}` : `BEST: ${formatTime(bestTime)}`}
                  </span>
                )}
              </div>
              <button
                type="button"
                onClick={handleStartGame}
                className="px-8 py-3 rounded-xl mesopotamian-btn-gold font-mono font-bold text-xs tracking-wider uppercase transition-all cursor-pointer shadow-lg"
              >
                {isAr ? 'إعادة المحاولة' : 'TRY AGAIN'}
              </button>
            </div>
          )}
        </div>

        {/* Bottom Control Dock (When Underground) */}
        {gameStatus === 'PLAYING' && scene === 'UNDERGROUND' && (
          <div className="bg-[#140e09] border-t border-amber-600/40 p-3.5 flex items-center justify-center z-20">
            {isPoliceSearching ? (
              <button
                type="button"
                disabled
                className="w-full max-w-xs py-3 px-4 rounded-xl bg-[#220e0e] border border-red-500/50 text-red-300 font-mono font-bold text-xs tracking-wider cursor-not-allowed opacity-80"
              >
                {isAr ? 'الشرطة في الخارج' : 'POLICE OUTSIDE'}
              </button>
            ) : (
              <button
                type="button"
                onClick={handleGoOut}
                className="w-full max-w-xs py-3 px-6 rounded-xl mesopotamian-btn-gold font-mono font-bold text-sm tracking-widest uppercase shadow-md transition-all cursor-pointer"
              >
                {isAr ? 'خروج إلى السطح' : 'GO OUT TO SURFACE'}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
