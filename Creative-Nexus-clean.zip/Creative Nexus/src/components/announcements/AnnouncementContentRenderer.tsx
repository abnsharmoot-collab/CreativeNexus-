import React, { useState } from 'react';
import { Maximize2 } from 'lucide-react';

interface AnnouncementContentRendererProps {
  content: string;
  className?: string;
  onImageClick?: (url: string) => void;
}

export const AnnouncementContentRenderer: React.FC<AnnouncementContentRendererProps> = ({ 
  content, 
  className = '',
  onImageClick 
}) => {
  if (!content) return null;

  // Split by double line breaks to form blocks
  const blocks = content.split(/\n\s*\n/);

  return (
    <div className={`space-y-4 text-archive-paper leading-relaxed ${className}`}>
      {blocks.map((block, idx) => {
        const trimmed = block.trim();
        if (!trimmed) return null;

        // Standalone Markdown Image Block ![alt](url)
        const imgBlockMatch = trimmed.match(/^!\[(.*?)\]\((.*?)\)$/);
        if (imgBlockMatch) {
          const [, alt, url] = imgBlockMatch;
          return (
            <figure 
              key={idx} 
              className="my-5 rounded-2xl overflow-hidden border border-archive-cyan/25 bg-archive-dark/60 group relative max-w-3xl"
            >
              <div 
                className="relative cursor-pointer overflow-hidden max-h-[500px]"
                onClick={() => onImageClick?.(url)}
              >
                <img
                  src={url}
                  alt={alt || 'Announcement Photo'}
                  className="w-full h-auto object-cover group-hover:scale-[1.02] transition-transform duration-300"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity p-2.5 rounded-xl bg-archive-dark/80 backdrop-blur-md border border-archive-cyan/40 text-archive-cyan">
                    <Maximize2 size={18} />
                  </div>
                </div>
              </div>
              {alt && (
                <figcaption className="px-4 py-2 text-center text-xs text-archive-paper-muted border-t border-archive-cyan/15 bg-archive-dark/80">
                  {alt}
                </figcaption>
              )}
            </figure>
          );
        }

        // Code block
        if (trimmed.startsWith('```') && trimmed.endsWith('```')) {
          const lines = trimmed.slice(3, -3).trim().split('\n');
          const firstLine = lines[0]?.trim();
          const isLangHeader = /^[a-zA-Z0-9_-]+$/.test(firstLine);
          const codeContent = isLangHeader ? lines.slice(1).join('\n') : lines.join('\n');

          return (
            <div key={idx} className="my-4 rounded-xl border border-archive-cyan/20 bg-archive-dark/90 p-4 font-mono text-sm text-archive-cyan overflow-x-auto">
              <pre className="whitespace-pre-wrap">{codeContent}</pre>
            </div>
          );
        }

        // H1
        if (trimmed.startsWith('# ')) {
          return (
            <h1 key={idx} className="text-2xl font-bold text-archive-paper border-b border-archive-cyan/20 pb-2 pt-2">
              {renderInline(trimmed.slice(2), onImageClick)}
            </h1>
          );
        }

        // H2
        if (trimmed.startsWith('## ')) {
          return (
            <h2 key={idx} className="text-xl font-semibold text-archive-cyan border-b border-archive-cyan/10 pb-1.5 pt-2">
              {renderInline(trimmed.slice(3), onImageClick)}
            </h2>
          );
        }

        // H3
        if (trimmed.startsWith('### ')) {
          return (
            <h3 key={idx} className="text-lg font-medium text-archive-paper pt-1">
              {renderInline(trimmed.slice(4), onImageClick)}
            </h3>
          );
        }

        // Blockquote
        if (trimmed.startsWith('>')) {
          const quoteLines = trimmed.split('\n').map((l) => l.replace(/^>\s?/, '')).join(' ');
          return (
            <blockquote key={idx} className="border-s-4 border-archive-cyan bg-archive-cyan/5 px-4 py-3 rounded-e-xl text-archive-paper-muted italic my-3">
              {renderInline(quoteLines, onImageClick)}
            </blockquote>
          );
        }

        // Bullet list
        if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
          const items = trimmed.split('\n').filter((l) => l.trim().startsWith('- ') || l.trim().startsWith('* '));
          return (
            <ul key={idx} className="list-disc list-inside space-y-1.5 ps-2 text-archive-paper/90">
              {items.map((item, iIdx) => (
                <li key={iIdx} className="leading-relaxed">
                  {renderInline(item.replace(/^[-*]\s+/, ''), onImageClick)}
                </li>
              ))}
            </ul>
          );
        }

        // Numbered list
        if (/^\d+\.\s/.test(trimmed)) {
          const items = trimmed.split('\n').filter((l) => /^\d+\.\s/.test(l.trim()));
          return (
            <ol key={idx} className="list-decimal list-inside space-y-1.5 ps-2 text-archive-paper/90">
              {items.map((item, iIdx) => (
                <li key={iIdx} className="leading-relaxed">
                  {renderInline(item.replace(/^\d+\.\s+/, ''), onImageClick)}
                </li>
              ))}
            </ol>
          );
        }

        // Standard paragraph with soft breaks
        const lines = trimmed.split('\n');
        return (
          <p key={idx} className="text-archive-paper/90 text-sm sm:text-base leading-relaxed">
            {lines.map((line, lIdx) => (
              <React.Fragment key={lIdx}>
                {renderInline(line, onImageClick)}
                {lIdx < lines.length - 1 && <br />}
              </React.Fragment>
            ))}
          </p>
        );
      })}
    </div>
  );
};

// Helper for inline markdown: images, bold, italic, inline code, links
function renderInline(text: string, onImageClick?: (url: string) => void): React.ReactNode[] {
  // Regex to match markdown images, links, bold, italic, code
  const tokens = text.split(/(!\[.*?\]\(.*?\) |\[.*?\]\(.*?\)|\*\*.*?\*\*|\*.*?\*|`.*?`)/g);

  return tokens.map((token, i) => {
    if (!token) return null;

    // Image ![alt](url)
    const imgMatch = token.match(/^!\[(.*?)\]\((.*?)\)$/);
    if (imgMatch) {
      const [, alt, url] = imgMatch;
      return (
        <span 
          key={i} 
          className="inline-block my-1 mx-1 align-middle rounded-lg overflow-hidden border border-archive-cyan/30 cursor-pointer max-w-[280px]"
          onClick={() => onImageClick?.(url)}
        >
          <img src={url} alt={alt || 'Photo'} className="max-h-36 w-auto object-cover hover:scale-105 transition-transform" />
        </span>
      );
    }

    // Link [text](url)
    const linkMatch = token.match(/^\[(.*?)\]\((.*?)\)$/);
    if (linkMatch) {
      const [, label, url] = linkMatch;
      return (
        <a
          key={i}
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-archive-cyan underline hover:text-archive-cyan/80 transition-colors font-medium inline-flex items-center gap-0.5"
        >
          {label}
        </a>
      );
    }

    // Bold **text**
    if (token.startsWith('**') && token.endsWith('**') && token.length >= 4) {
      return (
        <strong key={i} className="font-semibold text-archive-paper">
          {token.slice(2, -2)}
        </strong>
      );
    }

    // Italic *text*
    if (token.startsWith('*') && token.endsWith('*') && token.length >= 2) {
      return (
        <em key={i} className="italic text-archive-paper/90">
          {token.slice(1, -1)}
        </em>
      );
    }

    // Inline code `code`
    if (token.startsWith('`') && token.endsWith('`') && token.length >= 2) {
      return (
        <code key={i} className="rounded bg-archive-dark/80 px-1.5 py-0.5 font-mono text-xs text-archive-cyan border border-archive-cyan/20">
          {token.slice(1, -1)}
        </code>
      );
    }

    return token;
  });
}
