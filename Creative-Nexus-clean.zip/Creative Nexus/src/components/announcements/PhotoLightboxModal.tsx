import React, { useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ChevronLeft, ChevronRight, Download, ExternalLink } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

interface PhotoLightboxModalProps {
  isOpen: boolean;
  onClose: () => void;
  images: string[];
  currentIndex: number;
  onIndexChange: (index: number) => void;
}

export const PhotoLightboxModal: React.FC<PhotoLightboxModalProps> = ({
  isOpen,
  onClose,
  images,
  currentIndex,
  onIndexChange
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const hasMultiple = images.length > 1;
  const currentImage = images[currentIndex];

  const handlePrev = useCallback(() => {
    if (!hasMultiple) return;
    onIndexChange((currentIndex - 1 + images.length) % images.length);
  }, [currentIndex, images.length, hasMultiple, onIndexChange]);

  const handleNext = useCallback(() => {
    if (!hasMultiple) return;
    onIndexChange((currentIndex + 1) % images.length);
  }, [currentIndex, images.length, hasMultiple, onIndexChange]);

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') {
        if (isAr) handleNext();
        else handlePrev();
      }
      if (e.key === 'ArrowRight') {
        if (isAr) handlePrev();
        else handleNext();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, handlePrev, handleNext, isAr]);

  if (!isOpen || !currentImage) return null;

  return (
    <AnimatePresence>
      <div 
        id="announcement-photo-lightbox"
        className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-6 bg-black/90 backdrop-blur-xl select-none"
        onClick={onClose}
      >
        {/* Top Controls Bar */}
        <div 
          className="absolute top-4 inset-x-4 sm:inset-x-6 z-10 flex items-center justify-between pointer-events-none"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Photo Counter */}
          <div className="pointer-events-auto px-3 py-1 rounded-full bg-archive-dark/80 backdrop-blur-md border border-archive-cyan/20 text-xs font-mono font-medium text-archive-cyan">
            {hasMultiple ? `${currentIndex + 1} / ${images.length}` : (isAr ? 'صورة الإعلان' : 'Announcement Photo')}
          </div>

          {/* Close & Action Buttons */}
          <div className="pointer-events-auto flex items-center gap-2">
            {/* Open in new tab (if URL) */}
            {!currentImage.startsWith('data:') && (
              <a
                href={currentImage}
                target="_blank"
                rel="noopener noreferrer"
                title={isAr ? 'فتح في علامة تبويب جديدة' : 'Open in new tab'}
                className="p-2 rounded-xl bg-archive-dark/80 hover:bg-archive-card border border-archive-cyan/20 text-archive-paper-muted hover:text-archive-cyan transition-colors"
              >
                <ExternalLink size={18} />
              </a>
            )}

            {/* Close */}
            <button
              onClick={onClose}
              title={isAr ? 'إغلاق' : 'Close'}
              className="p-2 rounded-xl bg-archive-dark/80 hover:bg-archive-card border border-archive-cyan/20 text-archive-paper hover:text-archive-cyan transition-colors cursor-pointer"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Previous Button */}
        {hasMultiple && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              handlePrev();
            }}
            aria-label="Previous photo"
            className="absolute left-3 sm:left-6 z-10 p-2.5 sm:p-3 rounded-2xl bg-archive-dark/80 hover:bg-archive-card border border-archive-cyan/20 text-archive-paper hover:text-archive-cyan transition-all transform hover:scale-105 cursor-pointer shadow-lg"
          >
            <ChevronLeft size={24} />
          </button>
        )}

        {/* Next Button */}
        {hasMultiple && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleNext();
            }}
            aria-label="Next photo"
            className="absolute right-3 sm:right-6 z-10 p-2.5 sm:p-3 rounded-2xl bg-archive-dark/80 hover:bg-archive-card border border-archive-cyan/20 text-archive-paper hover:text-archive-cyan transition-all transform hover:scale-105 cursor-pointer shadow-lg"
          >
            <ChevronRight size={24} />
          </button>
        )}

        {/* Image Container with Animation */}
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.2 }}
          onClick={(e) => e.stopPropagation()}
          className="relative max-w-5xl max-h-[85vh] flex items-center justify-center overflow-hidden rounded-2xl border border-archive-cyan/25 bg-archive-dark/50 shadow-2xl"
        >
          <img
            src={currentImage}
            alt="Announcement preview"
            className="max-h-[82vh] max-w-full object-contain select-none"
          />
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
