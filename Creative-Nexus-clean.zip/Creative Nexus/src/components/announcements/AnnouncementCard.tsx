import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Pin, Calendar, Clock, ArrowRight, ArrowLeft, MoreVertical, Edit2, Trash2, Shield, User, Image as ImageIcon } from 'lucide-react';
import { Announcement, ANNOUNCEMENT_CATEGORIES } from '../../types/announcement';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';

interface AnnouncementCardProps {
  announcement: Announcement;
  onEdit?: (announcement: Announcement) => void;
  onDelete?: (id: string) => void;
  onTogglePin?: (id: string, isPinned: boolean) => void;
  hasPostageStamp?: boolean;
}

export const AnnouncementCard: React.FC<AnnouncementCardProps> = ({
  announcement,
  onEdit,
  onDelete,
  onTogglePin,
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { role } = useAuth();
  const isOwner = role === 'OWNER';

  const [isDeleting, setIsDeleting] = useState(false);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);

  // Match category configuration
  const categoryConfig = ANNOUNCEMENT_CATEGORIES.find(
    (c) => c.id.toLowerCase() === (announcement.category || '').toLowerCase()
  );

  // Format date
  const formatDate = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return new Intl.DateTimeFormat(isAr ? 'ar-EG' : 'en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }).format(date);
    } catch {
      return isoString;
    }
  };

  // Relative time helper
  const getRelativeTime = (isoString: string) => {
    try {
      const diffMs = Date.now() - new Date(isoString).getTime();
      const diffMins = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffMins < 2) return isAr ? 'الآن' : 'Just now';
      if (diffMins < 60) return isAr ? `منذ ${diffMins} دقيقة` : `${diffMins}m ago`;
      if (diffHours < 24) return isAr ? `منذ ${diffHours} ساعة` : `${diffHours}h ago`;
      if (diffDays < 7) return isAr ? `منذ ${diffDays} يوم` : `${diffDays}d ago`;
      return formatDate(isoString);
    } catch {
      return isoString;
    }
  };

  // Strip markdown formatting for clean excerpt
  const excerpt = announcement.content
    .replace(/#+\s+/g, '')
    .replace(/(\*\*|\*|`|\[.*?\]\(.*?\))/g, '')
    .replace(/\n+/g, ' ')
    .trim();

  const handleDelete = async () => {
    if (!onDelete) return;
    try {
      setIsDeleting(true);
      await onDelete(announcement.id);
    } finally {
      setIsDeleting(false);
      setShowConfirmDelete(false);
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.2 }}
      className={`group relative rounded-2xl border transition-all duration-300 overflow-hidden flex flex-col justify-between ${
        announcement.isPinned
          ? 'bg-gradient-to-br from-archive-card via-archive-dark/95 to-amber-950/15 border-amber-500/30 hover:border-amber-500/50 shadow-lg shadow-amber-950/20'
          : 'bg-archive-card/90 hover:bg-archive-card border-archive-cyan/15 hover:border-archive-cyan/35 shadow-md shadow-archive-dark/40'
      }`}
    >
      {/* Top Banner Accent */}
      {announcement.isPinned && (
        <div className="h-1 w-full bg-gradient-to-r from-amber-500/80 via-archive-cyan/70 to-amber-500/80" />
      )}

      <div className="p-5 sm:p-6 flex-1 flex flex-col">
        {/* Header Metadata row */}
        <div className="flex items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Pinned Tag */}
            {announcement.isPinned && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                <Pin size={11} className="rotate-45" />
                <span>{isAr ? 'مثبّت' : 'Pinned'}</span>
              </span>
            )}

            {/* Category Tag */}
            {announcement.category && (
              <span
                className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-medium border ${
                  categoryConfig ? categoryConfig.color : 'bg-archive-cyan/15 text-archive-cyan border-archive-cyan/30'
                }`}
              >
                {categoryConfig
                  ? isAr
                    ? categoryConfig.labelAr
                    : categoryConfig.labelEn
                  : announcement.category}
              </span>
            )}
          </div>

          {/* Published Time */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="flex items-center gap-1.5 text-[11px] text-archive-paper-muted" title={formatDate(announcement.publishedAt)}>
              <Clock size={12} className="text-archive-cyan/60" />
              <span>{getRelativeTime(announcement.publishedAt)}</span>
            </div>
          </div>
        </div>

        {/* Cover Photo Preview (if present) */}
        {(announcement.imageUrl || (announcement.images && announcement.images.length > 0)) && (
          <Link 
            to={`/announcements/${announcement.id}`} 
            className="block relative w-full h-44 sm:h-48 mb-3.5 rounded-xl overflow-hidden border border-archive-cyan/20 group-hover:border-archive-cyan/40 transition-all bg-archive-dark/80 shrink-0"
          >
            <img 
              src={announcement.imageUrl || announcement.images![0]} 
              alt={announcement.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-archive-dark/90 via-transparent to-transparent opacity-50" />
            
            {/* Gallery badge if multiple photos exist */}
            {announcement.images && announcement.images.length > (announcement.imageUrl ? 0 : 1) && (
              <span className="absolute bottom-2.5 end-2.5 px-2 py-0.5 rounded-lg bg-archive-dark/85 backdrop-blur-md border border-archive-cyan/30 text-[11px] font-medium text-archive-cyan flex items-center gap-1">
                <ImageIcon size={12} />
                <span>+{announcement.imageUrl ? announcement.images.length : announcement.images.length - 1}</span>
              </span>
            )}
          </Link>
        )}

        {/* Title */}
        <Link to={`/announcements/${announcement.id}`} className="group-hover:text-archive-cyan transition-colors">
          <h3 className="text-lg sm:text-xl font-bold text-archive-paper leading-snug tracking-tight line-clamp-2 mb-2">
            {announcement.title}
          </h3>
        </Link>

        {/* Content Excerpt */}
        <p className="text-sm text-archive-paper-muted line-clamp-3 leading-relaxed flex-1 mb-4">
          {excerpt}
        </p>

        {/* Author Details & Card Footer */}
        <div className="pt-4 border-t border-archive-cyan/10 flex items-center justify-between gap-3 mt-auto">
          {/* Author */}
          <div className="flex items-center gap-2.5 min-w-0">
            {announcement.authorAvatarUrl ? (
              <img
                src={announcement.authorAvatarUrl}
                alt={announcement.authorDisplayName}
                className="w-7 h-7 rounded-full object-cover border border-archive-cyan/30 shrink-0"
              />
            ) : (
              <div className="w-7 h-7 rounded-full bg-archive-cyan/15 border border-archive-cyan/30 flex items-center justify-center text-archive-cyan shrink-0">
                <User size={14} />
              </div>
            )}
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-semibold text-archive-paper truncate">
                  {announcement.authorDisplayName}
                </span>
                <span className="text-[10px] font-mono font-bold px-1 py-0.2 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30">
                  {isAr ? 'الإدارة' : 'Owner'}
                </span>
              </div>
            </div>
          </div>

          {/* Action Row */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Owner Management Buttons */}
            {isOwner && (
              <div className="flex items-center gap-1 border-e border-archive-cyan/15 pe-2">
                {/* Pin/Unpin */}
                {onTogglePin && (
                  <button
                    onClick={() => onTogglePin(announcement.id, !announcement.isPinned)}
                    title={announcement.isPinned ? (isAr ? 'إلغاء التثبيت' : 'Unpin') : (isAr ? 'تثبيت الإعلان' : 'Pin')}
                    className={`p-1.5 rounded-lg transition-colors text-xs ${
                      announcement.isPinned
                        ? 'text-amber-400 hover:bg-amber-500/15'
                        : 'text-archive-paper-muted hover:text-amber-300 hover:bg-archive-dark/60'
                    }`}
                  >
                    <Pin size={14} className={announcement.isPinned ? 'fill-amber-400 rotate-45' : ''} />
                  </button>
                )}

                {/* Edit */}
                {onEdit && (
                  <button
                    onClick={() => onEdit(announcement)}
                    title={isAr ? 'تعديل' : 'Edit'}
                    className="p-1.5 rounded-lg text-archive-paper-muted hover:text-archive-cyan hover:bg-archive-dark/60 transition-colors text-xs"
                  >
                    <Edit2 size={14} />
                  </button>
                )}

                {/* Delete */}
                {onDelete && (
                  <div className="relative">
                    <button
                      onClick={() => setShowConfirmDelete(true)}
                      title={isAr ? 'حذف' : 'Delete'}
                      className="p-1.5 rounded-lg text-archive-paper-muted hover:text-rose-400 hover:bg-rose-500/10 transition-colors text-xs"
                    >
                      <Trash2 size={14} />
                    </button>

                    {/* Quick Confirm Delete Popover */}
                    {showConfirmDelete && (
                      <div className="absolute bottom-full end-0 mb-2 w-48 p-2.5 rounded-xl bg-archive-dark border border-rose-500/40 shadow-xl z-20 text-start">
                        <p className="text-[11px] text-archive-paper mb-2">
                          {isAr ? 'حذف هذا الإعلان نهائياً؟' : 'Delete announcement?'}
                        </p>
                        <div className="flex items-center gap-1.5 justify-end">
                          <button
                            onClick={() => setShowConfirmDelete(false)}
                            className="px-2 py-0.5 rounded text-[10px] text-archive-paper-muted hover:text-archive-paper"
                          >
                            {isAr ? 'إلغاء' : 'Cancel'}
                          </button>
                          <button
                            onClick={handleDelete}
                            disabled={isDeleting}
                            className="px-2 py-0.5 rounded bg-rose-500 text-white font-bold text-[10px] hover:bg-rose-600 disabled:opacity-50"
                          >
                            {isDeleting ? '...' : isAr ? 'حذف' : 'Delete'}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Read / Open Link */}
            <Link
              to={`/announcements/${announcement.id}`}
              className="inline-flex items-center gap-1 text-xs font-semibold text-archive-cyan hover:text-archive-cyan/80 transition-colors px-2 py-1 rounded-lg hover:bg-archive-cyan/10"
            >
              <span>{isAr ? 'قراءة' : 'Read'}</span>
              {isAr ? <ArrowLeft size={13} /> : <ArrowRight size={13} />}
            </Link>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
