import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Pin, Tag, User, Sparkles, Eye, Edit3, AlertCircle, 
  Upload, Image as ImageIcon, Link as LinkIcon, Trash2, Check, Plus, Star 
} from 'lucide-react';
import { Announcement, ANNOUNCEMENT_CATEGORIES } from '../../types/announcement';
import { AnnouncementContentRenderer } from './AnnouncementContentRenderer';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { compressImageFile, isValidImageUrl } from '../../utils/imageCompressor';

interface AnnouncementModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: {
    title: string;
    content: string;
    category: string;
    isPinned: boolean;
    authorDisplayName?: string;
    imageUrl?: string;
    images?: string[];
  }) => Promise<void>;
  initialData?: Announcement | null;
  mode: 'create' | 'edit';
}

export const AnnouncementModal: React.FC<AnnouncementModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  initialData,
  mode
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { user } = useAuth();

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<string>('General');
  const [isPinned, setIsPinned] = useState(false);
  const [authorDisplayName, setAuthorDisplayName] = useState('');
  const [activeTab, setActiveTab] = useState<'edit' | 'preview'>('edit');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Photos state
  const [coverImageUrl, setCoverImageUrl] = useState<string>('');
  const [galleryImages, setGalleryImages] = useState<string[]>([]);
  const [isDraggingCover, setIsDraggingCover] = useState(false);
  const [isDraggingGallery, setIsDraggingGallery] = useState(false);
  const [isCompressing, setIsCompressing] = useState(false);

  // URL input modals / toggles
  const [showCoverUrlInput, setShowCoverUrlInput] = useState(false);
  const [coverUrlInput, setCoverUrlInput] = useState('');
  const [showGalleryUrlInput, setShowGalleryUrlInput] = useState(false);
  const [galleryUrlInput, setGalleryUrlInput] = useState('');

  const coverFileInputRef = useRef<HTMLInputElement>(null);
  const galleryFileInputRef = useRef<HTMLInputElement>(null);
  const contentTextareaRef = useRef<HTMLTextAreaElement>(null);

  // Populate form if initialData exists or user opens modal
  useEffect(() => {
    if (initialData) {
      setTitle(initialData.title);
      setContent(initialData.content);
      setCategory(initialData.category || 'General');
      setIsPinned(initialData.isPinned);
      setAuthorDisplayName(initialData.authorDisplayName || '');
      setCoverImageUrl(initialData.imageUrl || '');
      setGalleryImages(Array.isArray(initialData.images) ? [...initialData.images] : []);
    } else {
      setTitle('');
      setContent('');
      setCategory('General');
      setIsPinned(false);
      setAuthorDisplayName(user?.displayName || 'Owner');
      setCoverImageUrl('');
      setGalleryImages([]);
    }
    setActiveTab('edit');
    setError(null);
    setShowCoverUrlInput(false);
    setShowGalleryUrlInput(false);
    setCoverUrlInput('');
    setGalleryUrlInput('');
  }, [initialData, isOpen, user]);

  if (!isOpen) return null;

  // Handle Cover Photo File
  const handleCoverFileSelect = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const file = files[0];
    if (!file.type.startsWith('image/')) {
      setError(isAr ? 'يرجى اختيار ملف صورة صالح (PNG, JPG, WebP, GIF)' : 'Please select a valid image file');
      return;
    }

    try {
      setIsCompressing(true);
      setError(null);
      const processed = await compressImageFile(file, 1600, 0.85);
      setCoverImageUrl(processed.dataUrl);
    } catch (err: any) {
      console.error('Failed to compress cover image:', err);
      setError(isAr ? 'فشل معالجة الصورة، يرجى المحاولة مرة أخرى' : 'Failed to process image');
    } finally {
      setIsCompressing(false);
    }
  };

  // Handle Additional Gallery Files
  const handleGalleryFilesSelect = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const remainingSlots = 8 - galleryImages.length;
    if (remainingSlots <= 0) {
      setError(isAr ? 'تم الوصول للحد الأقصى للصور الإضافية (8 صور)' : 'Maximum 8 gallery photos reached');
      return;
    }

    try {
      setIsCompressing(true);
      setError(null);
      const filesToProcess = Array.from(files).slice(0, remainingSlots);
      const processedList: string[] = [];

      for (const file of filesToProcess) {
        if (file.type.startsWith('image/')) {
          const processed = await compressImageFile(file, 1400, 0.85);
          processedList.push(processed.dataUrl);
        }
      }

      setGalleryImages((prev) => [...prev, ...processedList]);
    } catch (err: any) {
      console.error('Failed to process gallery images:', err);
      setError(isAr ? 'فشل معالجة بعض الصور' : 'Failed to process some images');
    } finally {
      setIsCompressing(false);
    }
  };

  // Apply Cover URL
  const handleApplyCoverUrl = () => {
    if (!coverUrlInput.trim()) return;
    if (!isValidImageUrl(coverUrlInput.trim())) {
      setError(isAr ? 'يرجى إدخال رابط صورة صالح (يبدأ بـ http:// أو https://)' : 'Please enter a valid image URL');
      return;
    }
    setCoverImageUrl(coverUrlInput.trim());
    setCoverUrlInput('');
    setShowCoverUrlInput(false);
    setError(null);
  };

  // Apply Gallery URL
  const handleApplyGalleryUrl = () => {
    if (!galleryUrlInput.trim()) return;
    if (!isValidImageUrl(galleryUrlInput.trim())) {
      setError(isAr ? 'يرجى إدخال رابط صورة صالح (يبدأ بـ http:// أو https://)' : 'Please enter a valid image URL');
      return;
    }
    if (galleryImages.length >= 8) {
      setError(isAr ? 'تم الوصول للحد الأقصى للصور الإضافية (8 صور)' : 'Maximum 8 gallery photos reached');
      return;
    }
    setGalleryImages((prev) => [...prev, galleryUrlInput.trim()]);
    setGalleryUrlInput('');
    setShowGalleryUrlInput(false);
    setError(null);
  };

  // Insert image markdown snippet into content
  const handleInsertMarkdownImage = (imgUrl: string, caption = 'Image') => {
    const snippet = `\n\n![${caption}](${imgUrl})\n\n`;
    setContent((prev) => prev + snippet);
    setActiveTab('edit');
    if (contentTextareaRef.current) {
      contentTextareaRef.current.focus();
    }
  };

  // Set gallery image as cover
  const handleSetAsCover = (imgUrl: string, index: number) => {
    const oldCover = coverImageUrl;
    setCoverImageUrl(imgUrl);
    setGalleryImages((prev) => {
      const copy = [...prev];
      if (oldCover) {
        copy[index] = oldCover;
      } else {
        copy.splice(index, 1);
      }
      return copy;
    });
  };

  // Remove gallery image
  const handleRemoveGalleryImage = (index: number) => {
    setGalleryImages((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError(isAr ? 'يرجى إدخال عنوان الإعلان' : 'Please enter an announcement title');
      return;
    }
    if (!content.trim()) {
      setError(isAr ? 'يرجى إدخال محتوى الإعلان' : 'Please enter announcement content');
      return;
    }

    try {
      setIsSubmitting(true);
      setError(null);
      await onSubmit({
        title: title.trim(),
        content: content.trim(),
        category,
        isPinned,
        authorDisplayName: authorDisplayName.trim() || undefined,
        imageUrl: coverImageUrl.trim() || undefined,
        images: galleryImages.length > 0 ? galleryImages : undefined
      });
      onClose();
    } catch (err: any) {
      console.error('Submit announcement error:', err);
      setError(err.message || (isAr ? 'فشل حفظ الإعلان' : 'Failed to save announcement'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      <div 
        id="announcement-modal-backdrop"
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto bg-black/80 backdrop-blur-md"
      >
        <motion.div
          id="announcement-modal-card"
          initial={{ opacity: 0, scale: 0.96, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 15 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-3xl bg-archive-card border border-archive-cyan/30 rounded-2xl shadow-2xl shadow-cyan-950/50 overflow-hidden flex flex-col max-h-[92vh]"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-archive-cyan/15 bg-archive-dark/80">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-archive-cyan/15 border border-archive-cyan/30 flex items-center justify-center text-archive-cyan">
                <Sparkles size={18} />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-bold text-archive-paper">
                  {mode === 'create'
                    ? (isAr ? 'إنشاء إعلان جديد' : 'Publish New Announcement')
                    : (isAr ? 'تعديل الإعلان' : 'Edit Announcement')}
                </h3>
                <p className="text-xs text-archive-paper-muted">
                  {isAr ? 'بيان رسمي مع دعم إرفاق الصور والوسائط' : 'Official dispatch with photos and media support'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-archive-paper-muted hover:text-archive-paper hover:bg-archive-dark/60 transition-colors"
            >
              <X size={18} />
            </button>
          </div>

          {/* Form Content */}
          <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4">
            {error && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs sm:text-sm flex items-center gap-2">
                <AlertCircle size={16} className="shrink-0 text-rose-400" />
                <span>{error}</span>
              </div>
            )}

            {/* Title Input */}
            <div>
              <label className="block text-xs font-semibold text-archive-paper-muted mb-1.5 uppercase tracking-wider">
                {isAr ? 'عنوان الإعلان *' : 'Announcement Title *'}
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={isAr ? 'اكتب عنواناً بارزاً وموجزاً...' : 'e.g. Major Server Update & Community Directives...'}
                className="w-full px-4 py-2.5 rounded-xl bg-archive-dark/80 border border-archive-cyan/20 focus:border-archive-cyan focus:outline-none focus:ring-1 focus:ring-archive-cyan text-archive-paper text-sm placeholder:text-archive-paper-muted/50"
                maxLength={255}
                required
              />
            </div>

            {/* Category Selector */}
            <div>
              <label className="block text-xs font-semibold text-archive-paper-muted mb-1.5 uppercase tracking-wider flex items-center gap-1.5">
                <Tag size={12} />
                <span>{isAr ? 'التصنيف' : 'Category'}</span>
              </label>
              <div className="flex flex-wrap gap-1.5">
                {ANNOUNCEMENT_CATEGORIES.map((cat) => {
                  const isSelected = category === cat.id;
                  return (
                    <button
                      type="button"
                      key={cat.id}
                      onClick={() => setCategory(cat.id)}
                      className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                        isSelected
                          ? `${cat.color} ring-1 ring-archive-cyan/40 scale-105 font-bold shadow-sm`
                          : 'bg-archive-dark/60 text-archive-paper-muted border border-archive-cyan/10 hover:border-archive-cyan/30 hover:text-archive-paper'
                      }`}
                    >
                      {isAr ? cat.labelAr : cat.labelEn}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Author Name and Pin Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs font-semibold text-archive-paper-muted mb-1.5 uppercase tracking-wider flex items-center gap-1.5">
                  <User size={12} />
                  <span>{isAr ? 'اسم الناشر الظاهر' : 'Author Display Name'}</span>
                </label>
                <input
                  type="text"
                  value={authorDisplayName}
                  onChange={(e) => setAuthorDisplayName(e.target.value)}
                  placeholder={user?.displayName || 'Owner'}
                  className="w-full px-3 py-2 rounded-xl bg-archive-dark/80 border border-archive-cyan/20 focus:border-archive-cyan focus:outline-none text-archive-paper text-xs"
                  maxLength={100}
                />
              </div>

              <div className="flex items-center justify-between sm:justify-start sm:gap-4 p-2.5 rounded-xl bg-archive-dark/40 border border-archive-cyan/15 self-end">
                <div className="flex items-center gap-2">
                  <Pin size={16} className={isPinned ? 'text-amber-400' : 'text-archive-paper-muted'} />
                  <span className="text-xs text-archive-paper font-medium">
                    {isAr ? 'تثبيت في الأعلى' : 'Pin to Top'}
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={isPinned}
                  onChange={(e) => setIsPinned(e.target.checked)}
                  className="w-4 h-4 rounded border-archive-cyan/30 text-archive-cyan focus:ring-archive-cyan focus:ring-offset-archive-dark cursor-pointer accent-archive-cyan"
                />
              </div>
            </div>

            {/* COVER PHOTO SECTION */}
            <div className="pt-2">
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-archive-paper-muted uppercase tracking-wider flex items-center gap-1.5">
                  <ImageIcon size={14} className="text-archive-cyan" />
                  <span>{isAr ? 'صورة الغلاف الرئيسية (اختياري)' : 'Main Cover Photo (Optional)'}</span>
                </label>
                {!coverImageUrl && (
                  <button
                    type="button"
                    onClick={() => setShowCoverUrlInput(!showCoverUrlInput)}
                    className="text-[11px] text-archive-cyan hover:underline flex items-center gap-1"
                  >
                    <LinkIcon size={11} />
                    <span>{showCoverUrlInput ? (isAr ? 'إخفاء الرابط' : 'Hide URL') : (isAr ? 'إضافة عبر رابط' : 'Add via URL')}</span>
                  </button>
                )}
              </div>

              {/* Cover Photo URL Input Bar */}
              {showCoverUrlInput && !coverImageUrl && (
                <div className="mb-2.5 flex items-center gap-2">
                  <input
                    type="url"
                    value={coverUrlInput}
                    onChange={(e) => setCoverUrlInput(e.target.value)}
                    placeholder={isAr ? 'الصق رابط الصورة المباشر (https://...)' : 'Paste direct image URL (https://...)'}
                    className="flex-1 px-3 py-1.5 rounded-xl bg-archive-dark/90 border border-archive-cyan/30 text-xs text-archive-paper focus:outline-none focus:border-archive-cyan"
                  />
                  <button
                    type="button"
                    onClick={handleApplyCoverUrl}
                    className="px-3 py-1.5 rounded-xl bg-archive-cyan text-archive-dark text-xs font-bold hover:bg-archive-cyan/90 transition-colors shrink-0"
                  >
                    {isAr ? 'تطبيق' : 'Apply'}
                  </button>
                </div>
              )}

              {/* Hidden file input */}
              <input
                ref={coverFileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => handleCoverFileSelect(e.target.files)}
              />

              {coverImageUrl ? (
                /* Cover Photo Preview Card */
                <div className="relative rounded-2xl overflow-hidden border border-archive-cyan/30 bg-archive-dark/80 group">
                  <div className="h-44 sm:h-52 w-full overflow-hidden relative">
                    <img 
                      src={coverImageUrl} 
                      alt="Cover Preview" 
                      className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-archive-dark/90 via-black/20 to-transparent" />
                    <div className="absolute top-3 start-3 px-2.5 py-1 rounded-lg bg-archive-dark/80 backdrop-blur-md border border-archive-cyan/30 text-[11px] font-bold text-archive-cyan flex items-center gap-1.5">
                      <Star size={12} className="fill-archive-cyan text-archive-cyan" />
                      <span>{isAr ? 'صورة الغلاف' : 'Cover Photo'}</span>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="p-2.5 bg-archive-dark/95 border-t border-archive-cyan/15 flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => handleInsertMarkdownImage(coverImageUrl, isAr ? 'صورة الغلاف' : 'Cover Photo')}
                      className="px-2.5 py-1 rounded-lg bg-archive-card hover:bg-archive-cyan/15 text-[11px] font-medium text-archive-cyan border border-archive-cyan/20 transition-colors"
                      title={isAr ? 'إدراج في نص الإعلان' : 'Insert into text'}
                    >
                      {isAr ? 'إدراج في النص' : 'Insert in Text'}
                    </button>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => coverFileInputRef.current?.click()}
                        className="px-2.5 py-1 rounded-lg bg-archive-card hover:bg-archive-dark text-[11px] font-medium text-archive-paper-muted hover:text-archive-paper border border-archive-cyan/20 transition-colors"
                      >
                        {isAr ? 'تغيير الصورة' : 'Change'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setCoverImageUrl('')}
                        className="p-1 rounded-lg text-rose-400 hover:bg-rose-500/15 transition-colors"
                        title={isAr ? 'حذف صورة الغلاف' : 'Remove Cover'}
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                /* Cover Photo Dropzone */
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDraggingCover(true);
                  }}
                  onDragLeave={() => setIsDraggingCover(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setIsDraggingCover(false);
                    handleCoverFileSelect(e.dataTransfer.files);
                  }}
                  onClick={() => coverFileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-2xl p-5 text-center cursor-pointer transition-all ${
                    isDraggingCover
                      ? 'border-archive-cyan bg-archive-cyan/10'
                      : 'border-archive-cyan/25 hover:border-archive-cyan/50 bg-archive-dark/50 hover:bg-archive-dark/70'
                  }`}
                >
                  <div className="w-10 h-10 rounded-xl bg-archive-cyan/10 border border-archive-cyan/20 flex items-center justify-center text-archive-cyan mx-auto mb-2">
                    <Upload size={20} />
                  </div>
                  <p className="text-xs font-semibold text-archive-paper mb-0.5">
                    {isAr ? 'اضغط لاختيار صورة الغلاف أو اسحبها إلى هنا' : 'Click to select cover photo, or drag & drop'}
                  </p>
                  <p className="text-[11px] text-archive-paper-muted">
                    {isAr ? 'PNG, JPG, WebP أو GIF (سيتم تحسينها تلقائياً)' : 'PNG, JPG, WebP or GIF (automatically optimized)'}
                  </p>
                </div>
              )}
            </div>

            {/* ADDITIONAL PHOTOS / GALLERY SECTION */}
            <div className="pt-2">
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-archive-paper-muted uppercase tracking-wider flex items-center gap-1.5">
                  <ImageIcon size={14} className="text-archive-cyan/80" />
                  <span>{isAr ? 'معرض الصور المرفقة' : 'Attached Photos Gallery'}</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-archive-cyan/10 text-archive-cyan border border-archive-cyan/20">
                    {galleryImages.length}/8
                  </span>
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowGalleryUrlInput(!showGalleryUrlInput)}
                    className="text-[11px] text-archive-cyan hover:underline flex items-center gap-1"
                  >
                    <LinkIcon size={11} />
                    <span>{isAr ? 'رابط' : 'URL'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => galleryFileInputRef.current?.click()}
                    disabled={galleryImages.length >= 8}
                    className="text-[11px] text-archive-cyan hover:underline flex items-center gap-1 disabled:opacity-40"
                  >
                    <Plus size={11} />
                    <span>{isAr ? 'إضافة صورة' : 'Add Photo'}</span>
                  </button>
                </div>
              </div>

              {/* Gallery URL Input */}
              {showGalleryUrlInput && (
                <div className="mb-2.5 flex items-center gap-2">
                  <input
                    type="url"
                    value={galleryUrlInput}
                    onChange={(e) => setGalleryUrlInput(e.target.value)}
                    placeholder={isAr ? 'الصق رابط الصورة المباشر...' : 'Paste image URL...'}
                    className="flex-1 px-3 py-1.5 rounded-xl bg-archive-dark/90 border border-archive-cyan/30 text-xs text-archive-paper focus:outline-none focus:border-archive-cyan"
                  />
                  <button
                    type="button"
                    onClick={handleApplyGalleryUrl}
                    className="px-3 py-1.5 rounded-xl bg-archive-cyan text-archive-dark text-xs font-bold hover:bg-archive-cyan/90 transition-colors shrink-0"
                  >
                    {isAr ? 'إضافة' : 'Add'}
                  </button>
                </div>
              )}

              {/* Hidden file input for gallery */}
              <input
                ref={galleryFileInputRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={(e) => handleGalleryFilesSelect(e.target.files)}
              />

              {/* Gallery Grid */}
              {galleryImages.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
                  {galleryImages.map((imgUrl, idx) => (
                    <div 
                      key={idx} 
                      className="group relative rounded-xl overflow-hidden border border-archive-cyan/25 bg-archive-dark/90 aspect-video flex flex-col justify-between"
                    >
                      <img src={imgUrl} alt={`Attached photo ${idx + 1}`} className="w-full h-full object-cover" />
                      
                      {/* Overlay buttons on hover */}
                      <div className="absolute inset-0 bg-black/75 opacity-0 group-hover:opacity-100 transition-opacity p-2 flex flex-col justify-between">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-archive-cyan font-mono font-bold">#{idx + 1}</span>
                          <button
                            type="button"
                            onClick={() => handleRemoveGalleryImage(idx)}
                            className="p-1 rounded bg-rose-500/80 hover:bg-rose-600 text-white transition-colors"
                            title={isAr ? 'حذف' : 'Remove'}
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleSetAsCover(imgUrl, idx)}
                            className="flex-1 py-1 rounded bg-archive-card hover:bg-archive-cyan/20 border border-archive-cyan/30 text-[10px] font-bold text-archive-cyan text-center transition-colors"
                            title={isAr ? 'تعيين كغلاف' : 'Make Cover'}
                          >
                            {isAr ? 'غلاف' : 'Cover'}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleInsertMarkdownImage(imgUrl, `Photo ${idx + 1}`)}
                            className="flex-1 py-1 rounded bg-archive-card hover:bg-archive-cyan/20 border border-archive-cyan/30 text-[10px] font-bold text-archive-paper text-center transition-colors"
                            title={isAr ? 'إدراج في النص' : 'Insert'}
                          >
                            {isAr ? 'إدراج' : 'Insert'}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Add more slot button */}
                  {galleryImages.length < 8 && (
                    <button
                      type="button"
                      onClick={() => galleryFileInputRef.current?.click()}
                      className="rounded-xl border border-dashed border-archive-cyan/25 hover:border-archive-cyan/60 bg-archive-dark/40 hover:bg-archive-dark/70 aspect-video flex flex-col items-center justify-center text-archive-cyan/70 hover:text-archive-cyan transition-all"
                    >
                      <Plus size={18} />
                      <span className="text-[10px] font-medium mt-1">{isAr ? 'إضافة صورة' : 'Add Image'}</span>
                    </button>
                  )}
                </div>
              ) : (
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDraggingGallery(true);
                  }}
                  onDragLeave={() => setIsDraggingGallery(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setIsDraggingGallery(false);
                    handleGalleryFilesSelect(e.dataTransfer.files);
                  }}
                  onClick={() => galleryFileInputRef.current?.click()}
                  className={`border border-dashed rounded-xl p-3 text-center cursor-pointer transition-all ${
                    isDraggingGallery
                      ? 'border-archive-cyan bg-archive-cyan/10'
                      : 'border-archive-cyan/20 hover:border-archive-cyan/40 bg-archive-dark/40'
                  }`}
                >
                  <p className="text-[11px] text-archive-paper-muted">
                    {isAr ? 'اسحب الصور المرفقة هنا أو اضغط للاختيار (حتى 8 صور)' : 'Drop additional images here or click to attach (up to 8)'}
                  </p>
                </div>
              )}
            </div>

            {/* Content Tabs (Edit / Preview) */}
            <div className="pt-2">
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-archive-paper-muted uppercase tracking-wider">
                  {isAr ? 'المحتوى (يدعم التنسيق وماركداون) *' : 'Announcement Content (Markdown Supported) *'}
                </label>
                <div className="flex items-center gap-1 bg-archive-dark/80 p-0.5 rounded-lg border border-archive-cyan/20">
                  <button
                    type="button"
                    onClick={() => setActiveTab('edit')}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                      activeTab === 'edit'
                        ? 'bg-archive-cyan/20 text-archive-cyan font-semibold'
                        : 'text-archive-paper-muted hover:text-archive-paper'
                    }`}
                  >
                    <Edit3 size={12} />
                    <span>{isAr ? 'تحرير' : 'Edit'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('preview')}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                      activeTab === 'preview'
                        ? 'bg-archive-cyan/20 text-archive-cyan font-semibold'
                        : 'text-archive-paper-muted hover:text-archive-paper'
                    }`}
                  >
                    <Eye size={12} />
                    <span>{isAr ? 'معاينة' : 'Preview'}</span>
                  </button>
                </div>
              </div>

              {activeTab === 'edit' ? (
                <textarea
                  ref={contentTextareaRef}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={8}
                  placeholder={
                    isAr
                      ? 'اكتب نص الإعلان هنا...\nيمكنك استخدام # للعناوين، و- للقوائم، و**للخط العريض**، و![وصف](رابط) للصور.'
                      : 'Write announcement text here...\nYou can use # for headers, - for bullets, **for bold**, and ![caption](url) for images.'
                  }
                  className="w-full px-4 py-3 rounded-xl bg-archive-dark/80 border border-archive-cyan/20 focus:border-archive-cyan focus:outline-none focus:ring-1 focus:ring-archive-cyan text-archive-paper text-sm placeholder:text-archive-paper-muted/50 font-sans leading-relaxed resize-y min-h-[160px]"
                  required
                />
              ) : (
                <div className="w-full min-h-[160px] max-h-[360px] overflow-y-auto px-4 py-3 rounded-xl bg-archive-dark/95 border border-archive-cyan/25 space-y-4">
                  {/* Cover image in preview */}
                  {coverImageUrl && (
                    <div className="rounded-xl overflow-hidden border border-archive-cyan/20 max-h-56">
                      <img src={coverImageUrl} alt="Cover preview" className="w-full h-auto object-cover" />
                    </div>
                  )}

                  {content.trim() ? (
                    <AnnouncementContentRenderer content={content} />
                  ) : (
                    <p className="text-xs text-archive-paper-muted italic">
                      {isAr ? 'لا يوجد محتوى نصي للمعاينة.' : 'Nothing to preview yet.'}
                    </p>
                  )}

                  {/* Gallery in preview */}
                  {galleryImages.length > 0 && (
                    <div className="pt-3 border-t border-archive-cyan/15">
                      <p className="text-xs font-semibold text-archive-cyan mb-2">
                        {isAr ? 'الصور الإضافية المرفقة:' : 'Attached Images:'}
                      </p>
                      <div className="grid grid-cols-3 gap-2">
                        {galleryImages.map((img, i) => (
                          <img key={i} src={img} alt="Gallery" className="rounded-lg object-cover h-24 w-full border border-archive-cyan/20" />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Footer Buttons */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-archive-cyan/15">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting || isCompressing}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-archive-paper-muted hover:text-archive-paper hover:bg-archive-dark/50 transition-colors"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>

              <button
                type="submit"
                disabled={isSubmitting || isCompressing}
                className="px-5 py-2 rounded-xl bg-archive-cyan text-archive-dark font-bold text-xs hover:bg-archive-cyan/90 transition-all shadow-md shadow-cyan-900/30 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1.5"
              >
                {isSubmitting || isCompressing ? (
                  <>
                    <span className="w-3.5 h-3.5 border-2 border-archive-dark border-t-transparent rounded-full animate-spin" />
                    <span>{isCompressing ? (isAr ? 'جاري معالجة الصور...' : 'Processing photos...') : (isAr ? 'جاري الحفظ...' : 'Publishing...')}</span>
                  </>
                ) : (
                  <span>
                    {mode === 'create'
                      ? (isAr ? 'نشر الإعلان' : 'Publish Announcement')
                      : (isAr ? 'حفظ التعديلات' : 'Save Changes')}
                  </span>
                )}
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
