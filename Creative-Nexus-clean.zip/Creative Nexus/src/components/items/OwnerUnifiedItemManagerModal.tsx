import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Plus,
  Trash2,
  Edit2,
  Upload,
  Crown,
  Heart,
  Wind,
  Shield,
  Swords,
  Sparkles,
  Package,
  Coins,
  Check,
  AlertCircle,
  Eye,
  Sliders,
  Layers,
  Save,
  RotateCcw,
  ArrowRight,
  TrendingUp,
  Percent,
  Flame,
  Zap,
  Info,
  Download,
  FileUp
} from 'lucide-react';
import { useItems } from '../../context/ItemContext';
import { useCards } from '../../context/CardContext';
import { useCardUpgrade } from '../../context/CardUpgradeContext';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import {
  UnifiedItemDefinition,
  ItemCategory,
  BattleItemEffectType,
  DuplicateRewardMode
} from '../../types/items';
import { CardRarity } from '../../types/cards';
import {
  CardUpgradeSystemConfig,
  CardUpgradeTransitionRule,
  DEFAULT_CARD_UPGRADE_CONFIG
} from '../../types/cardUpgrade';
import { BrawlStarsItemDisplay } from './BrawlStarsItemDisplay';

interface OwnerUnifiedItemManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PACK_CHOICES: { id: CardRarity; labelEn: string; labelAr: string }[] = [
  { id: 'COMMON', labelEn: 'Genesis', labelAr: 'جينيسيس' },
  { id: 'UNCOMMON', labelEn: 'Emerald', labelAr: 'إميرالد' },
  { id: 'RARE', labelEn: 'Azure', labelAr: 'كوانتوم' },
  { id: 'EPIC', labelEn: 'Hyperion', labelAr: 'هايبريون' },
  { id: 'LEGENDARY', labelEn: 'Sovereign', labelAr: 'السيادي' }
];

export const OwnerUnifiedItemManagerModal: React.FC<OwnerUnifiedItemManagerModalProps> = ({
  isOpen,
  onClose
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { isOwner } = useAuth();

  const {
    items,
    saveOwnerItem,
    deleteOwnerItem,
    deleteAllOwnerItems,
    importOwnerItems,
    fetchItems: refreshItems,
    duplicateConfig,
    saveDuplicateConfig
  } = useItems();

  const { catalog, ownerImportCards, fetchCatalog } = useCards();
  const backupImportInputRef = useRef<HTMLInputElement>(null);

  const {
    upgradeConfig,
    saveOwnerUpgradeConfig
  } = useCardUpgrade();

  const [activeTab, setActiveTab] = useState<'ITEMS' | 'UPGRADES' | 'DUPLICATES'>('ITEMS');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | ItemCategory>('ALL');
  const [editingItem, setEditingItem] = useState<Partial<UnifiedItemDefinition> | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [feedback, setFeedback] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [confirmDeleteAll, setConfirmDeleteAll] = useState(false);

  // Upgrade settings local form state
  const [upgradeForm, setUpgradeForm] = useState<CardUpgradeSystemConfig>(upgradeConfig);

  // Duplicate settings local form state (strictly shards, 0 coins)
  const [dupForm, setDupForm] = useState(duplicateConfig);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setUpgradeForm(upgradeConfig);
  }, [upgradeConfig]);

  useEffect(() => {
    setDupForm(duplicateConfig);
  }, [duplicateConfig]);

  if (!isOpen) return null;

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setFeedback({ text, type });
    setTimeout(() => setFeedback(null), 3500);
  };

  const handleStartCreate = () => {
    setEditingItem({
      id: '',
      name: '',
      nameAr: '',
      description: '',
      descriptionAr: '',
      imageUrl: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=400&q=80',
      rarity: 'COMMON',
      category: 'UPGRADE_MATERIAL',
      maxStack: 99,
      targetCharacterId: 'ANY',
      lovePoints: 30,
      battleEffect: {
        type: 'HEAL_HP',
        value: 35,
        durationTurns: 0,
        consumesTurn: false,
        maxUsesPerBattle: 2
      },
      packages: ['COMMON', 'UNCOMMON', 'RARE'],
      dropWeight: 40,
      isActive: true
    });
  };

  const handleStartEdit = (item: UnifiedItemDefinition) => {
    setEditingItem({ ...item });
  };

  const handlePngUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast(isAr ? 'يرجى اختيار ملف صورة صالح' : 'Please select a valid image file', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl && editingItem) {
        setEditingItem(prev => prev ? ({ ...prev, imageUrl: dataUrl }) : null);
        showToast(isAr ? 'تم تحميل الصورة الشفافة بنجاح!' : 'PNG image loaded successfully!');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveItem = async () => {
    if (!editingItem || !editingItem.name?.trim()) {
      showToast(isAr ? 'يرجى إدخال اسم العنصر' : 'Please provide item name', 'error');
      return;
    }

    setIsSaving(true);
    try {
      await saveOwnerItem(editingItem);
      showToast(isAr ? 'تم حفظ وتحديث العنصر بنجاح!' : 'Item saved successfully!');
      setEditingItem(null);
    } catch (err: any) {
      showToast(err.message || 'Error saving item', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteItem = async (itemId: string) => {
    try {
      await deleteOwnerItem(itemId);
      showToast(isAr ? 'تم حذف العنصر بنجاح' : 'Item removed successfully');
    } catch (err: any) {
      showToast(err.message || 'Error deleting item', 'error');
    }
  };

  const handleDeleteAll = async () => {
    if (!confirmDeleteAll) {
      setConfirmDeleteAll(true);
      showToast(isAr ? 'اضغط مرة أخرى لتأكيد حذف جميع العناصر نهائياً' : 'Click again to confirm deleting all items permanently', 'error');
      setTimeout(() => setConfirmDeleteAll(false), 5000);
      return;
    }
    setConfirmDeleteAll(false);
    setIsSaving(true);
    try {
      const res = await deleteAllOwnerItems();
      showToast(isAr ? `تم حذف جميع العناصر بنجاح (${res.count})` : `All items deleted successfully (${res.count})`);
    } catch (err: any) {
      showToast(err.message || 'Error deleting all items', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveDuplicateConfig = async () => {
    setIsSaving(true);
    try {
      // Enforce zero coins
      const sanitized = {
        ...dupForm,
        mode: 'UPGRADE_MATERIALS' as DuplicateRewardMode,
        coinsByRarity: {
          COMMON: 0,
          UNCOMMON: 0,
          RARE: 0,
          EPIC: 0,
          LEGENDARY: 0,
          HALLOWEEN_2026: 0
        }
      };
      await saveDuplicateConfig(sanitized);
      showToast(isAr ? 'تم حفظ إعدادات مكافآت الشظايا للتكرار بنجاح!' : 'Duplicate shard rewards configuration saved successfully!');
    } catch (err: any) {
      showToast(err.message || 'Error saving duplicate settings', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveUpgradeConfig = async () => {
    setIsSaving(true);
    try {
      await saveOwnerUpgradeConfig(upgradeForm);
      showToast(isAr ? 'تم حفظ إعدادات ونسب ترقية البطاقات بنجاح!' : 'Card upgrade & ascension rules saved successfully!');
    } catch (err: any) {
      showToast(err.message || 'Error saving upgrade settings', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleExportAllSyncBackup = () => {
    const cardsToExport = Array.isArray(catalog) ? catalog : [];
    const itemsToExport = Array.isArray(items) ? items : [];
    const exportPayload = {
      app: 'Creative Nexus Sovereign Card Studio',
      version: 2,
      backupType: 'full_catalog_backup',
      exportedAt: new Date().toISOString(),
      count: cardsToExport.length,
      cards: cardsToExport,
      items: itemsToExport,
      itemsCount: itemsToExport.length
    };
    const jsonStr = JSON.stringify(exportPayload, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `nexus-all-cards-items-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast(isAr ? `تم تصدير ${cardsToExport.length} بطاقة و ${itemsToExport.length} عنصر بنجاح!` : `Exported ${cardsToExport.length} cards and ${itemsToExport.length} items to backup!`);
  };

  const handleImportSyncBackupFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      let itemsToImport: any[] = [];
      let cardsToImport: any[] = [];

      if (Array.isArray(parsed)) {
        cardsToImport = parsed.filter(p => p && p.rarity && (p.cardType || p.overallRating !== undefined || p.attack !== undefined));
        itemsToImport = parsed.filter(p => p && p.category && (p.lovePoints !== undefined || p.battleEffect !== undefined));
      } else if (parsed && typeof parsed === 'object') {
        if (Array.isArray(parsed.items)) itemsToImport = parsed.items;
        if (Array.isArray(parsed.cards)) cardsToImport = parsed.cards;
        if (Array.isArray(parsed.catalog) && cardsToImport.length === 0) cardsToImport = parsed.catalog;
      }

      let importedItems = 0;
      if (itemsToImport.length > 0) {
        const itemRes = await importOwnerItems(itemsToImport);
        importedItems = itemRes?.count || itemsToImport.length;
        await refreshItems();
      }

      let importedCards = 0;
      if (cardsToImport.length > 0) {
        const cardRes = await ownerImportCards(cardsToImport);
        importedCards = cardRes?.count || cardsToImport.length;
        await fetchCatalog();
      }

      showToast(isAr ? `تم استيراد ${importedCards} بطاقة و ${importedItems} عنصر بنجاح!` : `Successfully restored ${importedCards} cards and ${importedItems} items!`);
    } catch (err: any) {
      showToast(err.message || 'Error importing backup file', 'error');
    } finally {
      if (backupImportInputRef.current) {
        backupImportInputRef.current.value = '';
      }
    }
  };

  const filteredItems = items.filter(i => {
    if (categoryFilter === 'ALL') return true;
    return i.category === categoryFilter;
  });

  const upgradeMaterialItems = items.filter(i => i.category === 'UPGRADE_MATERIAL');

  return (
    <div 
      className="fixed inset-0 z-[70] flex items-center justify-center p-2 sm:p-3 bg-black/80 backdrop-blur-md"
      dir={isAr ? 'rtl' : 'ltr'}
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.96 }}
        className="relative w-full max-w-2xl sm:max-w-3xl max-h-[88dvh] rounded-2xl bg-gradient-to-b from-slate-900 via-slate-950 to-black border border-amber-500/30 shadow-2xl flex flex-col overflow-hidden text-white font-sans text-xs"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header - Compact & Simple */}
        <div className="px-3.5 py-2.5 border-b border-white/10 flex items-center justify-between bg-black/40 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
              <Crown size={15} />
            </div>
            <div>
              <h2 className="text-xs sm:text-sm font-bold text-white tracking-wide">
                {isAr ? 'إدارة العناصر والترقيات' : 'Items & Upgrades Studio'}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 border border-white/10 transition-colors cursor-pointer"
            title={isAr ? 'إغلاق' : 'Close'}
          >
            <X size={15} />
          </button>
        </div>

        {/* Tab Switcher - Compact Segmented Control */}
        <div className="px-3 py-1.5 bg-black/50 border-b border-white/10 flex items-center gap-1.5 shrink-0 overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => setActiveTab('ITEMS')}
            className={`px-3 py-1 rounded-lg font-mono font-bold text-[11px] flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'ITEMS'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Layers size={13} />
            <span>{isAr ? 'العناصر' : 'Items'}</span>
            <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-mono ${activeTab === 'ITEMS' ? 'bg-black/20 text-slate-950' : 'bg-white/10 text-slate-400'}`}>
              {items.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('UPGRADES')}
            className={`px-3 py-1 rounded-lg font-mono font-bold text-[11px] flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'UPGRADES'
                ? 'bg-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <TrendingUp size={13} />
            <span>{isAr ? 'الترقيات' : 'Upgrades'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('DUPLICATES')}
            className={`px-3 py-1 rounded-lg font-mono font-bold text-[11px] flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'DUPLICATES'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Sparkles size={13} />
            <span>{isAr ? 'المكررات' : 'Duplicates'}</span>
          </button>
        </div>

        {/* Toast Feedback */}
        <AnimatePresence>
          {feedback && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="px-3 py-1 bg-slate-950 border-b border-white/10 shrink-0"
            >
              <div className={`px-2.5 py-1.5 rounded-lg border text-[11px] font-mono font-bold flex items-center gap-2 ${
                feedback.type === 'success' 
                  ? 'bg-teal-950/80 border-teal-500/40 text-teal-200' 
                  : 'bg-rose-950/80 border-rose-500/40 text-rose-200'
              }`}>
                {feedback.type === 'success' ? <Check size={13} /> : <AlertCircle size={13} />}
                <span className="truncate">{feedback.text}</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 custom-scrollbar space-y-3">
          {/* ========================================================= */}
          {/* TAB 1: ITEMS CATALOG                                      */}
          {/* ========================================================= */}
          {activeTab === 'ITEMS' && (
            <div className="space-y-3">
              {/* Category Pills & Actions Bar */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1 flex-wrap">
                  {(['ALL', 'UPGRADE_MATERIAL', 'BATTLE', 'COMPANION', 'SPECIAL'] as const).map(cat => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setCategoryFilter(cat)}
                      className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold transition-all border cursor-pointer ${
                        categoryFilter === cat
                          ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-xs'
                          : 'bg-black/40 border-white/10 text-slate-400 hover:text-white'
                      }`}
                    >
                      {cat === 'ALL' ? (isAr ? 'الكل' : 'All') :
                       cat === 'UPGRADE_MATERIAL' ? (isAr ? 'شظايا' : 'Shards') :
                       cat === 'BATTLE' ? (isAr ? 'معركة' : 'Battle') :
                       cat === 'COMPANION' ? (isAr ? 'رفاق' : 'Gifts') :
                       (isAr ? 'خاص' : 'Special')}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-1.5">
                  <input
                    type="file"
                    ref={backupImportInputRef}
                    accept=".json"
                    className="hidden"
                    onChange={handleImportSyncBackupFile}
                  />

                  <button
                    type="button"
                    onClick={handleExportAllSyncBackup}
                    className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-white/5 hover:bg-amber-500/20 text-amber-300 border border-white/10 text-[10px] font-mono font-bold flex items-center gap-1 cursor-pointer transition-colors"
                    title={isAr ? 'تصدير نسخة' : 'Export Sync'}
                  >
                    <Download size={12} />
                    <span className="hidden sm:inline">{isAr ? 'تصدير' : 'Export'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => backupImportInputRef.current?.click()}
                    className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-white/5 hover:bg-teal-500/20 text-teal-300 border border-white/10 text-[10px] font-mono font-bold flex items-center gap-1 cursor-pointer transition-colors"
                    title={isAr ? 'استيراد نسخة' : 'Import Sync'}
                  >
                    <FileUp size={12} />
                    <span className="hidden sm:inline">{isAr ? 'استيراد' : 'Import'}</span>
                  </button>

                  {items.length > 0 && (
                    <button
                      type="button"
                      onClick={handleDeleteAll}
                      className={`p-1.5 sm:px-2.5 sm:py-1 rounded-lg border text-[10px] font-mono font-bold flex items-center gap-1 cursor-pointer transition-all ${
                        confirmDeleteAll
                          ? 'bg-rose-600 text-white border-rose-400 animate-pulse'
                          : 'bg-white/5 hover:bg-rose-500/20 text-rose-300 border-white/10'
                      }`}
                      title={isAr ? 'حذف الكل' : 'Delete All'}
                    >
                      <Trash2 size={12} />
                      <span className="hidden sm:inline">{confirmDeleteAll ? (isAr ? 'تأكيد؟' : 'Confirm?') : (isAr ? 'حذف الكل' : 'Delete All')}</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={handleStartCreate}
                    className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-bold text-[11px] font-mono flex items-center gap-1 shadow-sm hover:brightness-110 active:scale-95 cursor-pointer"
                  >
                    <Plus size={13} />
                    <span>{isAr ? 'عنصر جديد' : 'New Item'}</span>
                  </button>
                </div>
              </div>

              {/* Edit / Create Item Form (Sleek, Compact, No Clutter) */}
              <AnimatePresence>
                {editingItem && (
                  <motion.div
                    initial={{ opacity: 0, y: -6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -6 }}
                    className="p-3 rounded-2xl bg-black/70 border border-amber-400/50 space-y-2.5"
                  >
                    {/* Header */}
                    <div className="flex items-center justify-between pb-1.5 border-b border-white/10">
                      <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                        <Edit2 size={13} />
                        <span>{editingItem.id ? (isAr ? 'تعديل عنصر' : 'Edit Item') : (isAr ? 'إنشاء عنصر' : 'New Item')}</span>
                      </span>
                      <button
                        type="button"
                        onClick={() => setEditingItem(null)}
                        className="p-1 rounded text-slate-400 hover:text-white"
                      >
                        <X size={14} />
                      </button>
                    </div>

                    {/* Compact Top Row: Mini Preview + Name Inputs */}
                    <div className="flex items-center gap-2.5">
                      <div className="shrink-0 w-12 h-12 rounded-xl bg-slate-900 border border-white/15 p-1 flex items-center justify-center overflow-hidden">
                        <img
                          src={editingItem.imageUrl || 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=400&q=80'}
                          alt="preview"
                          className="w-full h-full object-contain"
                          onError={(e) => {
                            (e.target as any).src = 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=400&q=80';
                          }}
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 flex-1 min-w-0">
                        <input
                          type="text"
                          value={editingItem.name || ''}
                          onChange={e => setEditingItem({ ...editingItem, name: e.target.value })}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-black/60 border border-white/15 text-white font-sans text-xs focus:border-amber-400 outline-none"
                          placeholder={isAr ? 'الاسم (EN) *' : 'Name (EN) *'}
                        />
                        <input
                          type="text"
                          value={editingItem.nameAr || ''}
                          onChange={e => setEditingItem({ ...editingItem, nameAr: e.target.value })}
                          className="w-full px-2.5 py-1.5 rounded-lg bg-black/60 border border-white/15 text-white font-sans text-xs focus:border-amber-400 outline-none"
                          placeholder={isAr ? 'الاسم (AR)' : 'Name (AR)'}
                          dir="rtl"
                        />
                      </div>
                    </div>

                    {/* Category (4 Compact Chips) */}
                    <div>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                        {[
                          { id: 'UPGRADE_MATERIAL', icon: Zap, label: isAr ? 'شظية ترقية' : 'Upgrade Shard' },
                          { id: 'BATTLE', icon: Swords, label: isAr ? 'عنصر معركة' : 'Battle Item' },
                          { id: 'COMPANION', icon: Heart, label: isAr ? 'هدية رفيق' : 'Companion Gift' },
                          { id: 'SPECIAL', icon: Sparkles, label: isAr ? 'خاص' : 'Special' }
                        ].map(c => {
                          const IconComp = c.icon;
                          const isSel = (editingItem.category || 'UPGRADE_MATERIAL') === c.id;
                          return (
                            <button
                              key={c.id}
                              type="button"
                              onClick={() => setEditingItem({ ...editingItem, category: c.id as ItemCategory })}
                              className={`py-1.5 px-2 rounded-lg border text-center font-mono text-[10px] font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                                isSel
                                  ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                                  : 'bg-black/50 border-white/10 text-slate-400 hover:text-white'
                              }`}
                            >
                              <IconComp size={12} />
                              <span className="truncate">{c.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Rarity (6 Color Badges) */}
                    <div className="flex flex-wrap gap-1">
                      {[
                        { id: 'COMMON', label: 'Common', active: 'bg-zinc-700 text-white border-zinc-400' },
                        { id: 'UNCOMMON', label: 'Uncommon', active: 'bg-emerald-600 text-white border-emerald-400' },
                        { id: 'RARE', label: 'Rare', active: 'bg-cyan-600 text-white border-cyan-400' },
                        { id: 'EPIC', label: 'Epic', active: 'bg-purple-600 text-white border-purple-400' },
                        { id: 'LEGENDARY', label: 'Legendary', active: 'bg-amber-600 text-white border-amber-400' },
                        { id: 'HALLOWEEN_2026', label: 'Spectral', active: 'bg-violet-600 text-white border-violet-400' }
                      ].map(r => {
                        const isSel = (editingItem.rarity || 'COMMON') === r.id;
                        return (
                          <button
                            key={r.id}
                            type="button"
                            onClick={() => setEditingItem({ ...editingItem, rarity: r.id as CardRarity })}
                            className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold transition-all border cursor-pointer ${
                              isSel ? r.active : 'bg-black/50 border-white/10 text-slate-400 hover:text-white'
                            }`}
                          >
                            {r.label}
                          </button>
                        );
                      })}
                    </div>

                    {/* Artwork & Presets */}
                    <div className="space-y-1.5">
                      <div className="flex gap-1.5">
                        <input
                          type="text"
                          value={editingItem.imageUrl || ''}
                          onChange={e => setEditingItem({ ...editingItem, imageUrl: e.target.value })}
                          className="flex-1 px-2.5 py-1 rounded-lg bg-black/60 border border-white/15 text-white font-mono text-[11px] focus:border-amber-400 outline-none"
                          placeholder="Image URL or upload PNG"
                        />
                        <input
                          type="file"
                          accept="image/png,image/webp,image/jpeg"
                          ref={fileInputRef}
                          className="hidden"
                          onChange={handlePngUpload}
                        />
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-amber-500/20 text-amber-300 border border-white/15 font-mono text-[10px] font-bold flex items-center gap-1 cursor-pointer shrink-0"
                        >
                          <Upload size={12} />
                          <span>PNG</span>
                        </button>
                      </div>

                      {/* 6 Quick Icon Presets */}
                      <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
                        {[
                          { name: 'Shard', url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=400&q=80', cat: 'UPGRADE_MATERIAL' },
                          { name: 'Flask', url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=400&q=80', cat: 'BATTLE' },
                          { name: 'Shield', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=400&q=80', cat: 'BATTLE' },
                          { name: 'Honey', url: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=400&q=80', cat: 'COMPANION' },
                          { name: 'Rose', url: 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?auto=format&fit=crop&w=400&q=80', cat: 'COMPANION' },
                          { name: 'Ring', url: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=400&q=80', cat: 'SPECIAL' }
                        ].map((pre, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => setEditingItem(prev => ({
                              ...prev,
                              imageUrl: pre.url,
                              category: prev?.category ? prev.category : (pre.cat as ItemCategory)
                            }))}
                            className="px-2 py-0.5 rounded-md bg-white/5 hover:bg-amber-500/20 border border-white/10 text-[9px] font-mono text-slate-300 hover:text-amber-200 cursor-pointer shrink-0 transition-colors"
                          >
                            {pre.name}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Eligible Packs Sync */}
                    <div className="p-2 rounded-xl bg-black/40 border border-white/10 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono text-slate-300 font-bold">
                          {isAr ? 'الحزم المسقطة:' : 'Packs:'}
                        </span>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => setEditingItem({
                              ...editingItem,
                              packages: ['COMMON', 'UNCOMMON', 'RARE', 'EPIC', 'LEGENDARY']
                            })}
                            className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[9px] font-mono cursor-pointer"
                          >
                            {isAr ? 'الكل' : 'All'}
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingItem({ ...editingItem, packages: [] })}
                            className="px-1.5 py-0.5 rounded bg-white/5 text-slate-400 text-[9px] font-mono cursor-pointer"
                          >
                            {isAr ? 'إلغاء' : 'Clear'}
                          </button>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-1">
                        {PACK_CHOICES.map(pack => {
                          const isChecked = Array.isArray(editingItem.packages) && editingItem.packages.includes(pack.id);
                          return (
                            <button
                              key={pack.id}
                              type="button"
                              onClick={() => {
                                const cur = editingItem.packages || [];
                                const nxt = isChecked ? cur.filter(p => p !== pack.id) : [...cur, pack.id];
                                setEditingItem({ ...editingItem, packages: nxt });
                              }}
                              className={`px-2 py-0.5 rounded-md border text-[10px] font-mono font-bold transition-all cursor-pointer ${
                                isChecked
                                  ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                                  : 'bg-black/50 border-white/10 text-slate-400'
                              }`}
                            >
                              <span>{isAr ? pack.labelAr : pack.labelEn}</span>
                            </button>
                          );
                        })}
                      </div>

                      <div className="flex items-center justify-between gap-2 pt-1 border-t border-white/5 text-[10px] font-mono text-slate-400">
                        <span>Drop Weight: <span className="text-amber-400 font-bold">{editingItem.dropWeight || 40}</span></span>
                        <input
                          type="range"
                          min="5"
                          max="100"
                          step="5"
                          value={editingItem.dropWeight || 40}
                          onChange={e => setEditingItem({ ...editingItem, dropWeight: parseInt(e.target.value) || 40 })}
                          className="w-32 accent-amber-400 cursor-pointer"
                        />
                      </div>
                    </div>

                    {/* Conditional Settings (Only if Battle / Companion) */}
                    {editingItem.category === 'BATTLE' && (
                      <div className="p-2 rounded-xl bg-cyan-950/30 border border-cyan-500/20 flex items-center justify-between gap-2 text-[10px] font-mono">
                        <span className="text-cyan-300 font-bold">Combat:</span>
                        <select
                          value={editingItem.battleEffect?.type || 'HEAL_HP'}
                          onChange={e => setEditingItem({
                            ...editingItem,
                            battleEffect: {
                              type: e.target.value as BattleItemEffectType,
                              value: editingItem.battleEffect?.value || 35,
                              durationTurns: 0,
                              consumesTurn: false,
                              maxUsesPerBattle: 2
                            }
                          })}
                          className="px-2 py-0.5 rounded bg-black/60 border border-white/15 text-white"
                        >
                          <option value="HEAL_HP">Heal HP</option>
                          <option value="BOOST_ATK">Boost ATK</option>
                          <option value="BOOST_DEF">Boost DEF</option>
                          <option value="SHIELD">Shield</option>
                        </select>
                        <input
                          type="number"
                          value={editingItem.battleEffect?.value || 35}
                          onChange={e => setEditingItem({
                            ...editingItem,
                            battleEffect: {
                              type: editingItem.battleEffect?.type || 'HEAL_HP',
                              value: parseInt(e.target.value) || 35,
                              durationTurns: 0,
                              consumesTurn: false,
                              maxUsesPerBattle: 2
                            }
                          })}
                          className="w-14 px-1.5 py-0.5 rounded bg-black/60 border border-white/15 text-center text-white"
                        />
                      </div>
                    )}

                    {editingItem.category === 'COMPANION' && (
                      <div className="p-2 rounded-xl bg-rose-950/30 border border-rose-500/20 flex items-center justify-between gap-2 text-[10px] font-mono">
                        <span className="text-rose-300 font-bold">Affection:</span>
                        <input
                          type="range"
                          min="10"
                          max="200"
                          step="5"
                          value={editingItem.lovePoints || 30}
                          onChange={e => setEditingItem({ ...editingItem, lovePoints: parseInt(e.target.value) || 30 })}
                          className="flex-1 accent-rose-400 cursor-pointer"
                        />
                        <span className="text-rose-300 font-bold">+{editingItem.lovePoints || 30} pts</span>
                      </div>
                    )}

                    {/* Bottom Buttons */}
                    <div className="flex items-center justify-end gap-2 pt-1.5 border-t border-white/10">
                      <button
                        type="button"
                        onClick={() => setEditingItem(null)}
                        className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-[11px] font-mono cursor-pointer"
                      >
                        {isAr ? 'إلغاء' : 'Cancel'}
                      </button>
                      <button
                        type="button"
                        disabled={isSaving}
                        onClick={handleSaveItem}
                        className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-mono font-bold text-[11px] flex items-center gap-1.5 shadow-sm hover:brightness-110 active:scale-95 cursor-pointer"
                      >
                        <Save size={13} />
                        <span>{isSaving ? (isAr ? 'حفظ...' : 'Saving...') : (isAr ? 'حفظ ومزامنة' : 'Save Item')}</span>
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Items Grid (Compact, Fits Mobile) */}
              {filteredItems.length === 0 ? (
                <div className="p-6 rounded-2xl bg-black/40 border border-white/10 text-center space-y-2">
                  <Package size={20} className="mx-auto text-slate-500" />
                  <p className="text-xs text-slate-400">
                    {isAr ? 'لا توجد عناصر. لن تسقط أي عناصر في الحزم.' : 'No items. Packs will not drop items.'}
                  </p>
                  <button
                    type="button"
                    onClick={handleStartCreate}
                    className="px-3 py-1 rounded-lg bg-amber-500 text-slate-950 font-mono font-bold text-[11px] cursor-pointer"
                  >
                    + {isAr ? 'إنشاء عنصر' : 'Create Item'}
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
                  {filteredItems.map(it => (
                    <div key={it.id} className="relative group flex flex-col items-center bg-black/40 p-2 rounded-xl border border-white/10 hover:border-amber-400/40 transition-colors">
                      <div className="w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center overflow-hidden mb-1">
                        <img src={it.imageUrl} alt={it.name} className="w-full h-full object-contain" />
                      </div>
                      <span className="text-[10px] font-bold text-white truncate w-full text-center">
                        {isAr ? it.nameAr || it.name : it.name}
                      </span>
                      <span className="text-[9px] font-mono text-amber-400/80 uppercase">
                        {it.rarity}
                      </span>

                      {/* Quick Actions */}
                      <div className="absolute top-1 right-1 flex items-center gap-0.5 opacity-90 sm:opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          type="button"
                          onClick={() => handleStartEdit(it)}
                          className="p-1 rounded bg-black/80 hover:bg-amber-500 text-slate-300 hover:text-slate-950 border border-white/20 cursor-pointer"
                        >
                          <Edit2 size={10} />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteItem(it.id)}
                          className="p-1 rounded bg-black/80 hover:bg-rose-500 text-slate-300 hover:text-white border border-white/20 cursor-pointer"
                        >
                          <Trash2 size={10} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 2: UPGRADES                                           */}
          {/* ========================================================= */}
          {activeTab === 'UPGRADES' && (
            <div className="space-y-3">
              {/* Status Toggles Bar */}
              <div className="p-2.5 rounded-xl bg-slate-950 border border-emerald-500/30 flex items-center justify-between gap-2 flex-wrap">
                <span className="text-xs font-bold text-emerald-300">
                  {isAr ? 'نظام ترقية البطاقات' : 'Card Ascension'}
                </span>
                <div className="flex items-center gap-3 font-mono text-[11px]">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={upgradeForm.enabled}
                      onChange={e => setUpgradeForm({ ...upgradeForm, enabled: e.target.checked })}
                      className="accent-emerald-400 w-3.5 h-3.5"
                    />
                    <span>{isAr ? 'مفعّل' : 'Enabled'}</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={upgradeForm.allowUniversalShards}
                      onChange={e => setUpgradeForm({ ...upgradeForm, allowUniversalShards: e.target.checked })}
                      className="accent-cyan-400 w-3.5 h-3.5"
                    />
                    <span>{isAr ? 'الشظية الشاملة' : 'Universal Shard'}</span>
                  </label>
                </div>
              </div>

              {/* 4 Compact Transition Cards */}
              <div className="space-y-2">
                {(['COMMON_TO_UNCOMMON', 'UNCOMMON_TO_RARE', 'RARE_TO_EPIC', 'EPIC_TO_LEGENDARY'] as const).map(key => {
                  const rule: CardUpgradeTransitionRule = upgradeForm.transitions[key] || DEFAULT_CARD_UPGRADE_CONFIG.transitions[key];
                  if (!rule) return null;

                  return (
                    <div
                      key={key}
                      className="p-2.5 rounded-xl bg-black/50 border border-white/10 space-y-2 hover:border-white/20 transition-all text-xs"
                    >
                      {/* Header */}
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 font-mono font-bold text-[10px]">
                          <span className="px-1.5 py-0.5 rounded bg-slate-800 text-white border border-white/10">
                            {rule.fromRarity}
                          </span>
                          <ArrowRight size={11} className="text-amber-400" />
                          <span className="px-1.5 py-0.5 rounded bg-amber-500 text-slate-950">
                            {rule.toRarity}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 font-mono text-[10px]">
                          <span className="text-emerald-300 font-bold">Success: {rule.successRatePercent}%</span>
                          <span className="text-cyan-300 font-bold">+{Math.round(((rule.statMultiplier || 1.2) - 1) * 100)}%</span>
                        </div>
                      </div>

                      {/* 3 Compact Numeric Inputs */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 font-mono text-[10px]">
                        <div className="p-1.5 rounded-lg bg-slate-900 border border-white/10 flex items-center justify-between">
                          <span className="text-slate-400">Req. Copies:</span>
                          <input
                            type="number"
                            min={0}
                            max={20}
                            value={rule.requiredDuplicates ?? 1}
                            onChange={e => {
                              setUpgradeForm({
                                ...upgradeForm,
                                transitions: {
                                  ...upgradeForm.transitions,
                                  [key]: { ...rule, requiredDuplicates: Math.max(0, Number(e.target.value) || 0) }
                                }
                              });
                            }}
                            className="w-12 px-1 py-0.5 rounded bg-slate-950 border border-white/15 text-center text-amber-300 font-bold"
                          />
                        </div>

                        <div className="p-1.5 rounded-lg bg-slate-900 border border-white/10 flex items-center justify-between gap-1">
                          <select
                            value={rule.requiredShardItemId}
                            onChange={e => {
                              setUpgradeForm({
                                ...upgradeForm,
                                transitions: {
                                  ...upgradeForm.transitions,
                                  [key]: { ...rule, requiredShardItemId: e.target.value }
                                }
                              });
                            }}
                            className="w-24 px-1 py-0.5 rounded bg-slate-950 border border-white/15 text-cyan-300 text-[10px] truncate"
                          >
                            <option value="">No Shard</option>
                            {upgradeMaterialItems.map(m => (
                              <option key={m.id} value={m.id}>{m.name}</option>
                            ))}
                          </select>
                          <input
                            type="number"
                            min={0}
                            max={20}
                            value={rule.requiredShardCount}
                            onChange={e => {
                              setUpgradeForm({
                                ...upgradeForm,
                                transitions: {
                                  ...upgradeForm.transitions,
                                  [key]: { ...rule, requiredShardCount: Math.max(0, Number(e.target.value) || 0) }
                                }
                              });
                            }}
                            className="w-10 px-1 py-0.5 rounded bg-slate-950 border border-white/15 text-center text-cyan-300 font-bold"
                          />
                        </div>

                        <div className="p-1.5 rounded-lg bg-slate-900 border border-white/10 flex items-center justify-between">
                          <span className="text-slate-400">Success %:</span>
                          <input
                            type="number"
                            min={1}
                            max={100}
                            value={rule.successRatePercent}
                            onChange={e => {
                              setUpgradeForm({
                                ...upgradeForm,
                                transitions: {
                                  ...upgradeForm.transitions,
                                  [key]: { ...rule, successRatePercent: Math.min(100, Math.max(1, Number(e.target.value) || 10)) }
                                }
                              });
                            }}
                            className="w-12 px-1 py-0.5 rounded bg-slate-950 border border-white/15 text-center text-emerald-300 font-bold"
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}

                {/* Legendary Cap Notice - Compact */}
                <div className="p-2 rounded-xl bg-amber-950/30 border border-amber-500/30 flex items-center justify-between text-[11px] font-mono">
                  <span className="text-amber-300 font-bold flex items-center gap-1.5">
                    <Crown size={12} />
                    <span>LEGENDARY (Max Tier Cap)</span>
                  </span>
                  <span className="text-[10px] text-amber-400/80">Pinnacle</span>
                </div>
              </div>

              {/* Save Button */}
              <div className="flex justify-end pt-1.5 border-t border-white/10">
                <button
                  type="button"
                  disabled={isSaving}
                  onClick={handleSaveUpgradeConfig}
                  className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-mono font-bold text-[11px] flex items-center gap-1.5 shadow-sm hover:brightness-110 active:scale-95 cursor-pointer"
                >
                  <Save size={13} />
                  <span>{isSaving ? (isAr ? 'حفظ...' : 'Saving...') : (isAr ? 'حفظ إعدادات الترقية' : 'Save Upgrades')}</span>
                </button>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 3: DUPLICATE CARDS REWARDS (UPGRADE SHARDS ONLY)       */}
          {/* ========================================================= */}
          {activeTab === 'DUPLICATES' && (
            <div className="space-y-3">
              {/* Minimal Notice */}
              <div className="px-3 py-1.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 flex items-center justify-between text-[11px] font-mono">
                <span className="text-cyan-300 font-bold flex items-center gap-1.5">
                  <Sparkles size={13} />
                  <span>{isAr ? 'شظايا البطاقات المكررة' : 'Duplicate Shards'}</span>
                </span>
                <span className="text-[10px] text-cyan-400/80">{isAr ? '0 عملات (شظايا فقط)' : '0 Coins (Shards Only)'}</span>
              </div>

              {/* 6 Rarity Rows */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                {(['COMMON', 'UNCOMMON', 'RARE', 'EPIC', 'LEGENDARY', 'HALLOWEEN_2026'] as CardRarity[]).map(rarity => {
                  const currentMat = dupForm.materialsByRarity[rarity] || { itemId: 'item_shard_common', count: 1 };
                  return (
                    <div key={rarity} className="p-2 rounded-xl bg-black/50 border border-white/10 flex items-center justify-between gap-2">
                      <span className="text-[10px] font-bold text-amber-300 w-20 truncate">{rarity}</span>
                      <div className="flex items-center gap-1.5">
                        <select
                          value={currentMat.itemId}
                          onChange={e => setDupForm({
                            ...dupForm,
                            materialsByRarity: {
                              ...dupForm.materialsByRarity,
                              [rarity]: {
                                ...currentMat,
                                itemId: e.target.value
                              }
                            }
                          })}
                          className="w-28 px-1.5 py-0.5 rounded bg-black/70 border border-white/15 text-cyan-300 text-[10px] truncate"
                        >
                          {upgradeMaterialItems.map(m => (
                            <option key={m.id} value={m.id}>
                              {m.name}
                            </option>
                          ))}
                        </select>

                        <input
                          type="number"
                          min={0}
                          max={10}
                          value={currentMat.count}
                          onChange={e => setDupForm({
                            ...dupForm,
                            materialsByRarity: {
                              ...dupForm.materialsByRarity,
                              [rarity]: {
                                ...currentMat,
                                count: Number(e.target.value) || 0
                              }
                            }
                          })}
                          className="w-10 px-1 py-0.5 rounded bg-black/60 border border-white/15 text-center text-cyan-300 font-bold text-[10px]"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Save Button */}
              <div className="flex justify-end pt-1.5 border-t border-white/10">
                <button
                  type="button"
                  disabled={isSaving}
                  onClick={handleSaveDuplicateConfig}
                  className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-teal-400 text-slate-950 font-mono font-bold text-[11px] flex items-center gap-1.5 shadow-sm hover:brightness-110 active:scale-95 cursor-pointer"
                >
                  <Save size={13} />
                  <span>{isSaving ? (isAr ? 'حفظ...' : 'Saving...') : (isAr ? 'حفظ شظايا التكرار' : 'Save Duplicates')}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
