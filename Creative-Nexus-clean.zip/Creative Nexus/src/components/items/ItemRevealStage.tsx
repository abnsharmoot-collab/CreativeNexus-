import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BrawlStarsItemDisplay } from './BrawlStarsItemDisplay';
import { PackRewardItem } from '../../types/cards';
import { playItemRevealSound } from '../../utils/cardRevealAudio';
import { ChevronRight, ChevronLeft, Sparkles, Check, RotateCcw, Eye } from 'lucide-react';

interface ItemRevealStageProps {
  item: PackRewardItem;
  currentIndex: number;
  totalItems: number;
  hasNext: boolean;
  onContinue: () => void;
  onFinish: () => void;
  onOpenAnother?: () => void;
  onViewCard?: () => void;
  canAffordAnother?: boolean;
  packPrice?: number;
  isAr?: boolean;
}

export const ItemRevealStage: React.FC<ItemRevealStageProps> = ({
  item,
  currentIndex,
  totalItems,
  hasNext,
  onContinue,
  onFinish,
  onOpenAnother,
  onViewCard,
  canAffordAnother = false,
  packPrice = 0,
  isAr = false
}) => {
  const [isRevealed, setIsRevealed] = useState(false);
  const [isDebouncing, setIsDebouncing] = useState(false);
  const revealTimerRef = useRef<number | null>(null);

  // Trigger separate item reveal animation whenever item changes
  useEffect(() => {
    setIsRevealed(false);
    setIsDebouncing(true);

    // Play punchy arcade item reveal sound
    try {
      playItemRevealSound(item.rarity, 0.85);
    } catch {}

    revealTimerRef.current = window.setTimeout(() => {
      setIsRevealed(true);
      setIsDebouncing(false);
    }, 180);

    return () => {
      if (revealTimerRef.current) clearTimeout(revealTimerRef.current);
    };
  }, [item.id, currentIndex, item.rarity]);

  const handleTapContinue = () => {
    if (isDebouncing) return;
    setIsDebouncing(true);
    setTimeout(() => {
      onContinue();
    }, 120);
  };

  const getRarityGlow = () => {
    switch (item.rarity) {
      case 'LEGENDARY':
        return 'rgba(245, 158, 11, 0.45)';
      case 'EPIC':
        return 'rgba(217, 70, 239, 0.45)';
      case 'RARE':
        return 'rgba(59, 130, 246, 0.4)';
      case 'UNCOMMON':
        return 'rgba(16, 185, 129, 0.4)';
      case 'HALLOWEEN_2026':
        return 'rgba(45, 212, 191, 0.5)';
      default:
        return 'rgba(56, 189, 248, 0.35)';
    }
  };

  const rarityGlow = getRarityGlow();

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-between py-2 sm:py-4 select-none">
      {/* 1. Header with Reward Counter & Badge */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full flex flex-col items-center gap-1.5 shrink-0 z-20"
      >
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-950/80 border border-white/10 shadow-lg backdrop-blur-md">
          <Sparkles size={13} className="text-amber-300 animate-spin-slow" />
          <span className="text-[11px] sm:text-xs font-mono font-bold tracking-widest uppercase text-amber-200">
            {isAr ? 'عنصر مكافأة إضافي' : 'BONUS ITEM REWARD'}
          </span>
          {totalItems > 1 && (
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/10 text-stone-300 border border-white/10 font-bold">
              {currentIndex + 1} / {totalItems}
            </span>
          )}
        </div>

        {/* Step dots if multiple items */}
        {totalItems > 1 && (
          <div className="flex items-center gap-1.5 mt-0.5">
            {Array.from({ length: totalItems }).map((_, idx) => (
              <div
                key={idx}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  idx === currentIndex
                    ? 'w-5 bg-gradient-to-r from-amber-400 to-yellow-300 shadow-[0_0_8px_rgba(245,158,11,0.8)]'
                    : idx < currentIndex
                    ? 'w-2 bg-emerald-400/70'
                    : 'w-2 bg-white/20'
                }`}
              />
            ))}
          </div>
        )}
      </motion.div>

      {/* 2. Main Arena: Separate Item Display with Independent Reveal Animation */}
      <div className="relative w-full flex-1 flex items-center justify-center my-auto min-h-0 py-3">
        {/* Dynamic Shockwave Flare on Reveal */}
        <AnimatePresence mode="wait">
          <motion.div
            key={item.id + currentIndex}
            initial={{ scale: 0.2, opacity: 1 }}
            animate={{ scale: [0.2, 1.8, 2.2], opacity: [0.8, 0.4, 0] }}
            transition={{ duration: 0.65, ease: 'easeOut' }}
            className="absolute w-48 h-48 sm:w-64 sm:h-64 rounded-full pointer-events-none z-0"
            style={{
              background: `radial-gradient(circle, ${rarityGlow} 0%, transparent 70%)`
            }}
          />
        </AnimatePresence>

        {/* Shimmering Starburst Rays */}
        <div
          className="absolute w-72 h-72 sm:w-88 sm:h-88 rounded-full blur-2xl pointer-events-none opacity-40 z-0 animate-pulse"
          style={{ backgroundColor: rarityGlow }}
        />

        {/* THE BRAWL STARS ITEM DISPLAY COMPONENT */}
        <motion.div
          key={item.id + currentIndex}
          initial={{ scale: 0.4, opacity: 0, y: 30, rotateZ: -6 }}
          animate={{ scale: 1, opacity: 1, y: 0, rotateZ: 0 }}
          transition={{
            type: 'spring',
            stiffness: 340,
            damping: 22,
            mass: 0.8
          }}
          className="relative z-10 flex flex-col items-center"
        >
          <BrawlStarsItemDisplay
            item={{
              id: item.id,
              name: item.name,
              nameAr: item.nameAr,
              description: item.description,
              descriptionAr: item.descriptionAr,
              imageUrl: item.imageUrl,
              rarity: item.rarity,
              category: item.category,
              battleEffect: item.battleEffect,
              lovePoints: item.lovePoints
            }}
            count={item.count || 1}
            size="large"
            isHoverable={true}
            isAr={isAr}
            showDetails={true}
          />
        </motion.div>
      </div>

      {/* 3. Bottom Controls: Subtle & Elegant 'Tap to Continue' Button */}
      <div className="w-full max-w-sm pt-2 shrink-0 z-30">
        <AnimatePresence mode="wait">
          {hasNext ? (
            <motion.div
              key="continue-btn"
              initial={{ opacity: 0, y: 8, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -6, scale: 0.96 }}
              transition={{ duration: 0.24 }}
              className="flex flex-col items-center gap-2"
            >
              {/* Subtle Elegant Continuation Button */}
              <button
                type="button"
                onClick={handleTapContinue}
                disabled={isDebouncing}
                className="group relative w-full py-3 px-5 rounded-2xl bg-gradient-to-r from-teal-950/80 via-slate-900/90 to-teal-950/80 hover:from-teal-900/90 hover:to-slate-800 text-stone-200 border border-teal-500/40 hover:border-teal-400 shadow-[0_4px_20px_rgba(20,184,166,0.2)] hover:shadow-[0_6px_25px_rgba(94,234,212,0.35)] backdrop-blur-md transition-all duration-200 flex items-center justify-between cursor-pointer active:scale-98 disabled:opacity-60"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-2 h-2 rounded-full bg-teal-400 animate-ping" />
                  <span className="font-serif font-bold text-xs uppercase tracking-widest text-teal-200 group-hover:text-white transition-colors">
                    {isAr ? 'انقر للمتابعة' : 'Tap to Continue'}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 text-stone-400 group-hover:text-teal-300 font-mono text-[11px] font-semibold transition-colors">
                  <span>{isAr ? `متبقي ${totalItems - currentIndex - 1}` : `${totalItems - currentIndex - 1} left`}</span>
                  {isAr ? (
                    <ChevronLeft size={16} className="transition-transform group-hover:-translate-x-1" />
                  ) : (
                    <ChevronRight size={16} className="transition-transform group-hover:translate-x-1" />
                  )}
                </div>

                {/* Subtle top edge shimmer */}
                <div className="absolute top-0 inset-x-4 h-px bg-gradient-to-r from-transparent via-teal-300/40 to-transparent pointer-events-none" />
              </button>

              <span className="text-[10px] font-sans text-stone-500 tracking-wide">
                {isAr ? 'عناصر الحقيبة محفوظة تلقائياً' : 'Granted directly to your inventory'}
              </span>
            </motion.div>
          ) : (
            <motion.div
              key="finish-controls"
              initial={{ opacity: 0, y: 8, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.3 }}
              className="space-y-2.5"
            >
              <div className="flex items-center gap-2">
                {onViewCard && (
                  <button
                    type="button"
                    onClick={onViewCard}
                    className="py-2.5 px-3.5 rounded-xl font-sans font-medium text-xs text-stone-300 hover:text-white bg-black/50 hover:bg-black/80 border border-white/15 flex items-center justify-center gap-1.5 transition-colors cursor-pointer shrink-0"
                    title="View Unlocked Card"
                  >
                    <Eye size={14} />
                    <span className="hidden xs:inline">{isAr ? 'عرض البطاقة' : 'View Card'}</span>
                  </button>
                )}

                {canAffordAnother && onOpenAnother ? (
                  <button
                    type="button"
                    onClick={onOpenAnother}
                    className="flex-1 py-2.5 px-4 rounded-xl font-serif font-bold text-xs uppercase tracking-wider text-stone-950 bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 hover:brightness-110 shadow-lg shadow-amber-500/10 flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                  >
                    <RotateCcw size={14} />
                    <span>{isAr ? `فتح حزمة أخرى (${packPrice} 🪙)` : `Open Again (${packPrice} 🪙)`}</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={onFinish}
                    className="flex-1 py-2.5 px-4 rounded-xl font-serif font-bold text-xs uppercase tracking-wider text-stone-950 bg-gradient-to-r from-amber-400 to-amber-300 hover:brightness-110 flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-md"
                  >
                    <Check size={14} />
                    <span>{isAr ? 'استلام الكل ومتابعة' : 'Collect All & Continue'}</span>
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
