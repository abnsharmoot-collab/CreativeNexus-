import React from 'react';
import { motion } from 'motion/react';
import { UnifiedItemDefinition } from '../../types/items';
import { CardRarity } from '../../types/cards';
import { Sparkles, Swords, Heart, Shield, Zap, Layers, Star, Info } from 'lucide-react';

interface BrawlStarsItemDisplayProps {
  item: UnifiedItemDefinition | Partial<UnifiedItemDefinition>;
  count?: number;
  size?: 'compact' | 'standard' | 'large';
  onClick?: () => void;
  isHoverable?: boolean;
  isAr?: boolean;
  showDetails?: boolean;
  className?: string;
}

interface RarityStyleConfig {
  nameEn: string;
  nameAr: string;
  badgeBg: string;
  badgeBorder: string;
  badgeText: string;
  outerBorder: string;
  outerGlow: string;
  bgGradient: string;
  burstColor1: string;
  burstColor2: string;
  accentHex: string;
  stars: number;
}

const BRAWL_RARITY_THEMES: Record<CardRarity, RarityStyleConfig> = {
  COMMON: {
    nameEn: 'COMMON',
    nameAr: 'شائع',
    badgeBg: 'bg-gradient-to-b from-sky-400 to-blue-600',
    badgeBorder: 'border-sky-300',
    badgeText: 'text-white',
    outerBorder: 'border-sky-400/80',
    outerGlow: 'shadow-[0_10px_25px_rgba(56,189,248,0.35)]',
    bgGradient: 'from-slate-900 via-sky-950/60 to-black',
    burstColor1: 'rgba(56,189,248,0.25)',
    burstColor2: 'rgba(14,165,233,0.05)',
    accentHex: '#38bdf8',
    stars: 1
  },
  UNCOMMON: {
    nameEn: 'RARE',
    nameAr: 'مميز',
    badgeBg: 'bg-gradient-to-b from-emerald-400 to-green-600',
    badgeBorder: 'border-emerald-300',
    badgeText: 'text-white',
    outerBorder: 'border-emerald-400/80',
    outerGlow: 'shadow-[0_10px_25px_rgba(16,185,129,0.35)]',
    bgGradient: 'from-slate-900 via-emerald-950/60 to-black',
    burstColor1: 'rgba(16,185,129,0.25)',
    burstColor2: 'rgba(5,150,105,0.05)',
    accentHex: '#10b981',
    stars: 2
  },
  RARE: {
    nameEn: 'SUPER RARE',
    nameAr: 'نادر جداً',
    badgeBg: 'bg-gradient-to-b from-blue-500 to-indigo-700',
    badgeBorder: 'border-blue-300',
    badgeText: 'text-white',
    outerBorder: 'border-blue-500/80',
    outerGlow: 'shadow-[0_10px_25px_rgba(59,130,246,0.45)]',
    bgGradient: 'from-slate-900 via-indigo-950/70 to-black',
    burstColor1: 'rgba(59,130,246,0.35)',
    burstColor2: 'rgba(29,78,216,0.08)',
    accentHex: '#3b82f6',
    stars: 3
  },
  EPIC: {
    nameEn: 'EPIC',
    nameAr: 'ملحمي',
    badgeBg: 'bg-gradient-to-b from-fuchsia-500 to-purple-700',
    badgeBorder: 'border-fuchsia-300',
    badgeText: 'text-white',
    outerBorder: 'border-fuchsia-400/80',
    outerGlow: 'shadow-[0_10px_30px_rgba(217,70,239,0.45)]',
    bgGradient: 'from-slate-900 via-purple-950/70 to-black',
    burstColor1: 'rgba(217,70,239,0.35)',
    burstColor2: 'rgba(147,51,234,0.08)',
    accentHex: '#d946ef',
    stars: 4
  },
  LEGENDARY: {
    nameEn: 'LEGENDARY',
    nameAr: 'أسطوري',
    badgeBg: 'bg-gradient-to-b from-amber-400 via-yellow-500 to-amber-600',
    badgeBorder: 'border-amber-200',
    badgeText: 'text-slate-950 font-black',
    outerBorder: 'border-amber-400',
    outerGlow: 'shadow-[0_12px_35px_rgba(245,158,11,0.55)]',
    bgGradient: 'from-slate-900 via-amber-950/70 to-black',
    burstColor1: 'rgba(245,158,11,0.4)',
    burstColor2: 'rgba(217,119,6,0.1)',
    accentHex: '#f59e0b',
    stars: 5
  },
  HALLOWEEN_2026: {
    nameEn: 'SPECTRAL',
    nameAr: 'طيفي نادر',
    badgeBg: 'bg-gradient-to-b from-teal-400 to-emerald-600',
    badgeBorder: 'border-teal-200',
    badgeText: 'text-slate-950 font-black',
    outerBorder: 'border-teal-400',
    outerGlow: 'shadow-[0_12px_35px_rgba(45,212,191,0.55)]',
    bgGradient: 'from-slate-900 via-teal-950/70 to-black',
    burstColor1: 'rgba(45,212,191,0.4)',
    burstColor2: 'rgba(13,148,136,0.1)',
    accentHex: '#2dd4bf',
    stars: 5
  }
};

export const BrawlStarsItemDisplay: React.FC<BrawlStarsItemDisplayProps> = ({
  item,
  count,
  size = 'standard',
  onClick,
  isHoverable = true,
  isAr = false,
  showDetails = true,
  className = ''
}) => {
  const rarity: CardRarity = item.rarity || 'COMMON';
  const theme = BRAWL_RARITY_THEMES[rarity] || BRAWL_RARITY_THEMES.COMMON;

  // Determine Category Badge & Icons
  const category = item.category || 'UPGRADE_MATERIAL';

  const getCategoryInfo = () => {
    switch (category) {
      case 'UPGRADE_MATERIAL':
        return {
          label: isAr ? 'شظية ترقية' : 'UPGRADE SHARD',
          icon: <Sparkles size={11} className="text-amber-300" />,
          chipBg: 'bg-amber-950/80 border-amber-500/50 text-amber-200'
        };
      case 'BATTLE':
        return {
          label: isAr ? 'عنصر معركة' : 'BATTLE ITEM',
          icon: <Swords size={11} className="text-cyan-300" />,
          chipBg: 'bg-cyan-950/80 border-cyan-500/50 text-cyan-200'
        };
      case 'COMPANION':
        return {
          label: isAr ? 'هدية محبة' : 'COMPANION GIFT',
          icon: <Heart size={11} className="text-rose-300" />,
          chipBg: 'bg-rose-950/80 border-rose-500/50 text-rose-200'
        };
      default:
        return {
          label: isAr ? 'عنصر مميز' : 'SPECIAL ITEM',
          icon: <Star size={11} className="text-yellow-300" />,
          chipBg: 'bg-purple-950/80 border-purple-500/50 text-purple-200'
        };
    }
  };

  const catInfo = getCategoryInfo();

  // Primary effect or power value tag
  const getEffectTag = () => {
    if (category === 'BATTLE' && item.battleEffect) {
      const ef = item.battleEffect;
      if (ef.type === 'HEAL_HP') return `+${ef.value} HP`;
      if (ef.type === 'RESTORE_STAMINA') return `+${ef.value} STM`;
      if (ef.type === 'GRANT_SHIELD') return `+${ef.value} SHIELD`;
      if (ef.type === 'BUFF_ATTACK') return `+${ef.value}% ATK`;
      if (ef.type === 'BUFF_DEFENSE') return `+${ef.value}% DEF`;
    }
    if (category === 'COMPANION' && typeof item.lovePoints === 'number') {
      return `+${item.lovePoints} ♥`;
    }
    if (category === 'UPGRADE_MATERIAL') {
      return isAr ? 'محفز صعود' : 'ASCENSION SHARD';
    }
    return null;
  };

  const effectTag = getEffectTag();

  // Size specific stylings
  const isCompact = size === 'compact';
  const isLarge = size === 'large';

  return (
    <motion.div
      onClick={onClick}
      whileHover={isHoverable ? { y: -4, scale: 1.02 } : undefined}
      whileTap={isHoverable ? { scale: 0.98 } : undefined}
      className={`relative select-none flex flex-col items-center justify-between overflow-hidden rounded-[26px] border-2 ${theme.outerBorder} ${theme.outerGlow} bg-gradient-to-b ${theme.bgGradient} transition-all ${
        onClick ? 'cursor-pointer' : ''
      } ${
        isCompact
          ? 'w-[140px] p-2.5 min-h-[175px]'
          : isLarge
          ? 'w-[280px] p-4 min-h-[360px]'
          : 'w-[195px] p-3.5 min-h-[255px]'
      } ${className}`}
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* 1. ARCADE TOP INNER BEVEL HIGHLIGHT */}
      <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-transparent via-white/30 to-transparent pointer-events-none" />

      {/* 2. BRAWL STARS ROTATING / RADIAL STARBURST BACKGROUND */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-40">
        <div
          className="absolute -inset-10 animate-spin-slow origin-center"
          style={{
            backgroundImage: `conic-gradient(from 0deg, ${theme.burstColor1} 0deg 20deg, transparent 20deg 40deg, ${theme.burstColor1} 40deg 60deg, transparent 60deg 80deg, ${theme.burstColor1} 80deg 100deg, transparent 100deg 120deg, ${theme.burstColor1} 120deg 140deg, transparent 140deg 160deg, ${theme.burstColor1} 160deg 180deg, transparent 180deg 200deg, ${theme.burstColor1} 200deg 220deg, transparent 220deg 240deg, ${theme.burstColor1} 240deg 260deg, transparent 260deg 280deg, ${theme.burstColor1} 280deg 300deg, transparent 300deg 320deg, ${theme.burstColor1} 320deg 340deg, transparent 340deg 360deg)`
          }}
        />
        <div
          className="absolute inset-0"
          style={{
            background: `radial-gradient(circle at 50% 45%, ${theme.burstColor1} 0%, transparent 70%)`
          }}
        />
      </div>

      {/* 3. BRAWL STARS ANGULAR RARITY BANNER (TOP) */}
      <div className="relative z-10 w-full flex items-center justify-between gap-1.5">
        <div
          className={`px-2.5 py-0.5 rounded-lg border shadow-md font-sans font-black uppercase tracking-wider flex items-center gap-1 ${
            theme.badgeBg
          } ${theme.badgeBorder} ${theme.badgeText} ${
            isCompact ? 'text-[8.5px]' : isLarge ? 'text-xs' : 'text-[9.5px]'
          }`}
          style={{
            textShadow: '0 2px 4px rgba(0,0,0,0.8)'
          }}
        >
          <span>{isAr ? theme.nameAr : theme.nameEn}</span>
          <div className="flex items-center -space-x-0.5">
            {Array.from({ length: theme.stars }).map((_, i) => (
              <Star
                key={i}
                size={isCompact ? 7 : 9}
                className="fill-yellow-300 text-yellow-300 drop-shadow-sm"
              />
            ))}
          </div>
        </div>

        {/* Quantity Multiplier Pill (Brawl Stars style: 3D beveled yellow pill) */}
        {typeof count === 'number' && (
          <div
            className={`font-mono font-black rounded-lg px-2 py-0.5 bg-gradient-to-b from-amber-300 to-yellow-500 text-slate-950 border border-yellow-200 shadow-[0_3px_0_rgba(180,83,9,0.8)] leading-tight ${
              isCompact ? 'text-[9px]' : isLarge ? 'text-xs' : 'text-[10px]'
            }`}
          >
            x{count}
          </div>
        )}
      </div>

      {/* 4. FLOATING 3D ITEM ARTWORK WITH PULSING BACKLIGHT */}
      <div className="relative z-10 my-auto flex items-center justify-center py-2">
        {/* Soft Ambient Radial Backlight */}
        <div
          className="absolute w-24 h-24 rounded-full blur-xl pointer-events-none"
          style={{
            backgroundColor: theme.accentHex,
            opacity: 0.35
          }}
        />

        <motion.div
          animate={{
            y: [-3, 3, -3]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: 'easeInOut'
          }}
          className="relative"
        >
          <img
            src={item.imageUrl || 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=400&q=80'}
            alt={item.name || 'Item'}
            className={`object-contain drop-shadow-[0_14px_20px_rgba(0,0,0,0.9)] transition-transform ${
              isCompact ? 'w-16 h-16' : isLarge ? 'w-28 h-28' : 'w-20 h-20'
            }`}
          />
        </motion.div>
      </div>

      {/* 5. ITEM INFO BAR (BOTTOM) */}
      <div className="relative z-10 w-full flex flex-col items-center text-center space-y-1.5 pt-1">
        {/* Category & Stat Chips */}
        <div className="flex items-center justify-center gap-1.5 flex-wrap w-full">
          <span
            className={`px-1.5 py-0.5 rounded-md border flex items-center gap-1 font-mono font-bold tracking-tight ${
              catInfo.chipBg
            } ${isCompact ? 'text-[7.5px]' : 'text-[8.5px]'}`}
          >
            {catInfo.icon}
            <span>{catInfo.label}</span>
          </span>

          {effectTag && (
            <span
              className={`px-1.5 py-0.5 rounded-md font-mono font-extrabold bg-slate-950/90 border border-white/20 text-white shadow-inner ${
                isCompact ? 'text-[7.5px]' : 'text-[8.5px]'
              }`}
            >
              {effectTag}
            </span>
          )}
        </div>

        {/* Item Name with Bold Shadow */}
        <h4
          className={`font-sans font-black text-white leading-tight tracking-wide line-clamp-1 ${
            isCompact ? 'text-xs' : isLarge ? 'text-base' : 'text-sm'
          }`}
          style={{
            textShadow: '0 2px 8px rgba(0,0,0,0.9)'
          }}
          title={isAr && item.nameAr ? item.nameAr : item.name}
        >
          {isAr && item.nameAr ? item.nameAr : item.name || 'Unknown Item'}
        </h4>

        {/* Brief description in standard/large view */}
        {showDetails && !isCompact && (
          <p className="text-[10px] text-slate-300/80 line-clamp-2 leading-relaxed px-1">
            {isAr && item.descriptionAr ? item.descriptionAr : item.description || ''}
          </p>
        )}
      </div>

      {/* 6. BOTTOM ARCADE BEVEL SHADOW */}
      <div className="absolute bottom-0 inset-x-0 h-1 bg-black/40 pointer-events-none" />
    </motion.div>
  );
};
