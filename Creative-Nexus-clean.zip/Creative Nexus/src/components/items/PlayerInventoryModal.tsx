import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useItems } from '../../context/ItemContext';
import { useCards } from '../../context/CardContext';
import { useCardUpgrade } from '../../context/CardUpgradeContext';
import { BrawlStarsItemDisplay } from './BrawlStarsItemDisplay';
import { UnifiedItemDefinition, ItemCategory, UserItemOwnership } from '../../types/items';
import { 
  X, Backpack, Sparkles, Swords, Heart, 
  HelpCircle, ChevronRight, Layers, ArrowUpRight
} from 'lucide-react';

interface PlayerInventoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  isAr?: boolean;
  onSelectCardToUpgrade?: (cardId: string) => void;
}

export const PlayerInventoryModal: React.FC<PlayerInventoryModalProps> = ({
  isOpen,
  onClose,
  isAr = false,
  onSelectCardToUpgrade
}) => {
  const { items, inventory, inventoryMap, loading } = useItems();
  const { allCatalog, profile } = useCards();
  const { upgradeConfig } = useCardUpgrade();

  const [activeTab, setActiveTab] = useState<'ALL' | ItemCategory>('ALL');
  const [selectedItem, setSelectedItem] = useState<UnifiedItemDefinition | null>(null);

  // Strictly items owned by the player with count > 0
  const ownedItemsWithCounts = useMemo(() => {
    const list: Array<{ item: UnifiedItemDefinition; count: number }> = [];
    const seen = new Set<string>();

    if (Array.isArray(inventory)) {
      for (const entry of inventory) {
        if (entry && entry.count > 0) {
          const def = items.find(i => i.id === entry.itemId) || (entry.itemData as UnifiedItemDefinition);
          if (def) {
            seen.add(def.id);
            list.push({ item: def, count: entry.count });
          }
        }
      }
    }

    if (inventoryMap && typeof inventoryMap === 'object') {
      for (const [id, entry] of Object.entries(inventoryMap) as [string, UserItemOwnership][]) {
        if (entry && entry.count > 0 && !seen.has(id)) {
          const def = items.find(i => i.id === id) || (entry.itemData as UnifiedItemDefinition);
          if (def) {
            seen.add(def.id);
            list.push({ item: def, count: entry.count });
          }
        }
      }
    }

    return list;
  }, [items, inventory, inventoryMap]);

  // Filter based on tab - strictly owned items only!
  const filteredList = useMemo(() => {
    return ownedItemsWithCounts.filter(({ item, count }) => {
      if (count <= 0) return false;
      if (activeTab !== 'ALL' && (item.category || 'UPGRADE_MATERIAL') !== activeTab) {
        return false;
      }
      return true;
    });
  }, [ownedItemsWithCounts, activeTab]);

  // Sync selected item with currently filtered list of owned items
  useEffect(() => {
    if (filteredList.length > 0) {
      if (!selectedItem || !filteredList.some(f => f.item.id === selectedItem.id)) {
        setSelectedItem(filteredList[0].item);
      }
    } else {
      setSelectedItem(null);
    }
  }, [filteredList]);

  // Total shards count owned
  const totalShardsCount = useMemo(() => {
    return ownedItemsWithCounts
      .filter(({ item }) => (item.category || 'UPGRADE_MATERIAL') === 'UPGRADE_MATERIAL')
      .reduce((sum, { count }) => sum + count, 0);
  }, [ownedItemsWithCounts]);

  if (!isOpen) return null;

  // Find cards in player's collection eligible for upgrade with this shard
  const getEligibleCardsForShard = (shardId: string) => {
    if (!profile?.cards) return [];
    
    // Find transitions that use this shard or if it's universal
    const isUniversal = upgradeConfig.allowUniversalShards && shardId === upgradeConfig.universalShardItemId;
    
    return Object.entries(profile.cards).map(([cardId, ownership]) => {
      const baseCard = allCatalog.find(c => c.id === cardId);
      const ownerObj = ownership as any;
      const currentRarity = ownerObj?.upgradedRarity || baseCard.rarity;
      if (currentRarity === 'LEGENDARY') return null; // Already max

      // Check transition rule
      const nextRarity = 
        currentRarity === 'COMMON' ? 'UNCOMMON' :
        currentRarity === 'UNCOMMON' ? 'RARE' :
        currentRarity === 'RARE' ? 'EPIC' :
        currentRarity === 'EPIC' ? 'LEGENDARY' : null;

      if (!nextRarity) return null;
      const rule = upgradeConfig.transitions[`${currentRarity}_TO_${nextRarity}`];
      if (!rule) return null;

      if (rule.requiredShardItemId === shardId || isUniversal) {
        return {
          card: baseCard,
          currentRarity,
          nextRarity,
          requiredCount: rule.requiredShardCount,
          successRate: rule.successRatePercent
        };
      }
      return null;
    }).filter(Boolean);
  };

  const eligibleCards = selectedItem && (selectedItem.category || 'UPGRADE_MATERIAL') === 'UPGRADE_MATERIAL'
    ? getEligibleCardsForShard(selectedItem.id)
    : [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md overflow-hidden">
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 15 }}
        className="relative w-full max-w-4xl max-h-[90vh] bg-gradient-to-b from-[#0b171c] via-[#071014] to-black rounded-3xl border border-teal-500/30 shadow-[0_20px_70px_rgba(0,0,0,0.9)] flex flex-col overflow-hidden"
        dir={isAr ? 'rtl' : 'ltr'}
      >
        {/* Top Metallic Bevel Highlight */}
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-[#5eead4]/60 to-transparent pointer-events-none" />

        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between gap-3 bg-slate-950/60 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-teal-400 to-emerald-600 flex items-center justify-center text-slate-950 shadow-md">
              <Backpack size={20} />
            </div>
            <div>
              <h2 className="font-display font-black text-base sm:text-lg text-white flex items-center gap-2">
                <span>{isAr ? 'حقيبة المواد والشظايا' : 'Player Inventory & Upgrade Shards'}</span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                  {totalShardsCount} {isAr ? 'شظية' : 'Shards'}
                </span>
              </h2>
              <p className="text-xs text-stone-400">
                {isAr 
                  ? 'استعرض شظايا الترقية، عناصر المعارك التكتيكية، وهدايا المحبة' 
                  : 'Manage your ascension shards, tactical battle items, and companion gifts'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-stone-400 hover:text-white transition-all cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="px-4 py-2.5 bg-black/40 border-b border-white/10 flex items-center gap-2 overflow-x-auto studio-scrollbar shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('ALL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'ALL'
                ? 'bg-[#5eead4] text-slate-950 font-black shadow-sm'
                : 'bg-white/5 text-stone-400 hover:text-white'
            }`}
          >
            <Layers size={13} />
            <span>{isAr ? 'الكل' : 'All Items'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('UPGRADE_MATERIAL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'UPGRADE_MATERIAL'
                ? 'bg-amber-400 text-slate-950 font-black shadow-sm'
                : 'bg-white/5 text-amber-300 hover:bg-amber-950/40'
            }`}
          >
            <Sparkles size={13} className="text-amber-400" />
            <span>{isAr ? 'شظايا الترقية' : 'Ascension Shards'}</span>
            <span className="text-[10px] px-1.5 rounded-full bg-amber-950/80 text-amber-200">
              {totalShardsCount}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('BATTLE')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'BATTLE'
                ? 'bg-cyan-400 text-slate-950 font-black shadow-sm'
                : 'bg-white/5 text-cyan-300 hover:bg-cyan-950/40'
            }`}
          >
            <Swords size={13} className="text-cyan-400" />
            <span>{isAr ? 'عناصر المعارك' : 'Battle Consumables'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('COMPANION')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'COMPANION'
                ? 'bg-rose-400 text-slate-950 font-black shadow-sm'
                : 'bg-white/5 text-rose-300 hover:bg-rose-950/40'
            }`}
          >
            <Heart size={13} className="text-rose-400" />
            <span>{isAr ? 'هدايا المحبة' : 'Companion Gifts'}</span>
          </button>
        </div>

        {/* Modal Main Body (2 Columns on large screens: Grid + Item Inspector) */}
        <div className="flex-1 overflow-y-auto studio-scrollbar p-4 sm:p-5 grid grid-cols-1 md:grid-cols-12 gap-5 min-h-[350px]">
          {/* Left Grid: Brawl Stars Item Displays */}
          <div className="md:col-span-7 lg:col-span-8 flex flex-wrap gap-4 items-start justify-center sm:justify-start content-start">
            {filteredList.map(({ item, count }) => (
              <div key={item.id} className="relative group">
                <BrawlStarsItemDisplay
                  item={item}
                  count={count}
                  size="standard"
                  isHoverable={true}
                  isAr={isAr}
                  onClick={() => setSelectedItem(item)}
                  className={`cursor-pointer ${
                    selectedItem?.id === item.id ? 'ring-4 ring-amber-400/80 scale-105' : ''
                  }`}
                />
              </div>
            ))}

            {filteredList.length === 0 && (
              <div className="w-full py-16 text-center text-stone-400 font-mono text-xs flex flex-col items-center justify-center space-y-3">
                <Backpack size={36} className="text-slate-500 opacity-60" />
                <h4 className="text-sm font-bold text-white">
                  {isAr ? 'لا توجد عناصر ممتلكة في هذه الفئة' : 'No Owned Items in This Category'}
                </h4>
                <p className="text-xs text-slate-400 max-w-xs">
                  {isAr
                    ? 'تعرض هذه الحقيبة فقط المواد والعناصر التي تمتلكها بالفعل (الكمية > 0).'
                    : 'This bag strictly displays items and shards currently in your possession (Count > 0).'}
                </p>
              </div>
            )}
          </div>

          {/* Right Column: Selected Item Detail & Upgrade Compatibility */}
          <div className="md:col-span-5 lg:col-span-4 bg-slate-950/80 rounded-2xl border border-white/10 p-4 flex flex-col justify-between space-y-4">
            {selectedItem ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <div>
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-300">
                      {selectedItem.category || 'UPGRADE_MATERIAL'}
                    </span>
                    <h3 className="font-display font-black text-base text-white">
                      {isAr ? (selectedItem.nameAr || selectedItem.name) : selectedItem.name}
                    </h3>
                  </div>
                  <span className="px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 font-mono font-black text-xs">
                    x{(inventoryMap && inventoryMap[selectedItem.id]?.count) || (Array.isArray(inventory) ? inventory.find(entry => entry.itemId === selectedItem.id)?.count : 0) || 0} {isAr ? 'مملوكة' : 'Owned'}
                  </span>
                </div>

                <p className="text-xs text-stone-300 leading-relaxed">
                  {isAr ? (selectedItem.descriptionAr || selectedItem.description) : selectedItem.description}
                </p>

                {/* Shard Ascension Target Cards */}
                {(selectedItem.category || 'UPGRADE_MATERIAL') === 'UPGRADE_MATERIAL' && (
                  <div className="space-y-2 pt-2 border-t border-white/10">
                    <span className="text-xs font-mono font-bold text-emerald-300 flex items-center gap-1.5">
                      <Sparkles size={13} />
                      <span>{isAr ? 'البطاقات المؤهلة للصعود بهذه الشظية' : 'Compatible Relics for Ascension'}</span>
                    </span>

                    {eligibleCards.length > 0 ? (
                      <div className="space-y-2 max-h-48 overflow-y-auto studio-scrollbar pr-1">
                        {eligibleCards.map(item => {
                          if (!item) return null;
                          const { card, currentRarity, nextRarity, requiredCount, successRate } = item;
                          return (
                            <div
                              key={card.id}
                              className="p-2.5 rounded-xl bg-black/60 border border-white/10 flex items-center justify-between gap-2 hover:border-amber-400/50 transition-all"
                            >
                              <div className="min-w-0">
                                <div className="text-xs font-bold text-white truncate">{card.name}</div>
                                <div className="text-[10.5px] font-mono text-stone-400 flex items-center gap-1">
                                  <span>{currentRarity}</span>
                                  <span>→</span>
                                  <span className="text-amber-300 font-bold">{nextRarity}</span>
                                  <span className="text-emerald-400 font-mono ms-1">({successRate}%)</span>
                                </div>
                              </div>

                              <div className="flex items-center gap-1.5 shrink-0">
                                {onSelectCardToUpgrade && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      onSelectCardToUpgrade(card.id);
                                      onClose();
                                    }}
                                    className="px-2.5 py-1 rounded-lg bg-amber-400 hover:bg-yellow-400 text-stone-950 font-mono font-black text-[10px] flex items-center gap-1 cursor-pointer transition-transform active:scale-95"
                                  >
                                    <span>Ascend</span>
                                    <ArrowUpRight size={12} />
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <p className="text-[11px] text-stone-400 italic">
                        {isAr 
                          ? 'لا توجد بطاقات في مجموعتك تحتاج هذه الشظية حالياً.' 
                          : 'No cards currently in your collection require this shard tier.'}
                      </p>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div className="py-12 text-center text-stone-400 space-y-2">
                <HelpCircle size={32} className="mx-auto text-stone-500 opacity-60" />
                <p className="text-xs font-mono">
                  {isAr ? 'اضغط على أي عنصر لعرض تفاصيله وقواعد ترقيته' : 'Select any item to inspect stats and upgrade paths.'}
                </p>
              </div>
            )}

            {/* Bottom Tip */}
            <div className="p-2.5 rounded-xl bg-teal-950/30 border border-teal-500/20 text-[10px] font-mono text-teal-300 flex items-center gap-2">
              <Sparkles size={14} className="shrink-0 text-amber-400" />
              <span>
                {isAr 
                  ? 'البطاقات المكررة تمنح شظايا ترقية فقط. استخدم الشظايا لترقية رتبة وقوة بطاقاتك.'
                  : 'Duplicate cards grant Upgrade Shards. Use shards to ascend card rarity & combat ratings.'}
              </span>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
