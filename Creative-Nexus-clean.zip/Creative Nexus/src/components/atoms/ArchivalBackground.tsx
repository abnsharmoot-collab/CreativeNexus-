import React from 'react';
import { useEasterEggs } from '../../context/EasterEggContext';
import { useMainMenuBackground } from '../../context/MainMenuBackgroundContext';
import { MESOPOTAMIAN_ASSETS } from '../../assets/mesopotamianAssets';

export const ArchivalBackground: React.FC = React.memo(() => {
  const { activeTheme } = useEasterEggs();
  const { getBackgroundForTheme } = useMainMenuBackground();
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  const kohanBgConfig = getBackgroundForTheme('kohan-iraqi');
  const bgImage = kohanBgConfig?.imageUrl || MESOPOTAMIAN_ASSETS.heroBg;
  const blur = typeof kohanBgConfig?.blur === 'number' ? kohanBgConfig.blur : 0;
  const opacity = typeof kohanBgConfig?.opacity === 'number' ? kohanBgConfig.opacity : 0.88;
  const dim = typeof kohanBgConfig?.dim === 'number' ? kohanBgConfig.dim : 0.28;

  return (
    <div 
      className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none"
      style={{ contain: 'strict', transform: 'translate3d(0, 0, 0)' }}
      aria-hidden="true"
    >
      {isMesopotamian ? (
        <div className="absolute inset-0">
          {/* Rebuilt Legendary Ancient Iraqi Civilization Background */}
          <img
            src={bgImage}
            alt="Legendary Ancient Iraqi Civilization"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center pointer-events-none transition-all duration-500"
            style={{
              filter: blur > 0 ? `blur(${blur}px)` : 'none',
              opacity: opacity,
              transform: blur > 0 ? 'scale(1.08)' : 'none'
            }}
          />

          {/* Clean dark tint for reading clarity without bright orange wash */}
          <div 
            className="absolute inset-0 bg-[#060403] pointer-events-none transition-opacity duration-300" 
            style={{ opacity: dim }}
          />

          {/* Seamless low-opacity worn papyrus parchment & ancient clay tablet texture */}
          <div 
            className="absolute inset-0 pointer-events-none opacity-[0.14] mix-blend-overlay"
            style={{
              backgroundImage: `url(${MESOPOTAMIAN_ASSETS.papyrusClayTexture})`,
              backgroundRepeat: 'repeat',
              backgroundSize: '360px 360px'
            }}
          />

          <div className="absolute inset-0 shadow-[inset_0_0_140px_rgba(4,3,2,0.95)] pointer-events-none" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#060403]/90 via-transparent to-[#060403]/75 pointer-events-none" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#060403]/80 via-transparent to-[#060403]/90 pointer-events-none" />
        </div>
      ) : (
        <>
          {/* Creative Nexus Deep Dark Navy/Teal Base */}
          <div className="absolute inset-0 bg-[#031211]" />

          {/* Cinematic Radial Gradients */}
          <div 
            className="absolute inset-0 pointer-events-none opacity-90"
            style={{
              backgroundImage: `
                radial-gradient(60% 50% at 85% 8%, rgba(45,212,191,0.22), transparent 70%),
                radial-gradient(50% 45% at 8% 55%, rgba(20,110,150,0.28), transparent 70%),
                radial-gradient(45% 40% at 60% 100%, rgba(124,140,255,0.15), transparent 70%)
              `
            }}
          />

          {/* Drifting subtle nebulae */}
          <div className="absolute -top-[10vh] -start-[8vw] w-[46vw] min-w-[320px] h-[46vw] min-h-[320px] rounded-full bg-[#0e7c86]/25 blur-[120px]" />
          <div className="absolute top-[45vh] -end-[6vw] w-[38vw] min-w-[280px] h-[38vw] min-h-[280px] rounded-full bg-[#4b58d6]/16 blur-[130px]" />
          <div className="absolute bottom-[-10vh] start-[20vw] w-[35vw] min-w-[250px] h-[35vw] min-h-[250px] rounded-full bg-[#14b8a6]/15 blur-[110px]" />

          {/* Subtle noise/grid texture */}
          <div 
            className="absolute inset-0 opacity-[0.035] pointer-events-none" 
            style={{
              backgroundImage: `radial-gradient(rgba(255,255,255,0.8) 1px, transparent 1px)`,
              backgroundSize: '36px 36px'
            }}
          />
        </>
      )}
    </div>
  );
});

ArchivalBackground.displayName = 'ArchivalBackground';
