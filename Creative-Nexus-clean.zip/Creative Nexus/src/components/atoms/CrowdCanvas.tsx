import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

export interface CrowdCanvasProps {
  src?: string;
  rows?: number;
  cols?: number;
  memberCount?: number;
  minCharacters?: number;
  maxCharacters?: number;
  isMesopotamian?: boolean;
  className?: string;
  bottomOffset?: number;
}

import crowdPeepsSprite from '../../assets/images/crowd_peeps.png';

const LOCAL_SPRITE_SRC = crowdPeepsSprite;
const REMOTE_SPRITE_SRC =
  'https://cdn.21st.dev/assets/localized/abdb8990a7bef8c2f5af3e45f0a3c969c4b0603fba8be92e81347de4ea4e1ed7.png';

interface Peep {
  id: number;
  image: HTMLImageElement;
  rect: number[];
  width: number;
  height: number;
  x: number;
  y: number;
  anchorY: number;
  scaleX: number;
  walk: gsap.core.Timeline | null;
  drawWidth: number;
  drawHeight: number;
  setRect: (rect: number[]) => void;
  render: (ctx: CanvasRenderingContext2D) => void;
}

/**
 * Calculates how many active crowd members should be visible
 * in a dense, bustling walking line across mobile and computer screens.
 */
function calculateCrowdSize(
  memberCount: number | undefined,
  screenWidth: number,
  customMin?: number,
  customMax?: number
): number {
  const isMobile = screenWidth < 640;
  const isTablet = screenWidth >= 640 && screenWidth < 1024;

  // Rich, crowded walking procession across both mobile & computer viewports
  const min = customMin ?? (isMobile ? 12 : isTablet ? 20 : 28);
  const max = customMax ?? (isMobile ? 18 : isTablet ? 30 : 42);

  const realCount = typeof memberCount === 'number' && memberCount > 0 ? memberCount : 580;

  // Normalized scaling across standard Discord community sizes (50 to 1200+ members)
  const normalized = Math.min(1, Math.max(0, (realCount - 50) / 1150));
  const count = Math.round(min + normalized * (max - min));

  return Math.min(Math.max(count, min), max);
}

export const CrowdCanvas: React.FC<CrowdCanvasProps> = ({
  src,
  rows = 15,
  cols = 7,
  memberCount,
  minCharacters,
  maxCharacters,
  isMesopotamian = false,
  className = '',
  bottomOffset,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Keep latest member count & target count in refs to update dynamically without resetting animations
  const memberCountRef = useRef(memberCount);
  const targetCrowdSizeRef = useRef<number>(20);
  const isMountedRef = useRef<boolean>(true);

  useEffect(() => {
    memberCountRef.current = memberCount;
  }, [memberCount]);

  useEffect(() => {
    isMountedRef.current = true;
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Check reduced motion preference
    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // RANDOM UTILITIES
    const randomRange = (min: number, max: number) => min + Math.random() * (max - min);
    const randomIndex = (array: any[]) => (randomRange(0, array.length) | 0);
    const removeFromArray = (array: any[], i: number) => array.splice(i, 1)[0];
    const removeItemFromArray = (array: any[], item: any) =>
      removeFromArray(array, array.indexOf(item));
    const removeRandomFromArray = (array: any[]) => removeFromArray(array, randomIndex(array));
    const getRandomFromArray = (array: any[]) => array[randomIndex(array) | 0];

    const stage = {
      width: container.clientWidth || 800,
      height: container.clientHeight || 500,
      scaleFactor: 0.52,
      dpr: 1,
    };

    let peepIdCounter = 0;
    const allPeepBlueprints: { rect: number[]; width: number; height: number }[] = [];
    const availablePeeps: Peep[] = [];
    const crowd: Peep[] = [];
    let isInitialized = false;

    // Dynamic scale factor - significantly bigger so upper bodies fill the panel from the bottom
    const updateScaleFactor = () => {
      const isMobile = stage.width < 640;
      const isTablet = stage.width >= 640 && stage.width < 1024;
      // Prominent large scale for crowd filling the bottom of the panel
      const baseHeight = isMobile ? 220 : isTablet ? 270 : 310;
      // Original frame height is ~324px; scale up so crowd fills the bottom
      stage.scaleFactor = Math.min(1.05, Math.max(0.65, baseHeight / 324));
    };

    updateScaleFactor();
    targetCrowdSizeRef.current = calculateCrowdSize(
      memberCountRef.current,
      stage.width,
      minCharacters,
      maxCharacters
    );

    // TWEEN FACTORIES: ALL CITIZENS GATHERED AT BOTTOM WITH LOWER CUT FULLY SUBMERGED
    const resetPeep = (peep: Peep) => {
      const direction = Math.random() > 0.5 ? 1 : -1;
      
      const drawH = peep.height * stage.scaleFactor;
      const drawW = peep.width * stage.scaleFactor;
      peep.drawWidth = drawW;
      peep.drawHeight = drawH;

      // Submerge bottom ~35% of their body below the container floor so the design cut is never visible.
      // Their upper bodies fill the panel naturally from the bottom.
      const isMobile = stage.width < 640;
      const visiblePortion = isMobile ? 0.62 : 0.66;
      const directionOffset = direction === 1 ? 4 : -4;
      const microDepth = ((peep.id % 9) - 4) * 1.5;

      const startY = stage.height - (drawH * visiblePortion) + directionOffset + microDepth;

      let startX: number;
      let endX: number;

      if (direction === 1) {
        // Walking from left to right
        startX = -drawW - randomRange(10, 60);
        endX = stage.width + randomRange(10, 60);
        peep.scaleX = 1;
      } else {
        // Walking from right to left
        startX = stage.width + drawW + randomRange(10, 60);
        endX = -randomRange(10, 60);
        peep.scaleX = -1;
      }

      peep.x = startX;
      peep.y = startY;
      peep.anchorY = startY + drawH;

      return {
        startX,
        startY,
        endX,
      };
    };

    const normalWalk = (peep: Peep, props: { startX: number; startY: number; endX: number }) => {
      const { startX, startY, endX } = props;
      // Natural walking duration across the container width
      const distance = Math.abs(endX - startX);
      const baseSpeed = distance / 95; // ~10-18 seconds walk
      const xDuration = Math.max(8, baseSpeed * randomRange(0.85, 1.25));
      const yDuration = prefersReducedMotion ? 0.6 : randomRange(0.22, 0.3);

      const tl = gsap.timeline();
      tl.timeScale(prefersReducedMotion ? 0.3 : randomRange(0.7, 1.15));

      // Horizontal linear traversal along the walking line
      tl.to(
        peep,
        {
          duration: xDuration,
          x: endX,
          ease: 'none',
        },
        0
      );

      // Subtle vertical bounce bobbing (natural walking stride, bottom cut stays safely submerged)
      if (!prefersReducedMotion) {
        const bounceCount = Math.floor(xDuration / yDuration);
        tl.to(
          peep,
          {
            duration: yDuration,
            repeat: bounceCount,
            yoyo: true,
            y: startY - Math.min(peep.drawHeight * 0.02, 5),
            ease: 'sine.inOut',
          },
          0
        );
      }

      return tl;
    };

    // PEEP FACTORY
    const createPeepInstance = (blueprint: { rect: number[]; width: number; height: number }): Peep => {
      peepIdCounter++;
      const peep: Peep = {
        id: peepIdCounter,
        image: img,
        rect: blueprint.rect,
        width: blueprint.width,
        height: blueprint.height,
        drawWidth: blueprint.width * stage.scaleFactor,
        drawHeight: blueprint.height * stage.scaleFactor,
        x: 0,
        y: 0,
        anchorY: 0,
        scaleX: 1,
        walk: null,
        setRect: (rect: number[]) => {
          peep.rect = rect;
          peep.width = rect[2];
          peep.height = rect[3];
          peep.drawWidth = peep.width * stage.scaleFactor;
          peep.drawHeight = peep.height * stage.scaleFactor;
        },
        render: (renderCtx: CanvasRenderingContext2D) => {
          renderCtx.save();
          renderCtx.translate(peep.x, peep.y);
          renderCtx.scale(peep.scaleX, 1);
          renderCtx.drawImage(
            peep.image,
            peep.rect[0],
            peep.rect[1],
            peep.rect[2],
            peep.rect[3],
            0,
            0,
            peep.drawWidth,
            peep.drawHeight
          );
          renderCtx.restore();
        },
      };

      return peep;
    };

    const img = new Image();

    // Dissect sprite sheet into individual frames
    const createPeepBlueprints = () => {
      const { naturalWidth: width, naturalHeight: height } = img;
      if (!width || !height) return;

      allPeepBlueprints.length = 0;
      availablePeeps.length = 0;

      const total = rows * cols;
      const rectWidth = width / rows;
      const rectHeight = height / cols;

      for (let i = 0; i < total; i++) {
        const blueprint = {
          rect: [
            (i % rows) * rectWidth,
            ((i / rows) | 0) * rectHeight,
            rectWidth,
            rectHeight,
          ],
          width: rectWidth,
          height: rectHeight,
        };
        allPeepBlueprints.push(blueprint);
        availablePeeps.push(createPeepInstance(blueprint));
      }
    };

    const addPeepToCrowd = (randomInitialProgress: boolean = false): Peep | null => {
      if (!isMountedRef.current) return null;

      // If available pool is exhausted, replenish by cloning from blueprints
      if (!availablePeeps.length && allPeepBlueprints.length > 0) {
        const randomBlueprint = getRandomFromArray(allPeepBlueprints);
        availablePeeps.push(createPeepInstance(randomBlueprint));
      }

      if (!availablePeeps.length) return null;

      const peep = removeRandomFromArray(availablePeeps);
      const props = resetPeep(peep);

      const walk = normalWalk(peep, props).eventCallback('onComplete', () => {
        if (!isMountedRef.current) return;

        removePeepFromCrowd(peep);

        // Keep crowd population matching the real Discord member count dynamically
        const currentTarget = targetCrowdSizeRef.current;
        if (crowd.length < currentTarget) {
          addPeepToCrowd(false);
        }
      });

      peep.walk = walk;

      if (randomInitialProgress) {
        // Distribute peeps at random points in their stride across the canvas
        walk.progress(Math.random());
      }

      crowd.push(peep);
      // Sort by depth (anchorY) so foreground peeps render over background peeps
      crowd.sort((a, b) => a.anchorY - b.anchorY);

      return peep;
    };

    const removePeepFromCrowd = (peep: Peep) => {
      peep.walk?.kill();
      peep.walk = null;
      removeItemFromArray(crowd, peep);
      availablePeeps.push(peep);
    };

    const syncCrowdPopulation = () => {
      const targetSize = targetCrowdSizeRef.current;

      // If we need more peeps, spawn them
      while (crowd.length < targetSize) {
        const added = addPeepToCrowd(true);
        if (!added) break;
      }

      // If we need fewer peeps, gracefully let excess ones finish naturally
      if (crowd.length > targetSize + 6) {
        const excess = crowd.splice(targetSize);
        excess.forEach((p) => {
          p.walk?.kill();
          p.walk = null;
          availablePeeps.push(p);
        });
      }
    };

    const render = () => {
      if (!ctx || !canvas) return;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      ctx.save();
      // Scale according to device pixel ratio for crystal clear rendering
      ctx.scale(stage.dpr, stage.dpr);

      // Render each walking citizen
      for (let i = 0; i < crowd.length; i++) {
        crowd[i].render(ctx);
      }

      ctx.restore();
    };

    const resize = () => {
      if (!container || !canvas) return;

      const width = container.clientWidth || container.parentElement?.clientWidth || window.innerWidth;
      const height = container.clientHeight || 500;

      if (width <= 0 || height <= 0) return;

      stage.width = width;
      stage.height = height;
      updateScaleFactor();

      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      stage.dpr = dpr;
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);

      // Update target crowd size based on container width & server member count
      targetCrowdSizeRef.current = calculateCrowdSize(
        memberCountRef.current,
        stage.width,
        minCharacters,
        maxCharacters
      );

      // If initializing or dimensions changed significantly, re-seed positions smoothly
      if (!isInitialized) {
        crowd.forEach((peep) => peep.walk?.kill());
        crowd.length = 0;
        availablePeeps.length = 0;
        allPeepBlueprints.forEach((b) => availablePeeps.push(createPeepInstance(b)));

        const target = targetCrowdSizeRef.current;
        for (let i = 0; i < target; i++) {
          addPeepToCrowd(true);
        }
        isInitialized = true;
      } else {
        syncCrowdPopulation();
      }
    };

    const handleImageLoaded = () => {
      if (!img.naturalWidth || !img.naturalHeight) return;
      createPeepBlueprints();
      resize();
      gsap.ticker.add(render);
    };

    img.onload = handleImageLoaded;
    img.onerror = () => {
      // If local failed or remote failed, fallback to alternate URL
      if (img.src.includes('crowd_peeps.png')) {
        img.src = REMOTE_SPRITE_SRC;
      } else {
        console.warn('CrowdCanvas: Sprite image failed to load, falling back gracefully.');
      }
    };

    img.src = src || LOCAL_SPRITE_SRC;

    if (img.complete && img.naturalWidth > 0) {
      handleImageLoaded();
    }

    // Responsive container resize observer
    const resizeObserver = new ResizeObserver(() => {
      resize();
    });
    resizeObserver.observe(container);

    // Dynamic member count watch interval to gently sync population
    const syncInterval = setInterval(() => {
      if (!isMountedRef.current) return;
      targetCrowdSizeRef.current = calculateCrowdSize(
        memberCountRef.current,
        stage.width,
        minCharacters,
        maxCharacters
      );
      syncCrowdPopulation();
    }, 4000);

    return () => {
      isMountedRef.current = false;
      clearInterval(syncInterval);
      resizeObserver.disconnect();
      gsap.ticker.remove(render);

      crowd.forEach((peep) => peep.walk?.kill());
      crowd.length = 0;
      availablePeeps.length = 0;
      allPeepBlueprints.length = 0;
    };
  }, [src, rows, cols, minCharacters, maxCharacters, bottomOffset]);

  return (
    <div
      ref={containerRef}
      aria-hidden="true"
      className={`pointer-events-none absolute inset-0 h-full w-full select-none overflow-hidden ${className}`}
      style={{
        maskImage:
          'linear-gradient(to right, transparent 0%, rgba(0,0,0,1) 2.5%, rgba(0,0,0,1) 97.5%, transparent 100%)',
        WebkitMaskImage:
          'linear-gradient(to right, transparent 0%, rgba(0,0,0,1) 2.5%, rgba(0,0,0,1) 97.5%, transparent 100%)',
      }}
    >
      <canvas
        ref={canvasRef}
        aria-hidden="true"
        className={`pointer-events-none absolute inset-0 h-full w-full transition-all duration-700 ${
          isMesopotamian
            ? 'crowd-canvas-meso-theme opacity-90'
            : 'crowd-canvas-website-theme opacity-90'
        }`}
      />
    </div>
  );
};

export default CrowdCanvas;
