import React from 'react';
import { motion } from 'motion/react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'destructive';
  className?: string;
  children: React.ReactNode;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  type?: 'button' | 'submit' | 'reset';
  form?: string;
  disabled?: boolean;
}

export function Button({ variant = 'primary', children, className = '', disabled, ...props }: ButtonProps) {
  const baseStyles = "relative inline-flex items-center justify-center px-5 py-2.5 text-sm font-semibold tracking-normal transition-all duration-150 rounded-xl disabled:opacity-50 disabled:pointer-events-none cursor-pointer select-none active:translate-y-0.5";
  
  const variants = {
    primary: "bg-[#14b8a6] hover:bg-[#2dd4bf] text-[#022421] border border-[#2dd4bf] shadow-sm",
    secondary: "bg-[#0d2825] hover:bg-[#133a36] text-[#f0fdfa] border border-[rgba(45,212,191,0.2)]",
    outline: "bg-transparent text-[#2dd4bf] border border-[rgba(45,212,191,0.3)] hover:bg-[#14b8a6]/10 hover:border-[#2dd4bf]",
    ghost: "bg-transparent text-[#99b8b2] hover:text-[#f0fdfa] hover:bg-white/[0.04]",
    destructive: "bg-rose-500/15 text-rose-300 border border-rose-500/30 hover:bg-rose-500/25"
  };

  return (
    <button
      className={`${baseStyles} ${variants[variant]} ${className}`}
      disabled={disabled}
      {...props}
    >
      <span className="relative z-10 flex items-center justify-center gap-2">{children}</span>
    </button>
  );
}
