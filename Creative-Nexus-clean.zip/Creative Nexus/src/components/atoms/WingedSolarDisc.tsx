import React from 'react';

interface WingedSolarDiscProps {
  className?: string;
}

export function WingedSolarDisc({ className = '' }: WingedSolarDiscProps) {
  return (
    <div className={`flex items-center justify-center gap-3 sm:gap-4 select-none ${className}`}>
      {/* Left Tapered Gold Relief Rule */}
      <div className="h-[2px] w-12 sm:w-24 md:w-32 bg-gradient-to-r from-transparent via-amber-500/80 to-amber-400 shadow-[0_0_8px_rgba(245,158,11,0.5)]" />

      {/* Ancient Mesopotamian Winged Sun Disc Relief */}
      <svg
        viewBox="0 0 160 36"
        className="w-24 sm:w-32 md:w-40 h-auto filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)] drop-shadow-[0_0_10px_rgba(245,158,11,0.4)]"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="mesoGoldGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#fef3c7" />
            <stop offset="35%" stopColor="#f59e0b" />
            <stop offset="70%" stopColor="#d97706" />
            <stop offset="100%" stopColor="#78350f" />
          </linearGradient>
          <linearGradient id="discGlow" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#fffbeb" />
            <stop offset="50%" stopColor="#fbbf24" />
            <stop offset="100%" stopColor="#b45309" />
          </linearGradient>
        </defs>

        {/* Left Wing Primary Feather Rays */}
        <path
          d="M72 18 C58 13 36 10 6 12 C24 16 48 19 70 21 Z"
          fill="url(#mesoGoldGrad)"
          stroke="#78350f"
          strokeWidth="0.5"
        />
        <path
          d="M72 18 C56 16 32 15 12 18 C28 21 52 23 70 24 Z"
          fill="url(#mesoGoldGrad)"
          opacity="0.9"
        />
        <path
          d="M70 21 C54 21 34 22 20 25 C36 26 56 26 68 25 Z"
          fill="url(#mesoGoldGrad)"
          opacity="0.8"
        />

        {/* Right Wing Primary Feather Rays */}
        <path
          d="M88 18 C102 13 124 10 154 12 C136 16 112 19 90 21 Z"
          fill="url(#mesoGoldGrad)"
          stroke="#78350f"
          strokeWidth="0.5"
        />
        <path
          d="M88 18 C104 16 128 15 148 18 C132 21 108 23 90 24 Z"
          fill="url(#mesoGoldGrad)"
          opacity="0.9"
        />
        <path
          d="M90 21 C106 21 126 22 140 25 C124 26 104 26 92 25 Z"
          fill="url(#mesoGoldGrad)"
          opacity="0.8"
        />

        {/* Central Solar Disc */}
        <circle cx="80" cy="18" r="9" fill="url(#discGlow)" stroke="#78350f" strokeWidth="1" />
        <circle cx="80" cy="18" r="6" fill="#1a110a" stroke="#d97706" strokeWidth="0.8" />
        <circle cx="80" cy="18" r="3" fill="url(#discGlow)" />

        {/* Uraeus / Royal Flanks */}
        <path
          d="M76 27 C78 32 82 32 84 27 Z"
          fill="url(#mesoGoldGrad)"
        />
      </svg>

      {/* Right Tapered Gold Relief Rule */}
      <div className="h-[2px] w-12 sm:w-24 md:w-32 bg-gradient-to-l from-transparent via-amber-500/80 to-amber-400 shadow-[0_0_8px_rgba(245,158,11,0.5)]" />
    </div>
  );
}
