import React from 'react';

interface MesopotamianCornerBracketsProps {
  className?: string;
}

export function MesopotamianCornerBrackets({ className = '' }: MesopotamianCornerBracketsProps) {
  return (
    <div className={`absolute inset-0 pointer-events-none select-none z-10 ${className}`}>
      {/* Top Left Stepped Bracket */}
      <svg className="absolute top-1.5 start-1.5 w-4 h-4 text-amber-500/70" viewBox="0 0 16 16" fill="currentColor">
        <path d="M0 0 H16 V3 H3 V16 H0 Z" />
      </svg>

      {/* Top Right Stepped Bracket */}
      <svg className="absolute top-1.5 end-1.5 w-4 h-4 text-amber-500/70" viewBox="0 0 16 16" fill="currentColor">
        <path d="M0 0 H16 V16 H13 V3 H0 Z" />
      </svg>

      {/* Bottom Left Stepped Bracket */}
      <svg className="absolute bottom-1.5 start-1.5 w-4 h-4 text-amber-500/70" viewBox="0 0 16 16" fill="currentColor">
        <path d="M0 0 H3 V13 H16 V16 H0 Z" />
      </svg>

      {/* Bottom Right Stepped Bracket */}
      <svg className="absolute bottom-1.5 end-1.5 w-4 h-4 text-amber-500/70" viewBox="0 0 16 16" fill="currentColor">
        <path d="M13 0 H16 V16 H0 V13 H13 Z" />
      </svg>
    </div>
  );
}
