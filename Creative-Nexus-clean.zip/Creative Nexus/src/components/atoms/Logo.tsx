import React from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { useSiteLogo } from '../../context/SiteLogoContext';
import { Sparkles, Crown, Flame, Shield } from 'lucide-react';

export function Logo({ className = '', showSubtitle = true }: { className?: string; showSubtitle?: boolean }) {
  const { language } = useLanguage();
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';
  const { logoSettings } = useSiteLogo();

  const isImageMode = logoSettings.mode === 'image' && Boolean(logoSettings.imageUrl);
  const titleText = language === 'ar' 
    ? (logoSettings.titleAr || 'مركز الإبداع') 
    : (logoSettings.titleEn || 'Creative Nexus');
  const subtitleText = language === 'ar' 
    ? (logoSettings.subtitleAr || 'CREATIVE NEXUS // شبكة الإبداع') 
    : (logoSettings.subtitleEn || 'COMMUNITY PORTAL // NEXUS');
  const shouldDisplaySubtitle = showSubtitle && logoSettings.showSubtitle !== false;

  const accentColor = logoSettings.accentColor || '#5eead4';
  const gradFrom = logoSettings.gradientFrom || '#ffffff';
  const gradTo = logoSettings.gradientTo || '#2dd4bf';

  return (
    <div className={`inline-flex items-center gap-2 sm:gap-2.5 group select-none min-w-0 max-w-full ${className}`}>
      {/* Emblem Section - No circular or container box borders; boundaries come strictly from the logo image itself */}
      {isImageMode ? (
        <div className="relative shrink-0 flex items-center justify-center group-hover:scale-105 transition-transform duration-300 border-0 bg-transparent p-0 m-0 shadow-none">
          <img 
            src={logoSettings.imageUrl} 
            alt={titleText} 
            className="h-7.5 sm:h-8.5 md:h-9 w-auto max-w-[80px] sm:max-w-[110px] object-contain select-none drop-shadow-sm border-0 rounded-none" 
          />
        </div>
      ) : (
        <div className="relative w-7 h-7 sm:w-8 sm:h-8 shrink-0 transition-transform duration-300 group-hover:scale-105 flex items-center justify-center">
          {logoSettings.iconType === 'nexus_core' ? (
            <div className="relative z-10 w-full h-full flex items-center justify-center">
              <Sparkles size={20} style={{ color: accentColor }} className="drop-shadow-[0_0_8px_currentColor]" />
            </div>
          ) : logoSettings.iconType === 'crown' ? (
            <div className="relative z-10 w-full h-full flex items-center justify-center">
              <Crown size={20} style={{ color: accentColor }} className="drop-shadow-[0_0_8px_currentColor]" />
            </div>
          ) : logoSettings.iconType === 'dragon' ? (
            <div className="relative z-10 w-full h-full flex items-center justify-center">
              <Flame size={20} style={{ color: accentColor }} className="drop-shadow-[0_0_8px_currentColor]" />
            </div>
          ) : logoSettings.iconType === 'shield' ? (
            <div className="relative z-10 w-full h-full flex items-center justify-center">
              <Shield size={20} style={{ color: accentColor }} className="drop-shadow-[0_0_8px_currentColor]" />
            </div>
          ) : (
            <svg viewBox="0 0 200 200" className={`relative z-10 w-full h-full filter ${
              isMesopotamian ? 'drop-shadow-[0_0_10px_rgba(245,158,11,0.7)]' : 'drop-shadow-[0_0_10px_rgba(45,212,191,0.7)]'
            }`}>
              <defs>
                <linearGradient id="gf-logo-symbol" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#ffffff" />
                  <stop offset="25%" stopColor="#e0fdf4" />
                  <stop offset="55%" stopColor={accentColor} />
                  <stop offset="80%" stopColor="#14b8a6" />
                  <stop offset="100%" stopColor="#0f766e" />
                </linearGradient>
                <linearGradient id="gf-meso-symbol" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#fffbeb" />
                  <stop offset="45%" stopColor="#f59e0b" />
                  <stop offset="75%" stopColor="#b45309" />
                  <stop offset="100%" stopColor="#78350f" />
                </linearGradient>
              </defs>
              <g fill={isMesopotamian ? 'url(#gf-meso-symbol)' : 'url(#gf-logo-symbol)'}>
                <path transform="translate(58 6) scale(1.24)" d="M50 0C53 31 69 47 100 50C69 53 53 69 50 100C47 69 31 53 0 50C31 47 47 31 50 0Z" />
                <path transform="translate(8 96) scale(.9)" d="M50 0C53 31 69 47 100 50C69 53 53 69 50 100C47 69 31 53 0 50C31 47 47 31 50 0Z" />
              </g>
            </svg>
          )}
        </div>
      )}

      <div className="flex flex-col leading-tight min-w-0 justify-center">
        {/* Wordmark / Server Name */}
        <div className="flex items-center min-w-0">
          <span 
            className={`text-sm xs:text-base sm:text-lg md:text-xl font-black tracking-tight truncate ${
              isMesopotamian
                ? 'font-meso-serif mesopotamian-chiseled-title text-amber-200'
                : 'font-display'
            }`}
          >
            {isMesopotamian ? (
              <span className="text-amber-200 select-none">
                {titleText}
              </span>
            ) : (
              <span 
                className="inline-block transition-all duration-300 group-hover:brightness-110 select-none text-[#5eead4]"
                style={{
                  color: accentColor,
                  backgroundImage: `linear-gradient(135deg, ${gradFrom}, ${accentColor}, ${gradTo})`,
                  WebkitBackgroundClip: 'text',
                  backgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                {titleText}
              </span>
            )}
          </span>
        </div>

        {shouldDisplaySubtitle && (
          <div className="flex items-center">
            <span 
              className={`hidden xs:inline-block text-[0.58rem] sm:text-[0.66rem] tracking-[0.18em] sm:tracking-[0.22em] uppercase font-mono font-bold truncate ${
                isMesopotamian
                  ? 'text-amber-400/90'
                  : 'text-teal-300/80 group-hover:text-white transition-colors'
              }`}
            >
              {subtitleText}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
