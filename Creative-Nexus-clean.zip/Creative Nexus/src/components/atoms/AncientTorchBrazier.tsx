import React from 'react';

interface AncientTorchBrazierProps {
  className?: string;
  side?: 'left' | 'right';
}

export function AncientTorchBrazier({ className = '', side = 'left' }: AncientTorchBrazierProps) {
  return (
    <div className={`relative flex flex-col items-center pointer-events-none select-none ${className}`}>
      {/* Warm Fire Glow Halo */}
      <div className="absolute -top-16 start-1/2 -translate-x-1/2 w-48 h-48 bg-amber-500/25 rounded-full blur-[60px]" />
      <div className="absolute -top-8 start-1/2 -translate-x-1/2 w-28 h-28 bg-orange-500/35 rounded-full blur-[35px]" />

      {/* Animated Flickering Flame */}
      <div className="relative w-14 h-24 mb-1 flex items-end justify-center">
        {/* Core Outer Flame */}
        <div className="animate-torch-flame w-9 h-20 rounded-full bg-gradient-to-t from-red-600 via-amber-500 to-yellow-200 filter blur-[1px] opacity-90 shadow-[0_0_25px_rgba(245,158,11,0.8)]" />
        
        {/* Inner Hot White/Yellow Flame */}
        <div className="absolute bottom-1 w-4 h-12 rounded-full bg-gradient-to-t from-orange-400 via-yellow-200 to-white filter blur-[0.5px] opacity-95" />

        {/* Small floating spark/ember particles */}
        <div className="absolute -top-3 start-3 w-1.5 h-1.5 rounded-full bg-amber-300 animate-ping opacity-75" />
      </div>

      {/* Ancient Bronze/Stone Brazier Bowl */}
      <svg
        viewBox="0 0 70 50"
        className="w-16 h-12 filter drop-shadow-[0_8px_12px_rgba(0,0,0,0.9)]"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="bronzeBrazier" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#d97706" />
            <stop offset="40%" stopColor="#78350f" />
            <stop offset="100%" stopColor="#291809" />
          </linearGradient>
        </defs>

        {/* Bowl Rim */}
        <ellipse cx="35" cy="8" rx="28" ry="6" fill="#451a03" stroke="#f59e0b" strokeWidth="1" />
        <ellipse cx="35" cy="8" rx="24" ry="4" fill="#b45309" opacity="0.8" />

        {/* Bowl Basin */}
        <path
          d="M7 8 C10 24 22 32 35 32 C48 32 60 24 63 8 Z"
          fill="url(#bronzeBrazier)"
          stroke="#92400e"
          strokeWidth="1"
        />

        {/* Base Pedestal Column */}
        <path d="M28 32 L26 44 L44 44 L42 32 Z" fill="#291809" stroke="#78350f" strokeWidth="0.8" />
        {/* Base Plinth */}
        <path d="M20 44 L50 44 L54 50 L16 50 Z" fill="#180f08" stroke="#92400e" strokeWidth="1" />
      </svg>
    </div>
  );
}
