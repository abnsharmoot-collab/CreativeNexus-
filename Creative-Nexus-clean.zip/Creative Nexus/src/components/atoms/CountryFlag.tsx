import React from 'react';

interface CountryFlagProps {
  country: 'iraq' | 'uae' | 'egypt';
  className?: string;
  showName?: boolean;
  name?: string;
  onClick?: (e: React.MouseEvent) => void;
  isDesignated?: boolean;
}

export const CountryFlag: React.FC<CountryFlagProps> = ({
  country,
  className = '',
  showName = true,
  name,
  onClick,
}) => {
  const handleFlagClick = (e: React.MouseEvent) => {
    if (onClick) {
      e.stopPropagation();
      e.preventDefault();
      onClick(e);
    }
  };

  const isClickable = Boolean(onClick);

  if (country === 'egypt') {
    return (
      <div 
        role={isClickable ? 'button' : undefined}
        tabIndex={isClickable ? 0 : undefined}
        onClick={isClickable ? handleFlagClick : undefined}
        onKeyDown={isClickable ? (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleFlagClick(e as unknown as React.MouseEvent);
          }
        } : undefined}
        title={name || 'Egypt'}
        className={`inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-archive-dark/80 border border-amber-500/30 shadow-[0_0_12px_rgba(245,158,11,0.15)] select-none ${
          isClickable ? 'cursor-pointer active:scale-95 hover:scale-105 hover:border-amber-400/50' : 'cursor-default'
        } transition-all ${className}`}
      >
        <svg
          className="w-4 h-3 rounded-xs overflow-hidden shadow-xs shrink-0 pointer-events-none"
          viewBox="0 0 900 600"
          aria-label="Flag of Egypt"
        >
          {/* Top red stripe */}
          <rect width="900" height="200" fill="#c8102e" />
          {/* Middle white stripe */}
          <rect y="200" width="900" height="200" fill="#ffffff" />
          {/* Bottom black stripe */}
          <rect y="400" width="900" height="200" fill="#000000" />
          {/* Eagle of Saladin in gold/bronze */}
          <g transform="translate(450, 300) scale(0.95)">
            {/* Eagle silhouette */}
            <path
              d="M-22,-45 C-18,-60 18,-60 22,-45 C28,-25 35,-10 40,15 C35,28 20,40 18,50 L-18,50 C-20,40 -35,28 -40,15 C-35,-10 -28,-25 -22,-45 Z"
              fill="#c69214"
            />
            {/* Shield on chest */}
            <path
              d="M-12,-10 L12,-10 L12,18 C12,28 0,36 0,36 C0,36 -12,28 -12,18 Z"
              fill="#ffffff"
              stroke="#8a6405"
              strokeWidth="2"
            />
            {/* Head and beak */}
            <circle cx="0" cy="-48" r="10" fill="#c69214" />
            <path d="M4,-48 L16,-46 L6,-42 Z" fill="#8a6405" />
            {/* Base scroll */}
            <rect x="-24" y="48" width="48" height="8" rx="2" fill="#8a6405" />
          </g>
        </svg>
        {showName && (
          <span className="text-[11px] font-semibold tracking-wide text-amber-200">
            {name || 'Egypt'}
          </span>
        )}
      </div>
    );
  }
  if (country === 'iraq') {
    return (
      <div 
        role={isClickable ? 'button' : undefined}
        tabIndex={isClickable ? 0 : undefined}
        onClick={isClickable ? handleFlagClick : undefined}
        onKeyDown={isClickable ? (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleFlagClick(e as unknown as React.MouseEvent);
          }
        } : undefined}
        title={name || 'Iraq'}
        className={`inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-archive-dark/70 border border-amber-500/20 shadow-sm select-none ${
          isClickable ? 'cursor-pointer active:scale-95 hover:scale-105 hover:border-amber-400/50' : 'cursor-default'
        } transition-all ${className}`}
      >
        <svg
          className="w-4 h-3 rounded-xs overflow-hidden shadow-xs shrink-0 pointer-events-none"
          viewBox="0 0 900 600"
          aria-label="Flag of Iraq"
        >
          {/* Top red stripe */}
          <rect width="900" height="200" fill="#ce1126" />
          {/* Middle white stripe */}
          <rect y="200" width="900" height="200" fill="#ffffff" />
          {/* Bottom black stripe */}
          <rect y="400" width="900" height="200" fill="#000000" />
          {/* Kufic Takbir in green */}
          <g fill="#007a3d" transform="translate(450, 300) scale(0.65)">
            <text
              textAnchor="middle"
              dominantBaseline="central"
              fontSize="120"
              fontWeight="900"
              fontFamily="Cairo, sans-serif"
              letterSpacing="6"
            >
              الله أكبر
            </text>
          </g>
        </svg>
        {showName && (
          <span className="text-[11px] font-medium tracking-wide text-amber-300/90">
            {name || 'Iraq'}
          </span>
        )}
      </div>
    );
  }

  if (country === 'uae') {
    return (
      <div 
        role={isClickable ? 'button' : undefined}
        tabIndex={isClickable ? 0 : undefined}
        onClick={isClickable ? handleFlagClick : undefined}
        onKeyDown={isClickable ? (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleFlagClick(e as unknown as React.MouseEvent);
          }
        } : undefined}
        title={name || 'United Arab Emirates'}
        className={`inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-archive-dark/70 border border-emerald-500/20 shadow-sm select-none ${
          isClickable ? 'cursor-pointer active:scale-95 hover:scale-105 hover:border-emerald-400/50' : 'cursor-default'
        } transition-all ${className}`}
      >
        <svg
          className="w-4 h-3 rounded-xs overflow-hidden shadow-xs shrink-0 pointer-events-none"
          viewBox="0 0 1200 600"
          aria-label="Flag of United Arab Emirates"
        >
          {/* Three horizontal stripes on fly */}
          <rect x="300" y="0" width="900" height="200" fill="#00732f" />
          <rect x="300" y="200" width="900" height="200" fill="#ffffff" />
          <rect x="300" y="400" width="900" height="200" fill="#000000" />
          {/* Vertical red band on hoist */}
          <rect x="0" y="0" width="300" height="600" fill="#ff0000" />
        </svg>
        {showName && (
          <span className="text-[11px] font-medium tracking-wide text-emerald-300/90">
            {name || 'United Arab Emirates'}
          </span>
        )}
      </div>
    );
  }

  return null;
};
