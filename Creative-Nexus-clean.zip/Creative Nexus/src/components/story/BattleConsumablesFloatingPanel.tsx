import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { UnifiedItemDefinition } from '../../types/items';
import { PlayerDeck } from '../../types/decks';
import { BattleCardEntity } from '../../types/story';
import { useItems } from '../../context/ItemContext';
import { BrawlStarsItemDisplay } from '../items/BrawlStarsItemDisplay';
import { playBattleSound } from '../../utils/battleAudio';
import { X, ArrowLeft, Heart, Zap, Shield, Swords, Sparkles } from 'lucide-react';

interface BattleConsumablesFloatingPanelProps {
  isOpen: boolean;
  onClose: () => void;
  activeDeck?: PlayerDeck | null;
  playerCards?: BattleCardEntity[];
  onUseItem: (item: UnifiedItemDefinition, targetCardIndex: number) => Promise<void>;
  usedItemsInBattle: Record<string, number>;
  activePlayerHp?: number;
  activePlayerMaxHp?: number;
  activePlayerStamina?: number;
  activePlayerMaxStamina?: number;
  isAr: boolean;
}

export const BattleConsumablesFloatingPanel: React.FC<BattleConsumablesFloatingPanelProps> = ({
  isOpen,
  onClose,
  activeDeck,
  playerCards = [],
  onUseItem,
  isAr
}) => {
  const { items, inventoryMap } = useItems();
  
  // State: selected consumable transitions to the "Choose card" screen
  const [selectedConsumable, setSelectedConsumable] = useState<UnifiedItemDefinition | null>(null);

  // Reset when panel closes
  useEffect(() => {
    if (!isOpen) {
      setSelectedConsumable(null);
    }
  }, [isOpen]);

  // Helper: format what the item does simply
  const getEffectSummary = (item: UnifiedItemDefinition): string => {
    if (!item.battleEffect) return isAr ? 'عنصر قتالي' : 'Combat Item';
    const { type, value } = item.battleEffect;
    switch (type) {
      case 'HEAL_HP':
        return isAr ? `+${value} صحة` : `+${value} HP`;
      case 'RESTORE_STAMINA':
        return isAr ? `+${value} جهد` : `+${value} Stamina`;
      case 'GRANT_SHIELD':
        return isAr ? `+${value} درع` : `+${value} Shield`;
      case 'BUFF_ATTACK':
        return isAr ? `+${value}% هجوم` : `+${value}% Attack`;
      case 'BUFF_DEFENSE':
        return isAr ? `+${value}% دفاع` : `+${value}% Defense`;
      default:
        return isAr ? 'تأثير قتالي' : 'Combat Effect';
    }
  };

  // Resolve exactly 4 places: only show items the player actually has; otherwise write "Empty"
  const fourPlaces = useMemo(() => {
    const deckItemIds = Array.isArray(activeDeck?.itemIds) ? activeDeck.itemIds : [];
    const resolved: (UnifiedItemDefinition | null)[] = [null, null, null, null];

    // 1. Populate configured deck items if player has them in inventory
    for (let slot = 0; slot < 4; slot++) {
      const id = deckItemIds[slot];
      if (id) {
        const found = items.find(i => i.id === id);
        const count = found ? (inventoryMap[found.id]?.count ?? 0) : 0;
        if (found && count > 0) {
          resolved[slot] = found;
        }
      }
    }

    // 2. If deck had no configured items with inventory, check if user has any battle items
    const hasAnyInSlots = resolved.some(item => Boolean(item));
    if (!hasAnyInSlots) {
      const ownedBattle = items.filter(
        i => i.category === 'BATTLE' && (inventoryMap[i.id]?.count ?? 0) > 0
      );
      for (let i = 0; i < Math.min(4, ownedBattle.length); i++) {
        resolved[i] = ownedBattle[i];
      }
    }

    return resolved;
  }, [activeDeck, items, inventoryMap]);

  // Handle selecting a consumable
  const handleSelectConsumable = (item: UnifiedItemDefinition) => {
    playBattleSound('FORMATION_SUMMON', 0.85);
    setSelectedConsumable(item);
  };

  // Handle applying to the chosen card
  const handleApplyToCard = async (targetCardIndex: number) => {
    if (!selectedConsumable) return;
    const targetCard = playerCards[targetCardIndex];
    if (targetCard && (targetCard.isDefeated || targetCard.currentHp <= 0)) {
      return;
    }

    try {
      playBattleSound('FORMATION_SUMMON', 1.0);
      await onUseItem(selectedConsumable, targetCardIndex);
      onClose();
    } catch (err) {
      console.error('Error applying item to card:', err);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-3 overflow-hidden pointer-events-auto"
          style={{ perspective: 1200 }}
          dir={isAr ? 'rtl' : 'ltr'}
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/70 backdrop-blur-sm cursor-pointer"
          />

          {/* 
            Ultra-Simple 3D Tilting Panel (Static 3D Tilt to the right, no rotation animation loop)
          */}
          <motion.div
            initial={{ opacity: 0, scale: 0.88, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.88, y: 30 }}
            transition={{ type: 'spring', damping: 25, stiffness: 320 }}
            className="relative w-full max-w-sm sm:max-w-md bg-gradient-to-b from-[#031c20]/98 via-[#021114]/98 to-[#01090b]/98 border border-[#5eead4]/40 rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.9)] overflow-hidden z-10"
            style={{
              transform: 'perspective(1200px) rotateY(14deg) rotateZ(3.2deg) rotateX(7deg)',
              transformStyle: 'preserve-3d',
              boxShadow: '0 20px 60px rgba(0,0,0,0.85), 0 0 25px rgba(94,234,212,0.18)'
            }}
          >
            {/* Top metallic glow border */}
            <div
              className="absolute top-0 inset-x-0 h-[2px] pointer-events-none"
              style={{
                background: 'linear-gradient(90deg, transparent 0%, #5eead4 50%, transparent 100%)',
                boxShadow: '0 0 12px #5eead4'
              }}
            />

            {/* Header: Simple & Direct */}
            <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between bg-black/30">
              <div className="flex items-center gap-2">
                {selectedConsumable ? (
                  <button
                    type="button"
                    onClick={() => {
                      playBattleSound('FORMATION_SUMMON', 0.7);
                      setSelectedConsumable(null);
                    }}
                    className="w-7 h-7 rounded-lg bg-white/5 hover:bg-white/15 text-[#5eead4] flex items-center justify-center transition-all cursor-pointer"
                    title={isAr ? 'رجوع' : 'Back'}
                  >
                    <ArrowLeft size={15} className={isAr ? 'rotate-180' : ''} />
                  </button>
                ) : (
                  <div className="w-2.5 h-2.5 rounded-full bg-[#5eead4] shadow-[0_0_8px_#5eead4]" />
                )}
                <h2 className="text-sm font-bold text-white font-sans">
                  {selectedConsumable
                    ? (isAr ? 'اختر بطاقة لتطبيق التأثير عليها' : 'Choose a card to add the effect into it')
                    : (isAr ? 'العناصر المستهلكة' : 'Consumables')}
                </h2>
              </div>

              <button
                type="button"
                onClick={onClose}
                aria-label="Close"
                className="w-7 h-7 rounded-lg bg-white/5 hover:bg-white/15 text-stone-400 hover:text-white flex items-center justify-center transition-all cursor-pointer"
              >
                <X size={15} />
              </button>
            </div>

            {/* Content View */}
            <div className="p-3.5">
              <AnimatePresence mode="wait">
                {!selectedConsumable ? (
                  /* ========================================================
                     SCREEN 1: THE FOUR PLACES (JUST ITEM, NAME & WHAT IT DOES)
                     ======================================================== */
                  <motion.div
                    key="items_grid"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15 }}
                    className="grid grid-cols-2 gap-2.5"
                  >
                    {fourPlaces.map((item, index) => {
                      if (!item) {
                        return (
                          <div
                            key={`empty_${index}`}
                            className="rounded-2xl border border-dashed border-teal-900/40 bg-black/30 p-3 flex flex-col items-center justify-center text-center min-h-[110px]"
                          >
                            <span className="text-xs font-mono font-bold text-stone-500">
                              {isAr ? 'فارغ' : 'Empty'}
                            </span>
                          </div>
                        );
                      }

                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => handleSelectConsumable(item)}
                          className="rounded-2xl p-3 bg-gradient-to-b from-[#062930]/90 via-[#03171b]/90 to-black/90 border border-[#5eead4]/40 hover:border-[#5eead4] hover:shadow-[0_0_20px_rgba(94,234,212,0.3)] transition-all flex flex-col items-center justify-center text-center cursor-pointer min-h-[110px] group active:scale-95"
                        >
                          {/* Item Icon */}
                          <div className="w-12 h-12 flex items-center justify-center mb-1 shrink-0">
                            <BrawlStarsItemDisplay
                              item={item}
                              count={inventoryMap[item.id]?.count ?? 1}
                              size="compact"
                              isHoverable={false}
                              isAr={isAr}
                              showDetails={false}
                            />
                          </div>

                          {/* Item Name */}
                          <h3 className="text-xs font-bold text-white truncate max-w-full font-sans leading-tight">
                            {isAr ? (item.nameAr || item.name) : item.name}
                          </h3>

                          {/* What it does */}
                          <span className="mt-1 text-[11px] font-mono font-bold text-[#5eead4]">
                            {getEffectSummary(item)}
                          </span>
                        </button>
                      );
                    })}
                  </motion.div>
                ) : (
                  /* ========================================================
                     SCREEN 2: CHOOSE A CARD TO ADD THE EFFECT INTO IT
                     ======================================================== */
                  <motion.div
                    key="choose_card"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15 }}
                    className="space-y-2"
                  >
                    {/* Active Item Summary Chip */}
                    <div className="px-3 py-1.5 rounded-xl bg-teal-950/60 border border-[#5eead4]/30 flex items-center justify-between text-xs font-mono">
                      <span className="font-bold text-white truncate">
                        {isAr ? (selectedConsumable.nameAr || selectedConsumable.name) : selectedConsumable.name}
                      </span>
                      <span className="text-[#5eead4] font-bold shrink-0">
                        {getEffectSummary(selectedConsumable)}
                      </span>
                    </div>

                    {/* Card List */}
                    <div className="space-y-2 max-h-[300px] overflow-y-auto studio-scrollbar pr-0.5">
                      {playerCards.map((cardEntity, idx) => {
                        const isDefeated = Boolean(cardEntity.isDefeated || cardEntity.currentHp <= 0);
                        const hpPercent = Math.min(100, Math.max(0, Math.round((cardEntity.currentHp / (cardEntity.maxHp || 100)) * 100)));
                        const stmPercent = Math.min(100, Math.max(0, Math.round(((cardEntity.currentStamina ?? 100) / (cardEntity.maxStamina || 100)) * 100)));

                        return (
                          <button
                            key={cardEntity.instanceId || `card_${idx}`}
                            type="button"
                            disabled={isDefeated}
                            onClick={() => handleApplyToCard(idx)}
                            className={`w-full text-left rounded-2xl p-2.5 border transition-all flex items-center gap-3 relative overflow-hidden cursor-pointer ${
                              isDefeated
                                ? 'bg-black/50 border-white/5 opacity-40 cursor-not-allowed'
                                : 'bg-gradient-to-r from-[#042126]/90 via-[#031519]/90 to-black/90 border-[#5eead4]/40 hover:border-[#5eead4] hover:shadow-[0_0_15px_rgba(94,234,212,0.3)]'
                            }`}
                          >
                            {/* Card Image */}
                            <div className="w-11 h-13 rounded-xl overflow-hidden bg-black/80 border border-white/10 shrink-0 relative flex items-center justify-center">
                              {cardEntity.card?.imageUrl ? (
                                <img
                                  src={cardEntity.card.imageUrl}
                                  alt={cardEntity.card.name}
                                  className={`w-full h-full object-cover object-center ${isDefeated ? 'grayscale' : ''}`}
                                />
                              ) : (
                                <div className="w-full h-full bg-teal-950 flex items-center justify-center text-stone-400 font-mono text-[10px]">
                                  #{idx + 1}
                                </div>
                              )}
                            </div>

                            {/* Card Details & HP/Stamina */}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between gap-2">
                                <h4 className="text-xs font-bold text-white truncate font-sans">
                                  {isAr ? (cardEntity.card?.nameAr || cardEntity.card?.name) : cardEntity.card?.name}
                                </h4>
                                {isDefeated && (
                                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-rose-950/80 text-rose-300 border border-rose-500/40">
                                    {isAr ? 'ساقط' : 'Defeated'}
                                  </span>
                                )}
                              </div>

                              {/* HP Bar */}
                              <div className="mt-1.5 space-y-0.5">
                                <div className="flex items-center justify-between text-[9px] font-mono text-rose-300">
                                  <span>HP: {cardEntity.currentHp}/{cardEntity.maxHp}</span>
                                  <span>{hpPercent}%</span>
                                </div>
                                <div className="w-full h-1.5 rounded-full bg-black/60 overflow-hidden border border-white/5">
                                  <div
                                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-300"
                                    style={{ width: `${hpPercent}%` }}
                                  />
                                </div>
                              </div>

                              {/* Stamina Bar */}
                              <div className="mt-1 space-y-0.5">
                                <div className="flex items-center justify-between text-[8.5px] font-mono text-cyan-300">
                                  <span>STM: {cardEntity.currentStamina ?? 100}/{cardEntity.maxStamina || 100}</span>
                                </div>
                                <div className="w-full h-1 rounded-full bg-black/60 overflow-hidden border border-white/5">
                                  <div
                                    className="h-full bg-gradient-to-r from-cyan-500 to-blue-400 transition-all duration-300"
                                    style={{ width: `${stmPercent}%` }}
                                  />
                                </div>
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
