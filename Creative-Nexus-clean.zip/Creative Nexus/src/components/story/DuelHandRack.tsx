import React, { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { BattleCardEntity } from '../../types/story';
import { Zap, Shield, Skull, Sparkles } from 'lucide-react';
import { getRarityConfig } from '../../config/rarityConfig';

export interface CardHandOrigin {
  left: number;
  top: number;
  width: number;
  height: number;
  rotateZ: number;
  x: number;
  y: number;
}

interface DuelHandRackProps {
  cards: BattleCardEntity[];
  selectedCardIndex: number | null;
  inspectingCardIndex?: number | null;
  isTableEmpty: boolean;
  isSelectingNextCard: boolean;
  isAr: boolean;
  onCardSelect: (index: number, origin?: CardHandOrigin) => void;
  canInteract: boolean;
}

export const DuelHandRack: React.FC<DuelHandRackProps> = ({
  cards,
  selectedCardIndex,
  inspectingCardIndex,
  isTableEmpty,
  isSelectingNextCard,
  isAr,
  onCardSelect,
  canInteract
}) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);

  // Fanning angles and vertical offsets for natural "held in hand" look (Uno & Yu-Gi-Oh style)
  const getFanTransform = (index: number, total: number, isHovered: boolean) => {
    if (isHovered) {
      return {
        rotateZ: 0,
        rotateX: 0,
        y: -18,
        scale: 1.12,
        zIndex: 40
      };
    }

    const mid = (total - 1) / 2;
    const diff = index - mid;
    const rotateZ = diff * 3;
    const rotateX = 8;
    const y = Math.abs(diff) * 2.5;
    const zIndex = 10 + index;

    return {
      rotateZ,
      rotateX,
      y,
      scale: 1,
      zIndex
    };
  };

  const handleCardClick = (idx: number) => {
    const el = cardRefs.current[idx];
    let origin: CardHandOrigin | undefined = undefined;

    if (el && typeof window !== 'undefined') {
      try {
        const rect = el.getBoundingClientRect();
        const screenCenterX = window.innerWidth / 2;
        const screenCenterY = window.innerHeight / 2;
        const cardTransform = getFanTransform(idx, cards.length, false);
        const ox = Math.round((rect.left + rect.width / 2) - screenCenterX);
        const oy = Math.round((rect.top + rect.height / 2) - screenCenterY);
        const w = Math.round(rect.width);
        const h = Math.round(rect.height);

        if (!isNaN(ox) && !isNaN(oy) && w > 0 && h > 0) {
          origin = {
            left: Math.round(rect.left),
            top: Math.round(rect.top),
            x: ox,
            y: oy,
            width: w,
            height: h,
            rotateZ: cardTransform.rotateZ
          };
        }
      } catch {
        origin = undefined;
      }
    }

    onCardSelect(idx, origin);
  };

  return (
    <div className="relative w-full max-w-2xl mx-auto flex flex-col items-center select-none pt-1 pointer-events-auto">
      {/* 1. THE YU-GI-OH / UNO STYLE DUEL TRAY BASE CHASSIS */}
      <div 
        className="relative w-full rounded-2xl sm:rounded-3xl border border-cyan-500/40 px-1.5 xs:px-2 sm:px-4 pt-1.5 xs:pt-2 sm:pt-3 pb-1.5 sm:pb-2 shadow-[0_15px_45px_rgba(0,0,0,0.9),inset_0_1px_2px_rgba(255,255,255,0.15)] flex flex-col items-center"
        style={{
          background: 'linear-gradient(180deg, rgba(12,28,36,0.95) 0%, rgba(4,14,18,0.98) 100%)',
          boxShadow: '0 12px 35px rgba(0,0,0,0.85), inset 0 1px 0 rgba(94,234,212,0.3), inset 0 -2px 6px rgba(0,0,0,0.8)'
        }}
      >
        {/* Neon Power Conduit Line running along top of tray */}
        <div className="absolute -top-[1.5px] inset-x-8 sm:inset-x-16 h-[2px] bg-gradient-to-r from-transparent via-[#5eead4] to-transparent opacity-95 shadow-[0_0_12px_rgba(94,234,212,0.9)] pointer-events-none" />

        {/* Tray Decorative Mechanical Grip Trim */}
        <div className="absolute -bottom-1 inset-x-12 sm:inset-x-24 h-1 bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent rounded-full pointer-events-none" />

        {/* Status Chip on the Duel Tray */}
        <div className="flex items-center justify-between w-full px-1.5 mb-0.5 sm:mb-1 pointer-events-none">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#5eead4] animate-ping" />
            <span className="text-[7px] sm:text-[9px] font-mono font-black tracking-widest text-cyan-300 uppercase drop-shadow">
              {isAr ? 'منصة المبارزة' : 'DUEL DISK TRAY'}
            </span>
          </div>

          <div className="flex items-center gap-1 text-[6.5px] sm:text-[8px] font-mono font-bold text-slate-400">
            <span className="px-1.5 py-0.2 rounded bg-black/50 border border-cyan-500/30 text-cyan-200">
              {cards.filter(c => !c.isDefeated && c.currentHp > 0).length} / 4 {isAr ? 'متاح' : 'READY'}
            </span>
          </div>
        </div>

        {/* 2. THE 3D CARDS FAN CONTAINER */}
        <div 
          className="flex justify-center items-end gap-1 xs:gap-1.5 sm:gap-2.5 md:gap-3.5 w-full relative z-10 min-h-[110px] xs:min-h-[125px] sm:min-h-[155px] md:min-h-[180px] py-0.5 sm:py-1"
          style={{ perspective: '1000px' }}
        >
          {cards.slice(0, 4).map((card, idx) => {
            const isDead = card.isDefeated || card.currentHp <= 0;
            const maxHp = card.maxHp || 100;
            const hpPct = Math.max(0, Math.min(100, Math.round((card.currentHp / maxHp) * 100)));
            const currentStamina = card.currentStamina ?? 100;
            const maxStamina = card.maxStamina || 100;
            const staminaPct = Math.max(0, Math.min(100, Math.round((currentStamina / maxStamina) * 100)));
            const isExhausted = currentStamina <= 0;
            const isSelected = !isTableEmpty && idx === selectedCardIndex;
            const isInspecting = inspectingCardIndex === idx;
            const isHovered = hoveredIdx === idx && !isDead && !isInspecting;
            const transform = getFanTransform(idx, cards.length, isHovered);

            return (
              <motion.div
                key={card.instanceId}
                ref={(el) => { cardRefs.current[idx] = el; }}
                role="button"
                tabIndex={0}
                initial={false}
                animate={{
                  y: transform.y,
                  rotateZ: transform.rotateZ,
                  scale: isHovered ? 1.12 : isSelected ? 1.05 : 1,
                  zIndex: transform.zIndex
                }}
                transition={{
                  type: 'spring',
                  stiffness: 420,
                  damping: 24,
                  mass: 0.8
                }}
                onHoverStart={() => !isDead && !isInspecting && setHoveredIdx(idx)}
                onHoverEnd={() => setHoveredIdx(null)}
                onTap={() => {
                  if (isDead) return;
                  handleCardClick(idx);
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  if (isDead) return;
                  handleCardClick(idx);
                }}
                className={`relative flex flex-col items-center w-[21vw] max-w-[62px] xs:max-w-[72px] sm:max-w-[92px] md:max-w-[110px] shrink-0 cursor-pointer touch-manipulation focus:outline-none ${
                  isDead ? 'opacity-30 grayscale cursor-not-allowed' : 'active:scale-95'
                }`}
                style={{
                  transformOrigin: 'bottom center'
                }}
              >
                {/* HEALTH & STAMINA (STM) BARS ABOVE EACH CARD - NUMBERS & BARS ONLY */}
                <div className="w-full px-0.5 space-y-0.5 mb-1 pointer-events-none">
                  {/* Health Bar */}
                  <div className="flex items-center justify-between text-[6.5px] xs:text-[7.5px] sm:text-[8.5px] font-mono font-black text-white leading-tight mb-0.5">
                    <span className="text-cyan-300 font-bold">HP</span>
                    <span className={hpPct > 50 ? 'text-[#5eead4]' : hpPct > 20 ? 'text-amber-300' : 'text-rose-400 font-black'}>
                      {card.currentHp}/{maxHp}
                    </span>
                  </div>
                  <div className="w-full h-1.5 xs:h-2 sm:h-2 rounded-full bg-slate-900 border border-white/15 overflow-hidden p-[0.5px] shadow-[inset_0_1px_2px_rgba(0,0,0,0.9)]">
                    <div 
                      className={`h-full rounded-full transition-all duration-300 ${
                        hpPct > 50 
                          ? 'bg-gradient-to-r from-teal-500 via-cyan-400 to-[#5eead4] shadow-[0_0_8px_rgba(94,234,212,0.9)]' 
                          : hpPct > 20 
                            ? 'bg-gradient-to-r from-amber-500 to-yellow-300' 
                            : 'bg-gradient-to-r from-red-600 to-rose-400'
                      }`}
                      style={{ width: `${hpPct}%` }}
                    />
                  </div>

                  {/* Stamina Bar (STM) - Replaces energy */}
                  <div className="flex items-center justify-between text-[6px] xs:text-[7px] sm:text-[8px] font-mono font-bold leading-tight mt-0.5 mb-0.2">
                    <span className={isExhausted ? 'text-rose-400 animate-pulse font-black' : 'text-emerald-300'}>
                      {isExhausted ? (isAr ? 'منهك!' : 'EXHAUSTED') : (isAr ? 'الجهد' : 'STM')}
                    </span>
                    <span className={isExhausted ? 'text-rose-400 font-bold' : 'text-emerald-300'}>
                      {currentStamina}/{maxStamina}
                    </span>
                  </div>
                  <div className="w-full h-1 xs:h-1.5 sm:h-1.5 rounded-full bg-slate-900 border border-emerald-500/25 overflow-hidden p-[0.5px] shadow-[inset_0_1px_2px_rgba(0,0,0,0.9)]">
                    <div 
                      className={`h-full rounded-full transition-all duration-300 ${
                        isExhausted
                          ? 'bg-rose-500'
                          : staminaPct > 40
                            ? 'bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-300 shadow-[0_0_6px_rgba(16,185,129,0.7)]'
                            : 'bg-gradient-to-r from-amber-500 to-rose-400'
                      }`}
                      style={{ width: `${staminaPct}%` }}
                    />
                  </div>
                </div>

                {/* THE 3D CARD BODY OR HOLOGRAPHIC ENGAGED CRADLE */}
                {isInspecting ? (
                  /* Engaged Holographic Socket: Card has popped out to inspect! */
                  <div 
                    className="w-full aspect-[5/7] rounded-xl sm:rounded-2xl border-2 border-dashed border-cyan-400/60 bg-gradient-to-b from-cyan-950/40 to-slate-950/70 backdrop-blur-xs flex flex-col items-center justify-center p-1.5 shadow-[0_0_20px_rgba(94,234,212,0.25)] select-none animate-pulse"
                  >
                    <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center shadow-lg">
                      <span className="w-2 h-2 rounded-full bg-[#5eead4] animate-ping" />
                    </div>
                    <span className="text-[6px] sm:text-[7.5px] font-mono font-black text-cyan-300 uppercase tracking-widest mt-1 text-center">
                      {isAr ? 'قيد الفحص' : 'INSPECTING'}
                    </span>
                  </div>
                ) : (() => {
                  const rarityConf = getRarityConfig(card.card.rarity);
                  const isCommon = rarityConf.id === 'COMMON';
                  const isLegendary = rarityConf.id === 'LEGENDARY';
                  const isEpic = rarityConf.id === 'EPIC';
                  const isRare = rarityConf.id === 'RARE';
                  const isUncommon = rarityConf.id === 'UNCOMMON';

                  return (
                    <div
                      onClick={(e) => {
                        e.stopPropagation();
                        if (isDead) return;
                        handleCardClick(idx);
                      }}
                      className={`group relative w-full aspect-[5/7] rounded-xl sm:rounded-2xl overflow-hidden border-2 transition-all duration-300 flex flex-col justify-between select-none ${
                        isDead
                          ? 'border-slate-800 bg-slate-950 opacity-40 grayscale'
                          : isSelected
                            ? `ring-4 shadow-2xl`
                            : isHovered
                              ? `ring-2 shadow-xl`
                              : `shadow-md`
                      }`}
                      style={{
                        background: rarityConf.bgGradient,
                        borderColor: isSelected 
                          ? rarityConf.accentColor 
                          : isHovered 
                            ? rarityConf.primaryColor 
                            : `${rarityConf.borderColor}aa`,
                        boxShadow: isHovered
                          ? `${rarityConf.depthShadow}, 0 0 16px ${rarityConf.glowColor}`
                          : rarityConf.depthShadow
                      }}
                    >
                      {/* Rarity-specific Ambient Lighting */}
                      <div 
                        className={`absolute inset-0 pointer-events-none transition-opacity duration-300 ${
                          isHovered ? 'opacity-40' : 'opacity-20'
                        }`}
                        style={{
                          background: `radial-gradient(circle at 50% 20%, ${rarityConf.glowColor} 0%, transparent 75%)`
                        }}
                      />

                      {/* Glossy Top Edge Highlight */}
                      <div 
                        className="absolute top-0 inset-x-0 h-[2px] opacity-90 pointer-events-none" 
                        style={{
                          background: `linear-gradient(to right, transparent, ${rarityConf.accentColor}, transparent)`
                        }}
                      />

                      {/* Card Illustration with Rarity Saturation Profile */}
                      <img 
                        src={card.card.imageUrl} 
                        alt={card.card.name} 
                        className={`absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 pointer-events-none ${rarityConf.saturationClass}`}
                      />

                      {/* Shading Gradients for Depth */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/92 via-transparent to-black/60 pointer-events-none" />

                      {/* Subtle Animated Shimmer for Uncommon/Rare/Epic/Legendary */}
                      {!isCommon && (isHovered || isSelected) && (
                        <motion.div 
                          initial={{ x: '-100%' }}
                          animate={{ x: '200%' }}
                          transition={{ duration: isLegendary ? 0.9 : 1.2, repeat: Infinity, repeatDelay: 0.6, ease: 'linear' }}
                          className="absolute inset-y-0 w-1/2 bg-gradient-to-r from-transparent via-white/18 to-transparent skew-x-12 pointer-events-none"
                        />
                      )}

                      {/* Floating Micro-Particles for Legendary & Epic */}
                      {(isLegendary || isEpic) && (
                        <div className="absolute inset-0 pointer-events-none overflow-hidden z-15">
                          <span className="absolute top-2 right-2 w-1 h-1 rounded-full bg-amber-300/80 animate-ping" />
                          <span className="absolute bottom-6 left-2 w-1 h-1 rounded-full bg-yellow-200/60 animate-pulse" />
                        </div>
                      )}

                      {/* Top: Card Name & Shield badge */}
                      <div className="relative z-10 px-1 py-0.5 flex items-center justify-between pointer-events-none">
                        <span 
                          className="text-[7.5px] xs:text-[8.5px] sm:text-[10px] font-black font-sans text-white truncate drop-shadow-[0_1px_3px_rgba(0,0,0,1)] tracking-wide"
                          style={{
                            color: isLegendary ? '#fef08a' : isEpic ? '#f3e8ff' : isRare ? '#93c5fd' : isUncommon ? '#86efac' : '#ffffff'
                          }}
                        >
                          {card.card.name}
                        </span>
                        {card.shield > 0 && (
                          <span className="px-1 py-0.2 rounded-md bg-blue-500/40 border border-blue-400 text-blue-200 text-[6px] sm:text-[7px] font-mono font-black flex items-center gap-0.5 shadow-sm">
                            <Shield size={7} />
                            +{card.shield}
                          </span>
                        )}
                      </div>

                      {/* Skull if Dead */}
                      {isDead && (
                        <div className="absolute inset-0 z-20 bg-black/85 flex items-center justify-center pointer-events-none">
                          <Skull size={18} className="text-slate-500" />
                        </div>
                      )}

                      {/* Bottom: ORGANIZED ATK & DEF STATS (No rarity circle) */}
                      <div className="relative z-10 w-full px-1.5 py-0.5 bg-black/75 backdrop-blur-xs border-t border-white/10 flex items-center justify-between pointer-events-none rounded-b-[inherit]">
                        <div className="flex items-center gap-0.5 font-mono font-black text-cyan-300 drop-shadow">
                          <span className="text-[5.5px] xs:text-[6.5px] sm:text-[7.5px] text-cyan-400 font-bold uppercase tracking-tighter">ATK</span>
                          <span className="text-[7px] xs:text-[8px] sm:text-[9.5px]">{card.attack}</span>
                        </div>
                        <div className="flex items-center gap-0.5 font-mono font-black text-amber-300 drop-shadow">
                          <span className="text-[5.5px] xs:text-[6.5px] sm:text-[7.5px] text-amber-400 font-bold uppercase tracking-tighter">DEF</span>
                          <span className="text-[7px] xs:text-[8px] sm:text-[9.5px]">{card.defense}</span>
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* 3D Physical Card Socket / Shadow in Tray */}
                <div 
                  className="w-4/5 h-1 rounded-full bg-black/70 blur-[2px] mt-0.5 transition-opacity duration-300 pointer-events-none"
                  style={{ opacity: isHovered ? 0.3 : 0.8 }}
                />
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
