import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  StoryBattleDefinition, 
  BattleSessionState, 
  CombatIntent,
  CombatIntentType,
  RoundClashResolution,
  BattleCardEntity,
  ACTION_CONFIGS
} from '../../types/story';
import { PlayerDeck } from '../../types/decks';
import { CollectibleCardData } from '../../types/cards';
import { useLanguage } from '../../context/LanguageContext';
import { 
  initializeBattleCards, 
  createInitialMomentum,
  resolveRoundIntents, 
  generateEnemyIntentInfo,
  countAliveCards 
} from '../../utils/battleEngine';
import { playBattleSound, playCombatActionSound } from '../../utils/battleAudio';
import { BattleActiveZone, ClashStage } from './BattleActiveZone';
import { CardActionInspector, CardActionOrigin } from './CardActionInspector';
import { DuelHandRack } from './DuelHandRack';
import { EnemyDuelRack } from './EnemyDuelRack';
import { 
  Swords, Shield, Zap, Skull, 
  X, Flame, Crown, ScrollText,
  Backpack, Sparkles 
} from 'lucide-react';
import { BattleItemsModal } from './BattleItemsModal';
import { BattleConsumablesFloatingPanel } from './BattleConsumablesFloatingPanel';
import { useItems } from '../../context/ItemContext';
import { UnifiedItemDefinition } from '../../types/items';

interface BattleArenaProps {
  battle: StoryBattleDefinition;
  activeDeck?: PlayerDeck | null;
  playerDeckCards?: CollectibleCardData[];
  playerCards?: CollectibleCardData[];
  enemyDeckCards?: CollectibleCardData[];
  enemyCards?: CollectibleCardData[];
  onComplete: (outcome: 'VICTORY' | 'DEFEAT') => Promise<any>;
  onExit?: () => void;
  onClose?: () => void;
}

export const BattleArena: React.FC<BattleArenaProps> = ({
  battle,
  activeDeck,
  playerDeckCards,
  playerCards,
  enemyDeckCards,
  enemyCards,
  onComplete,
  onExit,
  onClose
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const handleExit = onExit || onClose || (() => {});

  // Exactly 4 cards for each side
  const resolvedPlayerCards = playerDeckCards || playerCards || [];
  const resolvedEnemyCards = battle.enemyCards && battle.enemyCards.length > 0
    ? battle.enemyCards
    : (enemyDeckCards || enemyCards || []);

  const [battleState, setBattleState] = useState<BattleSessionState>(() => {
    const pCards = initializeBattleCards(resolvedPlayerCards, 'player');
    const eCards = initializeBattleCards(resolvedEnemyCards, 'enemy');

    return {
      battleId: battle.id,
      battleName: battle.name,
      turnNumber: 1,
      roundNumber: 1,
      currentTurnSide: 'PLAYER',
      initiative: 'PLAYER',
      playerCards: pCards,
      enemyCards: eCards,
      playerActiveIndex: 0,
      enemyActiveIndex: 0,
      playerActiveFighterId: pCards[0]?.instanceId || null,
      enemyActiveFighterId: eCards[0]?.instanceId || null,
      playerMomentum: createInitialMomentum(),
      enemyMomentum: createInitialMomentum(),
      phase: 'COMBAT_ACTIVE',
      roundPhase: 'CHOOSE',
      selectedPlayerIntent: null,
      selectedEnemyIntent: null,
      currentClashData: null,
      turnPlanningLocked: false,
      isActionRevealed: false,
      lastClashResolution: null,
      isLastStand: false,
      lastStandSide: null,
      playerPatternHistory: [],
      activeMoment: null,
      logs: [],
      winner: null,
      coinsEarned: 0,
      xpEarned: 0,
      isFirstClear: false
    };
  });

  const battleStateRef = useRef<BattleSessionState>(battleState);
  battleStateRef.current = battleState;

  // TABLE STATE
  const [isTableEmpty, setIsTableEmpty] = useState<boolean>(true);
  const [selectedPlayerCardIndex, setSelectedPlayerCardIndex] = useState<number | null>(null);
  const [selectedEnemyCardIndex, setSelectedEnemyCardIndex] = useState<number | null>(null);
  const [inspectingCardIndex, setInspectingCardIndex] = useState<number | null>(null);
  const [inspectingCardOrigin, setInspectingCardOrigin] = useState<CardActionOrigin | null>(null);

  // Pre-clash stats for animated bar decrease/increase during clash
  const [preClashPlayer, setPreClashPlayer] = useState<{ hp: number; stamina: number; maxHp: number; maxStamina: number } | null>(null);
  const [preClashEnemy, setPreClashEnemy] = useState<{ hp: number; stamina: number; maxHp: number; maxStamina: number } | null>(null);
  const [isClashEffectApplied, setIsClashEffectApplied] = useState<boolean>(false);

  // SELECTION LOGIC STATE
  const [isSelectingNextCard, setIsSelectingNextCard] = useState<boolean>(false);

  // 3 2 1 FIGHT COUNTDOWN ANIMATION
  const [countdownText, setCountdownText] = useState<'3' | '2' | '1' | 'FIGHT' | null>('3');

  // ANIMATIONS & EFFECTS
  const [screenShake, setScreenShake] = useState<boolean>(false);
  const [impactFlash, setImpactFlash] = useState<boolean>(false);
  const [tableSlamImpact, setTableSlamImpact] = useState<boolean>(false);
  const [isCardSlamming, setIsCardSlamming] = useState<boolean>(false);
  const [isEnemyCardFlipping, setIsEnemyCardFlipping] = useState<boolean>(false);
  const [clashAnimationStage, setClashAnimationStage] = useState<ClashStage>('IDLE');
  const [lockedAction, setLockedAction] = useState<CombatIntentType | null>(null);
  const [enemySecretAction, setEnemySecretAction] = useState<CombatIntent | null>(null);

  // Big screen action words & Dramatic banners
  const [bigClashWord, setBigClashWord] = useState<string | null>(null);
  const [dramaticBanner, setDramaticBanner] = useState<{
    text: string;
    textAr: string;
    color: string;
    sub: string;
  } | null>(null);
  const [koStamp, setKoStamp] = useState<string | null>(null);

  const [floatingDamage, setFloatingDamage] = useState<{
    target: 'PLAYER' | 'ENEMY';
    amount: number;
    isCrit?: boolean;
  } | null>(null);

  // Combat Log Drawer
  const [showLogDrawer, setShowLogDrawer] = useState<boolean>(false);

  // Battle Consumables & Item System
  const { inventory, useBattleItemInCombat } = useItems();
  const [showBattleItemsModal, setShowBattleItemsModal] = useState<boolean>(false);
  const [usedItemsInBattle, setUsedItemsInBattle] = useState<Record<string, number>>({});
  const [itemFeedbackToast, setItemFeedbackToast] = useState<{ text: string; color: string } | null>(null);

  const battleConsumablesCount = inventory
    .filter(e => e.count > 0 && e.itemData?.category === 'BATTLE')
    .reduce((acc, e) => acc + e.count, 0);

  // Victory / Defeat outcome
  const [battleOutcome, setBattleOutcome] = useState<'VICTORY' | 'DEFEAT' | null>(null);
  const [isSubmittingResult, setIsSubmittingResult] = useState<boolean>(false);
  const [rewardOutcome, setRewardOutcome] = useState<{
    coinsAwarded: number;
    xpAwarded: number;
    isFirstClear: boolean;
  } | null>(null);

  const playerActiveCard = selectedPlayerCardIndex !== null 
    ? battleState.playerCards[selectedPlayerCardIndex] 
    : null;

  const enemyActiveCard = selectedEnemyCardIndex !== null 
    ? battleState.enemyCards[selectedEnemyCardIndex] 
    : null;

  // 3 2 1 FIGHT Sequence upon battle entry
  useEffect(() => {
    setCountdownText('3');
    playBattleSound('TACTICAL_SELECT', 0.9);

    const t1 = setTimeout(() => {
      setCountdownText('2');
      playBattleSound('TACTICAL_SELECT', 1.0);
    }, 650);

    const t2 = setTimeout(() => {
      setCountdownText('1');
      playBattleSound('ENERGY_SURGE', 1.0);
    }, 1300);

    const t3 = setTimeout(() => {
      setCountdownText('FIGHT');
      playBattleSound('SWORD_CLASH', 1.0);
      setScreenShake(true);
      setTimeout(() => setScreenShake(false), 300);
    }, 1950);

    const t4 = setTimeout(() => {
      setCountdownText(null);
    }, 2650);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
    };
  }, []);

  // Update enemy secret action secretly whenever fighters are deployed
  useEffect(() => {
    if (!isTableEmpty && enemyActiveCard && playerActiveCard && !lockedAction) {
      const generated = generateEnemyIntentInfo(
        enemyActiveCard, 
        playerActiveCard, 
        battle.difficulty, 
        battleState.turnNumber,
        battleState
      );
      setEnemySecretAction(generated.secretAction);
    }
  }, [isTableEmpty, enemyActiveCard, playerActiveCard, lockedAction, battle.difficulty, battleState]);

  // =========================================================================
  // USER REQUIREMENT:
  // "When I press at a card I want it to get pop out from it's place and gets closer to user
  // and then an animation of the bars getting from behind the card show up showing me the bars energy and health
  // then slowly the actions buttons will appear, I want better movements and animations for all of this
  // And if I press away the card gets back to it's place in a smooth animation"
  // =========================================================================
  const handleCardClick = (cardIndex: number, origin?: CardActionOrigin) => {
    // Dismiss countdown immediately when player taps a card
    if (countdownText !== null) {
      setCountdownText(null);
    }
    // Only block if cards are actively colliding/lunging in mid-clash
    if (clashAnimationStage === 'LUNGE_CLASH' || clashAnimationStage === 'IMPACT_BURST') return;

    const card = battleState.playerCards[cardIndex];
    if (!card || card.isDefeated || card.currentHp <= 0) return;

    setInspectingCardOrigin(origin || null);
    setInspectingCardIndex(cardIndex);
  };

  // =========================================================================
  // USER REQUIREMENT:
  // "when I take an action the card, bars and buttons will fade out,
  // then suddenly a card throw animation will happen in the table and the enemy's card will be thrown,
  // the enemy card should be a flat card hidden from user until the action happen"
  // =========================================================================
  const handleActionFromInspector = (action: CombatIntentType, cardIdx: number) => {
    setInspectingCardIndex(null);
    setInspectingCardOrigin(null);

    const card = battleState.playerCards[cardIdx];
    if (!card || card.isDefeated || card.currentHp <= 0) return;

    let enemyIndex = selectedEnemyCardIndex;
    const currentEnemy = enemyIndex !== null ? battleState.enemyCards[enemyIndex] : null;
    
    if (!currentEnemy || currentEnemy.isDefeated || currentEnemy.currentHp <= 0) {
      const survivingEnemy = battleState.enemyCards
        .map((c, i) => (!c.isDefeated && c.currentHp > 0 ? i : -1))
        .filter(i => i !== -1);
      enemyIndex = survivingEnemy.length > 0 
        ? survivingEnemy[Math.floor(Math.random() * survivingEnemy.length)] 
        : 0;
    }

    const enemyFighter = battleState.enemyCards[enemyIndex];

    // Snapshot pre-clash stats before effects take place
    setPreClashPlayer({
      hp: card.currentHp,
      stamina: card.currentStamina ?? 100,
      maxHp: card.maxHp || 100,
      maxStamina: card.maxStamina || 100
    });
    setPreClashEnemy({
      hp: enemyFighter ? enemyFighter.currentHp : 100,
      stamina: enemyFighter ? (enemyFighter.currentStamina ?? 100) : 100,
      maxHp: enemyFighter ? enemyFighter.maxHp : 100,
      maxStamina: enemyFighter ? (enemyFighter.maxStamina || 100) : 100
    });
    setIsClashEffectApplied(false);

    // Set active fighters
    setSelectedPlayerCardIndex(cardIdx);
    setSelectedEnemyCardIndex(enemyIndex);
    setIsTableEmpty(false);
    setLockedAction(action);
    setIsSelectingNextCard(false);

    // 1. The card gets thrown on the table
    setClashAnimationStage('CARD_THROW');
    setIsEnemyCardFlipping(false);
    playBattleSound('FORMATION_SUMMON', 1.0);

    // Secret enemy intent (resolved using intelligent battle brain)
    const activeEnemy = battleStateRef.current.enemyCards[enemyIndex];
    const activePlayer = battleStateRef.current.playerCards[cardIdx];
    const aiIntent: CombatIntent = enemySecretAction || (
      activeEnemy 
        ? generateEnemyIntentInfo(activeEnemy, activePlayer, battle.difficulty, battleStateRef.current.turnNumber, battleStateRef.current).secretAction
        : { side: 'ENEMY', type: 'STRIKE' }
    );
    setEnemySecretAction(aiIntent);

    // Landing table slam at 100ms (Card placed on table)
    const CARD_PLACE_DELAY_MS = 100;
    setTimeout(() => {
      playBattleSound('HEAVY_SLAM', 0.85);
      setTableSlamImpact(true);
      setIsEnemyCardFlipping(true);
      setTimeout(() => setTableSlamImpact(false), 120);
    }, CARD_PLACE_DELAY_MS);

    // 2. Exactly 0.5 seconds (500ms) between the card place and the action!
    // Card placed at 100ms -> Action executes at 100ms + 500ms = 600ms
    const DELAY_BETWEEN_PLACE_AND_ACTION_MS = 500; // 0.5 seconds
    setTimeout(() => {
      setBigClashWord(null);
      setClashAnimationStage('ACTION_CLASH');
      executeClash(
        cardIdx,
        enemyIndex,
        { side: 'PLAYER', type: action },
        aiIntent
      );
    }, CARD_PLACE_DELAY_MS + DELAY_BETWEEN_PLACE_AND_ACTION_MS);
  };

  const executeClash = (
    pCardIdx: number,
    eCardIdx: number,
    playerIntent: CombatIntent,
    enemyIntent: CombatIntent
  ) => {
    const currentState: BattleSessionState = {
      ...battleStateRef.current,
      playerActiveIndex: pCardIdx,
      enemyActiveIndex: eCardIdx,
      playerActiveFighterId: battleStateRef.current.playerCards[pCardIdx]?.instanceId || null,
      enemyActiveFighterId: battleStateRef.current.enemyCards[eCardIdx]?.instanceId || null
    };

    const { nextState, clashResolution } = resolveRoundIntents(
      playerIntent,
      enemyIntent,
      currentState,
      isAr
    );

    const isBlocked = clashResolution.playerOutcome.isBlocked || clashResolution.enemyOutcome.isBlocked;
    const isCrit = clashResolution.playerOutcome.isCrit || clashResolution.enemyOutcome.isCrit;
    const isGuardBreak = clashResolution.clashType === 'GUARD_CRUSH' || clashResolution.bannerTitle?.includes('GUARD');
    const isCounter = clashResolution.clashType === 'PARRY_COUNTER' || clashResolution.bannerTitle?.includes('COUNTER');

    // 1. Play distinct sound effect for this action + Legendary custom audio system!
    playCombatActionSound(playerIntent.type.toLowerCase(), {
      card: battleStateRef.current.playerCards[pCardIdx],
      isBlocked,
      isCrit,
      isGuardBreak,
      volume: 1.0
    });

    // 2. High-Impact Freeze Frame & Screen Shake
    setImpactFlash(true);
    setTimeout(() => setImpactFlash(false), 60);
    setScreenShake(true);
    setTimeout(() => setScreenShake(false), isCrit || isGuardBreak ? 240 : 160);

    // Provide clashData to state immediately for clean 3-line action result display
    setBattleState(prev => ({
      ...prev,
      currentClashData: nextState.currentClashData || null
    }));

    // 3. Bars emerge after impact (350ms)
    setTimeout(() => {
      setClashAnimationStage('BARS_SHOW');
      setIsClashEffectApplied(true);
      setBattleState(nextState);
      battleStateRef.current = nextState;

      // Floating damage numbers
      if (clashResolution.playerOutcome.damage > 0) {
        setFloatingDamage({
          target: 'ENEMY',
          amount: clashResolution.playerOutcome.damage,
          isCrit: clashResolution.playerOutcome.isCrit
        });
      } else if (clashResolution.enemyOutcome.damage > 0) {
        setFloatingDamage({
          target: 'PLAYER',
          amount: clashResolution.enemyOutcome.damage,
          isCrit: clashResolution.enemyOutcome.isCrit
        });
      }

      // 4. Snappy hold static (1100ms instead of 3000ms for zero lag)
      setTimeout(() => {
        setFloatingDamage(null);
        setBigClashWord(null);
        setDramaticBanner(null);
        setClashAnimationStage('BARS_TUCK_STRAIGHTEN');

        // 5. Card straightens and bars tuck, then swipes away swiftly
        setTimeout(() => {
          setClashAnimationStage('SWIPE_AWAY');
          playBattleSound('FORMATION_SUMMON', 0.8);

          // Fast clean swipe transition (400ms instead of 1500ms):
          setTimeout(() => {
            setIsTableEmpty(true);
            setSelectedPlayerCardIndex(null);
            setLockedAction(null);
            setEnemySecretAction(null);
            setClashAnimationStage('IDLE');
            setPreClashPlayer(null);
            setPreClashEnemy(null);
            setIsClashEffectApplied(false);
            setKoStamp(null);

            const pDied = nextState.playerCards[pCardIdx]?.currentHp <= 0;
            const eDied = nextState.enemyCards[eCardIdx]?.currentHp <= 0;

            if (pDied || eDied) {
              playBattleSound('CARD_DEFEAT', 1.0);
              setKoStamp(pDied ? (isAr ? 'سقوط مقاتلك!' : 'FIGHTER DOWN!') : (isAr ? 'ضربة قاضية!' : 'K.O.!'));
              setScreenShake(true);
              setTimeout(() => setScreenShake(false), 350);
            }

            if (nextState.phase === 'VICTORY') {
              setBattleOutcome('VICTORY');
              return;
            }
            if (nextState.phase === 'DEFEAT') {
              setBattleOutcome('DEFEAT');
              return;
            }

            if (pDied && countAliveCards(nextState.playerCards) > 0) {
              setIsSelectingNextCard(true);
            } else {
              setIsSelectingNextCard(false);
            }

            if (eDied) {
              const surviving = nextState.enemyCards
                .map((c, i) => (!c.isDefeated && c.currentHp > 0 ? i : -1))
                .filter(i => i !== -1);
              setSelectedEnemyCardIndex(surviving.length > 0 ? surviving[0] : 0);
            }

          }, 1500);

        }, 450);

      }, 3000); // 3.0 SECONDS (base + 0.5s)

    }, 450);
  };

  // Outcome submission
  useEffect(() => {
    if (battleOutcome && !rewardOutcome && !isSubmittingResult) {
      setIsSubmittingResult(true);
      if (battleOutcome === 'VICTORY') {
        playBattleSound('VICTORY_FANFARE', 1.0);
      } else {
        playBattleSound('DEFEAT_CHORD', 0.9);
      }

      onComplete(battleOutcome)
        .then(res => {
          if (res) {
            setRewardOutcome({
              coinsAwarded: res.coinsAwarded || battle.rewardCoins,
              xpAwarded: res.xpAwarded || battle.rewardXp,
              isFirstClear: Boolean(res.isFirstClear)
            });
          }
        })
        .catch(err => console.warn('Outcome error:', err))
        .finally(() => setIsSubmittingResult(false));
    }
  }, [battleOutcome, rewardOutcome, isSubmittingResult, onComplete, battle]);



  // Battle consumable item use handler
  const handleUseBattleItem = async (item: UnifiedItemDefinition, targetCardIdx?: number) => {
    try {
      const cardIdx = (typeof targetCardIdx === 'number' && targetCardIdx >= 0 && targetCardIdx < battleState.playerCards.length)
        ? targetCardIdx
        : (inspectingCardIndex !== null && !battleState.playerCards[inspectingCardIndex]?.isDefeated
          ? inspectingCardIndex
          : (selectedPlayerCardIndex !== null && !battleState.playerCards[selectedPlayerCardIndex]?.isDefeated
            ? selectedPlayerCardIndex
            : battleState.playerCards.findIndex(c => !c.isDefeated && c.currentHp > 0)));

      if (cardIdx < 0) return;
      const targetCard = { ...battleState.playerCards[cardIdx] };
      if (!targetCard || targetCard.isDefeated) return;

      await useBattleItemInCombat(item.id);
      setUsedItemsInBattle(prev => ({
        ...prev,
        [item.id]: (prev[item.id] || 0) + 1
      }));

      const effect = item.battleEffect!;
      let toastText = '';

      if (effect.type === 'HEAL_HP') {
        const prevHp = targetCard.currentHp;
        targetCard.currentHp = Math.min(targetCard.maxHp, targetCard.currentHp + effect.value);
        toastText = isAr ? `+${targetCard.currentHp - prevHp} صحة مستعادة!` : `+${targetCard.currentHp - prevHp} HP Restored!`;
        playBattleSound('FORMATION_SUMMON', 1.0);
      } else if (effect.type === 'RESTORE_STAMINA') {
        const prevStm = targetCard.currentStamina ?? 100;
        targetCard.currentStamina = Math.min(targetCard.maxStamina || 100, prevStm + effect.value);
        targetCard.isExhausted = targetCard.currentStamina <= 0;
        toastText = isAr ? `+${targetCard.currentStamina - prevStm} جهد قتالي!` : `+${targetCard.currentStamina - prevStm} Stamina Recovered!`;
        playBattleSound('FORMATION_SUMMON', 1.0);
      } else if (effect.type === 'GRANT_SHIELD') {
        targetCard.shield = (targetCard.shield || 0) + effect.value;
        toastText = isAr ? `+${effect.value} درع حركي واقٍ!` : `+${effect.value} Kinetic Shield!`;
        playBattleSound('HEAVY_SLAM', 0.85);
      } else if (effect.type === 'BUFF_ATTACK') {
        targetCard.activeBuffs = {
          ...(targetCard.activeBuffs || { turnsRemaining: 0 }),
          heavyDamageMultiplier: 1 + (effect.value / 100),
          turnsRemaining: effect.durationTurns || 2
        };
        toastText = isAr ? `+${effect.value}% تعزيز هجومي (${effect.durationTurns || 2} جولات)!` : `+${effect.value}% Attack Buff (${effect.durationTurns || 2} Turns)!`;
        playBattleSound('VICTORY_FANFARE', 0.85);
      } else if (effect.type === 'BUFF_DEFENSE') {
        targetCard.activeBuffs = {
          ...(targetCard.activeBuffs || { turnsRemaining: 0 }),
          damageReduction: 1 - (effect.value / 100),
          turnsRemaining: effect.durationTurns || 2
        };
        toastText = isAr ? `+${effect.value}% تخفيض ضرر دفاعي (${effect.durationTurns || 2} جولات)!` : `+${effect.value}% Defense Boost (${effect.durationTurns || 2} Turns)!`;
        playBattleSound('FORMATION_SUMMON', 1.0);
      }

      setItemFeedbackToast({ text: toastText, color: 'text-emerald-300' });
      setTimeout(() => setItemFeedbackToast(null), 3000);

      // Update battle state
      const updated = [...battleState.playerCards];
      updated[cardIdx] = targetCard;
      setBattleState(prev => ({ ...prev, playerCards: updated }));
      battleStateRef.current = { ...battleStateRef.current, playerCards: updated };

      if (effect.consumesTurn) {
        setShowBattleItemsModal(false);
        handleActionFromInspector('DEFENSE', cardIdx);
      }
    } catch (err: any) {
      setItemFeedbackToast({ text: err.message || 'Error using item', color: 'text-rose-400' });
      setTimeout(() => setItemFeedbackToast(null), 3000);
    }
  };

  const playerStamina = playerActiveCard?.currentStamina ?? 100;
  const canAffordStrike = playerStamina >= ACTION_CONFIGS.STRIKE.staminaCost;
  const canAffordHeavy = playerStamina >= ACTION_CONFIGS.HEAVY.staminaCost;
  const canAffordDefend = true;
  const canAffordSkill = playerStamina >= (ACTION_CONFIGS.SKILL?.staminaCost || 30);

  return (
    <div 
      className={`fixed inset-0 z-50 flex flex-col justify-between bg-[#020709] text-white select-none overflow-hidden h-[100dvh] max-h-[100dvh] ${
        screenShake ? 'animate-combat-shake' : ''
      }`}
      dir={isAr ? 'rtl' : 'ltr'}
      style={{
        fontFamily: isAr ? "'Cairo', 'Readex Pro', sans-serif" : "'Outfit', 'Readex Pro', sans-serif"
      }}
    >
      {/* Background Atmosphere */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div 
          className="absolute inset-0 opacity-35"
          style={{
            background: 'radial-gradient(circle at 50% 50%, rgba(20, 184, 166, 0.2) 0%, rgba(6, 78, 59, 0.08) 45%, #020709 90%)'
          }}
        />
      </div>

      {/* Header */}
      <header className="relative z-20 px-2 xs:px-3 sm:px-6 py-0.5 sm:py-1 flex items-center justify-between border-b border-cyan-500/20 bg-slate-950/80 backdrop-blur-md shrink-0 shadow-lg">
        <div className="flex items-center gap-1.5 xs:gap-2 min-w-0">
          <span className="text-[11px] xs:text-xs sm:text-sm font-black tracking-wide text-white uppercase font-sans truncate max-w-[130px] xs:max-w-[180px] sm:max-w-none">
            {isAr && battle.nameAr ? battle.nameAr : (battle.enemyCommanderName || battle.name)}
          </span>
          <span className="text-[7px] xs:text-[8px] sm:text-[8.5px] font-mono font-black px-1.5 py-0.2 rounded-md bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 uppercase shrink-0">
            {battle.difficulty}
          </span>
        </div>

        <div className="flex items-center gap-1.5 xs:gap-2 shrink-0">
          {/* Battle Consumables Backpack Toggle */}
          <button
            type="button"
            onClick={() => setShowBattleItemsModal(true)}
            className="px-2 py-0.5 sm:py-1 rounded-xl bg-gradient-to-r from-amber-500/20 via-pink-500/20 to-teal-500/20 hover:from-amber-500/30 hover:to-teal-500/30 text-amber-200 hover:text-white transition-all border border-amber-400/40 text-[10px] xs:text-xs font-mono flex items-center gap-1.5 cursor-pointer shadow-[0_0_12px_rgba(245,158,11,0.25)] active:scale-95"
            title={isAr ? 'عناصر المعركة المستهلكة' : 'Battle Consumables'}
          >
            <Backpack size={12.5} className="text-amber-400 animate-pulse shrink-0" />
            <span className="hidden xs:inline">{isAr ? 'العناصر' : 'Items'}</span>
            {battleConsumablesCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-amber-400 text-slate-950 font-bold text-[8.5px] leading-tight">
                {battleConsumablesCount}
              </span>
            )}
          </button>

          {/* Combat Log Drawer Toggle */}
          <button
            type="button"
            onClick={() => setShowLogDrawer(!showLogDrawer)}
            className="px-1.5 xs:px-2 py-0.5 sm:py-1 rounded-xl bg-white/5 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-200 transition-all border border-white/10 text-[10px] xs:text-xs font-mono flex items-center gap-1 cursor-pointer"
            title={isAr ? 'سجل المعركة' : 'Combat Log'}
          >
            <ScrollText size={12} className="shrink-0" />
            <span className="hidden sm:inline">{isAr ? 'السجل' : 'Log'}</span>
          </button>

          <button
            type="button"
            onClick={handleExit}
            className="p-1 rounded-xl bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 transition-all border border-white/10 hover:border-rose-500/40 cursor-pointer"
            title={isAr ? 'مغادرة' : 'Exit'}
          >
            <X size={14} />
          </button>
        </div>
      </header>

      {/* 3D ENEMY DUEL RACK (TOP ROW - MOVED DOWN WITH BALANCED SPACING) */}
      <div className="w-full shrink-0 z-20 pt-2 xs:pt-2.5 sm:pt-3.5 px-1 sm:px-3">
        <EnemyDuelRack cards={battleState.enemyCards} isAr={isAr} />
      </div>

      {/* THE BATTLE TABLE (CENTER ARENA MAT POWERED BY BattleActiveZone) */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-1.5 xs:px-2 sm:px-4 w-full min-h-0 py-0.5 overflow-visible">
        
        {/* Full-screen impact flash on hitstop */}
        <AnimatePresence>
          {impactFlash && (
            <motion.div
              initial={{ opacity: 0.85 }}
              animate={{ opacity: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.1, ease: 'easeOut' }}
              className="fixed inset-0 z-45 bg-white pointer-events-none mix-blend-screen"
            />
          )}
        </AnimatePresence>

        <BattleActiveZone
          playerCard={playerActiveCard}
          enemyCard={enemyActiveCard}
          turnNumber={battleState.turnNumber}
          clashData={battleState.currentClashData || null}
          playerChosenAction={lockedAction}
          enemyRevealedAction={enemySecretAction?.type || null}
          isTableEmpty={isTableEmpty}
          clashAnimationStage={clashAnimationStage}
          tableSlamImpact={tableSlamImpact}
          isCardSlamming={isCardSlamming}
          bigClashWord={bigClashWord}
          floatingDamage={floatingDamage}
          isSelectingNextCard={isSelectingNextCard}
          isAr={isAr}
          playerPreClash={preClashPlayer}
          enemyPreClash={preClashEnemy}
          isClashEffectApplied={isClashEffectApplied}
          isEnemyCardFlipping={isEnemyCardFlipping}
          dramaticBanner={dramaticBanner}
          isHitstop={impactFlash}
          koStamp={koStamp}
        />
      </main>

      {/* 3D PLAYER DUEL DISK TRAY (BOTTOM ROW) */}
      <footer className="relative z-20 flex flex-col items-center justify-center py-0.5 shrink-0 pb-1 sm:pb-2 px-2 w-full">
        <div className="w-full flex items-center justify-between px-2 sm:px-4 max-w-xl mx-auto mb-1">
          {/* Simple Prominent Battle Consumables Button */}
          <motion.button
            whileHover={{ scale: 1.06, y: -2 }}
            whileTap={{ scale: 0.94 }}
            type="button"
            onClick={() => {
              playBattleSound('TACTICAL_SELECT', 1.0);
              setShowBattleItemsModal(true);
            }}
            className="px-3.5 sm:px-4 py-1 sm:py-1.5 rounded-2xl bg-gradient-to-r from-teal-950/95 via-[#032328]/95 to-amber-950/95 hover:from-teal-900 hover:to-amber-900 text-amber-200 hover:text-white border-2 border-[#5eead4]/60 text-xs font-mono font-black flex items-center gap-2.5 shadow-[0_0_22px_rgba(94,234,212,0.45)] cursor-pointer backdrop-blur-xl transition-all active:scale-95 group"
            title={isAr ? 'عناصر المعركة المستهلكة (4 خانات)' : 'Battle Consumables Loadout (4 Places)'}
          >
            <div className="w-5 h-5 rounded-lg bg-[#5eead4]/20 border border-[#5eead4]/60 flex items-center justify-center text-[#5eead4] group-hover:scale-110 transition-transform">
              <Backpack size={13} className="animate-pulse" />
            </div>
            <span className="tracking-wide">{isAr ? 'العناصر القتالية' : 'CONSUMABLES'}</span>
            <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-[#5eead4] to-amber-300 text-slate-950 font-black text-[9.5px] leading-tight shadow-sm">
              4
            </span>
          </motion.button>

          {isSelectingNextCard && (
            <div className="text-center">
              <span className="text-[10px] sm:text-xs font-mono font-black text-[#5eead4] animate-pulse drop-shadow">
                {isAr ? '⚡ اضغط على بطاقة لنشر مقاتلك القادم' : '⚡ TAP A CARD TO DEPLOY NEXT'}
              </span>
            </div>
          )}
        </div>

        <DuelHandRack
          cards={battleState.playerCards}
          selectedCardIndex={selectedPlayerCardIndex}
          inspectingCardIndex={inspectingCardIndex}
          isTableEmpty={isTableEmpty}
          isSelectingNextCard={isSelectingNextCard}
          isAr={isAr}
          onCardSelect={handleCardClick}
          canInteract={clashAnimationStage !== 'LUNGE_CLASH' && clashAnimationStage !== 'IMPACT_BURST'}
        />
      </footer>

      {/* 3 2 1 FIGHT ANIMATED COUNTDOWN OVERLAY */}
      <AnimatePresence>
        {countdownText && (
          <motion.div
            key={countdownText}
            initial={{ scale: 0.2, opacity: 0 }}
            animate={{ scale: [0.2, 1.4, 1.0], opacity: 1 }}
            exit={{ scale: 2.2, opacity: 0 }}
            transition={{ duration: 0.45, ease: 'easeOut' }}
            className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none select-none"
          >
            <div className="flex flex-col items-center justify-center">
              {countdownText === 'FIGHT' ? (
                <span className="text-6xl sm:text-8xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-rose-400 to-yellow-300 drop-shadow-[0_0_60px_rgba(244,63,94,1)] tracking-widest uppercase italic">
                  {isAr ? 'ابدأ القتال!' : 'FIGHT!'}
                </span>
              ) : (
                <span className="text-7xl sm:text-9xl md:text-[11rem] font-black text-transparent bg-clip-text bg-gradient-to-b from-[#5eead4] via-teal-300 to-cyan-500 drop-shadow-[0_0_50px_rgba(94,234,212,1)] font-mono">
                  {countdownText}
                </span>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* COMBAT EVENT LOG DRAWER */}
      <AnimatePresence>
        {showLogDrawer && (
          <motion.div
            initial={{ opacity: 0, x: isAr ? -320 : 320 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: isAr ? -320 : 320 }}
            className={`fixed top-0 bottom-0 ${isAr ? 'left-0' : 'right-0'} z-50 w-full max-w-sm bg-slate-950/95 border-l border-cyan-500/30 backdrop-blur-2xl p-4 flex flex-col shadow-2xl`}
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
              <span className="text-xs font-mono font-black text-[#5eead4] uppercase tracking-wider flex items-center gap-1.5">
                <ScrollText size={14} />
                <span>{isAr ? 'سجل المعركة التكتيكي' : 'TACTICAL COMBAT LOG'}</span>
              </span>
              <button
                type="button"
                onClick={() => setShowLogDrawer(false)}
                className="p-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400"
              >
                <X size={15} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 font-mono text-[11px]">
              {battleState.logs.length === 0 ? (
                <p className="text-slate-500 text-center my-auto">
                  {isAr ? 'لا توجد أحداث حتى الآن.' : 'No events logged yet.'}
                </p>
              ) : (
                battleState.logs.map(log => (
                  <div key={log.id} className="p-2.5 rounded-xl bg-white/[0.03] border border-white/5 space-y-1">
                    <div className="flex items-center justify-between text-[9px] text-slate-400">
                      <span className="text-amber-300 font-bold">TURN {String(log.turnNumber).padStart(2, '0')}</span>
                      <span>{log.timestamp}</span>
                    </div>
                    <pre className="text-slate-200 whitespace-pre-wrap font-sans text-xs leading-relaxed">
                      {isAr && log.descriptionAr ? log.descriptionAr : log.description}
                    </pre>
                  </div>
                ))
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* VICTORY & DEFEAT OVERLAYS */}
      <AnimatePresence>
        {battleOutcome === 'VICTORY' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 text-center"
          >
            <motion.div 
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="bg-gradient-to-b from-slate-900 via-slate-950 to-black border border-cyan-500/60 rounded-3xl p-6 sm:p-8 max-w-sm w-full shadow-[0_0_50px_rgba(6,182,212,0.4)] ring-2 ring-cyan-500/20"
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-400 to-teal-500 text-slate-950 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-cyan-500/40">
                <Crown size={32} />
              </div>
              <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-white to-teal-300 uppercase mb-1 font-sans">
                {isAr ? 'نصر ساحق!' : 'VICTORY!'}
              </h2>
              <p className="text-xs text-cyan-200/80 mb-5 font-mono">
                +{rewardOutcome?.coinsAwarded ?? battle.rewardCoins} Coins · +{rewardOutcome?.xpAwarded ?? battle.rewardXp} EXP
              </p>
              <button
                type="button"
                onClick={handleExit}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-400 hover:brightness-110 text-slate-950 font-black text-xs uppercase cursor-pointer shadow-lg shadow-cyan-500/30 tracking-wider"
              >
                {isAr ? 'متابعة' : 'CONTINUE'}
              </button>
            </motion.div>
          </motion.div>
        )}

        {battleOutcome === 'DEFEAT' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 text-center"
          >
            <motion.div 
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="bg-gradient-to-b from-slate-900 via-slate-950 to-black border border-rose-500/60 rounded-3xl p-6 sm:p-8 max-w-sm w-full shadow-[0_0_50px_rgba(244,63,94,0.3)] ring-2 ring-rose-500/20"
            >
              <div className="w-14 h-14 rounded-2xl bg-rose-950 border border-rose-500 text-rose-400 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-rose-950/60">
                <Skull size={32} />
              </div>
              <h2 className="text-2xl font-black text-rose-400 uppercase mb-4 font-sans">
                {isAr ? 'هزيمة' : 'DEFEATED'}
              </h2>
              <button
                type="button"
                onClick={handleExit}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:brightness-110 text-white font-black text-xs uppercase cursor-pointer shadow-lg shadow-rose-950/60 tracking-wider"
              >
                {isAr ? 'مغادرة' : 'LEAVE'}
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* CARD ACTION INSPECTOR (POPPED OUT CLOSER TO SCREEN + BARS FROM BEHIND + SLOW BUTTONS + SMOOTH RETURN) */}
      {inspectingCardIndex !== null && battleState.playerCards[inspectingCardIndex] && (
        <CardActionInspector
          card={battleState.playerCards[inspectingCardIndex]}
          cardIndex={inspectingCardIndex}
          origin={inspectingCardOrigin}
          isOpen={inspectingCardIndex !== null}
          onClose={() => {
            setInspectingCardIndex(null);
            setInspectingCardOrigin(null);
          }}
          onSelectAction={handleActionFromInspector}
          isAr={isAr}
        />
      )}

      {/* 3D FLOATING 4-PLACES CONSUMABLE ITEMS PANEL (CARDS PULLING 3D TILT & ANIMATION) */}
      <BattleConsumablesFloatingPanel
        isOpen={showBattleItemsModal}
        onClose={() => setShowBattleItemsModal(false)}
        activeDeck={activeDeck}
        playerCards={battleState.playerCards}
        onUseItem={handleUseBattleItem}
        usedItemsInBattle={usedItemsInBattle}
        activePlayerHp={playerActiveCard ? playerActiveCard.currentHp : (battleState.playerCards[0]?.currentHp || 100)}
        activePlayerMaxHp={playerActiveCard ? playerActiveCard.maxHp : (battleState.playerCards[0]?.maxHp || 100)}
        activePlayerStamina={playerActiveCard ? (playerActiveCard.currentStamina ?? 100) : (battleState.playerCards[0]?.currentStamina ?? 100)}
        activePlayerMaxStamina={playerActiveCard ? (playerActiveCard.maxStamina || 100) : 100}
        isAr={isAr}
      />

      {/* Item Usage Feedback Toast */}
      <AnimatePresence>
        {itemFeedbackToast && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -15, scale: 0.9 }}
            className="fixed top-14 inset-x-0 z-50 flex items-center justify-center pointer-events-none px-4"
          >
            <div className="px-4 py-2 rounded-2xl bg-slate-950/95 border border-cyan-400/60 shadow-[0_0_25px_rgba(94,234,212,0.5)] backdrop-blur-xl flex items-center gap-2">
              <Sparkles size={14} className="text-cyan-400 animate-spin" />
              <span className={`text-xs font-mono font-black ${itemFeedbackToast.color}`}>
                {itemFeedbackToast.text}
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};
