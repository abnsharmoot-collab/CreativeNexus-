import React, { useState, useRef, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { StoryBattleDefinition, BattleDifficulty } from '../../types/story';
import { CollectibleCardData } from '../../types/cards';
import { 
  Lock, Check, Swords, Coins, Trophy, Sparkles, X, 
  ChevronRight, ChevronLeft, Skull, Crown, Settings2, Flame, Shield
} from 'lucide-react';

interface CinematicStoryMapProps {
  battles: StoryBattleDefinition[];
  isBattleUnlocked: (battleId: string) => boolean;
  isBattleCompleted: (battleId: string) => boolean;
  hasClaimedFirstClear: (battleId: string) => boolean;
  getEnemyCards: (cardIds: string[]) => CollectibleCardData[];
  onStartBattle: (battle: StoryBattleDefinition) => void;
  isAr: boolean;
  isOwner?: boolean;
  onEditBattle?: (battle: StoryBattleDefinition) => void;
  onQuickUpdateFightType?: (battle: StoryBattleDefinition, fightType: 'NORMAL' | 'BOSS' | 'CHAPTER_FINALE') => void;
  accentColor?: string;
  selectedBattleId?: string | null;
  onSelectBattle?: (battleId: string) => void;
}

export const CinematicStoryMap: React.FC<CinematicStoryMapProps> = ({
  battles,
  isBattleUnlocked,
  isBattleCompleted,
  hasClaimedFirstClear,
  getEnemyCards,
  onStartBattle,
  isAr,
  isOwner = false,
  onEditBattle,
  onQuickUpdateFightType,
  accentColor = '#2dd4bf',
  selectedBattleId,
  onSelectBattle
}) => {
  const nodeRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const [pathD, setPathD] = useState<string>('');
  const [nodeCenters, setNodeCenters] = useState<{ id: string; x: number; y: number }[]>([]);
  const [spotlightPos, setSpotlightPos] = useState<{ xPercent: number; yPercent: number }>({ xPercent: 50, yPercent: 20 });

  // Strictly 4 battle nodes in the vertical alternating journey
  const displayBattles = useMemo(() => battles.slice(0, 4), [battles]);

  // Determine completion count across these 4 nodes
  const completedCount = useMemo(() => {
    return displayBattles.filter(b => isBattleCompleted(b.id)).length;
  }, [displayBattles, isBattleCompleted]);

  // Determine the newest unlocked battle in this chapter (furthest active progression node)
  const newestUnlockedBattle = useMemo(() => {
    const unlockedList = displayBattles.filter((b, idx) => {
      const isPrevWon = idx === 0 || (displayBattles[idx - 1] && isBattleCompleted(displayBattles[idx - 1].id));
      return (idx === 0 || isPrevWon) && isBattleUnlocked(b.id);
    });
    if (unlockedList.length === 0) return displayBattles[0] || null;

    // Prefer the latest unlocked battle that is NOT completed yet
    const uncompleted = unlockedList.filter(b => !isBattleCompleted(b.id));
    if (uncompleted.length > 0) {
      return uncompleted[uncompleted.length - 1];
    }
    // If all unlocked in this chapter are completed, pick the final unlocked one
    return unlockedList[unlockedList.length - 1];
  }, [displayBattles, isBattleUnlocked, isBattleCompleted]);

  // Internal selection fallback synced with prop
  const [internalActiveBattleId, setInternalActiveBattleId] = useState<string | null>(null);

  // Active battle is either explicitly selected, or defaults to the newest unlocked fight
  const activeBattleId = (selectedBattleId && displayBattles.some(b => b.id === selectedBattleId))
    ? selectedBattleId
    : (internalActiveBattleId && displayBattles.some(b => b.id === internalActiveBattleId))
    ? internalActiveBattleId
    : (newestUnlockedBattle?.id || displayBattles[0]?.id || null);

  const handleSelectFight = (battleId: string) => {
    setInternalActiveBattleId(battleId);
    if (onSelectBattle) {
      onSelectBattle(battleId);
    }
  };

  // Sync to the newest unlocked fight automatically on mount / battle change
  useEffect(() => {
    if (newestUnlockedBattle && (!internalActiveBattleId || !displayBattles.some(b => b.id === internalActiveBattleId))) {
      setInternalActiveBattleId(newestUnlockedBattle.id);
      if (onSelectBattle && !selectedBattleId) {
        onSelectBattle(newestUnlockedBattle.id);
      }
    }
  }, [newestUnlockedBattle?.id, displayBattles]);

  // Calculate dynamic SVG path and node anchor points
  useEffect(() => {
    const updatePath = () => {
      if (!mapContainerRef.current) return;
      const containerRect = mapContainerRef.current.getBoundingClientRect();
      const points: { id: string; x: number; y: number }[] = [];

      displayBattles.forEach(battle => {
        const el = nodeRefs.current[battle.id];
        if (el) {
          const rect = el.getBoundingClientRect();
          points.push({
            id: battle.id,
            x: rect.left + rect.width / 2 - containerRect.left,
            y: rect.top + rect.height / 2 - containerRect.top
          });
        }
      });

      setNodeCenters(points);

      if (points.length < 2) return;

      // Construct smooth S-curve connecting all 4 alternating nodes
      let d = `M ${points[0].x} ${points[0].y}`;
      for (let i = 0; i < points.length - 1; i++) {
        const p0 = points[i];
        const p1 = points[i + 1];
        const midY = (p0.y + p1.y) / 2;
        d += ` C ${p0.x} ${midY}, ${p1.x} ${midY}, ${p1.x} ${p1.y}`;
      }
      setPathD(d);

      // Update spotlight position for Fog of War radial mask
      const currentActive = points.find(p => p.id === activeBattleId) || points[0];
      if (currentActive && containerRect.width > 0 && containerRect.height > 0) {
        setSpotlightPos({
          xPercent: (currentActive.x / containerRect.width) * 100,
          yPercent: (currentActive.y / containerRect.height) * 100
        });
      }
    };

    updatePath();
    const handleResize = () => updatePath();
    window.addEventListener('resize', handleResize);
    const timer = setTimeout(updatePath, 250);

    return () => {
      window.removeEventListener('resize', handleResize);
      clearTimeout(timer);
    };
  }, [displayBattles, activeBattleId]);

  const handleNodeClick = (battle: StoryBattleDefinition, index: number) => {
    const isPreviousWon = index === 0 || (displayBattles[index - 1] && isBattleCompleted(displayBattles[index - 1].id));
    const unlocked = (index === 0 || isPreviousWon) && isBattleUnlocked(battle.id);
    if (!unlocked) return; // Locked node cannot be selected

    if (activeBattleId === battle.id) {
      // Direct fight launch on second click
      onStartBattle(battle);
      return;
    }

    handleSelectFight(battle.id);

    // Smooth camera movement towards node
    const el = nodeRefs.current[battle.id];
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // Calculate drawing stroke progression:
  // 0 completed -> 12% drawn towards node 1
  // 1 completed -> ~38% drawn
  // 2 completed -> ~70% drawn
  // 3 completed -> 100% drawn
  // 4 completed -> 100% fully conquered
  const pathDrawnPercent = Math.min(100, Math.max(12, (completedCount / 3) * 100));

  return (
    <div 
      ref={mapContainerRef}
      className="relative w-full max-w-4xl mx-auto py-12 sm:py-20 select-none overflow-hidden rounded-3xl"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* ========================================================================= */}
      {/* 1. FOG OF WAR RADIAL GRADIENT MASK                                        */}
      {/* Creates depth, shrouding locked nodes until the player approaches         */}
      {/* ========================================================================= */}
      <div 
        className="absolute inset-0 pointer-events-none z-15 transition-all duration-700 ease-out"
        style={{
          background: `radial-gradient(circle 560px at ${spotlightPos.xPercent}% ${spotlightPos.yPercent}%, transparent 15%, rgba(2, 8, 10, 0.45) 55%, rgba(1, 4, 5, 0.88) 80%, rgba(1, 4, 5, 0.98) 100%)`
        }}
      />

      {/* Subtle Ambient Fog Drift Layers */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-25 z-10 mix-blend-screen bg-repeat"
        style={{
          backgroundImage: 'radial-gradient(rgba(45, 212, 191, 0.08) 1px, transparent 1px)',
          backgroundSize: '28px 28px'
        }}
      />

      {/* ========================================================================= */}
      {/* 2. CONTINUOUS SVG PATH WITH ANIMATED STROKE-DASHOFFSET                    */}
      {/* Visually connects 4 battle nodes as an animated continuous journey path   */}
      {/* ========================================================================= */}
      {pathD && (
        <svg 
          className="absolute inset-0 w-full h-full pointer-events-none z-5"
          style={{ overflow: 'visible' }}
        >
          <defs>
            {/* Luminous Neon Gradient */}
            <linearGradient id="journeyGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#2dd4bf" stopOpacity="0.9" />
              <stop offset="50%" stopColor="#f59e0b" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#a855f7" stopOpacity="0.9" />
            </linearGradient>

            {/* Glowing filter */}
            <filter id="pathGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Layer A: Ghost Blueprint Guide Track (Faint, showing the full journey) */}
          <path
            d={pathD}
            stroke="rgba(255, 255, 255, 0.08)"
            strokeWidth="3"
            strokeDasharray="6 8"
            fill="none"
            strokeLinecap="round"
          />

          {/* Layer B: Ambient Halo Glow along the path */}
          <path
            d={pathD}
            stroke="rgba(45, 212, 191, 0.12)"
            strokeWidth="16"
            fill="none"
            strokeLinecap="round"
            filter="url(#pathGlow)"
          />

          {/* Layer C: Active Progression Line (Drawn dynamically via stroke-dashoffset) */}
          <path
            d={pathD}
            pathLength="1000"
            stroke="url(#journeyGradient)"
            strokeWidth="4"
            fill="none"
            strokeLinecap="round"
            strokeDasharray="1000"
            strokeDashoffset={1000 * (1 - pathDrawnPercent / 100)}
            className="transition-all duration-1000 ease-out"
          />

          {/* Layer D: Animated Flowing Energy Dashes along the drawn path */}
          <path
            d={pathD}
            pathLength="1000"
            stroke="#ffffff"
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
            strokeDasharray="10 24"
            strokeDashoffset="0"
            className="opacity-75"
            style={{
              animation: 'flowingEnergy 2.8s linear infinite'
            }}
          />

          {/* Layer E: Traveling Energy Pulse along the SVG path */}
          <circle r="5" fill="#5eead4" filter="url(#pathGlow)">
            <animateMotion
              path={pathD}
              dur="4.5s"
              repeatCount="indefinite"
              rotate="auto"
            />
          </circle>

          {/* Layer F: Circular Anchor Seals at each Node coordinate */}
          {nodeCenters.map((pt, idx) => {
            const isCompleted = isBattleCompleted(pt.id);
            const isActive = activeBattleId === pt.id;
            const isUnlocked = isBattleUnlocked(pt.id);

            return (
              <g key={pt.id} transform={`translate(${pt.x}, ${pt.y})`}>
                {/* Outer pulsing ring for active node */}
                {isActive && (
                  <circle
                    r="16"
                    fill="none"
                    stroke="#5eead4"
                    strokeWidth="1.5"
                    className="animate-ping opacity-35"
                  />
                )}
                {/* Mid ring */}
                <circle
                  r="9"
                  fill="#031114"
                  stroke={isCompleted ? '#10b981' : isActive ? '#5eead4' : isUnlocked ? '#f59e0b' : '#334155'}
                  strokeWidth="2"
                />
                {/* Inner center dot */}
                <circle
                  r="4"
                  fill={isCompleted ? '#10b981' : isActive ? '#5eead4' : isUnlocked ? '#f59e0b' : '#1e293b'}
                />
              </g>
            );
          })}
        </svg>
      )}

      {/* Embedded CSS Keyframes for animated stroke dashoffset flow */}
      <style>{`
        @keyframes flowingEnergy {
          from {
            stroke-dashoffset: 100;
          }
          to {
            stroke-dashoffset: 0;
          }
        }
      `}</style>

      {/* ========================================================================= */}
      {/* 3. 4 BATTLE NODES IN ALTERNATING VERTICAL FORMATION                       */}
      {/* Node 1 -> right, Node 2 -> left, Node 3 -> right, Node 4 -> left         */}
      {/* ========================================================================= */}
      <div className="space-y-24 sm:space-y-36 relative z-20">
        {displayBattles.map((battle, index) => {
          const isPreviousWon = index === 0 || (displayBattles[index - 1] && isBattleCompleted(displayBattles[index - 1].id));
          const unlocked = (index === 0 || isPreviousWon) && isBattleUnlocked(battle.id);
          const completed = isBattleCompleted(battle.id);
          const isActive = activeBattleId === battle.id;
          const claimedFirstClear = hasClaimedFirstClear(battle.id);
          const enemyCards = getEnemyCards(battle.enemyDeckCardIds);

          // Resolve fight classification:
          // Normal fight vs Boss fight vs Chapter Finale
          const fightType: 'NORMAL' | 'BOSS' | 'CHAPTER_FINALE' = 
            battle.fightType || 
            (battle.difficulty === 'CHAPTER_FINALE' || battle.isChapterFinale ? 'CHAPTER_FINALE' : battle.difficulty === 'BOSS' ? 'BOSS' : 'NORMAL');
          
          const isBoss = fightType === 'BOSS';
          const isFinale = fightType === 'CHAPTER_FINALE';

          // Alternating horizontal alignment:
          // Node 1 (index 0) -> right
          // Node 2 (index 1) -> left
          // Node 3 (index 2) -> right
          // Node 4 (index 3) -> left
          const isRight = index % 2 === 0;

          const alignmentClass = isRight
            ? 'flex justify-end pr-2 sm:pr-8 md:pr-12'
            : 'flex justify-start pl-2 sm:pl-8 md:pl-12';

          // Fight classification specific styling
          const classificationBorder = isFinale
            ? 'border-amber-400/80 shadow-[0_0_40px_rgba(245,158,11,0.35)]'
            : isBoss
            ? 'border-rose-500/80 shadow-[0_0_40px_rgba(244,63,94,0.3)]'
            : 'border-[#5eead4]/60 shadow-[0_0_30px_rgba(45,212,191,0.2)]';

          const classificationBg = isFinale
            ? 'bg-gradient-to-b from-[#1c1404] via-[#0d0901] to-[#01080a]'
            : isBoss
            ? 'bg-gradient-to-b from-[#1f060a] via-[#100305] to-[#01080a]'
            : 'bg-gradient-to-b from-[#061e22] via-[#031316] to-[#01090a]';

          return (
            <div 
              key={battle.id}
              ref={el => { nodeRefs.current[battle.id] = el; }}
              className={`w-full ${alignmentClass}`}
            >
              {/* Node Container */}
              <motion.div
                layout
                onClick={() => handleNodeClick(battle, index)}
                className={`relative transition-all duration-500 rounded-3xl overflow-hidden ${
                  !unlocked
                    ? 'w-72 sm:w-80 md:w-88 bg-[#020507]/90 border border-white/5 cursor-not-allowed opacity-60 shadow-none'
                    : isActive
                    ? `w-full max-w-lg sm:max-w-xl ${classificationBg} border-2 ${classificationBorder}`
                    : completed
                    ? 'w-72 sm:w-80 md:w-88 bg-gradient-to-b from-[#031718] via-[#021012] to-black border border-teal-500/30 hover:border-teal-400 cursor-pointer shadow-lg'
                    : `w-72 sm:w-80 md:w-88 ${classificationBg} border ${classificationBorder} cursor-pointer`
                }`}
                whileHover={unlocked && !isActive ? { scale: 1.025 } : {}}
              >
                {/* Subtle Ambient Vignette & Commander Art Background (if not locked) */}
                {unlocked && battle.enemyCommanderAvatar && (
                  <div 
                    className="absolute inset-0 bg-cover bg-center opacity-15 mix-blend-luminosity pointer-events-none transition-opacity duration-500 group-hover:opacity-25"
                    style={{ backgroundImage: `url(${battle.enemyCommanderAvatar})` }}
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/70 to-transparent pointer-events-none" />

                {/* ================================================================= */}
                {/* LOCKED STATE: Clean, Dark with ONLY the word "Locked"            */}
                {/* User Prompt: "And the locked story parts should be dark with     */}
                {/* the word locked not anything else"                               */}
                {/* ================================================================= */}
                {!unlocked ? (
                  <div className="p-8 sm:p-10 flex flex-col items-center justify-center text-center min-h-[190px] relative z-10">
                    <div className="w-10 h-10 rounded-2xl bg-white/[0.03] border border-white/5 flex items-center justify-center text-slate-600 mb-3">
                      <Lock size={16} />
                    </div>
                    <span className="font-mono text-xs tracking-widest uppercase font-bold text-slate-500">
                      {isAr ? 'مغلق' : 'LOCKED'}
                    </span>
                  </div>
                ) : (
                  /* =============================================================== */
                  /* UNLOCKED / COMPLETED / ACTIVE STATE                             */
                  /* =============================================================== */
                  <div className="relative z-10 p-5 sm:p-6 flex flex-col justify-between min-h-[190px]">
                    {/* Top Row: Number, Classification Badges & Status */}
                    <div>
                      <div className="flex items-center justify-between gap-3 mb-2 flex-wrap">
                        {/* Step Number + Fight Type Badge */}
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-mono tracking-widest font-black text-slate-400">
                            {String(index + 1).padStart(2, '0')}
                          </span>

                          {/* Fight Classification Badge */}
                          {isFinale ? (
                            <span className="inline-flex items-center gap-1 text-[10px] font-mono font-black uppercase tracking-wider text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/40">
                              <Crown size={12} className="text-amber-400" />
                              <span>{isAr ? 'المعركة الختامية' : 'FINAL FIGHT'}</span>
                            </span>
                          ) : isBoss ? (
                            <span className="inline-flex items-center gap-1 text-[10px] font-mono font-black uppercase tracking-wider text-rose-300 bg-rose-500/20 px-2 py-0.5 rounded-full border border-rose-500/40">
                              <Skull size={12} className="text-rose-400" />
                              <span>{isAr ? 'نزال زعيم' : 'BOSS FIGHT'}</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[10px] font-mono tracking-wider text-teal-300 bg-teal-500/15 px-2 py-0.5 rounded-full border border-teal-500/30">
                              <Swords size={11} className="text-[#5eead4]" />
                              <span>{isAr ? 'معركة' : 'FIGHT'}</span>
                            </span>
                          )}
                        </div>

                        {/* Status Confirmation */}
                        {completed ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold text-emerald-400">
                            <Check size={13} className="text-emerald-400" />
                            <span>{isAr ? 'مكتمل' : 'COMPLETED'}</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 text-[10px] font-mono tracking-wider font-bold text-[#5eead4]">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#5eead4] animate-ping" />
                            <span>{isAr ? 'متاح للنزال' : 'AVAILABLE'}</span>
                          </span>
                        )}
                      </div>

                      {/* Battle Name */}
                      <h3 className="text-xl sm:text-2xl font-black text-white font-sans tracking-tight">
                        {isAr ? battle.nameAr || battle.name : battle.name}
                      </h3>

                      {/* Commander / Character Name */}
                      <p className="text-xs font-mono text-slate-400 mt-0.5">
                        {isAr 
                          ? battle.customCharacterNameAr || battle.enemyCommanderNameAr || battle.enemyCommanderName 
                          : battle.customCharacterName || battle.enemyCommanderName}
                      </p>
                    </div>

                    {/* ============================================================= */}
                    {/* OWNER QUICK FIGHT-TYPE TOGGLE BAR                            */}
                    {/* User Prompt: "make the owner have the ability to choose        */}
                    {/* weather the next fight be a boss fight or a normal fight or   */}
                    {/* even the final fight of the chapter"                          */}
                    {/* ============================================================= */}
                    {isOwner && onQuickUpdateFightType && (
                      <div 
                        className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between gap-2 flex-wrap"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <span className="text-[10px] font-mono text-amber-300 font-bold flex items-center gap-1">
                          <Crown size={12} />
                          <span>{isAr ? 'نوع النزال:' : 'Fight Type:'}</span>
                        </span>

                        <div className="flex items-center gap-1.5">
                          {/* 1. Normal Fight */}
                          <button
                            type="button"
                            onClick={() => onQuickUpdateFightType(battle, 'NORMAL')}
                            className={`px-2 py-1 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer flex items-center gap-1 ${
                              fightType === 'NORMAL'
                                ? 'bg-teal-500 text-black shadow-md'
                                : 'bg-white/5 hover:bg-white/10 text-slate-400 border border-white/10'
                            }`}
                          >
                            <Swords size={11} />
                            <span>{isAr ? 'عادية' : 'Normal'}</span>
                          </button>

                          {/* 2. Boss Fight */}
                          <button
                            type="button"
                            onClick={() => onQuickUpdateFightType(battle, 'BOSS')}
                            className={`px-2 py-1 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer flex items-center gap-1 ${
                              fightType === 'BOSS'
                                ? 'bg-rose-500 text-white shadow-md shadow-rose-500/30'
                                : 'bg-white/5 hover:bg-white/10 text-slate-400 border border-white/10'
                            }`}
                          >
                            <Skull size={11} />
                            <span>{isAr ? 'زعيم' : 'Boss'}</span>
                          </button>

                          {/* 3. Final Fight of Chapter */}
                          <button
                            type="button"
                            onClick={() => onQuickUpdateFightType(battle, 'CHAPTER_FINALE')}
                            className={`px-2 py-1 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer flex items-center gap-1 ${
                              fightType === 'CHAPTER_FINALE'
                                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-black shadow-md shadow-amber-500/40'
                                : 'bg-white/5 hover:bg-white/10 text-slate-400 border border-white/10'
                            }`}
                          >
                            <Crown size={11} />
                            <span>{isAr ? 'ختامية' : 'Finale'}</span>
                          </button>

                          {/* Edit Full Battle Details */}
                          {onEditBattle && (
                            <button
                              type="button"
                              onClick={() => onEditBattle(battle)}
                              className="p-1 rounded-lg bg-white/5 hover:bg-white/15 text-slate-300 border border-white/10 transition-colors"
                              title={isAr ? 'تعديل المعركة' : 'Edit Battle'}
                            >
                              <Settings2 size={12} />
                            </button>
                          )}
                        </div>
                      </div>
                    )}

                    {/* ============================================================= */}
                    {/* IN-PLACE EXPANDED LOCATION DETAILS (When Active/Selected)    */}
                    {/* ============================================================= */}
                    <AnimatePresence>
                      {isActive && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.35, ease: 'easeInOut' }}
                          className="pt-4 mt-3 border-t border-white/10 space-y-4"
                        >
                          {/* Story Lore / Description */}
                          <p className="text-xs text-slate-300 leading-relaxed font-sans">
                            {isAr ? battle.descriptionAr || battle.description : battle.description}
                          </p>

                          {/* Pre-Clash Dialogue Quote if available */}
                          {battle.introText && (
                            <p className="text-[11px] font-mono italic text-amber-200/80 border-l-2 border-amber-400/50 pl-2.5 py-0.5" dir={isAr ? 'rtl' : 'ltr'}>
                              {isAr ? battle.introTextAr || battle.introText : battle.introText}
                            </p>
                          )}

                          {/* Hostile Lineup Miniature Cards */}
                          <div className="space-y-1.5">
                            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
                              {isAr ? 'تشكيل الخصم:' : 'Hostile Lineup:'}
                            </span>

                            <div className="grid grid-cols-4 gap-2">
                              {[0, 1, 2, 3].map(slotIdx => {
                                const card = enemyCards[slotIdx];
                                return (
                                  <div
                                    key={slotIdx}
                                    className="aspect-[4/5] rounded-xl border border-white/10 bg-black/60 overflow-hidden relative flex flex-col justify-end p-1"
                                  >
                                    {card ? (
                                      <>
                                        <img 
                                          src={card.imageUrl} 
                                          alt={card.name} 
                                          className="w-full h-full object-cover absolute inset-0"
                                        />
                                        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent" />
                                        <span className="relative z-10 text-[8px] font-mono text-white truncate font-bold text-center block">
                                          ⚔️ {card.attack}
                                        </span>
                                      </>
                                    ) : (
                                      <span className="text-[9px] font-mono text-slate-600 m-auto">-</span>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </div>

                          {/* Rewards Row */}
                          <div className="flex items-center gap-3 text-xs font-mono text-slate-300 pt-1">
                            <span className="flex items-center gap-1 text-amber-300 font-bold">
                              <Coins size={13} className="text-amber-400" />
                              <span>+{battle.rewardCoins + (!claimedFirstClear ? battle.firstClearBonusCoins : 0)} Coins</span>
                            </span>
                            <span>•</span>
                            <span className="flex items-center gap-1 text-teal-300 font-bold">
                              <Trophy size={13} className="text-teal-400" />
                              <span>+{battle.rewardXp} XP</span>
                            </span>
                          </div>

                          {/* Primary "Enter Battle" Action Button */}
                          <div className="pt-2">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onStartBattle(battle);
                              }}
                              className={`w-full py-3.5 px-6 rounded-2xl font-extrabold text-xs font-mono tracking-wider uppercase transition-all duration-200 cursor-pointer shadow-lg flex items-center justify-center gap-2 active:scale-98 ${
                                isFinale
                                  ? 'bg-gradient-to-r from-amber-400 to-yellow-300 hover:from-amber-300 hover:to-yellow-200 text-black shadow-amber-400/30'
                                  : isBoss
                                  ? 'bg-gradient-to-r from-rose-500 to-red-600 hover:from-rose-400 hover:to-red-500 text-white shadow-rose-500/30'
                                  : 'bg-[#5eead4] hover:bg-[#2dd4bf] text-black shadow-[#5eead4]/20'
                              }`}
                            >
                              <Swords size={16} />
                              <span>{completed ? (isAr ? 'إعادة النزال' : 'Replay Battle') : (isAr ? 'بدء المعركة' : 'Enter Battle')}</span>
                            </button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* Collapsed Click Prompt (when not active) */}
                    {!isActive && (
                      <div className="pt-3 flex items-center justify-between gap-2 text-[11px] font-mono text-slate-400">
                        <span className="group-hover:text-[#5eead4] transition-colors truncate">
                          {isAr ? 'اضغط للتفاصيل' : 'Tap for details'}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onStartBattle(battle);
                          }}
                          className="px-3 py-1.5 rounded-xl bg-[#5eead4]/15 hover:bg-[#5eead4] text-[#5eead4] hover:text-black font-extrabold border border-[#5eead4]/40 text-[10px] tracking-wider uppercase transition-all flex items-center gap-1 cursor-pointer shrink-0"
                        >
                          <Swords size={12} />
                          <span>{isAr ? 'قتال ➔' : 'FIGHT ➔'}</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </motion.div>
            </div>
          );
        })}
      </div>

      {/* Floating Tactical Deploy Dock (Always easy to launch active fight) */}
      {(() => {
        const activeBattle = displayBattles.find(b => b.id === activeBattleId) || newestUnlockedBattle || displayBattles[0];
        if (!activeBattle) return null;
        const isFinale = activeBattle.fightType === 'CHAPTER_FINALE' || activeBattle.isChapterFinale;
        const isBoss = activeBattle.fightType === 'BOSS' || activeBattle.difficulty === 'BOSS';
        const isNewestUnlocked = activeBattle.id === newestUnlockedBattle?.id;
        const isCompleted = isBattleCompleted(activeBattle.id);

        return (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="fixed bottom-4 sm:bottom-6 inset-x-4 max-w-xl mx-auto z-40 p-2 sm:p-3 rounded-2xl bg-black/95 border border-teal-500/50 backdrop-blur-2xl shadow-[0_0_50px_rgba(45,212,191,0.3)] flex items-center justify-between gap-3 select-none"
          >
            <div className="flex items-center gap-2.5 min-w-0 pl-1.5">
              <div className="w-9 h-9 rounded-xl bg-teal-500/10 border border-teal-500/30 flex items-center justify-center shrink-0">
                {isFinale ? <Crown size={17} className="text-amber-400" /> : isBoss ? <Skull size={17} className="text-rose-400" /> : <Swords size={17} className="text-[#5eead4]" />}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className={`text-[9px] font-mono font-black uppercase px-2 py-0.5 rounded-full border ${
                    isNewestUnlocked 
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse'
                      : 'bg-teal-500/20 text-[#5eead4] border-teal-500/30'
                  }`}>
                    {isNewestUnlocked 
                      ? (isAr ? '⭐ أحدث معركة مفتوحة' : '⭐ NEWEST UNLOCKED') 
                      : (isAr ? '🎯 المعركة المفتوحة المحددة' : '🎯 OPENED BATTLE')}
                  </span>
                  {isCompleted && (
                    <span className="text-[9px] font-mono text-emerald-400 font-bold">
                      ✓ {isAr ? 'تم الاجتياز' : 'CLEARED'}
                    </span>
                  )}
                </div>

                <span className="text-xs sm:text-sm font-black text-white block truncate">
                  {isAr ? activeBattle.nameAr || activeBattle.name : activeBattle.name}
                </span>
                <span className="text-[10px] font-mono text-teal-300 font-bold block">
                  +{activeBattle.rewardCoins} Coins • +{activeBattle.rewardXp} XP
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onStartBattle(activeBattle)}
              className={`px-4 sm:px-6 py-2.5 sm:py-3 rounded-xl font-mono font-black text-xs uppercase tracking-wider transition-all duration-200 cursor-pointer shadow-lg flex items-center gap-1.5 shrink-0 active:scale-95 ${
                isFinale
                  ? 'bg-gradient-to-r from-amber-400 to-yellow-300 text-black shadow-amber-400/30 hover:brightness-110'
                  : isBoss
                  ? 'bg-gradient-to-r from-rose-500 to-red-600 text-white shadow-rose-500/30 hover:brightness-110'
                  : 'bg-[#5eead4] hover:bg-[#2dd4bf] text-black shadow-[#5eead4]/30'
              }`}
            >
              <Swords size={15} />
              <span>{isCompleted ? (isAr ? 'إعادة القتال' : 'REPLAY') : (isAr ? 'بدء القتال' : 'START FIGHT')}</span>
            </button>
          </motion.div>
        );
      })()}
    </div>
  );
};
