import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BattleCardEntity } from '../../types/story';
import { Skull, Shield, X, Swords, Zap, Eye, Wind, Heart, Sparkles } from 'lucide-react';
import { getRarityConfig } from '../../config/rarityConfig';

interface EnemyDuelRackProps {
  cards: BattleCardEntity[];
  isAr: boolean;
  onCardClick?: (card: BattleCardEntity, index: number) => void;
}

export const EnemyDuelRack: React.FC<EnemyDuelRackProps> = ({ cards, isAr, onCardClick }) => {
  const [inspectedCard, setInspectedCard] = useState<{ card: BattleCardEntity; index: number } | null>(null);

  const handleCardPress = (card: BattleCardEntity, idx: number) => {
    setInspectedCard({ card, index: idx });
    if (onCardClick) {
      onCardClick(card, idx);
    }
  };

  const totalCards = Math.max(1, cards.length);

  return (
    <div className="relative w-full max-w-[430px] xs:max-w-[490px] sm:max-w-[550px] mx-auto flex flex-col items-center select-none pt-1 sm:pt-1.5 pointer-events-auto">
      {/* 1. OPPONENT DUEL TRAY CHASSIS (BALANCED SIZE & SLEEK DESIGN) */}
      <div 
        className="relative w-full rounded-2xl sm:rounded-3xl border border-slate-700/60 px-2 xs:px-3 pt-1.5 pb-1.5 shadow-[0_8px_25px_rgba(0,0,0,0.85),inset_0_1px_0_rgba(255,255,255,0.08)] flex flex-col items-center backdrop-blur-md"
        style={{
          background: 'linear-gradient(180deg, rgba(14,19,26,0.96) 0%, rgba(8,11,16,0.98) 100%)'
        }}
      >
        {/* Subtle Neon Conduit Line along top of tray */}
        <div className="absolute -top-[1.5px] inset-x-8 sm:inset-x-16 h-[2px] bg-gradient-to-r from-transparent via-cyan-400/80 to-transparent opacity-85 pointer-events-none" />

        {/* Status Header on Opponent Tray */}
        <div className="flex items-center justify-between w-full px-1 mb-1 pointer-events-none">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-ping" />
            <span className="text-[6.5px] sm:text-[8px] font-mono font-black tracking-widest text-slate-300 uppercase drop-shadow">
              {isAr ? 'ساحة الخصم' : 'OPPONENT DUEL TRAY'}
            </span>
          </div>

          <div className="flex items-center gap-1 text-[6px] sm:text-[7.5px] font-mono font-bold text-slate-400">
            <span className="px-1.5 py-0.2 rounded bg-black/60 border border-slate-700/50 text-slate-300">
              {cards.filter(c => !c.isDefeated && c.currentHp > 0).length} / {totalCards} {isAr ? 'نشط' : 'ACTIVE'}
            </span>
          </div>
        </div>

        {/* 2. THE 3D ENEMY CARDS FAN CONTAINER */}
        <div 
          className="flex justify-center items-start gap-1.5 xs:gap-2 sm:gap-2.5 w-full relative z-10 min-h-[86px] xs:min-h-[100px] sm:min-h-[116px] md:min-h-[130px] py-0.5"
          style={{ perspective: '1000px' }}
        >
          {cards.slice(0, 4).map((card, idx) => {
            const isDead = card.isDefeated || card.currentHp <= 0;
            const maxHp = card.maxHp || 100;
            const hpPct = Math.max(0, Math.min(100, Math.round((card.currentHp / maxHp) * 100)));

            const currentStamina = card.currentStamina ?? 100;
            const maxStamina = card.maxStamina || 100;
            const staminaPct = Math.max(0, Math.min(100, Math.round((currentStamina / maxStamina) * 100)));
            const isExhausted = currentStamina <= 0;

            const mid = (cards.length - 1) / 2;
            const diff = idx - mid;
            const rotateZ = -diff * 2.2;
            const rotateX = -5;
            const y = Math.abs(diff) * 1.5;
            const zIndex = 10 + idx;

            // Rarity styling - Same system as player cards
            const rawRarity = card.card?.rarity || card.rarity || 'COMMON';
            const rarityConf = getRarityConfig(rawRarity);
            const isCommon = rarityConf.id === 'COMMON';
            const isLegendary = rarityConf.id === 'LEGENDARY';
            const isEpic = rarityConf.id === 'EPIC';
            const isRare = rarityConf.id === 'RARE';
            const isUncommon = rarityConf.id === 'UNCOMMON';

            return (
              <motion.div
                key={card.instanceId}
                initial={false}
                animate={{
                  y,
                  rotateZ,
                  rotateX,
                  zIndex
                }}
                transition={{
                  type: 'spring',
                  stiffness: 420,
                  damping: 24,
                  mass: 0.8
                }}
                onClick={() => handleCardPress(card, idx)}
                className={`relative flex flex-col items-center w-[18vw] max-w-[44px] xs:max-w-[52px] sm:max-w-[62px] md:max-w-[70px] shrink-0 cursor-pointer touch-manipulation hover:scale-105 active:scale-95 transition-transform duration-200 ${
                  isDead ? 'opacity-35 grayscale cursor-not-allowed' : ''
                }`}
              >
                {/* 
                  3D CARD BODY (FIRST - CARDS ARE ON TOP, BARS ARE DOWN BELOW)
                  Uses the exact same rarity colors, border, ambient glow, and gradients as player cards!
                  Zero rarity words displayed on card in panel!
                */}
                <div 
                  className={`relative w-full aspect-[5/7] rounded-lg sm:rounded-xl overflow-hidden border-2 transition-all duration-300 flex flex-col justify-between select-none ${
                    isDead 
                      ? 'border-slate-800 bg-slate-950'
                      : 'shadow-md hover:shadow-lg'
                  }`}
                  style={{
                    background: rarityConf.bgGradient,
                    borderColor: isDead ? '#334155' : `${rarityConf.borderColor}ee`,
                    boxShadow: isDead ? 'none' : `${rarityConf.depthShadow}, 0 0 10px ${rarityConf.glowColor}`
                  }}
                >
                  {/* Rarity-specific Ambient Lighting */}
                  <div 
                    className="absolute inset-0 pointer-events-none opacity-30"
                    style={{
                      background: `radial-gradient(circle at 50% 20%, ${rarityConf.glowColor} 0%, transparent 75%)`
                    }}
                  />

                  {/* Glossy Top Edge Highlight */}
                  <div 
                    className="absolute top-0 inset-x-0 h-[1.5px] opacity-90 pointer-events-none" 
                    style={{
                      background: `linear-gradient(to right, transparent, ${rarityConf.accentColor}, transparent)`
                    }}
                  />

                  {/* Card Illustration with Rarity Saturation Profile */}
                  <img 
                    src={card.card.imageUrl} 
                    alt={card.card.name} 
                    className={`absolute inset-0 w-full h-full object-cover pointer-events-none ${rarityConf.saturationClass}`}
                  />

                  {/* Shading Gradients for 3D Depth */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/92 via-transparent to-black/55 pointer-events-none" />

                  {/* Subtle Shimmer for Uncommon/Rare/Epic/Legendary */}
                  {!isCommon && !isDead && (
                    <motion.div 
                      initial={{ x: '-100%' }}
                      animate={{ x: '200%' }}
                      transition={{ duration: isLegendary ? 0.9 : 1.2, repeat: Infinity, repeatDelay: 0.8, ease: 'linear' }}
                      className="absolute inset-y-0 w-1/2 bg-gradient-to-r from-transparent via-white/18 to-transparent skew-x-12 pointer-events-none"
                    />
                  )}

                  {/* Floating Micro-Particles for Legendary & Epic */}
                  {(isLegendary || isEpic) && !isDead && (
                    <div className="absolute inset-0 pointer-events-none overflow-hidden z-15">
                      <span className="absolute top-1 right-1 w-1 h-1 rounded-full bg-amber-300/80 animate-ping" />
                    </div>
                  )}

                  {/* Top: Card Name & Shield badge */}
                  <div className="relative z-10 px-1 py-0.5 flex items-center justify-between pointer-events-none">
                    <span 
                      className="text-[6px] xs:text-[7px] sm:text-[8.5px] font-black font-sans text-white truncate drop-shadow-[0_1px_3px_rgba(0,0,0,1)] tracking-tight"
                      style={{
                        color: isLegendary ? '#fef08a' : isEpic ? '#f3e8ff' : isRare ? '#93c5fd' : isUncommon ? '#86efac' : '#ffffff'
                      }}
                    >
                      {card.card.name}
                    </span>
                    {card.shield > 0 && (
                      <span className="px-0.5 py-0.2 rounded-md bg-purple-500/40 border border-purple-400 text-purple-200 text-[5px] sm:text-[6px] font-mono font-black flex items-center gap-0.5 shadow-sm">
                        <Shield size={6} />
                        +{card.shield}
                      </span>
                    )}
                  </div>

                  {/* Skull if Dead */}
                  {isDead && (
                    <div className="absolute inset-0 z-20 bg-black/85 flex items-center justify-center pointer-events-none">
                      <Skull size={16} className="text-slate-500" />
                    </div>
                  )}

                  {/* Bottom: ORGANIZED ATK & DEF (No rarity circle - clean, balanced chips) */}
                  <div className="relative z-10 w-full px-1 py-0.5 bg-black/75 backdrop-blur-xs border-t border-white/10 flex items-center justify-between pointer-events-none rounded-b-[inherit]">
                    <div className="flex items-center gap-0.5 font-mono font-black text-cyan-300 drop-shadow">
                      <span className="text-[5px] xs:text-[6px] sm:text-[7px] text-cyan-400 font-bold uppercase tracking-tighter">ATK</span>
                      <span className="text-[6px] xs:text-[7.5px] sm:text-[9px]">{card.attack}</span>
                    </div>
                    <div className="flex items-center gap-0.5 font-mono font-black text-amber-300 drop-shadow">
                      <span className="text-[5px] xs:text-[6px] sm:text-[7px] text-amber-400 font-bold uppercase tracking-tighter">DEF</span>
                      <span className="text-[6px] xs:text-[7.5px] sm:text-[9px]">{card.defense}</span>
                    </div>
                  </div>
                </div>

                {/* 
                  HEALTH & STAMINA BARS (DOWN NOT ABOVE THE CARDS)
                  Positioned strictly below the card body!
                */}
                <div className="w-full px-0.5 space-y-0.5 mt-0.5 sm:mt-1 pointer-events-none drop-shadow-[0_1px_2px_rgba(0,0,0,0.95)]">
                  {/* Health Bar (HP) */}
                  <div className="flex items-center justify-between text-[5px] xs:text-[6px] sm:text-[7px] font-mono font-black text-white leading-none">
                    <span className="text-rose-400 font-bold">HP</span>
                    <span className={hpPct > 50 ? 'text-rose-200' : hpPct > 20 ? 'text-amber-300' : 'text-rose-400 font-black'}>
                      {card.currentHp}/{maxHp}
                    </span>
                  </div>
                  <div className="w-full h-1 xs:h-1.5 rounded-full bg-slate-900 border border-white/15 overflow-hidden p-[0.5px] shadow-[inset_0_1px_2px_rgba(0,0,0,0.9)]">
                    <div 
                      className={`h-full rounded-full transition-all duration-300 ${
                        hpPct > 50 
                          ? 'bg-gradient-to-r from-rose-600 via-pink-500 to-rose-400 shadow-[0_0_6px_rgba(244,63,94,0.8)]' 
                          : hpPct > 20 
                            ? 'bg-gradient-to-r from-amber-500 to-yellow-300' 
                            : 'bg-gradient-to-r from-red-600 to-rose-400'
                      }`}
                      style={{ width: `${hpPct}%` }}
                    />
                  </div>

                  {/* Stamina Bar (STM) */}
                  <div className="flex items-center justify-between text-[4.5px] xs:text-[5.5px] sm:text-[6.5px] font-mono font-bold leading-none mt-0.5">
                    <span className={isExhausted ? 'text-rose-400 animate-pulse font-black' : 'text-emerald-300'}>
                      {isExhausted ? (isAr ? 'منهك!' : 'EXH') : (isAr ? 'الجهد' : 'STM')}
                    </span>
                    <span className={isExhausted ? 'text-rose-400 font-bold' : 'text-emerald-300'}>
                      {currentStamina}/{maxStamina}
                    </span>
                  </div>
                  <div className="w-full h-0.5 xs:h-1 rounded-full bg-slate-900 border border-emerald-500/25 overflow-hidden p-[0.5px] shadow-[inset_0_1px_2px_rgba(0,0,0,0.9)]">
                    <div 
                      className={`h-full rounded-full transition-all duration-300 ${
                        isExhausted
                          ? 'bg-rose-500'
                          : staminaPct > 40
                            ? 'bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-300 shadow-[0_0_5px_rgba(16,185,129,0.7)]'
                            : 'bg-gradient-to-r from-amber-500 to-rose-400'
                      }`}
                      style={{ width: `${staminaPct}%` }}
                    />
                  </div>
                </div>

                {/* 3D Physical Card Socket / Shadow in Tray */}
                <div 
                  className="w-4/5 h-1 rounded-full bg-black/60 blur-[1.5px] mt-0.5 pointer-events-none"
                />
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* 
        ENEMY CARD INSPECTION MODAL:
        Only shows rarity words and detailed stats when the card is pressed on!
      */}
      <AnimatePresence>
        {inspectedCard && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setInspectedCard(null)}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 cursor-pointer select-none"
          >
            <motion.div
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.8, y: 20 }}
              transition={{ type: 'spring', stiffness: 350, damping: 25 }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-xs rounded-2xl border-2 overflow-hidden shadow-2xl p-4 flex flex-col gap-3 cursor-default"
              style={{
                background: getRarityConfig(inspectedCard.card.card?.rarity || inspectedCard.card.rarity).bgGradient,
                borderColor: getRarityConfig(inspectedCard.card.card?.rarity || inspectedCard.card.rarity).borderColor,
                boxShadow: `${getRarityConfig(inspectedCard.card.card?.rarity || inspectedCard.card.rarity).depthShadow}, 0 0 30px ${getRarityConfig(inspectedCard.card.card?.rarity || inspectedCard.card.rarity).glowColor}`
              }}
            >
              {/* Top Bar: Rarity Word Badge (Displayed only when pressed on) + Close */}
              {(() => {
                const conf = getRarityConfig(inspectedCard.card.card?.rarity || inspectedCard.card.rarity);
                return (
                  <div className="flex items-center justify-between pb-2 border-b border-white/10">
                    <div className="flex items-center gap-1.5">
                      <span className={`px-2 py-0.5 rounded text-[8px] font-mono font-black uppercase tracking-wider border shadow-xs ${conf.badgeBg} ${conf.badgeBorder} ${conf.badgeText}`}>
                        {conf.name}
                      </span>
                      <span className="text-[9px] font-mono font-bold text-slate-300">
                        {isAr ? 'بطاقة الخصم' : 'ENEMY CARD'}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => setInspectedCard(null)}
                      className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
                    >
                      <X size={14} />
                    </button>
                  </div>
                );
              })()}

              {/* 3D Visual Preview */}
              <div className="flex gap-3 items-center">
                <div 
                  className="w-20 aspect-[5/7] rounded-xl overflow-hidden border-2 shrink-0 relative shadow-lg"
                  style={{
                    borderColor: getRarityConfig(inspectedCard.card.card?.rarity || inspectedCard.card.rarity).borderColor
                  }}
                >
                  <img 
                    src={inspectedCard.card.card.imageUrl} 
                    alt={inspectedCard.card.card.name} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                </div>

                <div className="flex-1 min-w-0">
                  <h3 
                    className="text-sm font-black font-sans truncate drop-shadow"
                    style={{
                      color: getRarityConfig(inspectedCard.card.card?.rarity || inspectedCard.card.rarity).accentColor
                    }}
                  >
                    {inspectedCard.card.card.name}
                  </h3>
                  <p className="text-[10px] text-slate-400 line-clamp-2 mt-0.5 leading-tight">
                    {inspectedCard.card.card.description || inspectedCard.card.card.lore}
                  </p>

                  <div className="grid grid-cols-2 gap-1.5 mt-2 text-[9px] font-mono font-bold">
                    <span className="px-1.5 py-0.5 rounded bg-black/40 border border-white/10 text-cyan-300">
                      ATK: {inspectedCard.card.attack}
                    </span>
                    <span className="px-1.5 py-0.5 rounded bg-black/40 border border-white/10 text-amber-300">
                      DEF: {inspectedCard.card.defense}
                    </span>
                    <span className="px-1.5 py-0.5 rounded bg-black/40 border border-white/10 text-rose-300">
                      HP: {inspectedCard.card.currentHp}/{inspectedCard.card.maxHp || 100}
                    </span>
                    <span className="px-1.5 py-0.5 rounded bg-black/40 border border-white/10 text-emerald-300">
                      STM: {inspectedCard.card.currentStamina ?? 100}/100
                    </span>
                  </div>
                </div>
              </div>

              {/* Ability / Skill Info */}
              {inspectedCard.card.skill && (
                <div className="p-2 rounded-xl bg-black/50 border border-white/10 flex flex-col gap-0.5">
                  <div className="flex items-center justify-between text-[9px] font-mono font-bold text-amber-300">
                    <span className="flex items-center gap-1">
                      <Sparkles size={10} className="text-amber-400" />
                      <span>{isAr && inspectedCard.card.skill.nameAr ? inspectedCard.card.skill.nameAr : inspectedCard.card.skill.name}</span>
                    </span>
                    <span className="text-slate-400 text-[8px]">
                      {inspectedCard.card.skill.staminaCost} STM
                    </span>
                  </div>
                  <p className="text-[9px] text-slate-300 leading-tight">
                    {isAr && inspectedCard.card.skill.descriptionAr ? inspectedCard.card.skill.descriptionAr : inspectedCard.card.skill.description}
                  </p>
                </div>
              )}

              {/* Passive Stamina Rule Note */}
              <div className="text-[8px] font-mono text-slate-400 text-center pt-1 border-t border-white/10">
                {isAr ? '⚡ يستعيد 7% جهد كل جولة لا يتم اختياره فيها' : '⚡ Recovers 7% Stamina every turn not chosen'}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
