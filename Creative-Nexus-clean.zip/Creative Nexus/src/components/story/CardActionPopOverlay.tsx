import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BattleCardEntity, CombatIntentType, ACTION_CONFIGS } from '../../types/story';
import { Swords, Flame, Shield, Zap, X } from 'lucide-react';

interface CardActionPopOverlayProps {
  card: BattleCardEntity;
  onChooseAction: (action: CombatIntentType) => void;
  onCancel: () => void;
  isAr: boolean;
}

export const CardActionPopOverlay: React.FC<CardActionPopOverlayProps> = ({
  card,
  onChooseAction,
  onCancel,
  isAr
}) => {
  // Stages:
  // 1. POP: Card pops out, scaling up and getting closer to the screen
  // 2. BARS: Small animation revealing health and energy bars
  // 3. BUTTONS: Four buttons slowly appear prompting the user to take an action
  // 4. FADING: Fades out upon action selection before card throw
  const [stage, setStage] = useState<'POP' | 'BARS' | 'BUTTONS' | 'FADING'>('POP');

  useEffect(() => {
    // Stage 1: Card pops out getting closer
    setStage('POP');

    // Stage 2: Bars reveal with animation
    const tBars = setTimeout(() => {
      setStage('BARS');
    }, 220);

    // Stage 3: Slowly four buttons appear
    const tButtons = setTimeout(() => {
      setStage('BUTTONS');
    }, 500);

    return () => {
      clearTimeout(tBars);
      clearTimeout(tButtons);
    };
  }, []);

  const handleActionClick = (action: CombatIntentType) => {
    const cost = ACTION_CONFIGS[action].energyCost;
    if ((card.currentEnergy ?? 5) < cost) return;

    // Trigger fade out: card, bars, and buttons will fade out
    setStage('FADING');
    setTimeout(() => {
      onChooseAction(action);
    }, 250);
  };

  const hpPct = Math.max(0, Math.min(100, Math.round((card.currentHp / card.maxHp) * 100)));
  const energy = card.currentEnergy ?? 5;
  const maxEnergy = card.maxEnergy || 10;
  const energyPct = Math.min(100, Math.round((energy / maxEnergy) * 100));

  const canAffordStrike = energy >= ACTION_CONFIGS.STRIKE.energyCost;
  const canAffordHeavy = energy >= ACTION_CONFIGS.HEAVY.energyCost;
  const canAffordDefend = energy >= ACTION_CONFIGS.DEFEND.energyCost;
  const canAffordSkill = energy >= ACTION_CONFIGS.ABILITY.energyCost;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: stage === 'FADING' ? 0 : 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.25 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-3 select-none"
      >
        {/* Soft Darkened Backdrop */}
        <div 
          onClick={stage !== 'FADING' ? onCancel : undefined}
          className="absolute inset-0 bg-black/80 backdrop-blur-md cursor-pointer"
        />

        {/* Focused Dialog Container */}
        <motion.div
          initial={{ scale: 0.85, y: 70, opacity: 0 }}
          animate={
            stage === 'FADING'
              ? { scale: 0.95, opacity: 0, y: -10 }
              : { scale: 1, y: 0, opacity: 1 }
          }
          transition={{ 
            type: 'spring', 
            damping: 24, 
            stiffness: 350,
            opacity: { duration: stage === 'FADING' ? 0.22 : 0.2 } 
          }}
          className="relative z-10 flex flex-col items-center max-w-sm w-full pointer-events-auto"
        >
          {/* Cancel button */}
          <button
            type="button"
            onClick={onCancel}
            className="self-end mb-2 p-1.5 rounded-full bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white border border-white/10 transition-all cursor-pointer shadow-lg"
            title={isAr ? 'إلغاء' : 'Cancel'}
          >
            <X size={16} />
          </button>

          {/* 1. THE POPPED-OUT CARD GETTING CLOSER TO THE SCREEN */}
          <motion.div
            animate={{
              scale: stage === 'FADING' ? 0.95 : 1.05,
              y: stage === 'FADING' ? 10 : 0
            }}
            transition={{ type: 'spring', damping: 20, stiffness: 350 }}
            className="relative w-36 xs:w-42 sm:w-48 aspect-[5/7] rounded-2xl overflow-hidden border-2 border-cyan-400 shadow-[0_20px_50px_rgba(0,0,0,0.95),0_0_30px_rgba(6,182,212,0.45)] mb-3"
            style={{
              background: 'linear-gradient(180deg, rgba(8,28,34,0.98) 0%, rgba(3,14,18,0.99) 100%)'
            }}
          >
            <div className="absolute top-0 inset-x-0 h-[2.5px] bg-gradient-to-r from-transparent via-[#5eead4] to-transparent opacity-95 pointer-events-none" />

            <img 
              src={card.card.imageUrl} 
              alt={card.card.name} 
              className="absolute inset-0 w-full h-full object-cover pointer-events-none"
            />

            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-black/45 pointer-events-none" />

            {/* Card Header */}
            <div className="relative z-10 px-2 py-1 flex items-center justify-between pointer-events-none">
              <span className="text-xs sm:text-sm font-black font-sans text-white truncate drop-shadow-[0_2px_4px_rgba(0,0,0,1)] tracking-wide">
                {card.card.name}
              </span>
              {card.shield > 0 && (
                <span className="px-1.5 py-0.5 rounded bg-blue-500/30 border border-blue-400 text-blue-200 text-[8px] font-mono font-black flex items-center gap-0.5 shadow-sm">
                  <Shield size={9} />
                  +{card.shield}
                </span>
              )}
            </div>

            {/* Bottom stats tag */}
            <div className="relative z-10 px-2 pb-1.5 pt-0.5 flex items-center justify-between text-[8px] sm:text-[9.5px] font-mono font-bold text-slate-300 drop-shadow pointer-events-none">
              <span>ATK {card.attack}</span>
              <span>DEF {card.defense}</span>
            </div>
          </motion.div>

          {/* 2. SMALL ANIMATION SHOWING THE BARS, ENERGY AND HEALTH */}
          <AnimatePresence>
            {(stage === 'BARS' || stage === 'BUTTONS') && (
              <motion.div
                initial={{ opacity: 0, y: 15, scale: 0.92 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -10, scale: 0.9 }}
                transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                className="w-full max-w-[280px] xs:max-w-[320px] p-2.5 rounded-2xl bg-slate-950/90 border border-cyan-500/40 shadow-xl backdrop-blur-md mb-3 space-y-2"
              >
                {/* Health Bar Animation */}
                <div>
                  <div className="flex items-center justify-between text-[9px] sm:text-[10px] font-mono font-black text-white mb-0.5">
                    <span className="text-cyan-300">HEALTH</span>
                    <span className={hpPct > 50 ? 'text-[#5eead4]' : hpPct > 20 ? 'text-amber-300' : 'text-rose-400'}>
                      {card.currentHp} / {card.maxHp}
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-900 border border-white/20 overflow-hidden p-[1px] shadow-inner">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${hpPct}%` }}
                      transition={{ duration: 0.45, ease: 'easeOut' }}
                      className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-teal-400 to-[#5eead4] shadow-[0_0_8px_rgba(94,234,212,0.9)]"
                    />
                  </div>
                </div>

                {/* Energy Bar Animation */}
                <div>
                  <div className="flex items-center justify-between text-[8.5px] sm:text-[9.5px] font-mono font-black text-amber-300 mb-0.5">
                    <span className="flex items-center gap-1">
                      <Zap size={9} className="text-amber-400" />
                      <span>ENERGY</span>
                    </span>
                    <span className="text-amber-200">{energy} / {maxEnergy}</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-slate-900 border border-amber-500/30 overflow-hidden p-[0.5px] shadow-inner">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${energyPct}%` }}
                      transition={{ duration: 0.45, delay: 0.1, ease: 'easeOut' }}
                      className="h-full rounded-full bg-gradient-to-r from-amber-500 via-yellow-300 to-amber-400 shadow-[0_0_8px_rgba(245,158,11,0.8)]"
                    />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* 3. SLOWLY ANOTHER FOUR BUTTONS WILL APPEAR TELLING ME TO TAKE AN ACTION */}
          <AnimatePresence>
            {stage === 'BUTTONS' && (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                transition={{ duration: 0.4, ease: 'easeOut' }}
                className="w-full flex flex-col items-center gap-1.5"
              >
                <span className="text-[10px] sm:text-xs font-mono font-black tracking-widest text-cyan-300 uppercase mb-0.5">
                  {isAr ? '⚡ اختر حركتك القتالية' : '⚡ SELECT YOUR COMBAT ACTION'}
                </span>

                <div className="grid grid-cols-2 gap-2 w-full max-w-[320px]">
                  {/* 1. STRIKE */}
                  <button
                    type="button"
                    disabled={!canAffordStrike}
                    onClick={() => handleActionClick('STRIKE')}
                    className={`py-2.5 px-3 rounded-xl font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center transition-all active:scale-95 shadow-md ${
                      canAffordStrike
                        ? 'bg-slate-800 text-cyan-300 border border-cyan-500/40 hover:bg-slate-700 cursor-pointer shadow-cyan-500/20'
                        : 'bg-slate-800/40 text-slate-500 border border-slate-700 cursor-not-allowed opacity-50'
                    }`}
                  >
                    STRIKE
                  </button>

                  {/* 2. HEAVY */}
                  <button
                    type="button"
                    disabled={!canAffordHeavy}
                    onClick={() => handleActionClick('HEAVY')}
                    className={`py-2.5 px-3 rounded-xl font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center transition-all active:scale-95 shadow-md ${
                      canAffordHeavy
                        ? 'bg-slate-800 text-amber-300 border border-amber-500/40 hover:bg-slate-700 cursor-pointer shadow-amber-500/20'
                        : 'bg-slate-800/40 text-slate-500 border border-slate-700 cursor-not-allowed opacity-50'
                    }`}
                  >
                    HEAVY
                  </button>

                  {/* 3. DEFENSE */}
                  <button
                    type="button"
                    disabled={!canAffordDefend}
                    onClick={() => handleActionClick('DEFEND')}
                    className="py-2.5 px-3 rounded-xl bg-slate-800 text-emerald-300 border border-emerald-500/40 hover:bg-slate-700 font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center cursor-pointer transition-all active:scale-95 shadow-md shadow-emerald-500/20"
                  >
                    DEFENSE
                  </button>

                  {/* 4. SKILL */}
                  <button
                    type="button"
                    disabled={!canAffordSkill}
                    onClick={() => handleActionClick('ABILITY')}
                    className={`py-2.5 px-3 rounded-xl font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center transition-all active:scale-95 shadow-md ${
                      canAffordSkill
                        ? 'bg-slate-800 text-purple-300 border border-purple-500/40 hover:bg-slate-700 cursor-pointer shadow-purple-500/20'
                        : 'bg-slate-800/40 text-slate-500 border border-slate-700 cursor-not-allowed opacity-50'
                    }`}
                  >
                    SKILL
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
