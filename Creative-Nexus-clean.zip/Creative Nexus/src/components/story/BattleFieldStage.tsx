import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BattleCardEntity, CombatIntentType } from '../../types/story';
import { Shield, Zap, Swords, Flame } from 'lucide-react';

export type AnimationPhase = 
  | 'NEUTRAL'         // 0.00 - 0.15s: Stable arena, center clear
  | 'CARD_EMERGE'     // 0.15 - 0.45s: Bottom card emerges and moves upward
  | 'CARD_SETTLE'     // 0.40 - 0.70s: Card settles into combat position (tilted, soft shadow)
  | 'BAR_DARK'        // 0.45 - 0.80s: Dark status bar expands behind card
  | 'BAR_GREEN'       // 0.60 - 1.20s: Bright green main health bar expands rapidly
  | 'BARS_SECONDARY'  // 0.70 - 1.30s: Secondary yellow/muted status bars appear
  | 'PEAK_COMBAT'     // 0.80 - 1.35s: Peak combat state with subtle floating motion
  | 'BARS_FADE'       // 1.30 - 1.55s: Status bars dim and fade
  | 'CARD_EXIT'       // 1.40 - 1.70s: Card exits into bottom player area
  | 'NEW_ELEMENTS'    // 1.55 - 1.90s: Two turquoise battle elements enter vertically
  | 'SETTLED_HOLD';   // 1.90 - 3.35s+: Two turquoise elements remain stable

export interface BattleFieldStageProps {
  playerCard: BattleCardEntity | null;
  enemyCard: BattleCardEntity | null;
  turnNumber: number;
  activeAction: CombatIntentType | null;
  isCombatActive: boolean;
  damageAmount?: number;
  onSequenceComplete?: () => void;
  isAr: boolean;
  // External trigger or auto-replay flag
  sequenceKey?: number;
}

export const BattleFieldStage: React.FC<BattleFieldStageProps> = ({
  playerCard,
  enemyCard,
  turnNumber,
  activeAction,
  isCombatActive,
  damageAmount,
  onSequenceComplete,
  isAr,
  sequenceKey = 0
}) => {
  const [phase, setPhase] = useState<AnimationPhase>('NEUTRAL');

  // Exact Motion Timing sequence from reference:
  // Total reference duration: ~3.35s
  useEffect(() => {
    if (!isCombatActive && !playerCard) {
      setPhase('NEUTRAL');
      return;
    }

    // 0.00s: Neutral arena
    setPhase('NEUTRAL');

    // 0.15s: Bottom card begins emerging
    const t1 = setTimeout(() => {
      setPhase('CARD_EMERGE');
    }, 150);

    // 0.45s: Card settles, first dark status bar begins expanding behind card
    const t2 = setTimeout(() => {
      setPhase('BAR_DARK');
    }, 450);

    // 0.65s: Main bright green bar expands rapidly toward target width
    const t3 = setTimeout(() => {
      setPhase('BAR_GREEN');
    }, 650);

    // 0.80s: Secondary yellow/orange and muted bars appear -> Peak combat state
    const t4 = setTimeout(() => {
      setPhase('PEAK_COMBAT');
    }, 800);

    // 1.35s: Status bars fade/dim, card moves downward
    const t5 = setTimeout(() => {
      setPhase('BARS_FADE');
    }, 1350);

    // 1.45s: Card exits downward into bottom area
    const t6 = setTimeout(() => {
      setPhase('CARD_EXIT');
    }, 1450);

    // 1.65s: New turquoise battlefield elements enter vertically
    const t7 = setTimeout(() => {
      setPhase('NEW_ELEMENTS');
    }, 1650);

    // 1.95s: Settle into two vertically aligned turquoise combat elements holding stably
    const t8 = setTimeout(() => {
      setPhase('SETTLED_HOLD');
      if (onSequenceComplete) {
        onSequenceComplete();
      }
    }, 1950);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
      clearTimeout(t5);
      clearTimeout(t6);
      clearTimeout(t7);
      clearTimeout(t8);
    };
  }, [sequenceKey, isCombatActive, playerCard]);

  // Easing curves per specifications:
  // Card entering: cubic-bezier(0.22, 1, 0.36, 1)
  const cardEase = [0.22, 1, 0.36, 1] as const;
  // Status bar expansion: cubic-bezier(0.16, 1, 0.3, 1)
  const barEase = [0.16, 1, 0.3, 1] as const;

  // Active Card Data
  const card = playerCard;
  const currentHp = card ? card.currentHp : 100;
  const maxHp = card ? card.maxHp : 100;
  const hpPct = Math.max(0, Math.min(100, Math.round((currentHp / maxHp) * 100)));
  const energy = card ? (card.currentEnergy ?? 5) : 5;
  const maxEnergy = card ? (card.maxEnergy || 10) : 10;
  const energyPct = Math.min(100, Math.round((energy / maxEnergy) * 100));

  // Determine stage flags
  const isCardVisible = (
    phase === 'CARD_EMERGE' ||
    phase === 'CARD_SETTLE' ||
    phase === 'BAR_DARK' ||
    phase === 'BAR_GREEN' ||
    phase === 'BARS_SECONDARY' ||
    phase === 'PEAK_COMBAT' ||
    phase === 'BARS_FADE'
  );

  const areBarsVisible = (
    phase === 'BAR_DARK' ||
    phase === 'BAR_GREEN' ||
    phase === 'BARS_SECONDARY' ||
    phase === 'PEAK_COMBAT'
  );

  const areNewTurquoiseElementsVisible = (
    phase === 'NEW_ELEMENTS' ||
    phase === 'SETTLED_HOLD'
  );

  return (
    <div 
      className="relative w-full max-w-sm xs:max-w-md sm:max-w-xl md:max-w-2xl flex-1 min-h-[220px] sm:min-h-[270px] max-h-[380px] rounded-2xl sm:rounded-3xl border border-cyan-500/30 shadow-[0_15px_40px_rgba(0,0,0,0.9),0_0_20px_rgba(6,182,212,0.12)] flex flex-col items-center justify-between overflow-hidden p-2 backdrop-blur-xl shrink"
      style={{
        background: 'linear-gradient(180deg, rgba(3,18,22,0.97) 0%, rgba(2,10,14,0.99) 100%)'
      }}
    >
      {/* Subtle top & bottom cyan edge lines */}
      <div className="absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-80 pointer-events-none" />
      <div className="absolute bottom-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-teal-500/60 to-transparent opacity-60 pointer-events-none" />

      {/* Battlefield Header */}
      <div className="w-full flex items-center justify-between px-3 py-1 border-b border-cyan-500/20 z-10 shrink-0 bg-slate-950/40 rounded-t-xl">
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
          <span className="text-[9px] sm:text-xs font-mono font-bold tracking-widest text-cyan-300 uppercase">
            {isAr ? `المعركة — الجولة ${String(turnNumber).padStart(2, '0')}` : `ARENA — TURN ${String(turnNumber).padStart(2, '0')}`}
          </span>
        </div>
        <span className="text-[7.5px] sm:text-[9px] font-mono text-cyan-400/70 uppercase tracking-widest">
          {isAr ? 'ساحة القتال' : 'BATTLEFIELD'}
        </span>
      </div>

      {/* ========================================================================= */}
      {/* CENTRAL BATTLEFIELD (THE MAIN COMBAT STAGE)                               */}
      {/* ========================================================================= */}
      <div className="relative w-full flex-1 flex items-center justify-center overflow-hidden">
        
        {/* Subtle Battlefield Grid Floor (Depth without visual noise) */}
        <div 
          className="absolute inset-2 rounded-xl opacity-20 pointer-events-none border border-cyan-500/10"
          style={{
            backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(6, 182, 212, 0.15) 1px, transparent 1px)',
            backgroundSize: '16px 16px'
          }}
        />

        {/* ======================================================================= */}
        {/* LAYER 1: STATUS BARS (Z-INDEX 10)                                      */}
        {/* Placed behind character/card; portions obscured by card                 */}
        {/* Uses transform: scaleX(0 -> 1) with transform-origin: left center       */}
        {/* ======================================================================= */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
          <AnimatePresence>
            {areBarsVisible && (
              <motion.div 
                key="status-bars-group"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, transition: { duration: 0.2, ease: 'easeOut' } }}
                className="relative w-full max-w-[280px] xs:max-w-[320px] sm:max-w-[380px] flex flex-col gap-1.5 px-4"
              >
                {/* 1. First Bar: Dark / Low-Intensity Underlay Bar */}
                <div className="relative w-full h-3 sm:h-3.5 rounded-full bg-slate-950/90 border border-white/10 overflow-hidden shadow-inner p-[1px]">
                  <motion.div 
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: 1 }}
                    transition={{ duration: 0.35, ease: barEase }}
                    style={{ transformOrigin: 'left center' }}
                    className="h-full rounded-full bg-slate-800/80 w-full"
                  />
                  {/* Subtle bar indicator */}
                  <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[7px] font-mono text-slate-400 font-bold">
                    COMBAT READY
                  </span>
                </div>

                {/* 2. Main Health / Energy Bar: Bright Green (Most Visually Noticeable) */}
                <div className="relative w-full h-4 sm:h-5 rounded-full bg-slate-950/90 border border-emerald-500/40 overflow-hidden shadow-[0_2px_12px_rgba(34,197,94,0.3)] p-[1.5px]">
                  <motion.div 
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: hpPct / 100 }}
                    transition={{ duration: 0.55, delay: 0.15, ease: barEase }}
                    style={{ transformOrigin: 'left center' }}
                    className="h-full rounded-full bg-gradient-to-r from-emerald-600 via-emerald-400 to-teal-300 shadow-[0_0_12px_rgba(34,197,94,0.8)]"
                  />
                  {/* Health values */}
                  <div className="absolute inset-0 px-2.5 flex items-center justify-between text-[8px] sm:text-[9.5px] font-mono font-black text-white drop-shadow">
                    <span className="text-emerald-200">HEALTH</span>
                    <span className="text-emerald-100">{currentHp} / {maxHp}</span>
                  </div>
                </div>

                {/* 3. Secondary Status Bars: Yellow/Orange Energy Bar + Muted Status */}
                <div className="flex gap-2 items-center w-full">
                  {/* Energy Bar */}
                  <div className="relative flex-1 h-2.5 sm:h-3 rounded-full bg-slate-950/90 border border-amber-500/30 overflow-hidden p-[1px] shadow-sm">
                    <motion.div 
                      initial={{ scaleX: 0 }}
                      animate={{ scaleX: energyPct / 100 }}
                      transition={{ duration: 0.45, delay: 0.25, ease: barEase }}
                      style={{ transformOrigin: 'left center' }}
                      className="h-full rounded-full bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-300 shadow-[0_0_8px_rgba(245,158,11,0.6)]"
                    />
                    <div className="absolute inset-0 px-2 flex items-center justify-between text-[6.5px] sm:text-[7.5px] font-mono font-bold text-amber-200 drop-shadow">
                      <span className="flex items-center gap-0.5"><Zap size={7} /> NRG</span>
                      <span>{energy}/{maxEnergy}</span>
                    </div>
                  </div>

                  {/* Smaller Muted Cyan Bar */}
                  <div className="relative w-20 sm:w-28 h-2.5 sm:h-3 rounded-full bg-slate-950/90 border border-cyan-500/30 overflow-hidden p-[1px]">
                    <motion.div 
                      initial={{ scaleX: 0 }}
                      animate={{ scaleX: 0.85 }}
                      transition={{ duration: 0.4, delay: 0.35, ease: barEase }}
                      style={{ transformOrigin: 'left center' }}
                      className="h-full rounded-full bg-gradient-to-r from-cyan-600 to-teal-400"
                    />
                    <div className="absolute inset-0 px-1.5 flex items-center justify-between text-[6.5px] sm:text-[7px] font-mono text-cyan-200 font-bold drop-shadow">
                      <span>STANCE</span>
                      <span>ACTIVE</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ======================================================================= */}
        {/* LAYER 2: ATTACKING CARD (Z-INDEX 20)                                   */}
        {/* Emerges from bottom player area with cubic-bezier(0.22, 1, 0.36, 1)     */}
        {/* Sits tilted (-1.5deg), subtle drop shadow, floating motion in combat    */}
        {/* Partially obscures status bars passing behind it                        */}
        {/* ======================================================================= */}
        <div className="relative z-20 flex items-center justify-center">
          <AnimatePresence>
            {isCardVisible && card && (
              <motion.div
                key={`attacking-card-${card.instanceId}`}
                initial={{ 
                  y: 95, 
                  opacity: 0, 
                  rotate: -1.5,
                  scale: 0.94
                }}
                animate={
                  phase === 'PEAK_COMBAT'
                    ? {
                        y: [-2, 2],
                        opacity: 1,
                        rotate: [-1.8, -0.8],
                        scale: 1,
                        transition: {
                          y: { repeat: Infinity, repeatType: 'reverse', duration: 1.4, ease: 'easeInOut' },
                          rotate: { repeat: Infinity, repeatType: 'reverse', duration: 1.8, ease: 'easeInOut' },
                          scale: { duration: 0.3 }
                        }
                      }
                    : phase === 'BARS_FADE'
                      ? {
                          y: 12,
                          opacity: 0.85,
                          rotate: -1.5,
                          scale: 0.98,
                          transition: { duration: 0.2, ease: 'easeOut' }
                        }
                      : {
                          y: 0,
                          opacity: 1,
                          rotate: -1.5,
                          scale: 1,
                          transition: { duration: 0.45, ease: cardEase }
                        }
                }
                exit={{ 
                  y: 95, 
                  opacity: 0, 
                  scale: 0.92,
                  transition: { duration: 0.28, ease: 'easeIn' } 
                }}
                className="relative w-22 xs:w-26 sm:w-30 md:w-34 aspect-[5/7] rounded-xl sm:rounded-2xl border-2 border-cyan-400/90 shadow-[0_12px_28px_rgba(0,0,0,0.85),0_0_18px_rgba(6,182,212,0.35)] overflow-hidden flex flex-col justify-between select-none"
                style={{
                  background: 'linear-gradient(180deg, rgba(8,28,34,0.98) 0%, rgba(3,14,18,0.99) 100%)',
                  willChange: 'transform, opacity'
                }}
              >
                {/* Subtle top edge neon line */}
                <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-[#5eead4] to-transparent opacity-90 pointer-events-none" />

                {/* Card Artwork */}
                <img 
                  src={card.card.imageUrl} 
                  alt={card.card.name} 
                  className="absolute inset-0 w-full h-full object-cover pointer-events-none"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-black/50 pointer-events-none" />

                {/* Card Header (Card Name ONLY - no numbers or extra words down over the card) */}
                <div className="relative z-10 px-2 py-1 flex items-center justify-center pointer-events-none">
                  <span className="text-[8.5px] xs:text-[9.5px] sm:text-xs font-black font-sans text-white text-center truncate drop-shadow-[0_2px_4px_rgba(0,0,0,1)] tracking-wide">
                    {card.card.name}
                  </span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ======================================================================= */}
        {/* LAYER 3: NEW TURQUOISE COMBAT ELEMENTS (Z-INDEX 30)                    */}
        {/* Appears after previous card exits downward                              */}
        {/* Enters vertically from top (translateY: -20px -> 0px, opacity: 0 -> 1)  */}
        {/* Settles into two vertically aligned turquoise combat elements holding   */}
        {/* ======================================================================= */}
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 sm:gap-4 pointer-events-none z-30">
          <AnimatePresence>
            {areNewTurquoiseElementsVisible && (
              <>
                {/* 1. First Turquoise Element (Top Combat Node) */}
                <motion.div
                  key="turquoise-node-top"
                  initial={{ y: -20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.35, ease: 'easeOut' }}
                  className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl border border-cyan-400/80 bg-cyan-950/80 shadow-[0_4px_18px_rgba(6,182,212,0.35)] backdrop-blur-md w-full max-w-[220px] xs:max-w-[260px] sm:max-w-[300px]"
                >
                  <div className="w-8 h-8 rounded-lg overflow-hidden border border-cyan-400 shrink-0 shadow-sm bg-slate-900">
                    {enemyCard ? (
                      <img src={enemyCard.card.imageUrl} alt={enemyCard.card.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-cyan-900/60 flex items-center justify-center text-cyan-300 font-bold text-[9px]">AI</div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between text-[8px] sm:text-[9px] font-mono font-black text-cyan-200">
                      <span className="truncate">{enemyCard ? enemyCard.card.name : (isAr ? 'الخصم' : 'ENEMY')}</span>
                      <span className="text-cyan-400 font-mono">{enemyCard ? `${enemyCard.currentHp} HP` : '100%'}</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-950/90 border border-cyan-500/40 overflow-hidden mt-0.5">
                      <div 
                        className="h-full bg-gradient-to-r from-teal-500 via-cyan-400 to-[#5eead4] rounded-full" 
                        style={{ width: enemyCard ? `${Math.round((enemyCard.currentHp / enemyCard.maxHp) * 100)}%` : '100%' }}
                      />
                    </div>
                  </div>
                </motion.div>

                {/* 2. Second Turquoise Element (Bottom Combat Node) */}
                <motion.div
                  key="turquoise-node-bottom"
                  initial={{ y: -16, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.35, delay: 0.12, ease: 'easeOut' }}
                  className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl border border-cyan-400/80 bg-cyan-950/80 shadow-[0_4px_18px_rgba(6,182,212,0.35)] backdrop-blur-md w-full max-w-[220px] xs:max-w-[260px] sm:max-w-[300px]"
                >
                  <div className="w-8 h-8 rounded-lg overflow-hidden border border-cyan-400 shrink-0 shadow-sm bg-slate-900">
                    {playerCard ? (
                      <img src={playerCard.card.imageUrl} alt={playerCard.card.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-teal-900/60 flex items-center justify-center text-teal-300 font-bold text-[9px]">YOU</div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between text-[8px] sm:text-[9px] font-mono font-black text-cyan-200">
                      <span className="truncate">{playerCard ? playerCard.card.name : (isAr ? 'أنت' : 'PLAYER')}</span>
                      <span className="text-[#5eead4] font-mono">{currentHp} HP</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-950/90 border border-cyan-500/40 overflow-hidden mt-0.5">
                      <div 
                        className="h-full bg-gradient-to-r from-teal-500 via-cyan-400 to-[#5eead4] rounded-full" 
                        style={{ width: `${hpPct}%` }}
                      />
                    </div>
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>

      </div>

      {/* Battlefield Bottom Status Indicator */}
      <div className="w-full flex items-center justify-between px-3 py-0.5 border-t border-cyan-500/15 z-10 shrink-0 bg-slate-950/30 rounded-b-xl text-[7.5px] sm:text-[8.5px] font-mono text-cyan-300/80">
        <span>{phase === 'SETTLED_HOLD' ? (isAr ? 'الحالة: استقرار النزال' : 'STATE: STABLE BATTLEFIELD') : (isAr ? 'الحالة: تنفيذ الهجوم' : 'STATE: COMBAT RESOLUTION')}</span>
        <span>{isAr ? 'نظام حركة ثنائي الأبعاد' : 'POLISHED 2D BATTLE ENGINE'}</span>
      </div>

    </div>
  );
};
