import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { StoryBattleDefinition } from '../../types/story';
import { CollectibleCardData } from '../../types/cards';
import { PlayerDeck } from '../../types/decks';
import { Swords, Shield, Heart, Zap, X, Skull, Crown, AlertTriangle } from 'lucide-react';

interface PreBattleConfirmationModalProps {
  isOpen: boolean;
  battle: StoryBattleDefinition;
  playerCards: CollectibleCardData[];
  enemyCards: CollectibleCardData[];
  activeDeck?: PlayerDeck | null;
  onConfirm: () => void;
  onCancel: () => void;
  isAr: boolean;
}

export const PreBattleConfirmationModal: React.FC<PreBattleConfirmationModalProps> = ({
  isOpen,
  battle,
  playerCards,
  enemyCards,
  activeDeck,
  onConfirm,
  onCancel,
  isAr
}) => {
  if (!isOpen) return null;

  // Player Stats Overall
  const playerOverallAtk = playerCards.reduce((sum, c) => sum + (c.attack || 0), 0);
  const playerOverallHp = playerCards.reduce((sum, c) => sum + (c.defense || c.health || 0), 0);
  const playerOverallPower = activeDeck?.power || Math.round((playerOverallAtk * 1.5) + playerOverallHp);

  // Enemy Stats Overall
  const enemyOverallAtk = enemyCards.reduce((sum, c) => sum + (c.attack || 0), 0);
  const enemyOverallHp = enemyCards.reduce((sum, c) => sum + (c.defense || c.health || 0), 0);
  const enemyOverallPower = Math.round((enemyOverallAtk * 1.5) + enemyOverallHp);

  const isBoss = battle.difficulty === 'BOSS';
  const isFinale = battle.difficulty === 'CHAPTER_FINALE' || battle.isChapterFinale;

  const getGridCols = (count: number) => {
    if (count === 1) return 'grid-cols-1 max-w-[80px] mx-auto';
    if (count === 2) return 'grid-cols-2 max-w-[170px] mx-auto';
    if (count === 3) return 'grid-cols-3 max-w-[260px] mx-auto';
    return 'grid-cols-4';
  };

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center p-2.5 xs:p-3 sm:p-4 bg-black/85 backdrop-blur-md select-none overflow-y-auto"
        dir={isAr ? 'rtl' : 'ltr'}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 15 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 15 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          className="relative w-full max-w-2xl bg-gradient-to-b from-[#06181c] via-[#030e11] to-[#01080a] border-2 border-cyan-500/50 rounded-2xl sm:rounded-3xl shadow-[0_25px_80px_rgba(0,0,0,0.9),0_0_40px_rgba(20,184,166,0.2)] p-3.5 sm:p-6 overflow-hidden my-auto max-h-[92dvh] overflow-y-auto"
        >
          {/* Top ambient glow line */}
          <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-[#5eead4] to-transparent opacity-90" />

          {/* Close / Cancel Button */}
          <button
            type="button"
            onClick={onCancel}
            className="absolute top-3 right-3 sm:top-4 sm:right-4 p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer border border-white/10 z-10"
          >
            <X size={16} />
          </button>

          {/* Header Title & Prompt */}
          <div className="text-center mb-3 sm:mb-4 px-6">
            <span className="text-[10px] sm:text-xs font-mono font-bold tracking-widest text-cyan-300 uppercase block mb-1">
              {isAr ? 'تأكيد المعركة' : 'BATTLE CONFRONTATION'}
            </span>
            <h2 className="text-base sm:text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-white to-teal-300 uppercase font-sans">
              {isAr ? 'هل أنت متأكد أنك تريد البدء؟' : 'Are you sure you want to start?'}
            </h2>
            <p className="text-[10px] sm:text-xs text-slate-400 font-mono mt-0.5">
              {isAr && battle.nameAr ? battle.nameAr : battle.name} · <span className="text-amber-400 font-bold uppercase">{battle.difficulty}</span>
            </p>
          </div>

          {/* Main Confrontation Comparison Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 sm:gap-4 mb-4">
            
            {/* 1. USER DECK COLUMN */}
            <div className="rounded-xl sm:rounded-2xl border border-cyan-500/40 bg-gradient-to-b from-cyan-950/20 to-black/60 p-2.5 sm:p-3 flex flex-col justify-between">
              {/* Header */}
              <div className="flex items-center justify-between pb-1.5 border-b border-cyan-500/20 mb-2">
                <div className="flex items-center gap-1.5">
                  <Shield size={14} className="text-[#5eead4]" />
                  <span className="text-xs font-black text-white uppercase font-sans">
                    {isAr ? 'تشكيلتك' : 'YOUR DECK'}
                  </span>
                </div>
                <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded-md bg-cyan-500/20 text-[#5eead4] border border-cyan-500/40">
                  PWR {playerOverallPower}
                </span>
              </div>

              {/* Cards Miniature Strip */}
              <div className={`grid ${getGridCols(playerCards.slice(0, 4).length)} gap-1.5 mb-2`}>
                {playerCards.slice(0, 4).map((card, idx) => (
                  <div key={card.id || idx} className="aspect-[5/7] rounded-lg overflow-hidden border border-cyan-500/30 relative bg-black/80">
                    <img src={card.imageUrl} alt={card.name} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent" />
                    <span className="absolute bottom-0.5 inset-x-0 text-center text-[7px] font-mono font-black text-cyan-300 drop-shadow truncate px-0.5">
                      {card.name}
                    </span>
                  </div>
                ))}
              </div>

              {/* Overall Summary Stats */}
              <div className="grid grid-cols-2 gap-1.5 text-center bg-black/50 p-1.5 rounded-xl border border-white/5 font-mono text-[10px] sm:text-xs">
                <div>
                  <span className="text-[8.5px] text-slate-400 block">{isAr ? 'إجمالي الهجوم' : 'Overall ATK'}</span>
                  <span className="font-bold text-amber-300">⚔️ {playerOverallAtk}</span>
                </div>
                <div>
                  <span className="text-[8.5px] text-slate-400 block">{isAr ? 'إجمالي الصحة' : 'Overall HP'}</span>
                  <span className="font-bold text-[#5eead4]">❤️ {playerOverallHp}</span>
                </div>
              </div>
            </div>

            {/* 2. ENEMY DECK COLUMN */}
            <div className="rounded-xl sm:rounded-2xl border border-purple-500/40 bg-gradient-to-b from-purple-950/20 to-black/60 p-2.5 sm:p-3 flex flex-col justify-between">
              {/* Header */}
              <div className="flex items-center justify-between pb-1.5 border-b border-purple-500/20 mb-2">
                <div className="flex items-center gap-1.5">
                  {isBoss ? <Skull size={14} className="text-rose-400" /> : <Swords size={14} className="text-purple-400" />}
                  <span className="text-xs font-black text-white uppercase font-sans">
                    {isAr ? 'تشكيلة الخصم' : 'ENEMY DECK'}
                  </span>
                </div>
                <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded-md bg-purple-500/20 text-purple-300 border border-purple-500/40">
                  PWR {enemyOverallPower}
                </span>
              </div>

              {/* Cards Miniature Strip */}
              <div className={`grid ${getGridCols(enemyCards.slice(0, 4).length)} gap-1.5 mb-2`}>
                {enemyCards.slice(0, 4).map((card, idx) => (
                  <div key={card.id || idx} className="aspect-[5/7] rounded-lg overflow-hidden border border-purple-500/30 relative bg-black/80">
                    <img src={card.imageUrl} alt={card.name} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent" />
                    <span className="absolute bottom-0.5 inset-x-0 text-center text-[7px] font-mono font-black text-purple-300 drop-shadow truncate px-0.5">
                      {card.name}
                    </span>
                  </div>
                ))}
              </div>

              {/* Overall Summary Stats */}
              <div className="grid grid-cols-2 gap-1.5 text-center bg-black/50 p-1.5 rounded-xl border border-white/5 font-mono text-[10px] sm:text-xs">
                <div>
                  <span className="text-[8.5px] text-slate-400 block">{isAr ? 'إجمالي الهجوم' : 'Overall ATK'}</span>
                  <span className="font-bold text-amber-300">⚔️ {enemyOverallAtk}</span>
                </div>
                <div>
                  <span className="text-[8.5px] text-slate-400 block">{isAr ? 'إجمالي الصحة' : 'Overall HP'}</span>
                  <span className="font-bold text-rose-400">❤️ {enemyOverallHp}</span>
                </div>
              </div>
            </div>

          </div>

          {/* Action Confirm / Cancel Buttons */}
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 font-black text-xs uppercase cursor-pointer transition-all"
            >
              {isAr ? 'تراجع' : 'Cancel'}
            </button>

            <button
              type="button"
              onClick={onConfirm}
              className="flex-2 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 via-cyan-400 to-[#5eead4] hover:brightness-110 active:scale-98 text-slate-950 font-black text-xs sm:text-sm uppercase cursor-pointer transition-all shadow-lg shadow-teal-500/30 flex items-center justify-center gap-2"
            >
              <Swords size={16} />
              <span>{isAr ? 'نعم، ابدأ النزال' : 'Yes, Start Fight'}</span>
            </button>
          </div>

        </motion.div>
      </div>
    </AnimatePresence>
  );
};
