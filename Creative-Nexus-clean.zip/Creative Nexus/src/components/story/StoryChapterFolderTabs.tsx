import React from 'react';
import { motion } from 'motion/react';
import { StoryChapterDefinition } from '../../types/story';
import { 
  Folder, FolderOpen, Plus, CheckCircle2, Lock, 
  Settings2, Layers, Trash2 
} from 'lucide-react';

interface StoryChapterFolderTabsProps {
  chapters: StoryChapterDefinition[];
  activeChapterId: string;
  onSelectChapter: (chapterId: string) => void;
  isBattleCompleted: (battleId: string) => boolean;
  isChapterUnlocked?: (chapterId: string) => boolean;
  isOwner: boolean;
  onNewChapter: () => void;
  onEditCurrentChapter: () => void;
  onDeleteCurrentChapter?: () => void;
  onAddBattleToCurrentChapter: () => void;
  isAr: boolean;
}

export const StoryChapterFolderTabs: React.FC<StoryChapterFolderTabsProps> = ({
  chapters,
  activeChapterId,
  onSelectChapter,
  isBattleCompleted,
  isChapterUnlocked,
  isOwner,
  onNewChapter,
  onEditCurrentChapter,
  onDeleteCurrentChapter,
  onAddBattleToCurrentChapter,
  isAr
}) => {
  const activeChapter = chapters.find(c => c.id === activeChapterId) || chapters[0];

  // Helper to calculate completion stats for a chapter
  const getChapterProgress = (chapter: StoryChapterDefinition) => {
    const total = chapter.battles.length;
    const completed = chapter.battles.filter(b => isBattleCompleted(b.id)).length;
    const isAllCompleted = total > 0 && completed === total;
    return { total, completed, isAllCompleted };
  };

  const checkUnlocked = (chapterId: string, idx: number) => {
    if (isChapterUnlocked) return isChapterUnlocked(chapterId);
    if (idx === 0) return true;
    return getChapterProgress(chapters[idx - 1]).isAllCompleted;
  };

  const isCurrentChapterUnlocked = activeChapter ? checkUnlocked(activeChapter.id, chapters.findIndex(c => c.id === activeChapter.id)) : true;
  const currentStats = activeChapter ? getChapterProgress(activeChapter) : { total: 0, completed: 0, isAllCompleted: false };
  const accent = activeChapter?.accentColor || '#2dd4bf';

  return (
    <div className="w-full mb-10 select-none" dir={isAr ? 'rtl' : 'ltr'}>
      {/* ========================================================================= */}
      {/* 1. TACTICAL DOSSIER FOLDER TABS RACK (Physical Folder Styling)            */}
      {/* ========================================================================= */}
      <div className="flex items-end gap-1.5 sm:gap-2 overflow-x-auto pb-0 px-2 sm:px-4 scrollbar-none pt-4">
        {chapters.map((chapter, idx) => {
          const isActive = chapter.id === activeChapterId;
          const { total, completed, isAllCompleted } = getChapterProgress(chapter);
          const chAccent = chapter.accentColor || '#2dd4bf';
          const isUnlocked = checkUnlocked(chapter.id, idx);

          return (
            <button
              key={chapter.id}
              type="button"
              onClick={() => {
                if (isUnlocked) onSelectChapter(chapter.id);
              }}
              className={`group relative flex items-center gap-2 sm:gap-2.5 px-3.5 sm:px-5 py-2.5 sm:py-3 transition-all duration-200 rounded-t-2xl font-mono shrink-0 border-t border-x ${
                !isUnlocked
                  ? 'bg-black/80 border-white/5 text-slate-600 opacity-60 cursor-not-allowed z-0'
                  : isActive
                    ? 'bg-gradient-to-b from-[#061b1e] to-[#031114] border-teal-500/40 text-white z-20 shadow-[0_-8px_20px_rgba(0,0,0,0.6)] translate-y-[1px] cursor-pointer'
                    : 'bg-black/50 hover:bg-white/[0.04] border-white/10 hover:border-white/20 text-slate-400 hover:text-slate-200 z-10 cursor-pointer'
              }`}
              style={{
                borderTopColor: isUnlocked && isActive ? chAccent : undefined
              }}
            >
              {/* Folder Notch Accent Tab */}
              <div 
                className="w-2 h-2 rounded-full shrink-0 transition-transform group-hover:scale-110"
                style={{ 
                  backgroundColor: !isUnlocked ? '#334155' : isActive ? chAccent : '#64748b',
                  boxShadow: isUnlocked && isActive ? `0 0 10px ${chAccent}` : 'none'
                }} 
              />

              {/* Folder Icon / Lock */}
              {!isUnlocked ? (
                <Lock size={14} className="text-slate-500 shrink-0" />
              ) : isActive ? (
                <FolderOpen size={16} style={{ color: chAccent }} className="shrink-0" />
              ) : (
                <Folder size={15} className="text-slate-500 group-hover:text-slate-300 shrink-0" />
              )}

              {/* Chapter Tab Label */}
              <div className="flex flex-col text-left items-start">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] sm:text-[11px] font-black tracking-wider uppercase">
                    {isAr ? `فصل ${idx + 1}` : `CH ${String(idx + 1).padStart(2, '0')}`}
                  </span>
                  
                  {!isUnlocked ? (
                    <span className="text-[8.5px] px-1 py-0.2 rounded bg-black/60 text-slate-500 font-bold border border-white/5">
                      {isAr ? 'مقفل' : 'LOCKED'}
                    </span>
                  ) : isAllCompleted ? (
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40">
                      ✓
                    </span>
                  ) : (
                    <span className="text-[9px] text-slate-500 font-mono">
                      {completed}/{total}
                    </span>
                  )}
                </div>

                <span className={`text-[11px] sm:text-xs font-bold font-sans truncate max-w-[120px] sm:max-w-[150px] ${
                  !isUnlocked ? 'text-slate-600' : isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'
                }`}>
                  {isAr ? chapter.titleAr || chapter.title : chapter.title}
                </span>
              </div>

              {/* Active Tab Underline Bridge */}
              {isUnlocked && isActive && (
                <div 
                  className="absolute -bottom-[2px] left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#061b1e] to-transparent z-30" 
                />
              )}
            </button>
          );
        })}

        {/* Owner Quick "New Chapter Folder" Button */}
        {isOwner && (
          <button
            type="button"
            onClick={onNewChapter}
            className="flex items-center gap-1.5 px-3 sm:px-4 py-2 sm:py-2.5 rounded-t-xl bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 hover:text-white border-t border-x border-purple-500/30 text-[11px] font-mono font-bold transition-all cursor-pointer shrink-0"
          >
            <Plus size={14} className="text-purple-400" />
            <span>{isAr ? '+ فصل جديد' : '+ New Folder'}</span>
          </button>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 2. OPEN CHAPTER FOLDER BODY (Dossier Interior & Banner)                   */}
      {/* ========================================================================= */}
      {activeChapter && (
        <motion.div
          key={activeChapter.id}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          className="relative rounded-b-3xl rounded-tr-3xl overflow-hidden bg-gradient-to-b from-[#061b1e] via-[#020f12] to-[#01080a] border border-teal-500/30 shadow-[0_15px_40px_rgba(0,0,0,0.8)]"
          style={{ borderColor: `${accent}40` }}
        >
          {/* Subtle Folder Spine & Stitching Details at the top */}
          <div className="h-1.5 w-full bg-gradient-to-r from-teal-500/20 via-white/10 to-teal-500/20 border-b border-white/5" />

          {/* USER REQUIREMENT: LOCKED CHAPTER BODY */}
          {!isCurrentChapterUnlocked ? (
            <div className="p-10 sm:p-16 flex flex-col items-center justify-center text-center space-y-3 bg-[#020507]/90">
              <div className="w-16 h-16 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center justify-center text-slate-500 shadow-2xl">
                <Lock size={28} />
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-slate-400 font-sans tracking-wide uppercase">
                {isAr ? 'هذا الفصل مقفل' : 'CHAPTER LOCKED'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 font-mono max-w-md">
                {isAr 
                  ? 'يجب إكمال كافة معارك الفصل السابق بنجاح لفتح واستكشاف هذا الفصل.' 
                  : 'You must conquer all battles in the previous chapter to unlock and explore this chapter.'}
              </p>
            </div>
          ) : (
            /* UNLOCKED CHAPTER BANNER & LORE */
            <div className="relative min-h-[140px] sm:min-h-[170px] p-5 sm:p-7 flex flex-col justify-between overflow-hidden">
              {/* Background Custom Banner with Vignette */}
              {activeChapter.bannerImageUrl ? (
                <div 
                  className="absolute inset-0 bg-cover bg-center pointer-events-none opacity-20 mix-blend-luminosity scale-105 transition-transform duration-700 hover:scale-100"
                  style={{ backgroundImage: `url(${activeChapter.bannerImageUrl})` }}
                />
              ) : null}
              <div className="absolute inset-0 bg-gradient-to-t from-[#020f12] via-[#020f12]/80 to-transparent pointer-events-none" />
              <div className="absolute inset-0 bg-gradient-to-r from-[#020f12] via-transparent to-[#020f12] pointer-events-none" />

              {/* Folder Header Content */}
              <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  {/* Chapter Meta Badges */}
                  <div className="flex items-center gap-2.5 flex-wrap mb-2">
                    <span 
                      className="text-[10px] font-mono font-black uppercase tracking-widest px-2.5 py-0.5 rounded-full border"
                      style={{ 
                        color: accent,
                        borderColor: `${accent}60`,
                        backgroundColor: `${accent}15`
                      }}
                    >
                      {isAr 
                        ? activeChapter.badgeTextAr || `الفصل ${activeChapter.chapterNumber}` 
                        : activeChapter.badgeText || `CHAPTER ${String(activeChapter.chapterNumber).padStart(2, '0')}`}
                    </span>

                    <span className="text-xs font-mono text-slate-400">
                      {isAr ? activeChapter.subtitleAr || activeChapter.subtitle : activeChapter.subtitle}
                    </span>

                    {currentStats.isAllCompleted && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-mono text-emerald-400 font-bold bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                        <CheckCircle2 size={12} />
                        <span>{isAr ? 'تم تحرير الفصل كاملاً' : 'Chapter Conquered'}</span>
                      </span>
                    )}
                  </div>

                  {/* Chapter Title */}
                  <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white font-sans tracking-tight">
                    {isAr ? activeChapter.titleAr || activeChapter.title : activeChapter.title}
                  </h2>

                  {/* Chapter Lore Dossier */}
                  <p className="text-xs sm:text-sm text-slate-300/90 font-sans max-w-2xl mt-2 leading-relaxed">
                    {isAr ? activeChapter.descriptionAr || activeChapter.description : activeChapter.description}
                  </p>
                </div>

                {/* Right Side: Chapter Progress Gauge & Owner Controls */}
                <div className="flex flex-col items-start md:items-end gap-3 shrink-0">
                  {/* Progress Mini Meter */}
                  <div className="px-4 py-2.5 rounded-2xl bg-black/60 border border-white/10 backdrop-blur-sm text-right">
                    <div className="flex items-center justify-between gap-4 text-xs font-mono mb-1.5">
                      <span className="text-slate-400">
                        {isAr ? 'تقدم المسار:' : 'Journey Progress:'}
                      </span>
                      <span className="font-bold text-[#5eead4]">
                        {currentStats.completed} / {currentStats.total}
                      </span>
                    </div>

                    <div className="w-36 sm:w-44 h-2 rounded-full bg-slate-900 border border-white/10 overflow-hidden p-0.5">
                      <div 
                        className="h-full rounded-full transition-all duration-500"
                        style={{ 
                          width: `${currentStats.total > 0 ? (currentStats.completed / currentStats.total) * 100 : 0}%`,
                          backgroundColor: accent,
                          boxShadow: `0 0 10px ${accent}`
                        }}
                      />
                    </div>
                  </div>

                  {/* Owner Controls on Folder (Edit / Add / Delete) */}
                  {isOwner && (
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={onAddBattleToCurrentChapter}
                        className="px-3 py-1.5 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 text-[#5eead4] border border-teal-500/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                        title={isAr ? 'إضافة معركة جديدة لهذا الفصل' : 'Add Fight to this Chapter'}
                      >
                        <Layers size={13} />
                        <span>{isAr ? '+ معركة' : '+ Fight'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={onEditCurrentChapter}
                        className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 transition-colors cursor-pointer"
                        title={isAr ? 'تعديل بيانات الفصل' : 'Edit Chapter'}
                      >
                        <Settings2 size={14} />
                      </button>

                      {onDeleteCurrentChapter && (
                        <button
                          type="button"
                          onClick={onDeleteCurrentChapter}
                          className="p-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 transition-colors cursor-pointer"
                          title={isAr ? 'حذف هذا الفصل' : 'Delete Chapter'}
                        >
                          <Trash2 size={14} />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
};
