import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { UnifiedItemDefinition } from '../../types/items';
import { useItems } from '../../context/ItemContext';
import { X, Heart, Wind, Shield, Swords, Sparkles, Check, AlertCircle, Backpack } from 'lucide-react';

interface BattleItemsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUseItem: (item: UnifiedItemDefinition) => void;
  usedItemsInBattle: Record<string, number>;
  activePlayerHp: number;
  activePlayerMaxHp: number;
  activePlayerStamina: number;
  activePlayerMaxStamina: number;
  isAr: boolean;
}

export const BattleItemsModal: React.FC<BattleItemsModalProps> = ({
  isOpen,
  onClose,
  onUseItem,
  usedItemsInBattle,
  activePlayerHp,
  activePlayerMaxHp,
  activePlayerStamina,
  activePlayerMaxStamina,
  isAr
}) => {
  const { inventory } = useItems();

  if (!isOpen) return null;

  // Filter inventory for battle consumables
  const battleConsumables = inventory
    .filter(entry => entry.count > 0 && entry.itemData?.category === 'BATTLE' && entry.itemData?.battleEffect)
    .map(entry => ({
      item: entry.itemData as UnifiedItemDefinition,
      count: entry.count,
      usedCount: usedItemsInBattle[entry.itemId] || 0
    }));

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md"
        dir={isAr ? 'rtl' : 'ltr'}
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 15 }}
          transition={{ type: 'spring', damping: 25, stiffness: 320 }}
          className="relative w-full max-w-md max-h-[85vh] rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-black border border-cyan-500/40 shadow-[0_20px_60px_rgba(0,0,0,0.9),0_0_30px_rgba(94,234,212,0.25)] flex flex-col overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between bg-white/[0.03]">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-teal-400 p-0.5 shadow-[0_0_12px_rgba(94,234,212,0.6)] flex items-center justify-center">
                <Backpack size={16} className="text-slate-950" />
              </div>
              <div>
                <h3 className="text-sm font-black text-white font-sans tracking-wide">
                  {isAr ? 'حقيبة عناصر المعركة' : 'Combat Consumables'}
                </h3>
                <p className="text-[10px] text-cyan-300/80 font-mono">
                  {isAr ? 'جرعات، دروع، وتعزيزات تكتيكية' : 'Potions, Shields & Combat Boosters'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 border border-white/10 transition-colors cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>

          {/* Quick Active Card Status */}
          <div className="px-4 py-2 bg-slate-950/60 border-b border-white/5 flex items-center justify-between text-[11px] font-mono">
            <div className="flex items-center gap-1.5 text-cyan-300">
              <Heart size={12} className="text-rose-400 fill-rose-400/30" />
              <span>{isAr ? 'صحة المقاتل:' : 'Card HP:'}</span>
              <span className="font-bold text-white">{activePlayerHp} / {activePlayerMaxHp}</span>
            </div>
            <div className="flex items-center gap-1.5 text-emerald-300">
              <Wind size={12} className="text-emerald-400" />
              <span>{isAr ? 'الجهد:' : 'Stamina:'}</span>
              <span className="font-bold text-white">{activePlayerStamina} / {activePlayerMaxStamina}</span>
            </div>
          </div>

          {/* Consumables List */}
          <div className="p-3.5 space-y-2.5 overflow-y-auto max-h-[60vh] custom-scrollbar">
            {battleConsumables.length === 0 ? (
              <div className="p-8 text-center flex flex-col items-center justify-center space-y-2">
                <Backpack size={36} className="text-slate-600 animate-pulse" />
                <p className="text-xs font-bold text-slate-400 font-sans">
                  {isAr ? 'لا تملك عناصر معركة في حقيبتك حالياً' : 'No battle consumables in your inventory'}
                </p>
                <p className="text-[10px] text-slate-500 font-sans max-w-xs">
                  {isAr 
                    ? 'يمكنك الحصول على جرعات العلاج والدروع من الحزم في المتجر أو عبر مكافآت البطاقات المكررة!' 
                    : 'Open booster packs in the Card Vault or convert duplicate cards to obtain battle items!'}
                </p>
              </div>
            ) : (
              battleConsumables.map(({ item, count, usedCount }) => {
                const effect = item.battleEffect!;
                const maxUses = effect.maxUsesPerBattle || 1;
                const isLimitReached = usedCount >= maxUses;
                const isConsumesTurn = Boolean(effect.consumesTurn);

                // Disable conditions
                let disableReason: string | null = null;
                if (isLimitReached) {
                  disableReason = isAr ? 'استُخدم الحد الأقصى في هذه المعركة' : 'Max uses reached this battle';
                } else if (effect.type === 'HEAL_HP' && activePlayerHp >= activePlayerMaxHp) {
                  disableReason = isAr ? 'صحة المقاتل مكتملة' : 'HP already full';
                } else if (effect.type === 'RESTORE_STAMINA' && activePlayerStamina >= activePlayerMaxStamina) {
                  disableReason = isAr ? 'الجهد مكتمل' : 'Stamina already full';
                }

                const canUse = !disableReason && count > 0;

                // Color accent by effect type
                const effectColor = 
                  effect.type === 'HEAL_HP' ? 'border-emerald-500/40 from-emerald-950/40 text-emerald-300' :
                  effect.type === 'RESTORE_STAMINA' ? 'border-cyan-500/40 from-cyan-950/40 text-cyan-300' :
                  effect.type === 'GRANT_SHIELD' ? 'border-blue-500/40 from-blue-950/40 text-blue-300' :
                  effect.type === 'BUFF_ATTACK' ? 'border-amber-500/40 from-amber-950/40 text-amber-300' :
                  'border-purple-500/40 from-purple-950/40 text-purple-300';

                return (
                  <div
                    key={item.id}
                    className={`p-3 rounded-2xl bg-gradient-to-r via-slate-900/90 to-black border transition-all ${effectColor} shadow-md flex items-center justify-between gap-3`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="relative w-12 h-12 rounded-xl bg-black/60 border border-white/10 p-1 flex items-center justify-center shrink-0 overflow-hidden shadow-inner">
                        <img
                          src={item.imageUrl}
                          alt={item.name}
                          className="w-full h-full object-contain filter drop-shadow"
                        />
                        <span className="absolute bottom-0 right-0 px-1 py-0.2 rounded-tl-md bg-black/90 font-mono font-bold text-[9px] text-white border-t border-l border-white/20">
                          x{count}
                        </span>
                      </div>

                      <div className="min-w-0 space-y-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h4 className="text-xs font-bold text-white truncate max-w-[170px] font-sans">
                            {isAr && item.nameAr ? item.nameAr : item.name}
                          </h4>
                          <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-black/50 border border-white/10 text-slate-300">
                            {maxUses - usedCount}/{maxUses} {isAr ? 'متبقٍ' : 'left'}
                          </span>
                        </div>

                        {/* Effect Badge */}
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className={`px-2 py-0.5 rounded-full font-mono font-bold text-[10px] flex items-center gap-1 bg-black/60 border border-white/10`}>
                            {effect.type === 'HEAL_HP' && <Heart size={10} className="text-emerald-400 fill-emerald-400" />}
                            {effect.type === 'RESTORE_STAMINA' && <Wind size={10} className="text-cyan-400" />}
                            {effect.type === 'GRANT_SHIELD' && <Shield size={10} className="text-blue-400 fill-blue-400/30" />}
                            {effect.type === 'BUFF_ATTACK' && <Swords size={10} className="text-amber-400" />}
                            {effect.type === 'BUFF_DEFENSE' && <Shield size={10} className="text-purple-400" />}
                            <span>
                              {effect.type === 'HEAL_HP' ? `+${effect.value} HP` :
                               effect.type === 'RESTORE_STAMINA' ? `+${effect.value} STM` :
                               effect.type === 'GRANT_SHIELD' ? `+${effect.value} Shield` :
                               effect.type === 'BUFF_ATTACK' ? `+${effect.value}% ATK (${effect.durationTurns || 2}T)` :
                               `+${effect.value}% DEF (${effect.durationTurns || 2}T)`}
                            </span>
                          </span>

                          <span className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded ${
                            isConsumesTurn 
                              ? 'bg-amber-950/60 text-amber-300 border border-amber-500/30' 
                              : 'bg-teal-950/60 text-teal-300 border border-teal-500/30'
                          }`}>
                            {isConsumesTurn ? (isAr ? 'يستهلك جولة' : 'Consumes Turn') : (isAr ? 'حركة حرة' : 'Free Action')}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Use Button */}
                    <div className="shrink-0 flex flex-col items-end gap-1">
                      <button
                        type="button"
                        disabled={!canUse}
                        onClick={() => onUseItem(item)}
                        className={`px-3 py-1.5 rounded-xl font-mono font-bold text-xs transition-all shadow-md active:scale-95 cursor-pointer ${
                          canUse
                            ? 'bg-gradient-to-r from-cyan-500 via-teal-400 to-cyan-500 text-slate-950 hover:brightness-110 shadow-[0_0_14px_rgba(94,234,212,0.5)]'
                            : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed opacity-50'
                        }`}
                      >
                        {isAr ? 'استخدام' : 'USE'}
                      </button>

                      {disableReason && (
                        <span className="text-[8.5px] text-rose-400 font-sans max-w-[90px] text-right truncate">
                          {disableReason}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
