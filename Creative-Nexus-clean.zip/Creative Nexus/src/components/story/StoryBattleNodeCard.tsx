import React from 'react';
import { motion } from 'motion/react';
import { StoryBattleDefinition, BattleDifficulty } from '../../types/story';
import { CollectibleCardData } from '../../types/cards';
import { MODERN_CARD_ASSETS } from '../../assets/modernCardAssets';
import { 
  Swords, Shield, Zap, Lock, CheckCircle, Flame, 
  Coins, Sparkles, Trophy, Edit, Trash2, Loader2, Crown, Skull
} from 'lucide-react';

interface StoryBattleNodeCardProps {
  battle: StoryBattleDefinition;
  chapterNumber: number;
  stepNumber: number;
  totalBattles: number;
  isUnlocked: boolean;
  isCompleted: boolean;
  hasClaimedFirstClear: boolean;
  enemyCards: CollectibleCardData[];
  isOwner: boolean;
  isDeleting?: boolean;
  isAr: boolean;
  accentColor?: string;
  onSelect: (battle: StoryBattleDefinition) => void;
  onEdit?: (e: React.MouseEvent, battle: StoryBattleDefinition) => void;
  onDelete?: (e: React.MouseEvent, battleId: string, battleName: string) => void;
}

export const StoryBattleNodeCard: React.FC<StoryBattleNodeCardProps> = ({
  battle,
  chapterNumber,
  stepNumber,
  totalBattles,
  isUnlocked,
  isCompleted,
  hasClaimedFirstClear,
  enemyCards,
  isOwner,
  isDeleting = false,
  isAr,
  accentColor = '#2dd4bf',
  onSelect,
  onEdit,
  onDelete
}) => {
  const isBoss = battle.difficulty === 'BOSS';
  const isElite = battle.difficulty === 'ELITE';
  const isHard = battle.difficulty === 'HARD';
  const totalCoins = battle.rewardCoins + battle.firstClearBonusCoins;

  // Difficulty color styling
  const diffBadgeClass = isBoss
    ? 'bg-rose-500/20 text-rose-300 border-rose-500/50'
    : isElite
    ? 'bg-purple-500/20 text-purple-300 border-purple-500/50'
    : isHard
    ? 'bg-orange-500/20 text-orange-300 border-orange-500/50'
    : 'bg-teal-500/20 text-teal-300 border-teal-500/50';

  const nodeBorderClass = !isUnlocked
    ? 'border-white/10 bg-black/40 opacity-60'
    : isCompleted
    ? 'border-teal-500/40 bg-gradient-to-r from-[#041c1e] via-[#021114] to-black hover:border-teal-400'
    : isBoss
    ? 'border-rose-500/60 bg-gradient-to-r from-[#20050b] via-[#100306] to-black shadow-rose-950/40 ring-1 ring-rose-500/30'
    : 'border-amber-500/50 bg-gradient-to-r from-[#141a06] via-[#091515] to-black ring-1 ring-amber-500/30 shadow-xl';

  return (
    <div className="relative flex items-center justify-between gap-4 py-2 sm:py-3">
      {/* Waypoint Rune Orb on SVG Track (Center on Desktop) */}
      <div 
        className="absolute left-6 sm:left-1/2 -translate-x-1/2 w-8 h-8 rounded-full border-2 z-20 hidden sm:flex items-center justify-center transition-transform group-hover:scale-110 shadow-lg"
        style={{
          borderColor: isCompleted ? '#10b981' : isUnlocked ? (isBoss ? '#f43f5e' : '#f59e0b') : '#475569',
          backgroundColor: '#031417'
        }}
      >
        {isCompleted ? (
          <CheckCircle size={14} className="text-emerald-400" />
        ) : !isUnlocked ? (
          <Lock size={12} className="text-slate-500" />
        ) : isBoss ? (
          <Skull size={14} className="text-rose-400 animate-pulse" />
        ) : (
          <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
        )}
      </div>

      {/* Main Battle Pedestal Node Card */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.35 }}
        onClick={() => isUnlocked && onSelect(battle)}
        className={`w-full rounded-3xl border p-4 sm:p-5 transition-all duration-300 relative overflow-hidden group shadow-2xl ${
          isUnlocked ? 'cursor-pointer hover:scale-[1.01]' : 'cursor-not-allowed'
        } ${nodeBorderClass}`}
      >
        {/* Top Glow Line */}
        <div 
          className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-current to-transparent opacity-40 pointer-events-none"
          style={{ color: isCompleted ? '#10b981' : isBoss ? '#f43f5e' : accentColor }}
        />

        {!isUnlocked ? (
          <div className="py-8 sm:py-10 flex flex-col items-center justify-center text-center w-full">
            <div className="w-10 h-10 rounded-2xl bg-white/[0.03] border border-white/5 flex items-center justify-center text-slate-600 mb-2">
              <Lock size={16} />
            </div>
            <span className="font-mono text-xs tracking-widest uppercase font-bold text-slate-500">
              {isAr ? 'مغلق' : 'LOCKED'}
            </span>
          </div>
        ) : (
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          {/* Left: Commander Portrait & Battle Info */}
          <div className="flex items-start gap-4 min-w-0 flex-1">
            {/* Commander Frame */}
            <div className="relative w-16 h-20 sm:w-20 sm:h-26 rounded-2xl overflow-hidden border-2 shrink-0 shadow-lg bg-black group-hover:scale-103 transition-transform"
              style={{
                borderColor: isCompleted ? '#10b981' : isBoss ? '#f43f5e' : '#f59e0b'
              }}
            >
              <img
                src={battle.enemyCommanderAvatar || MODERN_CARD_ASSETS.cardApexSovereign}
                alt={battle.enemyCommanderName}
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = MODERN_CARD_ASSETS.cardApexSovereign;
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-transparent" />
              
              {/* Mini difficulty indicator on portrait */}
              <div className="absolute bottom-1 inset-x-0 text-center">
                <span className="text-[9px] font-mono font-bold text-white uppercase drop-shadow">
                  #{battle.battleNumber || stepNumber}
                </span>
              </div>
            </div>

            {/* Info Column */}
            <div className="space-y-1.5 min-w-0 flex-1">
              {/* Badges Bar */}
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-lg bg-black/80 border border-white/10 text-xs font-mono font-black text-amber-300 shadow-sm">
                  {isAr ? `معركة #${battle.battleNumber || stepNumber}` : `Trial #${battle.battleNumber || stepNumber}`}
                </span>

                <span className={`px-2 py-0.5 rounded-lg text-[10px] font-mono font-extrabold border uppercase ${diffBadgeClass}`}>
                  {battle.difficulty}
                </span>

                {isCompleted && (
                  <span className="px-2 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-mono font-bold flex items-center gap-1">
                    <CheckCircle size={11} />
                    <span>{isAr ? 'تم الانتصار' : 'Cleared'}</span>
                  </span>
                )}
              </div>

              {/* Battle Title & Character Name */}
              <div>
                <h3 className="text-base sm:text-lg font-black text-white font-sans tracking-tight truncate group-hover:text-[#5eead4] transition-colors">
                  {isAr ? battle.nameAr || battle.name : battle.name}
                </h3>
                <span className="text-xs font-mono text-slate-400 block truncate">
                  {isAr ? 'القائد الخصم: ' : 'Commander: '}
                  <strong className="text-amber-300 font-sans">
                    {isAr 
                      ? battle.customCharacterNameAr || battle.enemyCommanderNameAr || battle.enemyCommanderName 
                      : battle.customCharacterName || battle.enemyCommanderName}
                  </strong>
                </span>
              </div>

              {/* Description */}
              <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed font-sans max-w-xl">
                {isAr ? battle.descriptionAr || battle.description : battle.description}
              </p>
            </div>
          </div>

          {/* Center: 4-Card Hostile Squad Preview */}
          <div className="p-2.5 rounded-2xl bg-black/60 border border-white/5 space-y-1.5 shrink-0 self-stretch lg:self-auto min-w-[200px] sm:min-w-[240px]">
            <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
              <span className="flex items-center gap-1">
                <Swords size={11} className="text-rose-400" />
                <span>{isAr ? 'التشكيل الرباعي للخصم:' : 'Hostile 4-Card Squad:'}</span>
              </span>
              <span>{battle.enemyDeckCardIds.length}/4</span>
            </div>

            <div className="grid grid-cols-4 gap-1.5">
              {[0, 1, 2, 3].map(slotIdx => {
                const card = enemyCards[slotIdx];
                return (
                  <div
                    key={slotIdx}
                    className={`aspect-[4/5] rounded-lg border overflow-hidden relative flex flex-col justify-end p-0.5 ${
                      card ? 'bg-black/90 border-teal-500/40' : 'bg-black/30 border-dashed border-white/10'
                    }`}
                  >
                    {card ? (
                      <>
                        <img src={card.imageUrl} alt={card.name} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent" />
                        <span className="relative z-10 text-[8px] font-mono text-amber-300 truncate font-bold text-center block">
                          ⚔️{card.attack}
                        </span>
                      </>
                    ) : (
                      <span className="text-[8px] text-slate-600 text-center block m-auto">-</span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Rewards & Action / Owner Controls */}
          <div className="flex flex-col sm:flex-row lg:flex-col items-end justify-between gap-3 shrink-0">
            {/* Rewards Strip */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-1 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-mono font-bold flex items-center gap-1">
                <Coins size={13} className="text-amber-400" />
                <span>+{isCompleted ? battle.rewardCoins : totalCoins}</span>
              </span>

              <span className="px-2.5 py-1 rounded-xl bg-teal-500/15 border border-teal-500/30 text-teal-300 text-xs font-mono font-bold flex items-center gap-1">
                <Trophy size={13} className="text-teal-400" />
                <span>+{battle.rewardXp} XP</span>
              </span>

              {!hasClaimedFirstClear && (
                <span className="px-2 py-0.5 rounded-lg bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[10px] font-mono font-bold flex items-center gap-1">
                  <Sparkles size={11} />
                  <span>{isAr ? 'مكافأة أول فوز' : 'First-Clear Bonus'}</span>
                </span>
              )}
            </div>

            {/* Launch / Status Button & Owner Controls */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              {/* Owner Action Buttons */}
              {isOwner && (
                <div className="flex items-center gap-1 bg-black/60 p-1 rounded-xl border border-white/10 shrink-0">
                  {onEdit && (
                    <button
                      type="button"
                      onClick={(e) => onEdit(e, battle)}
                      className="p-2 rounded-lg bg-purple-500/20 hover:bg-purple-500/40 text-purple-300 border border-purple-500/30 transition-all cursor-pointer"
                      title={isAr ? 'تعديل المعركة' : 'Edit Battle'}
                    >
                      <Edit size={13} />
                    </button>
                  )}

                  {onDelete && (
                    <button
                      type="button"
                      disabled={isDeleting}
                      onClick={(e) => onDelete(e, battle.id, battle.name)}
                      className="p-2 rounded-lg bg-rose-500/20 hover:bg-rose-500/40 text-rose-300 border border-rose-500/30 transition-all cursor-pointer disabled:opacity-40"
                      title={isAr ? 'إزالة المعركة' : 'Delete Battle'}
                    >
                      {isDeleting ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
                    </button>
                  )}
                </div>
              )}

              {/* Status Action Button */}
              {isCompleted ? (
                <button
                  type="button"
                  onClick={() => onSelect(battle)}
                  className="w-full sm:w-auto px-4 py-2 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 text-[#5eead4] border border-teal-500/40 text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <Swords size={14} />
                  <span>{isAr ? 'إعادة النزال' : 'Replay Trial'}</span>
                </button>
              ) : !isUnlocked ? (
                <div className="w-full sm:w-auto px-4 py-2 rounded-xl bg-black/60 border border-white/10 text-slate-500 text-xs font-mono flex items-center justify-center gap-1.5">
                  <Lock size={12} />
                  <span>{isAr ? 'مغلق (أكمل السابق)' : 'Locked'}</span>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => onSelect(battle)}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-orange-500 hover:brightness-110 active:scale-98 text-black font-extrabold text-xs font-mono flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 transition-all cursor-pointer animate-pulse"
                >
                  <Flame size={14} />
                  <span>{isAr ? 'خوض النزال الآن' : 'Engage Battle'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
        )}
      </motion.div>
    </div>
  );
};
