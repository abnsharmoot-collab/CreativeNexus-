import React from 'react';
import { motion } from 'motion/react';

interface StoryJourneyMapConnectingPathProps {
  isAr?: boolean;
  accentColor?: string;
}

export const StoryJourneyMapConnectingPath: React.FC<StoryJourneyMapConnectingPathProps> = ({
  accentColor = '#2dd4bf'
}) => {
  return (
    <div 
      className="absolute top-4 bottom-4 left-6 sm:left-1/2 -translate-x-1/2 w-8 pointer-events-none z-0 hidden sm:flex flex-col items-center justify-between"
      aria-hidden="true"
    >
      {/* Background spine track flowing through all chapter theme colors */}
      <div className="absolute inset-y-0 w-1.5 bg-gradient-to-b from-teal-500/50 via-amber-500/50 via-purple-500/50 to-rose-500/50 rounded-full" />
      
      {/* Outer ambient glow track */}
      <div className="absolute inset-y-0 w-6 bg-gradient-to-b from-teal-500/20 via-amber-500/20 via-purple-500/20 to-rose-500/25 blur-md rounded-full" />

      {/* Downward Traveling Energy Pulse */}
      <motion.div
        animate={{
          y: ['-100%', '900%'],
          opacity: [0, 1, 1, 0]
        }}
        transition={{
          duration: 5.5,
          repeat: Infinity,
          ease: 'linear'
        }}
        className="absolute w-2.5 h-44 bg-gradient-to-b from-transparent via-[#5eead4] via-amber-300 to-white rounded-full shadow-[0_0_24px_rgba(94,234,212,0.9)]"
      />

      {/* Secondary softer wave traveling along the progression */}
      <motion.div
        animate={{
          y: ['-50%', '800%'],
          opacity: [0, 0.8, 0.8, 0]
        }}
        transition={{
          duration: 7,
          delay: 2,
          repeat: Infinity,
          ease: 'linear'
        }}
        className="absolute w-2 h-32 bg-gradient-to-b from-transparent via-purple-400 via-rose-300 to-white rounded-full shadow-[0_0_16px_rgba(168,85,247,0.8)]"
      />
    </div>
  );
};

