import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { StoryChapterDefinition } from '../../types/story';
import { useLanguage } from '../../context/LanguageContext';
import { compressImageFile } from '../../utils/imageCompressor';
import { MESOPOTAMIAN_ASSETS } from '../../assets/mesopotamianAssets';
import { 
  X, BookOpen, Sparkles, Image as ImageIcon, Upload, 
  Trash2, AlertCircle, Loader2, Check, Palette, Layers, Plus
} from 'lucide-react';

interface StoryChapterEditorModalProps {
  isOpen: boolean;
  chapterToEdit: StoryChapterDefinition | null;
  onClose: () => void;
  onSave: (chapterData: Partial<StoryChapterDefinition>) => Promise<{ success: boolean; error?: string }>;
  onDelete?: (chapterId: string) => Promise<{ success: boolean; error?: string }>;
  canDelete?: boolean;
}

const PRESET_CHAPTER_BANNERS = [
  { id: 'meso_hero', name: 'Mesopotamian Obsidian Temple', url: MESOPOTAMIAN_ASSETS.heroBg },
  { id: 'meso_frieze', name: 'Golden Cuneiform Frieze', url: MESOPOTAMIAN_ASSETS.friezeBanner },
  { id: 'meso_lamassu', name: 'Celestial Winged Lamassu', url: MESOPOTAMIAN_ASSETS.lamassuRelief },
  { id: 'meso_king', name: 'High King of Ur & Babylon', url: MESOPOTAMIAN_ASSETS.kingRelief },
  { id: 'meso_eagle', name: 'Sun-Eagle Ancient Seal', url: MESOPOTAMIAN_ASSETS.eagleRelief }
];

const PRESET_ACCENT_COLORS = [
  { label: 'Cyan Teal', value: '#2dd4bf', bg: 'bg-[#2dd4bf]' },
  { label: 'Amber Gold', value: '#f59e0b', bg: 'bg-[#f59e0b]' },
  { label: 'Royal Violet', value: '#a855f7', bg: 'bg-[#a855f7]' },
  { label: 'Crimson Rose', value: '#f43f5e', bg: 'bg-[#f43f5e]' },
  { label: 'Emerald Jade', value: '#10b981', bg: 'bg-[#10b981]' },
  { label: 'Celestial Blue', value: '#38bdf8', bg: 'bg-[#38bdf8]' }
];

export const StoryChapterEditorModal: React.FC<StoryChapterEditorModalProps> = ({
  isOpen,
  chapterToEdit,
  onClose,
  onSave,
  onDelete,
  canDelete = false
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [title, setTitle] = useState('');
  const [titleAr, setTitleAr] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [subtitleAr, setSubtitleAr] = useState('');
  const [description, setDescription] = useState('');
  const [descriptionAr, setDescriptionAr] = useState('');
  const [bannerImageUrl, setBannerImageUrl] = useState('');
  const [accentColor, setAccentColor] = useState('#2dd4bf');
  const [badgeText, setBadgeText] = useState('PROVING GROUNDS');
  const [badgeTextAr, setBadgeTextAr] = useState('ساحات الإثبات');

  const [isCompressing, setIsCompressing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (chapterToEdit) {
      setTitle(chapterToEdit.title || '');
      setTitleAr(chapterToEdit.titleAr || chapterToEdit.title || '');
      setSubtitle(chapterToEdit.subtitle || '');
      setSubtitleAr(chapterToEdit.subtitleAr || chapterToEdit.subtitle || '');
      setDescription(chapterToEdit.description || '');
      setDescriptionAr(chapterToEdit.descriptionAr || chapterToEdit.description || '');
      setBannerImageUrl(chapterToEdit.bannerImageUrl || PRESET_CHAPTER_BANNERS[0].url);
      setAccentColor(chapterToEdit.accentColor || '#2dd4bf');
      setBadgeText(chapterToEdit.badgeText || 'CHRONICLE');
      setBadgeTextAr(chapterToEdit.badgeTextAr || 'ملحمة');
    } else {
      setTitle('NEW CHRONICLE EXPEDITION');
      setTitleAr('فصل استكشافي جديد');
      setSubtitle('Chapter Realm: The Astral Citadel');
      setSubtitleAr('عالم الفصل: القلعة النجمية');
      setDescription('Venture into uncharted territory and overcome tactical battle trials to unlock ancient relics.');
      setDescriptionAr('انطلق في أراضٍ مجهولة وتغلب على التحديات القتالية التكتيكية لفتح الآثار القديمة.');
      setBannerImageUrl(PRESET_CHAPTER_BANNERS[1].url);
      setAccentColor('#f59e0b');
      setBadgeText('EXPEDITION');
      setBadgeTextAr('حملة استكشاف');
    }
    setErrorMessage(null);
  }, [chapterToEdit, isOpen]);

  if (!isOpen) return null;

  // Handle device file upload with client-side compression
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsCompressing(true);
      setErrorMessage(null);
      const compressed = await compressImageFile(file, 1600, 0.82);
      setBannerImageUrl(compressed.dataUrl);
    } catch (err: any) {
      console.error('Failed to compress chapter banner image:', err);
      setErrorMessage(isAr ? 'فشل معالجة الصورة، يرجى المحاولة بصورة أصغر' : 'Failed to process image, please try another file');
    } finally {
      setIsCompressing(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMessage(isAr ? 'يرجى إدخال عنوان الفصل' : 'Please provide a chapter title');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMessage(null);

      const chapterPayload: Partial<StoryChapterDefinition> = {
        id: chapterToEdit?.id,
        title: title.trim(),
        titleAr: titleAr.trim() || title.trim(),
        subtitle: subtitle.trim(),
        subtitleAr: subtitleAr.trim() || subtitle.trim(),
        description: description.trim(),
        descriptionAr: descriptionAr.trim() || description.trim(),
        bannerImageUrl: bannerImageUrl.trim() || PRESET_CHAPTER_BANNERS[0].url,
        accentColor,
        badgeText: badgeText.trim(),
        badgeTextAr: badgeTextAr.trim() || badgeText.trim(),
        battles: chapterToEdit?.battles || []
      };

      const result = await onSave(chapterPayload);
      if (result.success) {
        onClose();
      } else {
        setErrorMessage(result.error || (isAr ? 'فشل حفظ الفصل' : 'Failed to save chapter'));
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error occurred while saving chapter');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!chapterToEdit || !onDelete) return;
    if (!confirm(isAr ? `هل أنت متأكد من حذف فصل "${chapterToEdit.title}"؟` : `Are you sure you want to delete chapter "${chapterToEdit.title}"?`)) {
      return;
    }

    try {
      setIsDeleting(true);
      const res = await onDelete(chapterToEdit.id);
      if (res.success) {
        onClose();
      } else {
        setErrorMessage(res.error || (isAr ? 'فشل حذف الفصل' : 'Failed to delete chapter'));
      }
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-2xl bg-[#031518] border border-teal-500/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        dir={isAr ? 'rtl' : 'ltr'}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-teal-500/20 bg-gradient-to-r from-teal-950/60 via-[#041c20] to-black/80 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-10 h-10 rounded-2xl flex items-center justify-center border shadow-inner"
              style={{ backgroundColor: `${accentColor}25`, borderColor: `${accentColor}60`, color: accentColor }}
            >
              <BookOpen size={20} />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase tracking-wider block" style={{ color: accentColor }}>
                {isAr ? 'إدارة فصول طور القصة' : 'Story Chapters Administration'}
              </span>
              <h2 className="text-lg sm:text-xl font-black text-white font-sans">
                {chapterToEdit 
                  ? (isAr ? `تعديل: ${chapterToEdit.titleAr || chapterToEdit.title}` : `Edit: ${chapterToEdit.title}`)
                  : (isAr ? 'إنشاء فصل قصة جديد' : 'Create New Story Chapter')}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-all cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSave} className="p-5 sm:p-6 space-y-6 overflow-y-auto flex-1">
          {errorMessage && (
            <div className="p-3.5 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-sans flex items-center gap-2">
              <AlertCircle size={16} className="shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Chapter Banner & Device Image Upload */}
          <div className="space-y-3">
            <label className="block text-xs font-mono text-slate-300 uppercase tracking-wider font-bold">
              {isAr ? 'صورة وبانر الفصل (تحميل من جهازك أو اختيار تصميم جاهز)' : 'Chapter Banner (Upload From Device or Select Preset)'}
            </label>

            {/* Preview Banner */}
            <div className="relative h-40 sm:h-48 w-full rounded-2xl overflow-hidden border-2 border-teal-500/40 bg-black group shadow-lg">
              {bannerImageUrl ? (
                <img
                  src={bannerImageUrl}
                  alt="Chapter Banner Preview"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-slate-500 gap-2">
                  <ImageIcon size={32} />
                  <span className="text-xs">{isAr ? 'لم يتم تعيين صورة' : 'No image set'}</span>
                </div>
              )}

              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent flex flex-col justify-end p-4">
                <span 
                  className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold w-max mb-1 border"
                  style={{ backgroundColor: `${accentColor}30`, borderColor: `${accentColor}80`, color: '#ffffff' }}
                >
                  {isAr ? badgeTextAr || badgeText : badgeText}
                </span>
                <h3 className="text-base sm:text-lg font-black text-white truncate font-sans">
                  {isAr ? titleAr || title : title}
                </h3>
              </div>

              {isCompressing && (
                <div className="absolute inset-0 bg-black/80 flex items-center justify-center gap-2 text-[#5eead4] text-xs font-mono">
                  <Loader2 size={20} className="animate-spin" />
                  <span>{isAr ? 'جاري ضغط ومعالجة الصورة من الجهاز...' : 'Compressing device image...'}</span>
                </div>
              )}
            </div>

            {/* Upload Controls */}
            <div className="flex flex-wrap items-center gap-3">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
                id="chapter-image-file-input"
              />

              <label
                htmlFor="chapter-image-file-input"
                className="px-4 py-2.5 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 text-[#5eead4] border border-teal-500/40 text-xs font-mono font-bold flex items-center gap-2 cursor-pointer transition-all shadow-sm"
              >
                <Upload size={14} />
                <span>{isAr ? '📱 تحميل صورة من جهازك' : '📱 Upload from Device'}</span>
              </label>

              <button
                type="button"
                onClick={() => setBannerImageUrl(PRESET_CHAPTER_BANNERS[0].url)}
                className="px-3.5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 text-xs font-mono transition-all"
              >
                {isAr ? 'إعادة التعيين' : 'Reset Default'}
              </button>
            </div>

            {/* Preset Thumbnails */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[11px] font-mono text-slate-400 block">
                {isAr ? 'أو اختر من التصاميم الأثرية الجاهزة:' : 'Or pick an archival preset:'}
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {PRESET_CHAPTER_BANNERS.map(preset => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => setBannerImageUrl(preset.url)}
                    className={`relative rounded-xl border p-1 overflow-hidden transition-all text-left ${
                      bannerImageUrl === preset.url
                        ? 'border-amber-400 ring-2 ring-amber-400/30 bg-amber-400/10'
                        : 'border-white/10 hover:border-teal-500/40 bg-black/40'
                    }`}
                  >
                    <img
                      src={preset.url}
                      alt={preset.name}
                      className="w-full h-12 object-cover rounded-lg mb-1"
                    />
                    <span className="text-[9px] font-sans text-slate-300 truncate block leading-tight px-0.5">
                      {preset.name}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Accent Color Picker */}
          <div className="space-y-2">
            <label className="block text-xs font-mono text-slate-300 uppercase tracking-wider font-bold flex items-center gap-1.5">
              <Palette size={14} className="text-[#5eead4]" />
              <span>{isAr ? 'لون الهوية البصرية للفصل' : 'Chapter Accent Theme Color'}</span>
            </label>
            <div className="flex items-center gap-2.5 flex-wrap">
              {PRESET_ACCENT_COLORS.map(col => (
                <button
                  key={col.value}
                  type="button"
                  onClick={() => setAccentColor(col.value)}
                  className={`h-9 px-3.5 rounded-xl border flex items-center gap-2 text-xs font-mono transition-all cursor-pointer ${
                    accentColor === col.value
                      ? 'border-white ring-2 ring-white/40 text-white font-bold'
                      : 'border-white/10 hover:border-white/30 text-slate-400'
                  }`}
                  style={{ backgroundColor: `${col.value}20` }}
                >
                  <span className={`w-3.5 h-3.5 rounded-full ${col.bg} shrink-0`} />
                  <span>{col.label}</span>
                  {accentColor === col.value && <Check size={13} className="text-white ml-auto" />}
                </button>
              ))}
            </div>
          </div>

          {/* Titles & Arabic Titles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-mono text-slate-300 font-bold">
                {isAr ? 'عنوان الفصل (إنجليزي)' : 'Chapter Title (English)'}
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. THE CHRONO ABYSS"
                required
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-teal-500/30 text-white text-xs font-mono focus:outline-none focus:border-[#5eead4]"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-mono text-slate-300 font-bold">
                {isAr ? 'عنوان الفصل (عربي)' : 'Chapter Title (Arabic)'}
              </label>
              <input
                type="text"
                value={titleAr}
                onChange={(e) => setTitleAr(e.target.value)}
                placeholder="مثال: الهاوية الزمنية"
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-teal-500/30 text-white text-xs font-sans focus:outline-none focus:border-[#5eead4]"
                dir="rtl"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-mono text-slate-300 font-bold">
                {isAr ? 'العنوان الفرعي (إنجليزي)' : 'Subtitle (English)'}
              </label>
              <input
                type="text"
                value={subtitle}
                onChange={(e) => setSubtitle(e.target.value)}
                placeholder="e.g. Chapter 2: The Temporal Rifts"
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-teal-500/30 text-white text-xs font-mono focus:outline-none focus:border-[#5eead4]"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-mono text-slate-300 font-bold">
                {isAr ? 'العنوان الفرعي (عربي)' : 'Subtitle (Arabic)'}
              </label>
              <input
                type="text"
                value={subtitleAr}
                onChange={(e) => setSubtitleAr(e.target.value)}
                placeholder="مثال: الفصل الثاني: شقوق بابل الزمنية"
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-teal-500/30 text-white text-xs font-sans focus:outline-none focus:border-[#5eead4]"
                dir="rtl"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-mono text-slate-300 font-bold">
                {isAr ? 'نص الشارة (إنجليزي)' : 'Badge Label (English)'}
              </label>
              <input
                type="text"
                value={badgeText}
                onChange={(e) => setBadgeText(e.target.value)}
                placeholder="e.g. TEMPORAL EXPEDITION"
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-teal-500/30 text-white text-xs font-mono focus:outline-none focus:border-[#5eead4]"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-mono text-slate-300 font-bold">
                {isAr ? 'نص الشارة (عربي)' : 'Badge Label (Arabic)'}
              </label>
              <input
                type="text"
                value={badgeTextAr}
                onChange={(e) => setBadgeTextAr(e.target.value)}
                placeholder="مثال: حملة الأبعاد الزمنية"
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-teal-500/30 text-white text-xs font-sans focus:outline-none focus:border-[#5eead4]"
                dir="rtl"
              />
            </div>
          </div>

          {/* Descriptions */}
          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-mono text-slate-300 font-bold">
                {isAr ? 'وصف الفصل وقصته (إنجليزي)' : 'Chapter Description & Lore (English)'}
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                placeholder="Describe the atmosphere, environment, and tactical stakes of this chapter..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-teal-500/30 text-white text-xs font-sans leading-relaxed focus:outline-none focus:border-[#5eead4]"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-mono text-slate-300 font-bold">
                {isAr ? 'وصف الفصل وقصته (عربي)' : 'Chapter Description & Lore (Arabic)'}
              </label>
              <textarea
                value={descriptionAr}
                onChange={(e) => setDescriptionAr(e.target.value)}
                rows={3}
                placeholder="صف أجواء الفصل، وعالم المعارك، والتحديات التكتيكية..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-teal-500/30 text-white text-xs font-sans leading-relaxed focus:outline-none focus:border-[#5eead4]"
                dir="rtl"
              />
            </div>
          </div>

          {/* Actions Footer */}
          <div className="pt-4 border-t border-teal-500/20 flex items-center justify-between gap-3">
            {canDelete && chapterToEdit && onDelete ? (
              <button
                type="button"
                onClick={handleDelete}
                disabled={isDeleting || isSubmitting}
                className="px-4 py-2.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-40"
              >
                {isDeleting ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                <span>{isAr ? 'حذف الفصل' : 'Delete Chapter'}</span>
              </button>
            ) : <div />}

            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 text-xs font-mono transition-all"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>

              <button
                type="submit"
                disabled={isSubmitting || isCompressing}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 hover:brightness-110 active:scale-98 text-black font-extrabold text-xs font-mono flex items-center gap-2 shadow-lg shadow-teal-500/25 transition-all cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 size={14} className="animate-spin" />
                    <span>{isAr ? 'جاري الحفظ...' : 'Saving...'}</span>
                  </>
                ) : (
                  <>
                    <Check size={14} />
                    <span>{chapterToEdit ? (isAr ? 'تحديث الفصل' : 'Update Chapter') : (isAr ? 'حفظ وإنشاء الفصل' : 'Create Chapter')}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
