import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { StoryBattleDefinition } from '../../types/story';
import { PlayerDeck } from '../../types/decks';
import { CollectibleCardData } from '../../types/cards';
import { useLanguage } from '../../context/LanguageContext';
import { 
  X, Swords, Shield, Zap, Sparkles, Trophy, Coins, 
  Crown, Play, AlertCircle, CheckCircle 
} from 'lucide-react';

interface BattlePreviewModalProps {
  isOpen: boolean;
  battle: StoryBattleDefinition | null;
  activeDeck: PlayerDeck | null;
  activeDeckCards: CollectibleCardData[];
  enemyCards: CollectibleCardData[];
  isCompleted: boolean;
  hasClaimedFirstClear: boolean;
  onClose: () => void;
  onStartBattle: () => void;
}

export const BattlePreviewModal: React.FC<BattlePreviewModalProps> = ({
  isOpen,
  battle,
  activeDeck,
  activeDeckCards,
  enemyCards,
  isCompleted,
  hasClaimedFirstClear,
  onClose,
  onStartBattle
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  if (!isOpen || !battle) return null;

  const totalFirstClearCoins = battle.rewardCoins + battle.firstClearBonusCoins;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-2xl bg-[#030f12] border border-teal-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        dir={isAr ? 'rtl' : 'ltr'}
      >
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-teal-950 via-[#071d22] to-black border-b border-teal-500/20 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-mono font-bold">
              Battle #{battle.battleNumber}
            </span>
            <h2 className="text-base sm:text-lg font-bold text-white font-sans">
              {isAr ? battle.nameAr : battle.name}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-black/40 hover:bg-black/60 text-slate-300 hover:text-white transition-all cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto flex-1">
          {/* Intro Lore */}
          <div className="p-4 rounded-xl bg-black/40 border border-teal-900/30 space-y-1.5">
            <span className="text-[10px] font-mono text-[#5eead4] uppercase tracking-wider block">
              {isAr ? 'بيانات الاستخبارات القتالية' : 'Combat Tactical Intelligence'}
            </span>
            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-sans">
              {isAr ? battle.introTextAr : battle.introText}
            </p>
          </div>

          {/* Opponent & Player Deck Comparison */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Player Active Deck */}
            <div className="p-3.5 rounded-xl bg-[#05161a] border border-teal-500/30 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-[#5eead4] flex items-center gap-1">
                  <Crown size={13} className="text-amber-400" />
                  <span>{isAr ? 'تشكيلتك النشطة' : 'Your Active Deck'}</span>
                </span>
                <span className="text-[10px] font-mono text-slate-400">
                  {activeDeck ? activeDeck.cardIds.length : 0} / 4
                </span>
              </div>

              {activeDeck ? (
                <>
                  <p className="text-xs font-bold text-white truncate font-sans">
                    {activeDeck.name}
                  </p>

                  <div className="grid grid-cols-4 gap-1">
                    {[0, 1, 2, 3].map(i => {
                      const c = activeDeckCards[i];
                      return (
                        <div
                          key={i}
                          className="aspect-[3/4] rounded-md border border-teal-500/20 bg-black/60 overflow-hidden"
                        >
                          {c ? (
                            <img src={c.imageUrl} alt={c.name} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-[9px] text-teal-800">
                              -
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  <div className="flex items-center justify-between text-[11px] font-mono text-slate-300 pt-1 border-t border-teal-900/30">
                    <span>PWR: {activeDeck.power}</span>
                    <span>DEF: {activeDeck.defense}</span>
                    <span>SPD: {activeDeck.speed}</span>
                  </div>
                </>
              ) : (
                <div className="p-3 text-center space-y-2">
                  <p className="text-xs text-rose-300 font-mono">
                    {isAr ? 'لا توجد تشكيلة نشطة حالياً.' : 'No active deck found.'}
                  </p>
                  <Link
                    to="/decks"
                    onClick={onClose}
                    className="inline-block px-3 py-1 rounded-lg bg-teal-500/20 text-[#5eead4] hover:bg-teal-500/30 border border-[#5eead4]/40 text-xs font-mono font-bold"
                  >
                    {isAr ? 'إعداد التشكيلة ➔' : 'Setup Deck ➔'}
                  </Link>
                </div>
              )}
            </div>

            {/* Enemy Formation */}
            <div className="p-3.5 rounded-xl bg-black/60 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-rose-400">
                  {isAr ? 'قوات العدو' : 'Enemy Vanguard'}
                </span>
                <span className="px-2 py-0.2 rounded text-[10px] font-mono font-bold bg-rose-500/10 text-rose-300 border border-rose-500/20">
                  {battle.difficulty}
                </span>
              </div>

              <div className="flex items-center gap-2">
                {battle.enemyCommanderAvatar && (
                  <img
                    src={battle.enemyCommanderAvatar}
                    alt={battle.enemyCommanderName}
                    className="w-6 h-6 rounded-full object-cover border border-rose-400 shrink-0"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                )}
                <p className="text-xs font-bold text-slate-300 truncate font-sans">
                  {battle.enemyCommanderName}
                </p>
              </div>

              <div className="grid grid-cols-4 gap-1">
                {[0, 1, 2, 3].map(i => {
                  const c = enemyCards[i];
                  return (
                    <div
                      key={i}
                      className="aspect-[3/4] rounded-md border border-white/10 bg-black/60 overflow-hidden"
                    >
                      {c ? (
                        <img src={c.imageUrl} alt={c.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-[9px] text-slate-700">
                          -
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              <span className="text-[10px] font-mono text-slate-400 block pt-1 border-t border-white/5">
                {enemyCards.length} {isAr ? 'بطاقات في التشكيلة' : 'Cards deployed'}
              </span>
            </div>
          </div>

          {/* Rewards Breakdown */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-amber-500/10 via-amber-400/5 to-transparent border border-amber-500/30 flex items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-amber-300">
                <Coins size={14} className="text-amber-400" />
                <span>{isAr ? 'مكافآت الانتصار' : 'Victory Rewards'}</span>
              </div>
              <p className="text-[11px] font-mono text-slate-300">
                {!hasClaimedFirstClear
                  ? (isAr ? `مكافأة الإنجاز الأول: +${totalFirstClearCoins} عملة و +${battle.rewardXp} XP` : `First-Clear Bonus: +${totalFirstClearCoins} Coins & +${battle.rewardXp} XP`)
                  : (isAr ? `مكافأة إعادة المعركة: +${Math.round(battle.rewardCoins * 0.35)} عملة` : `Replay Reward: +${Math.round(battle.rewardCoins * 0.35)} Coins`)}
              </p>
            </div>

            {isCompleted && (
              <span className="px-2.5 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-mono flex items-center gap-1 shrink-0">
                <CheckCircle size={13} />
                <span>{isAr ? 'تم الاجتياز' : 'Cleared'}</span>
              </span>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-3.5 bg-black/80 border-t border-white/10 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-mono transition-all cursor-pointer"
          >
            {isAr ? 'إغلاق' : 'Close'}
          </button>

          <button
            type="button"
            disabled={!activeDeck || activeDeck.cardIds.length === 0}
            onClick={onStartBattle}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-amber-300 to-[#5eead4] hover:brightness-110 active:scale-[0.98] text-[#031211] font-bold text-xs font-mono flex items-center gap-2 shadow-lg shadow-amber-500/20 transition-all cursor-pointer disabled:opacity-50"
          >
            <Play size={14} className="text-black fill-black" />
            <span>{isAr ? 'بدء المعركة الآن' : 'Start Battle'}</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
};
