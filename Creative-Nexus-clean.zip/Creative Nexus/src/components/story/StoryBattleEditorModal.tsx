import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { StoryBattleDefinition, StoryChapterDefinition, BattleDifficulty } from '../../types/story';
import { CollectibleCardData } from '../../types/cards';
import { useCards } from '../../context/CardContext';
import { useLanguage } from '../../context/LanguageContext';
import { compressImageFile } from '../../utils/imageCompressor';
import { MESOPOTAMIAN_ASSETS } from '../../assets/mesopotamianAssets';
import { MODERN_CARD_ASSETS } from '../../assets/modernCardAssets';
import { 
  X, Swords, Shield, Zap, Sparkles, Plus, Trash2, 
  Image as ImageIcon, Trophy, Coins, Lock, CheckCircle, Search, 
  Crown, Layers, AlertCircle, Loader2, ArrowRight, ArrowLeft, Upload, BookOpen, Skull
} from 'lucide-react';

interface StoryBattleEditorModalProps {
  isOpen: boolean;
  battleToEdit: StoryBattleDefinition | null;
  existingBattles: StoryBattleDefinition[];
  chapters?: StoryChapterDefinition[];
  currentChapterId?: string;
  onClose: () => void;
  onSave: (battleData: Partial<StoryBattleDefinition>) => Promise<{ success: boolean; error?: string }>;
}

const COMMANDER_AVATAR_PRESETS = [
  { id: 'apex_sovereign', name: 'High Sovereign Prime', url: MODERN_CARD_ASSETS.cardApexSovereign },
  { id: 'aegis_valkyrie', name: 'Aegis Valkyrie Commander', url: MODERN_CARD_ASSETS.cardAegisValkyrie },
  { id: 'chrono_architect', name: 'Chrono Grand Architect', url: MODERN_CARD_ASSETS.cardChronoArchitect },
  { id: 'astral_empress', name: 'Astral Empress Seraphina', url: MODERN_CARD_ASSETS.cardAstralEmpress },
  { id: 'shadow_operative', name: 'Shadow Operative Eclipse', url: MODERN_CARD_ASSETS.cardShadowOperative },
  { id: 'king_relief', name: 'Mesopotamian Emperor', url: MESOPOTAMIAN_ASSETS.kingRelief },
  { id: 'lamassu_guardian', name: 'Celestial Lamassu Sentinel', url: MESOPOTAMIAN_ASSETS.lamassuRelief },
  { id: 'eagle_sentinel', name: 'Sun-Eagle Archon', url: MESOPOTAMIAN_ASSETS.eagleRelief }
];

const BATTLE_BG_PRESETS = [
  { id: 'bg_meso_hero', name: 'Obsidian Hero Temple', url: MESOPOTAMIAN_ASSETS.heroBg },
  { id: 'bg_frieze', name: 'Cuneiform Sun Wall', url: MESOPOTAMIAN_ASSETS.friezeBanner },
  { id: 'bg_dark_sanctum', name: 'Obsidian Vault Chamber', url: MODERN_CARD_ASSETS.packEpicHyperion }
];

export const StoryBattleEditorModal: React.FC<StoryBattleEditorModalProps> = ({
  isOpen,
  battleToEdit,
  existingBattles,
  chapters = [],
  currentChapterId = 'chapter_1',
  onClose,
  onSave
}) => {
  const { catalog } = useCards();
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const avatarInputRef = useRef<HTMLInputElement>(null);
  const bgInputRef = useRef<HTMLInputElement>(null);

  // Form State
  const [chapterId, setChapterId] = useState(currentChapterId);
  const [name, setName] = useState('');
  const [nameAr, setNameAr] = useState('');
  const [title, setTitle] = useState('');
  const [titleAr, setTitleAr] = useState('');
  const [description, setDescription] = useState('');
  const [descriptionAr, setDescriptionAr] = useState('');
  const [introText, setIntroText] = useState('');
  const [introTextAr, setIntroTextAr] = useState('');
  const [difficulty, setDifficulty] = useState<BattleDifficulty>('NORMAL');
  const [fightClassification, setFightClassification] = useState<'NORMAL' | 'BOSS' | 'CHAPTER_FINALE'>('NORMAL');
  const [enemyCommanderName, setEnemyCommanderName] = useState('');
  const [enemyCommanderNameAr, setEnemyCommanderNameAr] = useState('');
  const [customCharacterName, setCustomCharacterName] = useState('');
  const [customCharacterNameAr, setCustomCharacterNameAr] = useState('');
  const [enemyCommanderAvatar, setEnemyCommanderAvatar] = useState('');
  const [backgroundImageUrl, setBackgroundImageUrl] = useState('');
  const [enemyDeckCardIds, setEnemyDeckCardIds] = useState<string[]>([]);
  const [rewardCoins, setRewardCoins] = useState<number>(60);
  const [rewardXp, setRewardXp] = useState<number>(75);
  const [firstClearBonusCoins, setFirstClearBonusCoins] = useState<number>(45);
  const [unlockRequirementId, setUnlockRequirementId] = useState<string | null>(null);

  // Image Upload State
  const [isCompressingAvatar, setIsCompressingAvatar] = useState(false);
  const [isCompressingBg, setIsCompressingBg] = useState(false);

  // Editor Tabs
  const [activeTab, setActiveTab] = useState<'IDENTITY' | 'COMMANDER' | 'LINEUP' | 'REWARDS'>('IDENTITY');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRarity, setSelectedRarity] = useState<string>('ALL');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Populate when editing or creating
  useEffect(() => {
    if (battleToEdit) {
      setChapterId(battleToEdit.chapterId || currentChapterId);
      setName(battleToEdit.name || '');
      setNameAr(battleToEdit.nameAr || battleToEdit.name || '');
      setTitle(battleToEdit.title || '');
      setTitleAr(battleToEdit.titleAr || battleToEdit.title || '');
      setDescription(battleToEdit.description || '');
      setDescriptionAr(battleToEdit.descriptionAr || battleToEdit.description || '');
      setIntroText(battleToEdit.introText || '');
      setIntroTextAr(battleToEdit.introTextAr || battleToEdit.introText || '');
      setDifficulty(battleToEdit.difficulty || 'NORMAL');
      const resolvedClass = battleToEdit.fightType || 
        (battleToEdit.difficulty === 'CHAPTER_FINALE' || battleToEdit.isChapterFinale ? 'CHAPTER_FINALE' : battleToEdit.difficulty === 'BOSS' ? 'BOSS' : 'NORMAL');
      setFightClassification(resolvedClass);
      setEnemyCommanderName(battleToEdit.enemyCommanderName || '');
      setEnemyCommanderNameAr(battleToEdit.enemyCommanderNameAr || battleToEdit.enemyCommanderName || '');
      setCustomCharacterName(battleToEdit.customCharacterName || battleToEdit.enemyCommanderName || '');
      setCustomCharacterNameAr(battleToEdit.customCharacterNameAr || battleToEdit.enemyCommanderNameAr || '');
      setEnemyCommanderAvatar(battleToEdit.enemyCommanderAvatar || COMMANDER_AVATAR_PRESETS[0].url);
      setBackgroundImageUrl(battleToEdit.backgroundImageUrl || '');
      setEnemyDeckCardIds(battleToEdit.enemyDeckCardIds ? [...battleToEdit.enemyDeckCardIds] : []);
      setRewardCoins(battleToEdit.rewardCoins || 60);
      setRewardXp(battleToEdit.rewardXp || 75);
      setFirstClearBonusCoins(battleToEdit.firstClearBonusCoins || 45);
      setUnlockRequirementId(battleToEdit.unlockRequirementId !== undefined ? battleToEdit.unlockRequirementId : null);
    } else {
      setChapterId(currentChapterId);
      setName('Sanctuary Gate Guardian');
      setNameAr('حارس بوابة الملاذ القديم');
      setTitle('Outer Sanctum Defense Protocol');
      setTitleAr('بروتوكول دفاع الحرم الخارجي');
      setDescription('An elite autonomous defender stands guard at the gateway. Overcome their defensive barriers.');
      setDescriptionAr('يقف مدافع نخبوي مستقل على حراسة البوابة. تغلب على دروع دفاعاته المتينة.');
      setIntroText('"Halt, challenger. The proving grounds demand supreme strategic resonance."');
      setIntroTextAr('"قف أيها المتحدي. ساحات الإثبات تتطلب تناغماً استراتيجياً أسمى."');
      setDifficulty('NORMAL');
      setEnemyCommanderName('Archon Guardian Unit');
      setEnemyCommanderNameAr('وحدة حرس الأركون');
      setCustomCharacterName('Archon Guardian Unit');
      setCustomCharacterNameAr('وحدة حرس الأركون');
      setEnemyCommanderAvatar(COMMANDER_AVATAR_PRESETS[0].url);
      setBackgroundImageUrl('');
      const defaultIds = catalog.slice(0, 3).map(c => c.id);
      setEnemyDeckCardIds(defaultIds.length > 0 ? defaultIds : ['card_kinetic_scout', 'card_core_recruit']);
      setRewardCoins(80);
      setRewardXp(90);
      setFirstClearBonusCoins(50);
      const lastBattle = existingBattles[existingBattles.length - 1];
      setUnlockRequirementId(lastBattle ? lastBattle.id : null);
    }
    setErrorMessage(null);
  }, [battleToEdit, existingBattles, catalog, currentChapterId, isOpen]);

  if (!isOpen) return null;

  // Selected enemy cards from catalog
  const selectedCards: CollectibleCardData[] = enemyDeckCardIds
    .map(id => catalog.find(c => c.id === id))
    .filter((c): c is CollectibleCardData => Boolean(c));

  // Filter available cards for lineup builder
  const filteredCatalog = catalog.filter(card => {
    const matchesSearch = 
      card.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (card.element && card.element.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesRarity = selectedRarity === 'ALL' || card.rarity === selectedRarity;
    return matchesSearch && matchesRarity;
  });

  const handleAddCard = (cardId: string) => {
    if (enemyDeckCardIds.length >= 4) {
      setErrorMessage(isAr ? 'الحد الأقصى هو 4 بطاقات لتشكيل الخصم' : 'Strict maximum 4 cards in hostile squad formation');
      return;
    }
    setEnemyDeckCardIds(prev => [...prev, cardId]);
    setErrorMessage(null);
  };

  const handleRemoveCard = (index: number) => {
    setEnemyDeckCardIds(prev => prev.filter((_, i) => i !== index));
  };

  // Device file upload for Commander Portrait
  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsCompressingAvatar(true);
      setErrorMessage(null);
      const res = await compressImageFile(file, 900, 0.85);
      setEnemyCommanderAvatar(res.dataUrl);
    } catch (err: any) {
      console.error('Failed to compress avatar:', err);
      setErrorMessage(isAr ? 'فشل معالجة صورة القائد' : 'Failed to compress commander image');
    } finally {
      setIsCompressingAvatar(false);
      if (avatarInputRef.current) avatarInputRef.current.value = '';
    }
  };

  // Device file upload for Battle Background
  const handleBgUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsCompressingBg(true);
      setErrorMessage(null);
      const res = await compressImageFile(file, 1600, 0.80);
      setBackgroundImageUrl(res.dataUrl);
    } catch (err: any) {
      console.error('Failed to compress battle background:', err);
      setErrorMessage(isAr ? 'فشل معالجة خلفية المعركة' : 'Failed to compress battle background');
    } finally {
      setIsCompressingBg(false);
      if (bgInputRef.current) bgInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMessage(isAr ? 'يرجى إدخال اسم المعركة' : 'Battle name is required');
      return;
    }
    if (!enemyCommanderName.trim()) {
      setErrorMessage(isAr ? 'يرجى إدخال اسم قائد الخصم' : 'Hostile commander name is required');
      return;
    }
    if (enemyDeckCardIds.length === 0) {
      setErrorMessage(isAr ? 'يرجى اختيار بطاقة واحدة على الأقل لتشكيل الخصم' : 'Please select at least 1 card for hostile squad');
      return;
    }

    setIsSubmitting(true);

    try {
      const payload: Partial<StoryBattleDefinition> = {
        id: battleToEdit?.id,
        chapterId: chapterId || currentChapterId,
        battleNumber: battleToEdit?.battleNumber || (existingBattles.length + 1),
        name: name.trim(),
        nameAr: nameAr.trim() || name.trim(),
        title: title.trim() || name.trim(),
        titleAr: titleAr.trim() || nameAr.trim(),
        description: description.trim(),
        descriptionAr: descriptionAr.trim() || description.trim(),
        introText: introText.trim(),
        introTextAr: introTextAr.trim() || introText.trim(),
        difficulty: fightClassification === 'CHAPTER_FINALE' ? 'CHAPTER_FINALE' : fightClassification === 'BOSS' ? 'BOSS' : difficulty,
        fightType: fightClassification,
        isChapterFinale: fightClassification === 'CHAPTER_FINALE',
        enemyCommanderName: enemyCommanderName.trim(),
        enemyCommanderNameAr: enemyCommanderNameAr.trim() || enemyCommanderName.trim(),
        customCharacterName: customCharacterName.trim() || enemyCommanderName.trim(),
        customCharacterNameAr: customCharacterNameAr.trim() || enemyCommanderNameAr.trim() || enemyCommanderName.trim(),
        enemyCommanderAvatar: enemyCommanderAvatar.trim() || COMMANDER_AVATAR_PRESETS[0].url,
        backgroundImageUrl: backgroundImageUrl.trim(),
        enemyDeckCardIds: enemyDeckCardIds.slice(0, 4),
        enemyCards: selectedCards.slice(0, 4),
        rewardCoins: Number(rewardCoins) || 50,
        rewardXp: Number(rewardXp) || 60,
        firstClearBonusCoins: Number(firstClearBonusCoins) || 40,
        unlockRequirementId: unlockRequirementId || null
      };

      const res = await onSave(payload);
      if (res.success) {
        onClose();
      } else {
        setErrorMessage(res.error || 'Failed to save battle');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Error occurred while saving battle');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto" dir={isAr ? 'rtl' : 'ltr'}>
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-4xl bg-gradient-to-b from-[#031518] via-[#021013] to-black border border-teal-500/30 rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden my-auto"
      >
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-teal-500/20 bg-black/60 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <span className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-300 border border-amber-500/40">
              <Crown size={20} />
            </span>
            <div>
              <span className="text-[10px] font-mono text-[#5eead4] uppercase tracking-wider block">
                {isAr ? 'لوحة تحكم المالك • استوديو المعارك والقتال' : 'Owner Studio • Story Battle Builder'}
              </span>
              <h2 className="text-lg sm:text-xl font-extrabold text-white font-sans tracking-tight">
                {battleToEdit
                  ? (isAr ? `تعديل المعركة: ${battleToEdit.name}` : `Edit Battle: ${battleToEdit.name}`)
                  : (isAr ? 'إضافة معركة قصة جديدة' : 'Create New Story Battle')}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-all cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-4 sm:px-6 pt-3 pb-2 border-b border-white/5 bg-black/40 flex items-center gap-2 overflow-x-auto shrink-0 scrollbar-none">
          <button
            type="button"
            onClick={() => setActiveTab('IDENTITY')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
              activeTab === 'IDENTITY'
                ? 'bg-teal-500 text-black shadow-lg shadow-teal-500/20'
                : 'bg-white/5 hover:bg-white/10 text-slate-300'
            }`}
          >
            <Layers size={14} />
            <span>{isAr ? '1. الهوية والفصل' : '1. Lore & Chapter'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('COMMANDER')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
              activeTab === 'COMMANDER'
                ? 'bg-teal-500 text-black shadow-lg shadow-teal-500/20'
                : 'bg-white/5 hover:bg-white/10 text-slate-300'
            }`}
          >
            <ImageIcon size={14} />
            <span>{isAr ? '2. القائد والصور' : '2. Commander & Imagery'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('LINEUP')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
              activeTab === 'LINEUP'
                ? 'bg-teal-500 text-black shadow-lg shadow-teal-500/20'
                : 'bg-white/5 hover:bg-white/10 text-slate-300'
            }`}
          >
            <Swords size={14} />
            <span>{isAr ? '3. تشكيل الخصم (4 بطاقات)' : '3. Hostile Squad (Max 4)'}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-black/40 text-[10px]">
              {enemyDeckCardIds.length}/4
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('REWARDS')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
              activeTab === 'REWARDS'
                ? 'bg-teal-500 text-black shadow-lg shadow-teal-500/20'
                : 'bg-white/5 hover:bg-white/10 text-slate-300'
            }`}
          >
            <Trophy size={14} />
            <span>{isAr ? '4. الصعوبة والجوائز' : '4. Difficulty & Rewards'}</span>
          </button>
        </div>

        {/* Error Notification */}
        {errorMessage && (
          <div className="mx-4 sm:mx-6 mt-3 p-3 rounded-xl bg-rose-950/50 border border-rose-500/40 text-rose-200 text-xs font-mono flex items-center gap-2 shrink-0">
            <AlertCircle size={16} className="text-rose-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Content Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: IDENTITY & LORE & CHAPTER SELECTION */}
          {activeTab === 'IDENTITY' && (
            <div className="space-y-4">
              {/* Chapter Selector */}
              {chapters.length > 0 && (
                <div className="p-4 rounded-2xl bg-black/60 border border-teal-500/30 space-y-2">
                  <label className="text-xs font-mono text-[#5eead4] flex items-center gap-2 font-bold">
                    <BookOpen size={14} />
                    <span>{isAr ? 'الفصل الذي تنتمي إليه هذه المعركة:' : 'Assign Battle To Chapter:'}</span>
                  </label>
                  <select
                    value={chapterId}
                    onChange={(e) => setChapterId(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#031518] border border-teal-500/40 text-white text-xs font-mono focus:outline-none"
                  >
                    {chapters.map((ch, idx) => (
                      <option key={ch.id} value={ch.id}>
                        {isAr ? `الفصل ${idx + 1}: ${ch.titleAr || ch.title}` : `Chapter ${idx + 1}: ${ch.title}`}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* English Name */}
                <div className="space-y-1.5">
                  <label className="text-xs font-mono text-[#5eead4] block font-bold">
                    {isAr ? 'اسم المعركة (إنجليزي) *' : 'Battle Name (English) *'}
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    required
                    placeholder="e.g. Celestial Warden Breach"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-[#5eead4] text-white text-xs font-mono focus:outline-none"
                  />
                </div>

                {/* Arabic Name */}
                <div className="space-y-1.5">
                  <label className="text-xs font-mono text-[#5eead4] block font-bold">
                    {isAr ? 'اسم المعركة (عربي)' : 'Battle Name (Arabic)'}
                  </label>
                  <input
                    type="text"
                    value={nameAr}
                    onChange={e => setNameAr(e.target.value)}
                    dir="rtl"
                    placeholder="مثال: اقتحام حارس السماوات"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-[#5eead4] text-white text-xs font-sans focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Title */}
                <div className="space-y-1.5">
                  <label className="text-xs font-mono text-slate-300 block">
                    {isAr ? 'العنوان الفرعي (إنجليزي)' : 'Subtitle / Title (English)'}
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={e => setTitle(e.target.value)}
                    placeholder="e.g. Archon Singularity Defense"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-[#5eead4] text-white text-xs font-mono focus:outline-none"
                  />
                </div>

                {/* Title Arabic */}
                <div className="space-y-1.5">
                  <label className="text-xs font-mono text-slate-300 block">
                    {isAr ? 'العنوان الفرعي (عربي)' : 'Subtitle / Title (Arabic)'}
                  </label>
                  <input
                    type="text"
                    value={titleAr}
                    onChange={e => setTitleAr(e.target.value)}
                    dir="rtl"
                    placeholder="مثال: بروتوكول حماية نقطة التفرد"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-[#5eead4] text-white text-xs font-sans focus:outline-none"
                  />
                </div>
              </div>

              {/* Descriptions */}
              <div className="space-y-1.5">
                <label className="text-xs font-mono text-slate-300 block">
                  {isAr ? 'وصف المعركة (إنجليزي)' : 'Battle Lore & Dossier (English)'}
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Describe the combatants, tactical stakes, and strategic atmosphere..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-[#5eead4] text-white text-xs font-sans focus:outline-none resize-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-mono text-slate-300 block">
                  {isAr ? 'وصف المعركة (عربي)' : 'Battle Lore & Dossier (Arabic)'}
                </label>
                <textarea
                  rows={2}
                  value={descriptionAr}
                  onChange={e => setDescriptionAr(e.target.value)}
                  dir="rtl"
                  placeholder="اكتب قصة المعركة ودوافع الخصم واستراتيجية القتال المطلوبة..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-[#5eead4] text-white text-xs font-sans focus:outline-none resize-none"
                />
              </div>

              {/* Pre-Clash Intro Speech */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-mono text-amber-300 block">
                    {isAr ? 'كلمات القائد قبل النزال (إنجليزي)' : 'Pre-Clash Dialogue Quote (English)'}
                  </label>
                  <input
                    type="text"
                    value={introText}
                    onChange={e => setIntroText(e.target.value)}
                    placeholder='"You dare step onto the proving grounds? Show me your conviction."'
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-amber-400 text-white text-xs font-mono focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-mono text-amber-300 block">
                    {isAr ? 'كلمات القائد قبل النزال (عربي)' : 'Pre-Clash Dialogue Quote (Arabic)'}
                  </label>
                  <input
                    type="text"
                    value={introTextAr}
                    onChange={e => setIntroTextAr(e.target.value)}
                    dir="rtl"
                    placeholder='"أتقف أمام عرشي بكل هذه الثقة؟ أرني قوتك الحقيقية."'
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-amber-400 text-white text-xs font-sans focus:outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: HOSTILE COMMANDER & CUSTOM CHARACTER IMAGERY */}
          {activeTab === 'COMMANDER' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
                {/* Live Preview Card */}
                <div className="flex flex-col items-center p-4 rounded-2xl bg-black/60 border border-teal-500/30 text-center">
                  <span className="text-[10px] font-mono text-[#5eead4] uppercase tracking-wider mb-2">
                    {isAr ? 'معاينة صورة القائد' : 'Commander Portrait Preview'}
                  </span>
                  
                  <div className="relative w-36 h-48 rounded-xl overflow-hidden border-2 border-amber-400 shadow-xl bg-black mb-3">
                    <img
                      src={enemyCommanderAvatar || COMMANDER_AVATAR_PRESETS[0].url}
                      alt={enemyCommanderName || 'Commander Preview'}
                      className="w-full h-full object-cover"
                      onError={e => {
                        (e.target as HTMLImageElement).src = COMMANDER_AVATAR_PRESETS[0].url;
                      }}
                    />
                    <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black via-black/80 to-transparent p-2 text-center">
                      <span className="text-[11px] font-bold text-white block truncate">
                        {isAr ? customCharacterNameAr || enemyCommanderNameAr || enemyCommanderName : customCharacterName || enemyCommanderName || 'Hostile Commander'}
                      </span>
                      <span className="text-[9px] font-mono text-amber-400 uppercase">
                        {difficulty}
                      </span>
                    </div>

                    {isCompressingAvatar && (
                      <div className="absolute inset-0 bg-black/80 flex items-center justify-center gap-1.5 text-xs text-amber-300 font-mono">
                        <Loader2 size={16} className="animate-spin" />
                        <span>{isAr ? 'جاري المعالجة...' : 'Compressing...'}</span>
                      </div>
                    )}
                  </div>

                  <p className="text-[10px] font-mono text-slate-400">
                    {isAr ? 'تظهر في بطاقة المعركة وشاشة المواجهة التكتيكية' : 'Displayed in VS battle screen and story node card'}
                  </p>
                </div>

                {/* Inputs & Device Upload */}
                <div className="md:col-span-2 space-y-4">
                  {/* Custom Character Names */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <label className="text-xs font-mono text-[#5eead4] block font-bold">
                        {isAr ? 'اسم الشخصية / القائد (إنجليزي) *' : 'Commander / Character Name (English) *'}
                      </label>
                      <input
                        type="text"
                        value={enemyCommanderName}
                        onChange={e => {
                          setEnemyCommanderName(e.target.value);
                          if (!customCharacterName) setCustomCharacterName(e.target.value);
                        }}
                        required
                        placeholder="e.g. Lord Sovereign Prime"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-[#5eead4] text-white text-xs font-mono focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-mono text-[#5eead4] block font-bold">
                        {isAr ? 'اسم الشخصية / القائد (عربي)' : 'Commander / Character Name (Arabic)'}
                      </label>
                      <input
                        type="text"
                        value={enemyCommanderNameAr}
                        onChange={e => {
                          setEnemyCommanderNameAr(e.target.value);
                          if (!customCharacterNameAr) setCustomCharacterNameAr(e.target.value);
                        }}
                        dir="rtl"
                        placeholder="مثال: لورد السيادة برايم"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-[#5eead4] text-white text-xs font-sans focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Device Upload Button */}
                  <div className="p-3.5 rounded-2xl bg-teal-950/20 border border-teal-500/30 space-y-2">
                    <label className="text-xs font-mono text-teal-300 font-bold block flex items-center gap-1.5">
                      <Upload size={14} />
                      <span>{isAr ? '📱 رفع صورة مخصصة للشخصية من جهازك:' : '📱 Upload Custom Character Picture from Device:'}</span>
                    </label>

                    <div className="flex flex-wrap items-center gap-2.5">
                      <input
                        ref={avatarInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleAvatarUpload}
                        className="hidden"
                        id="battle-avatar-file-input"
                      />
                      <label
                        htmlFor="battle-avatar-file-input"
                        className="px-4 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold flex items-center gap-2 cursor-pointer transition-all shadow-sm"
                      >
                        <Upload size={13} />
                        <span>{isAr ? 'اختر صورة من جهازك' : 'Choose File from Device'}</span>
                      </label>

                      <span className="text-[10px] font-mono text-slate-400">
                        {isAr ? 'يتم ضغط الصورة تلقائياً لتناسب قواعد البيانات' : 'Auto-compressed for ultra-fast gameplay'}
                      </span>
                    </div>
                  </div>

                  {/* Custom Picture URL Input */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-mono text-slate-300 block">
                      {isAr ? 'أو أدخل رابط صورة مخصص (URL)' : 'Or Enter Custom Image URL:'}
                    </label>
                    <input
                      type="url"
                      value={enemyCommanderAvatar}
                      onChange={e => setEnemyCommanderAvatar(e.target.value)}
                      placeholder="https://... or choose from presets below"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-[#5eead4] text-white text-xs font-mono focus:outline-none"
                    />
                  </div>

                  {/* Preset Artwork Gallery */}
                  <div className="space-y-2 pt-1">
                    <span className="text-xs font-mono text-amber-300 block">
                      {isAr ? 'أو اختر من صور القادة المميزة الجاهزة:' : 'Or Select From Premium Character Artwork Presets:'}
                    </span>

                    <div className="grid grid-cols-4 gap-2">
                      {COMMANDER_AVATAR_PRESETS.map(preset => {
                        const isSelected = enemyCommanderAvatar === preset.url;
                        return (
                          <button
                            key={preset.id}
                            type="button"
                            onClick={() => {
                              setEnemyCommanderAvatar(preset.url);
                              if (!enemyCommanderName) setEnemyCommanderName(preset.name);
                            }}
                            className={`p-1.5 rounded-xl border flex flex-col items-center gap-1 transition-all cursor-pointer ${
                              isSelected
                                ? 'border-[#5eead4] bg-teal-500/20 ring-2 ring-[#5eead4]/40 scale-102'
                                : 'border-white/10 bg-black/40 hover:border-white/30'
                            }`}
                          >
                            <img
                              src={preset.url}
                              alt={preset.name}
                              className="w-14 h-16 rounded-lg object-cover"
                            />
                            <span className="text-[9px] font-mono text-slate-300 truncate max-w-full text-center">
                              {preset.name.split(' ')[0]}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>

              {/* Optional Battle Background Upload */}
              <div className="pt-4 border-t border-white/10 space-y-3">
                <label className="text-xs font-mono text-[#5eead4] font-bold block flex items-center gap-2">
                  <ImageIcon size={14} />
                  <span>{isAr ? 'خلفية ساحة القتال الخاصة بهذه المعركة (اختياري)' : 'Custom Fight Arena Background (Optional):'}</span>
                </label>

                <div className="flex flex-wrap items-center gap-3">
                  <input
                    ref={bgInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleBgUpload}
                    className="hidden"
                    id="battle-bg-file-input"
                  />
                  <label
                    htmlFor="battle-bg-file-input"
                    className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 border border-white/15 text-xs font-mono flex items-center gap-2 cursor-pointer transition-all"
                  >
                    <Upload size={13} />
                    <span>{isAr ? '📱 تحميل خلفية من جهازك' : '📱 Upload Arena BG from Device'}</span>
                  </label>

                  {backgroundImageUrl && (
                    <button
                      type="button"
                      onClick={() => setBackgroundImageUrl('')}
                      className="px-3 py-2 rounded-xl bg-rose-500/20 text-rose-300 text-xs font-mono hover:bg-rose-500/30"
                    >
                      {isAr ? 'إزالة الخلفية' : 'Remove Background'}
                    </button>
                  )}
                </div>

                {backgroundImageUrl && (
                  <div className="relative h-24 w-full rounded-xl overflow-hidden border border-teal-500/30">
                    <img src={backgroundImageUrl} alt="Arena Backdrop Preview" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center text-xs font-mono text-white">
                      {isAr ? 'تم تعيين خلفية مخصصة للنزال' : 'Custom Arena Backdrop Set'}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: HOSTILE SQUAD LINEUP (STRICT MAX 4) */}
          {activeTab === 'LINEUP' && (
            <div className="space-y-6">
              {/* Active 4-Card Formation Slots */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-mono text-[#5eead4] uppercase tracking-wider block font-bold">
                    {isAr ? 'تشكيل الخصم الرباعي الميداني (حد أقصى 4 بطاقات):' : 'Hostile 4-Card Squad Formation:'}
                  </label>
                  <span className="text-xs font-mono text-amber-300">
                    {enemyDeckCardIds.length} / 4 {isAr ? 'بطاقات مختارة' : 'Slots Filled'}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[0, 1, 2, 3].map(slotIdx => {
                    const card = selectedCards[slotIdx];
                    const roleNames = ['VANGUARD', 'STRIKER', 'BULWARK', 'TACTICIAN'];

                    return (
                      <div
                        key={slotIdx}
                        className={`rounded-2xl border p-2 flex flex-col justify-between transition-all relative ${
                          card
                            ? 'bg-black/70 border-teal-500/40 shadow-lg'
                            : 'border-dashed border-teal-900/50 bg-black/20 min-h-[140px] items-center justify-center'
                        }`}
                      >
                        {card ? (
                          <>
                            <div className="flex items-center justify-between mb-1.5">
                              <span className="text-[9px] font-mono text-[#5eead4] font-bold">
                                {roleNames[slotIdx]}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleRemoveCard(slotIdx)}
                                className="p-1 rounded-md bg-rose-500/20 text-rose-300 hover:bg-rose-500/40 cursor-pointer"
                                title="Remove card"
                              >
                                <X size={12} />
                              </button>
                            </div>

                            <img
                              src={card.imageUrl}
                              alt={card.name}
                              className="w-full h-24 object-cover rounded-xl border border-white/10 mb-1.5"
                            />

                            <div className="space-y-0.5">
                              <h4 className="text-xs font-bold text-white truncate font-sans">
                                {card.name}
                              </h4>
                              <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                                <span>⚔️ {card.attack}</span>
                                <span>🛡️ {card.defense}</span>
                              </div>
                            </div>
                          </>
                        ) : (
                          <div className="text-center p-2">
                            <span className="text-[10px] font-mono text-slate-500 block mb-1">
                              {roleNames[slotIdx]}
                            </span>
                            <span className="text-xs font-mono text-slate-600 block">
                              {isAr ? 'خانة شاغرة' : 'Empty Slot'}
                            </span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Card Catalog Browser to Add Cards */}
              <div className="space-y-3 pt-3 border-t border-white/10">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <span className="text-xs font-mono text-slate-300 font-bold block">
                    {isAr ? 'اختر بطاقات الخصم من الكتالوج العام:' : 'Select Cards From Card Vault Catalog:'}
                  </span>

                  {/* Search & Filter */}
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        placeholder="Search card..."
                        className="pl-8 pr-3 py-1.5 rounded-xl bg-black/60 border border-white/15 text-white text-xs font-mono focus:outline-none"
                      />
                    </div>

                    <select
                      value={selectedRarity}
                      onChange={e => setSelectedRarity(e.target.value)}
                      className="px-2.5 py-1.5 rounded-xl bg-black/60 border border-white/15 text-white text-xs font-mono focus:outline-none"
                    >
                      <option value="ALL">All Rarities</option>
                      <option value="COMMON">COMMON</option>
                      <option value="UNCOMMON">UNCOMMON</option>
                      <option value="RARE">RARE</option>
                      <option value="EPIC">EPIC</option>
                      <option value="LEGENDARY">LEGENDARY</option>
                    </select>
                  </div>
                </div>

                {/* Available Cards Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2 max-h-60 overflow-y-auto p-1 rounded-2xl bg-black/40 border border-white/5">
                  {filteredCatalog.map(card => {
                    const countInSquad = enemyDeckCardIds.filter(id => id === card.id).length;
                    const isFull = enemyDeckCardIds.length >= 4;

                    return (
                      <button
                        key={card.id}
                        type="button"
                        onClick={() => handleAddCard(card.id)}
                        disabled={isFull}
                        className={`p-1.5 rounded-xl border text-left transition-all relative flex flex-col justify-between ${
                          countInSquad > 0
                            ? 'bg-teal-950/40 border-teal-500/60'
                            : 'bg-black/60 border-white/10 hover:border-white/30'
                        } ${isFull ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer hover:scale-102'}`}
                      >
                        {countInSquad > 0 && (
                          <span className="absolute top-2 right-2 px-1.5 py-0.5 rounded-full bg-teal-500 text-black text-[9px] font-mono font-bold z-10">
                            x{countInSquad}
                          </span>
                        )}

                        <img
                          src={card.imageUrl}
                          alt={card.name}
                          className="w-full h-20 object-cover rounded-lg mb-1"
                        />

                        <h5 className="text-[11px] font-bold text-white truncate font-sans">
                          {card.name}
                        </h5>

                        <div className="flex items-center justify-between text-[9px] font-mono text-slate-400 mt-0.5">
                          <span className="text-teal-300">{card.element || 'ASTRAL'}</span>
                          <span>⚔️{card.attack}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: DIFFICULTY & REWARDS */}
          {activeTab === 'REWARDS' && (
            <div className="space-y-6">
              {/* Fight Classification Selection (Normal, Boss, or Chapter Finale) */}
              <div className="space-y-3 p-4 rounded-2xl bg-black/60 border border-teal-500/30">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-mono text-[#5eead4] block uppercase tracking-wider font-bold">
                    {isAr ? 'نوع المعركة وتصنيف النزال:' : 'Fight Type & Chapter Progression Role:'}
                  </label>
                  <span className="text-[11px] font-mono text-amber-300 font-bold">
                    {fightClassification === 'CHAPTER_FINALE'
                      ? (isAr ? '👑 معركة نهاية الفصل' : '👑 Chapter Finale')
                      : fightClassification === 'BOSS'
                      ? (isAr ? '💀 معركة زعيم' : '💀 Boss Encounter')
                      : (isAr ? '⚔️ معركة عادية' : '⚔️ Normal Fight')}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Option 1: Normal Fight */}
                  <button
                    type="button"
                    onClick={() => {
                      setFightClassification('NORMAL');
                      setDifficulty('NORMAL');
                    }}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      fightClassification === 'NORMAL'
                        ? 'border-teal-400 bg-teal-500/20 text-white ring-2 ring-teal-400/40 shadow-lg'
                        : 'border-white/10 bg-black/40 text-slate-400 hover:border-white/25'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Swords size={16} className={fightClassification === 'NORMAL' ? 'text-teal-300' : 'text-slate-400'} />
                      <span className="text-xs font-mono font-bold text-white">
                        {isAr ? 'معركة عادية' : 'Normal Fight'}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono opacity-80 block leading-relaxed">
                      {isAr ? 'مواجهة تكتيكية قياسية للمسار الاستكشافي' : 'Standard tactical journey encounter'}
                    </span>
                  </button>

                  {/* Option 2: Boss Fight */}
                  <button
                    type="button"
                    onClick={() => {
                      setFightClassification('BOSS');
                      setDifficulty('BOSS');
                    }}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      fightClassification === 'BOSS'
                        ? 'border-rose-500 bg-rose-500/20 text-white ring-2 ring-rose-500/40 shadow-lg'
                        : 'border-white/10 bg-black/40 text-slate-400 hover:border-white/25'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Skull size={16} className={fightClassification === 'BOSS' ? 'text-rose-400' : 'text-slate-400'} />
                      <span className="text-xs font-mono font-bold text-white">
                        {isAr ? 'معركة زعيم' : 'Boss Fight'}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono opacity-80 block leading-relaxed">
                      {isAr ? 'مواجهة رئيسية كبرى بقائد مدرع وقوة مضاعفة' : 'Major boss duel with reinforced guard & higher stakes'}
                    </span>
                  </button>

                  {/* Option 3: Final Fight of Chapter */}
                  <button
                    type="button"
                    onClick={() => {
                      setFightClassification('CHAPTER_FINALE');
                      setDifficulty('CHAPTER_FINALE');
                    }}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      fightClassification === 'CHAPTER_FINALE'
                        ? 'border-amber-400 bg-gradient-to-r from-amber-500/25 via-amber-400/20 to-purple-500/20 text-white ring-2 ring-amber-400/50 shadow-xl'
                        : 'border-white/10 bg-black/40 text-slate-400 hover:border-white/25'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Crown size={16} className={fightClassification === 'CHAPTER_FINALE' ? 'text-amber-400' : 'text-slate-400'} />
                      <span className="text-xs font-mono font-bold text-white">
                        {isAr ? 'المعركة الختامية للفصل' : 'Chapter Finale'}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono opacity-80 block leading-relaxed">
                      {isAr ? 'البوابة الأخيرة لختام الفصل مع أعلى مكافآت التحدي' : 'Climactic final gate showdown that conquers the chapter'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Coin & XP Bounties */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5 p-3.5 rounded-2xl bg-black/60 border border-amber-500/30">
                  <label className="text-xs font-mono text-amber-300 flex items-center gap-1.5 font-bold">
                    <Coins size={14} />
                    <span>{isAr ? 'عملات الفوز المتكرر:' : 'Repeat Win Coins:'}</span>
                  </label>
                  <input
                    type="number"
                    min="10"
                    max="10000"
                    value={rewardCoins}
                    onChange={e => setRewardCoins(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-black/80 border border-white/15 text-white text-xs font-mono focus:border-amber-400 focus:outline-none"
                  />
                  <span className="text-[10px] font-mono text-slate-400 block">
                    {isAr ? 'يحصل عليها اللاعب عند كل فوز' : 'Awarded every time player clears this fight'}
                  </span>
                </div>

                <div className="space-y-1.5 p-3.5 rounded-2xl bg-black/60 border border-amber-500/30">
                  <label className="text-xs font-mono text-amber-300 flex items-center gap-1.5 font-bold">
                    <Sparkles size={14} />
                    <span>{isAr ? 'مكافأة الفوز الأول (Bonus):' : 'First-Clear Bonus Coins:'}</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="20000"
                    value={firstClearBonusCoins}
                    onChange={e => setFirstClearBonusCoins(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-black/80 border border-white/15 text-white text-xs font-mono focus:border-amber-400 focus:outline-none"
                  />
                  <span className="text-[10px] font-mono text-slate-400 block">
                    {isAr ? 'تمنح مرة واحدة فقط كإنجاز' : 'One-time bonus upon first victory'}
                  </span>
                </div>

                <div className="space-y-1.5 p-3.5 rounded-2xl bg-black/60 border border-teal-500/30">
                  <label className="text-xs font-mono text-[#5eead4] flex items-center gap-1.5 font-bold">
                    <Trophy size={14} />
                    <span>{isAr ? 'نقاط الخبرة (XP):' : 'XP Awarded:'}</span>
                  </label>
                  <input
                    type="number"
                    min="10"
                    max="5000"
                    value={rewardXp}
                    onChange={e => setRewardXp(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-black/80 border border-white/15 text-white text-xs font-mono focus:border-[#5eead4] focus:outline-none"
                  />
                  <span className="text-[10px] font-mono text-slate-400 block">
                    {isAr ? 'تزيد من مستوى حساب اللاعب' : 'Increases player level profile'}
                  </span>
                </div>
              </div>

              {/* Unlock Requirement */}
              <div className="space-y-2 p-3.5 rounded-2xl bg-black/60 border border-white/10">
                <label className="text-xs font-mono text-slate-300 flex items-center gap-1.5 font-bold">
                  <Lock size={14} className="text-amber-400" />
                  <span>{isAr ? 'شرط فتح المعركة (المعركة السابقة المطلوبة):' : 'Unlock Requirement (Prerequisite Battle):'}</span>
                </label>

                <select
                  value={unlockRequirementId || ''}
                  onChange={e => setUnlockRequirementId(e.target.value ? e.target.value : null)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-black/80 border border-white/15 text-white text-xs font-mono focus:outline-none"
                >
                  <option value="">{isAr ? 'مفتوحة تلقائياً (معركة بداية)' : 'None (Unlocked by Default / Starter Battle)'}</option>
                  {existingBattles
                    .filter(b => !battleToEdit || b.id !== battleToEdit.id)
                    .map(b => (
                      <option key={b.id} value={b.id}>
                        {isAr ? `تتطلب إكمال: ${b.nameAr || b.name} (#${b.battleNumber})` : `Requires clearing: ${b.name} (#${b.battleNumber})`}
                      </option>
                    ))}
                </select>
              </div>
            </div>
          )}

          {/* Footer Actions */}
          <div className="pt-4 border-t border-teal-500/20 flex items-center justify-between gap-3 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 text-xs font-mono transition-all"
            >
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>

            <button
              type="submit"
              disabled={isSubmitting || isCompressingAvatar || isCompressingBg}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 hover:brightness-110 active:scale-98 text-black font-extrabold text-xs font-mono flex items-center gap-2 shadow-lg shadow-teal-500/25 transition-all cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <Loader2 size={14} className="animate-spin" />
                  <span>{isAr ? 'جاري الحفظ...' : 'Saving...'}</span>
                </>
              ) : (
                <>
                  <Sparkles size={14} />
                  <span>{battleToEdit ? (isAr ? 'حفظ التعديلات' : 'Save Changes') : (isAr ? 'نشر المعركة' : 'Publish Battle')}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
