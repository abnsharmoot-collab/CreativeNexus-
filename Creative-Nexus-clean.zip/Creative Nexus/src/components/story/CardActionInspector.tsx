import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { BattleCardEntity, CombatIntentType, ACTION_CONFIGS } from '../../types/story';
import { playBattleSound } from '../../utils/battleAudio';
import { Swords, Flame, Shield, Zap, X, Heart, Sparkles, AlertTriangle, Wind, Droplet, Music, Backpack } from 'lucide-react';
import { getRarityConfig } from '../../config/rarityConfig';
import { LegendaryCombatAudioModal } from '../cards/LegendaryCombatAudioModal';

export interface CardActionOrigin {
  left?: number;
  top?: number;
  width?: number;
  height?: number;
  rotateZ?: number;
  x?: number;
  y?: number;
}

interface CardActionInspectorProps {
  card: BattleCardEntity;
  cardIndex: number;
  origin?: CardActionOrigin | null;
  isOpen: boolean;
  onClose: () => void;
  onSelectAction: (action: CombatIntentType, cardIndex: number) => void;
  onOpenItemsModal?: () => void;
  battleItemsCount?: number;
  isAr: boolean;
}

export const CardActionInspector: React.FC<CardActionInspectorProps> = ({
  card,
  cardIndex,
  origin,
  isOpen,
  onClose,
  onSelectAction,
  isAr
}) => {
  // Choreography:
  // 1. Two left cards (indices 0 & 1) pop out to the LEFT side with LEFT 3D tilt.
  // 2. Two right cards (indices 2 & 3) pop out to the RIGHT side with RIGHT 3D tilt.
  // 3. Card is positioned prominently above the bars.
  // 4. Slowly the bars emerge DOWN the card with matching 3D tilt and the SAME living flow as the card!
  // 5. When pressing away:
  //    - Bars slide back under the card and disappear.
  //    - Then slowly the card moves through 3D space directly back to its exact place in the tray.
  const [barsVisible, setBarsVisible] = useState(false);
  const [dismissingBars, setDismissingBars] = useState(false);
  const [isReturningCard, setIsReturningCard] = useState(false);
  const [isThrowing, setIsThrowing] = useState(false);
  const [hasEntered, setHasEntered] = useState(false);
  const [isAudioModalOpen, setIsAudioModalOpen] = useState(false);

  const mountedAtRef = useRef<number>(Date.now());
  const [windowDims, setWindowDims] = useState({
    w: typeof window !== 'undefined' ? window.innerWidth : 400,
    h: typeof window !== 'undefined' ? window.innerHeight : 800
  });

  useEffect(() => {
    const handleResize = () => {
      setWindowDims({ w: window.innerWidth, h: window.innerHeight });
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const W = windowDims.w;
  const H = windowDims.h;
  const isMobile = W < 640;

  // The two cards on the left (0, 1) go to the left side; the two cards on the right (2, 3) go to the right side!
  const isLeftSide = cardIndex < 2;

  // Target card dimensions
  const targetW = isMobile 
    ? Math.max(155, Math.min(185, Math.floor(W * 0.44))) 
    : Math.min(235, Math.max(205, Math.floor(W * 0.22)));
  const targetH = Math.round(targetW * 1.4); // 5/7 ratio

  // Target card position: Left side for cards 0 & 1, Right side for cards 2 & 3
  const targetLeft = isLeftSide
    ? (isMobile ? Math.max(16, Math.floor(W * 0.05)) : Math.max(48, Math.floor(W * 0.09)))
    : (isMobile ? W - targetW - Math.max(16, Math.floor(W * 0.05)) : W - targetW - Math.max(48, Math.floor(W * 0.09)));

  const targetTop = isMobile 
    ? Math.max(52, Math.floor(H * 0.15)) 
    : Math.max(72, Math.floor(H * 0.18));

  const targetCenterX = targetLeft + targetW / 2;
  const targetCenterY = targetTop + targetH / 2;

  // Bars width and horizontal placement (aligned cleanly with the card)
  const barsW = Math.max(targetW, isMobile ? Math.min(235, W - 32) : 265);
  const barsLeft = isLeftSide 
    ? targetLeft 
    : Math.max(16, targetLeft + targetW - barsW);

  // Resolve origin center and scale directly from the measured tray bounding rect
  const originW = origin?.width && origin.width > 0 ? origin.width : 70;
  const originH = origin?.height && origin.height > 0 ? origin.height : 98;
  const originLeft = origin?.left !== undefined 
    ? origin.left 
    : (origin?.x !== undefined ? W / 2 + origin.x - originW / 2 : W / 2 - originW / 2);
  const originTop = origin?.top !== undefined 
    ? origin.top 
    : (origin?.y !== undefined ? H / 2 + origin.y - originH / 2 : H - 140);

  const originCenterX = originLeft + originW / 2;
  const originCenterY = originTop + originH / 2;
  const originRotateZ = origin?.rotateZ ?? ((cardIndex - 1.5) * 3);

  // Exact coordinate deltas from target to origin
  const deltaX = Math.round(originCenterX - targetCenterX);
  const deltaY = Math.round(originCenterY - targetCenterY);
  const startScale = Math.min(0.85, Math.max(0.35, originW / targetW));

  // Dynamic 3D tilt
  const tilt3D = {
    rotateX: 12,
    rotateY: isLeftSide ? 15 : -15,
    rotateZ: isLeftSide ? -3.5 : 3.5
  };

  // 4-Action Resource System: HP & Stamina (100 Max)
  const currentStamina = card.currentStamina ?? 100;
  const maxStamina = 100;
  const isExhausted = currentStamina <= 0;
  const staminaPct = Math.max(0, Math.min(100, Math.round((currentStamina / maxStamina) * 100)));

  const hpPct = Math.max(0, Math.min(100, Math.round((card.currentHp / (card.maxHp || 100)) * 100)));

  const skill = card.skill;
  const isSkillReady = !skill || skill.currentCooldown === 0;
  const skillStaminaCost = skill?.staminaCost || 35;

  // Card Rarity restrictions:
  // - SKILL: ONLY available for RARE, EPIC, LEGENDARY, and HALLOWEEN cards
  // - ULTIMATE: Available for LEGENDARY and HALLOWEEN cards!
  const rawRarity = (card.rarity || card.card?.rarity || 'COMMON').toUpperCase();
  const isHalloween = 
    rawRarity === 'HALLOWEEN_2026' || 
    (card.card?.rarity as string)?.toUpperCase() === 'HALLOWEEN_2026' ||
    card.card?.frameStyle === 'halloween_spectral' ||
    card.card?.foilStyle === 'halloween_specter' ||
    Boolean(card.card?.name && /halloween/i.test(card.card.name)) ||
    Boolean((card.card as any)?.title && /halloween/i.test((card.card as any).title));

  const isLegendary = rawRarity === 'LEGENDARY';
  const hasSkill = rawRarity === 'RARE' || rawRarity === 'EPIC' || isLegendary || isHalloween;
  const hasUltimate = isLegendary || isHalloween;

  // Affordability rules:
  // - STRIKE: 15 Stamina (Hand limb punch)
  // - HEAVY: 30 Stamina (Leg limb kick)
  // - DEFENSE: Always available (Dual arms guard)
  // - SKILL: Consumes 35 Stamina (Special body skill)
  // - ULTIMATE: Available for Halloween and Legendary cards, consumes 40 Stamina
  const canAffordStrike = currentStamina >= 15;
  const canAffordHeavy = !isExhausted && currentStamina >= 30;
  const canAffordDefend = true;
  const canAffordSkill = hasSkill && isSkillReady && currentStamina >= skillStaminaCost;
  const canAffordUltimate = hasUltimate && !isExhausted && currentStamina >= 40;

  // Mount sequence
  useEffect(() => {
    mountedAtRef.current = Date.now();
    playBattleSound('CARD_POP_FORWARD', 0.95);

    const tEnter = setTimeout(() => {
      setHasEntered(true);
    }, 450);

    const tBars = setTimeout(() => {
      setBarsVisible(true);
      playBattleSound('HUD_SLIDE', 0.85);
    }, 480);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isReturningCard && !isThrowing && !dismissingBars) {
        handlePressAway();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      clearTimeout(tEnter);
      clearTimeout(tBars);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  // When pressing away
  const handlePressAway = () => {
    if (dismissingBars || isReturningCard || isThrowing) return;

    setDismissingBars(true);
    setBarsVisible(false);
    playBattleSound('HUD_SLIDE', 0.7);

    setTimeout(() => {
      setIsReturningCard(true);
      playBattleSound('CARD_RETURN_TRAY', 0.9);

      setTimeout(() => {
        onClose();
      }, 480);
    }, 240);
  };

  // Action selected -> proceed to battle clash
  const handleActionClick = (action: CombatIntentType) => {
    if (dismissingBars || isReturningCard || isThrowing) return;
    setIsThrowing(true);
    playBattleSound('TACTICAL_SELECT', 1.0);

    setBarsVisible(false);
    setDismissingBars(true);

    setTimeout(() => {
      onSelectAction(action, cardIndex);
    }, 250);
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-[100] select-none overflow-hidden touch-manipulation"
      style={{ perspective: '1200px' }}
      dir="ltr"
    >
      {/* Fullscreen Dimmed Atmospheric Backdrop */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: isReturningCard || isThrowing ? 0 : 1 }}
        transition={{ duration: 0.32, ease: 'easeOut' }}
        onClick={(e) => {
          e.stopPropagation();
          if (Date.now() - mountedAtRef.current < 200) return;
          handlePressAway();
        }}
        className="absolute inset-0 bg-slate-950/80 backdrop-blur-md cursor-pointer"
      />

      {/* Floating Tactical Dust & Light Aura */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-25"
        style={{
          backgroundImage: 'radial-gradient(circle at 50% 40%, rgba(94, 234, 212, 0.18) 0%, transparent 60%)'
        }}
      />

      {/* Main 3D Stage Container */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{ transformStyle: 'preserve-3d' }}
      >
        {/* ================================================================= */}
        {/* 1. PHYSICAL 3D CARD ELEMENT                                       */}
        {/* ================================================================= */}
        <motion.div
          initial={{
            x: deltaX,
            y: deltaY,
            scale: startScale,
            rotateX: 0,
            rotateY: 0,
            rotateZ: originRotateZ,
            opacity: 0.9
          }}
          animate={
            isReturningCard
              ? {
                  x: deltaX,
                  y: deltaY,
                  scale: startScale,
                  rotateX: 0,
                  rotateY: 0,
                  rotateZ: originRotateZ,
                  opacity: 0.95
                }
              : isThrowing
                ? {
                    x: isLeftSide ? -100 : 100,
                    y: -140,
                    scale: 0.85,
                    rotateX: 20,
                    rotateY: isLeftSide ? 25 : -25,
                    rotateZ: isLeftSide ? -8 : 8,
                    opacity: 0
                  }
                : hasEntered
                  ? {
                      x: 0,
                      y: [0, -3.5, 0],
                      scale: [1, 1.015, 1],
                      rotateX: [tilt3D.rotateX, tilt3D.rotateX + 1.2, tilt3D.rotateX],
                      rotateY: [tilt3D.rotateY, tilt3D.rotateY + (isLeftSide ? -1.5 : 1.5), tilt3D.rotateY],
                      rotateZ: [tilt3D.rotateZ, tilt3D.rotateZ + (isLeftSide ? 0.8 : -0.8), tilt3D.rotateZ],
                      opacity: 1
                    }
                  : {
                      x: 0,
                      y: 0,
                      scale: 1,
                      rotateX: tilt3D.rotateX,
                      rotateY: tilt3D.rotateY,
                      rotateZ: tilt3D.rotateZ,
                      opacity: 1
                    }
          }
          transition={
            isReturningCard
              ? {
                  duration: 0.46,
                  ease: [0.22, 1, 0.36, 1]
                }
              : isThrowing
                ? {
                    duration: 0.28,
                    ease: [0.32, 0, 0.67, 0]
                  }
                : hasEntered
                  ? {
                      y: { duration: 3.2, repeat: Infinity, ease: 'easeInOut' },
                      scale: { duration: 3.2, repeat: Infinity, ease: 'easeInOut' },
                      rotateX: { duration: 3.2, repeat: Infinity, ease: 'easeInOut' },
                      rotateY: { duration: 3.2, repeat: Infinity, ease: 'easeInOut' },
                      rotateZ: { duration: 3.2, repeat: Infinity, ease: 'easeInOut' }
                    }
                  : {
                      duration: 0.44,
                      ease: [0.22, 1, 0.36, 1]
                    }
          }
          style={{
            position: 'absolute',
            left: targetLeft,
            top: targetTop,
            width: targetW,
            height: targetH,
            transformStyle: 'preserve-3d',
            willChange: 'transform, opacity'
          }}
          className="z-30 pointer-events-auto"
        >
          {/* Card Body with Acrylic Bevel & Rarity-Based Specular Lighting */}
          {(() => {
            const rarityConf = getRarityConfig(card.card?.rarity || card.rarity);
            return (
              <div 
                className="w-full h-full rounded-2xl overflow-hidden border-2 flex flex-col justify-between relative select-none"
                style={{
                  background: rarityConf.bgGradient,
                  borderColor: rarityConf.borderColor,
                  boxShadow: `${rarityConf.depthShadow}, 0 0 24px ${rarityConf.glowColor}`
                }}
              >
                {/* Rarity-specific Ambient Glow */}
                <div 
                  className="absolute inset-0 pointer-events-none opacity-30"
                  style={{
                    background: `radial-gradient(circle at 50% 20%, ${rarityConf.glowColor} 0%, transparent 75%)`
                  }}
                />

                {/* Top Specular Rim */}
                <div 
                  className="absolute top-0 inset-x-0 h-[2px] opacity-95 pointer-events-none" 
                  style={{
                    background: `linear-gradient(to right, transparent, ${rarityConf.accentColor}, transparent)`
                  }}
                />

                {/* Card Artwork with Rarity Profile */}
                <img 
                  src={card.card.imageUrl} 
                  alt={card.card.name} 
                  className={`absolute inset-0 w-full h-full object-cover pointer-events-none ${rarityConf.saturationClass}`}
                />

                {/* Subtle Gradient Veil */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/92 via-black/25 to-black/55 pointer-events-none" />

                {/* Top Card Bar: Name & Shield */}
                <div className="relative z-10 px-2 sm:px-2.5 py-1.5 flex items-center justify-between pointer-events-none">
                  <span 
                    className="text-[10px] xs:text-[11px] sm:text-[13px] font-black font-sans text-white drop-shadow-[0_1px_4px_rgba(0,0,0,1)] tracking-wide truncate"
                    style={{
                      color: rarityConf.id === 'LEGENDARY' ? '#fef08a' : rarityConf.id === 'EPIC' ? '#f3e8ff' : '#ffffff'
                    }}
                  >
                    {card.card.name}
                  </span>
                  <div className="flex items-center gap-1">
                    {isLegendary && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setIsAudioModalOpen(true);
                        }}
                        className="p-1 rounded-md bg-amber-500/25 hover:bg-amber-400 text-amber-300 hover:text-stone-950 border border-amber-400/50 pointer-events-auto transition-colors cursor-pointer shadow-xs"
                        title={isAr ? 'تخصيص مؤثرات الصوت الأسطورية' : 'Legendary SFX Settings'}
                      >
                        <Music size={10} />
                      </button>
                    )}
                    {card.shield > 0 && (
                      <span className="px-1.5 py-0.5 rounded-full bg-blue-500/30 border border-blue-400 text-blue-200 text-[8px] font-mono font-bold flex items-center gap-0.5 shadow-sm">
                        <Shield size={8.5} />
                        +{card.shield}
                      </span>
                    )}
                  </div>
                </div>

                {/* Exhausted State Banner on Card */}
                {isExhausted && (
                  <div className="absolute inset-0 z-15 bg-black/60 flex items-center justify-center pointer-events-none backdrop-blur-[1px]">
                    <div className="px-3 py-1 rounded-full bg-rose-600/90 border border-rose-300 text-white font-mono font-black text-[9px] uppercase tracking-wider animate-pulse flex items-center gap-1 shadow-lg">
                      <AlertTriangle size={11} className="text-yellow-300" />
                      <span>{isAr ? 'منهك تماماً' : 'EXHAUSTED'}</span>
                    </div>
                  </div>
                )}

                {/* Bottom Card Bar: Jewel Dot + ATK, STM, DEF (No rarity text) */}
                <div className="relative z-10 px-2 sm:px-2.5 pb-2 pt-1 flex items-center justify-between text-[8px] xs:text-[9px] sm:text-[10px] font-mono font-black text-slate-200 drop-shadow pointer-events-none">
                  <span 
                    className="w-2 h-2 rounded-full shrink-0 shadow-xs"
                    style={{ backgroundColor: rarityConf.accentColor, boxShadow: `0 0 6px ${rarityConf.glowColor}` }}
                  />

                  <div className="flex items-center gap-2">
                    <span className="text-cyan-300">ATK {card.attack}</span>
                    <span className="text-emerald-300">STM {currentStamina}</span>
                    <span className="text-amber-300">DEF {card.defense}</span>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Close Handle / Tap Away Hint */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handlePressAway();
            }}
            className={`absolute -top-3.5 ${isLeftSide ? '-right-3.5' : '-left-3.5'} z-40 w-7 h-7 rounded-full bg-slate-900 border border-cyan-400/80 text-cyan-300 hover:text-white hover:bg-cyan-950 flex items-center justify-center shadow-lg transition-transform hover:scale-110 active:scale-95 cursor-pointer touch-manipulation`}
            title={isAr ? 'إغلاق' : 'Close'}
          >
            <X size={14} />
          </button>
        </motion.div>

        {/* ================================================================= */}
        {/* 2. BARS & 4 ACTION BUTTONS HUD (DOWN THE CARD)                    */}
        {/* ================================================================= */}
        <motion.div
          initial={{
            y: -12,
            scale: 0.94,
            opacity: 0,
            rotateX: tilt3D.rotateX,
            rotateY: tilt3D.rotateY,
            rotateZ: tilt3D.rotateZ
          }}
          animate={
            barsVisible && !dismissingBars && !isReturningCard && !isThrowing
              ? hasEntered
                ? {
                    y: [-1, -4, -1],
                    scale: [1, 1.015, 1],
                    opacity: 1,
                    rotateX: [tilt3D.rotateX, tilt3D.rotateX + 1.2, tilt3D.rotateX],
                    rotateY: [tilt3D.rotateY, tilt3D.rotateY + (isLeftSide ? -1.5 : 1.5), tilt3D.rotateY],
                    rotateZ: [tilt3D.rotateZ, tilt3D.rotateZ + (isLeftSide ? 0.8 : -0.8), tilt3D.rotateZ]
                  }
                : {
                    y: 0,
                    scale: 1,
                    opacity: 1,
                    rotateX: tilt3D.rotateX,
                    rotateY: tilt3D.rotateY,
                    rotateZ: tilt3D.rotateZ
                  }
              : {
                  y: -12,
                  scale: 0.94,
                  opacity: 0,
                  rotateX: tilt3D.rotateX,
                  rotateY: tilt3D.rotateY,
                  rotateZ: tilt3D.rotateZ
                }
          }
          transition={
            barsVisible && !dismissingBars && !isReturningCard && !isThrowing
              ? hasEntered
                ? {
                    y: { duration: 3.2, repeat: Infinity, ease: 'easeInOut' },
                    scale: { duration: 3.2, repeat: Infinity, ease: 'easeInOut' },
                    rotateX: { duration: 3.2, repeat: Infinity, ease: 'easeInOut' },
                    rotateY: { duration: 3.2, repeat: Infinity, ease: 'easeInOut' },
                    rotateZ: { duration: 3.2, repeat: Infinity, ease: 'easeInOut' }
                  }
                : {
                    duration: 0.36,
                    ease: [0.16, 1, 0.3, 1]
                  }
              : {
                  duration: 0.24,
                  ease: 'easeInOut'
                }
          }
          style={{ 
            position: 'absolute',
            left: barsLeft,
            top: targetTop + targetH + 8,
            width: barsW,
            transformStyle: 'preserve-3d',
            willChange: 'transform'
          }}
          className="relative flex flex-col gap-1.5 xs:gap-2 p-2 xs:p-2.5 sm:p-3 rounded-2xl bg-slate-900/95 border border-cyan-500/50 shadow-[0_16px_45px_rgba(0,0,0,0.92),0_0_25px_rgba(94,234,212,0.3)] backdrop-blur-xl pointer-events-auto"
          onClick={(e) => e.stopPropagation()}
        >
          {/* A. BARS SECTION: HP & STAMINA */}
          <div className="space-y-1.5 w-full pb-1.5 border-b border-white/10">
            {/* Health Bar (HP) */}
            <div>
              <div className="flex items-center justify-between text-[8px] xs:text-[9px] sm:text-[10px] font-mono font-black text-white mb-0.5">
                <span className="flex items-center gap-1 text-cyan-300">
                  <Heart size={9.5} className="text-cyan-400 fill-cyan-400/20" />
                  <span>{isAr ? 'الصحة' : 'HP'}</span>
                </span>
                <span className={hpPct > 50 ? 'text-[#5eead4]' : hpPct > 20 ? 'text-amber-300' : 'text-rose-400 font-black'}>
                  {card.currentHp} / {card.maxHp || 100}
                </span>
              </div>
              <div className="relative w-full h-1.5 xs:h-2 rounded-full bg-slate-950 border border-white/20 overflow-hidden p-[0.5px] shadow-inner">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${hpPct}%` }}
                  transition={{ duration: 0.45, ease: 'easeOut' }}
                  className={`h-full rounded-full relative overflow-hidden ${
                    hpPct > 50 
                      ? 'bg-gradient-to-r from-teal-500 via-cyan-400 to-[#5eead4] shadow-[0_0_10px_rgba(94,234,212,0.9)]' 
                      : hpPct > 20 
                        ? 'bg-gradient-to-r from-amber-500 to-yellow-300 shadow-[0_0_8px_rgba(245,158,11,0.8)]' 
                        : 'bg-gradient-to-r from-red-600 to-rose-400 shadow-[0_0_8px_rgba(244,63,94,0.8)]'
                  }`}
                />
              </div>
            </div>

            {/* Stamina Bar (STM) - Sole Resource */}
            <div>
              <div className="flex items-center justify-between text-[7.5px] xs:text-[8.5px] sm:text-[9.5px] font-mono font-black mb-0.5">
                <span className="flex items-center gap-1">
                  <Wind size={9} className={isExhausted ? 'text-rose-400' : 'text-emerald-400'} />
                  <span className={isExhausted ? 'text-rose-400 animate-pulse font-black' : 'text-emerald-300 font-bold'}>
                    {isExhausted ? (isAr ? 'منهك!' : 'EXHAUSTED') : (isAr ? 'الجهد / اللياقة' : 'STAMINA')}
                  </span>
                </span>
                <span className={isExhausted ? 'text-rose-400 font-bold' : 'text-emerald-300'}>
                  {currentStamina} / {maxStamina}
                </span>
              </div>
              <div className="relative w-full h-1.5 xs:h-2 rounded-full bg-slate-950 border border-emerald-500/30 overflow-hidden p-[0.5px] shadow-inner">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${staminaPct}%` }}
                  transition={{ duration: 0.45, ease: 'easeOut' }}
                  className={`h-full rounded-full transition-all duration-300 ${
                    isExhausted 
                      ? 'bg-rose-500' 
                      : staminaPct > 40 
                        ? 'bg-gradient-to-r from-emerald-500 to-teal-300 shadow-[0_0_8px_rgba(16,185,129,0.8)]' 
                        : 'bg-gradient-to-r from-amber-500 to-rose-400 shadow-[0_0_8px_rgba(245,158,11,0.8)]'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* B. 4 STRATEGIC ACTION BUTTONS: STRIKE, HEAVY, DEFENSE, SKILL */}
          <div className="w-full grid grid-cols-2 gap-1.5 pt-1">
            {/* 1. STRIKE */}
            <button
              type="button"
              disabled={!canAffordStrike}
              onClick={() => handleActionClick('STRIKE')}
              className={`py-2 px-2.5 rounded-xl border font-mono font-bold text-xs tracking-wider uppercase transition-all select-none touch-manipulation cursor-pointer flex items-center justify-center ${
                canAffordStrike
                  ? 'bg-slate-800/90 hover:bg-slate-700/90 text-cyan-300 border-cyan-500/40 hover:border-cyan-400 active:scale-95 shadow-sm'
                  : 'bg-slate-900/40 text-slate-500 border-slate-800/60 cursor-not-allowed opacity-50'
              }`}
            >
              STRIKE
            </button>

            {/* 2. HEAVY */}
            <button
              type="button"
              disabled={!canAffordHeavy}
              onClick={() => handleActionClick('HEAVY')}
              className={`py-2 px-2.5 rounded-xl border font-mono font-bold text-xs tracking-wider uppercase transition-all select-none touch-manipulation cursor-pointer flex items-center justify-center ${
                canAffordHeavy
                  ? 'bg-slate-800/90 hover:bg-slate-700/90 text-amber-300 border-amber-500/40 hover:border-amber-400 active:scale-95 shadow-sm'
                  : 'bg-slate-900/40 text-slate-500 border-slate-800/60 cursor-not-allowed opacity-50'
              }`}
            >
              HEAVY
            </button>

            {/* 3. DEFENSE */}
            <button
              type="button"
              disabled={!canAffordDefend}
              onClick={() => handleActionClick('DEFENSE')}
              className={`py-2 px-2.5 rounded-xl border font-mono font-bold text-xs tracking-wider uppercase transition-all select-none touch-manipulation cursor-pointer flex items-center justify-center ${
                canAffordDefend
                  ? 'bg-slate-800/90 hover:bg-slate-700/90 text-emerald-300 border-emerald-500/40 hover:border-emerald-400 active:scale-95 shadow-sm'
                  : 'bg-slate-900/40 text-slate-500 border-slate-800/60 cursor-not-allowed opacity-50'
              }`}
            >
              DEFENSE
            </button>

            {/* 4. SKILL */}
            <button
              type="button"
              disabled={!hasSkill || !canAffordSkill || !isSkillReady}
              onClick={() => hasSkill && canAffordSkill && isSkillReady && handleActionClick('SKILL')}
              className={`py-2 px-2.5 rounded-xl border font-mono font-bold text-xs tracking-wider uppercase transition-all select-none touch-manipulation cursor-pointer flex items-center justify-center ${
                hasSkill && canAffordSkill && isSkillReady
                  ? 'bg-slate-800/90 hover:bg-slate-700/90 text-purple-300 border-purple-500/40 hover:border-purple-400 active:scale-95 shadow-sm'
                  : 'bg-slate-900/40 text-slate-500 border-slate-800/60 cursor-not-allowed opacity-50'
              }`}
            >
              SKILL
            </button>
          </div>
        </motion.div>
      </div>

      {isAudioModalOpen && (
        <LegendaryCombatAudioModal
          isOpen={isAudioModalOpen}
          onClose={() => setIsAudioModalOpen(false)}
          targetCard={card.card as any}
          isAr={isAr}
        />
      )}
    </div>
  );
};
