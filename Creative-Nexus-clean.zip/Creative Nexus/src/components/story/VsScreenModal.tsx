import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PlayerDeck } from '../../types/decks';
import { StoryBattleDefinition } from '../../types/story';
import { CollectibleCardData } from '../../types/cards';
import { useLanguage } from '../../context/LanguageContext';
import { Swords, Shield, Coins, Sparkles, X, Flame, AlertCircle } from 'lucide-react';
import { playBattleSound } from '../../utils/battleAudio';
import { getRarityConfig } from '../../config/rarityConfig';

interface VsScreenModalProps {
  isOpen?: boolean;
  battle: StoryBattleDefinition;
  activeDeck?: PlayerDeck | null;
  playerCards?: CollectibleCardData[];
  enemyCards?: CollectibleCardData[];
  onProceed: () => void;
  onCancel?: () => void;
  onComplete?: () => void;
}

// Calculate 0-99 overall score from squad cards
export const calculateSquadOverall = (cards: CollectibleCardData[]): number => {
  if (!cards || cards.length === 0) return 70;
  const total = cards.reduce((sum, c) => {
    const computed = Math.round(
      (c.attack * 0.42) + 
      (c.defense * 0.35) + 
      ((c.hp || 100) * 0.23)
    );
    return sum + Math.max(50, Math.min(99, computed));
  }, 0);
  return Math.round(total / cards.length);
};

export const VsScreenModal: React.FC<VsScreenModalProps> = ({
  isOpen = true,
  battle,
  activeDeck,
  playerCards = [],
  enemyCards = [],
  onProceed,
  onCancel,
  onComplete
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const handleStart = () => {
    playBattleSound('FORMATION_SUMMON', 0.9);
    if (onProceed) onProceed();
    else if (onComplete) onComplete();
  };

  const handleClose = () => {
    playBattleSound('TACTICAL_SELECT', 0.7);
    if (onCancel) onCancel();
  };

  if (!isOpen) return null;

  const playerDisplayCards = playerCards.slice(0, 4);
  const enemyDisplayCards = enemyCards.slice(0, 4);

  const playerOverall = calculateSquadOverall(playerDisplayCards);
  const enemyOverall = calculateSquadOverall(enemyDisplayCards);

  const deckName = activeDeck?.name || (isAr ? 'فرقة الطليعة' : 'Vanguard Squad');
  const enemyCommanderName = isAr 
    ? battle.customCharacterNameAr || battle.enemyCommanderNameAr || battle.enemyCommanderName 
    : battle.customCharacterName || battle.enemyCommanderName;

  const getGridColsClass = (count: number) => {
    switch (count) {
      case 1: return 'grid-cols-1 max-w-[85px] sm:max-w-[110px] mx-auto';
      case 2: return 'grid-cols-2 max-w-[180px] sm:max-w-[220px] mx-auto';
      case 3: return 'grid-cols-3 max-w-[270px] sm:max-w-[330px] mx-auto';
      default: return 'grid-cols-4';
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-2 xs:p-3 sm:p-5 bg-black/90 backdrop-blur-xl overflow-y-auto select-none" 
      dir={isAr ? 'rtl' : 'ltr'}
      style={{
        fontFamily: isAr ? "'Cairo', 'Readex Pro', sans-serif" : "'Outfit', 'Readex Pro', sans-serif"
      }}
    >
      {/* Dynamic Background Atmosphere */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-teal-500/10 via-transparent to-black pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, scale: 0.94, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.25, ease: 'easeOut' }}
        className="relative w-full max-w-3xl bg-gradient-to-b from-[#071d22] via-[#031114] to-[#01080a] border border-cyan-500/40 rounded-2xl sm:rounded-3xl p-3.5 xs:p-4 sm:p-6 shadow-[0_0_60px_rgba(6,182,212,0.25)] flex flex-col justify-between max-h-[92dvh] overflow-y-auto my-auto"
      >
        {/* Top Close Button */}
        {onCancel && (
          <button
            type="button"
            onClick={handleClose}
            className="absolute top-3 right-3 sm:top-4 sm:right-4 p-1.5 sm:p-2 rounded-xl bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 transition-colors border border-white/10 cursor-pointer z-20"
            title={isAr ? 'إلغاء' : 'Cancel'}
          >
            <X size={15} />
          </button>
        )}

        {/* 1. HEADER: CONFIRMATION PROMPT */}
        <div className="text-center space-y-1 mb-2.5 sm:mb-4 px-6">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-[#5eead4] font-mono text-[9px] sm:text-xs tracking-widest uppercase font-bold">
            <Swords size={11} className="text-[#5eead4]" />
            <span className="truncate max-w-[200px] sm:max-w-none">{isAr ? battle.nameAr || battle.name : battle.name}</span>
            <span className="text-[7.5px] px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-200 border border-cyan-400/40 ml-1">
              {battle.difficulty}
            </span>
          </div>

          <h2 className="text-base xs:text-lg sm:text-2xl font-black text-white font-sans tracking-tight">
            {isAr ? 'هل أنت متأكد من بدء النزال؟' : 'ARE YOU SURE YOU WANT TO START?'}
          </h2>
          <p className="text-[10px] xs:text-[11px] sm:text-xs text-slate-400 font-mono">
            {isAr ? 'قارن تشكيلة بطاقاتك مع تشكيلة الخصم قبل دخول ساحة القتال' : 'Compare your squad power against the enemy formation before engaging'}
          </p>
        </div>

        {/* 2. DUAL SQUAD COMPARISON (MY DECK vs ENEMY DECK) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 sm:gap-4 my-1">
          
          {/* ================================================================= */}
          {/* PLAYER SQUAD (MY DECK)                                            */}
          {/* ================================================================= */}
          <div className="p-2.5 xs:p-3 sm:p-4 rounded-xl sm:rounded-2xl bg-cyan-950/25 border border-cyan-500/30 flex flex-col justify-between">
            {/* Header: Name + Overall Score */}
            <div className="flex items-center justify-between mb-2 pb-1.5 border-b border-cyan-500/20">
              <div className="flex items-center gap-1.5 min-w-0">
                <Shield size={14} className="text-[#5eead4] shrink-0" />
                <span className="text-xs sm:text-sm font-black text-white font-sans truncate">
                  {deckName}
                </span>
                <span className="text-[9px] font-mono text-cyan-300/70 shrink-0">
                  ({playerDisplayCards.length} {isAr ? 'بطاقات' : 'cards'})
                </span>
              </div>

              {/* USER OVERALL BADGE */}
              <div className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-cyan-500/20 border border-cyan-400 text-[#5eead4] shadow-[0_0_10px_rgba(94,234,212,0.3)] shrink-0">
                <span className="text-[9px] font-mono font-bold">{isAr ? 'المعدل:' : 'OVR:'}</span>
                <span className="text-xs sm:text-sm font-mono font-black">{playerOverall}</span>
              </div>
            </div>

            {/* Cards Grid */}
            <div className={`grid ${getGridColsClass(playerDisplayCards.length)} gap-1.5`}>
              {playerDisplayCards.map((card, idx) => {
                const conf = getRarityConfig(card.rarity);
                return (
                  <div 
                    key={card.id || idx} 
                    className="aspect-[5/7] rounded-lg sm:rounded-xl overflow-hidden border-2 bg-black relative flex flex-col justify-between shadow-md"
                    style={{
                      borderColor: conf.borderColor,
                      background: conf.bgGradient
                    }}
                  >
                    <img src={card.imageUrl} alt={card.name} className="absolute inset-0 w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-black/60 pointer-events-none" />
                    
                    <span 
                      className="relative z-10 px-1 py-0.5 text-[7.5px] xs:text-[8px] font-black truncate drop-shadow"
                      style={{ color: conf.accentColor }}
                    >
                      {card.name}
                    </span>

                    <div className="relative z-10 w-full px-1 py-0.5 bg-black/75 backdrop-blur-xs border-t border-white/10 flex items-center justify-between text-[6px] xs:text-[7px] font-mono font-black">
                      <span className="text-cyan-300">⚔️{card.attack}</span>
                      <span className="text-amber-300">🛡️{card.defense}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ================================================================= */}
          {/* ENEMY SQUAD (ENEMY DECK - EXACT NUMBER OF CHOSEN CARDS)           */}
          {/* ================================================================= */}
          <div className="p-2.5 xs:p-3 sm:p-4 rounded-xl sm:rounded-2xl bg-rose-950/20 border border-rose-500/30 flex flex-col justify-between">
            {/* Header: Name + Overall Score */}
            <div className="flex items-center justify-between mb-2 pb-1.5 border-b border-rose-500/20">
              <div className="flex items-center gap-1.5 min-w-0">
                <Flame size={14} className="text-rose-400 shrink-0" />
                <span className="text-xs sm:text-sm font-black text-white font-sans truncate">
                  {enemyCommanderName}
                </span>
                <span className="text-[9px] font-mono text-rose-300/70 shrink-0">
                  ({enemyDisplayCards.length} {isAr ? 'بطاقات' : 'cards'})
                </span>
              </div>

              {/* ENEMY OVERALL BADGE */}
              <div className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-rose-500/20 border border-rose-400 text-rose-300 shadow-[0_0_10px_rgba(244,63,94,0.3)] shrink-0">
                <span className="text-[9px] font-mono font-bold">{isAr ? 'المعدل:' : 'OVR:'}</span>
                <span className="text-xs sm:text-sm font-mono font-black">{enemyOverall}</span>
              </div>
            </div>

            {/* Cards Grid */}
            <div className={`grid ${getGridColsClass(enemyDisplayCards.length)} gap-1.5`}>
              {enemyDisplayCards.map((card, idx) => {
                const conf = getRarityConfig(card.rarity);
                return (
                  <div 
                    key={card.id || idx} 
                    className="aspect-[5/7] rounded-lg sm:rounded-xl overflow-hidden border-2 bg-black relative flex flex-col justify-between shadow-md"
                    style={{
                      borderColor: conf.borderColor,
                      background: conf.bgGradient
                    }}
                  >
                    <img src={card.imageUrl} alt={card.name} className="absolute inset-0 w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-black/60 pointer-events-none" />
                    
                    <span 
                      className="relative z-10 px-1 py-0.5 text-[7.5px] xs:text-[8px] font-black truncate drop-shadow"
                      style={{ color: conf.accentColor }}
                    >
                      {card.name}
                    </span>

                    <div className="relative z-10 w-full px-1 py-0.5 bg-black/75 backdrop-blur-xs border-t border-white/10 flex items-center justify-between text-[6px] xs:text-[7px] font-mono font-black">
                      <span className="text-rose-300">⚔️{card.attack}</span>
                      <span className="text-amber-300">🛡️{card.defense}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* 3. REWARD STAKES & ACTION BUTTONS (MOBILE-FIT LAYOUT) */}
        <div className="mt-2.5 sm:mt-4 pt-2.5 sm:pt-3 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Rewards Preview */}
          <div className="flex items-center gap-2.5 text-xs font-mono">
            <span className="text-slate-400 text-[10px] sm:text-xs">{isAr ? 'المكافآت:' : 'Rewards:'}</span>
            <div className="flex items-center gap-1 text-amber-300 font-bold px-2 py-0.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-[10px] sm:text-xs">
              <Coins size={12} className="text-amber-400" />
              <span>+{battle.rewardCoins}</span>
            </div>
            <div className="flex items-center gap-1 text-cyan-300 font-bold px-2 py-0.5 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-[10px] sm:text-xs">
              <Sparkles size={12} className="text-cyan-400" />
              <span>+{battle.rewardXp} XP</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            {onCancel && (
              <button
                type="button"
                onClick={handleClose}
                className="flex-1 sm:flex-none px-4 py-2 sm:py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 font-bold text-xs uppercase cursor-pointer border border-white/10 transition-colors text-center"
              >
                {isAr ? 'تراجع' : 'Cancel'}
              </button>
            )}

            <button
              type="button"
              onClick={handleStart}
              className="flex-1 sm:flex-none px-6 py-2 sm:py-2.5 rounded-xl bg-gradient-to-r from-teal-400 via-cyan-400 to-[#5eead4] hover:brightness-110 active:scale-95 text-slate-950 font-black text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(94,234,212,0.4)] cursor-pointer flex items-center justify-center gap-1.5"
            >
              <Swords size={14} />
              <span>{isAr ? 'بدء القتال' : 'START FIGHT'}</span>
            </button>
          </div>
        </div>

      </motion.div>
    </div>
  );
};
