import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BattleCardEntity, ClashResultData, CombatIntentType } from '../../types/story';
import { ACTIONS, validateCombatAction } from '../../config/combatActions';
import { Skull, Shield, Zap, AlertTriangle, Sparkles, Swords, Flame, Heart } from 'lucide-react';
import { getRarityConfig } from '../../config/rarityConfig';

export type ClashStage = 
  | 'IDLE' 
  | 'CARD_THROW' 
  | 'ACTION_CLASH' 
  | 'BARS_SHOW' 
  | 'BARS_TUCK_STRAIGHTEN' 
  | 'SWIPE_AWAY';

interface BattleActiveZoneProps {
  playerCard: BattleCardEntity | null;
  enemyCard: BattleCardEntity | null;
  turnNumber: number;
  clashData: ClashResultData | null;
  playerChosenAction: CombatIntentType | null;
  enemyRevealedAction: CombatIntentType | null;
  isTableEmpty: boolean;
  clashAnimationStage: ClashStage;
  tableSlamImpact: boolean;
  isCardSlamming?: boolean;
  bigClashWord?: string | null;
  floatingDamage: {
    target: 'PLAYER' | 'ENEMY';
    amount: number;
    isCrit?: boolean;
  } | null;
  isSelectingNextCard?: boolean;
  isAr: boolean;
  playerPreClash?: { hp: number; stamina: number; maxHp: number; maxStamina: number } | null;
  enemyPreClash?: { hp: number; stamina: number; maxHp: number; maxStamina: number } | null;
  isClashEffectApplied?: boolean;
  isEnemyCardFlipping?: boolean;
  dramaticBanner?: {
    text: string;
    textAr: string;
    color: string;
    sub: string;
  } | null;
  isHitstop?: boolean;
  koStamp?: string | null;
}

// Single Source of Truth Action icon and metadata display
const getActionDisplay = (action: CombatIntentType | string | null | undefined, isAr: boolean) => {
  const normalized = validateCombatAction(action) || 'strike';
  const def = ACTIONS[normalized] || ACTIONS.strike;
  return {
    icon: def.icon,
    label: isAr ? def.nameAr : def.name.toUpperCase(),
    shortLabel: isAr ? def.nameAr : def.name.toUpperCase(),
    color: def.color,
    badgeBg: def.badgeBg
  };
};

export const BattleActiveZone: React.FC<BattleActiveZoneProps> = ({
  playerCard,
  enemyCard,
  turnNumber,
  clashData,
  playerChosenAction,
  enemyRevealedAction,
  isTableEmpty,
  clashAnimationStage,
  tableSlamImpact,
  floatingDamage,
  isSelectingNextCard = false,
  isAr,
  playerPreClash,
  enemyPreClash,
  isClashEffectApplied = false,
  isEnemyCardFlipping = false,
  dramaticBanner,
  isHitstop = false,
  koStamp = null
}) => {
  // Enemy card face revealed once action clash happens or flipping triggered
  const isEnemyCardRevealed = 
    clashAnimationStage === 'ACTION_CLASH' || 
    clashAnimationStage === 'BARS_SHOW' || 
    clashAnimationStage === 'BARS_TUCK_STRAIGHTEN' || 
    clashAnimationStage === 'SWIPE_AWAY';

  const isEnemyFlipped = isEnemyCardFlipping || isEnemyCardRevealed;

  // Bars visible during BARS_SHOW and fading during BARS_TUCK_STRAIGHTEN
  const areBarsVisible = 
    clashAnimationStage === 'BARS_SHOW' || 
    clashAnimationStage === 'BARS_TUCK_STRAIGHTEN';

  // Action teller visible starting from ACTION_CLASH until SWIPE_AWAY finishes
  const isActionTellerVisible = 
    !isTableEmpty && 
    (clashAnimationStage === 'ACTION_CLASH' || 
     clashAnimationStage === 'BARS_SHOW' || 
     clashAnimationStage === 'BARS_TUCK_STRAIGHTEN' ||
     clashAnimationStage === 'SWIPE_AWAY');

  const playerActionMeta = getActionDisplay(playerChosenAction, isAr);
  const enemyActionMeta = getActionDisplay(enemyRevealedAction || 'STRIKE', isAr);

  // Normalize uppercase action names for minimal battle action result display
  const normalizeActionName = (action: string | null | undefined): string => {
    if (!action) return 'STRIKE';
    const act = action.toUpperCase();
    if (act === 'DEFEND') return 'DEFENSE';
    if (act === 'ABILITY') return 'SKILL';
    return act;
  };

  const enemyActionName = normalizeActionName(enemyRevealedAction);
  const playerActionName = normalizeActionName(playerChosenAction);

  // Simple result symbol: X when matching, ▲ when player wins, ▼ when enemy wins
  const getResultSymbol = (): string => {
    if (enemyActionName === playerActionName) {
      return 'X';
    }
    if (clashData?.winner === 'PLAYER') {
      return '▲';
    }
    if (clashData?.winner === 'ENEMY') {
      return '▼';
    }
    if (clashData?.winner === 'TIE') {
      return 'X';
    }
    if (
      (playerActionName === 'STRIKE' && enemyActionName === 'HEAVY') ||
      (playerActionName === 'HEAVY' && enemyActionName === 'DEFENSE') ||
      (playerActionName === 'DEFENSE' && enemyActionName === 'STRIKE') ||
      (playerActionName === 'SKILL' && enemyActionName === 'DEFENSE')
    ) {
      return '▲';
    }
    if (
      (enemyActionName === 'STRIKE' && playerActionName === 'HEAVY') ||
      (enemyActionName === 'HEAVY' && playerActionName === 'DEFENSE') ||
      (enemyActionName === 'DEFENSE' && playerActionName === 'STRIKE') ||
      (enemyActionName === 'SKILL' && playerActionName === 'DEFENSE')
    ) {
      return '▼';
    }
    if (floatingDamage?.target === 'ENEMY') return '▲';
    if (floatingDamage?.target === 'PLAYER') return '▼';
    return 'X';
  };

  const isRevealingActions = !isTableEmpty && (
    clashAnimationStage === 'ACTION_CLASH' || 
    clashAnimationStage === 'BARS_SHOW' || 
    clashAnimationStage === 'BARS_TUCK_STRAIGHTEN'
  );

  // =========================================================================
  // CARD BODY (CLEAN TACTILE ACRYLIC SLAB)
  // =========================================================================
  // =========================================================================
  // CARD BODY (MODERN PREMIUM ACRYLIC SLAB WITH FLOWING LIGHT)
  // =========================================================================
  const renderCardBody = (card: BattleCardEntity, isEnemy: boolean = false) => {
    const isDead = card.isDefeated || card.currentHp <= 0;
    const rarityConf = getRarityConfig(card.card?.rarity || card.rarity);
    const accentColor = rarityConf.accentColor;

    const currentCardAction = isEnemy 
      ? (enemyRevealedAction || 'STRIKE') 
      : (playerChosenAction || 'STRIKE');
    const isClashing = clashAnimationStage === 'ACTION_CLASH' || clashAnimationStage === 'BARS_SHOW';

    return (
      <div 
        className={`w-full h-full rounded-xl sm:rounded-2xl overflow-hidden border-2 flex flex-col justify-between relative select-none transition-all duration-300 ${
          isDead 
            ? 'border-slate-800 bg-slate-950 opacity-40 grayscale' 
            : 'shadow-[0_12px_32px_rgba(0,0,0,0.92)]'
        }`}
        style={{
          background: rarityConf.bgGradient,
          borderColor: isDead ? '#334155' : rarityConf.borderColor,
          boxShadow: isDead ? 'none' : `${rarityConf.depthShadow}, 0 0 16px ${rarityConf.glowColor}`
        }}
      >
        {/* Dynamic Elemental Action Aura when Clashing */}
        {isClashing && !isDead && (
          <div 
            className="absolute -inset-0.5 z-25 pointer-events-none rounded-[inherit] border-2 border-cyan-400/80 transition-opacity duration-200"
          />
        )}

        {/* Dynamic Hit Reaction & Damage Flash */}
        {floatingDamage?.target === (isEnemy ? 'ENEMY' : 'PLAYER') && floatingDamage.amount > 0 && (
          <motion.div 
            initial={{ opacity: 0.8 }}
            animate={{ opacity: 0 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="absolute inset-0 z-30 pointer-events-none rounded-[inherit] bg-rose-600/30"
          />
        )}

        {/* Deflection Barrier Flash */}
        {clashData?.clashType === 'DEFENSE_WALL' && isClashing && (
          ((isEnemy && clashData.winner === 'ENEMY') || (!isEnemy && clashData.winner === 'PLAYER')) && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.2 }}
              className="absolute inset-0 z-30 pointer-events-none rounded-[inherit] border-2 border-cyan-400 bg-cyan-500/25 backdrop-blur-[1px] shadow-[inset_0_0_25px_rgba(34,211,238,0.8),0_0_25px_#22d3ee]"
            />
          )
        )}
        {/* Soft Fluid Ambient Light Flow */}
        <div 
          className="absolute -inset-1/2 opacity-35 mix-blend-screen pointer-events-none animate-card-liquid"
          style={{
            background: `radial-gradient(circle at 40% 30%, ${accentColor}55 0%, transparent 60%)`
          }}
        />

        {/* Running Perimeter Light Rim */}
        <div className="absolute inset-0 rounded-[inherit] pointer-events-none z-25 overflow-hidden" aria-hidden="true">
          <div 
            className="absolute inset-0 rounded-[inherit] border border-transparent animate-card-perimeter opacity-70"
            style={{
              background: `linear-gradient(135deg, transparent 25%, ${accentColor} 50%, rgba(255,255,255,0.9) 55%, ${accentColor} 60%, transparent 80%) border-box`,
              WebkitMask: 'linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0)',
              WebkitMaskComposite: 'destination-out',
              maskComposite: 'exclude',
              borderWidth: '1.2px',
            }}
          />
        </div>

        {/* Specular Top Rim Highlight */}
        <div 
          className="absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-current to-transparent opacity-95 pointer-events-none z-20"
          style={{ color: accentColor }}
        />

        {/* Continuous Soft Fluid Sweep */}
        <div className="absolute -inset-full animate-card-sweep pointer-events-none z-15 opacity-25">
          <div 
            className="w-full h-full"
            style={{
              background: `linear-gradient(115deg, transparent 35%, rgba(255,255,255,0.2) 50%, ${accentColor}40 60%, transparent 70%)`
            }}
          />
        </div>

        {/* Card Artwork */}
        <img 
          src={card.card.imageUrl} 
          alt={card.card.name} 
          className="absolute inset-0 w-full h-full object-cover pointer-events-none filter brightness-100 contrast-105"
        />

        {/* Atmospheric Shading Gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/95 via-transparent to-slate-950/45 pointer-events-none" />

        {/* Top: Card Name ONLY (No numbers or extra words over table card) */}
        <div className="relative z-20 px-2 py-1 flex items-center justify-center pointer-events-none">
          <span 
            className="text-[8.5px] xs:text-[9.5px] sm:text-[11px] font-black font-sans text-white text-center truncate drop-shadow-[0_2px_4px_rgba(0,0,0,1)] tracking-wide"
            style={{
              textShadow: `0 0 12px ${accentColor}88, 0 1px 3px rgba(0,0,0,0.95)`
            }}
          >
            {card.card.name}
          </span>
        </div>

        {/* Skull Icon if Defeated (Icon only, zero words or numbers) */}
        {isDead && (
          <div className="absolute inset-0 z-30 bg-black/85 flex items-center justify-center pointer-events-none backdrop-blur-xs">
            <Skull size={22} className="text-slate-400" />
          </div>
        )}
      </div>
    );
  };

  // =========================================================================
  // OPPONENT CARD BACK (LUXURY HOLOGRAPHIC SLEEVE)
  // =========================================================================
  const renderEnemySecretBack = () => {
    return (
      <div 
        className="w-full h-full rounded-xl sm:rounded-2xl overflow-hidden border border-purple-500/70 shadow-[0_12px_28px_rgba(0,0,0,0.9),0_0_15px_rgba(192,132,252,0.3)] relative"
        style={{
          background: 'linear-gradient(145deg, #1b0728 0%, #0c0214 45%, #020005 100%)'
        }}
      >
        {/* Soft flowing radial aura */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(192,132,252,0.18),transparent_70%)] pointer-events-none" />

        {/* Micro-bezel double hairline */}
        <div className="absolute inset-1 border border-purple-400/30 rounded-lg pointer-events-none" />
        <div className="absolute inset-1.5 border border-dashed border-purple-400/20 rounded-md pointer-events-none" />

        {/* Central Prismatic Sigil */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none gap-1">
          <div className="w-6 h-6 rotate-45 border-2 border-purple-400/50 bg-purple-950/60 flex items-center justify-center shadow-[0_0_10px_rgba(192,132,252,0.5)]">
            <div className="w-3 h-3 rotate-45 bg-gradient-to-tr from-purple-500 to-cyan-400 opacity-80" />
          </div>
          <span className="text-[6px] font-mono font-bold tracking-widest text-purple-300/70 uppercase">
            NEXUS
          </span>
        </div>

        {/* Diagonal Soft Specular Glare */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/[0.05] to-transparent pointer-events-none" />
      </div>
    );
  };

  // =========================================================================
  // UPGRADED COMBAT STATS HUD (HP, STAMINA)
  // Shows right after action: glowing glassmorphic chassis, trailing ghost
  // damage bar, high-visibility typography, and combat delta indicator!
  // =========================================================================
  const renderLeftSideStatsPillar = (
    card: BattleCardEntity, 
    preClash?: { hp: number; stamina: number; maxHp: number; maxStamina: number } | null,
    isEnemy: boolean = false
  ) => {
    const maxHp = card.maxHp || preClash?.maxHp || 100;
    const preHp = preClash ? preClash.hp : card.currentHp;
    const currentHp = card.currentHp;
    const displayHp = isClashEffectApplied ? currentHp : preHp;
    const hpPct = Math.max(0, Math.min(100, Math.round((displayHp / maxHp) * 100)));
    const preHpPct = Math.max(0, Math.min(100, Math.round((preHp / maxHp) * 100)));

    const maxStamina = 100;
    const preStamina = preClash ? preClash.stamina : (card.currentStamina ?? 100);
    const currentStamina = card.currentStamina ?? 100;
    const displayStamina = isClashEffectApplied ? currentStamina : preStamina;
    const staminaPct = Math.max(0, Math.min(100, Math.round((displayStamina / maxStamina) * 100)));
    const isExhausted = displayStamina <= 0;

    const hpDelta = preClash ? Math.max(0, preClash.hp - currentHp) : 0;
    const staminaDelta = preClash ? (currentStamina - preStamina) : 0;

    return (
      <div 
        className={`flex flex-col gap-1.5 p-2 sm:p-2.5 rounded-xl sm:rounded-2xl border-2 backdrop-blur-xl shadow-2xl w-[105px] xs:w-[118px] sm:w-[136px] shrink-0 pointer-events-none transition-all duration-300 ${
          isEnemy 
            ? 'bg-gradient-to-b from-purple-950/95 via-slate-950/95 to-black/98 border-purple-400/80 shadow-[0_8px_25px_rgba(0,0,0,0.9),0_0_18px_rgba(192,132,252,0.4)]' 
            : 'bg-gradient-to-b from-cyan-950/95 via-slate-950/95 to-black/98 border-cyan-400/80 shadow-[0_8px_25px_rgba(0,0,0,0.9),0_0_18px_rgba(94,234,212,0.4)]'
        }`}
        style={{
          transformStyle: 'preserve-3d',
          transform: 'rotateX(4deg) rotateY(6deg)'
        }}
      >
        {/* Header: Label + Damage Delta Tag */}
        <div className="flex items-center justify-between pb-0.5 border-b border-white/10 leading-none">
          <div className="flex items-center gap-1">
            <span className={`w-1.5 h-1.5 rounded-full ${isEnemy ? 'bg-purple-400 animate-pulse' : 'bg-[#5eead4] animate-ping'}`} />
            <span className={`text-[7px] xs:text-[8px] sm:text-[9px] font-mono font-black uppercase tracking-wider ${isEnemy ? 'text-purple-300' : 'text-cyan-300'}`}>
              {isEnemy ? (isAr ? 'الخصم' : 'ENEMY') : (isAr ? 'أنت' : 'YOU')}
            </span>
          </div>

          {isClashEffectApplied && hpDelta > 0 && (
            <span className="px-1 py-0.2 rounded bg-rose-500/30 border border-rose-400/60 text-[6.5px] xs:text-[7.5px] font-mono font-black text-rose-300 animate-bounce">
              -{hpDelta}
            </span>
          )}
        </div>

        {/* Health Bar (HP) */}
        <div>
          <div className="flex items-center justify-between text-[6.5px] xs:text-[7.5px] sm:text-[8.5px] font-bold font-mono text-white mb-0.5 leading-none">
            <span className="flex items-center gap-0.5 text-rose-300 font-bold">
              <span className="text-[7.5px] text-rose-400">♥</span> HP
            </span>
            <span className={hpPct > 50 ? (isEnemy ? 'text-purple-200' : 'text-[#5eead4]') : hpPct > 20 ? 'text-amber-300' : 'text-rose-400 font-black'}>
              {displayHp}/{maxHp}
            </span>
          </div>
          <div className="relative w-full h-2 sm:h-2.5 rounded-full bg-slate-950 border border-white/20 overflow-hidden p-[1px] shadow-[inset_0_1px_3px_rgba(0,0,0,0.9)]">
            {/* Ghost Trailing Bar */}
            <div 
              className="absolute inset-y-0 left-0 bg-rose-500/80 rounded-full transition-all duration-700 ease-out"
              style={{ width: `${isClashEffectApplied ? preHpPct : hpPct}%` }}
            />
            {/* Live Health Fill Bar */}
            <div 
              className={`relative h-full rounded-full transition-all duration-400 ease-out ${
                isEnemy
                  ? 'bg-gradient-to-r from-purple-600 via-rose-500 to-purple-300 shadow-[0_0_8px_rgba(168,85,247,0.9)]'
                  : hpPct > 50 
                    ? 'bg-gradient-to-r from-teal-400 via-cyan-400 to-[#5eead4] shadow-[0_0_8px_rgba(94,234,212,0.9)]' 
                    : hpPct > 20 
                      ? 'bg-gradient-to-r from-amber-500 to-yellow-300' 
                      : 'bg-gradient-to-r from-red-600 to-rose-400'
              }`}
              style={{ width: `${hpPct}%` }}
            />
          </div>
        </div>

        {/* Stamina Bar (STM) */}
        <div>
          <div className="flex items-center justify-between text-[6px] xs:text-[7px] sm:text-[8px] font-mono font-bold mb-0.5 leading-none">
            <span className={isExhausted ? 'text-rose-400 animate-pulse font-black' : 'text-emerald-300 font-bold'}>
              {isExhausted ? (isAr ? 'منهك!' : 'EXHAUSTED') : (isAr ? 'الجهد' : 'STM')}
            </span>
            <div className="flex items-center gap-1">
              <span className={isExhausted ? 'text-rose-400 font-bold' : 'text-emerald-300'}>
                {displayStamina}/{maxStamina}
              </span>
              {isClashEffectApplied && staminaDelta !== 0 && (
                <span className={`px-1 py-0.2 rounded text-[6px] xs:text-[7px] font-mono font-black ${
                  staminaDelta > 0 
                    ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-400/60 animate-bounce' 
                    : 'bg-amber-500/30 text-amber-300 border border-amber-400/60'
                }`}>
                  {staminaDelta > 0 ? `+${staminaDelta}` : `${staminaDelta}`}
                </span>
              )}
            </div>
          </div>
          <div className="w-full h-1.5 sm:h-2 rounded-full bg-slate-950 border border-emerald-500/30 overflow-hidden p-[1px] shadow-[inset_0_1px_3px_rgba(0,0,0,0.9)]">
            <div 
              className={`h-full rounded-full transition-all duration-400 ease-out ${
                isExhausted
                  ? 'bg-rose-500'
                  : staminaPct > 40
                    ? 'bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-300 shadow-[0_0_8px_rgba(16,185,129,0.8)]'
                    : 'bg-gradient-to-r from-amber-500 to-rose-400'
              }`}
              style={{ width: `${staminaPct}%` }}
            />
          </div>
        </div>

        {/* Status flags */}
        {card.counterWindow && (
          <div className="text-[5.5px] xs:text-[6.5px] font-mono font-black text-emerald-300 uppercase tracking-tighter text-center py-0.5 bg-emerald-950/90 rounded border border-emerald-500/50 shadow-sm">
            {isAr ? '⚡ نافذة مضادة' : '⚡ COUNTER WINDOW'}
          </div>
        )}
      </div>
    );
  };

  const tableCardSizeClass = "w-16 xs:w-20 sm:w-24 md:w-28 aspect-[5/7] shrink-0";

  // Outcome styling for action confrontation teller
  const getOutcomeTagMeta = (title?: string) => {
    switch (title) {
      case 'INTERRUPTED':
        return {
          bg: 'bg-amber-950/90 border-amber-400 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.5)]',
          icon: '⚠️'
        };
      case 'GUARD BREAK':
        return {
          bg: 'bg-rose-950/90 border-rose-500 text-rose-300 shadow-[0_0_12px_rgba(244,63,94,0.5)]',
          icon: '💥'
        };
      case 'BLOCKED':
        return {
          bg: 'bg-blue-950/90 border-blue-400 text-blue-200 shadow-[0_0_12px_rgba(59,130,246,0.4)]',
          icon: '🛡️'
        };
      case 'COUNTER WINDOW':
        return {
          bg: 'bg-emerald-950/90 border-emerald-400 text-emerald-200 shadow-[0_0_12px_rgba(16,185,129,0.5)]',
          icon: '⚡'
        };
      case 'HEAVY CLASH':
        return {
          bg: 'bg-orange-950/90 border-orange-500 text-orange-200 shadow-[0_0_12px_rgba(249,115,22,0.5)]',
          icon: '🔥'
        };
      case 'STANDOFF':
        return {
          bg: 'bg-slate-900/90 border-slate-400 text-slate-200 shadow-[0_0_10px_rgba(148,163,184,0.3)]',
          icon: '🤝'
        };
      default:
        return {
          bg: 'bg-cyan-950/90 border-cyan-400 text-cyan-200 shadow-[0_0_10px_rgba(94,234,212,0.3)]',
          icon: '⚔️'
        };
    }
  };

  const outcomeMeta = getOutcomeTagMeta(clashData?.clashTitle);

  return (
    <div 
      className="relative w-full max-w-sm xs:max-w-md sm:max-w-lg md:max-w-xl flex-1 min-h-[160px] xs:min-h-[175px] max-h-[35vh] xs:max-h-[39vh] rounded-2xl sm:rounded-3xl border border-cyan-500/30 shadow-[0_16px_45px_rgba(0,0,0,0.92)] flex flex-col items-center justify-between overflow-visible p-1 xs:p-1.5 backdrop-blur-2xl shrink"
      style={{
        background: 'linear-gradient(180deg, rgba(4,16,20,0.98) 0%, rgba(2,8,11,0.99) 100%)',
        perspective: '1200px',
        transformStyle: 'preserve-3d'
      }}
    >
      {/* Duel Field Grid Background */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-20 rounded-2xl sm:rounded-3xl overflow-hidden"
        style={{
          backgroundImage: `
            radial-gradient(circle at 50% 50%, rgba(94, 234, 212, 0.12) 0%, transparent 60%),
            linear-gradient(to right, rgba(94, 234, 212, 0.08) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(94, 234, 212, 0.08) 1px, transparent 1px)
          `,
          backgroundSize: '100% 100%, 28px 28px, 28px 28px'
        }}
      />

      {/* Top Turn Header */}
      <div className="w-full flex items-center justify-between px-2.5 py-0.5 border-b border-cyan-500/15 z-20 shrink-0 bg-slate-950/60 rounded-t-xl">
        <span className="text-[7.5px] xs:text-[8.5px] sm:text-[10px] font-mono font-bold tracking-widest text-[#5eead4] uppercase">
          {isAr ? `الجولة ${String(turnNumber).padStart(2, '0')}` : `TURN ${String(turnNumber).padStart(2, '0')}`}
        </span>
        <span className="text-[6.5px] xs:text-[7.5px] font-mono text-cyan-300/60 uppercase tracking-widest">
          {isAr ? 'ساحة النزال' : 'DUEL MAT'}
        </span>
      </div>

      {/* TACTILE MAT SLAM SURFACE FLASH */}
      {tableSlamImpact && (
        <motion.div 
          initial={{ opacity: 0.7, scale: 0.95 }}
          animate={{ opacity: 0, scale: 1.05 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          className="absolute inset-4 rounded-2xl border border-cyan-400/40 bg-cyan-500/[0.03] pointer-events-none z-15"
        />
      )}

      {/* RAZOR-SHARP SPECULAR CONTACT FLASH & ACTION-SPECIFIC COMBAT SPECTACLE */}
      {clashAnimationStage === 'ACTION_CLASH' && (
        <>
          {/* Lightweight High-Impact Specular Slash Blade */}
          <motion.div 
            initial={{ opacity: 1, scaleX: 0.2 }}
            animate={{ opacity: 0, scaleX: 1.4 }}
            transition={{ duration: 0.18, ease: 'easeOut' }}
            className="absolute top-1/2 -translate-y-1/2 inset-x-8 h-[2.5px] bg-gradient-to-r from-transparent via-white to-transparent shadow-[0_0_20px_rgba(255,255,255,1)] pointer-events-none z-30"
          />

          {/* Quick kinetic shockwave ripple ring */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-35 overflow-hidden">
            <motion.div
              initial={{ scale: 0.2, opacity: 1 }}
              animate={{ scale: 2.2, opacity: 0 }}
              transition={{ duration: 0.3, ease: 'easeOut' }}
              className="w-28 h-28 rounded-full border border-cyan-300 shadow-[0_0_25px_#22d3ee]"
            />
          </div>
        </>
      )}

      {/* 
        ========================================================================
        BATTLE ACTION RESULTS: 3 SIMPLE VERTICALLY STACKED LINES
        Top line: Enemy action in uppercase
        Middle line: Result symbol (X when matching, ▲/▼ for other outcomes)
        Bottom line: Player action in uppercase
        ========================================================================
      */}
      <AnimatePresence>
        {isRevealingActions && (
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.96 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="absolute z-40 top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 pointer-events-none flex flex-col items-center justify-center text-center select-none"
          >
            <div className="flex flex-col items-center justify-center font-mono font-black text-center tracking-widest leading-none space-y-2 sm:space-y-3">
              {/* Top line: Enemy */}
              <span className="text-base sm:text-xl md:text-2xl text-slate-200 uppercase drop-shadow-sm">
                {enemyActionName}
              </span>
              {/* Middle line: Result Symbol */}
              <span className="text-xl sm:text-2xl md:text-3xl text-amber-400 font-black">
                {getResultSymbol()}
              </span>
              {/* Bottom line: Player */}
              <span className="text-base sm:text-xl md:text-2xl text-cyan-300 uppercase drop-shadow-sm">
                {playerActionName}
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* K.O. Stamp */}
      <AnimatePresence>
        {koStamp && (
          <motion.div
            initial={{ scale: 2.2, opacity: 0 }}
            animate={{ scale: 1.0, opacity: 1 }}
            exit={{ scale: 0.4, opacity: 0 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="absolute z-45 top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2 pointer-events-none flex flex-col items-center justify-center text-center select-none"
          >
            <div className="px-5 py-2 sm:px-7 sm:py-2.5 rounded-3xl bg-red-950/95 border-2 border-red-500 shadow-[0_0_50px_rgba(239,68,68,0.95)]">
              <span className="text-xl sm:text-3xl font-black text-white uppercase tracking-widest drop-shadow-[0_0_20px_#ef4444]">
                {koStamp}
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* EMPTY TABLE STATE */}
      {isTableEmpty ? (
        <div className="flex flex-col items-center justify-center text-center my-auto">
          <div className={`${tableCardSizeClass} rounded-xl sm:rounded-2xl border border-dashed flex flex-col items-center justify-center shadow-inner transition-all duration-200 ${
            isSelectingNextCard
              ? 'border-[#5eead4]/80 bg-cyan-950/20'
              : 'border-cyan-500/30 opacity-30'
          }`}>
            <span className="text-[8.5px] sm:text-xs font-mono font-bold text-cyan-200 px-1 text-center">
              {isSelectingNextCard ? (isAr ? 'اختر بطاقتك' : 'CHOOSE') : (isAr ? 'نزال' : 'VS')}
            </span>
          </div>
        </div>
      ) : (
        /* 
          ======================================================================
          3D CARDS ON TABLE
          CRITICAL FIX: Cards stay rock-solid in their place!
          The bars emerge ABSOLUTELY from underneath the card to the left,
          WITHOUT altering or shifting the card's position by even 1px!
          ======================================================================
        */
        <div 
          className="w-full h-full flex flex-col justify-between items-center py-1 relative"
          style={{ transformStyle: 'preserve-3d' }}
        >
          {/* ================================================================= */}
          {/* 1. ENEMY CARD ON TABLE                                            */}
          {/* ================================================================= */}
          {enemyCard && (
            <div className="relative flex items-center justify-center">
              <motion.div
                initial={{ y: -70, opacity: 0 }}
                animate={
                  clashAnimationStage === 'SWIPE_AWAY'
                    ? { y: -260, opacity: 0 }
                    : clashAnimationStage === 'ACTION_CLASH'
                    ? floatingDamage?.target === 'ENEMY'
                      ? { y: [0, 26, -14, 6, 0], x: [0, 7, -8, 5, 0], rotate: [0, 3, -6, 2, 0], scale: [1, 1.1, 0.94, 1] }
                      : { y: [0, 36, 26], scale: [1, 1.15, 1.08], rotate: [0, 3, 1.5] }
                    : { y: 0, x: 0, rotate: 0, scale: 1, opacity: 1 }
                }
                transition={
                  clashAnimationStage === 'SWIPE_AWAY'
                    ? { duration: 0.38, ease: 'easeIn' }
                    : clashAnimationStage === 'ACTION_CLASH'
                    ? { duration: 0.28, ease: 'easeOut' }
                    : { duration: 0.2, ease: [0.16, 1, 0.3, 1] }
                }
                className="relative z-20"
              >
                {/* ENEMY CARD BODY: 3D CARD FLIP ANIMATION */}
                <div className={`${tableCardSizeClass} relative z-20`} style={{ perspective: '1000px' }}>
                  <motion.div 
                    className="w-full h-full relative"
                    style={{ transformStyle: 'preserve-3d' }}
                    animate={{ rotateY: isEnemyFlipped ? 0 : 180 }}
                    transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
                  >
                    {/* Front Face (Revealed Card) */}
                    <div 
                      className="absolute inset-0 w-full h-full"
                      style={{ backfaceVisibility: 'hidden', WebkitBackfaceVisibility: 'hidden' }}
                    >
                      {renderCardBody(enemyCard, true)}
                    </div>

                    {/* Back Face (Secret Card Back) */}
                    <div 
                      className="absolute inset-0 w-full h-full"
                      style={{ 
                        backfaceVisibility: 'hidden', 
                        WebkitBackfaceVisibility: 'hidden', 
                        transform: 'rotateY(180deg)' 
                      }}
                    >
                      {renderEnemySecretBack()}
                    </div>
                  </motion.div>
                </div>

                {/* 
                  BARS: POSITIONED ABSOLUTELY TO THE LEFT OF THE CARD!
                  Tucked directly under/behind the card at x: 45,
                  then slides smoothly out to x: 0 without moving the card!
                */}
                <AnimatePresence>
                  {areBarsVisible && (
                    <motion.div
                      key="enemy-side-bars"
                      className="absolute right-full top-1/2 -translate-y-1/2 mr-2 z-10 pointer-events-none"
                      initial={{ x: 45, opacity: 0 }}
                      animate={{ 
                        x: clashAnimationStage === 'BARS_TUCK_STRAIGHTEN' ? 45 : 0, 
                        opacity: clashAnimationStage === 'BARS_TUCK_STRAIGHTEN' ? 0 : 1 
                      }}
                      exit={{ x: 45, opacity: 0 }}
                      transition={{ 
                        duration: clashAnimationStage === 'BARS_TUCK_STRAIGHTEN' ? 0.35 : 0.4, 
                        ease: [0.16, 1, 0.3, 1] 
                      }}
                    >
                      {renderLeftSideStatsPillar(enemyCard, enemyPreClash, true)}
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Floating Damage on Enemy */}
                {floatingDamage?.target === 'ENEMY' && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.5, y: 10 }}
                    animate={{ opacity: [0, 1, 1, 0], scale: [0.5, 1.35, 1.1, 0.9], y: -28 }}
                    transition={{ duration: 0.85, ease: 'easeOut' }}
                    className="absolute inset-0 flex flex-col items-center justify-center z-45 pointer-events-none select-none"
                  >
                    {floatingDamage.isCrit && (
                      <span className="text-[9px] sm:text-[11px] font-black font-sans uppercase tracking-widest text-amber-300 drop-shadow-[0_0_12px_#f59e0b] px-2.5 py-0.5 rounded-full bg-amber-950/90 border border-amber-400 mb-0.5 animate-bounce">
                        ⚡ CRITICAL!
                      </span>
                    )}
                    <span className="text-xl sm:text-2xl md:text-3xl font-black font-mono text-emerald-300 drop-shadow-[0_2px_16px_rgba(52,211,153,1)] tracking-tight">
                      -{floatingDamage.amount}
                    </span>
                  </motion.div>
                )}
              </motion.div>
            </div>
          )}

          {/* ================================================================= */}
          {/* 2. PLAYER CARD ON TABLE                                           */}
          {/* ================================================================= */}
          {playerCard && (
            <div className="relative flex items-center justify-center">
              <motion.div
                initial={{ y: 70, opacity: 0 }}
                animate={
                  clashAnimationStage === 'SWIPE_AWAY'
                    ? { y: 260, opacity: 0 }
                    : clashAnimationStage === 'ACTION_CLASH'
                    ? floatingDamage?.target === 'PLAYER'
                      ? { y: [0, -26, 14, -6, 0], x: [0, -7, 8, -5, 0], rotate: [0, -3, 6, -2, 0], scale: [1, 1.1, 0.94, 1] }
                      : { y: [0, -36, -26], scale: [1, 1.15, 1.08], rotate: [0, -3, -1.5] }
                    : { y: 0, x: 0, rotate: 0, scale: 1, opacity: 1 }
                }
                transition={
                  clashAnimationStage === 'SWIPE_AWAY'
                    ? { duration: 0.38, ease: 'easeIn' }
                    : clashAnimationStage === 'ACTION_CLASH'
                    ? { duration: 0.28, ease: 'easeOut' }
                    : { duration: 0.2, ease: [0.16, 1, 0.3, 1] }
                }
                className="relative z-20"
              >
                {/* PLAYER CARD BODY: Sits firmly in center */}
                <div className={`${tableCardSizeClass} relative z-20`}>
                  {renderCardBody(playerCard, false)}
                </div>

                {/* 
                  BARS: POSITIONED ABSOLUTELY TO THE LEFT OF THE CARD!
                  Tucked directly under/behind the card at x: 45,
                  then slides smoothly out to x: 0 without moving the card!
                */}
                <AnimatePresence>
                  {areBarsVisible && (
                    <motion.div
                      key="player-side-bars"
                      className="absolute right-full top-1/2 -translate-y-1/2 mr-2 z-10 pointer-events-none"
                      initial={{ x: 45, opacity: 0 }}
                      animate={{ 
                        x: clashAnimationStage === 'BARS_TUCK_STRAIGHTEN' ? 45 : 0, 
                        opacity: clashAnimationStage === 'BARS_TUCK_STRAIGHTEN' ? 0 : 1 
                      }}
                      exit={{ x: 45, opacity: 0 }}
                      transition={{ 
                        duration: clashAnimationStage === 'BARS_TUCK_STRAIGHTEN' ? 0.35 : 0.4, 
                        ease: [0.16, 1, 0.3, 1] 
                      }}
                    >
                      {renderLeftSideStatsPillar(playerCard, playerPreClash, false)}
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Floating Damage on Player */}
                {floatingDamage?.target === 'PLAYER' && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.5, y: -10 }}
                    animate={{ opacity: [0, 1, 1, 0], scale: [0.5, 1.35, 1.1, 0.9], y: -28 }}
                    transition={{ duration: 0.85, ease: 'easeOut' }}
                    className="absolute inset-0 flex flex-col items-center justify-center z-45 pointer-events-none select-none"
                  >
                    {floatingDamage.isCrit && (
                      <span className="text-[9px] sm:text-[11px] font-black font-sans uppercase tracking-widest text-rose-300 drop-shadow-[0_0_12px_#f43f5e] px-2.5 py-0.5 rounded-full bg-rose-950/90 border border-rose-400 mb-0.5 animate-bounce">
                        💥 CRITICAL HIT!
                      </span>
                    )}
                    <span className="text-xl sm:text-2xl md:text-3xl font-black font-mono text-rose-400 drop-shadow-[0_2px_16px_rgba(244,63,94,1)] tracking-tight">
                      -{floatingDamage.amount}
                    </span>
                  </motion.div>
                )}
              </motion.div>
            </div>
          )}

        </div>
      )}

    </div>
  );
};
