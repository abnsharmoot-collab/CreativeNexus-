import React from 'react';
import { motion } from 'motion/react';
import { StoryChapterDefinition } from '../../types/story';
import { 
  Trophy, Sparkles, BookOpen, Crown, Plus, Edit, 
  Layers, CheckCircle, Compass, Coins, Swords, Shield
} from 'lucide-react';

interface StoryChapterSectionBannerProps {
  chapter: StoryChapterDefinition;
  chapterNumber: number;
  completedBattlesCount: number;
  totalBattlesCount: number;
  isUnlocked: boolean;
  isOwner: boolean;
  isAr: boolean;
  onEditChapter?: (chapter: StoryChapterDefinition) => void;
  onAddBattleToChapter?: (chapterId: string) => void;
}

export const StoryChapterSectionBanner: React.FC<StoryChapterSectionBannerProps> = ({
  chapter,
  chapterNumber,
  completedBattlesCount,
  totalBattlesCount,
  isUnlocked,
  isOwner,
  isAr,
  onEditChapter,
  onAddBattleToChapter
}) => {
  const percent = totalBattlesCount > 0 
    ? Math.round((completedBattlesCount / totalBattlesCount) * 100) 
    : 0;
  const isMastered = totalBattlesCount > 0 && completedBattlesCount === totalBattlesCount;
  const accent = chapter.accentColor || '#2dd4bf';

  return (
    <div
      id={`chapter-section-${chapter.id}`}
      className="relative rounded-3xl overflow-hidden border transition-all duration-500 shadow-2xl mb-8 group"
      style={{
        borderColor: `${accent}40`,
        backgroundColor: '#031417'
      }}
    >
      {/* Background Banner Image with Dark Cinematic Gradient Overlay */}
      {chapter.bannerImageUrl && (
        <div 
          className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-103 opacity-30 mix-blend-screen"
          style={{ backgroundImage: `url(${chapter.bannerImageUrl})` }}
        />
      )}

      {/* Atmospheric Radial Gradients */}
      <div 
        className="absolute -top-24 -right-24 w-96 h-96 rounded-full blur-3xl pointer-events-none opacity-20"
        style={{ backgroundColor: accent }}
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black/95 via-black/80 to-black/90 pointer-events-none" />

      {/* Banner Content */}
      <div className="relative z-10 p-5 sm:p-7 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-3 max-w-3xl">
          {/* Milestone Badges & Owner Controls */}
          <div className="flex items-center gap-2.5 flex-wrap">
            <span 
              className="px-3 py-1 rounded-full text-xs font-mono font-extrabold uppercase tracking-wider flex items-center gap-1.5 shadow-sm border"
              style={{
                backgroundColor: `${accent}25`,
                borderColor: `${accent}60`,
                color: '#ffffff'
              }}
            >
              <Trophy size={13} style={{ color: accent }} />
              <span>{isAr ? `الفصل ${chapterNumber}` : `Chapter ${chapterNumber}`}</span>
              <span>•</span>
              <span>{isAr ? chapter.badgeTextAr || chapter.badgeText || 'ملحمة' : chapter.badgeText || 'CHRONICLE'}</span>
            </span>

            {isMastered && (
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[11px] font-mono font-bold flex items-center gap-1">
                <CheckCircle size={12} />
                <span>{isAr ? 'تم إتقان الفصل بالكامل' : 'Chapter Mastered'}</span>
              </span>
            )}

            {isOwner && (
              <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 border border-purple-500/40 text-purple-300 text-[11px] font-mono font-bold flex items-center gap-1">
                <Crown size={12} />
                <span>{isAr ? 'إدارة المالك' : 'Owner Managed'}</span>
              </span>
            )}
          </div>

          {/* Chapter Main Title */}
          <div>
            <h2 className="text-2xl sm:text-4xl font-black text-white font-sans tracking-tight">
              {isAr ? chapter.titleAr || chapter.title : chapter.title}
            </h2>
            <p className="text-xs sm:text-sm font-mono mt-1" style={{ color: accent }}>
              {isAr ? chapter.subtitleAr || chapter.subtitle : chapter.subtitle}
            </p>
          </div>

          {/* Lore Description */}
          <p className="text-xs sm:text-sm text-slate-300 font-sans leading-relaxed max-w-2xl">
            {isAr ? chapter.descriptionAr || chapter.description : chapter.description}
          </p>

          {/* Chapter Progression Tracker */}
          <div className="pt-2 max-w-md space-y-1.5">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-slate-400 flex items-center gap-1.5">
                <Compass size={13} style={{ color: accent }} />
                <span>{isAr ? 'تقدم إكمال معارك الفصل:' : 'Chapter Battles Cleared:'}</span>
              </span>
              <span className="font-bold text-white">
                {completedBattlesCount}/{totalBattlesCount} {isAr ? 'معارك' : 'Cleared'} ({percent}%)
              </span>
            </div>

            <div className="w-full h-2.5 rounded-full bg-black/80 border border-white/10 overflow-hidden p-0.5">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${percent}%` }}
                transition={{ duration: 0.8, ease: 'easeOut' }}
                className="h-full rounded-full"
                style={{
                  background: `linear-gradient(90deg, ${accent}, #ffffff)`
                }}
              />
            </div>
          </div>
        </div>

        {/* Action Controls for Chapter */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
          {/* Owner Chapter Admin Controls */}
          {isOwner && onAddBattleToChapter && (
            <button
              type="button"
              onClick={() => onAddBattleToChapter(chapter.id)}
              className="px-4 py-2.5 rounded-2xl bg-teal-500/20 hover:bg-teal-500/30 text-[#5eead4] border border-teal-500/40 text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-md"
            >
              <Plus size={15} />
              <span>{isAr ? '+ إضافة معركة لهذا الفصل' : '+ Add Fight to Chapter'}</span>
            </button>
          )}

          {isOwner && onEditChapter && (
            <button
              type="button"
              onClick={() => onEditChapter(chapter)}
              className="px-4 py-2.5 rounded-2xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-md"
            >
              <Edit size={14} />
              <span>{isAr ? 'تعديل الفصل' : 'Customize Chapter'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
