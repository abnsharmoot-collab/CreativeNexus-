import React, { useRef, useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Sparkles, Clock, Crown, Heart, Shield } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { useAuth } from '../../context/AuthContext';
import { useOwnerCardBackgrounds } from '../../context/OwnerCardBackgroundsContext';
import { useStaff } from '../../context/StaffContext';
import { CountryFlag } from '../atoms/CountryFlag';
import { OwnerCardBackgroundLayer } from './OwnerCardBackgroundLayer';
import { OwnerCardEffectLayer } from './OwnerCardEffectLayer';
import { getAccentColor } from '../../utils/ownerCardStyles';
import { useScroll3DTilt } from '../../hooks/useScroll3DTilt';

export interface Owner3DCardProps {
  cardId: string;
  fallbackCardId?: string;
  romanNumeral?: string;
  numeralIndex?: number;
  name: string;
  displayName?: string;
  username?: string;
  rankTitle?: string;
  roleLabelAr?: string;
  roleLabelEn?: string;
  subtitleAr?: string;
  subtitleEn?: string;
  badge?: string;
  accentColor?: string;
  effect?: string;
  glowIntensity?: number;
  borderStyle?: string;
  country?: 'iraq' | 'uae' | 'egypt' | string;
  status?: 'present' | 'former';
  avatarUrl?: string;
  isWife?: boolean;
  isCustom?: boolean;
  order?: number;
  displayMode?: 'vault' | 'timeline' | 'compact';
  className?: string;
}

export const Owner3DCard: React.FC<Owner3DCardProps> = ({
  cardId,
  fallbackCardId,
  romanNumeral,
  numeralIndex = 0,
  name,
  displayName,
  username,
  rankTitle,
  roleLabelAr,
  roleLabelEn,
  subtitleAr,
  subtitleEn,
  badge,
  accentColor,
  effect,
  glowIntensity,
  borderStyle,
  country,
  status = 'present',
  avatarUrl,
  isWife,
  isCustom,
  order,
  className = '',
}) => {
  const { t, language } = useLanguage();
  const isAr = language === 'ar';
  const { setIsKohanGameOpen } = useEasterEggs();
  const { isAuthenticated } = useAuth();
  const { getCustomization } = useOwnerCardBackgrounds();
  const { staff } = useStaff();
  const navigate = useNavigate();

  const cardRef = useRef<HTMLDivElement>(null);
  const [hoverRotateX, setHoverRotateX] = useState(0);
  const [hoverRotateY, setHoverRotateY] = useState(0);
  const [hoverGlarePos, setHoverGlarePos] = useState({ x: 50, y: 30 });
  const [isHovered, setIsHovered] = useState(false);
  const [imgError, setImgError] = useState(false);
  const prefersReducedMotion = useRef(false);
  const lastTapRef = useRef<number>(0);
  const lastTouchTimeRef = useRef<number>(0);

  const handleCardInteraction = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button, a, input, select')) return;
    const now = Date.now();
    const timeDiff = now - lastTapRef.current;
    if (timeDiff < 400 && timeDiff > 40) {
      navigate(`/owner/${cardId}`);
      lastTapRef.current = 0;
    } else {
      lastTapRef.current = now;
    }
  };

  const handleCardDoubleClick = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button, a, input, select')) return;
    navigate(`/owner/${cardId}`);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if ((e.target as HTMLElement).closest('button, a, input, select')) return;
    const now = Date.now();
    const timeDiff = now - lastTouchTimeRef.current;
    if (timeDiff < 400 && timeDiff > 40) {
      navigate(`/owner/${cardId}`);
      lastTouchTimeRef.current = 0;
    } else {
      lastTouchTimeRef.current = now;
    }
  };

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
      prefersReducedMotion.current = mq.matches;
      const onChange = (e: MediaQueryListEvent) => {
        prefersReducedMotion.current = e.matches;
      };
      mq.addEventListener('change', onChange);
      return () => mq.removeEventListener('change', onChange);
    }
  }, []);

  // Fetch real-time synced card customization
  const custom = getCustomization(cardId, fallbackCardId);

  // If marked as removed, do not render
  if (custom?.removed) {
    return null;
  }

  const activeStatus = (custom?.status || status) === 'present' ? 'present' : 'former';
  const isPresent = activeStatus === 'present';

  const activeAccentKey = custom?.accentColor || accentColor || (isWife ? 'rose' : 'amber');
  const accentObj = getAccentColor(activeAccentKey);

  const activeEffect = custom?.effect || effect || (isWife ? 'romantic' : 'none');
  const activeBorderStyle = custom?.borderStyle || borderStyle || 'glow';
  const activeGlowIntensity = typeof custom?.glowIntensity === 'number' ? custom.glowIntensity : (typeof glowIntensity === 'number' ? glowIntensity : 0.5);

  const displayNameText = custom?.displayName || custom?.name || displayName || name;
  const subtitleText = isAr ? (custom?.subtitle || subtitleAr || subtitleEn || '') : (custom?.subtitle || subtitleEn || subtitleAr || '');
  const roleTitleText = isAr ? (custom?.roleTitle || roleLabelAr || rankTitle || 'مالك السيرفر') : (custom?.roleTitle || roleLabelEn || rankTitle || 'Server Owner');
  const badgeText = custom?.badge || badge || (isAr ? 'قائد' : 'Leader');
  const countryVal = (custom?.country as any) || country;

  // Card Height & Dimension Customization
  const cardHeightPreset = custom?.cardHeightPreset || 'standard';
  const customCardHeight = custom?.cardHeight;

  const minHeightClass = customCardHeight
    ? ''
    : cardHeightPreset === 'compact'
    ? 'min-h-[440px] sm:min-h-[460px]'
    : cardHeightPreset === 'tall'
    ? 'min-h-[580px] sm:min-h-[620px]'
    : cardHeightPreset === 'epic'
    ? 'min-h-[660px] sm:min-h-[700px]'
    : 'min-h-[500px] sm:min-h-[540px]';

  // Buttons customization / removal toggles
  const hideAllButtons = custom?.hideAllButtons ?? false;
  const hideEditButton = hideAllButtons || (custom?.hideEditButton ?? false);
  const hideBadgeButton = hideAllButtons || (custom?.hideBadgeButton ?? false);
  const hideStatusBadge = hideAllButtons || (custom?.hideStatusBadge ?? false);

  const isKohanCard = name.toUpperCase().includes('KOHAN') || displayNameText.toUpperCase().includes('KOHAN');

  const accentHex = accentObj.hex || '#f59e0b';

  // Real-time smooth scroll 3D tilt & dynamic lighten-up (operates in both directions: down and up/going back)
  const scrollTilt = useScroll3DTilt({
    cardRef,
    isAlternate: (numeralIndex % 2 !== 0),
    isHovered,
    hoverRotateX,
    hoverRotateY,
    maxTiltX: 2.8,
    maxTiltY: 1.8,
    accentColorHex: accentHex,
    glowIntensity: activeGlowIntensity,
    enabled: true,
  });

  // Interactive mouse tracking when hovering
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (prefersReducedMotion.current || !cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rX = ((y - centerY) / centerY) * -2.4;
    const rY = ((x - centerX) / centerX) * 2.4;

    setHoverRotateX(rX);
    setHoverRotateY(rY);
    setHoverGlarePos({
      x: Math.round((x / rect.width) * 100),
      y: Math.round((y / rect.height) * 100)
    });
  };

  const handleMouseEnter = () => {
    if (prefersReducedMotion.current) return;
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setHoverRotateX(0);
    setHoverRotateY(0);
    setHoverGlarePos({ x: 50, y: 30 });
  };

  // Face gradients based on accent color
  const faceGradients: Record<string, string> = {
    amber: 'bg-gradient-to-b from-[#1c1204]/95 via-slate-950/90 to-[#0e0801]/98',
    emerald: 'bg-gradient-to-b from-[#041a12]/95 via-slate-950/90 to-[#020d09]/98',
    rose: 'bg-gradient-to-b from-[#220713]/95 via-slate-950/90 to-[#120308]/98',
    cyan: 'bg-gradient-to-b from-[#051824]/95 via-slate-950/90 to-[#020c13]/98',
    purple: 'bg-gradient-to-b from-[#180927]/95 via-slate-950/90 to-[#0b0312]/98',
    amethyst: 'bg-gradient-to-b from-[#150a24]/95 via-slate-950/90 to-[#0b0314]/98',
    mint: 'bg-gradient-to-b from-[#041c19]/95 via-slate-950/90 to-[#020e0d]/98',
    platinum: 'bg-gradient-to-b from-[#161a22]/95 via-slate-950/90 to-[#0b0d12]/98',
    red: 'bg-gradient-to-b from-[#220707]/95 via-slate-950/90 to-[#120303]/98',
    orange: 'bg-gradient-to-b from-[#220c04]/95 via-slate-950/90 to-[#110502]/98',
    yellow: 'bg-gradient-to-b from-[#1e1704]/95 via-slate-950/90 to-[#0f0b01]/98',
    blue: 'bg-gradient-to-b from-[#061427]/95 via-slate-950/90 to-[#020a14]/98',
  };

  const cardBgClass = faceGradients[activeAccentKey] || faceGradients.amber;

  const cardBorderClass = activeBorderStyle === 'neon'
    ? `${accentObj.borderClass} border-2`
    : activeBorderStyle === 'solid'
    ? 'border-white/15'
    : `${accentObj.borderClass} ${accentObj.hoverBorderClass}`;

  const dynamicBoxShadow = isHovered
    ? `0 30px 70px rgba(0,0,0,0.92), 0 0 ${Math.round(24 + activeGlowIntensity * 50)}px ${accentHex}${Math.round(activeGlowIntensity * 140).toString(16).padStart(2, '0')}, inset 0 1px 1px rgba(255,255,255,0.2)`
    : scrollTilt.boxShadowStyle;

  return (
    <div
      ref={cardRef}
      role="button"
      tabIndex={0}
      onClick={handleCardInteraction}
      onDoubleClick={handleCardDoubleClick}
      onTouchEnd={handleTouchEnd}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          navigate(`/owner/${cardId}`);
        }
      }}
      title={isAr ? 'انقر مرتين (Double Tap) لفتح الملف التعريفي للمالك' : 'Double tap to open Owner Profile'}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      style={{
        transform: isHovered
          ? (prefersReducedMotion.current ? 'none' : `perspective(1200px) rotateX(${hoverRotateX}deg) rotateY(${hoverRotateY}deg) translateY(-4px) scale3d(1.01, 1.01, 1.01)`)
          : scrollTilt.transform,
        transformStyle: 'preserve-3d',
        boxShadow: dynamicBoxShadow,
        filter: isHovered ? 'brightness(1.12) contrast(1.02)' : scrollTilt.filterStyle,
        height: customCardHeight ? `${customCardHeight}px` : undefined,
        transition: isHovered ? 'box-shadow 0.2s ease, filter 0.2s ease' : 'box-shadow 0.35s ease, filter 0.35s ease',
      }}
      className={`relative flex flex-col justify-between border rounded-[2rem] sm:rounded-[2.2rem] overflow-hidden backdrop-blur-md transition-all duration-300 ${minHeightClass} ${cardBorderClass} ${cardBgClass} ${className} gpu-60fps cursor-pointer`}
    >
      {/* Visual Effect Aura Layer */}
      <OwnerCardEffectLayer
        effect={activeEffect}
        accentColor={activeAccentKey}
        glowIntensity={activeGlowIntensity}
        borderStyle={activeBorderStyle}
      />

      {/* Background Photo & Customizable Tint Layer */}
      <OwnerCardBackgroundLayer
        cardId={cardId}
        fallbackCardId={fallbackCardId}
        ownerName={displayNameText}
        displayName={displayNameText}
        roleTitle={roleTitleText}
        subtitle={subtitleText}
        badge={badgeText}
        country={countryVal}
        status={activeStatus}
        defaultAccent={activeAccentKey}
        order={order}
        showEditButton={!hideEditButton}
        buttonPosition="top-right"
      />

      {/* Top Hairline Metallic Bevel (Lightens up on scroll / hover) */}
      <div
        className="absolute top-0 inset-x-0 h-[2px] pointer-events-none z-20 transition-all duration-300"
        style={{
          background: (scrollTilt.isIlluminated || isHovered)
            ? 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.8) 50%, transparent 100%)'
            : 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.35) 50%, transparent 100%)',
          boxShadow: (scrollTilt.isIlluminated || isHovered)
            ? `0 0 12px rgba(255,255,255,0.6)`
            : 'none',
        }}
        aria-hidden="true"
      />

      {/* Dynamic Light Sweep Layer (Subtly brightens card face as you scroll down or back up) */}
      <div
        className="absolute inset-0 pointer-events-none rounded-[inherit] transition-opacity duration-300 z-15 overflow-hidden"
        style={{
          opacity: isHovered ? 0.35 : scrollTilt.lightenProgress * 0.42,
        }}
        aria-hidden="true"
      >
        <div
          className="absolute -inset-full bg-gradient-to-tr from-transparent via-white/12 to-transparent pointer-events-none"
          style={{
            transform: `translateY(${(50 - scrollTilt.glarePos.y) * 1.5}%) rotate(-25deg)`,
            transition: 'transform 0.15s ease-out',
          }}
        />
      </div>

      {/* Interactive Glare Surface */}
      <div
        className="absolute inset-0 pointer-events-none rounded-[inherit] transition-opacity duration-300 z-10"
        style={{
          opacity: isHovered && !prefersReducedMotion.current ? 0.12 : scrollTilt.glareOpacity,
          background: `radial-gradient(circle 460px at ${isHovered ? hoverGlarePos.x : scrollTilt.glarePos.x}% ${isHovered ? hoverGlarePos.y : scrollTilt.glarePos.y}%, rgba(255,255,255,0.95), transparent 70%)`,
        }}
        aria-hidden="true"
      />

      {/* ============================================================ */}
      {/* 1. TOP HEADER: Status, Country Flag, Latin Epoch             */}
      {/* ============================================================ */}
      <div
        className="relative z-20 p-4 sm:p-5 pb-1 bg-gradient-to-b from-slate-950/85 via-slate-950/40 to-transparent flex items-center justify-between gap-3 flex-wrap"
        style={{
          transform: isHovered && !prefersReducedMotion.current ? 'translateZ(16px)' : 'translateZ(8px)',
          transition: 'transform 0.35s ease-out',
        }}
      >
        <div className="flex items-center gap-2">
          {/* Status Indicator (unless removed by customization) */}
          {!hideStatusBadge && (
            isPresent ? (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] sm:text-[11px] font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 shadow-[0_0_12px_rgba(16,185,129,0.25)] backdrop-blur-md">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400" />
                </span>
                <span>{t('history.status.present')}</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] sm:text-[11px] font-medium bg-slate-900/80 text-slate-400 border border-slate-700/50 shadow-xs backdrop-blur-md">
                <Clock size={11} className="text-slate-400 shrink-0" />
                <span>{t('history.status.former')}</span>
              </span>
            )
          )}

          {/* Country Flag */}
          {countryVal && (
            <CountryFlag
              country={countryVal}
              name={t(`country.${countryVal}`)}
            />
          )}
        </div>

        {/* Latin Numeral Pill */}
        {romanNumeral && (
          <span className="font-serif text-[11px] font-bold tracking-widest text-slate-300 uppercase px-2 py-0.5 rounded-lg bg-black/45 border border-white/[0.08] backdrop-blur-md shadow-xs">
            {romanNumeral}
          </span>
        )}
      </div>

      {/* ============================================================ */}
      {/* 2. MIDDLE VIEWPORT: Clean open view for background image     */}
      {/* ============================================================ */}
      <div className="relative z-10 flex-1 flex flex-col p-3 min-h-[220px] sm:min-h-[260px] overflow-hidden justify-center items-center">
        {/* Ambient Backlight Aura (matching owner accent color with breathing emergence & scroll lighten bloom) */}
        <motion.div
          animate={{
            opacity: isHovered 
              ? [0.65, 0.95, 0.65] 
              : [Math.min(0.9, scrollTilt.auraOpacity * 0.85), Math.min(1.0, scrollTilt.auraOpacity * 1.15), Math.min(0.9, scrollTilt.auraOpacity * 0.85)],
            scale: isHovered 
              ? [1.1, 1.25, 1.1] 
              : [scrollTilt.auraScale * 0.96, scrollTilt.auraScale * 1.08, scrollTilt.auraScale * 0.96],
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: 'easeInOut'
          }}
          className="absolute inset-0 w-48 h-48 sm:w-56 sm:h-56 m-auto rounded-full blur-3xl pointer-events-none transition-all duration-300"
          style={{
            background: `${accentHex}40`,
          }}
          aria-hidden="true"
        />

        {/* Clean, open viewport: ONLY Background image is displayed (no character above) */}
        <div className="flex-1 w-full" />
      </div>

      {/* ============================================================ */}
      {/* 3. BOTTOM CARD FACE: Names, Bio, and Honor Badges            */}
      {/* ============================================================ */}
      <div
        className="relative z-20 pt-5 pb-5 px-5 sm:px-6 bg-gradient-to-t from-slate-950 via-slate-950/92 to-transparent border-t border-white/[0.04] backdrop-blur-[2px]"
        style={{
          transform: isHovered && !prefersReducedMotion.current ? 'translateZ(18px)' : 'translateZ(10px)',
          transition: 'transform 0.35s ease-out',
        }}
      >
        {/* Owner Display Name */}
        <div className="text-center mb-1.5">
          <h3 className={`font-display font-extrabold text-xl sm:text-2xl text-transparent bg-clip-text bg-gradient-to-r ${accentObj.textGradient} tracking-wide break-words max-w-full leading-snug drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)]`}>
            {displayNameText}
          </h3>
        </div>

        {/* Clean Hairline */}
        <div className="my-2 mx-auto w-2/3 h-[1px] bg-gradient-to-r from-transparent via-cyan-400/30 to-transparent pointer-events-none opacity-60" />

        {/* Short Narrative Information */}
        {subtitleText && (
          <p className="font-sans text-center text-slate-300 leading-relaxed font-normal text-xs sm:text-[13px] mb-3 px-1 drop-shadow-sm line-clamp-2">
            {subtitleText}
          </p>
        )}

        {/* Bottom Bar: Action/Badge Buttons & Roman Watermark */}
        <div className="pt-2 border-t border-white/[0.08] flex items-center justify-between text-xs text-slate-400">
          {!hideBadgeButton && (
            isKohanCard && isAuthenticated ? (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsKohanGameOpen(true);
                }}
                className="font-mono text-[10px] tracking-wider text-amber-300 hover:text-amber-100 bg-amber-950/50 hover:bg-amber-900/70 border border-amber-500/35 px-2 py-0.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer group/star shadow-xs active:scale-95"
                title={isAr ? 'لعبة سرية' : 'Secret Game'}
                aria-label="Secret Game"
              >
                <Sparkles size={10} className="shrink-0 text-amber-400 group-hover/star:rotate-45 transition-transform" />
                <span>{badgeText}</span>
              </button>
            ) : (
              <span className="font-mono text-[10px] tracking-wider text-cyan-300/90 flex items-center gap-1.5">
                <Sparkles size={10} className="shrink-0" />
                <span>{badgeText}</span>
              </span>
            )
          )}

          {romanNumeral && (
            <span className="font-serif font-bold text-sm sm:text-base text-white/20 select-none pointer-events-none tracking-widest ms-auto">
              {romanNumeral}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
