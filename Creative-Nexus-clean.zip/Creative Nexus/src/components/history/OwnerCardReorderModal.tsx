import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ArrowUp, ArrowDown, MoveVertical, Check, RefreshCw, Crown, AlertCircle } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { useOwnerCardBackgrounds } from '../../context/OwnerCardBackgroundsContext';

interface ReorderItem {
  cardId: string;
  name: string;
  role: string;
  order: number;
  accent?: string;
  isCustom?: boolean;
}

interface OwnerCardReorderModalProps {
  isOpen: boolean;
  onClose: () => void;
  cards: Array<{
    cardId: string;
    name: string;
    displayName?: string;
    roleLabel?: string;
    order?: number;
    accent?: string;
    isCustom?: boolean;
  }>;
  onReordered?: () => void;
}

export const OwnerCardReorderModal: React.FC<OwnerCardReorderModalProps> = ({
  isOpen,
  onClose,
  cards,
  onReordered
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { isOwner } = useAuth();
  const { reorderCards } = useOwnerCardBackgrounds();

  const [items, setItems] = useState<ReorderItem[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    if (isOpen) {
      const mapped = cards.map((c, idx) => ({
        cardId: c.cardId,
        name: c.displayName || c.name,
        role: c.roleLabel || 'Server Owner',
        order: typeof c.order === 'number' ? c.order : idx + 1,
        accent: c.accent || 'amber',
        isCustom: c.isCustom
      })).sort((a, b) => a.order - b.order);

      // Normalize sequence 1..N
      const normalized = mapped.map((item, i) => ({ ...item, order: i + 1 }));
      setItems(normalized);
      setStatusMsg(null);
    }
  }, [isOpen, cards]);

  if (!isOpen || !isOwner) return null;

  const moveUp = (index: number) => {
    if (index === 0) return;
    const newItems = [...items];
    const temp = newItems[index];
    newItems[index] = newItems[index - 1];
    newItems[index - 1] = temp;
    // Reassign order
    const updated = newItems.map((item, i) => ({ ...item, order: i + 1 }));
    setItems(updated);
  };

  const moveDown = (index: number) => {
    if (index === items.length - 1) return;
    const newItems = [...items];
    const temp = newItems[index];
    newItems[index] = newItems[index + 1];
    newItems[index + 1] = temp;
    // Reassign order
    const updated = newItems.map((item, i) => ({ ...item, order: i + 1 }));
    setItems(updated);
  };

  const handleSave = async () => {
    setIsSaving(true);
    setStatusMsg(null);

    const payload = items.map((it, idx) => ({
      cardId: it.cardId,
      order: idx + 1
    }));

    const res = await reorderCards(payload);
    setIsSaving(false);

    if (res.success) {
      setStatusMsg({
        text: isAr ? 'تم حفظ ترتيب البطاقات بنجاح!' : 'Card sequence updated successfully!',
        type: 'success'
      });
      if (onReordered) onReordered();
      setTimeout(() => {
        onClose();
      }, 700);
    } else {
      setStatusMsg({
        text: res.error || (isAr ? 'فشل حفظ الترتيب' : 'Failed to save card order'),
        type: 'error'
      });
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/80 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-lg rounded-3xl bg-[#071215] border border-cyan-500/30 text-slate-100 shadow-[0_20px_60px_rgba(0,0,0,0.85)] overflow-hidden z-10 my-auto"
        >
          {/* Header */}
          <div className="px-6 py-4 border-b border-slate-800/90 bg-gradient-to-r from-amber-950/30 via-slate-900 to-cyan-950/30 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-300">
                <MoveVertical size={18} />
              </div>
              <div>
                <h3 className="font-cairo font-bold text-base sm:text-lg text-white">
                  {isAr ? 'إعادة ترتيب بطاقات القيادة' : 'Reorder Leader Cards'}
                </h3>
                <p className="font-cairo text-xs text-slate-400">
                  {isAr ? 'قم بتغيير مكان البطاقات بالتقديم والتأخير' : 'Move cards up and down to change sequence'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-white/[0.05] border border-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>

          {/* Cards Sequence List */}
          <div className="p-5 max-h-[60vh] overflow-y-auto custom-scrollbar space-y-2.5">
            {items.map((item, idx) => {
              const isFirst = idx === 0;
              const isLast = idx === items.length - 1;

              return (
                <div
                  key={item.cardId}
                  className="flex items-center justify-between gap-3 p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-amber-500/30 transition-all group"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="w-7 h-7 rounded-lg bg-slate-950 border border-amber-500/30 font-mono font-bold text-xs text-amber-300 flex items-center justify-center shrink-0">
                      #{idx + 1}
                    </span>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-cairo font-bold text-sm text-white truncate">
                          {item.name}
                        </h4>
                        {item.isCustom && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                            CUSTOM
                          </span>
                        )}
                      </div>
                      <p className="font-cairo text-xs text-slate-400 truncate">
                        {item.role}
                      </p>
                    </div>
                  </div>

                  {/* Move Up & Move Down Buttons */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      disabled={isFirst}
                      onClick={() => moveUp(idx)}
                      className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 border border-slate-700 text-slate-200 flex items-center justify-center transition-colors cursor-pointer disabled:cursor-not-allowed"
                      title={isAr ? 'تقديم للأمام' : 'Move Up'}
                    >
                      <ArrowUp size={15} />
                    </button>
                    <button
                      type="button"
                      disabled={isLast}
                      onClick={() => moveDown(idx)}
                      className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:hover:bg-slate-800 border border-slate-700 text-slate-200 flex items-center justify-center transition-colors cursor-pointer disabled:cursor-not-allowed"
                      title={isAr ? 'تأخير للخلف' : 'Move Down'}
                    >
                      <ArrowDown size={15} />
                    </button>
                  </div>
                </div>
              );
            })}

            {items.length === 0 && (
              <p className="text-center py-8 text-xs text-slate-400 font-cairo">
                {isAr ? 'لا توجد بطاقات لإعادة ترتيبها' : 'No cards found to reorder'}
              </p>
            )}

            {/* Status Feedback */}
            {statusMsg && (
              <div className={`p-3 rounded-xl text-xs font-cairo flex items-center gap-2 ${
                statusMsg.type === 'success'
                  ? 'bg-emerald-950/50 border border-emerald-500/40 text-emerald-200'
                  : 'bg-rose-950/50 border border-rose-500/40 text-rose-200'
              }`}>
                {statusMsg.type === 'success' ? <Check size={14} /> : <AlertCircle size={14} />}
                <span>{statusMsg.text}</span>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-6 py-4 border-t border-slate-800/80 bg-slate-950/80 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-cairo font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>

            <button
              type="button"
              disabled={isSaving}
              onClick={handleSave}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 font-cairo font-bold text-xs shadow-lg shadow-amber-500/20 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSaving ? <RefreshCw size={14} className="animate-spin" /> : <Check size={14} />}
              <span>{isSaving ? (isAr ? 'جارِ الحفظ...' : 'Saving...') : (isAr ? 'تأكيد الترتيب الجديد' : 'Save New Sequence')}</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
