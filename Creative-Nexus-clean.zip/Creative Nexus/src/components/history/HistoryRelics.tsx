import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../../context/LanguageContext';
import { 
  Gem, 
  Flame, 
  Star, 
  Compass, 
  ShieldCheck, 
  Heart, 
  Crown,
  Sparkles,
  Check,
  Info
} from 'lucide-react';

interface RelicItem {
  id: string;
  nameEn: string;
  nameAr: string;
  custodianEn: string;
  custodianAr: string;
  era: string;
  descEn: string;
  descAr: string;
  icon: React.ReactNode;
  themeColor: string;
  borderColor: string;
  glowColor: string;
  bgGradient: string;
}

export const HistoryRelics: React.FC = () => {
  const { t, language } = useLanguage();
  const isRtl = language === 'ar';
  const [selectedRelic, setSelectedRelic] = useState<string | null>(null);

  const RELICS: RelicItem[] = [
    {
      id: 'crown',
      nameEn: 'The Golden Crown of the Nile',
      nameAr: 'تاج النيل الذهبي',
      custodianEn: 'Edgar (Server Owner)',
      custodianAr: 'Edgar (مالك السيرفر)',
      era: 'Current Era',
      descEn: 'The sovereign crown forged with Egyptian architectural grace, representing modern leadership, royal vision, and steadfast unity.',
      descAr: 'التاج الملكي المرصع بلمسات العمارة المصرية الأصيلة، رمز القيادة الحالية، والرؤية الثاقبة، والوحدة الراسخة.',
      icon: <Crown className="w-8 h-8 text-amber-300 fill-amber-400/30" />,
      themeColor: 'text-amber-300',
      borderColor: 'border-amber-400/40 hover:border-amber-400/80',
      glowColor: 'shadow-[0_0_30px_rgba(251,191,36,0.2)]',
      bgGradient: 'from-amber-950/30 via-archive-dark to-[#081316]',
    },
    {
      id: 'torch',
      nameEn: 'The Incandescent Torch',
      nameAr: 'الشعلة المتوقدة',
      custodianEn: 'Sh3la',
      custodianAr: 'Sh3la',
      era: 'The Golden Era',
      descEn: 'A blazing inextinguishable flame commemorating the longest administrative tenure, relentless loyalty, and passionate brotherhood.',
      descAr: 'لهيب خالد لا ينطفئ، يخلد أطول حقبة إدارية، والوفاء المستمر، والشغف الإداري الذي رسخ أركان السيرفر.',
      icon: <Flame className="w-8 h-8 text-orange-400 fill-orange-500/40 animate-pulse" />,
      themeColor: 'text-orange-300',
      borderColor: 'border-orange-500/40 hover:border-orange-500/80',
      glowColor: 'shadow-[0_0_30px_rgba(249,115,22,0.25)]',
      bgGradient: 'from-orange-950/30 via-archive-dark to-[#091214]',
    },
    {
      id: 'mesopotamia',
      nameEn: 'The Star of Mesopotamia',
      nameAr: 'نجمة بلاد الرافدين',
      custodianEn: 'Kohan',
      custodianAr: 'Kohan',
      era: 'Brotherhood Era',
      descEn: 'An eight-pointed golden star celebrating infinite kindness, steadfast support, and international cross-border harmony.',
      descAr: 'نجمة ثمانية ذهبية تجسد الطيبة اللامحدودة، والدعم الأخوي الراسخ، والوئام العابر للحدود من أرض الرافدين.',
      icon: <Star className="w-8 h-8 text-amber-400 fill-amber-400/30" />,
      themeColor: 'text-amber-200',
      borderColor: 'border-amber-500/35 hover:border-amber-400/70',
      glowColor: 'shadow-[0_0_30px_rgba(245,158,11,0.2)]',
      bgGradient: 'from-amber-950/25 via-archive-dark to-[#081214]',
    },
    {
      id: 'rose',
      nameEn: 'The Rose of Grace',
      nameAr: 'وردة النقاء الخالد',
      custodianEn: 'Shado',
      custodianAr: 'Shado',
      era: 'Harmony Era',
      descEn: 'A crystal rose honoring the wife of the server owner, radiating gentle affection, peace, and eternal elegance throughout our halls.',
      descAr: 'وردة بلورية تكريماً لزوجة مالك السيرفر، تبث أريج المودة والرقي والسلام الداخلي في جميع أرجاء السيرفر.',
      icon: <Heart className="w-8 h-8 text-rose-400 fill-rose-400/40" />,
      themeColor: 'text-rose-300',
      borderColor: 'border-rose-500/35 hover:border-rose-400/70',
      glowColor: 'shadow-[0_0_30px_rgba(244,63,94,0.2)]',
      bgGradient: 'from-rose-950/25 via-archive-dark to-[#081214]',
    },
    {
      id: 'shield',
      nameEn: 'The Aegis of the Emirates',
      nameAr: 'درع الوفاء الإماراتي',
      custodianEn: 'ABYSSWOLF',
      custodianAr: 'ABYSSWOLF',
      era: 'Protection Era',
      descEn: 'An emerald-crested shield symbolizing noble defense, chivalry, unshakeable friendship, and protective warmth.',
      descAr: 'درع زمردي مهيب يرمز للشهامة، والذود عن الأصدقاء، والإخاء الصادق المحصن ضد أي انكسار.',
      icon: <ShieldCheck className="w-8 h-8 text-emerald-400 fill-emerald-500/20" />,
      themeColor: 'text-emerald-300',
      borderColor: 'border-emerald-500/35 hover:border-emerald-400/70',
      glowColor: 'shadow-[0_0_30px_rgba(16,185,129,0.2)]',
      bgGradient: 'from-emerald-950/25 via-archive-dark to-[#081214]',
    },
    {
      id: 'genesis',
      nameEn: 'The Primal Genesis Stone',
      nameAr: 'حجر التأسيس الأول',
      custodianEn: 'Kevin',
      custodianAr: 'Kevin',
      era: 'Founding Year 2021',
      descEn: 'The cornerstone upon which the foundation of CREATINE NEXUS was laid, initiating our community into existence.',
      descAr: 'حجر الأساس العتيق الذي انبثقت منه أولى لبنات CREATINE NEXUS ليرسم معالم هذا المجتمع التاريخي.',
      icon: <Gem className="w-8 h-8 text-archive-cyan fill-archive-cyan/20" />,
      themeColor: 'text-archive-cyan',
      borderColor: 'border-archive-cyan/35 hover:border-archive-cyan/70',
      glowColor: 'shadow-[0_0_30px_rgba(6,182,212,0.2)]',
      bgGradient: 'from-teal-950/25 via-archive-dark to-[#081214]',
    },
  ];

  return (
    <section id="relics" className="relative py-24 px-4 sm:px-6">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-archive-teal-light/25 border border-archive-cyan/30 text-archive-cyan text-xs font-semibold uppercase tracking-[0.25em] mb-5 shadow-[0_0_20px_rgba(6,182,212,0.15)]"
        >
          <Sparkles size={13} className="text-amber-400" />
          <span>{t('history.relics.subtitle')}</span>
        </motion.div>

        <motion.h3
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="font-display font-black text-3xl sm:text-4xl md:text-5xl text-transparent bg-clip-text bg-gradient-to-r from-white via-archive-paper to-archive-cyan tracking-wide mb-5"
        >
          {t('history.relics.title')}
        </motion.h3>

        <motion.p
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-sans text-archive-paper-muted text-sm sm:text-base font-light leading-relaxed max-w-2xl mx-auto"
        >
          {t('history.relics.desc')}
        </motion.p>
      </div>

      {/* Relics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {RELICS.map((relic, index) => {
          const isSelected = selectedRelic === relic.id;
          return (
            <motion.div
              key={relic.id}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={{ duration: 0.6, delay: index * 0.08 }}
              onClick={() => setSelectedRelic(isSelected ? null : relic.id)}
              className={`relative cursor-pointer rounded-3xl border ${relic.borderColor} bg-gradient-to-br ${relic.bgGradient} p-7 backdrop-blur-xl transition-all duration-400 ${relic.glowColor} group hover:scale-[1.02] active:scale-[0.99]`}
            >
              {/* Corner Badge */}
              <div className="flex items-center justify-between gap-2 mb-6">
                <div className="p-3 rounded-2xl bg-archive-dark/80 border border-white/10 shadow-inner group-hover:scale-110 transition-transform duration-300">
                  {relic.icon}
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-mono tracking-wider px-3 py-1 rounded-full bg-black/40 text-archive-paper-muted border border-white/10">
                    {relic.era}
                  </span>
                </div>
              </div>

              {/* Title */}
              <h4 className={`font-display font-bold text-xl sm:text-2xl mb-2 tracking-wide text-archive-paper group-hover:${relic.themeColor} transition-colors`}>
                {isRtl ? relic.nameAr : relic.nameEn}
              </h4>

              {/* Custodian Dedication */}
              <div className="flex items-center gap-2 mb-4 text-xs font-mono">
                <span className="text-archive-paper-muted/70">
                  {isRtl ? 'مهدى إلى:' : 'Dedicated to:'}
                </span>
                <span className={`font-semibold ${relic.themeColor}`}>
                  {isRtl ? relic.custodianAr : relic.custodianEn}
                </span>
              </div>

              {/* Description */}
              <p className="font-sans text-archive-paper-muted text-xs sm:text-sm font-light leading-relaxed mb-5 line-clamp-3 group-hover:line-clamp-none transition-all duration-300">
                {isRtl ? relic.descAr : relic.descEn}
              </p>

              {/* Bottom Interactive Tap Helper */}
              <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[11px] font-mono text-archive-cyan/70">
                <span className="flex items-center gap-1.5">
                  <Info size={12} />
                  <span>{t('history.relics.inspect')}</span>
                </span>
                <span className="opacity-0 group-hover:opacity-100 transition-opacity text-white">
                  ✦
                </span>
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
};
