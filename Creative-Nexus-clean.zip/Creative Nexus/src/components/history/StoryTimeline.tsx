import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CHAPTERS_DATA, ChapterData } from '../../data/historyChapters';
import { useLanguage } from '../../context/LanguageContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { 
  Quote, 
  Sparkles, 
  Flame, 
  Shield, 
  Crown, 
  Bookmark, 
  CheckCircle2, 
  AlertTriangle,
  ChevronRight,
  Compass,
  Users
} from 'lucide-react';

interface PersonStyle {
  name: string;
  colorClass: string;
}

const PEOPLE_CONFIG: Record<string, PersonStyle> = {
  // CRITICAL REQUIREMENT: "make the name of عمر العنزي Red"
  'عمر العنزي': {
    name: 'عمر العنزي',
    colorClass: 'text-red-400 font-bold bg-red-950/80 border border-red-500/70 shadow-[0_0_14px_rgba(239,68,68,0.4)] ring-1 ring-red-500/40 hover:bg-red-900/90 hover:text-red-100 transition-all duration-200',
  },
  'عمر': {
    name: 'عمر',
    colorClass: 'text-red-400 font-bold bg-red-950/80 border border-red-500/70 shadow-[0_0_14px_rgba(239,68,68,0.4)] ring-1 ring-red-500/40 hover:bg-red-900/90 hover:text-red-100 transition-all duration-200',
  },
  'Omar': {
    name: 'Omar',
    colorClass: 'text-red-400 font-bold bg-red-950/80 border border-red-500/70 shadow-[0_0_14px_rgba(239,68,68,0.4)] ring-1 ring-red-500/40 hover:bg-red-900/90 hover:text-red-100 transition-all duration-200',
  },

  // Sovereign Edgar - Radiant Solar Amber
  'إيدجر': {
    name: 'إيدجر',
    colorClass: 'text-amber-300 font-bold bg-amber-950/60 border border-amber-500/50 shadow-[0_0_12px_rgba(245,158,11,0.25)] hover:bg-amber-900/60 hover:text-amber-100 transition-all duration-200',
  },
  'إدغار': {
    name: 'إدغار',
    colorClass: 'text-amber-300 font-bold bg-amber-950/60 border border-amber-500/50 shadow-[0_0_12px_rgba(245,158,11,0.25)] hover:bg-amber-900/60 hover:text-amber-100 transition-all duration-200',
  },
  'Edgar': {
    name: 'Edgar',
    colorClass: 'text-amber-300 font-bold bg-amber-950/60 border border-amber-500/50 shadow-[0_0_12px_rgba(245,158,11,0.25)] hover:bg-amber-900/60 hover:text-amber-100 transition-all duration-200',
  },

  // Kevin (First Owner) - Regal Cobalt Blue
  'Kevin': {
    name: 'Kevin',
    colorClass: 'text-sky-300 font-semibold bg-sky-950/50 border border-sky-500/50 hover:bg-sky-900/50 hover:text-sky-100 transition-all duration-200',
  },

  // Sh3la - The Sacred Blaze Orange
  'Sh3la — شعلة': {
    name: 'Sh3la — شعلة',
    colorClass: 'text-orange-300 font-semibold bg-orange-950/50 border border-orange-500/50 shadow-[0_0_10px_rgba(249,115,22,0.25)] hover:bg-orange-900/50 hover:text-orange-100 transition-all duration-200',
  },
  'Sh3la': {
    name: 'Sh3la',
    colorClass: 'text-orange-300 font-semibold bg-orange-950/50 border border-orange-500/50 shadow-[0_0_10px_rgba(249,115,22,0.25)] hover:bg-orange-900/50 hover:text-orange-100 transition-all duration-200',
  },
  'شعلة': {
    name: 'شعلة',
    colorClass: 'text-orange-300 font-semibold bg-orange-950/50 border border-orange-500/50 shadow-[0_0_10px_rgba(249,115,22,0.25)] hover:bg-orange-900/50 hover:text-orange-100 transition-all duration-200',
  },

  // Hamo - Muted Amethyst Violet
  'حمو': {
    name: 'حمو',
    colorClass: 'text-purple-300 font-semibold bg-purple-950/50 border border-purple-500/50 hover:bg-purple-900/50 hover:text-purple-100 transition-all duration-200',
  },
  'Hamo': {
    name: 'Hamo',
    colorClass: 'text-purple-300 font-semibold bg-purple-950/50 border border-purple-500/50 hover:bg-purple-900/50 hover:text-purple-100 transition-all duration-200',
  },

  // Adham - Sky Azure
  'Adham': {
    name: 'Adham',
    colorClass: 'text-cyan-300 font-semibold bg-cyan-950/50 border border-cyan-500/50 hover:bg-cyan-900/50 hover:text-cyan-100 transition-all duration-200',
  },
  'أدهم': {
    name: 'أدهم',
    colorClass: 'text-cyan-300 font-semibold bg-cyan-950/50 border border-cyan-500/50 hover:bg-cyan-900/50 hover:text-cyan-100 transition-all duration-200',
  },

  // Super - Solar Honey
  'Super': {
    name: 'Super',
    colorClass: 'text-yellow-300 font-semibold bg-yellow-950/50 border border-yellow-500/50 hover:bg-yellow-900/50 hover:text-yellow-100 transition-all duration-200',
  },

  // Osama - Mint Emerald
  'Osama': {
    name: 'Osama',
    colorClass: 'text-teal-300 font-semibold bg-teal-950/50 border border-teal-500/50 hover:bg-teal-900/50 hover:text-teal-100 transition-all duration-200',
  },
  'أسامة': {
    name: 'أسامة',
    colorClass: 'text-teal-300 font-semibold bg-teal-950/50 border border-teal-500/50 hover:bg-teal-900/50 hover:text-teal-100 transition-all duration-200',
  },

  // ABYSSWOLF - Glacial Arctic Emerald
  'ABYSSWOLF': {
    name: 'ABYSSWOLF',
    colorClass: 'text-emerald-300 font-bold bg-emerald-950/60 border border-emerald-500/50 shadow-[0_0_12px_rgba(16,185,129,0.3)] hover:bg-emerald-900/60 hover:text-emerald-100 transition-all duration-200',
  },
  'Abysswolf': {
    name: 'Abysswolf',
    colorClass: 'text-emerald-300 font-bold bg-emerald-950/60 border border-emerald-500/50 shadow-[0_0_12px_rgba(16,185,129,0.3)] hover:bg-emerald-900/60 hover:text-emerald-100 transition-all duration-200',
  },

  // KOHAN - Ancient Mesopotamian Gold
  'KOHAN': {
    name: 'KOHAN',
    colorClass: 'text-amber-200 font-bold bg-amber-950/60 border border-amber-500/50 shadow-[0_0_12px_rgba(245,158,11,0.3)] hover:bg-amber-900/60 hover:text-amber-100 transition-all duration-200',
  },
  'Kohan': {
    name: 'Kohan',
    colorClass: 'text-amber-200 font-bold bg-amber-950/60 border border-amber-500/50 shadow-[0_0_12px_rgba(245,158,11,0.3)] hover:bg-amber-900/60 hover:text-amber-100 transition-all duration-200',
  },

  // SHADOW - Velvet Royal Rose
  'SHADOW': {
    name: 'SHADOW',
    colorClass: 'text-rose-200 font-bold bg-rose-950/60 border border-rose-500/50 shadow-[0_0_12px_rgba(244,63,94,0.3)] hover:bg-rose-900/60 hover:text-rose-100 transition-all duration-200',
  },
  'Shadow': {
    name: 'Shadow',
    colorClass: 'text-rose-200 font-bold bg-rose-950/60 border border-rose-500/50 shadow-[0_0_12px_rgba(244,63,94,0.3)] hover:bg-rose-900/60 hover:text-rose-100 transition-all duration-200',
  },

  // Current Moderation Vanguard in Chapter 4
  'YOUSSEF': { name: 'YOUSSEF', colorClass: 'text-indigo-300 font-semibold bg-indigo-950/50 border border-indigo-500/50' },
  'MAKO': { name: 'MAKO', colorClass: 'text-cyan-300 font-semibold bg-cyan-950/50 border border-cyan-500/50' },
  'VIOLET': { name: 'VIOLET', colorClass: 'text-violet-300 font-semibold bg-violet-950/50 border border-violet-500/50' },
  'NADA': { name: 'NADA', colorClass: 'text-pink-300 font-semibold bg-pink-950/50 border border-pink-500/50' },
  'DOMA': { name: 'DOMA', colorClass: 'text-teal-300 font-semibold bg-teal-950/50 border border-teal-500/50' },
};

// Sort by length desc so longer composite names match first
const SORTED_NAMES = Object.keys(PEOPLE_CONFIG).sort((a, b) => b.length - a.length);
const ESCAPED_PATTERN = '(' + SORTED_NAMES.map(n => n.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&')).join('|') + ')';
const NAMES_REGEX = new RegExp(ESCAPED_PATTERN, 'g');

function renderInlineHighlightedText(text: string) {
  const parts = text.split(NAMES_REGEX);
  return (
    <>
      {parts.map((part, idx) => {
        const person = PEOPLE_CONFIG[part];
        if (person) {
          return (
            <span
              key={idx}
              className={`inline-flex items-center px-2 py-0.5 mx-1 rounded-md text-sm sm:text-base border cursor-default align-baseline shadow-xs ${person.colorClass}`}
            >
              {part}
            </span>
          );
        }
        return <span key={idx}>{part}</span>;
      })}
    </>
  );
}

function renderStoryParagraph(text: string) {
  // 1. Chapter 4 Staff Team Grid (Clean, legendary operational card group)
  if (text.includes('YOUSSEF') && text.includes('MAKO') && text.includes('DOMA')) {
    const moderators = [
      { name: 'YOUSSEF', roleAr: 'درع السيرفر والرقابة', color: 'from-indigo-500/20 to-indigo-950/40 text-indigo-300 border-indigo-500/40' },
      { name: 'MAKO', roleAr: 'تنسيق العمليات والمجتمع', color: 'from-cyan-500/20 to-cyan-950/40 text-cyan-300 border-cyan-500/40' },
      { name: 'VIOLET', roleAr: 'حفظ النظام والفعاليات', color: 'from-violet-500/20 to-violet-950/40 text-violet-300 border-violet-500/40' },
      { name: 'NADA', roleAr: 'رعاية المجتمع والإرشاد', color: 'from-pink-500/20 to-pink-950/40 text-pink-300 border-pink-500/40' },
      { name: 'DOMA', roleAr: 'الدعم التقني والإداري', color: 'from-teal-500/20 to-teal-950/40 text-teal-300 border-teal-500/40' },
    ];

    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 my-7">
        {moderators.map((m) => (
          <motion.div
            key={m.name}
            whileHover={{ y: -3, scale: 1.02 }}
            transition={{ duration: 0.2 }}
            className={`p-4 rounded-xl bg-gradient-to-b ${m.color} border text-center flex flex-col items-center justify-center transition-all shadow-md group`}
          >
            <span className="w-8 h-8 rounded-lg bg-white/10 border border-white/15 flex items-center justify-center mb-1.5 text-xs font-cinzel font-bold text-white shadow-xs group-hover:scale-110 transition-transform">
              {m.name[0]}
            </span>
            <span className="font-cairo font-bold text-sm text-white tracking-wide">{m.name}</span>
            <span className="text-[11px] text-slate-300 mt-1 line-clamp-1 font-cairo font-medium">{m.roleAr}</span>
          </motion.div>
        ))}
      </div>
    );
  }

  // 2. Punchy Single Figure Line (e.g. 'ABYSSWOLF.' or 'KOHAN.' or 'SHADOW.')
  const trimmed = text.trim().replace(/\.$/, '');
  if (PEOPLE_CONFIG[trimmed]) {
    const person = PEOPLE_CONFIG[trimmed];
    return (
      <div className="my-3">
        <span className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm sm:text-base font-bold border transition-all cursor-default ${person.colorClass}`}>
          <span>{trimmed}</span>
        </span>
      </div>
    );
  }

  // 3. Core Creed / Defining Quote Block
  if (text.includes('السيرفر لم يصل إلى هنا لأنه لم ينهَر') || text.includes('أنه سيعيد السيرفر أفضل مما كان')) {
    return (
      <motion.div 
        whileHover={{ scale: 1.01 }}
        transition={{ duration: 0.2 }}
        className="my-7 p-6 sm:p-7 rounded-2xl bg-gradient-to-r from-amber-950/40 via-[#0d161a] to-amber-950/20 border-s-4 border-amber-400 border-y border-e border-amber-500/30 shadow-[0_0_25px_rgba(245,158,11,0.12)] relative overflow-hidden"
      >
        <div className="absolute top-2 end-4 text-amber-500/10 font-cinzel text-5xl select-none pointer-events-none">
          ❝
        </div>
        <p className="font-messiri font-bold text-amber-200 text-lg sm:text-xl leading-relaxed relative z-10">
          « {text} »
        </p>
      </motion.div>
    );
  }

  // 4. Dramatic Turning Point (Second Breach)
  if (text.includes('حمو هكر السيرفر مرة ثانية')) {
    return (
      <div className="my-5 p-5 rounded-2xl bg-gradient-to-r from-rose-950/40 via-red-950/30 to-slate-950/70 border border-rose-500/50 text-rose-200 font-cairo font-bold text-base sm:text-lg leading-relaxed shadow-[0_0_20px_rgba(244,63,94,0.2)] flex items-center gap-3">
        <AlertTriangle className="text-rose-400 shrink-0 w-6 h-6 animate-pulse" />
        <div>{text}</div>
      </div>
    );
  }

  // 5. Standard paragraph with character name color highlighting (especially عمر العنزي in RED)
  return (
    <p className="transition-colors hover:text-white leading-[2.2]">
      {renderInlineHighlightedText(text)}
    </p>
  );
}

// Visual themes and gradients for each chapter
interface ChapterThemeSpec {
  gradientBg: string;
  glowAura: string;
  borderClass: string;
  borderTop: string;
  numberColor: string;
  watermarkColor: string;
  accentPill: string;
  activeNavGlow: string;
  icon: React.ComponentType<{ className?: string; size?: number }>;
}

const CHAPTER_THEMES: Record<ChapterData['theme'], ChapterThemeSpec> = {
  genesis: {
    gradientBg: 'bg-gradient-to-br from-cyan-950/35 via-[#061114] to-[#04080a]',
    glowAura: 'from-cyan-500/20 via-teal-500/10 to-transparent',
    borderClass: 'border-cyan-500/30 hover:border-cyan-400/60 shadow-[0_10px_35px_rgba(6,182,212,0.1)]',
    borderTop: 'border-t-cyan-400',
    numberColor: 'text-cyan-400',
    watermarkColor: 'text-cyan-400/10',
    accentPill: 'bg-cyan-950/60 border-cyan-500/40 text-cyan-300',
    activeNavGlow: 'border-cyan-400 bg-cyan-950/70 text-cyan-200 shadow-[0_0_15px_rgba(6,182,212,0.35)]',
    icon: Sparkles,
  },
  tragedy: {
    gradientBg: 'bg-gradient-to-br from-rose-950/40 via-[#13070b] to-[#0a0406]',
    glowAura: 'from-rose-500/20 via-red-500/10 to-transparent',
    borderClass: 'border-rose-500/30 hover:border-rose-400/60 shadow-[0_10px_35px_rgba(244,63,94,0.12)]',
    borderTop: 'border-t-rose-500',
    numberColor: 'text-rose-400',
    watermarkColor: 'text-rose-400/10',
    accentPill: 'bg-rose-950/60 border-rose-500/40 text-rose-300',
    activeNavGlow: 'border-rose-400 bg-rose-950/70 text-rose-200 shadow-[0_0_15px_rgba(244,63,94,0.35)]',
    icon: Flame,
  },
  struggle: {
    gradientBg: 'bg-gradient-to-br from-indigo-950/40 via-[#0a0815] to-[#06040c]',
    glowAura: 'from-indigo-500/20 via-purple-500/10 to-transparent',
    borderClass: 'border-indigo-500/30 hover:border-indigo-400/60 shadow-[0_10px_35px_rgba(99,102,241,0.12)]',
    borderTop: 'border-t-indigo-400',
    numberColor: 'text-indigo-400',
    watermarkColor: 'text-indigo-400/10',
    accentPill: 'bg-indigo-950/60 border-indigo-500/40 text-indigo-300',
    activeNavGlow: 'border-indigo-400 bg-indigo-950/70 text-indigo-200 shadow-[0_0_15px_rgba(99,102,241,0.35)]',
    icon: Shield,
  },
  golden: {
    gradientBg: 'bg-gradient-to-br from-amber-950/45 via-[#130e06] to-[#080603]',
    glowAura: 'from-amber-400/25 via-yellow-500/15 to-transparent',
    borderClass: 'border-amber-500/40 hover:border-amber-300/70 shadow-[0_12px_45px_rgba(245,158,11,0.18)]',
    borderTop: 'border-t-amber-400',
    numberColor: 'text-amber-400',
    watermarkColor: 'text-amber-400/15',
    accentPill: 'bg-amber-950/70 border-amber-400/50 text-amber-300',
    activeNavGlow: 'border-amber-400 bg-amber-950/80 text-amber-200 shadow-[0_0_20px_rgba(245,158,11,0.45)]',
    icon: Crown,
  },
};

export const StoryTimeline: React.FC = () => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';
  const [activeChapterId, setActiveChapterId] = useState<string>('chapter-01');

  // Smooth scroll handler
  const scrollToChapter = (chapterId: string) => {
    setActiveChapterId(chapterId);
    const element = document.getElementById(chapterId);
    if (element) {
      const yOffset = -90;
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }
  };

  // Scroll spy to keep active tab in sync
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 220;
      for (const chapter of CHAPTERS_DATA) {
        const el = document.getElementById(chapter.id);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveChapterId(chapter.id);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section className="relative py-10 sm:py-16">
      {/* ============================================================ */}
      {/* CHAPTER JUMP DOCK (Simple, Modern & Premium with Gradient)   */}
      {/* ============================================================ */}
      <div className="mb-12 flex justify-center px-2">
        <nav 
          aria-label="Story Chapters Navigation"
          className="inline-flex flex-wrap items-center justify-center gap-2 max-w-full overflow-x-auto"
        >
          {CHAPTERS_DATA.map((ch: ChapterData) => {
            const theme = CHAPTER_THEMES[ch.theme];
            const isActive = activeChapterId === ch.id;
            const Icon = theme.icon;

            return (
              <button
                key={ch.id}
                onClick={() => scrollToChapter(ch.id)}
                className={`relative flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all duration-300 cursor-pointer whitespace-nowrap shadow-sm ${
                  isActive
                    ? 'bg-gradient-to-r from-teal-500/35 via-[#5eead4]/40 to-emerald-500/35 text-white border border-[#5eead4]/60 font-bold shadow-[0_0_15px_rgba(94,234,212,0.35)]'
                    : 'bg-gradient-to-b from-white/[0.08] to-white/[0.02] text-slate-300 hover:text-white hover:bg-gradient-to-b hover:from-white/[0.15] hover:to-white/[0.05] border border-white/10 hover:border-white/25'
                }`}
              >
                <Icon size={13} className={`shrink-0 ${isActive ? 'text-[#5eead4]' : 'text-slate-400'}`} />
                <span className="font-cinzel text-xs opacity-60">{ch.roman}</span>
                <span className="font-cairo">{isAr ? ch.title : ch.taglineEn}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Main Chapter Content Container with Vertical Timeline Glow Accent */}
      <div className="relative max-w-3xl mx-auto space-y-16 sm:space-y-24">
        {CHAPTERS_DATA.map((chapter: ChapterData, cIdx: number) => {
          const theme = CHAPTER_THEMES[chapter.theme] || CHAPTER_THEMES.genesis;
          const ChapterIcon = theme.icon;

          return (
            <motion.article
              key={chapter.id}
              id={chapter.id}
              initial={{ opacity: 0, y: 35 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, ease: 'easeOut', delay: cIdx * 0.05 }}
              className={`relative rounded-3xl p-6 sm:p-10 md:p-14 scroll-mt-24 border ${theme.borderClass} ${theme.borderTop} border-t-4 overflow-hidden transition-all duration-300 ${
                isMesopotamian
                  ? 'mesopotamian-stone-bg border-amber-600/50 text-amber-100 shadow-[0_15px_40px_rgba(217,119,6,0.15)]'
                  : `${theme.gradientBg} text-slate-100`
              }`}
            >
              {/* Subtle ambient radiant glow behind card */}
              <div 
                aria-hidden="true"
                className={`absolute -top-24 -end-24 w-80 h-80 rounded-full bg-gradient-to-br ${theme.glowAura} blur-[80px] pointer-events-none opacity-80`} 
              />

              {/* Huge stylized watermark Roman numeral in background */}
              <div 
                aria-hidden="true"
                className={`absolute top-4 end-6 font-cinzel text-7xl sm:text-9xl font-extrabold select-none pointer-events-none transition-opacity duration-300 ${theme.watermarkColor}`}
              >
                {chapter.roman}
              </div>

              {/* Chapter Header: Rich Typography & Dynamic Badge */}
              <header className="relative z-10 mb-10 pb-7 border-b border-slate-800/80">
                <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                  {/* Themed Pill Badge */}
                  <div className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-cairo font-bold border ${theme.accentPill} shadow-xs`}>
                    <ChapterIcon size={14} />
                    <span>{chapter.taglineAr}</span>
                    <span className="opacity-40">·</span>
                    <span className="font-cinzel text-[11px] tracking-wider">{chapter.taglineEn}</span>
                  </div>

                  {/* Subtitle / Chronicle Tagline */}
                  <div className="font-cairo text-xs sm:text-sm text-slate-400 font-medium">
                    {chapter.subtitle}
                  </div>
                </div>

                {/* Chapter Main Title in El Messiri */}
                <h3 className="font-messiri font-black text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight leading-tight pt-1">
                  {chapter.title}
                </h3>
              </header>

              {/* Story Narrative Sections */}
              <div className="relative z-10 space-y-9">
                {chapter.eventSections.map((sec, sIdx) => {
                  const isCrisisSection = sec.sectionId === 'omar-crisis';

                  return (
                    <div 
                      key={sIdx} 
                      className={`space-y-4 ${
                        isCrisisSection 
                          ? 'p-5 sm:p-7 rounded-2xl bg-gradient-to-r from-red-950/30 via-red-950/15 to-transparent border border-red-900/40 shadow-[0_0_20px_rgba(239,68,68,0.12)]' 
                          : ''
                      }`}
                    >
                      {sec.sectionTitle && (
                        <h4 className="font-messiri font-bold text-lg sm:text-xl text-slate-100 pb-2 border-b border-slate-800/70 flex items-center gap-2">
                          <span className={`w-2 h-2 rounded-full ${theme.numberColor} bg-current inline-block`} />
                          <span>{renderInlineHighlightedText(sec.sectionTitle)}</span>
                        </h4>
                      )}

                      <div className="space-y-4 text-base sm:text-lg text-slate-200 font-cairo font-normal">
                        {sec.paragraphs.map((p, pIdx) => (
                          <div key={pIdx}>
                            {renderStoryParagraph(p)}
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Chapter Closing Highlight Quote Footer */}
              {chapter.quoteHighlightAr && (
                <footer className="relative z-10 mt-10 pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-sm text-slate-400">
                  <div className="flex items-center gap-2.5">
                    <Quote size={16} className={`${theme.numberColor} shrink-0`} />
                    <span className="font-messiri font-semibold italic text-slate-200">
                      « {chapter.quoteHighlightAr} »
                    </span>
                  </div>
                  {chapter.quoteSpeakerAr && (
                    <div className="font-cairo text-xs text-slate-400 font-medium sm:text-end shrink-0 px-2.5 py-1 rounded-lg bg-white/[0.03] border border-white/[0.06]">
                      {chapter.quoteSpeakerAr}
                    </div>
                  )}
                </footer>
              )}
            </motion.article>
          );
        })}
      </div>
    </section>
  );
};

export default StoryTimeline;
