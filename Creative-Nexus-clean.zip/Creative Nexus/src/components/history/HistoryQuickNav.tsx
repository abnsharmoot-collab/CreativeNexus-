import React from 'react';
import { motion } from 'motion/react';
import { useLanguage } from '../../context/LanguageContext';
import { 
  BookOpen, 
  Crown, 
  Users, 
  Clock, 
  CheckCircle2 
} from 'lucide-react';

export const HistoryQuickNav: React.FC = () => {
  const { t, language } = useLanguage();
  const isRtl = language === 'ar';

  const NAV_LINKS = [
    { href: '#eras', label: t('history.nav.eras'), icon: BookOpen },
    { href: '#sovereign-crown', label: t('history.nav.sovereign'), icon: Crown, highlight: true },
    { href: '#owners', label: t('history.nav.owners'), icon: Users },
  ];

  const STAT_CARDS = [
    {
      label: t('history.stats.years'),
      value: '2+',
      subtext: isRtl ? '2023 — الحاضر' : '2023 — Present',
      icon: Clock,
      color: 'text-archive-cyan',
    },
    {
      label: t('history.stats.members'),
      value: '500+',
      subtext: isRtl ? 'مواطنو السيرفر' : 'Sanctuary Citizens',
      icon: Users,
      color: 'text-emerald-400',
    },
    {
      label: t('history.stats.intact'),
      value: '100%',
      subtext: isRtl ? 'سلامة التوثيق' : 'Archival Integrity',
      icon: CheckCircle2,
      color: 'text-teal-300',
    },
  ];

  const handleSmoothScroll = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="mb-20">
      {/* 1. Interactive Anchor Pills */}
      <div className="flex flex-wrap items-center justify-center gap-2.5 sm:gap-3 mb-14">
        {NAV_LINKS.map((link) => {
          const Icon = link.icon;
          return (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => handleSmoothScroll(e, link.href)}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all duration-300 backdrop-blur-xl hover:scale-105 active:scale-95 shadow-md ${
                link.highlight
                  ? 'bg-gradient-to-r from-amber-500/25 via-amber-400/30 to-amber-500/25 border border-amber-400/50 text-amber-200 hover:shadow-[0_0_20px_rgba(245,158,11,0.3)]'
                  : 'bg-gradient-to-b from-white/[0.08] to-white/[0.02] border border-white/10 hover:border-white/25 text-slate-300 hover:text-white hover:bg-gradient-to-b hover:from-white/[0.15] hover:to-white/[0.05]'
              }`}
            >
              <Icon size={14} className={link.highlight ? 'text-amber-300' : 'text-archive-cyan'} />
              <span>{link.label}</span>
            </a>
          );
        })}
      </div>

      {/* 2. Archival Quick-Metrics Ledger */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-4xl mx-auto">
        {STAT_CARDS.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.08 }}
              className="relative rounded-2xl p-5 border border-archive-cyan/20 bg-archive-card/60 backdrop-blur-xl shadow-lg hover:border-archive-cyan/40 transition-colors"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-[11px] font-mono uppercase tracking-wider text-archive-paper-muted/80">
                  {stat.label}
                </span>
                <Icon size={16} className={stat.color} />
              </div>
              <div className={`font-display font-black text-2xl sm:text-3xl ${stat.color} mb-1 tracking-tight`}>
                {stat.value}
              </div>
              <div className="text-[11px] font-sans text-archive-paper-muted/60 font-light">
                {stat.subtext}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
