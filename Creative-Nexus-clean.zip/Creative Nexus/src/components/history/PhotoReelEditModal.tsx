import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Plus, 
  Trash2, 
  Upload, 
  Image as ImageIcon, 
  Check, 
  ArrowUp, 
  ArrowDown, 
  Sparkles,
  Camera,
  Copy,
  RotateCcw,
  Palette
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { OwnerPhotoSlide } from '../../context/OwnerCardBackgroundsContext';

// Compression helper for photo reel uploads
async function compressPhotoFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const MAX_DIM = 1400;
        let w = img.width;
        let h = img.height;
        if (w > h) {
          if (w > MAX_DIM) {
            h = Math.round((h * MAX_DIM) / w);
            w = MAX_DIM;
          }
        } else {
          if (h > MAX_DIM) {
            w = Math.round((w * MAX_DIM) / h);
            h = MAX_DIM;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(e.target?.result as string);
        ctx.drawImage(img, 0, 0, w, h);
        try {
          resolve(canvas.toDataURL('image/webp', 0.88));
        } catch {
          resolve(canvas.toDataURL('image/jpeg', 0.88));
        }
      };
      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

export interface PhotoReelEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  slides?: OwnerPhotoSlide[];
  initialSlides?: OwnerPhotoSlide[];
  onSave: (updatedSlides: OwnerPhotoSlide[]) => Promise<void>;
  ownerName?: string;
  accentColor?: string;
}

export const PhotoReelEditModal: React.FC<PhotoReelEditModalProps> = ({
  isOpen,
  onClose,
  slides,
  initialSlides,
  onSave,
  ownerName = '',
  accentColor = '#2dd4bf',
}) => {
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const rawSlides = slides || initialSlides || [];
  const [reelItems, setReelItems] = useState<OwnerPhotoSlide[]>(() =>
    Array.isArray(rawSlides) ? rawSlides.map((s) => ({ ...s })) : []
  );
  const [activeEditingIndex, setActiveEditingIndex] = useState<number | null>(0);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [uploadingIndex, setUploadingIndex] = useState<number | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync safely whenever modal opens
  useEffect(() => {
    if (isOpen) {
      const source = slides || initialSlides || [];
      const list = Array.isArray(source) ? source.map((s) => ({ ...s })) : [];
      setReelItems(list);
      setActiveEditingIndex(list.length > 0 ? 0 : null);
      setSaveSuccess(false);
    }
  }, [isOpen, slides, initialSlides]);

  if (!isOpen) return null;

  const handleAddNewPhoto = () => {
    const newItem: OwnerPhotoSlide = {
      image: '',
      title: isAr ? 'لقطة تاريخية جديدة' : 'New Chronicle Memory',
      caption: isAr ? 'قصة أو تفاصيل هذه الذكرى في السيرفر...' : 'Backstory or details of this server memory...',
      palette: 'dawn',
      seed: Math.floor(Math.random() * 9999) + 1,
    };
    setReelItems((prev) => [...prev, newItem]);
    setActiveEditingIndex(reelItems.length);
  };

  const handleDuplicatePhoto = (index: number) => {
    const target = reelItems[index];
    if (!target) return;
    const duplicated: OwnerPhotoSlide = {
      ...target,
      title: `${target.title || ''} (${isAr ? 'نسخة' : 'Copy'})`,
      seed: Math.floor(Math.random() * 9999) + 1,
    };
    setReelItems((prev) => {
      const copy = [...prev];
      copy.splice(index + 1, 0, duplicated);
      return copy;
    });
    setActiveEditingIndex(index + 1);
  };

  const handleUpdateItem = (index: number, updates: Partial<OwnerPhotoSlide>) => {
    setReelItems((prev) => {
      const copy = [...prev];
      if (!copy[index]) return prev;
      copy[index] = { ...copy[index], ...updates };
      return copy;
    });
  };

  const handleDeleteItem = (index: number) => {
    setReelItems((prev) => prev.filter((_, i) => i !== index));
    if (activeEditingIndex === index) {
      setActiveEditingIndex(reelItems.length > 1 ? Math.max(0, index - 1) : null);
    } else if (activeEditingIndex !== null && activeEditingIndex > index) {
      setActiveEditingIndex(activeEditingIndex - 1);
    }
  };

  const handleMove = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= reelItems.length) return;
    setReelItems((prev) => {
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[targetIndex];
      copy[targetIndex] = temp;
      return copy;
    });
    setActiveEditingIndex(targetIndex);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, targetIdx: number) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setUploadingIndex(targetIdx);
      const dataUrl = await compressPhotoFile(file);
      handleUpdateItem(targetIdx, { image: dataUrl });
    } catch (err) {
      console.error('Failed to compress image:', err);
    } finally {
      setUploadingIndex(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveSuccess(false);
    try {
      await onSave(reelItems);
      setSaveSuccess(true);
      setTimeout(() => {
        setSaveSuccess(false);
        onClose();
      }, 700);
    } catch (err) {
      console.error('Failed to save reel:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const activeItem = activeEditingIndex !== null ? reelItems[activeEditingIndex] : null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/85 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-4xl rounded-3xl bg-[#031514] border border-cyan-500/30 text-slate-100 shadow-[0_25px_80px_rgba(0,0,0,0.95)] overflow-hidden z-10 my-auto"
        >
          {/* Header */}
          <div className="relative px-6 py-4 border-b border-white/10 bg-gradient-to-r from-slate-950 via-[#061e1c] to-slate-950 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div 
                className="w-10 h-10 rounded-xl flex items-center justify-center border shadow-xs"
                style={{
                  backgroundColor: `${accentColor}20`,
                  borderColor: `${accentColor}50`,
                  color: accentColor,
                }}
              >
                <Camera size={20} />
              </div>
              <div>
                <h3 className="font-display font-bold text-base sm:text-lg text-white">
                  {isAr ? 'تعديل ألبوم الذكريات واللقطات الأثرية' : 'Edit Archival Snapshots & Photo Reel'}
                </h3>
                <p className="text-xs text-slate-400 font-sans">
                  {isAr
                    ? `إضافة وتعديل الصور، العناوين، والقصص المعلقة على الحبل لـ ${ownerName || 'المالك'}`
                    : `Customize photos, titles, backstories, and string prints for ${ownerName || 'Owner'}`}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>

          {/* Body Content */}
          <div className="p-5 sm:p-6 grid grid-cols-1 md:grid-cols-12 gap-5 max-h-[calc(85vh-140px)] overflow-y-auto custom-scrollbar">
            {/* Left Column: Photo List */}
            <div className="md:col-span-5 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="text-xs font-mono uppercase tracking-wider text-slate-300">
                  {isAr ? `اللقطات المعلقة (${reelItems.length})` : `Hanging Prints (${reelItems.length})`}
                </span>
                <button
                  type="button"
                  onClick={handleAddNewPhoto}
                  className="px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer active:scale-95"
                >
                  <Plus size={13} />
                  <span>{isAr ? 'إضافة لقطة' : 'Add Print'}</span>
                </button>
              </div>

              {reelItems.length === 0 ? (
                <div className="p-8 text-center rounded-2xl bg-black/40 border border-dashed border-white/15">
                  <ImageIcon size={28} className="mx-auto text-slate-500 mb-2" />
                  <p className="text-xs text-slate-400 mb-3">
                    {isAr ? 'لا توجد صور في الألبوم حالياً' : 'No photos in reel yet'}
                  </p>
                  <button
                    type="button"
                    onClick={handleAddNewPhoto}
                    className="px-3 py-1.5 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs cursor-pointer active:scale-95"
                  >
                    {isAr ? 'إضافة أول لقطة' : 'Add First Print'}
                  </button>
                </div>
              ) : (
                <div className="space-y-2 max-h-[360px] overflow-y-auto pe-1 custom-scrollbar">
                  {reelItems.map((item, idx) => {
                    const isSelected = activeEditingIndex === idx;
                    return (
                      <div
                        key={idx}
                        onClick={() => setActiveEditingIndex(idx)}
                        className={`p-2.5 rounded-xl border flex items-center gap-3 cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-cyan-500/15 border-cyan-400/60 shadow-[0_0_15px_rgba(6,182,212,0.15)]'
                            : 'bg-black/40 border-white/10 hover:border-white/20'
                        }`}
                      >
                        {/* Thumbnail */}
                        <div className="w-14 h-10 rounded-lg overflow-hidden bg-slate-900 border border-white/15 shrink-0 flex items-center justify-center">
                          {item.image ? (
                            <img src={item.image} alt={item.title || ''} className="w-full h-full object-cover" />
                          ) : (
                            <span className="text-[10px] font-mono text-cyan-400 capitalize">{item.palette || 'dawn'}</span>
                          )}
                        </div>

                        {/* Title & Caption snippet */}
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-bold text-white truncate">
                            {item.title || (isAr ? `لقطة #${idx + 1}` : `Print #${idx + 1}`)}
                          </p>
                          <p className="text-[11px] text-slate-400 truncate">
                            {item.caption || (isAr ? 'بدون وصف' : 'No description')}
                          </p>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                          <button
                            type="button"
                            disabled={idx === 0}
                            onClick={() => handleMove(idx, 'up')}
                            title={isAr ? 'تقديم' : 'Move Up'}
                            className="p-1 rounded text-slate-400 hover:text-white disabled:opacity-20 cursor-pointer"
                          >
                            <ArrowUp size={12} />
                          </button>
                          <button
                            type="button"
                            disabled={idx === reelItems.length - 1}
                            onClick={() => handleMove(idx, 'down')}
                            title={isAr ? 'تأخير' : 'Move Down'}
                            className="p-1 rounded text-slate-400 hover:text-white disabled:opacity-20 cursor-pointer"
                          >
                            <ArrowDown size={12} />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDuplicatePhoto(idx)}
                            title={isAr ? 'تكرار' : 'Duplicate'}
                            className="p-1 rounded text-slate-400 hover:text-cyan-300 cursor-pointer"
                          >
                            <Copy size={12} />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteItem(idx)}
                            title={isAr ? 'حذف' : 'Delete'}
                            className="p-1 rounded text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 cursor-pointer"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Right Column: Active Photo Details Form */}
            <div className="md:col-span-7 space-y-4">
              {activeItem && activeEditingIndex !== null ? (
                <div className="p-4 sm:p-5 rounded-2xl bg-black/50 border border-white/10 space-y-4">
                  <div className="flex items-center justify-between border-b border-white/10 pb-3">
                    <span className="text-xs font-mono text-cyan-400 flex items-center gap-1.5">
                      <Sparkles size={13} />
                      <span>{isAr ? `تعديل اللقطة #${activeEditingIndex + 1}` : `Edit Print #${activeEditingIndex + 1}`}</span>
                    </span>
                    <span className="text-[10px] font-mono text-slate-400 uppercase">
                      {activeItem.image ? (isAr ? 'صورة مخصصة' : 'Custom Photo') : (isAr ? 'لوحة فنية' : 'Procedural Canvas')}
                    </span>
                  </div>

                  {/* Photo Preview with Outline Only (Matching the New Design!) */}
                  <div className="relative aspect-[16/10] w-full rounded-2xl overflow-hidden bg-slate-950 border-2 border-white/30 shadow-[0_16px_35px_rgba(0,0,0,0.8)] group">
                    {activeItem.image ? (
                      <img
                        src={activeItem.image}
                        alt="Active preview"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 p-4 text-center bg-gradient-to-br from-slate-900 via-teal-950/40 to-slate-950">
                        <ImageIcon size={32} className="text-cyan-400/70 mb-2" />
                        <span className="text-xs font-sans text-slate-300 font-medium">
                          {isAr 
                            ? `لوحة طبيعية بطراز (${activeItem.palette || 'dawn'})` 
                            : `Procedural landscape style (${activeItem.palette || 'dawn'})`}
                        </span>
                        <span className="text-[10px] text-slate-500 mt-1 font-mono">
                          {isAr ? 'تتولد تلقائياً برمجياً إذا لم يتم رفع صورة' : 'Generates dynamically when no photo URL is set'}
                        </span>
                      </div>
                    )}

                    {/* On-image Scrim Title & Story Preview */}
                    <div className="absolute inset-x-0 bottom-0 p-3.5 bg-gradient-to-t from-black/90 via-black/50 to-transparent flex flex-col gap-1 pointer-events-none">
                      <div className="text-sm font-bold text-white truncate">
                        {activeItem.title || (isAr ? 'بدون عنوان' : 'Untitled Memory')}
                      </div>
                      {activeItem.caption && (
                        <div className="text-xs text-slate-300 line-clamp-1">
                          {activeItem.caption}
                        </div>
                      )}
                    </div>

                    {uploadingIndex === activeEditingIndex && (
                      <div className="absolute inset-0 bg-black/80 flex items-center justify-center text-cyan-300 text-xs font-medium">
                        {isAr ? 'جاري ضغط ومعالجة الصورة...' : 'Processing image...'}
                      </div>
                    )}
                  </div>

                  {/* Image URL & File Upload */}
                  <div>
                    <label className="block text-[11px] font-mono text-slate-300 mb-1.5">
                      {isAr ? 'رابط الصورة المباشر أو رفع ملف من جهازك' : 'Photo Image URL or Direct Upload'}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="url"
                        value={activeItem.image || ''}
                        onChange={(e) => handleUpdateItem(activeEditingIndex, { image: e.target.value })}
                        placeholder="https://... or paste image URL"
                        className="flex-1 px-3 py-2 rounded-xl bg-black/60 border border-white/15 focus:border-cyan-400 text-xs text-white font-mono focus:outline-hidden"
                      />
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileUpload(e, activeEditingIndex)}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        disabled={uploadingIndex !== null}
                        className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-white/20 text-slate-200 text-xs font-medium flex items-center gap-1.5 cursor-pointer disabled:opacity-50 shrink-0 active:scale-95"
                      >
                        <Upload size={13} />
                        <span>{isAr ? 'رفع ملف' : 'Upload'}</span>
                      </button>
                      {activeItem.image && (
                        <button
                          type="button"
                          onClick={() => handleUpdateItem(activeEditingIndex, { image: '' })}
                          title={isAr ? 'إزالة الصورة واستخدام لوحة فنية' : 'Remove photo and use canvas'}
                          className="p-2 rounded-xl bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 border border-white/10 hover:border-rose-500/30 cursor-pointer"
                        >
                          <RotateCcw size={13} />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Nature Palette & Seed Option (Used when image is empty) */}
                  <div>
                    <label className="block text-[11px] font-mono text-slate-300 mb-1.5 flex items-center gap-1.5">
                      <Palette size={12} className="text-cyan-400" />
                      <span>{isAr ? 'نمط اللوحة الفنية التلقائية' : 'Procedural Canvas Palette (if no photo)'}</span>
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      {(['dawn', 'alpine', 'dusk', 'mist'] as const).map((pal) => {
                        const isSelected = (activeItem.palette || 'dawn') === pal;
                        return (
                          <button
                            key={pal}
                            type="button"
                            onClick={() => handleUpdateItem(activeEditingIndex, { palette: pal })}
                            className={`px-2.5 py-1.5 rounded-xl border text-xs capitalize font-mono transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200 font-bold shadow-xs'
                                : 'bg-black/40 border-white/10 text-slate-400 hover:text-white hover:border-white/25'
                            }`}
                          >
                            {pal}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Photo Title */}
                  <div>
                    <label className="block text-[11px] font-mono text-slate-300 mb-1.5">
                      {isAr ? 'عنوان واسم اللقطة (Photo Title)' : 'Photo Title / Name'}
                    </label>
                    <input
                      type="text"
                      value={activeItem.title || ''}
                      onChange={(e) => handleUpdateItem(activeEditingIndex, { title: e.target.value })}
                      placeholder="e.g. Genesis Dawn, Golden Era Triumph, Sanctuary Gathering"
                      className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 focus:border-cyan-400 text-xs text-white font-sans focus:outline-hidden"
                    />
                  </div>

                  {/* Photo Story / Caption */}
                  <div>
                    <label className="block text-[11px] font-mono text-slate-300 mb-1.5">
                      {isAr ? 'القصة أو السيرة للقطة (Photo Backstory / Caption)' : 'Photo Backstory / Caption'}
                    </label>
                    <textarea
                      rows={3}
                      value={activeItem.caption || ''}
                      onChange={(e) => handleUpdateItem(activeEditingIndex, { caption: e.target.value })}
                      placeholder="Write the backstory, context, date, or memories associated with this photograph..."
                      className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 focus:border-cyan-400 text-xs text-white font-sans focus:outline-hidden leading-relaxed"
                    />
                  </div>
                </div>
              ) : (
                <div className="h-full flex items-center justify-center p-8 rounded-2xl bg-black/30 border border-white/10 text-slate-500 text-xs">
                  {isAr ? 'اختر لقطة من القائمة على اليمين أو انقر "إضافة لقطة" لتعديلها' : 'Select a print from the list or click "Add Print"'}
                </div>
              )}
            </div>
          </div>

          {/* Footer Save Actions */}
          <div className="px-6 py-4 border-t border-white/10 bg-slate-950/90 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>

            <button
              type="button"
              disabled={isSaving}
              onClick={handleSave}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 text-slate-950 text-xs font-bold shadow-[0_0_20px_rgba(6,182,212,0.4)] hover:shadow-[0_0_25px_rgba(6,182,212,0.6)] transition-all cursor-pointer disabled:opacity-50 flex items-center gap-2 active:scale-95"
            >
              {saveSuccess ? (
                <>
                  <Check size={14} />
                  <span>{isAr ? 'تم حفظ الألبوم بنجاح!' : 'Photo Reel Saved!'}</span>
                </>
              ) : isSaving ? (
                <span>{isAr ? 'جاري الحفظ...' : 'Saving Reel...'}</span>
              ) : (
                <span>{isAr ? 'حفظ كافة تعديلات الألبوم' : 'Save Photo Reel'}</span>
              )}
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
