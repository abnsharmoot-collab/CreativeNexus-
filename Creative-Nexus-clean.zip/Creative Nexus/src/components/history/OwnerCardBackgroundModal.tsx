import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Upload, 
  Image as ImageIcon, 
  Sliders, 
  Trash2, 
  Check, 
  AlertCircle, 
  Sparkles, 
  Eye, 
  EyeOff,
  RefreshCw,
  Link as LinkIcon,
  Crown,
  Heart,
  Flame,
  Star,
  Shield,
  Palette,
  MoveUp,
  MoveDown,
  Plus,
  Layers,
  Flag,
  Zap,
  Move,
  Maximize2,
  Minimize2,
  RotateCcw
} from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { useOwnerCardBackgrounds, OwnerCardCustomization } from '../../context/OwnerCardBackgroundsContext';
import { OwnerCardEffectLayer } from './OwnerCardEffectLayer';

// Color theme presets
const ACCENT_COLORS = [
  { id: 'amber', nameAr: 'ذهبي ملكي', nameEn: 'Royal Gold', hex: '#f59e0b', ring: 'ring-amber-500', bg: 'bg-amber-500' },
  { id: 'emerald', nameAr: 'زمردي ناصع', nameEn: 'Emerald Green', hex: '#10b981', ring: 'ring-emerald-500', bg: 'bg-emerald-500' },
  { id: 'rose', nameAr: 'وردي مخملي', nameEn: 'Velvet Rose', hex: '#f43f5e', ring: 'ring-rose-500', bg: 'bg-rose-500' },
  { id: 'cyan', nameAr: 'فيروزي جليدي', nameEn: 'Arctic Cyan', hex: '#06b6d4', ring: 'ring-cyan-500', bg: 'bg-cyan-500' },
  { id: 'purple', nameAr: 'بنفسجي أرجواني', nameEn: 'Royal Purple', hex: '#a855f7', ring: 'ring-purple-500', bg: 'bg-purple-500' },
  { id: 'amethyst', nameAr: 'جمشت بلوري', nameEn: 'Crystal Amethyst', hex: '#8b5cf6', ring: 'ring-violet-500', bg: 'bg-violet-500' },
  { id: 'mint', nameAr: 'نعناع سماوي', nameEn: 'Celestial Mint', hex: '#2dd4bf', ring: 'ring-teal-400', bg: 'bg-teal-400' },
  { id: 'platinum', nameAr: 'بلاتينوم فضي', nameEn: 'Silver Platinum', hex: '#e2e8f0', ring: 'ring-slate-300', bg: 'bg-slate-300' },
  { id: 'red', nameAr: 'أحمر قرمزي', nameEn: 'Crimson Red', hex: '#ef4444', ring: 'ring-red-500', bg: 'bg-red-500' },
  { id: 'orange', nameAr: 'شعلة نارية', nameEn: 'Blaze Orange', hex: '#f97316', ring: 'ring-orange-500', bg: 'bg-orange-500' },
  { id: 'yellow', nameAr: 'شمس ساطعة', nameEn: 'Solar Honey', hex: '#eab308', ring: 'ring-yellow-500', bg: 'bg-yellow-500' },
  { id: 'blue', nameAr: 'أزرق ملكي', nameEn: 'Sapphire Blue', hex: '#3b82f6', ring: 'ring-blue-500', bg: 'bg-blue-500' },
];

// Special effect presets
const VISUAL_EFFECTS = [
  { id: 'none', nameAr: 'بدون مؤثر', nameEn: 'Clean Standard', icon: Sliders },
  { id: 'romantic', nameAr: 'قلوب رومانسية مضيئة', nameEn: 'Floating Hearts', icon: Heart },
  { id: 'fire', nameAr: 'شرارات نيران صاعدة', nameEn: 'Rising Embers', icon: Flame },
  { id: 'stars', nameAr: 'نجوم سديمية براقة', nameEn: 'Cosmic Stars', icon: Star },
  { id: 'guardian', nameAr: 'درع حماية زمردي', nameEn: 'Guardian Aura', icon: Shield },
  { id: 'cyber', nameAr: 'تأثير سيبراني حديث', nameEn: 'Cyber Grid', icon: Sparkles },
  { id: 'solar', nameAr: 'هالة شمسية ذهبية', nameEn: 'Solar Corona', icon: Crown },
  { id: 'electric', nameAr: 'طاقة كهربائية ساطعة', nameEn: 'Electric Surge', icon: Zap },
  { id: 'void', nameAr: 'سديم فضائي غامض', nameEn: 'Void Nebula', icon: Star },
  { id: 'phoenix', nameAr: 'أجنحة العنقاء الذهبية', nameEn: 'Phoenix Flame', icon: Flame },
  { id: 'aurora', nameAr: 'أورورا الشفق القطبي', nameEn: 'Borealis Aurora', icon: Sparkles },
  { id: 'sakura', nameAr: 'بتلات ساكورا بلورية', nameEn: 'Zen Sakura', icon: Heart },
];

// Helper to compress an image file to a base64 Data URL (max 1600px, quality 0.85)
async function compressImageFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const MAX_WIDTH = 1600;
        const MAX_HEIGHT = 1600;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height = Math.round((height * MAX_WIDTH) / width);
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width = Math.round((width * MAX_HEIGHT) / height);
            height = MAX_HEIGHT;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          return resolve(e.target?.result as string);
        }

        ctx.drawImage(img, 0, 0, width, height);
        try {
          const dataUrl = canvas.toDataURL('image/webp', 0.84);
          resolve(dataUrl);
        } catch {
          const dataUrl = canvas.toDataURL('image/jpeg', 0.84);
          resolve(dataUrl);
        }
      };
      img.onerror = () => reject(new Error('Failed to load image for compression'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.readAsDataURL(file);
  });
}

export const OwnerCardBackgroundModal: React.FC = () => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { isOwner } = useAuth();
  const { 
    isModalOpen, 
    closeEditModal, 
    activeCardForEdit, 
    getCustomization,
    updateCard, 
    deleteCard,
  } = useOwnerCardBackgrounds();

  // Active Tab: Wallpaper Scene, Card Size, Buttons & Removal, Colors, Effects, Info, Order
  const [activeTab, setActiveTab] = useState<'photo' | 'card-size' | 'buttons' | 'style' | 'effects' | 'info' | 'order'>('photo');

  // Basic Details
  const [name, setName] = useState<string>('');
  const [displayName, setDisplayName] = useState<string>('');
  const [roleTitle, setRoleTitle] = useState<string>('Server Owner');
  const [subtitle, setSubtitle] = useState<string>('');
  const [badge, setBadge] = useState<string>('');
  const [country, setCountry] = useState<string>('');
  const [status, setStatus] = useState<'present' | 'former'>('present');

  // Styling & Effects
  const [accentColor, setAccentColor] = useState<string>('amber');
  const [effect, setEffect] = useState<string>('none');
  const [glowIntensity, setGlowIntensity] = useState<number>(0.5);
  const [borderStyle, setBorderStyle] = useState<string>('glow');

  // Card Height & Proportions
  const [cardHeightPreset, setCardHeightPreset] = useState<'compact' | 'standard' | 'tall' | 'epic'>('standard');
  const [cardHeight, setCardHeight] = useState<number | undefined>(undefined);

  // Button Visibility & Removal Toggles
  const [hideAllButtons, setHideAllButtons] = useState<boolean>(false);
  const [hideEditButton, setHideEditButton] = useState<boolean>(false);
  const [hideBadgeButton, setHideBadgeButton] = useState<boolean>(false);
  const [hideStatusBadge, setHideStatusBadge] = useState<boolean>(false);
  const [hideCharacter, setHideCharacter] = useState<boolean>(false);

  // Background Wallpaper
  const [imageUrl, setImageUrl] = useState<string>('');
  const [overlayOpacity, setOverlayOpacity] = useState<number>(0.45);
  const [blurAmount, setBlurAmount] = useState<number>(0);
  const [objectPosition, setObjectPosition] = useState<string>('center');
  const [order, setOrder] = useState<number>(1);

  // URL input fields
  const [customUrlInput, setCustomUrlInput] = useState<string>('');

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isProcessingFile, setIsProcessingFile] = useState<boolean>(false);
  const [statusMsg, setStatusMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync state whenever active target card changes
  useEffect(() => {
    if (activeCardForEdit && isModalOpen) {
      const existing = getCustomization(activeCardForEdit.cardId, activeCardForEdit.fallbackCardId);

      setName(existing?.name || activeCardForEdit.ownerName || '');
      setDisplayName(existing?.displayName || activeCardForEdit.displayName || activeCardForEdit.ownerName || '');
      setRoleTitle(existing?.roleTitle || activeCardForEdit.roleTitle || 'Server Owner');
      setSubtitle(existing?.subtitle || activeCardForEdit.subtitle || '');
      setBadge(existing?.badge || activeCardForEdit.badge || '');
      setCountry(existing?.country || activeCardForEdit.country || '');
      setStatus(existing?.status || activeCardForEdit.status || 'present');

      setAccentColor(existing?.accentColor || activeCardForEdit.defaultAccent || 'amber');
      setEffect(existing?.effect || 'none');
      setGlowIntensity(typeof existing?.glowIntensity === 'number' ? existing.glowIntensity : 0.5);
      setBorderStyle(existing?.borderStyle || 'glow');

      // Card height
      setCardHeightPreset(existing?.cardHeightPreset || 'standard');
      setCardHeight(existing?.cardHeight);

      // Button removal / clean mode
      setHideAllButtons(existing?.hideAllButtons ?? false);
      setHideEditButton(existing?.hideEditButton ?? false);
      setHideBadgeButton(existing?.hideBadgeButton ?? false);
      setHideStatusBadge(existing?.hideStatusBadge ?? false);

      // Background Wallpaper
      setImageUrl(existing?.imageUrl || '');
      setOverlayOpacity(typeof existing?.overlayOpacity === 'number' ? existing.overlayOpacity : 0.45);
      setBlurAmount(typeof existing?.blur === 'number' ? existing.blur : 0);
      setObjectPosition(existing?.objectPosition || 'center');
      setOrder(typeof existing?.order === 'number' ? existing.order : 1);
      setCustomUrlInput(existing?.imageUrl?.startsWith('data:') ? '' : (existing?.imageUrl || ''));
      setStatusMsg(null);
    }
  }, [activeCardForEdit, isModalOpen, getCustomization]);

  if (!isModalOpen || !isOwner || !activeCardForEdit) {
    return null;
  }

  // Handle local background image file
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setStatusMsg({
        text: isAr ? 'يرجى اختيار ملف صورة صالح' : 'Please select a valid image file',
        type: 'error'
      });
      return;
    }

    try {
      setIsProcessingFile(true);
      setStatusMsg(null);
      const dataUrl = await compressImageFile(file);
      setImageUrl(dataUrl);
      setCustomUrlInput('');
      setStatusMsg({
        text: isAr ? 'تم تحميل الصورة وضغطها بنجاح' : 'Image loaded and compressed successfully',
        type: 'success'
      });
    } catch {
      setStatusMsg({
        text: isAr ? 'فشل معالجة الصورة، يرجى المحاولة مرة أخرى' : 'Failed to process image, please try again',
        type: 'error'
      });
    } finally {
      setIsProcessingFile(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Handle local character artwork file
  const handleApplyUrl = () => {
    const trimmed = customUrlInput.trim();
    if (!trimmed) return;
    setImageUrl(trimmed);
    setStatusMsg({
      text: isAr ? 'تم تعيين رابط الصورة' : 'Image URL applied',
      type: 'success'
    });
  };

  // Save Card Customization
  const handleSaveCard = async () => {
    setIsSubmitting(true);
    setStatusMsg(null);

    const res = await updateCard({
      cardId: activeCardForEdit.cardId,
      name: name.trim() || activeCardForEdit.ownerName,
      displayName: displayName.trim() || name.trim() || activeCardForEdit.ownerName,
      roleTitle: roleTitle.trim(),
      subtitle: subtitle.trim(),
      badge: badge.trim(),
      accentColor,
      effect,
      glowIntensity,
      borderStyle,
      imageUrl: imageUrl.trim() || null,
      characterImageUrl: null,
      hideCharacter: true,
      cardHeightPreset,
      cardHeight,
      hideAllButtons,
      hideEditButton,
      hideBadgeButton,
      hideStatusBadge,
      overlayOpacity,
      blur: blurAmount,
      objectPosition,
      order,
      status,
      country: country || undefined,
      isCustom: activeCardForEdit.isCustom ?? false
    });

    setIsSubmitting(false);

    if (res.success) {
      setStatusMsg({
        text: isAr ? 'تم حفظ كافة تخصيصات البطاقة بنجاح!' : 'All card customizations saved successfully!',
        type: 'success'
      });
      setTimeout(() => {
        closeEditModal();
      }, 700);
    } else {
      setStatusMsg({
        text: res.error || (isAr ? 'حدث خطأ أثناء الحفظ' : 'Failed to save card customization'),
        type: 'error'
      });
    }
  };

  // Delete Card
  const handleDeleteCard = async () => {
    if (!window.confirm(isAr ? 'هل أنت متأكد من رغبتك في حذف هذه البطاقة نهائياً؟' : 'Are you sure you want to permanently delete this card?')) {
      return;
    }

    setIsSubmitting(true);
    const res = await deleteCard(activeCardForEdit.cardId);
    setIsSubmitting(false);

    if (res.success) {
      setStatusMsg({
        text: isAr ? 'تم حذف البطاقة بنجاح' : 'Card deleted successfully',
        type: 'success'
      });
      setTimeout(() => {
        closeEditModal();
      }, 600);
    } else {
      setStatusMsg({
        text: res.error || (isAr ? 'فشل حذف البطاقة' : 'Failed to delete card'),
        type: 'error'
      });
    }
  };

  // Color hex object
  const activeColorObj = ACCENT_COLORS.find(c => c.id === accentColor) || ACCENT_COLORS[0];

  if (!isModalOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={closeEditModal}
          className="fixed inset-0 bg-black/85 backdrop-blur-md"
        />

        {/* Modal Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-5xl rounded-3xl bg-[#061114] border border-cyan-500/30 text-slate-100 shadow-[0_25px_70px_rgba(0,0,0,0.9)] overflow-hidden z-10 my-auto"
        >
          {/* Top Bar Header */}
          <div className="relative px-6 py-4 border-b border-slate-800/90 bg-gradient-to-r from-amber-950/40 via-slate-900 to-cyan-950/40 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-center text-amber-300 shadow-[0_0_15px_rgba(245,158,11,0.2)]">
                <Crown size={20} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-cairo font-bold text-base sm:text-lg text-white">
                    {activeCardForEdit.isCustom 
                      ? (isAr ? 'إضافة بطاقة قيادية جديدة' : 'Add New Leader Card') 
                      : (isAr ? 'تخصيص البطاقة المتقدم' : 'Advanced Card Customizer')}
                  </h3>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950 text-amber-300 border border-amber-500/40">
                    OWNER SUITE
                  </span>
                </div>
                <p className="font-cairo text-xs text-slate-400">
                  {isAr 
                    ? `تعديل الحجم، مكان الشخصية، إزالة الأزرار، الألوان، والمؤثرات لـ ${activeCardForEdit.ownerName}` 
                    : `Customize character placement, size, card height & remove buttons for ${activeCardForEdit.ownerName}`}
                </p>
              </div>
            </div>

            <button
              onClick={closeEditModal}
              className="w-9 h-9 rounded-xl bg-white/[0.05] border border-white/10 flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-1.5 px-6 py-2.5 bg-slate-950/80 border-b border-slate-800/80 overflow-x-auto custom-scrollbar">
            {[
              { id: 'photo', labelAr: 'خلفية البطاقة', labelEn: 'Wallpaper Scene', icon: ImageIcon },
              { id: 'card-size', labelAr: 'أبعاد وارتفاع البطاقة', labelEn: 'Card Dimensions', icon: Maximize2 },
              { id: 'buttons', labelAr: 'التحكم بالأزرار والحذف', labelEn: 'Buttons & Removal', icon: EyeOff },
              { id: 'style', labelAr: 'الألوان والتدرجات', labelEn: 'Colors & Glow', icon: Palette },
              { id: 'effects', labelAr: 'المؤثرات البصرية', labelEn: 'Visual Effects', icon: Sparkles },
              { id: 'info', labelAr: 'الاسم والبيانات', labelEn: 'Details', icon: Crown },
              { id: 'order', labelAr: 'الترتيب والمكان', labelEn: 'Order', icon: Layers },
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-cairo font-semibold transition-all cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-amber-950/70 border border-amber-500/50 text-amber-200 shadow-xs'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.03] border border-transparent'
                  }`}
                >
                  <Icon size={14} className={isActive ? 'text-amber-400' : 'opacity-70'} />
                  <span>{isAr ? tab.labelAr : tab.labelEn}</span>
                </button>
              );
            })}
          </div>

          {/* Modal Body with Live Preview */}
          <div className="p-5 sm:p-7 max-h-[calc(85vh-160px)] overflow-y-auto custom-scrollbar space-y-6">
            {/* Live Interactive Card Preview Mockup */}
            <div className="p-4 rounded-2xl bg-white/[0.02] border border-slate-800/80">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-cairo font-semibold text-slate-300 flex items-center gap-1.5">
                  <Eye size={13} className="text-amber-400" />
                  <span>{isAr ? 'معاينة حية فورية لخلفية البطاقة' : 'Live Real-Time Card Background Preview'}</span>
                </span>
                <div className="flex items-center gap-2 text-[11px] font-mono text-slate-400">
                  <span className="text-amber-400 font-semibold">{isAr ? 'عرض خلفية البطاقة فقط' : 'Background Image Only'}</span>
                  <span>•</span>
                  <span>{displayName || name || 'LEADER'} #{order}</span>
                </div>
              </div>

              {/* High-Fidelity Mockup with Character Size & Placement + Button Removal */}
              {(() => {
                const faceGradients: Record<string, string> = {
                  amber: 'bg-gradient-to-b from-[#1c1204]/95 via-slate-950/90 to-[#0e0801]/98',
                  emerald: 'bg-gradient-to-b from-[#041a12]/95 via-slate-950/90 to-[#020d09]/98',
                  rose: 'bg-gradient-to-b from-[#220713]/95 via-slate-950/90 to-[#120308]/98',
                  cyan: 'bg-gradient-to-b from-[#051824]/95 via-slate-950/90 to-[#020c13]/98',
                  purple: 'bg-gradient-to-b from-[#180927]/95 via-slate-950/90 to-[#0b0312]/98',
                  amethyst: 'bg-gradient-to-b from-[#150a24]/95 via-slate-950/90 to-[#0b0314]/98',
                  mint: 'bg-gradient-to-b from-[#041c19]/95 via-slate-950/90 to-[#020e0d]/98',
                  platinum: 'bg-gradient-to-b from-[#161a22]/95 via-slate-950/90 to-[#0b0d12]/98',
                  red: 'bg-gradient-to-b from-[#220707]/95 via-slate-950/90 to-[#120303]/98',
                  orange: 'bg-gradient-to-b from-[#220c04]/95 via-slate-950/90 to-[#110502]/98',
                  yellow: 'bg-gradient-to-b from-[#1e1704]/95 via-slate-950/90 to-[#0f0b01]/98',
                  blue: 'bg-gradient-to-b from-[#061427]/95 via-slate-950/90 to-[#020a14]/98',
                };
                const cardFaceBg = faceGradients[accentColor] || faceGradients.amber;
                const latinNumerals = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII', 'XIII'];
                const latinNum = (order && order > 0 && order <= 13) ? latinNumerals[order - 1] : latinNumerals[0];

                const isCleanMode = hideAllButtons;
                const isEditButtonRemoved = isCleanMode || hideEditButton;
                const isBadgeRemoved = isCleanMode || hideBadgeButton;
                const isStatusRemoved = isCleanMode || hideStatusBadge;

                return (
                  <div 
                    className={`relative rounded-3xl min-h-[390px] flex flex-col justify-between overflow-hidden border transition-all duration-300 shadow-2xl max-w-sm mx-auto ${cardFaceBg}`}
                    style={{
                      borderColor: activeColorObj.hex + '50',
                      boxShadow: `0 16px 45px rgba(0,0,0,0.9), 0 0 ${Math.round(15 + (glowIntensity || 0.4) * 35)}px ${activeColorObj.hex}${Math.round((glowIntensity || 0.4) * 90).toString(16).padStart(2, '0')}`,
                    }}
                  >
                    {/* Top ambient highlight line */}
                    <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-white/40 to-transparent pointer-events-none z-20" />

                    {/* Background scene/wallpaper if set */}
                    {imageUrl && (
                      <div
                        className="absolute inset-0 bg-cover pointer-events-none transition-all z-0"
                        style={{
                          backgroundImage: `url(${imageUrl})`,
                          backgroundPosition: objectPosition,
                          filter: blurAmount > 0 ? `blur(${blurAmount}px)` : 'none',
                          opacity: 1 - overlayOpacity
                        }}
                      />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent pointer-events-none z-0" />

                    {/* Animated Effect Layer */}
                    <OwnerCardEffectLayer
                      effect={effect}
                      accentColor={accentColor}
                      glowIntensity={glowIntensity}
                      borderStyle={borderStyle}
                    />

                    {/* Top Floating Customize Card Button Preview (if not removed) */}
                    {!isEditButtonRemoved && (
                      <div className="absolute top-3 end-3 z-30 pointer-events-none">
                        <span className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-950/90 border border-amber-500/40 text-amber-300 text-[10px] font-bold font-cairo shadow-sm">
                          <Sliders size={11} className="text-amber-400" />
                          <span>{isAr ? 'زر التخصيص' : 'Edit'}</span>
                        </span>
                      </div>
                    )}

                    {/* Card Top Header */}
                    <div className="relative z-10 p-3.5 pb-1 flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        {!isStatusRemoved && (
                          <span 
                            className="px-2.5 py-0.5 rounded-full text-[10px] font-bold border backdrop-blur-md"
                            style={{ color: activeColorObj.hex, borderColor: activeColorObj.hex + '60', backgroundColor: activeColorObj.hex + '18' }}
                          >
                            {roleTitle || 'Server Owner'}
                          </span>
                        )}
                        {country && (
                          <span className="text-xs uppercase font-mono px-1.5 py-0.5 rounded bg-black/40 border border-white/10 text-slate-300">
                            {country === 'iraq' ? '🇮🇶' : country === 'uae' ? '🇦🇪' : country === 'egypt' ? '🇪🇬' : country}
                          </span>
                        )}
                      </div>
                      
                      {/* Latin Number Badge */}
                      <span className="font-serif text-[11px] font-bold tracking-widest text-slate-300 uppercase px-2 py-0.5 rounded-lg bg-black/50 border border-white/10 shadow-xs">
                        {latinNum}
                      </span>
                    </div>

                    {/* Middle Viewport - Clean open view showing ONLY the background image */}
                    <div className="relative z-10 flex-1 flex flex-col p-2 my-auto min-h-[170px] overflow-hidden justify-center items-center">
                      {/* Soft ambient aura */}
                      <div 
                        className="absolute inset-0 w-32 h-32 m-auto rounded-full blur-2xl pointer-events-none"
                        style={{
                          backgroundColor: activeColorObj.hex,
                          opacity: (glowIntensity || 0.4) * 0.35
                        }}
                      />
                      <div className="flex-1 w-full" />
                    </div>

                    {/* Bottom Face Information */}
                    <div className="relative z-10 pt-4 pb-4 px-5 bg-gradient-to-t from-slate-950 via-slate-950/90 to-transparent border-t border-white/[0.05]">
                      <h4 
                        className="font-display font-extrabold text-xl text-center mb-1 tracking-wide"
                        style={{ color: activeColorObj.hex }}
                      >
                        {displayName || name || 'LEADER'}
                      </h4>

                      <div className="my-2 mx-auto w-2/3 h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-60" />

                      <p className="text-xs text-slate-300 font-sans text-center line-clamp-2 mb-2 px-1">
                        {subtitle || (isAr ? 'عضو ريادي وداعم رئيسي في العصر الحالي لـ Creative Nexus' : 'Key leader & supporter in Creative Nexus')}
                      </p>

                      <div className="pt-2 border-t border-white/[0.08] flex items-center justify-between text-[11px] text-slate-400">
                        {!isBadgeRemoved ? (
                          <span className="font-mono text-[10px] tracking-wider text-cyan-300 flex items-center gap-1">
                            <Sparkles size={10} />
                            <span>{badge || (isAr ? 'قائد' : 'Leader')}</span>
                          </span>
                        ) : (
                          <span className="text-[10px] font-cairo text-slate-600 italic">
                            {isAr ? '(تمت إزالة الزر)' : '(Button removed)'}
                          </span>
                        )}
                        <span className="font-display font-bold text-sm text-white/30 tracking-widest ms-auto">
                          {latinNum}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* TAB 1: Names & Details */}
            {activeTab === 'info' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-cairo font-semibold text-slate-200 block">
                      {isAr ? 'اسم البطاقة / المفتاح الرئيسي' : 'Card Primary Name'}
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. KOHAN, SHADOW, ABYSSWOLF"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm font-bold text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  {/* Display Name */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-cairo font-semibold text-slate-200 block">
                      {isAr ? 'الاسم الظاهر بالعنوان (Display Name)' : 'Formatted Display Name'}
                    </label>
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="e.g. ࣪˖ 𝐒𝐇𝐀𝐃𝐎𝐖 ࣪˖ or Kohan"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  {/* Role Title */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-cairo font-semibold text-slate-200 block">
                      {isAr ? 'الرتبة أو اللقب (Role Title)' : 'Role Title'}
                    </label>
                    <input
                      type="text"
                      value={roleTitle}
                      onChange={(e) => setRoleTitle(e.target.value)}
                      placeholder="e.g. Server Owner, Owner & Wife, Founder"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  {/* Honor Badge */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-cairo font-semibold text-slate-200 block">
                      {isAr ? 'وسام أو شارة التكريم (Badge Tag)' : 'Honor Badge'}
                    </label>
                    <input
                      type="text"
                      value={badge}
                      onChange={(e) => setBadge(e.target.value)}
                      placeholder="e.g. القلب الخالد, درع المجتمع"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                {/* Subtitle / Bio */}
                <div className="space-y-1.5">
                  <label className="text-xs font-cairo font-semibold text-slate-200 block">
                    {isAr ? 'الوصف التكريمي / النبذة (Bio Subtitle)' : 'Bio / Subtitle'}
                  </label>
                  <textarea
                    rows={2}
                    value={subtitle}
                    onChange={(e) => setSubtitle(e.target.value)}
                    placeholder={isAr ? 'اكتب نبذة أو وصفاً يظهر أسفل الاسم في البطاقة...' : 'Write descriptive bio text displayed on the card...'}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                </div>

                {/* Country Flag & Status */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                  <div className="space-y-1.5">
                    <label className="text-xs font-cairo font-semibold text-slate-200 block">
                      {isAr ? 'علم الدولة (Country Flag)' : 'Country Flag'}
                    </label>
                    <select
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs font-cairo text-white focus:outline-none focus:border-amber-400 cursor-pointer"
                    >
                      <option value="">{isAr ? 'بدون علم' : 'No Flag'}</option>
                      <option value="iraq">العراق 🇮🇶 (Iraq)</option>
                      <option value="uae">الإمارات 🇦🇪 (UAE)</option>
                      <option value="egypt">مصر 🇪🇬 (Egypt)</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-cairo font-semibold text-slate-200 block">
                      {isAr ? 'حالة المالك (Status)' : 'Status'}
                    </label>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setStatus('present')}
                        className={`flex-1 py-2 rounded-xl text-xs font-cairo font-bold border transition-colors cursor-pointer ${
                          status === 'present'
                            ? 'bg-emerald-950/70 border-emerald-500 text-emerald-300'
                            : 'bg-slate-900 border-slate-700 text-slate-400'
                        }`}
                      >
                        {isAr ? 'مالك حالي (Present)' : 'Present Owner'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setStatus('former')}
                        className={`flex-1 py-2 rounded-xl text-xs font-cairo font-bold border transition-colors cursor-pointer ${
                          status === 'former'
                            ? 'bg-slate-800 border-slate-500 text-slate-200'
                            : 'bg-slate-900 border-slate-700 text-slate-400'
                        }`}
                      >
                        {isAr ? 'مالك تاريخي (Former)' : 'Former Owner'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: Card Dimensions & Height */}
            {activeTab === 'card-size' && (
              <div className="space-y-5">
                <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4">
                  <div>
                    <h4 className="text-xs font-cairo font-bold text-amber-300">
                      {isAr ? 'ارتفاع وأبعاد البطاقة (Card Height Presets)' : 'Card Height & Proportions'}
                    </h4>
                    <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                      {isAr ? 'اختر ارتفاع البطاقة ليناسب حجم وتفاصيل شخصية القائد بشكل سينمائي.' : 'Select the vertical presence and proportion of the card canvas.'}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {[
                      { id: 'compact', labelAr: 'مدمج (460px)', labelEn: 'Compact (460px)', height: 460 },
                      { id: 'standard', labelAr: 'متوازن (540px)', labelEn: 'Standard (540px)', height: 540 },
                      { id: 'tall', labelAr: 'طويل بارز (620px)', labelEn: 'Tall Hero (620px)', height: 620 },
                      { id: 'epic', labelAr: 'ملحمي واسع (700px)', labelEn: 'Epic Grand (700px)', height: 700 },
                    ].map(p => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => {
                          setCardHeightPreset(p.id as any);
                          setCardHeight(p.height);
                        }}
                        className={`p-3 rounded-xl border text-xs font-cairo text-center transition-all cursor-pointer ${
                          cardHeightPreset === p.id
                            ? 'bg-amber-950/70 border-amber-400 text-amber-200 font-bold shadow-md'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        <Maximize2 size={16} className={`mx-auto mb-1.5 ${cardHeightPreset === p.id ? 'text-amber-400' : 'text-slate-500'}`} />
                        <span>{isAr ? p.labelAr : p.labelEn}</span>
                      </button>
                    ))}
                  </div>

                  {/* Custom Height Slider */}
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                    <div className="flex justify-between items-center text-xs font-cairo font-semibold">
                      <span className="text-slate-300">{isAr ? 'ارتفاع مخصص بالبكسل (Custom Height)' : 'Custom Height Slider'}</span>
                      <span className="font-mono text-amber-400">
                        {cardHeight || (cardHeightPreset === 'compact' ? 460 : cardHeightPreset === 'tall' ? 620 : cardHeightPreset === 'epic' ? 700 : 540)}px
                      </span>
                    </div>
                    <input
                      type="range"
                      min="420"
                      max="750"
                      step="10"
                      value={cardHeight || 540}
                      onChange={(e) => setCardHeight(parseInt(e.target.value))}
                      className="w-full accent-amber-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg appearance-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* TAB 4: Buttons Customization & Removal */}
            {activeTab === 'buttons' && (
              <div className="space-y-6">
                {/* 1. Button Visibility Toggles on Card Face */}
                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700 space-y-4">
                  <div>
                    <h4 className="text-xs font-cairo font-bold text-amber-300 flex items-center gap-1.5">
                      <EyeOff size={14} />
                      <span>{isAr ? 'التحكم في ظهور أزرار البطاقة (Card Buttons Display & Removal)' : 'Card Buttons Display & Removal'}</span>
                    </h4>
                    <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                      {isAr ? 'يمكنك إزالة الأزرار من وجه البطاقة لجعلها نقية وأنيقة دون أي عناصر تشويش.' : 'Remove buttons from the card face for an ultra-clean archival appearance.'}
                    </p>
                  </div>

                  {/* Master Clean Mode Toggle */}
                  <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/40 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-cairo font-bold text-amber-200 block">
                        {isAr ? '✨ وضع فني نقي - إزالة كافة الأزرار من البطاقة' : '✨ Clean Artistic Mode - Remove All Buttons'}
                      </span>
                      <span className="text-[11px] text-slate-400 font-cairo">
                        {isAr ? 'إخفاء زر التخصيص، شارة الحالة، وأزرار الأوسمة لعرض فني خالص' : 'Hides customize button, status badge, and honor action buttons from card'}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setHideAllButtons(prev => !prev)}
                      className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                        hideAllButtons ? 'bg-amber-500' : 'bg-slate-800'
                      }`}
                    >
                      <span 
                        className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                          hideAllButtons ? 'start-6' : 'start-0.5'
                        }`} 
                      />
                    </button>
                  </div>

                  {/* Individual Button Removal Toggles */}
                  <div className="space-y-2.5 pt-1">
                    {/* Hide Floating Customize Button */}
                    <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                      <div>
                        <span className="text-xs font-cairo font-semibold text-slate-200 block">
                          {isAr ? 'إزالة زر "تخصيص البطاقة" العائم من على البطاقة' : 'Remove Floating "Customize Card" Button from Card'}
                        </span>
                        <span className="text-[11px] text-slate-400 font-cairo">
                          {isAr ? 'يخفي الزر العائم في الزاوية العلوية لهذه البطاقة' : 'Hides the top-corner floating customize button on this card'}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setHideEditButton(prev => !prev)}
                        className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                          hideEditButton ? 'bg-amber-500' : 'bg-slate-800'
                        }`}
                      >
                        <span 
                          className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                            hideEditButton ? 'start-6' : 'start-0.5'
                          }`} 
                        />
                      </button>
                    </div>

                    {/* Hide Badge Action & Secret Game Button */}
                    <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                      <div>
                        <span className="text-xs font-cairo font-semibold text-slate-200 block">
                          {isAr ? 'إزالة زر الوسام واللعبة السرية' : 'Remove Honor Badge & Secret Game Button'}
                        </span>
                        <span className="text-[11px] text-slate-400 font-cairo">
                          {isAr ? 'يخفي زر التكريم التفاعلي من أسفل البطاقة' : 'Hides interactive honor pill and secret mini-game button'}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setHideBadgeButton(prev => !prev)}
                        className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                          hideBadgeButton ? 'bg-amber-500' : 'bg-slate-800'
                        }`}
                      >
                        <span 
                          className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                            hideBadgeButton ? 'start-6' : 'start-0.5'
                          }`} 
                        />
                      </button>
                    </div>

                    {/* Hide Status Indicator (Present / Former) */}
                    <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                      <div>
                        <span className="text-xs font-cairo font-semibold text-slate-200 block">
                          {isAr ? 'إزالة شارة الحالة (حالي / سابق)' : 'Remove Status Pill (Present / Former)'}
                        </span>
                        <span className="text-[11px] text-slate-400 font-cairo">
                          {isAr ? 'يخفي الشارة الخضراء أو الرمادية من أعلى البطاقة' : 'Hides top status indicator pill'}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setHideStatusBadge(prev => !prev)}
                        className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                          hideStatusBadge ? 'bg-amber-500' : 'bg-slate-800'
                        }`}
                      >
                        <span 
                          className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                            hideStatusBadge ? 'start-6' : 'start-0.5'
                          }`} 
                        />
                      </button>
                    </div>
                  </div>
                </div>

                {/* 2. Quick Element Removal Action Buttons */}
                <div className="p-4 rounded-2xl bg-rose-950/20 border border-rose-900/40 space-y-3">
                  <div>
                    <h4 className="text-xs font-cairo font-bold text-rose-300">
                      {isAr ? 'أزرار إزالة العناصر السريعة (Quick Element Removals)' : 'Quick Removal Action Buttons'}
                    </h4>
                    <p className="text-[11px] text-rose-400/80 font-cairo">
                      {isAr ? 'أزرار لإزالة محتويات محددة بنقرة واحدة:' : 'One-click removal buttons for specific elements:'}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                    {/* Clean Viewport / Background Only Mode */}
                    <button
                      type="button"
                      onClick={() => {
                        setHideAllButtons(true);
                        setStatusMsg({ text: isAr ? 'تم تفعيل الوضع النظيف (عرض صورة الخلفية فقط بدون أزرار)' : 'Clean mode enabled: Showing only background image without buttons', type: 'success' });
                      }}
                      className="p-2.5 rounded-xl bg-slate-900 hover:bg-amber-950/60 border border-slate-700 hover:border-amber-500/50 text-slate-200 hover:text-amber-200 text-xs font-cairo font-semibold flex items-center justify-between cursor-pointer transition-colors"
                    >
                      <span className="flex items-center gap-2">
                        <EyeOff size={13} className="text-amber-400" />
                        <span>{isAr ? 'الوضع النظيف (خلفية فقط)' : 'Clean Mode (Background Only)'}</span>
                      </span>
                      <Sliders size={13} className="opacity-60" />
                    </button>

                    {/* Remove Wallpaper Background */}
                    <button
                      type="button"
                      onClick={() => {
                        setImageUrl('');
                        setCustomUrlInput('');
                        setStatusMsg({ text: isAr ? 'تمت إزالة صورة الخلفية' : 'Background wallpaper removed', type: 'success' });
                      }}
                      className="p-2.5 rounded-xl bg-slate-900 hover:bg-rose-950/60 border border-slate-700 hover:border-rose-500/50 text-slate-200 hover:text-rose-200 text-xs font-cairo font-semibold flex items-center justify-between cursor-pointer transition-colors"
                    >
                      <span className="flex items-center gap-2">
                        <ImageIcon size={13} className="text-rose-400" />
                        <span>{isAr ? 'إزالة خلفية البطاقة' : 'Remove Background'}</span>
                      </span>
                      <Trash2 size={13} className="opacity-60" />
                    </button>

                    {/* Remove Visual Effect */}
                    <button
                      type="button"
                      onClick={() => {
                        setEffect('none');
                        setStatusMsg({ text: isAr ? 'تمت إزالة المؤثر البصري' : 'Visual effect removed', type: 'success' });
                      }}
                      className="p-2.5 rounded-xl bg-slate-900 hover:bg-rose-950/60 border border-slate-700 hover:border-rose-500/50 text-slate-200 hover:text-rose-200 text-xs font-cairo font-semibold flex items-center justify-between cursor-pointer transition-colors"
                    >
                      <span className="flex items-center gap-2">
                        <Sparkles size={13} className="text-rose-400" />
                        <span>{isAr ? 'إزالة المؤثر البصري' : 'Remove Aura Effect'}</span>
                      </span>
                      <Trash2 size={13} className="opacity-60" />
                    </button>

                    {/* Remove Honor Badge */}
                    <button
                      type="button"
                      onClick={() => {
                        setBadge('');
                        setStatusMsg({ text: isAr ? 'تمت إزالة وسام التكريم' : 'Badge cleared', type: 'success' });
                      }}
                      className="p-2.5 rounded-xl bg-slate-900 hover:bg-rose-950/60 border border-slate-700 hover:border-rose-500/50 text-slate-200 hover:text-rose-200 text-xs font-cairo font-semibold flex items-center justify-between cursor-pointer transition-colors"
                    >
                      <span className="flex items-center gap-2">
                        <Crown size={13} className="text-rose-400" />
                        <span>{isAr ? 'إزالة وسام التكريم' : 'Clear Badge'}</span>
                      </span>
                      <Trash2 size={13} className="opacity-60" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 5: Colors & Border */}
            {activeTab === 'style' && (
              <div className="space-y-5">
                {/* Accent Color Swatches */}
                <div className="space-y-2">
                  <label className="text-xs font-cairo font-semibold text-slate-200 block">
                    {isAr ? 'اختر لون السمة والتمييز (Accent Color)' : 'Select Accent Color'}
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {ACCENT_COLORS.map(c => (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => setAccentColor(c.id)}
                        className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs font-cairo transition-all cursor-pointer ${
                          accentColor === c.id
                            ? 'border-amber-400 bg-amber-950/50 shadow-md text-white font-bold ring-2 ring-amber-400/30'
                            : 'border-slate-800 bg-slate-900 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        <span className={`w-4 h-4 rounded-full ${c.bg} shrink-0 shadow-xs`} />
                        <span>{isAr ? c.nameAr : c.nameEn}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Border Style */}
                <div className="space-y-2">
                  <label className="text-xs font-cairo font-semibold text-slate-200 block">
                    {isAr ? 'نمط وحركة الإطار (Border Style)' : 'Border Style'}
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                    {[
                      { id: 'glow', labelAr: 'توهج سينمائي', labelEn: 'Radiant Glow' },
                      { id: 'pulse', labelAr: 'نبض تنفسي هادئ', labelEn: 'Pulse Breath' },
                      { id: 'shimmer', labelAr: 'شريط متدرج متحرك', labelEn: 'Gradient Sweep' },
                      { id: 'neon', labelAr: 'إطار ليزر نيون', labelEn: 'Neon Laser' },
                      { id: 'solid', labelAr: 'كلاسيكي أنيق', labelEn: 'Minimal Solid' },
                    ].map(b => (
                      <button
                        key={b.id}
                        type="button"
                        onClick={() => setBorderStyle(b.id)}
                        className={`py-2 px-3 rounded-xl text-xs font-cairo border transition-colors cursor-pointer text-center ${
                          borderStyle === b.id
                            ? 'bg-amber-950/70 border-amber-400 text-amber-200 font-bold'
                            : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
                        }`}
                      >
                        {isAr ? b.labelAr : b.labelEn}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 6: Visual Effects */}
            {activeTab === 'effects' && (
              <div className="space-y-5">
                <div className="space-y-2">
                  <label className="text-xs font-cairo font-semibold text-slate-200 block">
                    {isAr ? 'اختر المؤثر الخاص بالبطاقة (Aura Effect)' : 'Select Aura Effect'}
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {VISUAL_EFFECTS.map(eff => {
                      const Icon = eff.icon;
                      return (
                        <button
                          key={eff.id}
                          type="button"
                          onClick={() => setEffect(eff.id)}
                          className={`flex items-center gap-3 p-3 rounded-xl border text-xs font-cairo transition-all cursor-pointer ${
                            effect === eff.id
                              ? 'border-amber-400 bg-amber-950/60 text-amber-200 font-bold shadow-md ring-2 ring-amber-400/20'
                              : 'border-slate-800 bg-slate-900 text-slate-300 hover:border-slate-700'
                          }`}
                        >
                          <Icon size={18} className={effect === eff.id ? 'text-amber-400' : 'text-slate-500'} />
                          <div className="text-start">
                            <span className="block font-semibold">{isAr ? eff.nameAr : eff.nameEn}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Glow Intensity Slider */}
                <div className="space-y-2 p-4 rounded-xl bg-slate-900/60 border border-slate-800">
                  <div className="flex justify-between items-center text-xs font-cairo font-semibold">
                    <span className="text-slate-200">{isAr ? 'شدة التوهج الخلفي (Glow Intensity)' : 'Glow Intensity'}</span>
                    <span className="font-mono text-amber-400 bg-amber-950/70 px-2 py-0.5 rounded border border-amber-500/30">
                      {Math.round(glowIntensity * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={glowIntensity}
                    onChange={(e) => setGlowIntensity(parseFloat(e.target.value))}
                    className="w-full accent-amber-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg appearance-none"
                  />
                </div>
              </div>
            )}

            {/* TAB 7: Background Wallpaper */}
            {activeTab === 'photo' && (
              <div className="space-y-5">
                <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-cairo font-bold text-slate-200">
                        {isAr ? 'خلفية البطاقة الكاملة (Background Wallpaper / Scene)' : 'Background Wallpaper / Scene'}
                      </h4>
                      <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                        {isAr ? 'صورة تغطي خلفية البطاقة بالكامل.' : 'Image covering the entire card background.'}
                      </p>
                    </div>
                    {imageUrl && (
                      <button
                        type="button"
                        onClick={() => {
                          setImageUrl('');
                          setCustomUrlInput('');
                        }}
                        className="text-[11px] font-cairo text-rose-400 hover:text-rose-300 underline cursor-pointer"
                      >
                        {isAr ? 'إزالة الخلفية' : 'Remove Background'}
                      </button>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row items-center gap-3">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                    <button
                      type="button"
                      disabled={isProcessingFile}
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full sm:w-auto px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-slate-200 font-cairo font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
                    >
                      <Upload size={14} />
                      <span>{isProcessingFile ? (isAr ? 'جارِ المعالجة...' : 'Processing...') : (isAr ? 'رفع خلفية' : 'Upload Wallpaper')}</span>
                    </button>

                    <div className="flex-1 flex gap-2 w-full">
                      <input
                        type="url"
                        placeholder="https://example.com/photo.jpg"
                        value={customUrlInput}
                        onChange={(e) => setCustomUrlInput(e.target.value)}
                        className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs font-mono text-white focus:outline-none focus:border-amber-400"
                      />
                      <button
                        type="button"
                        onClick={handleApplyUrl}
                        className="px-3.5 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs font-cairo font-semibold text-slate-200 hover:text-white cursor-pointer"
                      >
                        {isAr ? 'تطبيق' : 'Apply'}
                      </button>
                    </div>
                  </div>

                  {/* Sliders: Blur & Opacity */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center text-xs font-cairo font-semibold">
                        <span className="text-slate-300">{isAr ? 'الضبابية (Blur)' : 'Blur Radius'}</span>
                        <span className="font-mono text-amber-400">{blurAmount}px</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="35"
                        step="1"
                        value={blurAmount}
                        onChange={(e) => setBlurAmount(parseInt(e.target.value))}
                        className="w-full accent-amber-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg appearance-none"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center text-xs font-cairo font-semibold">
                        <span className="text-slate-300">{isAr ? 'تعتيم الخلفية للوضوح' : 'Dark Overlay Tint'}</span>
                        <span className="font-mono text-amber-400">{Math.round(overlayOpacity * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0.05"
                        max="0.9"
                        step="0.05"
                        value={overlayOpacity}
                        onChange={(e) => setOverlayOpacity(parseFloat(e.target.value))}
                        className="w-full accent-amber-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg appearance-none"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 8: Order & Management */}
            {activeTab === 'order' && (
              <div className="space-y-5">
                <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-cairo font-bold text-white">
                        {isAr ? 'ترتيب ومكان ظهور البطاقة' : 'Display Sequence Order'}
                      </h4>
                      <p className="text-xs text-slate-400 font-cairo">
                        {isAr ? 'البطاقات ذات الرقم الأصغر تظهر أولاً' : 'Cards with smaller numbers appear first'}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setOrder(prev => Math.max(1, prev - 1))}
                        className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-200 hover:text-white cursor-pointer"
                      >
                        <MoveUp size={14} />
                      </button>
                      <span className="font-mono font-bold text-base px-3 py-1 rounded-lg bg-slate-950 border border-amber-500/40 text-amber-300">
                        #{order}
                      </span>
                      <button
                        type="button"
                        onClick={() => setOrder(prev => prev + 1)}
                        className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-200 hover:text-white cursor-pointer"
                      >
                        <MoveDown size={14} />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Delete Danger Zone */}
                <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-900/40 flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-cairo font-bold text-rose-300">
                      {isAr ? 'حذف البطاقة نهائياً من السجل' : 'Delete Card from Archive'}
                    </h4>
                    <p className="text-[11px] text-rose-400/70 font-cairo">
                      {isAr ? 'إزالة هذه البطاقة بالكامل من العرض وقاعدة البيانات' : 'Permanently remove this leader card from display'}
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={isSubmitting}
                    onClick={handleDeleteCard}
                    className="px-3 py-2 rounded-xl bg-rose-950/70 hover:bg-rose-900 border border-rose-500/40 text-rose-200 text-xs font-cairo font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Trash2 size={14} />
                    <span>{isAr ? 'حذف البطاقة' : 'Delete Card'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* Status Message */}
            {statusMsg && (
              <div className={`p-3 rounded-xl text-xs font-cairo flex items-center gap-2 ${
                statusMsg.type === 'success'
                  ? 'bg-emerald-950/50 border border-emerald-500/40 text-emerald-200'
                  : 'bg-rose-950/50 border border-rose-500/40 text-rose-200'
              }`}>
                {statusMsg.type === 'success' ? <Check size={14} /> : <AlertCircle size={14} />}
                <span>{statusMsg.text}</span>
              </div>
            )}
          </div>

          {/* Modal Footer */}
          <div className="px-6 py-4 border-t border-slate-800/80 bg-slate-950/80 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={closeEditModal}
              className="px-4 py-2 rounded-xl text-xs font-cairo font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>

            <button
              type="button"
              disabled={isSubmitting}
              onClick={handleSaveCard}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 font-cairo font-bold text-xs shadow-lg shadow-amber-500/20 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? <RefreshCw size={14} className="animate-spin" /> : <Check size={14} />}
              <span>{isSubmitting ? (isAr ? 'جارِ الحفظ...' : 'Saving...') : (activeCardForEdit.isCustom ? (isAr ? 'إنشاء وإضافة البطاقة' : 'Create & Add Card') : (isAr ? 'حفظ كافة التعديلات' : 'Save All Changes'))}</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
