import React, { useRef, useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { useLanguage } from '../../context/LanguageContext';
import { useEasterEggs } from '../../context/EasterEggContext';
import { useAuth } from '../../context/AuthContext';
import { useOwnerCardBackgrounds } from '../../context/OwnerCardBackgroundsContext';
import { useStaff } from '../../context/StaffContext';
import { CountryFlag } from '../atoms/CountryFlag';
import { 
  Sparkles, 
  Clock,
  ArrowUp,
  ArrowDown,
  Trash2,
  ArrowUpRight
} from 'lucide-react';
import { OwnerCardBackgroundLayer } from './OwnerCardBackgroundLayer';
import { OwnerCardEffectLayer } from './OwnerCardEffectLayer';
import { getAccentColor, ACCENT_COLOR_MAP, toRomanNumeral } from '../../utils/ownerCardStyles';
import { useScroll3DTilt } from '../../hooks/useScroll3DTilt';

export interface OwnerData {
  id: number | string;
  cardId?: string;
  fallbackCardId?: string;
  romanNumeral: string;
  nameKey: string;
  displayName?: string;
  titleKey: string;
  descKey: string;
  badgeKey: string;
  status: 'present' | 'former';
  country?: 'iraq' | 'uae' | 'egypt';
  highlightType: 'standard' | 'chronicle' | 'warmth' | 'youth' | 'voyager' | 'guardian' | 'romantic' | 'code' | 'vanguard';
  order?: number;
  isCustom?: boolean;
}

interface OwnerTimelineCardProps {
  owner: OwnerData;
  index: number;
  isAlternate: boolean;
  showControls?: boolean;
  isFirst?: boolean;
  isLast?: boolean;
  onMoveUp?: () => void;
  onMoveDown?: () => void;
  onDelete?: () => void;
}

export const OwnerTimelineCard: React.FC<OwnerTimelineCardProps> = ({
  owner,
  index,
  isAlternate,
  showControls = false,
  isFirst = false,
  isLast = false,
  onMoveUp,
  onMoveDown,
  onDelete,
}) => {
  const { t, language } = useLanguage();
  const { setIsKohanGameOpen } = useEasterEggs();
  const { isAuthenticated, isOwner } = useAuth();
  const { getCustomization } = useOwnerCardBackgrounds();
  const { staff } = useStaff();
  const navigate = useNavigate();
  const isRtl = language === 'ar';
  const isAr = isRtl;

  const cardRef = useRef<HTMLDivElement>(null);
  const [hoverRotateX, setHoverRotateX] = useState(0);
  const [hoverRotateY, setHoverRotateY] = useState(0);
  const cardId = owner.cardId || `history_owner_${owner.id}`;
  const fallbackCardId = owner.fallbackCardId || (
    owner.id === 7 ? 'owner_shadow' :
    owner.id === 8 ? 'owner_abysswolf' :
    owner.id === 9 ? 'owner_kohan' :
    owner.id === 10 ? 'owner_luigi' :
    undefined
  );

  const [hoverGlarePos, setHoverGlarePos] = useState({ x: 50, y: 30 });
  const [isHovered, setIsHovered] = useState(false);
  const prefersReducedMotion = useRef(false);
  const lastTapRef = useRef<number>(0);
  const lastTouchTimeRef = useRef<number>(0);

  const handleCardInteraction = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button, a, input, select')) return;
    const now = Date.now();
    const timeDiff = now - lastTapRef.current;
    if (timeDiff < 400 && timeDiff > 40) {
      navigate(`/owner/${cardId}`);
      lastTapRef.current = 0;
    } else {
      lastTapRef.current = now;
    }
  };

  const handleCardDoubleClick = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button, a, input, select')) return;
    navigate(`/owner/${cardId}`);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if ((e.target as HTMLElement).closest('button, a, input, select')) return;
    const now = Date.now();
    const timeDiff = now - lastTouchTimeRef.current;
    if (timeDiff < 400 && timeDiff > 40) {
      navigate(`/owner/${cardId}`);
      lastTouchTimeRef.current = 0;
    } else {
      lastTouchTimeRef.current = now;
    }
  };

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
      prefersReducedMotion.current = mq.matches;
      const onChange = (e: MediaQueryListEvent) => {
        prefersReducedMotion.current = e.matches;
      };
      mq.addEventListener('change', onChange);
      return () => mq.removeEventListener('change', onChange);
    }
  }, []);

  // Real-time synced customization for this card
  const custom = getCustomization(cardId, fallbackCardId);

  // If card is marked as removed, don't display it
  if (custom?.removed) {
    return null;
  }

  const isPresent = (custom?.status || owner.status) === 'present';
  const customAccentKey = custom?.accentColor || (
    owner.highlightType === 'romantic' ? 'rose' :
    owner.highlightType === 'warmth' ? 'amber' :
    owner.highlightType === 'guardian' ? 'emerald' :
    owner.highlightType === 'chronicle' ? 'orange' :
    owner.highlightType === 'code' ? 'purple' :
    owner.highlightType === 'vanguard' ? 'cyan' :
    'amber'
  );
  const customAccentObj = getAccentColor(customAccentKey);

  const isShado = (custom?.effect === 'romantic') || (!custom?.effect && owner.highlightType === 'romantic');
  const isKohan = owner.highlightType === 'warmth';
  const isSh3la = owner.highlightType === 'chronicle';

  const activeEffect = custom?.effect || (isShado ? 'romantic' : isSh3la ? 'fire' : 'none');
  const activeBorderStyle = custom?.borderStyle || 'glow';
  const glowIntensity = typeof custom?.glowIntensity === 'number' ? custom.glowIntensity : 0.5;

  // Real-time smooth scroll 3D tilt & dynamic lighten-up (operates in both directions: down and up/going back)
  const scrollTilt = useScroll3DTilt({
    cardRef,
    isAlternate,
    isHovered,
    hoverRotateX,
    hoverRotateY,
    maxTiltX: 2.8,
    maxTiltY: 1.8,
    accentColorHex: customAccentObj.hex || '#f59e0b',
    glowIntensity,
    enabled: true,
  });

  // Card Height Customization
  const cardHeightPreset = custom?.cardHeightPreset || 'standard';
  const customCardHeight = custom?.cardHeight;
  const minHeightClass = customCardHeight
    ? ''
    : cardHeightPreset === 'compact'
    ? 'min-h-[440px] sm:min-h-[460px]'
    : cardHeightPreset === 'tall'
    ? 'min-h-[580px] sm:min-h-[620px]'
    : cardHeightPreset === 'epic'
    ? 'min-h-[660px] sm:min-h-[700px]'
    : 'min-h-[460px] sm:min-h-[500px] md:min-h-[540px]';

  // Buttons Customization & Removal
  const hideAllButtons = custom?.hideAllButtons ?? false;
  const hideEditButton = hideAllButtons || (custom?.hideEditButton ?? false);
  const hideBadgeButton = hideAllButtons || (custom?.hideBadgeButton ?? false);
  const hideStatusBadge = hideAllButtons || (custom?.hideStatusBadge ?? false);

  // Base card styling with synchronized rich multi-stop face gradients & enriched 3D backlight auras
  const getCardThemeClasses = () => {
    const accentHex = customAccentObj.hex || '#f59e0b';
    
    // Custom face gradients tailored to accent color
    const faceGradients: Record<string, string> = {
      amber: 'bg-gradient-to-b from-[#1c1204]/95 via-slate-950/90 to-[#0e0801]/98',
      emerald: 'bg-gradient-to-b from-[#041a12]/95 via-slate-950/90 to-[#020d09]/98',
      rose: 'bg-gradient-to-b from-[#220713]/95 via-slate-950/90 to-[#120308]/98',
      cyan: 'bg-gradient-to-b from-[#051824]/95 via-slate-950/90 to-[#020c13]/98',
      purple: 'bg-gradient-to-b from-[#180927]/95 via-slate-950/90 to-[#0b0312]/98',
      amethyst: 'bg-gradient-to-b from-[#150a24]/95 via-slate-950/90 to-[#0b0314]/98',
      mint: 'bg-gradient-to-b from-[#041c19]/95 via-slate-950/90 to-[#020e0d]/98',
      platinum: 'bg-gradient-to-b from-[#161a22]/95 via-slate-950/90 to-[#0b0d12]/98',
      red: 'bg-gradient-to-b from-[#220707]/95 via-slate-950/90 to-[#120303]/98',
      orange: 'bg-gradient-to-b from-[#220c04]/95 via-slate-950/90 to-[#110502]/98',
      yellow: 'bg-gradient-to-b from-[#1e1704]/95 via-slate-950/90 to-[#0f0b01]/98',
      blue: 'bg-gradient-to-b from-[#061427]/95 via-slate-950/90 to-[#020a14]/98',
    };

    const cardBgClass = faceGradients[customAccentKey] || 'bg-gradient-to-b from-slate-900/95 via-slate-950/85 to-slate-950/98';

    return {
      cardBorder: activeBorderStyle === 'neon' 
        ? `${customAccentObj.borderClass} border-2`
        : activeBorderStyle === 'solid'
        ? 'border-white/15'
        : `${customAccentObj.borderClass} ${customAccentObj.hoverBorderClass}`,
      cardBg: cardBgClass,
      badgeColor: `${customAccentObj.badgeText} ${customAccentObj.badgeBg} ${customAccentObj.badgeBorder}`,
      accentColor: customAccentObj.textGradient,
      sealBorder: `${customAccentObj.badgeBorder} ${customAccentObj.badgeText}`,
      spineColor: `${customAccentObj.borderClass} bg-slate-950 ${customAccentObj.badgeText}`,
      glowBg: `${accentHex}40`,
      hex: accentHex,
    };
  };

  const theme = getCardThemeClasses();
  const displayNameText = custom?.displayName || custom?.name || (owner.nameKey.startsWith('owner.') ? t(owner.nameKey) : owner.nameKey);
  const descText = custom?.subtitle || (owner.descKey.startsWith('owner.') ? t(owner.descKey) : owner.descKey);
  const badgeText = custom?.badge || (owner.badgeKey.startsWith('owner.') ? t(owner.badgeKey) : owner.badgeKey);
  const countryVal = (custom?.country as any) || owner.country;
  
  // Latin number (Roman Numeral) for the owner (I, II, III, IV, V, VI, VII, VIII, IX, X, XI, XII...)
  const romanNumeralSafe = (owner.romanNumeral && owner.romanNumeral !== 'OWNER' && /^[IVXLCDM]+$/i.test(owner.romanNumeral))
    ? owner.romanNumeral.toUpperCase()
    : toRomanNumeral(index + 1);

  // Interactive mouse tracking when hovering
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (prefersReducedMotion.current || !cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rX = ((y - centerY) / centerY) * -2.4;
    const rY = ((x - centerX) / centerX) * 2.4;

    setHoverRotateX(rX);
    setHoverRotateY(rY);
    setHoverGlarePos({
      x: Math.round((x / rect.width) * 100),
      y: Math.round((y / rect.height) * 100)
    });
  };

  const handleMouseEnter = () => {
    if (prefersReducedMotion.current) return;
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setHoverRotateX(0);
    setHoverRotateY(0);
    setHoverGlarePos({ x: 50, y: 30 });
  };

  // Dynamic Box Shadow responding to custom glowIntensity and hover state
  const dynamicBoxShadow = isHovered
    ? `0 30px 70px rgba(0,0,0,0.92), 0 0 ${Math.round(24 + glowIntensity * 50)}px ${theme.hex}${Math.round(glowIntensity * 140).toString(16).padStart(2, '0')}, inset 0 1px 1px rgba(255,255,255,0.2)`
    : scrollTilt.boxShadowStyle;

  // Tall/Long Card Content Component
  const renderCardContent = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.5, delay: Math.min(index * 0.04, 0.2) }}
      className={`w-full relative z-10 ${
        isAlternate ? 'md:ps-8 lg:ps-12' : 'md:pe-8 lg:pe-12'
      } group owner-card-3d-stage gpu-60fps`}
    >
      {/* Mobile Latin Number Counter positioned on the side timeline line */}
      <div 
        className={`md:hidden absolute -start-10 top-8 w-8 h-8 rounded-xl border-2 flex items-center justify-center z-20 text-[11px] font-serif font-black shadow-lg backdrop-blur-md ${theme.spineColor}`}
      >
        <span className="text-transparent bg-clip-text bg-gradient-to-b from-white to-amber-200">
          {romanNumeralSafe}
        </span>
      </div>

      {/* Quick Card Sequence Controls (Move Up/Down in the line, Delete) */}
      {showControls && (
        <div className={`mb-3 flex items-center justify-between w-full max-w-sm px-2 text-[11px] font-mono text-slate-400 ${
          isAlternate ? 'md:ms-0' : 'md:ms-auto'
        }`}>
          <span className="text-amber-400 font-bold flex items-center gap-1.5 bg-black/70 px-2.5 py-0.5 rounded-lg border border-amber-500/30 backdrop-blur-md shadow-xs">
            <span>№</span>
            <span>{romanNumeralSafe}</span>
          </span>
          <div className="flex items-center gap-1.5 bg-black/80 p-1 rounded-xl border border-white/10 backdrop-blur-md shadow-md">
            <button
              type="button"
              disabled={isFirst}
              onClick={(e) => {
                e.stopPropagation();
                onMoveUp?.();
              }}
              title={isAr ? 'تقديم الترتيب للأعلى' : 'Move Up in Line'}
              className="w-6 h-6 rounded-lg bg-slate-900 hover:bg-amber-950 border border-slate-700 hover:border-amber-400 text-slate-300 hover:text-amber-300 disabled:opacity-20 flex items-center justify-center transition-all cursor-pointer disabled:cursor-not-allowed shadow-xs"
            >
              <ArrowUp size={12} />
            </button>
            <button
              type="button"
              disabled={isLast}
              onClick={(e) => {
                e.stopPropagation();
                onMoveDown?.();
              }}
              title={isAr ? 'تأخير الترتيب للأسفل' : 'Move Down in Line'}
              className="w-6 h-6 rounded-lg bg-slate-900 hover:bg-amber-950 border border-slate-700 hover:border-amber-400 text-slate-300 hover:text-amber-300 disabled:opacity-20 flex items-center justify-center transition-all cursor-pointer disabled:cursor-not-allowed shadow-xs"
            >
              <ArrowDown size={12} />
            </button>
            {(owner.isCustom || cardId.startsWith('custom_')) && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete?.();
                }}
                title={isAr ? 'حذف هذه البطاقة' : 'Delete this card'}
                className="w-6 h-6 rounded-lg bg-rose-950 hover:bg-rose-900 border border-rose-600/50 hover:border-rose-400 text-rose-300 flex items-center justify-center transition-all cursor-pointer shadow-xs ms-0.5"
              >
                <Trash2 size={12} />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Card Main Body - Well-Proportioned Portrait Canvas with Multi-stop Face Gradients */}
      <div
        ref={cardRef}
        role="button"
        tabIndex={0}
        onClick={handleCardInteraction}
        onDoubleClick={handleCardDoubleClick}
        onTouchEnd={handleTouchEnd}
        title={isAr ? 'انقر مرتين (Double Tap) لفتح الملف التعريفي للمالك' : 'Double tap to open Owner Profile'}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            navigate(`/owner/${cardId}`);
          }
        }}
        onMouseMove={handleMouseMove}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        style={{
          transform: isHovered
            ? (prefersReducedMotion.current ? 'none' : `perspective(1200px) rotateX(${hoverRotateX}deg) rotateY(${hoverRotateY}deg) translateY(-4px) scale3d(1.01, 1.01, 1.01)`)
            : scrollTilt.transform,
          transformStyle: 'preserve-3d',
          boxShadow: dynamicBoxShadow,
          filter: isHovered ? 'brightness(1.12) contrast(1.02)' : scrollTilt.filterStyle,
          height: customCardHeight ? `${customCardHeight}px` : undefined,
          transition: isHovered ? 'box-shadow 0.2s ease, filter 0.2s ease' : 'box-shadow 0.35s ease, filter 0.35s ease',
        }}
        className={`relative ${minHeightClass} flex flex-col justify-between border rounded-[2rem] sm:rounded-[2.2rem] overflow-hidden backdrop-blur-md owner-card-depth-surface ${theme.cardBorder} ${theme.cardBg} gpu-60fps cursor-pointer group/card`}
      >
        {/* Custom Owner Card Visual Effect Layer */}
        <OwnerCardEffectLayer
          effect={activeEffect}
          accentColor={customAccentKey}
          glowIntensity={glowIntensity}
          borderStyle={activeBorderStyle}
        />

        {/* Custom Owner Card Background Photo Layer (The character behind image shines through here) */}
        <OwnerCardBackgroundLayer
          cardId={cardId}
          fallbackCardId={fallbackCardId}
          ownerName={displayNameText}
          displayName={custom?.displayName}
          roleTitle={custom?.roleTitle}
          subtitle={custom?.subtitle}
          badge={custom?.badge}
          country={countryVal}
          status={custom?.status || owner.status}
          defaultAccent={customAccentKey}
          order={custom?.order}
          showEditButton={!hideEditButton}
          buttonPosition="top-right"
        />

        {/* Premium Metallic Bevel Top Hairline Highlight (Lightens up on scroll / hover) */}
        <div 
          className="absolute top-0 inset-x-0 h-[2px] pointer-events-none z-20 transition-all duration-300"
          style={{
            background: (scrollTilt.isIlluminated || isHovered)
              ? 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.8) 50%, transparent 100%)'
              : 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.35) 50%, transparent 100%)',
            boxShadow: (scrollTilt.isIlluminated || isHovered)
              ? `0 0 12px rgba(255,255,255,0.6)`
              : 'none',
          }}
          aria-hidden="true"
        />

        {/* Dynamic Light Sweep Layer (Subtly brightens card face as you scroll down or back up) */}
        <div
          className="absolute inset-0 pointer-events-none rounded-[inherit] transition-opacity duration-300 z-15 overflow-hidden"
          style={{
            opacity: isHovered ? 0.35 : scrollTilt.lightenProgress * 0.42,
          }}
          aria-hidden="true"
        >
          <div
            className="absolute -inset-full bg-gradient-to-tr from-transparent via-white/12 to-transparent pointer-events-none"
            style={{
              transform: `translateY(${(50 - scrollTilt.glarePos.y) * 1.5}%) rotate(-25deg)`,
              transition: 'transform 0.15s ease-out',
            }}
          />
        </div>

        {/* Accent Color Ambient Top Sheen */}
        <div 
          className="absolute top-0 inset-x-0 h-28 bg-gradient-to-b from-white/[0.06] via-white/[0.01] to-transparent pointer-events-none z-10"
          aria-hidden="true"
        />

        {/* Interactive Specular Glare Layer (Responds smoothly to cursor position and scroll movement) */}
        <div 
          className="absolute inset-0 pointer-events-none rounded-[inherit] transition-opacity duration-300 z-10"
          style={{
            opacity: isHovered && !prefersReducedMotion.current ? 0.12 : scrollTilt.glareOpacity,
            background: `radial-gradient(circle 460px at ${isHovered ? hoverGlarePos.x : scrollTilt.glarePos.x}% ${isHovered ? hoverGlarePos.y : scrollTilt.glarePos.y}%, rgba(255,255,255,0.95), transparent 70%)`,
          }}
          aria-hidden="true"
        />

        {/* ============================================================ */}
        {/* 1. TOP HEADER: Status, Country Flag, Latin Epoch Pill       */}
        {/* ============================================================ */}
        <div 
          className="relative z-20 p-4 sm:p-5 pb-1 bg-gradient-to-b from-slate-950/85 via-slate-950/40 to-transparent flex items-center justify-between gap-3 flex-wrap"
          style={{
            transform: isHovered && !prefersReducedMotion.current ? 'translateZ(16px)' : 'translateZ(8px)',
            transition: 'transform 0.35s ease-out',
          }}
        >
          {/* Status Indicator (unless removed by customization) */}
          <div className="flex items-center gap-2">
            {!hideStatusBadge && (
              isPresent ? (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] sm:text-[11px] font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 shadow-[0_0_12px_rgba(16,185,129,0.25)] backdrop-blur-md">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400" />
                  </span>
                  <span>{t('history.status.present')}</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] sm:text-[11px] font-medium bg-slate-900/80 text-slate-400 border border-slate-700/50 shadow-xs backdrop-blur-md">
                  <Clock size={11} className="text-slate-400 shrink-0" />
                  <span>{t('history.status.former')}</span>
                </span>
              )
            )}

            {/* Country decoration if present */}
            {countryVal && (
              <CountryFlag
                country={countryVal}
                name={t(`country.${countryVal}`)}
              />
            )}
          </div>

          {/* Epoch Latin Numeral Pill */}
          <span className="font-serif text-[11px] font-bold tracking-widest text-archive-paper-muted/80 uppercase px-2 py-0.5 rounded-lg bg-black/40 border border-white/[0.08] backdrop-blur-md shadow-xs">
            {romanNumeralSafe}
          </span>
        </div>

        {/* ============================================================ */}
        {/* 2. BALANCED MIDDLE VIEWPORT: Clean open background image view*/}
        {/* ============================================================ */}
        <div className="relative z-10 flex-1 flex flex-col p-3 min-h-[220px] sm:min-h-[260px] md:min-h-[290px] overflow-hidden justify-center items-center">
          {/* Ambient Soft Backlight Aura (matching owner accent color with breathing emergence & scroll lighten bloom) */}
          <motion.div 
            animate={{
              opacity: isHovered 
                ? [0.65, 0.95, 0.65] 
                : [Math.min(0.9, scrollTilt.auraOpacity * 0.85), Math.min(1.0, scrollTilt.auraOpacity * 1.15), Math.min(0.9, scrollTilt.auraOpacity * 0.85)],
              scale: isHovered 
                ? [1.1, 1.25, 1.1] 
                : [scrollTilt.auraScale * 0.96, scrollTilt.auraScale * 1.08, scrollTilt.auraScale * 0.96],
            }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: 'easeInOut'
            }}
            className="absolute inset-0 w-48 h-48 md:w-56 md:h-56 m-auto rounded-full blur-3xl pointer-events-none transition-all duration-300"
            style={{
              background: theme.glowBg,
            }}
            aria-hidden="true"
          />

          {/* Clean open viewport: ONLY Background image is displayed (no character above) */}
          <div className="flex-1 w-full" />
        </div>

        {/* ============================================================ */}
        {/* 3. BOTTOM CARD FACE: Name, Bio, and Badge with Scrim Gradients*/}
        {/* ============================================================ */}
        <div 
          className="relative z-20 pt-6 pb-5 px-5 sm:px-6 bg-gradient-to-t from-slate-950 via-slate-950/92 to-transparent border-t border-white/[0.04] backdrop-blur-[2px]"
          style={{
            transform: isHovered && !prefersReducedMotion.current ? 'translateZ(18px)' : 'translateZ(10px)',
            transition: 'transform 0.35s ease-out',
          }}
        >
          {/* Owner Name */}
          <div className="text-center mb-1.5">
            <h3 className={`font-display font-extrabold text-xl sm:text-2xl text-transparent bg-clip-text bg-gradient-to-r ${theme.accentColor} tracking-wide break-words max-w-full leading-snug drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)]`}>
              {displayNameText}
            </h3>
          </div>

          {/* Clean Subtle Hairline Divider (No middle icon) */}
          <div 
            className="my-2 mx-auto w-2/3 h-[1px] bg-gradient-to-r from-transparent via-archive-cyan/30 to-transparent pointer-events-none opacity-60"
          />

          {/* Short Narrative Information */}
          <p className="font-sans text-center text-archive-paper-muted leading-relaxed font-normal text-xs sm:text-[13px] mb-3 px-1 drop-shadow-sm line-clamp-2">
            {descText}
          </p>

          {/* Bottom Story Visual Footprint & Latin Numeral */}
          <div className="pt-2 border-t border-white/[0.08] flex items-center justify-between text-xs text-archive-paper-muted/80">
            {!hideBadgeButton && (
              isKohan && isAuthenticated ? (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsKohanGameOpen(true);
                  }}
                  className="font-mono text-[10px] tracking-wider text-amber-300 hover:text-amber-100 bg-amber-950/50 hover:bg-amber-900/70 border border-amber-500/35 px-2 py-0.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer group/star shadow-xs active:scale-95"
                  title={isRtl ? 'لعبة سرية' : 'Secret Game'}
                  aria-label="Secret Game"
                >
                  <Sparkles size={10} className="shrink-0 text-amber-400 group-hover/star:rotate-45 transition-transform" />
                  <span>{badgeText}</span>
                </button>
              ) : (
                <span className="font-mono text-[10px] tracking-wider text-archive-cyan/90 flex items-center gap-1.5">
                  <Sparkles size={10} className="shrink-0" />
                  <span>{badgeText}</span>
                </span>
              )
            )}

            {/* Ancient Roman Numeral Watermark & View Profile Action */}
            <div className="flex items-center gap-2.5 ms-auto">
              <span className="font-mono text-[10px] text-cyan-300/80 group-hover/card:text-cyan-200 flex items-center gap-1 transition-colors">
                <span>{isAr ? 'الملف الشخصي' : 'Profile'}</span>
                <ArrowUpRight size={11} className="text-cyan-400 group-hover/card:translate-x-0.5 group-hover/card:-translate-y-0.5 transition-transform" />
              </span>
              <span className="font-serif font-bold text-sm sm:text-base text-archive-paper/20 select-none pointer-events-none tracking-widest">
                {romanNumeralSafe}
              </span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );

  return (
    <div className="w-full md:grid md:grid-cols-2 md:gap-x-20 lg:gap-x-28 items-center mb-14 md:mb-20 relative">
      {/* ============================================================ */}
      {/* Central Latin Number Medallion & Energy Connector (I, II, III...) */}
      {/* ============================================================ */}
      
      {/* Horizontal glowing connector bridge from center line to card */}
      <div 
        className={`hidden md:block absolute top-20 md:top-24 h-[2px] pointer-events-none z-10 transition-all duration-300 ${
          isAlternate 
            ? 'left-1/2 w-16 lg:w-24 bg-gradient-to-r from-archive-cyan/70 to-transparent' 
            : 'right-1/2 w-16 lg:w-24 bg-gradient-to-l from-archive-cyan/70 to-transparent'
        } ${isHovered ? 'opacity-100 shadow-[0_0_12px_#06b6d4]' : 'opacity-40'}`}
      />

      {/* Central Latin Number Medallion on the Timeline Spine Line */}
      <div 
        className={`hidden md:flex absolute left-1/2 -translate-x-1/2 top-20 md:top-24 w-11 h-11 md:w-12 md:h-12 rounded-2xl border-2 items-center justify-center z-20 transition-all duration-300 shadow-xl backdrop-blur-md ${theme.spineColor} ${
          isHovered ? 'scale-110 shadow-[0_0_24px_rgba(6,182,212,0.7)] ring-4 ring-cyan-400/20' : ''
        }`}
        title={`Owner ${romanNumeralSafe}`}
      >
        <span className="font-serif font-black text-xs md:text-sm tracking-widest select-none text-transparent bg-clip-text bg-gradient-to-b from-white via-slate-100 to-amber-200 drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)]">
          {romanNumeralSafe}
        </span>
      </div>

      {isAlternate ? (
        <>
          {/* Empty spacer column on desktop keeping card away from center line */}
          <div className="hidden md:block" />
          {renderCardContent()}
        </>
      ) : (
        <>
          {renderCardContent()}
          {/* Empty spacer column on desktop keeping card away from center line */}
          <div className="hidden md:block" />
        </>
      )}
    </div>
  );
};

