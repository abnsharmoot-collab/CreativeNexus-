import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../../context/LanguageContext';
import { useOwnerCardBackgrounds } from '../../context/OwnerCardBackgroundsContext';
import { OwnerTimelineCard, OwnerData } from './OwnerTimelineCard';
import { 
  Crown, 
  Sparkles, 
  Filter, 
  Shield, 
  Heart, 
  Search, 
  X,
  PlusCircle,
  ArrowUpDown,
  SlidersHorizontal,
  Check,
  ArrowUp,
  ArrowDown,
  ChevronsUp,
  ChevronsDown,
  Trash2
} from 'lucide-react';

export function toRomanNumeral(num: number): string {
  if (num <= 0) return 'I';
  const romanMap: [number, string][] = [
    [1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'],
    [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'],
    [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']
  ];
  let result = '';
  let n = num;
  for (const [val, sym] of romanMap) {
    while (n >= val) {
      result += sym;
      n -= val;
    }
  }
  return result || String(num);
}

const OWNERS_DATA: OwnerData[] = [
  {
    id: 1,
    romanNumeral: 'I',
    nameKey: 'owner.1.name',
    titleKey: 'owner.1.title',
    descKey: 'owner.1.desc',
    badgeKey: 'owner.1.badge',
    status: 'former',
    highlightType: 'standard',
  },
  {
    id: 2,
    romanNumeral: 'II',
    nameKey: 'owner.2.name',
    titleKey: 'owner.2.title',
    descKey: 'owner.2.desc',
    badgeKey: 'owner.2.badge',
    status: 'former',
    highlightType: 'chronicle',
  },
  {
    id: 3,
    romanNumeral: 'III',
    nameKey: 'owner.hamo.name',
    titleKey: 'owner.hamo.title',
    descKey: 'owner.hamo.desc',
    badgeKey: 'owner.hamo.badge',
    status: 'former',
    highlightType: 'code',
  },
  {
    id: 4,
    romanNumeral: 'IV',
    nameKey: 'owner.super.name',
    titleKey: 'owner.super.title',
    descKey: 'owner.super.desc',
    badgeKey: 'owner.super.badge',
    status: 'former',
    highlightType: 'youth',
  },
  {
    id: 5,
    romanNumeral: 'V',
    nameKey: 'owner.osama.name',
    titleKey: 'owner.osama.title',
    descKey: 'owner.osama.desc',
    badgeKey: 'owner.osama.badge',
    status: 'former',
    highlightType: 'voyager',
  },
  {
    id: 6,
    romanNumeral: 'VI',
    nameKey: 'owner.adham.name',
    titleKey: 'owner.adham.title',
    descKey: 'owner.adham.desc',
    badgeKey: 'owner.adham.badge',
    status: 'former',
    highlightType: 'vanguard',
  },
  {
    id: 7,
    romanNumeral: 'VII',
    nameKey: 'owner.shadow.name',
    titleKey: 'owner.shadow.title',
    descKey: 'owner.shadow.desc',
    badgeKey: 'owner.shadow.badge',
    status: 'present',
    highlightType: 'romantic',
  },
  {
    id: 8,
    romanNumeral: 'VIII',
    nameKey: 'owner.abysswolf.name',
    titleKey: 'owner.abysswolf.title',
    descKey: 'owner.abysswolf.desc',
    badgeKey: 'owner.abysswolf.badge',
    status: 'present',
    country: 'uae',
    highlightType: 'guardian',
  },
  {
    id: 9,
    romanNumeral: 'IX',
    nameKey: 'owner.kohan.name',
    titleKey: 'owner.kohan.title',
    descKey: 'owner.kohan.desc',
    badgeKey: 'owner.kohan.badge',
    status: 'present',
    country: 'iraq',
    highlightType: 'warmth',
  },
  {
    id: 10,
    romanNumeral: 'X',
    nameKey: 'owner.luigi.name',
    titleKey: 'owner.luigi.title',
    descKey: 'owner.luigi.desc',
    badgeKey: 'owner.luigi.badge',
    status: 'present',
    highlightType: 'vanguard',
  },
];

export const OwnersTimeline: React.FC = () => {
  const { t, language } = useLanguage();
  const isRtl = language === 'ar';
  const [activeFilter, setActiveFilter] = useState<'all' | 'present' | 'former'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isReorderMode, setIsReorderMode] = useState<boolean>(false);
  const [isReorderModalOpen, setIsReorderModalOpen] = useState<boolean>(false);

  const { 
    backgrounds, 
    getCustomization, 
    reorderCards, 
    deleteCard, 
    openCreateCardModal 
  } = useOwnerCardBackgrounds();

  // Combine base OWNERS_DATA with custom added owner cards, filtering out removed cards and sorting by order
  const allOwners = useMemo(() => {
    const list: OwnerData[] = [];

    OWNERS_DATA.forEach((o, idx) => {
      const cardId = `history_owner_${o.id}`;
      const fallbackId =
        o.id === 7 ? 'owner_shadow' :
        o.id === 8 ? 'owner_abysswolf' :
        o.id === 9 ? 'owner_kohan' :
        o.id === 10 ? 'owner_luigi' :
        undefined;

      const custom = getCustomization(cardId, fallbackId);
      if (custom?.removed) return; // Filter out removed cards

      list.push({
        ...o,
        cardId,
        fallbackCardId: fallbackId,
        displayName: custom?.displayName,
        status: (custom?.status || o.status) as 'present' | 'former',
        country: (custom?.country as any) || o.country,
        order: typeof custom?.order === 'number' ? custom.order : (idx + 1),
        isCustom: false
      });
    });

    // Also include custom created cards
    Object.entries(backgrounds).forEach(([cId, rawData], idx) => {
      const cData = rawData as any;
      if (cId.startsWith('history_owner_') || cId.startsWith('owner_')) {
        return;
      }
      if (cData?.isCustom && !cData?.removed) {
        list.push({
          id: cId,
          cardId: cId,
          romanNumeral: toRomanNumeral(10 + idx + 1),
          nameKey: cData.displayName || cData.name || 'Leader',
          displayName: cData.displayName || cData.name,
          titleKey: cData.roleTitle || 'Server Owner',
          descKey: cData.subtitle || '',
          badgeKey: cData.badge || 'Leader',
          status: (cData.status || 'present') as 'present' | 'former',
          country: cData.country as any,
          highlightType: 'standard',
          order: typeof cData.order === 'number' ? cData.order : (100 + idx),
          isCustom: true
        });
      }
    });

    // Sort deterministically by order ascending
    return list.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  }, [backgrounds, getCustomization]);

  // Handle reordering: move card up or down
  const handleMove = async (currentIndex: number, direction: -1 | 1) => {
    const targetIndex = currentIndex + direction;
    if (targetIndex < 0 || targetIndex >= allOwners.length) return;

    const newOwners = [...allOwners];
    const [moved] = newOwners.splice(currentIndex, 1);
    newOwners.splice(targetIndex, 0, moved);

    const payload = newOwners.map((item, idx) => ({
      cardId: item.cardId || `history_owner_${item.id}`,
      order: idx + 1
    }));

    await reorderCards(payload);
  };

  // Move to extreme top or extreme bottom
  const handleMoveToExtremity = async (currentIndex: number, toTop: boolean) => {
    if (currentIndex < 0 || currentIndex >= allOwners.length) return;
    const newOwners = [...allOwners];
    const [moved] = newOwners.splice(currentIndex, 1);
    if (toTop) {
      newOwners.unshift(moved);
    } else {
      newOwners.push(moved);
    }

    const payload = newOwners.map((item, idx) => ({
      cardId: item.cardId || `history_owner_${item.id}`,
      order: idx + 1
    }));

    await reorderCards(payload);
  };

  // Delete custom card
  const handleDeleteCard = async (cardId: string) => {
    if (window.confirm(isRtl ? 'هل أنت متأكد من حذف هذه البطاقة من الخط الزمني؟' : 'Are you sure you want to remove this card from the timeline?')) {
      await deleteCard(cardId);
    }
  };

  const filteredOwners = useMemo(() => {
    let list = allOwners;
    if (activeFilter === 'present') {
      list = list.filter((o) => o.status === 'present');
    } else if (activeFilter === 'former') {
      list = list.filter((o) => o.status === 'former');
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter((o) => {
        const custom = getCustomization(
          o.cardId || `history_owner_${o.id}`,
          o.fallbackCardId
        );
        const name = (custom?.displayName || custom?.name || (o.nameKey.startsWith('owner.') ? t(o.nameKey) : o.nameKey)).toLowerCase();
        const title = (custom?.roleTitle || (o.titleKey.startsWith('owner.') ? t(o.titleKey) : o.titleKey)).toLowerCase();
        const desc = (custom?.subtitle || (o.descKey.startsWith('owner.') ? t(o.descKey) : o.descKey)).toLowerCase();
        const badge = (custom?.badge || (o.badgeKey.startsWith('owner.') ? t(o.badgeKey) : o.badgeKey)).toLowerCase();
        const country = (custom?.country ? t(`country.${custom.country}`) : (o.country ? t(`country.${o.country}`) : '')).toLowerCase();

        return (
          name.includes(q) ||
          title.includes(q) ||
          desc.includes(q) ||
          badge.includes(q) ||
          country.includes(q) ||
          o.romanNumeral.toLowerCase().includes(q)
        );
      });
    }

    return list;
  }, [allOwners, activeFilter, searchQuery, t, getCustomization]);

  return (
    <div className="relative py-10 md:py-14 overflow-hidden">
      {/* Cinematic Ambient Glow */}
      <div className="absolute top-1/3 start-1/2 -translate-x-1/2 rtl:translate-x-1/2 w-[850px] h-[550px] bg-gradient-to-tr from-archive-cyan/15 via-archive-teal-light/20 to-transparent rounded-full blur-[140px] pointer-events-none -z-10" />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Sub-Header & Controls */}
        <div className="text-center max-w-3xl mx-auto mb-10 md:mb-12">
          
          {/* ============================================================ */}
          {/* ACTION BUTTONS: Add Card into Line & Change Place of Cards  */}
          {/* ============================================================ */}
          <div className="flex flex-wrap items-center justify-center gap-3 max-w-2xl mx-auto mb-6">
            {/* 1. Add Card into Line Button */}
            <button
              type="button"
              onClick={() => openCreateCardModal()}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-500 to-cyan-500 hover:from-emerald-500 hover:via-teal-400 hover:to-cyan-400 text-slate-950 font-cairo font-bold text-xs sm:text-sm flex items-center gap-2 shadow-[0_0_20px_rgba(45,212,191,0.4)] hover:shadow-[0_0_25px_rgba(45,212,191,0.6)] active:scale-95 transition-all cursor-pointer border border-teal-300/40"
              title={isRtl ? 'إضافة بطاقة مالك جديدة إلى الخط الزمني' : 'Add New Owner Card into the Line'}
            >
              <PlusCircle size={16} className="text-slate-950 shrink-0" />
              <span>{isRtl ? 'إضافة بطاقة إلى الخط الزمني' : 'Add Card into Line'}</span>
            </button>

            {/* 2. Change Place of Cards Modal Button */}
            <button
              type="button"
              onClick={() => setIsReorderModalOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500/20 via-yellow-500/15 to-orange-500/20 hover:from-amber-500/30 hover:via-yellow-500/25 hover:to-orange-500/30 text-amber-200 hover:text-white font-cairo font-bold text-xs sm:text-sm flex items-center gap-2 border border-amber-400/40 hover:border-amber-300/70 shadow-[0_0_15px_rgba(245,158,11,0.2)] active:scale-95 transition-all cursor-pointer backdrop-blur-md"
              title={isRtl ? 'تغيير وترتيب أماكن البطاقات في الخط' : 'Change Place & Order of Cards'}
            >
              <ArrowUpDown size={16} className="text-amber-300 shrink-0" />
              <span>{isRtl ? 'تغيير مكان وترتيب البطاقات' : 'Change Place of Cards'}</span>
            </button>

            {/* 3. Inline Quick Move Toggle */}
            <button
              type="button"
              onClick={() => {
                setIsReorderMode(prev => !prev);
              }}
              className={`px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-cairo font-semibold flex items-center gap-2 border transition-all cursor-pointer ${
                isReorderMode
                  ? 'bg-cyan-500 text-slate-950 border-cyan-300 font-bold shadow-[0_0_20px_rgba(6,182,212,0.5)]'
                  : 'bg-archive-card/90 text-slate-300 hover:text-white border-archive-cyan/25 hover:border-archive-cyan/50'
              }`}
              title={isRtl ? 'إظهار أزرار التقديم والتأخير فوق كل بطاقة في الخط' : 'Toggle inline move up/down controls on cards'}
            >
              {isReorderMode ? <Check size={15} /> : <SlidersHorizontal size={15} />}
              <span>
                {isReorderMode 
                  ? (isRtl ? 'إخفاء أزرار التحريك' : 'Hide Move Controls') 
                  : (isRtl ? 'أزرار التحريك السريع (↑ ↓)' : 'Inline Move Controls (↑ ↓)')
                }
              </span>
            </button>
          </div>

          {/* Reorder Mode Active Banner */}
          <AnimatePresence>
            {isReorderMode && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mb-6 p-3 rounded-2xl bg-cyan-950/70 border border-cyan-400/40 text-cyan-200 text-xs font-cairo flex items-center justify-between gap-3 max-w-xl mx-auto shadow-lg backdrop-blur-md"
              >
                <div className="flex items-center gap-2">
                  <Sparkles size={16} className="text-cyan-400 shrink-0" />
                  <span>
                    {isRtl 
                      ? 'وضع تحريك البطاقات نشط: استخدم أزرار (↑) و (↓) فوق كل بطاقة لتغيير مكانها في الخط الزمني!' 
                      : 'Card reordering active: Use (↑) and (↓) buttons above each card to change its position in the line!'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsReorderMode(false)}
                  className="px-2.5 py-1 rounded-lg bg-cyan-500 text-slate-950 font-bold hover:bg-cyan-400 text-xs cursor-pointer shrink-0 transition-all"
                >
                  {isRtl ? 'تم' : 'Done'}
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Search & Filter Controls */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-xl mx-auto mb-8">
            {/* Search Input */}
            <div className="relative w-full sm:w-72">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('history.search.placeholder')}
                className="w-full ps-10 pe-9 py-2 rounded-xl bg-archive-card/90 border border-archive-cyan/20 focus:border-archive-cyan text-xs font-sans text-archive-paper placeholder-archive-paper-muted/50 outline-hidden transition-all shadow-inner"
              />
              <Search size={14} className="absolute start-3.5 top-1/2 -translate-y-1/2 text-archive-cyan/60" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute end-3 top-1/2 -translate-y-1/2 text-archive-paper-muted hover:text-white"
                >
                  <X size={13} />
                </button>
              )}
            </div>

            {/* Filter Pills */}
            <div className="inline-flex items-center p-1 rounded-xl bg-archive-card/90 border border-archive-cyan/20 backdrop-blur-xl shadow-lg shadow-black/40">
              <button
                onClick={() => setActiveFilter('all')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all duration-300 cursor-pointer ${
                  activeFilter === 'all'
                    ? 'bg-archive-cyan text-archive-dark shadow-[0_0_15px_rgba(6,182,212,0.5)] font-semibold'
                    : 'text-archive-paper-muted hover:text-archive-paper'
                }`}
              >
                {t('history.owners.filter.all')} ({allOwners.length})
              </button>
              <button
                onClick={() => setActiveFilter('present')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all duration-300 flex items-center gap-1.5 cursor-pointer ${
                  activeFilter === 'present'
                    ? 'bg-emerald-500 text-archive-dark shadow-[0_0_15px_rgba(16,185,129,0.5)] font-semibold'
                    : 'text-archive-paper-muted hover:text-emerald-400'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                {t('history.owners.filter.present')} ({allOwners.filter(o => o.status === 'present').length})
              </button>
              <button
                onClick={() => setActiveFilter('former')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all duration-300 cursor-pointer ${
                  activeFilter === 'former'
                    ? 'bg-slate-700 text-archive-paper shadow-md font-semibold'
                    : 'text-archive-paper-muted hover:text-slate-300'
                }`}
              >
                {t('history.owners.filter.former')} ({allOwners.filter(o => o.status === 'former').length})
              </button>
            </div>
          </div>
        </div>

        {/* The Vertical Chronological Timeline */}
        <div className="relative">
          {/* Main Central Energy Spine (Desktop) - Safely in background (z-0) and perfectly centered */}
          <div className="hidden md:block absolute left-1/2 top-0 -translate-x-1/2 w-[2px] h-full bg-gradient-to-b from-archive-cyan/5 via-archive-cyan/35 to-archive-cyan/5 pointer-events-none z-0">
            {/* Animated glowing pulse down the spine */}
            <motion.div
              animate={{ y: ['0%', '100%'] }}
              transition={{ duration: 6, repeat: Infinity, ease: 'linear' }}
              className="w-full h-32 bg-gradient-to-b from-transparent via-archive-cyan to-transparent shadow-[0_0_12px_rgba(6,182,212,0.8)] pointer-events-none"
            />
          </div>

          {/* Main Side Spine (Mobile) */}
          <div className="md:hidden absolute start-2 top-0 w-[2px] h-full bg-gradient-to-b from-archive-cyan/5 via-archive-cyan/35 to-archive-cyan/5 pointer-events-none z-0">
            <motion.div
              animate={{ y: ['0%', '100%'] }}
              transition={{ duration: 6, repeat: Infinity, ease: 'linear' }}
              className="w-full h-24 bg-gradient-to-b from-transparent via-archive-cyan to-transparent shadow-[0_0_10px_rgba(6,182,212,0.8)] pointer-events-none"
            />
          </div>

          {/* Cards List or Empty Search State */}
          <div className="ps-8 md:ps-0">
            {filteredOwners.length === 0 ? (
              <div className="py-16 text-center">
                <p className="font-sans text-sm text-archive-paper-muted">
                  {t('history.search.noResults')}
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setActiveFilter('all');
                  }}
                  className="mt-4 px-4 py-1.5 text-xs rounded-lg bg-archive-teal-light/30 border border-archive-cyan/30 text-archive-cyan hover:bg-archive-teal-light/50 transition-all cursor-pointer"
                >
                  Reset Filters
                </button>
              </div>
            ) : (
              <AnimatePresence>
                {filteredOwners.map((owner, index) => {
                  const safeNumeral = toRomanNumeral(index + 1);
                  const originalIndex = allOwners.findIndex(
                    o => (o.cardId || `history_owner_${o.id}`) === (owner.cardId || `history_owner_${owner.id}`)
                  );

                  return (
                    <OwnerTimelineCard
                      key={owner.cardId || owner.id}
                      owner={{ ...owner, romanNumeral: safeNumeral }}
                      index={index}
                      isAlternate={index % 2 !== 0}
                      showControls={isReorderMode}
                      isFirst={originalIndex <= 0}
                      isLast={originalIndex >= allOwners.length - 1}
                      onMoveUp={() => handleMove(originalIndex, -1)}
                      onMoveDown={() => handleMove(originalIndex, 1)}
                      onDelete={() => handleDeleteCard(owner.cardId || `history_owner_${owner.id}`)}
                    />
                  );
                })}
              </AnimatePresence>
            )}
          </div>
        </div>

        {/* Archival Closing Seal */}
        <div className="mt-12 text-center flex flex-col items-center">
          <div className="inline-flex items-center gap-3 text-xs font-mono tracking-widest text-archive-cyan/60 uppercase">
            <span className="w-10 h-[1px] bg-archive-cyan/30" />
            <span>CREATIVE NEXUS ARCHIVE VAULT</span>
            <span className="w-10 h-[1px] bg-archive-cyan/30" />
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* REORDER CARDS MODAL (Change Place of Cards in the Area)       */}
      {/* ============================================================ */}
      <AnimatePresence>
        {isReorderModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="w-full max-w-2xl bg-gradient-to-b from-slate-900 via-[#041917] to-slate-950 border border-cyan-500/30 rounded-3xl p-5 sm:p-6 shadow-[0_20px_60px_rgba(0,0,0,0.9)] max-h-[85vh] flex flex-col"
            >
              {/* Modal Header */}
              <div className="flex items-center justify-between pb-4 border-b border-white/10 shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
                    <ArrowUpDown size={18} />
                  </div>
                  <div>
                    <h3 className="font-cairo font-bold text-base sm:text-lg text-white">
                      {isRtl ? 'ترتيب وتغيير أماكن بطاقات الملاك' : 'Change Place & Order of Cards'}
                    </h3>
                    <p className="font-cairo text-xs text-slate-400">
                      {isRtl 
                        ? 'استخدم الأسهم لتحريك أي بطاقة للأعلى أو للأسفل في الخط الزمني' 
                        : 'Use the arrows to shift cards up or down along the timeline'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsReorderModalOpen(false)}
                  className="w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Cards Reorder List */}
              <div className="overflow-y-auto custom-scrollbar my-4 space-y-2 pe-1 flex-1">
                {allOwners.map((owner, idx) => {
                  const cardId = owner.cardId || `history_owner_${owner.id}`;
                  const custom = getCustomization(cardId, owner.fallbackCardId);
                  const name = custom?.displayName || custom?.name || (owner.nameKey.startsWith('owner.') ? t(owner.nameKey) : owner.nameKey);
                  const role = custom?.roleTitle || (owner.titleKey.startsWith('owner.') ? t(owner.titleKey) : owner.titleKey);
                  const isPresent = (custom?.status || owner.status) === 'present';
                  const isFirst = idx === 0;
                  const isLast = idx === allOwners.length - 1;

                  return (
                    <div
                      key={cardId}
                      className="p-2.5 sm:p-3 rounded-2xl bg-slate-950/80 border border-white/10 hover:border-cyan-500/40 transition-all flex items-center justify-between gap-3 group"
                    >
                      {/* Left: Index badge & Name */}
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-8 h-8 rounded-xl bg-slate-900 border border-amber-500/30 flex items-center justify-center text-amber-300 font-mono text-xs font-bold shrink-0">
                          {toRomanNumeral(idx + 1)}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-cairo font-bold text-sm text-white truncate">
                              {name}
                            </span>
                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono shrink-0 ${
                              isPresent 
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30' 
                                : 'bg-slate-800 text-slate-400 border border-slate-700'
                            }`}>
                              {isPresent ? (isRtl ? 'حاضر' : 'Present') : (isRtl ? 'سابق' : 'Former')}
                            </span>
                          </div>
                          <span className="text-[11px] text-slate-400 block truncate">
                            {role}
                          </span>
                        </div>
                      </div>

                      {/* Right: Action Buttons */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        {/* Move to Top */}
                        <button
                          type="button"
                          disabled={isFirst}
                          onClick={() => handleMoveToExtremity(idx, true)}
                          title={isRtl ? 'نقل للبداية (الأول)' : 'Move to Top'}
                          className="w-7 h-7 rounded-lg bg-slate-900 hover:bg-cyan-950 border border-slate-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 disabled:opacity-20 flex items-center justify-center transition-all cursor-pointer disabled:cursor-not-allowed"
                        >
                          <ChevronsUp size={13} />
                        </button>

                        {/* Move Up 1 */}
                        <button
                          type="button"
                          disabled={isFirst}
                          onClick={() => handleMove(idx, -1)}
                          title={isRtl ? 'تقديم مكان واحد للأعلى' : 'Move Up 1 place'}
                          className="w-7 h-7 rounded-lg bg-slate-900 hover:bg-amber-950 border border-slate-700 hover:border-amber-400 text-slate-300 hover:text-amber-300 disabled:opacity-20 flex items-center justify-center transition-all cursor-pointer disabled:cursor-not-allowed"
                        >
                          <ArrowUp size={13} />
                        </button>

                        {/* Move Down 1 */}
                        <button
                          type="button"
                          disabled={isLast}
                          onClick={() => handleMove(idx, 1)}
                          title={isRtl ? 'تأخير مكان واحد للأسفل' : 'Move Down 1 place'}
                          className="w-7 h-7 rounded-lg bg-slate-900 hover:bg-amber-950 border border-slate-700 hover:border-amber-400 text-slate-300 hover:text-amber-300 disabled:opacity-20 flex items-center justify-center transition-all cursor-pointer disabled:cursor-not-allowed"
                        >
                          <ArrowDown size={13} />
                        </button>

                        {/* Move to Bottom */}
                        <button
                          type="button"
                          disabled={isLast}
                          onClick={() => handleMoveToExtremity(idx, false)}
                          title={isRtl ? 'نقل للنهاية (الأسفل)' : 'Move to Bottom'}
                          className="w-7 h-7 rounded-lg bg-slate-900 hover:bg-cyan-950 border border-slate-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 disabled:opacity-20 flex items-center justify-center transition-all cursor-pointer disabled:cursor-not-allowed"
                        >
                          <ChevronsDown size={13} />
                        </button>

                        {/* Delete for custom cards */}
                        {(owner.isCustom || cardId.startsWith('custom_')) && (
                          <button
                            type="button"
                            onClick={() => handleDeleteCard(cardId)}
                            title={isRtl ? 'حذف هذه البطاقة' : 'Delete Card'}
                            className="w-7 h-7 rounded-lg bg-rose-950/70 hover:bg-rose-900 border border-rose-600/40 text-rose-300 flex items-center justify-center transition-all cursor-pointer ms-1"
                          >
                            <Trash2 size={13} />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Modal Footer */}
              <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setIsReorderModalOpen(false);
                    openCreateCardModal();
                  }}
                  className="px-3.5 py-2 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 border border-teal-400/40 text-teal-300 font-cairo font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <PlusCircle size={14} />
                  <span>{isRtl ? 'إضافة بطاقة جديدة إلى الخط' : 'Add New Card to Line'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsReorderModalOpen(false)}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 text-slate-950 font-cairo font-bold text-xs hover:brightness-110 transition-all cursor-pointer"
                >
                  {isRtl ? 'تم وحفظ الترتيب' : 'Done & Save Order'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
