import React, { useRef, useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../../context/LanguageContext';
import { Owner3DCard } from './Owner3DCard';
import { OwnerData } from './OwnerTimelineCard';
import { toRomanNumeral } from '../../utils/ownerCardStyles';
import {
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Disc3,
  Sparkles,
  Compass,
  Layers,
  Crown,
  Eye,
  ArrowUpRight
} from 'lucide-react';

export interface Owners3DWorksWheelProps {
  owners: OwnerData[];
  className?: string;
  onSelectOwner?: (owner: OwnerData) => void;
}

/* =========================================================================
   GEOMETRY CONSTANTS FOR PORTRAIT OWNER CARDS
   Calibrated for high-fidelity archival portrait cards (~340px x 515px)
   ========================================================================= */
const CARD_ASPECT = 0.66; // width / height
const STEP_DEG = 26; // degrees between cards along the drum
const DRUM_MULT = 1.48; // drum radius in card heights
const LENS_MULT = 2.45; // perspective distance in card heights
const BOW_MULT = 0.22; // subtle horizontal arc displacement
const CULL_RANGE = 2.4; // culling threshold (cards beyond this are hidden)

const WHEEL_UNITS = 650; // mouse wheel sensitivity
const DRAG_UNITS = 340; // drag gesture sensitivity
const SETTLE_DELAY = 120; // settle timeout in ms
const EASE_FACTOR = 0.12; // smooth rAF easing

const clamp = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v));
const rad = (deg: number) => (deg * Math.PI) / 180;

export const Owners3DWorksWheel: React.FC<Owners3DWorksWheelProps> = ({
  owners,
  className = '',
  onSelectOwner,
}) => {
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const isRtl = language === 'ar';

  const stageRef = useRef<HTMLDivElement>(null);
  const drumRef = useRef<HTMLDivElement>(null);
  const cardWrappersRef = useRef<(HTMLDivElement | null)[]>([]);

  const turn = useRef(0);
  const target = useRef(0);
  const isDraggingRef = useRef(false);
  const dragStartPos = useRef<{ x: number; y: number } | null>(null);
  const settlingTimer = useRef<number>(0);

  const [activeIndex, setActiveIndex] = useState(0);
  const [stageDimensions, setStageDimensions] = useState({ w: 0, h: 0 });
  const [reducedMotion, setReducedMotion] = useState(false);

  const count = owners.length;
  const maxTurn = Math.max(0, count - 1);

  // Check reduced motion preference
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mq.matches);
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  // Measure stage dimensions on resize
  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const updateSize = () => {
      setStageDimensions({ w: el.clientWidth, h: el.clientHeight });
    };
    updateSize();
    const ro = new ResizeObserver(updateSize);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // Calibrate card metrics based on responsive stage size
  const metrics = useMemo(() => {
    const { w, h } = stageDimensions;
    if (!w || !h) {
      return {
        cardW: 340,
        cardH: 515,
        drumR: 760,
        lens: 1260,
        bow: 110,
      };
    }

    // Adaptive card sizing: wide on desktop, compact on mobile
    const maxW = Math.min(360, w * 0.88);
    const maxH = Math.min(540, h * 0.76);

    let cardW = maxW;
    let cardH = cardW / CARD_ASPECT;

    if (cardH > maxH) {
      cardH = maxH;
      cardW = cardH * CARD_ASPECT;
    }

    // Ensure readable minimums
    cardW = Math.max(260, Math.round(cardW));
    cardH = Math.max(390, Math.round(cardH));

    const drumR = cardH * DRUM_MULT;
    const lens = cardH * LENS_MULT;
    const bow = cardH * BOW_MULT;

    return {
      cardW,
      cardH,
      drumR,
      lens,
      bow,
    };
  }, [stageDimensions]);

  // Navigate smoothly to target index
  const goToIndex = useCallback(
    (index: number) => {
      target.current = clamp(index, 0, maxTurn);
    },
    [maxTurn]
  );

  // Single rAF loop for 60fps cinematic 3D transform updates
  useEffect(() => {
    if (!stageDimensions.h || count === 0) return;
    let animationFrameId = 0;
    const { drumR, bow } = metrics;

    const renderFrame = () => {
      animationFrameId = requestAnimationFrame(renderFrame);

      const delta = target.current - turn.current;
      if (Math.abs(delta) < 0.0004) {
        turn.current = target.current;
      } else {
        turn.current += delta * (reducedMotion ? 1 : EASE_FACTOR);
      }

      const currentTurn = turn.current;
      const roundedActive = clamp(Math.round(currentTurn), 0, maxTurn);

      if (drumRef.current) {
        // Subtle drum breathing and orientation
        drumRef.current.style.transform = `translateZ(${-drumR * 0.15}px)`;
      }

      for (let i = 0; i < count; i++) {
        const wrapper = cardWrappersRef.current[i];
        if (!wrapper) continue;

        const distance = i - currentTurn;
        const absDist = Math.abs(distance);

        if (absDist > CULL_RANGE) {
          wrapper.style.opacity = '0';
          wrapper.style.pointerEvents = 'none';
          wrapper.style.transform = 'translate3d(0, -9999px, -2000px)';
          continue;
        }

        const drumDeg = distance * STEP_DEG;
        const radAngle = rad(drumDeg);

        // Cylindrical coordinates
        const yPos = Math.sin(radAngle) * drumR;
        const zPos = Math.cos(radAngle) * drumR - drumR;
        // Subtle bow: slight horizontal curve to accent perspective
        const xBow = -Math.sign(distance) * (1 - Math.cos(radAngle)) * bow * 0.6;

        // Visual depth attenuation
        const scale = clamp(1 - absDist * 0.1, 0.72, 1);
        const opacity = clamp(1 - (absDist - 0.4) * 0.75, 0, 1);
        const brightness = clamp(1.04 - absDist * 0.38, 0.45, 1);
        const blur = absDist > 0.8 ? Math.min(2.5, (absDist - 0.8) * 2) : 0;

        wrapper.style.transform = `translate3d(${xBow}px, ${yPos}px, ${zPos}px) rotateX(${-drumDeg}deg) scale3d(${scale}, ${scale}, 1)`;
        wrapper.style.opacity = String(opacity);
        wrapper.style.filter = blur > 0.1 ? `brightness(${brightness}) blur(${blur}px)` : `brightness(${brightness})`;
        wrapper.style.zIndex = String(Math.round(100 - absDist * 10));

        // Interaction gating: front card has full interactive clicks; inactive neighbors can be clicked to focus
        if (absDist < 0.45) {
          wrapper.style.pointerEvents = 'auto';
        } else {
          wrapper.style.pointerEvents = 'auto'; // allows clicking neighbor card to rotate into focus
        }
      }

      setActiveIndex((prev) => (prev === roundedActive ? prev : roundedActive));
    };

    animationFrameId = requestAnimationFrame(renderFrame);
    return () => cancelAnimationFrame(animationFrameId);
  }, [metrics, stageDimensions.h, count, maxTurn, reducedMotion]);

  // Wheel listener with boundary pass-through (never traps page scroll!)
  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;

    const handleWheel = (e: WheelEvent) => {
      const delta = e.deltaY;
      const isAtTop = target.current <= 0.05 && delta < 0;
      const isAtBottom = target.current >= maxTurn - 0.05 && delta > 0;

      // Allow natural page scroll when at boundaries!
      if (isAtTop || isAtBottom) {
        return;
      }

      e.preventDefault();
      const next = clamp(target.current + delta / WHEEL_UNITS, 0, maxTurn);
      goToIndex(next);

      window.clearTimeout(settlingTimer.current);
      settlingTimer.current = window.setTimeout(() => {
        goToIndex(Math.round(target.current));
      }, SETTLE_DELAY);
    };

    el.addEventListener('wheel', handleWheel, { passive: false });
    return () => {
      el.removeEventListener('wheel', handleWheel);
      window.clearTimeout(settlingTimer.current);
    };
  }, [goToIndex, maxTurn]);

  // Pointer drag gestures with drag threshold detection (prevents misclick on card buttons!)
  const handlePointerDown = (e: React.PointerEvent) => {
    dragStartPos.current = { x: e.clientX, y: e.clientY };
    isDraggingRef.current = false;
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragStartPos.current) return;
    const dy = dragStartPos.current.y - e.clientY;
    const dx = dragStartPos.current.x - e.clientX;

    // Detect if this is an intentional drag
    if (!isDraggingRef.current && Math.hypot(dx, dy) > 7) {
      isDraggingRef.current = true;
    }

    if (isDraggingRef.current) {
      goToIndex(target.current + dy / DRAG_UNITS);
      dragStartPos.current = { x: e.clientX, y: e.clientY };
    }
  };

  const handlePointerUp = () => {
    dragStartPos.current = null;
    goToIndex(Math.round(target.current));
    // Reset drag flag shortly to allow genuine button clicks to complete
    setTimeout(() => {
      isDraggingRef.current = false;
    }, 60);
  };

  // Keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowRight') {
      e.preventDefault();
      goToIndex(Math.round(target.current) + 1);
    } else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') {
      e.preventDefault();
      goToIndex(Math.round(target.current) - 1);
    }
  };

  const currentOwner = owners[activeIndex] || owners[0];

  return (
    <div className={`relative w-full select-none ${className}`}>
      {/* ============================================================ */}
      {/* 3D EXHIBITION STAGE CONTAINER                                */}
      {/* ============================================================ */}
      <div
        ref={stageRef}
        tabIndex={0}
        role="region"
        aria-label="3D Owner Sovereign Wheel"
        onKeyDown={handleKeyDown}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        style={{
          perspective: `${metrics.lens}px`,
          perspectiveOrigin: '50% 50%',
        }}
        className="relative w-full h-[620px] sm:h-[680px] md:h-[730px] rounded-3xl overflow-hidden border border-cyan-500/25 bg-gradient-to-b from-[#021211]/90 via-[#010908]/95 to-[#021413]/95 shadow-[0_25px_80px_rgba(0,0,0,0.85),inset_0_1px_1px_rgba(94,234,212,0.2)] focus:outline-none focus:ring-2 focus:ring-cyan-400/40 cursor-grab active:cursor-grabbing touch-pan-x"
      >
        {/* Background Atmospheric Backlight Behind Active Card */}
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] sm:w-[480px] h-[340px] sm:h-[480px] rounded-full pointer-events-none blur-[100px] sm:blur-[130px] -z-10 transition-all duration-700 opacity-60"
          style={{
            background: 'radial-gradient(circle, rgba(94,234,212,0.25) 0%, rgba(245,158,11,0.15) 50%, transparent 75%)',
          }}
          aria-hidden="true"
        />

        {/* Ambient Top & Bottom Archival Gradients */}
        <div className="absolute top-0 inset-x-0 h-28 bg-gradient-to-b from-black/80 via-black/30 to-transparent pointer-events-none z-20" />
        <div className="absolute bottom-0 inset-x-0 h-32 bg-gradient-to-t from-black/85 via-black/40 to-transparent pointer-events-none z-20" />

        {/* ============================================================ */}
        {/* TOP STATUS TICKER: Epoch Index & Owner Directory Selector   */}
        {/* ============================================================ */}
        <div className="absolute top-4 inset-x-4 sm:inset-x-6 z-30 flex items-center justify-between gap-3 pointer-events-none">
          {/* Active Owner Roman Title */}
          <div className="pointer-events-auto flex items-center gap-2 px-3.5 py-1.5 rounded-2xl bg-black/75 border border-cyan-500/30 backdrop-blur-xl shadow-lg">
            <Disc3 size={15} className="text-cyan-400 animate-spin-slow shrink-0" />
            <span className="font-serif font-black text-xs text-amber-300 tracking-wider">
              № {toRomanNumeral(activeIndex + 1)}
            </span>
            <span className="text-white/20">|</span>
            <span className="font-cairo font-bold text-xs text-slate-200 truncate max-w-[130px] sm:max-w-[200px]">
              {currentOwner?.displayName || (currentOwner?.nameKey.startsWith('owner.') ? t(currentOwner.nameKey) : currentOwner?.nameKey)}
            </span>
          </div>

          {/* Quick Step Indicator */}
          <div className="pointer-events-auto flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-black/70 border border-white/10 backdrop-blur-xl text-[11px] font-mono text-slate-400">
            <span className="text-cyan-400 font-bold">{activeIndex + 1}</span>
            <span>/</span>
            <span>{count}</span>
          </div>
        </div>

        {/* ============================================================ */}
        {/* 3D DRUM REVOLVING ROTUNDA                                     */}
        {/* ============================================================ */}
        <div
          ref={drumRef}
          className="absolute inset-0 flex items-center justify-center [transform-style:preserve-3d] pointer-events-none"
        >
          {owners.map((owner, idx) => {
            const isCenter = idx === activeIndex;
            const romanSafe = owner.romanNumeral || toRomanNumeral(idx + 1);

            return (
              <div
                key={owner.cardId || owner.id}
                ref={(node) => {
                  cardWrappersRef.current[idx] = node;
                }}
                onClick={(e) => {
                  if (isDraggingRef.current) return;
                  if (!isCenter) {
                    e.stopPropagation();
                    goToIndex(idx);
                  } else {
                    e.stopPropagation();
                    const targetId = owner.cardId || owner.fallbackCardId || `history_owner_${owner.id}`;
                    navigate(`/owner/${targetId}`);
                  }
                }}
                className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 will-change-transform [transform-style:preserve-3d] transition-shadow duration-300 cursor-pointer group/drumcard ${
                  isCenter ? 'ring-2 ring-cyan-400/40 rounded-[2.2rem]' : ''
                }`}
                style={{
                  width: metrics.cardW,
                  height: metrics.cardH,
                }}
              >
                {/* 
                  CRITICAL REQUIREMENT PRESERVED:
                  We render the REAL Owner card directly, preserving all its
                  native design, photo layers, hover tilt, badges, and buttons!
                */}
                <div
                  className="w-full h-full relative"
                  onClick={(e) => {
                    // Suppress click on card child elements if dragging
                    if (isDraggingRef.current) {
                      e.stopPropagation();
                    }
                  }}
                >
                  <Owner3DCard
                    cardId={owner.cardId || `history_owner_${owner.id}`}
                    fallbackCardId={owner.fallbackCardId}
                    romanNumeral={romanSafe}
                    numeralIndex={idx}
                    name={owner.displayName || (owner.nameKey.startsWith('owner.') ? t(owner.nameKey) : owner.nameKey)}
                    displayName={owner.displayName}
                    rankTitle={owner.titleKey.startsWith('owner.') ? t(owner.titleKey) : owner.titleKey}
                    roleLabelAr={owner.titleKey.startsWith('owner.') ? t(owner.titleKey) : owner.titleKey}
                    subtitleAr={owner.descKey.startsWith('owner.') ? t(owner.descKey) : owner.descKey}
                    badge={owner.badgeKey.startsWith('owner.') ? t(owner.badgeKey) : owner.badgeKey}
                    country={owner.country}
                    status={owner.status}
                    isCustom={owner.isCustom}
                    order={owner.order}
                    className="h-full shadow-2xl"
                  />

                  {/* Elegant Floating "View Profile" Cue for Active Center Card */}
                  {isCenter && (
                    <div className="absolute -bottom-4 start-1/2 -translate-x-1/2 rtl:translate-x-1/2 z-30 pointer-events-none opacity-0 group-hover/drumcard:opacity-100 transition-opacity duration-200">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/90 text-cyan-200 border border-cyan-400/50 text-[10px] font-semibold font-mono tracking-wider shadow-lg backdrop-blur-md">
                        <span>{isRtl ? 'فتح الملف الشخصي' : 'Open Dedicated Profile'}</span>
                        <ArrowUpRight size={11} className="text-cyan-300" />
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* ============================================================ */}
        {/* INTERACTIVE NAVIGATION BUTTONS (PREV / NEXT CHEVRONS)        */}
        {/* ============================================================ */}
        <button
          type="button"
          disabled={activeIndex <= 0}
          onClick={(e) => {
            e.stopPropagation();
            goToIndex(activeIndex - 1);
          }}
          className="absolute top-1/2 -translate-y-1/2 start-3 sm:start-5 z-30 w-10 sm:w-12 h-10 sm:h-12 rounded-2xl bg-black/75 hover:bg-cyan-950/80 border border-cyan-500/30 hover:border-cyan-400 text-cyan-300 disabled:opacity-20 disabled:pointer-events-none flex items-center justify-center transition-all cursor-pointer shadow-xl backdrop-blur-md hover:scale-105 active:scale-95"
          title={isRtl ? 'المالك السابق' : 'Previous Owner'}
          aria-label="Previous Owner"
        >
          {isRtl ? <ChevronRight size={22} /> : <ChevronLeft size={22} />}
        </button>

        <button
          type="button"
          disabled={activeIndex >= count - 1}
          onClick={(e) => {
            e.stopPropagation();
            goToIndex(activeIndex + 1);
          }}
          className="absolute top-1/2 -translate-y-1/2 end-3 sm:end-5 z-30 w-10 sm:w-12 h-10 sm:h-12 rounded-2xl bg-black/75 hover:bg-cyan-950/80 border border-cyan-500/30 hover:border-cyan-400 text-cyan-300 disabled:opacity-20 disabled:pointer-events-none flex items-center justify-center transition-all cursor-pointer shadow-xl backdrop-blur-md hover:scale-105 active:scale-95"
          title={isRtl ? 'المالك التالي' : 'Next Owner'}
          aria-label="Next Owner"
        >
          {isRtl ? <ChevronLeft size={22} /> : <ChevronRight size={22} />}
        </button>

        {/* ============================================================ */}
        {/* BOTTOM QUICK-JUMP OWNER DOCK TICKER                          */}
        {/* ============================================================ */}
        <div className="absolute bottom-3 sm:bottom-4 inset-x-3 sm:inset-x-8 z-30 pointer-events-none flex flex-col items-center gap-2">
          {/* Scroll & Drag Guidance Pill */}
          <div className="pointer-events-auto hidden sm:flex items-center gap-2 px-3 py-1 rounded-full bg-black/60 border border-white/10 backdrop-blur-md text-[10px] text-slate-400">
            <Compass size={11} className="text-cyan-400 shrink-0" />
            <span>
              {isRtl
                ? 'حرّك عجلة الفأرة، اسحب البطاقات رأسياً، أو استخدم الأسهم للتنقل'
                : 'Turn with mouse wheel, drag vertically, or use keyboard arrows'}
            </span>
          </div>

          {/* Luxury Horizontal Owner Pill Carousel */}
          <div className="pointer-events-auto flex items-center gap-1.5 p-1.5 rounded-2xl bg-black/85 border border-white/10 backdrop-blur-2xl max-w-full overflow-x-auto no-scrollbar shadow-2xl">
            {owners.map((owner, i) => {
              const isSelected = i === activeIndex;
              const nameText = owner.displayName || (owner.nameKey.startsWith('owner.') ? t(owner.nameKey) : owner.nameKey);

              return (
                <button
                  key={owner.cardId || owner.id}
                  type="button"
                  onClick={() => goToIndex(i)}
                  className={`px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-xl text-[10px] sm:text-xs font-cairo font-semibold transition-all duration-300 flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
                    isSelected
                      ? 'bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 text-slate-950 font-bold shadow-[0_0_15px_rgba(6,182,212,0.6)] scale-105'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                  title={nameText}
                >
                  <span className="font-serif font-bold text-[9px] opacity-80">
                    {toRomanNumeral(i + 1)}
                  </span>
                  <span className="truncate max-w-[80px] sm:max-w-[110px]">{nameText}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Owners3DWorksWheel;
