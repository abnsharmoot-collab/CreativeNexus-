import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useLanguage } from '../../context/LanguageContext';
import { Scroll, Copy, Check, Sparkles, Feather } from 'lucide-react';

export const SanctuaryCreed: React.FC = () => {
  const { t, language } = useLanguage();
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    const textToCopy = t('history.creed.text');
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <section id="creed" className="relative py-20 px-4 sm:px-6">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.8 }}
          className="relative rounded-[2.5rem] border border-amber-500/30 bg-gradient-to-b from-[#111618] via-archive-dark to-[#091114] p-8 sm:p-12 md:p-14 backdrop-blur-2xl shadow-[0_20px_60px_rgba(0,0,0,0.6),inset_0_1px_1px_rgba(245,158,11,0.2)] overflow-hidden text-center"
        >
          {/* Subtle Golden Amber Top Rim */}
          <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-amber-400/80 to-transparent shadow-[0_0_15px_rgba(251,191,36,0.6)]" />

          {/* Faint watermark scroll */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-[0.03] pointer-events-none select-none text-amber-200">
            <Scroll size={300} />
          </div>

          {/* Header */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/25 text-amber-300 text-xs font-semibold uppercase tracking-[0.25em] mb-6 shadow-[0_0_15px_rgba(245,158,11,0.15)]">
            <Feather size={13} className="text-amber-400" />
            <span>{t('history.creed.title')}</span>
          </div>

          {/* Creed Quotation */}
          <blockquote className="font-display italic text-lg sm:text-2xl md:text-3xl text-archive-paper leading-relaxed max-w-3xl mx-auto mb-8 font-normal tracking-wide drop-shadow-sm">
            {t('history.creed.text')}
          </blockquote>

          {/* Ornate Divider */}
          <div className="flex items-center justify-center gap-4 my-8 max-w-md mx-auto">
            <div className="h-px flex-1 bg-gradient-to-r from-transparent to-amber-400/40" />
            <div className="flex items-center gap-1.5 text-amber-400">
              <Sparkles size={14} />
              <div className="w-1.5 h-1.5 rotate-45 bg-amber-400" />
              <Sparkles size={14} />
            </div>
            <div className="h-px flex-1 bg-gradient-to-l from-transparent to-amber-400/40" />
          </div>

          {/* Copy Button */}
          <div className="flex justify-center">
            <button
              onClick={handleCopy}
              className="inline-flex items-center gap-2.5 px-6 py-3 rounded-2xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400/40 text-amber-200 text-xs sm:text-sm font-semibold tracking-wider uppercase transition-all duration-300 shadow-[0_0_20px_rgba(245,158,11,0.2)] hover:scale-105 active:scale-95"
            >
              {copied ? (
                <>
                  <Check size={16} className="text-emerald-400" />
                  <span className="text-emerald-300">{t('history.creed.copied')}</span>
                </>
              ) : (
                <>
                  <Copy size={16} className="text-amber-400" />
                  <span>{t('history.creed.copy')}</span>
                </>
              )}
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
