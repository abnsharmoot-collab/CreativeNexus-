import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Shield, Sparkles } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useStaff } from '../../context/StaffContext';

export interface AdminProfile {
  id?: string;
  name: string;
  displayName?: string;
  username?: string;
  avatarUrl?: string;
  role: 'admin';
  rankTitle?: string;
  roleLabelAr: string;
  roleLabelEn: string;
  accent: string;
  initials: string;
}

const FALLBACK_ADMINS: AdminProfile[] = [
  {
    name: 'DOMA',
    displayName: '𝑫𝑶𝑴𝑨',
    username: 'adam046778',
    role: 'admin',
    rankTitle: 'Moderator',
    roleLabelAr: 'مشرف السيرفر',
    roleLabelEn: 'Moderator',
    accent: 'teal',
    initials: 'DO',
  },
  {
    name: 'MAKO',
    displayName: '𝑀𝑎𝑘𝑜,.',
    username: 'mako._.5',
    role: 'admin',
    rankTitle: 'Senior Moderator',
    roleLabelAr: 'مشرف أول',
    roleLabelEn: 'Senior Moderator',
    accent: 'teal',
    initials: 'MA',
  },
  {
    name: 'NADA',
    displayName: 'ŇÃĎÃ💢🧢',
    username: 'ggmoneyha',
    role: 'admin',
    rankTitle: 'Administrator',
    roleLabelAr: 'إدارية السيرفر',
    roleLabelEn: 'Administrator',
    accent: 'pink',
    initials: 'NA',
  },
  {
    name: 'YOUSSEF',
    displayName: 'Youssef',
    username: 'pepsi_2x',
    role: 'admin',
    rankTitle: 'Moderator',
    roleLabelAr: 'مشرف السيرفر',
    roleLabelEn: 'Moderator',
    accent: 'teal',
    initials: 'YO',
  },
  {
    name: 'VIOLET',
    displayName: '777',
    username: 'violet_0087',
    role: 'admin',
    rankTitle: 'Senior Moderator',
    roleLabelAr: 'مشرفة أولى',
    roleLabelEn: 'Senior Moderator',
    accent: 'purple',
    initials: 'VI',
  },
  {
    name: 'SEIF',
    displayName: '𝐒𝐄𝐈𝐅',
    username: 'seif_01',
    role: 'admin',
    rankTitle: 'Moderator',
    roleLabelAr: 'مشرف السيرفر',
    roleLabelEn: 'Moderator',
    accent: 'teal',
    initials: 'SE',
  },
  {
    name: 'MAHMOUD',
    displayName: 'Mahmoud',
    username: 'mahmoud_x',
    role: 'admin',
    rankTitle: 'Moderator',
    roleLabelAr: 'مشرف السيرفر',
    roleLabelEn: 'Moderator',
    accent: 'teal',
    initials: 'MA',
  },
  {
    name: 'KHALED',
    displayName: 'Khaled',
    username: 'khaled_99',
    role: 'admin',
    rankTitle: 'Senior Moderator',
    roleLabelAr: 'مشرف أول',
    roleLabelEn: 'Senior Moderator',
    accent: 'purple',
    initials: 'KH',
  },
  {
    name: 'OMAR',
    displayName: 'Omar',
    username: 'omar_dev',
    role: 'admin',
    rankTitle: 'Administrator',
    roleLabelAr: 'إداري السيرفر',
    roleLabelEn: 'Administrator',
    accent: 'cyan',
    initials: 'OM',
  },
  {
    name: 'TARIQ',
    displayName: 'Tariq',
    username: 'tariq_nexus',
    role: 'admin',
    rankTitle: 'Moderator',
    roleLabelAr: 'مشرف السيرفر',
    roleLabelEn: 'Moderator',
    accent: 'teal',
    initials: 'TA',
  },
];

export const CurrentEraSection: React.FC = () => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { staff } = useStaff();
  const [admins, setAdmins] = useState<AdminProfile[]>(FALLBACK_ADMINS);

  // Sync dynamic current era administrators from backend API
  useEffect(() => {
    let isMounted = true;
    const fetchCurrentEra = async () => {
      try {
        const res = await fetch('/api/history/current-era', {
          headers: { 'Accept': 'application/json' }
        });
        if (res.ok) {
          const data = await res.json();
          if (isMounted && data.success && Array.isArray(data.administrators) && data.administrators.length > 0) {
            setAdmins(data.administrators);
          }
        }
      } catch (err) {
        console.warn('Notice: Using fallback administrators data', err);
      }
    };

    fetchCurrentEra();
    return () => {
      isMounted = false;
    };
  }, []);

  // Sync administrators with real-time Discord staff if available
  useEffect(() => {
    if (staff && staff.length > 0) {
      setAdmins(prev => {
        return prev.map(admin => {
          const matched = staff.find(s =>
            (admin.username && s.username?.toLowerCase() === admin.username.toLowerCase()) ||
            (admin.displayName && s.displayName?.toLowerCase() === admin.displayName.toLowerCase()) ||
            (admin.name && s.displayName?.toLowerCase().includes(admin.name.toLowerCase()))
          );
          if (matched) {
            const rankLabel = matched.rank === 'ADMINISTRATOR' ? 'Administrator'
              : matched.rank === 'SUPER_ADMIN' ? 'Super Admin'
              : matched.rank === 'SENIOR_ADMINISTRATOR' ? 'Senior Admin'
              : matched.rank === 'SENIOR_MODERATOR' ? 'Senior Moderator'
              : matched.rank === 'MODERATOR' ? 'Moderator'
              : admin.rankTitle;

            const rankAr = matched.rank === 'ADMINISTRATOR' ? 'إداري السيرفر'
              : matched.rank === 'SUPER_ADMIN' ? 'مدير عام'
              : matched.rank === 'SENIOR_ADMINISTRATOR' ? 'إداري أول'
              : matched.rank === 'SENIOR_MODERATOR' ? 'مشرف أول'
              : matched.rank === 'MODERATOR' ? 'مشرف السيرفر'
              : admin.roleLabelAr;

            return {
              ...admin,
              displayName: matched.displayName || admin.displayName,
              username: matched.username || admin.username,
              avatarUrl: matched.avatarUrl || admin.avatarUrl,
              rankTitle: rankLabel,
              roleLabelAr: rankAr,
            };
          }
          return admin;
        });
      });
    }
  }, [staff]);

  return (
    <section id="current-era" className="relative py-16 sm:py-20 scroll-mt-24">
      {/* Subtle background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-gradient-to-tr from-cyan-500/10 via-emerald-500/5 to-transparent blur-[140px] pointer-events-none -z-10" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/60 border border-cyan-400/30 text-cyan-300 text-xs font-semibold tracking-widest uppercase mb-4 shadow-[0_0_15px_rgba(6,182,212,0.15)]">
            <Sparkles size={13} />
            <span>THE LIVING SANCTUARY • ADMINISTRATION</span>
          </div>

          <h2 className="font-display font-bold text-3xl sm:text-5xl text-white tracking-wide mb-3">
            CURRENT ADMINISTRATORS
          </h2>

          <p className="font-sans text-base sm:text-lg text-slate-300 font-medium max-w-2xl mx-auto leading-relaxed" dir="rtl">
            "التطور المستمر والازدهار في سيرفر Creative Nexus يُبنى بجهود طاقم الإدارة والمشرفين المخلصين، وبتفانيهم في خدمة المجتمع وحمايته."
          </p>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 font-mono">
            Dedicated team of administrators and moderators upholding server excellence.
          </p>
        </div>

        {/* Administrators Section Header */}
        <div className="flex items-center gap-3 mb-6" dir={isAr ? 'rtl' : 'ltr'}>
          <div className="w-8 h-8 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-300 shrink-0">
            <Shield size={16} />
          </div>
          <div>
            <h3 className="font-display font-bold text-lg sm:text-xl text-white tracking-wide">
              {isAr ? 'طاقم الإدارة الحالي' : 'Active Server Administrators'}
            </h3>
            <p className="text-xs text-slate-400 font-mono">
              {isAr ? `${admins.length} إداريين ومشرفين` : `${admins.length} Staff Members`}
            </p>
          </div>
          <div className="flex-1 h-px bg-gradient-to-r from-cyan-500/20 via-cyan-500/5 to-transparent ms-4" />
        </div>

        {/* Administrators Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
          {admins.map((admin, idx) => (
            <motion.div
              key={admin.name || admin.username || idx}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: idx * 0.04 }}
              className="relative rounded-2xl p-4 bg-gradient-to-b from-slate-900/80 to-slate-950/90 border border-slate-800/80 hover:border-cyan-400/40 transition-all duration-300 group hover:shadow-[0_8px_20px_rgba(6,182,212,0.12)] backdrop-blur-md text-center flex flex-col justify-between"
            >
              <div>
                {/* Avatar Profile Picture */}
                <div className="relative w-12 h-12 rounded-xl mx-auto mb-3 overflow-hidden border border-slate-700/80 flex items-center justify-center font-display font-bold text-base text-cyan-300 bg-gradient-to-br from-slate-800 to-slate-900 group-hover:border-cyan-400/50 group-hover:scale-105 transition-all shadow-md">
                  {admin.avatarUrl ? (
                    <img
                      src={admin.avatarUrl}
                      alt={admin.displayName || admin.name}
                      className="w-full h-full object-cover"
                      loading="lazy"
                      onError={(e) => {
                        (e.currentTarget as HTMLElement).style.display = 'none';
                        const parent = e.currentTarget.parentElement;
                        if (parent) {
                          const fallback = parent.querySelector('.admin-initials-fallback') as HTMLElement;
                          if (fallback) fallback.style.display = 'flex';
                        }
                      }}
                    />
                  ) : null}

                  <div className={`admin-initials-fallback ${admin.avatarUrl ? 'hidden' : 'flex'} items-center justify-center w-full h-full`}>
                    {admin.initials}
                  </div>
                </div>

                {/* Display Name */}
                <h4 className="font-display font-bold text-sm sm:text-base text-white tracking-wider mb-0.5 group-hover:text-cyan-200 transition-colors truncate">
                  {admin.displayName || admin.name}
                </h4>

                {/* Username */}
                {admin.username && (
                  <p className="text-[11px] font-mono text-slate-400 truncate mb-2">
                    @{admin.username}
                  </p>
                )}
              </div>

              {/* Role / Rank Pill */}
              <div className="pt-2 border-t border-slate-800/60 mt-1">
                <span className="inline-block text-[11px] font-mono text-cyan-400/90 bg-cyan-950/40 border border-cyan-500/20 px-2 py-0.5 rounded-full truncate max-w-full">
                  {isAr ? (admin.roleLabelAr || 'إداري') : (admin.rankTitle || 'Administrator')}
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
