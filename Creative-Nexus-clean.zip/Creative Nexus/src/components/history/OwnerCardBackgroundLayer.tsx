import React from 'react';
import { Sliders, Palette, Camera } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { useOwnerCardBackgrounds } from '../../context/OwnerCardBackgroundsContext';

interface OwnerCardBackgroundLayerProps {
  cardId: string;
  fallbackCardId?: string;
  ownerName: string;
  displayName?: string;
  roleTitle?: string;
  subtitle?: string;
  badge?: string;
  country?: string;
  status?: 'present' | 'former';
  defaultAccent?: string;
  isCustom?: boolean;
  order?: number;
  className?: string;
  showEditButton?: boolean;
  buttonPosition?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left';
}

export const OwnerCardBackgroundLayer: React.FC<OwnerCardBackgroundLayerProps> = ({
  cardId,
  fallbackCardId,
  ownerName,
  displayName,
  roleTitle,
  subtitle,
  badge,
  country,
  status,
  defaultAccent,
  isCustom,
  order,
  className = '',
  showEditButton = true,
  buttonPosition = 'top-right'
}) => {
  const { isOwner } = useAuth();
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { getBackground, openEditModal } = useOwnerCardBackgrounds();

  const bg = getBackground(cardId, fallbackCardId);

  // If card is configured to hide edit button or all buttons, respect that
  const shouldShowButton = showEditButton && !bg?.hideEditButton && !bg?.hideAllButtons;

  const positionClasses = {
    'top-right': 'top-3 end-3',
    'top-left': 'top-3 start-3',
    'bottom-right': 'bottom-3 end-3',
    'bottom-left': 'bottom-3 start-3',
  }[buttonPosition];

  return (
    <>
      {/* Background Photo & Tint Layer */}
      {bg?.imageUrl && (
        <div className={`absolute inset-0 pointer-events-none overflow-hidden rounded-[inherit] z-0 ${className}`}>
          {/* Main Photo */}
          <div
            className="absolute inset-0 transition-all duration-700 ease-out"
            style={{
              backgroundImage: `url(${bg.imageUrl})`,
              backgroundPosition: bg.objectPosition || 'center',
              backgroundSize: 'cover',
              backgroundRepeat: 'no-repeat',
              filter: bg.blur && bg.blur > 0 ? `blur(${bg.blur}px)` : 'none',
              transform: bg.blur && bg.blur > 0 ? 'scale(1.08)' : 'scale(1)'
            }}
          />

          {/* Configured Dark Backdrop Tint */}
          <div
            className="absolute inset-0 transition-opacity duration-300"
            style={{
              backgroundColor: `rgba(2, 7, 9, ${bg.overlayOpacity ?? 0.45})`
            }}
          />

          {/* Seamless Radial Edge Gradient Vignette */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-slate-950/40" />
        </div>
      )}

      {/* Floating Owner Card Customizer Button */}
      {shouldShowButton && (
        <div className={`absolute ${positionClasses} z-30 pointer-events-auto`}>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              e.preventDefault();
              openEditModal({
                cardId,
                fallbackCardId,
                ownerName,
                displayName: displayName || bg?.displayName || ownerName,
                roleTitle: roleTitle || bg?.roleTitle,
                subtitle: subtitle || bg?.subtitle,
                badge: badge || bg?.badge,
                country: country || bg?.country,
                status: status || bg?.status,
                defaultAccent: defaultAccent || bg?.accentColor || 'amber',
                isCustom: isCustom || bg?.isCustom,
                order: order ?? bg?.order
              });
            }}
            title={isAr ? `تخصيص كامل لبطاقة ${ownerName}: الأسماء، الألوان، المؤثرات، الخلفية والترتيب (للمالك فقط)` : `Full card customizer for ${ownerName}: names, colors, effects, background & order (Owner Only)`}
            className="group/owner-btn flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-950/90 hover:bg-amber-950 border border-amber-500/50 hover:border-amber-400 text-amber-300 shadow-[0_4px_16px_rgba(0,0,0,0.6)] backdrop-blur-md transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer"
          >
            <Sliders size={13} className="group-hover/owner-btn:rotate-12 transition-transform text-amber-400" />
            <span className="text-[10px] font-bold font-cairo tracking-tight hidden sm:inline-block">
              {isAr ? 'تخصيص البطاقة' : 'Customize Card'}
            </span>
          </button>
        </div>
      )}
    </>
  );
};
