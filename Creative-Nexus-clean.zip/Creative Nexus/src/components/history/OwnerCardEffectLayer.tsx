import React from 'react';
import { motion } from 'motion/react';
import { Heart, Flame, Star, Shield, Sparkles, Crown, Zap, Moon } from 'lucide-react';

interface OwnerCardEffectLayerProps {
  effect?: string; // 'none' | 'romantic' | 'fire' | 'stars' | 'guardian' | 'cyber' | 'solar' | 'electric' | 'void' | 'phoenix'
  accentColor?: string; // 'amber' | 'emerald' | 'rose' | 'cyan' | 'purple' | 'red' | 'orange' | 'yellow' | 'blue'
  glowIntensity?: number; // 0 to 1
  borderStyle?: string; // 'glow' | 'pulse' | 'shimmer' | 'neon' | 'solid'
}

export const OwnerCardEffectLayer: React.FC<OwnerCardEffectLayerProps> = ({
  effect = 'none',
  accentColor = 'amber',
  glowIntensity = 0.5,
  borderStyle = 'glow'
}) => {
  const intensity = typeof glowIntensity === 'number' ? glowIntensity : 0.5;

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-[inherit] z-0">
      {/* 1. ROMANTIC EFFECT: Gentle Drifting Glowing Hearts & Rose Petals */}
      {effect === 'romantic' && (
        <>
          <div 
            className="absolute top-0 end-0 w-80 h-80 bg-radial from-rose-500/25 via-rose-500/8 to-transparent rounded-full blur-2xl pointer-events-none"
            style={{ opacity: Math.max(0.35, intensity * 1.3) }}
          />
          <motion.div
            animate={{ y: [0, -18, 0], opacity: [0.4, 0.85, 0.4], scale: [0.95, 1.08, 0.95] }}
            transition={{ duration: 4.2, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute top-6 end-8 text-rose-400/60 drop-shadow-[0_0_10px_rgba(244,63,94,0.6)]"
          >
            <Heart size={18} fill="currentColor" />
          </motion.div>
          <motion.div
            animate={{ y: [0, -14, 0], opacity: [0.25, 0.7, 0.25], scale: [1, 1.15, 1] }}
            transition={{ duration: 5.2, repeat: Infinity, ease: 'easeInOut', delay: 1.2 }}
            className="absolute bottom-16 start-8 text-rose-400/50 drop-shadow-[0_0_8px_rgba(244,63,94,0.5)]"
          >
            <Heart size={15} fill="currentColor" />
          </motion.div>
          <motion.div
            animate={{ y: [0, -10, 0], opacity: [0.3, 0.6, 0.3] }}
            transition={{ duration: 3.8, repeat: Infinity, ease: 'easeInOut', delay: 2.1 }}
            className="absolute top-1/2 end-10 text-pink-400/40"
          >
            <Heart size={12} fill="currentColor" />
          </motion.div>
          <motion.div
            animate={{ y: [20, -30], x: [-10, 15], opacity: [0, 0.6, 0], rotate: [0, 90] }}
            transition={{ duration: 6, repeat: Infinity, ease: 'linear' }}
            className="absolute bottom-1/3 start-1/4 w-2 h-2 rounded-full bg-rose-400/50 blur-[0.5px]"
          />
        </>
      )}

      {/* 2. FIRE EFFECT: Rising Cinematic Embers & Radiant Warmth */}
      {effect === 'fire' && (
        <>
          <div 
            className="absolute top-0 inset-x-0 h-44 bg-radial from-orange-500/30 via-red-600/12 to-transparent blur-2xl pointer-events-none animate-pulse"
            style={{ opacity: Math.max(0.4, intensity * 1.35) }}
          />
          <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-orange-500 to-transparent shadow-[0_0_16px_rgba(249,115,22,0.9)]" />
          
          {/* Animated rising sparks */}
          <motion.div
            animate={{ y: [30, -50], x: [0, 6, -6, 3], opacity: [0, 0.95, 0] }}
            transition={{ duration: 2.6, repeat: Infinity, ease: 'easeOut' }}
            className="absolute bottom-6 start-1/4 w-2 h-2 rounded-full bg-orange-400 shadow-[0_0_12px_#f97316]"
          />
          <motion.div
            animate={{ y: [30, -60], x: [0, -8, 4, -3], opacity: [0, 0.9, 0] }}
            transition={{ duration: 3.2, repeat: Infinity, ease: 'easeOut', delay: 0.9 }}
            className="absolute bottom-8 start-3/5 w-2.5 h-2.5 rounded-full bg-amber-300 shadow-[0_0_14px_#f59e0b]"
          />
          <motion.div
            animate={{ y: [30, -40], x: [0, 7, -4], opacity: [0, 0.85, 0] }}
            transition={{ duration: 2.4, repeat: Infinity, ease: 'easeOut', delay: 1.7 }}
            className="absolute bottom-4 end-1/4 w-2 h-2 rounded-full bg-red-400 shadow-[0_0_10px_#ef4444]"
          />
        </>
      )}

      {/* 3. STARS EFFECT: Cosmic Twinkling Starlight & Celestial Nebula */}
      {effect === 'stars' && (
        <>
          <div 
            className="absolute inset-0 bg-radial from-violet-600/20 via-indigo-600/8 to-transparent rounded-full blur-3xl pointer-events-none"
            style={{ opacity: Math.max(0.35, intensity * 1.2) }}
          />
          <motion.div
            animate={{ scale: [0.8, 1.35, 0.8], opacity: [0.35, 0.95, 0.35], rotate: [0, 45, 0] }}
            transition={{ duration: 3.2, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute top-5 end-7 text-amber-200/70 drop-shadow-[0_0_10px_rgba(251,191,36,0.6)]"
          >
            <Star size={16} fill="currentColor" />
          </motion.div>
          <motion.div
            animate={{ scale: [1, 1.4, 1], opacity: [0.25, 0.85, 0.25], rotate: [0, -30, 0] }}
            transition={{ duration: 4.2, repeat: Infinity, ease: 'easeInOut', delay: 1.5 }}
            className="absolute bottom-16 start-8 text-cyan-200/60 drop-shadow-[0_0_8px_rgba(6,182,212,0.5)]"
          >
            <Sparkles size={15} />
          </motion.div>
          <motion.div
            animate={{ scale: [0.7, 1.2, 0.7], opacity: [0.3, 0.8, 0.3] }}
            transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut', delay: 2.2 }}
            className="absolute top-1/3 start-6 text-indigo-300/50"
          >
            <Star size={12} fill="currentColor" />
          </motion.div>
        </>
      )}

      {/* 4. GUARDIAN EFFECT: Protective Pulsing Energy Shield Aura */}
      {effect === 'guardian' && (
        <>
          <div 
            className="absolute inset-0 bg-gradient-to-t from-emerald-500/20 via-teal-500/8 to-emerald-500/15 blur-2xl pointer-events-none"
            style={{ opacity: Math.max(0.4, intensity * 1.3) }}
          />
          <motion.div
            animate={{ scale: [1, 1.025, 1], opacity: [0.4, 0.9, 0.4] }}
            transition={{ duration: 3.2, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute -inset-px rounded-[inherit] border-2 border-emerald-400/50 shadow-[0_0_20px_rgba(16,185,129,0.3)] pointer-events-none"
          />
          <div className="absolute top-5 end-7 text-emerald-400/40 drop-shadow-[0_0_8px_rgba(16,185,129,0.5)]">
            <Shield size={18} />
          </div>
        </>
      )}

      {/* 5. CYBER EFFECT: High-Tech Scanline Grid Shimmer */}
      {effect === 'cyber' && (
        <>
          <div 
            className="absolute inset-0 bg-[linear-gradient(to_bottom,transparent_50%,rgba(6,182,212,0.08)_51%)] bg-[length:100%_4px] opacity-50 pointer-events-none"
          />
          <motion.div
            animate={{ y: [-100, 500] }}
            transition={{ duration: 3.8, repeat: Infinity, ease: 'linear' }}
            className="absolute inset-x-0 h-16 bg-gradient-to-b from-transparent via-cyan-400/20 to-transparent pointer-events-none"
          />
          <div className="absolute top-0 inset-x-0 h-[2px] bg-cyan-400/70 shadow-[0_0_14px_#06b6d4]" />
        </>
      )}

      {/* 6. SOLAR EFFECT: Royal Golden Sun Corona */}
      {effect === 'solar' && (
        <>
          <div 
            className="absolute -top-14 inset-x-0 h-48 bg-radial from-amber-400/30 via-yellow-500/15 to-transparent blur-3xl pointer-events-none"
            style={{ opacity: Math.max(0.45, intensity * 1.35) }}
          />
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 35, repeat: Infinity, ease: 'linear' }}
            className="absolute -top-12 end-6 w-32 h-32 border-2 border-amber-400/25 rounded-full border-dashed pointer-events-none opacity-50"
          />
          <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-amber-400 to-transparent shadow-[0_0_18px_rgba(251,191,36,0.9)]" />
        </>
      )}

      {/* 7. ELECTRIC EFFECT: Dynamic Voltage Spark Pulse */}
      {effect === 'electric' && (
        <>
          <div 
            className="absolute inset-0 bg-radial from-sky-400/25 via-cyan-500/8 to-transparent blur-2xl pointer-events-none"
            style={{ opacity: Math.max(0.4, intensity * 1.25) }}
          />
          <motion.div
            animate={{ opacity: [0.2, 0.85, 0.15, 0.9, 0.3] }}
            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute -inset-px rounded-[inherit] border border-cyan-400/60 shadow-[0_0_15px_rgba(6,182,212,0.4)] pointer-events-none"
          />
          <div className="absolute top-5 end-7 text-cyan-300/50 drop-shadow-[0_0_10px_#06b6d4]">
            <Zap size={18} />
          </div>
        </>
      )}

      {/* 8. VOID EFFECT: Deep Celestial Cosmic Nebula */}
      {effect === 'void' && (
        <>
          <div 
            className="absolute inset-0 bg-radial from-purple-700/25 via-indigo-900/10 to-transparent blur-3xl pointer-events-none"
            style={{ opacity: Math.max(0.4, intensity * 1.3) }}
          />
          <motion.div
            animate={{ scale: [1, 1.15, 1], opacity: [0.2, 0.5, 0.2] }}
            transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute -top-10 -start-10 w-48 h-48 rounded-full bg-purple-600/20 blur-2xl pointer-events-none"
          />
          <div className="absolute top-5 end-7 text-purple-300/40">
            <Moon size={18} />
          </div>
        </>
      )}

      {/* 9. PHOENIX EFFECT: Golden/Orange Fiery Wings */}
      {effect === 'phoenix' && (
        <>
          <div 
            className="absolute -bottom-10 inset-x-0 h-40 bg-radial from-amber-500/30 via-orange-600/12 to-transparent blur-2xl pointer-events-none"
            style={{ opacity: Math.max(0.4, intensity * 1.3) }}
          />
          <motion.div
            animate={{ y: [0, -12, 0], opacity: [0.4, 0.85, 0.4] }}
            transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute top-5 end-7 text-amber-400/50"
          >
            <Crown size={18} />
          </motion.div>
        </>
      )}

      {/* 10. AURORA EFFECT: Northern Lights Spectral Waves */}
      {effect === 'aurora' && (
        <>
          <motion.div
            animate={{ 
              x: ['-20%', '20%', '-20%'], 
              opacity: [0.35, 0.7, 0.35],
              scaleY: [0.9, 1.15, 0.9]
            }}
            transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute -top-10 inset-x-0 h-52 bg-gradient-to-r from-emerald-500/25 via-teal-400/30 to-cyan-500/25 blur-3xl pointer-events-none"
            style={{ opacity: Math.max(0.4, intensity * 1.35) }}
          />
          <motion.div
            animate={{ 
              y: [-10, 10, -10],
              opacity: [0.2, 0.6, 0.2]
            }}
            transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
            className="absolute top-0 inset-x-0 h-32 bg-gradient-to-b from-teal-400/20 via-cyan-400/10 to-transparent blur-2xl pointer-events-none"
          />
          <div className="absolute top-5 end-7 text-teal-300/60 drop-shadow-[0_0_10px_#2dd4bf]">
            <Sparkles size={18} />
          </div>
        </>
      )}

      {/* 11. SAKURA EFFECT: Crystalline Drifting Petals */}
      {effect === 'sakura' && (
        <>
          <div 
            className="absolute inset-0 bg-radial from-rose-400/15 via-pink-500/5 to-transparent blur-2xl pointer-events-none"
            style={{ opacity: Math.max(0.35, intensity * 1.2) }}
          />
          <motion.div
            animate={{ 
              y: [-20, 180], 
              x: [0, 25, -15, 10], 
              rotate: [0, 180, 360],
              opacity: [0, 0.85, 0.8, 0] 
            }}
            transition={{ duration: 5.5, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute top-4 start-1/4 w-2.5 h-3 rounded-full bg-rose-300/70 blur-[0.3px] shadow-[0_0_8px_#f43f5e]"
          />
          <motion.div
            animate={{ 
              y: [-10, 200], 
              x: [10, -20, 15, -5], 
              rotate: [45, 225, 405],
              opacity: [0, 0.9, 0.7, 0] 
            }}
            transition={{ duration: 6.2, repeat: Infinity, ease: 'easeInOut', delay: 1.8 }}
            className="absolute top-8 end-1/3 w-3 h-3.5 rounded-full bg-pink-200/80 blur-[0.3px] shadow-[0_0_10px_#ec4899]"
          />
          <div className="absolute top-5 end-7 text-pink-300/50">
            <Heart size={16} fill="currentColor" />
          </div>
        </>
      )}

      {/* BORDER STYLE: Shimmer Light Sweep */}
      {borderStyle === 'shimmer' && (
        <motion.div
          animate={{ x: ['-100%', '250%'] }}
          transition={{ duration: 3.2, repeat: Infinity, ease: 'easeInOut', repeatDelay: 1.2 }}
          className="absolute top-0 bottom-0 w-32 bg-gradient-to-r from-transparent via-white/15 to-transparent -skew-x-12 pointer-events-none"
        />
      )}

      {/* BORDER STYLE: Neon Pulse */}
      {(borderStyle === 'pulse' || borderStyle === 'neon') && (
        <motion.div
          animate={{ opacity: borderStyle === 'neon' ? [0.6, 1, 0.6] : [0.3, 0.85, 0.3] }}
          transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
          className={`absolute -inset-px rounded-[inherit] border-2 border-current pointer-events-none ${
            borderStyle === 'neon' ? 'shadow-[0_0_18px_currentColor] opacity-80' : 'opacity-60'
          }`}
        />
      )}
    </div>
  );
};
