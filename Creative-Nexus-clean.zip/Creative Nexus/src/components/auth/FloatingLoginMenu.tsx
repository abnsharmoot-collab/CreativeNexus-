import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const FloatingLoginMenu: React.FC = () => {
  const { isAuthenticated, loginWithDiscord, loading, isLoginModalOpen } = useAuth();
  const { t } = useLanguage();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Show after initial load or when scrolling
    const handleScroll = () => {
      // Appear in front of the user as they scroll
      setIsVisible(true);
    };

    // Make visible after brief delay
    const timer = setTimeout(() => setIsVisible(true), 600);

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      clearTimeout(timer);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Do not show if already logged in or if the full login modal is already open
  if (isAuthenticated || isLoginModalOpen) {
    return null;
  }

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          id="floating-login-menu"
          initial={{ opacity: 0, y: 30, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 30, scale: 0.9 }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="fixed bottom-6 start-1/2 -translate-x-1/2 rtl:translate-x-1/2 z-40 pointer-events-auto"
        >
          <div className="flex items-center gap-3 px-4 py-2.5 rounded-full bg-archive-dark/90 backdrop-blur-2xl border border-archive-cyan/35 shadow-[0_12px_40px_rgba(0,0,0,0.7),0_0_20px_rgba(6,182,212,0.15)] ring-1 ring-white/10 hover:border-archive-cyan/60 transition-all duration-300">
            {/* Discord Icon with Pulsing Online Beacon */}
            <div className="relative flex items-center justify-center w-8 h-8 rounded-full bg-[#5865F2]/20 text-[#5865F2] shrink-0 border border-[#5865F2]/40">
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.893.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
              </svg>
              <span className="absolute -top-0.5 -end-0.5 w-2.5 h-2.5 bg-archive-cyan rounded-full animate-ping opacity-75" />
              <span className="absolute -top-0.5 -end-0.5 w-2.5 h-2.5 bg-archive-cyan rounded-full" />
            </div>

            {/* Single Simple Action Button */}
            <button
              id="floating-discord-login-btn"
              type="button"
              disabled={loading}
              onClick={() => {
                loginWithDiscord();
              }}
              className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#5865F2] hover:bg-[#4752C4] text-white text-xs font-bold shadow-md shadow-[#5865F2]/30 hover:shadow-[#5865F2]/50 transition-all transform active:scale-95 cursor-pointer whitespace-nowrap"
            >
              <span>{loading ? t('auth.connecting') : t('auth.login')}</span>
              <ArrowRight size={14} className="opacity-85" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
