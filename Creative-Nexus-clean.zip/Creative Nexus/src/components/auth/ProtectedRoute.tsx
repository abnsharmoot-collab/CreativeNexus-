import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { Link } from 'react-router-dom';
import { Shield, Lock, ArrowLeft, ArrowRight, LogIn, AlertTriangle, RefreshCw } from 'lucide-react';
import { Permission } from '../../types/auth';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredPermission?: Permission;
  requireOwner?: boolean;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, requiredPermission, requireOwner }) => {
  const { 
    isAuthenticated, 
    loading, 
    user, 
    role, 
    isOwner,
    hasPermission, 
    isMember, 
    refreshSession, 
    loginWithDiscord,
    setIsLoginModalOpen, 
    error 
  } = useAuth();
  const { t, language } = useLanguage();

  if (loading) {
    return (
      <main className="flex-1 min-h-[70vh] flex flex-col items-center justify-center px-4 relative z-10">
        <div className="flex flex-col items-center gap-4">
          <div className="relative w-14 h-14 flex items-center justify-center">
            <div className="w-14 h-14 rounded-full border-2 border-cyan-500/20 border-t-cyan-400 animate-spin" />
            <Shield size={20} className="text-cyan-400" />
          </div>
          <p className="text-sm font-mono text-cyan-400/90 tracking-wider uppercase">
            Verifying Discord RBAC Session...
          </p>
        </div>
      </main>
    );
  }

  // If not logged in:
  if (!isAuthenticated) {
    return (
      <main className="flex-1 min-h-[75vh] flex flex-col items-center justify-center px-4 py-20 relative z-10">
        <div className="max-w-md w-full bg-archive-card border border-archive-cyan/20 rounded-2xl p-8 text-center shadow-2xl shadow-archive-cyan/10 relative overflow-hidden">
          <div className="w-14 h-14 mx-auto mb-6 rounded-full bg-cyan-500/10 border border-cyan-500/25 flex items-center justify-center text-cyan-400">
            <Lock size={24} />
          </div>

          <h2 className="text-2xl font-bold text-archive-paper mb-3">
            {t('auth.required.title')}
          </h2>

          <p className="text-sm text-archive-paper-muted leading-relaxed mb-6">
            Access to the CREATINE NEXUS Staff Center requires an authorized Discord account with verified server membership.
          </p>

          {error && (
            <div className="mb-6 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs">
              {error}
            </div>
          )}

          <div className="flex flex-col gap-3">
            <button
              id="protected-route-discord-login-btn"
              onClick={() => {
                loginWithDiscord();
              }}
              className="w-full flex items-center justify-center gap-3 px-6 py-3.5 rounded-xl font-medium text-sm text-white bg-[#5865F2] hover:bg-[#4752C4] shadow-lg shadow-[#5865F2]/25 hover:shadow-[#5865F2]/45 transition-all duration-300 transform active:scale-95 cursor-pointer"
            >
              <svg className="w-5 h-5 fill-current shrink-0" viewBox="0 0 24 24">
                <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.893.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
              </svg>
              <span>{t('auth.login')}</span>
            </button>

            <Link
              to="/"
              className="w-full flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl font-medium text-xs text-archive-paper-muted hover:text-archive-paper bg-archive-dark/40 border border-archive-cyan/10 hover:border-archive-cyan/30 transition-colors"
            >
              {language === 'ar' ? <ArrowRight size={14} /> : <ArrowLeft size={14} />}
              <span>{t('nav.home')}</span>
            </Link>
          </div>
        </div>
      </main>
    );
  }

  // If logged in, but not a member of CREATINE NEXUS:
  if (!isMember) {
    return (
      <main className="flex-1 min-h-[75vh] flex flex-col items-center justify-center px-4 py-20 relative z-10">
        <div className="max-w-md w-full bg-archive-card border border-amber-500/30 rounded-2xl p-8 text-center shadow-2xl relative overflow-hidden">
          <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <AlertTriangle size={28} />
          </div>

          <h2 className="text-xl font-bold text-archive-paper mb-2">
            Server Membership Required
          </h2>

          <p className="text-xs text-archive-paper-muted leading-relaxed mb-6">
            Your Discord account (<span className="font-mono text-archive-cyan">@{user?.username}</span>) is authenticated, but was not detected as an active member inside the CREATINE NEXUS Discord server.
          </p>

          <div className="flex flex-col gap-3">
            <a
              href="https://discord.gg/7wEm4bhc"
              target="_blank"
              rel="noreferrer"
              className="w-full flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-medium text-xs text-white bg-[#5865F2] hover:bg-[#4752C4] shadow-lg transition-all"
            >
              <span>Join CREATINE NEXUS Discord</span>
            </a>

            <button
              onClick={() => refreshSession()}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-medium text-xs text-archive-cyan bg-archive-cyan/10 hover:bg-archive-cyan/20 border border-archive-cyan/30 transition-all"
            >
              <RefreshCw size={14} />
              <span>Re-check Server Membership</span>
            </button>
          </div>
        </div>
      </main>
    );
  }

  // If owner permission is required and user is not an owner:
  if (requireOwner && !isOwner) {
    return (
      <main className="flex-1 min-h-[75vh] flex flex-col items-center justify-center px-4 py-20 relative z-10">
        <div className="max-w-md w-full bg-archive-card border border-rose-500/40 rounded-2xl p-8 text-center shadow-2xl relative overflow-hidden">
          <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
            <Lock size={28} />
          </div>

          <h2 className="text-xl font-bold text-archive-paper mb-2">
            Owner Authorization Required // صلاحية المالك مطلوبة
          </h2>

          <p className="text-xs text-archive-paper-muted leading-relaxed mb-4">
            This module is exclusively restricted to Server Owners. Regular members and staff without Owner privileges cannot access this area.
          </p>

          <div className="p-3 rounded-xl bg-archive-dark/60 border border-archive-cyan/15 text-xs text-start font-mono text-archive-paper-muted mb-6 space-y-1">
            <div>• Identity: <span className="text-archive-paper">{user?.displayName} (@{user?.username})</span></div>
            <div>• Discord ID: <span className="text-archive-paper">{user?.discordId}</span></div>
            <div>• Role: <span className="text-amber-400 font-bold">{role}</span></div>
            <div>• Owner Clearance: <span className="text-rose-400 font-bold">DENIED</span></div>
          </div>

          <div className="flex flex-col gap-3">
            <Link
              to="/cards"
              className="w-full flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl font-medium text-xs text-[#5eead4] hover:text-white bg-[#5eead4]/10 hover:bg-[#5eead4]/20 border border-[#5eead4]/30 transition-all"
            >
              <span>Back to Card Shop</span>
            </Link>
          </div>
        </div>
      </main>
    );
  }

  // If specific permission is required and user does not have it:
  if (requiredPermission && !hasPermission(requiredPermission)) {
    return (
      <main className="flex-1 min-h-[75vh] flex flex-col items-center justify-center px-4 py-20 relative z-10">
        <div className="max-w-md w-full bg-archive-card border border-rose-500/30 rounded-2xl p-8 text-center shadow-2xl relative overflow-hidden">
          <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
            <Lock size={28} />
          </div>

          <h2 className="text-xl font-bold text-archive-paper mb-2">
            Insufficient Permissions
          </h2>

          <p className="text-xs text-archive-paper-muted leading-relaxed mb-4">
            This administrative module requires the <span className="font-mono text-archive-cyan font-bold">[{requiredPermission}]</span> permission.
          </p>

          <div className="p-3 rounded-xl bg-archive-dark/60 border border-archive-cyan/15 text-xs text-start font-mono text-archive-paper-muted mb-6 space-y-1">
            <div>• Your Identity: <span className="text-archive-paper">{user?.displayName} (@{user?.username})</span></div>
            <div>• Discord Snowflake: <span className="text-archive-paper">{user?.discordId}</span></div>
            <div>• Assigned Role: <span className="text-archive-cyan font-bold">{role}</span></div>
          </div>

          <div className="flex flex-col gap-3">
            <button
              onClick={() => setIsLoginModalOpen(true)}
              className="w-full flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl font-medium text-xs text-archive-paper bg-archive-dark/60 hover:bg-archive-dark/80 border border-archive-cyan/20 transition-colors"
            >
              <LogIn size={14} />
              <span>Switch Discord Account</span>
            </button>

            <Link
              to="/staff-management"
              className="w-full flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl font-medium text-xs text-archive-cyan hover:text-white bg-archive-cyan/10 hover:bg-archive-cyan/20 border border-archive-cyan/30 transition-all"
            >
              <span>Back to Staff Dashboard</span>
            </Link>
          </div>
        </div>
      </main>
    );
  }

  return <>{children}</>;
};
