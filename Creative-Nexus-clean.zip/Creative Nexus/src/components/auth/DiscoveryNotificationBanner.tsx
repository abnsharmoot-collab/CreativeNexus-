import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  Crown, 
  ShieldCheck, 
  Users, 
  Sparkles, 
  X, 
  Settings, 
  ArrowRight,
  Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const DiscoveryNotificationBanner: React.FC = () => {
  const { 
    user, 
    role, 
    isAuthenticated, 
    lastDiscovery, 
    dismissDiscovery, 
    moderatorRoleConfig,
    setIsLoginModalOpen 
  } = useAuth();

  if (!isAuthenticated || !user) return null;

  const currentModRole = moderatorRoleConfig?.moderatorRoleName || 'admin';
  const discoveredAs = user.discoveredAs || (role === 'OWNER' ? 'OWNER' : role === 'MODERATOR' ? 'MODERATOR' : 'MEMBER');

  return (
    <div id="discovery-notification-banner" className="w-full mb-6">
      <div className={`w-full rounded-2xl p-4 border shadow-xl backdrop-blur-xl relative overflow-hidden transition-all ${
        discoveredAs === 'OWNER'
          ? 'bg-gradient-to-r from-amber-500/15 via-archive-dark/90 to-amber-500/10 border-amber-500/30'
          : discoveredAs === 'MODERATOR'
          ? 'bg-gradient-to-r from-indigo-500/15 via-archive-dark/90 to-indigo-500/10 border-indigo-500/30'
          : 'bg-gradient-to-r from-emerald-500/15 via-archive-dark/90 to-emerald-500/10 border-emerald-500/30'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3.5">
            {/* Identity Icon */}
            <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border ${
              discoveredAs === 'OWNER'
                ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                : discoveredAs === 'MODERATOR'
                ? 'bg-indigo-500/20 text-indigo-400 border-indigo-500/40'
                : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
            }`}>
              {discoveredAs === 'OWNER' && <Crown size={22} />}
              {discoveredAs === 'MODERATOR' && <ShieldCheck size={22} />}
              {discoveredAs === 'MEMBER' && <Users size={22} />}
            </div>

            {/* Discovery Information */}
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <span className="text-[10px] uppercase font-bold tracking-wider text-archive-paper-muted">
                  Discord Account Identity Discovered:
                </span>
                
                {discoveredAs === 'OWNER' && (
                  <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-amber-500/25 text-amber-300 border border-amber-500/40">
                    👑 THE SERVER OWNER
                  </span>
                )}
                {discoveredAs === 'MODERATOR' && (
                  <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/25 text-indigo-300 border border-indigo-500/40">
                    🛡️ A MODERATOR (MODERATOR VIEW)
                  </span>
                )}
                {discoveredAs === 'MEMBER' && (
                  <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/25 text-emerald-300 border border-emerald-500/40">
                    👤 A NORMAL MEMBER (MEMBER VIEW)
                  </span>
                )}

                <span className="text-xs text-archive-paper font-semibold">
                  {user.displayName} (@{user.username})
                </span>
              </div>

              {/* Discovery Description */}
              <p className="text-xs text-archive-paper-muted leading-relaxed">
                {discoveredAs === 'OWNER' && (
                  <>
                    Logged in as the Guild Sovereign. You have master control over the website, staff roster, and the <strong className="text-amber-300">Moderator Discord Role Selector</strong> below.
                  </>
                )}
                {discoveredAs === 'MODERATOR' && (
                  <>
                    Discovered as <strong className="text-indigo-300">A Moderator</strong> because your Discord account role matches the Owner's configured role (<strong className="text-amber-300 font-mono">"{currentModRole}"</strong>). You are viewing the <strong className="text-indigo-300">Moderator View</strong> with full staff review and point management permissions.
                  </>
                )}
                {discoveredAs === 'MEMBER' && (
                  <>
                    Discovered as <strong className="text-emerald-300">A Normal Member</strong>. You have citizen read-only access. To receive the Moderator view, an account must have the Discord role <strong className="text-amber-300 font-mono">"{currentModRole}"</strong> chosen by the Server Owner.
                  </>
                )}
              </p>
            </div>
          </div>

          {/* Action pill / Switch test user */}
          <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
            <button
              id="switch-identity-btn"
              onClick={() => setIsLoginModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-archive-dark/80 hover:bg-archive-cyan/15 text-archive-paper border border-archive-cyan/20 text-xs font-medium flex items-center gap-1.5 transition-all"
            >
              <Settings size={13} />
              <span>Switch Identity</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
