import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { X, Copy, Check, ExternalLink, ShieldAlert, Key } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const OAuthConfigModal: React.FC = () => {
  const { showConfigGuide, setShowConfigGuide, oauthConfig } = useAuth();
  const { t } = useLanguage();
  const [copiedField, setCopiedField] = useState<string | null>(null);

  if (!showConfigGuide) return null;

  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : '';
  const callbackUrl = oauthConfig?.redirectUri || `${currentOrigin}/auth/discord/callback`;

  // Compute dev and preview URLs dynamically based on current origin
  const devUrl = callbackUrl;
  const sharedUrl = currentOrigin.includes('ais-dev-') 
    ? callbackUrl.replace('ais-dev-', 'ais-pre-')
    : callbackUrl;

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-archive-dark/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-xl bg-archive-card border border-archive-cyan/20 rounded-2xl p-6 shadow-2xl shadow-archive-cyan/10 overflow-hidden"
        >
          {/* Header */}
          <div className="flex items-start justify-between mb-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                <Key size={20} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-archive-paper">
                  Discord OAuth2 Setup
                </h3>
                <p className="text-xs text-archive-paper-muted">
                  Configure Discord Developer Portal to enable authentication
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowConfigGuide(false)}
              className="p-1.5 rounded-lg text-archive-paper-muted hover:text-archive-paper hover:bg-archive-dark/50 transition-colors"
            >
              <X size={18} />
            </button>
          </div>

          {/* Setup steps */}
          <div className="space-y-4 text-sm text-archive-paper-muted">
            <div className="bg-archive-dark/60 rounded-xl p-4 border border-archive-cyan/10 space-y-3">
              <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-archive-cyan">
                <span>1. Discord Developer Portal</span>
                <a
                  href="https://discord.com/developers/applications"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1 text-archive-cyan hover:underline"
                >
                  Open Portal <ExternalLink size={12} />
                </a>
              </div>
              <p className="text-xs">
                In your Discord Application &gt; <strong>OAuth2</strong> &gt; <strong>Redirects</strong>, add these callback URLs:
              </p>

              {/* Dev Callback URL */}
              <div>
                <label className="text-[11px] font-mono text-archive-paper-muted block mb-1">
                  Development Redirect URI:
                </label>
                <div className="flex items-center gap-2 bg-black/40 rounded-lg p-2 font-mono text-xs text-archive-cyan/90 border border-archive-cyan/20">
                  <span className="truncate flex-1">{devUrl}</span>
                  <button
                    onClick={() => copyToClipboard(devUrl, 'dev')}
                    className="p-1 text-archive-paper-muted hover:text-archive-cyan transition-colors"
                    title="Copy URI"
                  >
                    {copiedField === 'dev' ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                  </button>
                </div>
              </div>

              {/* Shared Callback URL */}
              <div>
                <label className="text-[11px] font-mono text-archive-paper-muted block mb-1">
                  Shared / Deployed Redirect URI:
                </label>
                <div className="flex items-center gap-2 bg-black/40 rounded-lg p-2 font-mono text-xs text-archive-cyan/90 border border-archive-cyan/20">
                  <span className="truncate flex-1">{sharedUrl}</span>
                  <button
                    onClick={() => copyToClipboard(sharedUrl, 'shared')}
                    className="p-1 text-archive-paper-muted hover:text-archive-cyan transition-colors"
                    title="Copy URI"
                  >
                    {copiedField === 'shared' ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                  </button>
                </div>
              </div>
            </div>

            <div className="bg-archive-dark/60 rounded-xl p-4 border border-archive-cyan/10 space-y-2">
              <div className="text-xs font-semibold uppercase tracking-wider text-archive-cyan">
                2. Add Environment Variables
              </div>
              <p className="text-xs leading-relaxed">
                Copy your Discord <strong>Client ID</strong> and <strong>Client Secret</strong> into the AI Studio project Settings &gt; Secrets:
              </p>
              <ul className="text-xs font-mono list-disc list-inside space-y-1 text-archive-paper">
                <li><span className="text-archive-cyan">Client ID</span>: 1548702834755637369</li>
                <li><span className="text-archive-cyan">Client Secret</span>: (Configured securely on server)</li>
              </ul>
            </div>
          </div>

          {/* Action button */}
          <div className="mt-6 flex justify-end">
            <button
              onClick={() => setShowConfigGuide(false)}
              className="px-5 py-2 rounded-xl text-xs font-semibold bg-archive-cyan/20 text-archive-cyan border border-archive-cyan/40 hover:bg-archive-cyan/30 transition-all"
            >
              Got It
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
