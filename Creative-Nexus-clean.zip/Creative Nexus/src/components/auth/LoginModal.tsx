import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { 
  X, 
  AlertCircle, 
  ArrowRight, 
  Loader2,
  ShieldCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const LoginModal: React.FC = () => {
  const { 
    isLoginModalOpen, 
    setIsLoginModalOpen, 
    error: authError,
    clearError,
    loading,
    loginWithDiscord
  } = useAuth();
  const { language } = useLanguage();
  const [redirecting, setRedirecting] = useState(false);

  const isAr = language === 'ar';

  if (!isLoginModalOpen) return null;

  const handleOAuthLogin = () => {
    clearError();
    setRedirecting(true);
    loginWithDiscord();
  };

  return (
    <AnimatePresence>
      <div 
        id="login-modal-overlay"
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-archive-dark/85 backdrop-blur-md"
        onClick={() => setIsLoginModalOpen(false)}
      >
        <motion.div
          id="login-modal-card"
          initial={{ opacity: 0, scale: 0.94, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 15 }}
          transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-sm bg-archive-card/95 border border-archive-cyan/25 rounded-2xl p-6 shadow-2xl relative backdrop-blur-xl text-center"
        >
          {/* Close button */}
          <button
            id="close-login-modal-btn"
            onClick={() => setIsLoginModalOpen(false)}
            className="absolute top-4 end-4 p-1.5 rounded-lg text-archive-paper-muted hover:text-archive-paper hover:bg-archive-cyan/10 transition-colors"
            aria-label="Close"
          >
            <X size={18} />
          </button>

          {/* Discord Icon */}
          <div className="mx-auto w-14 h-14 rounded-2xl bg-[#5865F2] text-white flex items-center justify-center shadow-lg shadow-[#5865F2]/30 mb-4">
            <svg className="w-8 h-8 fill-current" viewBox="0 0 24 24">
              <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.893.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
            </svg>
          </div>

          {/* Heading */}
          <h2 className="text-xl font-bold text-archive-paper mb-2">
            {isAr ? 'تسجيل الدخول عبر ديسكورد' : 'Sign In with Discord'}
          </h2>
          <p className="text-xs text-archive-paper-muted leading-relaxed mb-6">
            {isAr 
              ? 'سجّل دخولك بحساب ديسكورد ليتم فحص رتبك وصلاحياتك في السيرفر تلقائياً.'
              : 'Sign in with your Discord account to automatically verify your server roles and permissions.'}
          </p>

          {/* Error message */}
          {authError && (
            <div className="mb-5 p-3 rounded-xl bg-rose-500/10 border border-rose-500/25 text-rose-400 text-xs text-start flex items-start gap-2">
              <AlertCircle size={16} className="shrink-0 mt-0.5" />
              <span className="leading-relaxed">{authError}</span>
            </div>
          )}

          {/* Discord Login Button */}
          <button
            id="discord-login-button"
            type="button"
            onClick={handleOAuthLogin}
            disabled={loading || redirecting}
            className="w-full py-3 px-4 rounded-xl bg-[#5865F2] hover:bg-[#4752C4] active:scale-[0.98] text-white font-bold text-sm flex items-center justify-center gap-2.5 shadow-lg shadow-[#5865F2]/25 hover:shadow-[#5865F2]/40 transition-all cursor-pointer disabled:opacity-60"
          >
            {loading || redirecting ? (
              <>
                <Loader2 size={18} className="animate-spin" />
                <span>{isAr ? 'جاري الاتصال بديسكورد...' : 'Connecting to Discord...'}</span>
              </>
            ) : (
              <>
                <svg className="w-5 h-5 fill-current shrink-0" viewBox="0 0 24 24">
                  <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.893.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
                </svg>
                <span>{isAr ? 'تسجيل الدخول' : 'Sign In'}</span>
                <ArrowRight size={15} />
              </>
            )}
          </button>

          {/* Secure badge */}
          <div className="mt-5 pt-4 border-t border-archive-cyan/10 flex items-center justify-center gap-1.5 text-[11px] text-archive-paper-muted">
            <ShieldCheck size={14} className="text-archive-cyan" />
            <span>{isAr ? 'حماية مشفرة عبر OAuth2 الرسمي' : 'Official Discord OAuth2 Protection'}</span>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
