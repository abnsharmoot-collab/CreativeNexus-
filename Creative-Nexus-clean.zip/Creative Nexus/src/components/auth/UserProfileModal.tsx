import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { useStaff } from '../../context/StaffContext';
import { useAchievements } from '../../context/AchievementContext';
import { useCards } from '../../context/CardContext';
import { getTierForPoints } from '../../types/rankMap';
import { 
  X, Copy, Check, Shield, User, Calendar, LogOut, 
  Award, Trophy, ExternalLink, Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({ isOpen, onClose }) => {
  const { user, role, logout } = useAuth();
  const { t, language } = useLanguage();
  const isAr = language === 'ar';
  const navigate = useNavigate();
  const { staff } = useStaff();
  const { stats, evaluateMemberAchievements } = useAchievements();
  const { coins, profile: cardProfile, playerProfile } = useCards();

  const [copied, setCopied] = useState(false);

  if (!isOpen || !user) return null;

  // Find staff dossier if this user is a registered staff member
  const staffMember = staff.find(
    (s) => s.discordId === user.discordId || String(s.id) === user.discordId
  );

  const currentTier = staffMember ? getTierForPoints(staffMember.points) : null;
  const memberAchievements = staffMember ? evaluateMemberAchievements(staffMember) : [];
  const unlockedCount = staffMember
    ? memberAchievements.filter((a) => a.isUnlocked).length
    : stats.unlockedCount;

  const copyDiscordId = () => {
    navigator.clipboard.writeText(user.discordId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-lg bg-archive-card border border-archive-cyan/25 rounded-2xl shadow-2xl shadow-black/80 overflow-hidden my-auto max-h-[90dvh] flex flex-col"
        >
          {/* Top Banner / Cover */}
          <div className="relative h-24 sm:h-28 bg-gradient-to-r from-archive-cyan/20 via-indigo-900/40 to-archive-dark border-b border-archive-cyan/15 flex items-start justify-between p-4 shrink-0">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider bg-archive-dark/80 text-archive-cyan border border-archive-cyan/30 backdrop-blur-sm">
                CREATINE NEXUS IDENTITY
              </span>
            </div>
            
            {/* Close button */}
            <button
              onClick={onClose}
              aria-label="Close"
              className="p-2 rounded-xl text-archive-paper-muted hover:text-archive-paper bg-archive-dark/60 hover:bg-archive-dark border border-archive-cyan/20 transition-all cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>

          {/* User Info Header with protruding Avatar */}
          <div className="px-5 sm:px-6 pt-0 pb-4 border-b border-archive-cyan/10 shrink-0">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 -mt-12 sm:-mt-14 mb-3">
              {/* Avatar with Status Ring */}
              <div className="relative inline-block self-start">
                <img
                  src={user.avatarUrl}
                  alt={user.displayName}
                  className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl border-2 border-archive-cyan shadow-[0_0_20px_rgba(6,182,212,0.35)] object-cover bg-archive-dark"
                />
                <span 
                  className="absolute -bottom-1 -end-1 w-5 h-5 bg-emerald-500 border-2 border-archive-dark rounded-full shadow-md" 
                  title="Online on Discord" 
                />
              </div>

              {/* Badges / Roles */}
              <div className="flex flex-wrap items-center gap-2">
                <span className={`px-3 py-1 rounded-xl text-xs font-mono font-bold tracking-wide border shadow-sm ${
                  role === 'OWNER'
                    ? 'bg-amber-500/15 text-amber-300 border-amber-500/40 shadow-amber-500/10'
                    : role === 'MODERATOR'
                    ? 'bg-indigo-500/15 text-indigo-300 border-indigo-500/40 shadow-indigo-500/10'
                    : 'bg-archive-cyan/15 text-archive-cyan border-archive-cyan/40 shadow-archive-cyan/10'
                }`}>
                  {role === 'OWNER' ? '👑 OWNER' : role === 'MODERATOR' ? '🛡️ MODERATOR' : '👤 COMMUNITY MEMBER'}
                </span>
                
                {staffMember && (
                  <span className="px-2.5 py-1 rounded-xl text-xs font-mono font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                    ⚡ STAFF MEMBER
                  </span>
                )}
              </div>
            </div>

            {/* Names */}
            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-archive-paper tracking-wide">
                {user.displayName}
              </h3>
              <p className="text-xs sm:text-sm font-mono text-archive-cyan/80">
                @{user.username}
              </p>
              {playerProfile?.selectedTitle && (
                <div className="pt-1.5 flex items-center gap-1.5">
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg text-[11px] font-mono font-bold tracking-wider uppercase bg-amber-500/15 text-amber-300 border border-amber-500/30">
                    <Award size={12} className="text-amber-400" />
                    <span>{isAr ? playerProfile.selectedTitle.nameAr : playerProfile.selectedTitle.name}</span>
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Scrollable Content Body */}
          <div className="flex-1 overflow-y-auto custom-scrollbar px-5 sm:px-6 py-4 space-y-4">
            {/* Player Profile Card Identity Progression Hero Card */}
            {playerProfile && (
              <div className="p-4 rounded-2xl bg-gradient-to-br from-[#072421] via-[#041917] to-[#020e0d] border border-[rgba(158,255,230,0.25)] shadow-lg space-y-3 relative overflow-hidden">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-[#5eead4]/15 text-[#5eead4]">
                      <Sparkles size={15} />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                        {isAr ? 'منظومة تقدم اللاعب' : 'PLAYER PROGRESSION'}
                      </p>
                      <p className="text-[10px] text-[#8db8b1]">
                        {isAr ? 'المستوى وتقدم جمع البطاقات' : 'Level progression & card collection matrix'}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onClose();
                      navigate(`/profile/${user.discordId}`);
                    }}
                    className="flex items-center gap-1 px-3 py-1 rounded-xl text-xs font-bold text-amber-300 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 transition-all cursor-pointer shadow-xs"
                  >
                    <span>{isAr ? 'الملف الكامل' : 'Open Profile'}</span>
                    <ExternalLink size={12} />
                  </button>
                </div>

                {/* Level & XP */}
                <div className="space-y-1.5 pt-1">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="font-bold text-amber-300">
                      LEVEL {playerProfile.progression.level}
                    </span>
                    <span className="text-[#8db8b1] text-[11px]">
                      {playerProfile.progression.xpIntoLevel.toLocaleString()} / {playerProfile.progression.xpNeededForNextLevel.toLocaleString()} XP ({playerProfile.progression.progressPercent}%)
                    </span>
                  </div>

                  <div className="w-full h-2 rounded-full bg-black/60 overflow-hidden border border-white/10 p-0.5">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-amber-500 to-[#5eead4] transition-all duration-500"
                      style={{ width: `${playerProfile.progression.progressPercent}%` }}
                    />
                  </div>
                </div>

                {/* Quick stats mini-row */}
                <div className="grid grid-cols-3 gap-2 pt-1">
                  <div className="p-2 rounded-xl bg-black/40 border border-white/5 text-center">
                    <p className="text-[9px] font-mono uppercase text-[#8db8b1]">{isAr ? 'البطاقات' : 'Total'}</p>
                    <p className="text-xs font-bold font-mono text-white">{playerProfile.stats.totalCards}</p>
                  </div>
                  <div className="p-2 rounded-xl bg-black/40 border border-white/5 text-center">
                    <p className="text-[9px] font-mono uppercase text-[#8db8b1]">{isAr ? 'الفريدة' : 'Unique'}</p>
                    <p className="text-xs font-bold font-mono text-amber-300">{playerProfile.stats.uniqueCards}</p>
                  </div>
                  <div className="p-2 rounded-xl bg-black/40 border border-white/5 text-center">
                    <p className="text-[9px] font-mono uppercase text-[#8db8b1]">{isAr ? 'أسطوري' : 'Legendary'}</p>
                    <p className="text-xs font-bold font-mono text-amber-400">{playerProfile.stats.legendaryCount}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Staff Dossier & Progression Card (if staff) */}
            {staffMember && currentTier ? (
              <div className="p-4 rounded-xl bg-gradient-to-br from-archive-dark/90 to-archive-card border border-archive-cyan/25 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Award size={16} className="text-archive-cyan" />
                    <span className="text-xs font-bold uppercase tracking-wider text-archive-paper">
                      {isAr ? 'الملف الإداري والرتبة' : 'Staff Dossier & Rank Tier'}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      onClose();
                      navigate(`/staff-management/${staffMember.id}`);
                    }}
                    className="flex items-center gap-1 text-xs font-medium text-archive-cyan hover:underline"
                  >
                    <span>{isAr ? 'عرض الملف الكامل' : 'Full Profile'}</span>
                    <ExternalLink size={12} />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div className="p-2.5 rounded-lg bg-archive-dark/60 border border-archive-cyan/10">
                    <p className="text-[10px] font-mono text-archive-paper-muted">{isAr ? 'الرتبة الميدانية' : 'Current Rank'}</p>
                    <p className="text-xs sm:text-sm font-bold text-archive-cyan truncate">{currentTier.name}</p>
                  </div>
                  <div className="p-2.5 rounded-lg bg-archive-dark/60 border border-archive-cyan/10">
                    <p className="text-[10px] font-mono text-archive-paper-muted">{isAr ? 'رصيد النقاط' : 'Rank Points'}</p>
                    <p className="text-xs sm:text-sm font-bold text-amber-300 font-mono">{staffMember.points} PTS</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-3.5 rounded-xl bg-archive-dark/60 border border-archive-cyan/15 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Sparkles size={16} className="text-archive-cyan" />
                  <div>
                    <p className="text-xs font-bold text-archive-paper">
                      {isAr ? 'عضوية مركز الإبداع' : 'Creatine Nexus Community'}
                    </p>
                    <p className="text-[11px] text-archive-paper-muted">
                      {isAr ? 'تتبع إنجازاتك ورتب السيرفر التفاعلية' : 'Track achievements & discover rank progression'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    onClose();
                    navigate('/rank-points');
                  }}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-medium text-archive-cyan bg-archive-cyan/10 hover:bg-archive-cyan/20 border border-archive-cyan/30 transition-colors shrink-0"
                >
                  {isAr ? 'خريطة الرتب' : 'Rank Map'}
                </button>
              </div>
            )}

            {/* Achievements Snapshot Card */}
            <div className="p-3.5 rounded-xl bg-archive-dark/60 border border-archive-cyan/15 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  <Trophy size={16} />
                </div>
                <div>
                  <p className="text-xs font-bold text-archive-paper">
                    {isAr ? 'الإنجازات المكتسبة' : 'Earned Achievements'}
                  </p>
                  <p className="text-[11px] font-mono text-amber-300">
                    {unlockedCount} / {stats.totalCount} {isAr ? 'مكتمل' : 'Unlocked'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  onClose();
                  navigate('/achievements');
                }}
                className="px-2.5 py-1.5 rounded-lg text-xs font-medium text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 transition-colors shrink-0"
              >
                {isAr ? 'استعراض' : 'Showcase'}
              </button>
            </div>

            {/* Discord User ID with Copy */}
            <div className="bg-archive-dark/60 rounded-xl p-3 border border-archive-cyan/15 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-archive-paper-muted">
                <User size={14} className="text-archive-cyan" />
                <span>Discord User ID</span>
              </div>
              <div className="flex items-center gap-2 font-mono text-xs text-archive-paper">
                <span className="select-all">{user.discordId}</span>
                <button
                  onClick={copyDiscordId}
                  className="p-1 rounded hover:bg-archive-cyan/10 hover:text-archive-cyan transition-colors"
                  title="Copy Discord ID"
                >
                  {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                </button>
              </div>
            </div>

            {/* Guild Status & Session Security */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div className="bg-archive-dark/60 rounded-xl p-3 border border-archive-cyan/15 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-archive-paper-muted">
                  <Shield size={14} className="text-archive-cyan" />
                  <span>{isAr ? 'حالة التوثيق' : 'Guild Status'}</span>
                </div>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Verified
                </span>
              </div>

              <div className="bg-archive-dark/60 rounded-xl p-3 border border-archive-cyan/15 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-archive-paper-muted">
                  <Calendar size={14} className="text-archive-cyan" />
                  <span>{isAr ? 'جلسة الاتصال' : 'Session'}</span>
                </div>
                <span className="text-[11px] font-mono text-archive-paper-muted">
                  HMAC-SHA256
                </span>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="p-4 bg-archive-dark/80 border-t border-archive-cyan/15 flex items-center justify-between gap-3 shrink-0">
            <button
              onClick={() => {
                logout();
                onClose();
              }}
              className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-medium text-rose-400 bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500/20 transition-all cursor-pointer"
            >
              <LogOut size={14} />
              <span>{t('auth.logout')}</span>
            </button>

            <button
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl text-xs font-semibold bg-archive-cyan/20 text-archive-cyan border border-archive-cyan/40 hover:bg-archive-cyan/30 transition-all cursor-pointer"
            >
              {isAr ? 'إغلاق' : 'Close'}
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

