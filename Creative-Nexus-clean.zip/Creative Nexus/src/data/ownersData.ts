import { OwnerStats } from '../context/OwnerCardBackgroundsContext';

export interface BaseOwnerDefinition {
  cardId: string;
  fallbackCardId?: string;
  numericId?: number;
  romanNumeral: string;
  nameKey: string;
  defaultName: string;
  titleKey: string;
  defaultTitle: string;
  descKey: string;
  defaultDesc: string;
  badgeKey: string;
  defaultBadge: string;
  status: 'present' | 'former';
  country?: 'egypt' | 'iraq' | 'uae' | string;
  defaultAccent: string;
  defaultAvatar: string;
  defaultCharacterArtwork?: string;
  defaultDiscordHandle?: string;
  defaultDiscordId?: string;
  defaultStats: OwnerStats;
  era: string;
  joinedYear: string;
  highlightType: string;
}

export const BASE_OWNERS: BaseOwnerDefinition[] = [
  {
    cardId: 'owner_edgar',
    numericId: 0,
    romanNumeral: 'SOVEREIGN',
    nameKey: 'owner.edgar.name',
    defaultName: 'Edgar',
    titleKey: 'owner.edgar.title',
    defaultTitle: 'Server Owner & Sovereign Creator',
    descKey: 'owner.edgar.desc',
    defaultDesc: 'The artist, content creator, and live streamer at the heart of CREATIVE NEXUS. Edgar built this sanctuary to bring together his fans, celebrate creative arts, host captivating live streams, and offer a joyful home where everyone can express talent and have unforgettable fun.',
    badgeKey: 'owner.edgar.badge',
    defaultBadge: 'The Creative Sovereign & Streamer',
    status: 'present',
    country: 'egypt',
    defaultAccent: 'amber',
    defaultAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    defaultDiscordHandle: 'edgar_creator',
    defaultDiscordId: '871043296280076308',
    defaultStats: {
      leadership: 99,
      activity: 95,
      management: 98,
      communication: 96,
      creativity: 100,
      reliability: 97,
    },
    era: 'Sovereign Era',
    joinedYear: '2023',
    highlightType: 'solar',
  },
  {
    cardId: 'history_owner_1',
    fallbackCardId: 'owner_kevin',
    numericId: 1,
    romanNumeral: 'I',
    nameKey: 'owner.1.name',
    defaultName: 'Kevin',
    titleKey: 'owner.1.title',
    defaultTitle: 'Server Owner & Co-Founder',
    descKey: 'owner.1.desc',
    defaultDesc: 'Co-founder of CREATIVE NEXUS who helped Edgar establish the initial server structure and foundations.',
    badgeKey: 'owner.1.badge',
    defaultBadge: 'The Genesis',
    status: 'former',
    defaultAccent: 'amber',
    defaultAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
    defaultDiscordHandle: 'kevin_genesis',
    defaultStats: {
      leadership: 88,
      activity: 72,
      management: 85,
      communication: 80,
      creativity: 86,
      reliability: 84,
    },
    era: 'Genesis 2023',
    joinedYear: '2023',
    highlightType: 'standard',
  },
  {
    cardId: 'history_owner_2',
    fallbackCardId: 'owner_sh3la',
    numericId: 2,
    romanNumeral: 'II',
    nameKey: 'owner.2.name',
    defaultName: 'Sh3la',
    titleKey: 'owner.2.title',
    defaultTitle: 'Server Owner & The Eternal Flame',
    descKey: 'owner.2.desc',
    defaultDesc: 'One of the most monumental figures in server history. A brother, mentor, and unwavering pillar whose fiery loyalty forged the bedrock of CREATIVE NEXUS.',
    badgeKey: 'owner.2.badge',
    defaultBadge: 'The Golden Chapter',
    status: 'former',
    defaultAccent: 'orange',
    defaultAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
    defaultDiscordHandle: 'sh3la_flame',
    defaultStats: {
      leadership: 96,
      activity: 88,
      management: 94,
      communication: 91,
      creativity: 90,
      reliability: 98,
    },
    era: 'Golden Chapter 2023',
    joinedYear: '2023',
    highlightType: 'chronicle',
  },
  {
    cardId: 'history_owner_3',
    fallbackCardId: 'owner_hamo',
    numericId: 3,
    romanNumeral: 'III',
    nameKey: 'owner.hamo.name',
    defaultName: 'Hamo',
    titleKey: 'owner.hamo.title',
    defaultTitle: 'Server Developer & Owner',
    descKey: 'owner.hamo.desc',
    defaultDesc: 'The server developer who contributed greatly to server history and became an Owner through unmatched architectural innovation.',
    badgeKey: 'owner.hamo.badge',
    defaultBadge: 'The Programmer',
    status: 'former',
    defaultAccent: 'purple',
    defaultAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&auto=format&fit=crop&q=80',
    defaultDiscordHandle: 'hamo_dev',
    defaultStats: {
      leadership: 85,
      activity: 82,
      management: 89,
      communication: 86,
      creativity: 98,
      reliability: 92,
    },
    era: 'Rise 2023',
    joinedYear: '2023',
    highlightType: 'code',
  },
  {
    cardId: 'history_owner_4',
    fallbackCardId: 'owner_super',
    numericId: 4,
    romanNumeral: 'IV',
    nameKey: 'owner.super.name',
    defaultName: 'Super',
    titleKey: 'owner.super.title',
    defaultTitle: 'Server Owner',
    descKey: 'owner.super.desc',
    defaultDesc: 'The youngest and one of the kindest among them, navigating the server through turbulent times with heartfelt warmth.',
    badgeKey: 'owner.super.badge',
    defaultBadge: 'The Young Luminary',
    status: 'former',
    defaultAccent: 'cyan',
    defaultAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=400&auto=format&fit=crop&q=80',
    defaultDiscordHandle: 'super_luminary',
    defaultStats: {
      leadership: 84,
      activity: 86,
      management: 80,
      communication: 94,
      creativity: 88,
      reliability: 87,
    },
    era: 'Ascent 2024',
    joinedYear: '2024',
    highlightType: 'youth',
  },
  {
    cardId: 'history_owner_5',
    fallbackCardId: 'owner_osama',
    numericId: 5,
    romanNumeral: 'V',
    nameKey: 'owner.osama.name',
    defaultName: 'Osama',
    titleKey: 'owner.osama.title',
    defaultTitle: 'Server Owner & Voyager',
    descKey: 'owner.osama.desc',
    defaultDesc: 'A distinguished leader and beloved figure in server history whose steady guidance shaped memorable milestones.',
    badgeKey: 'owner.osama.badge',
    defaultBadge: 'The Horizon Voyager',
    status: 'former',
    defaultAccent: 'amber',
    defaultAvatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&auto=format&fit=crop&q=80',
    defaultDiscordHandle: 'osama_voyager',
    defaultStats: {
      leadership: 88,
      activity: 83,
      management: 87,
      communication: 89,
      creativity: 85,
      reliability: 90,
    },
    era: 'Exploration 2024',
    joinedYear: '2024',
    highlightType: 'voyager',
  },
  {
    cardId: 'history_owner_6',
    fallbackCardId: 'owner_adham',
    numericId: 6,
    romanNumeral: 'VI',
    nameKey: 'owner.adham.name',
    defaultName: 'Adham',
    titleKey: 'owner.adham.title',
    defaultTitle: 'Former Owner & Vanguard',
    descKey: 'owner.adham.desc',
    defaultDesc: 'One of the administrators and leaders who took part in a crucial chapter of the server alongside Super and Osama.',
    badgeKey: 'owner.adham.badge',
    defaultBadge: 'The Vanguard',
    status: 'former',
    defaultAccent: 'cyan',
    defaultAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&auto=format&fit=crop&q=80',
    defaultDiscordHandle: 'adham_vanguard',
    defaultStats: {
      leadership: 86,
      activity: 80,
      management: 88,
      communication: 82,
      creativity: 81,
      reliability: 89,
    },
    era: 'Vanguard 2024',
    joinedYear: '2024',
    highlightType: 'vanguard',
  },
  {
    cardId: 'history_owner_7',
    fallbackCardId: 'owner_shadow',
    numericId: 7,
    romanNumeral: 'VII',
    nameKey: 'owner.shadow.name',
    defaultName: 'SHADOW',
    titleKey: 'owner.shadow.title',
    defaultTitle: 'Server Owner & Eternal Heart',
    descKey: 'owner.shadow.desc',
    defaultDesc: 'The wife of the server owner and an enduring pillar of care, compassion, and strength throughout the community.',
    badgeKey: 'owner.shadow.badge',
    defaultBadge: 'Eternal Heart',
    status: 'present',
    defaultAccent: 'rose',
    defaultAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80',
    defaultDiscordHandle: 'shadow_heart',
    defaultDiscordId: '1099135885699727460',
    defaultStats: {
      leadership: 95,
      activity: 94,
      management: 96,
      communication: 99,
      creativity: 94,
      reliability: 98,
    },
    era: 'Golden Era 2024',
    joinedYear: '2024',
    highlightType: 'romantic',
  },
  {
    cardId: 'history_owner_8',
    fallbackCardId: 'owner_abysswolf',
    numericId: 8,
    romanNumeral: 'VIII',
    nameKey: 'owner.abysswolf.name',
    defaultName: 'ABYSSWOLF',
    titleKey: 'owner.abysswolf.title',
    defaultTitle: 'Server Owner & Radiant Protector',
    descKey: 'owner.abysswolf.desc',
    defaultDesc: 'The second kindest person in the world, loyal leader, and chief architect of the Golden Era.',
    badgeKey: 'owner.abysswolf.badge',
    defaultBadge: 'The Radiant Protector',
    status: 'present',
    country: 'uae',
    defaultAccent: 'emerald',
    defaultAvatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=400&auto=format&fit=crop&q=80',
    defaultDiscordHandle: 'abysswolf_uae',
    defaultDiscordId: '831102094521532418',
    defaultStats: {
      leadership: 97,
      activity: 96,
      management: 97,
      communication: 95,
      creativity: 96,
      reliability: 99,
    },
    era: 'Golden Era 2024',
    joinedYear: '2024',
    highlightType: 'guardian',
  },
  {
    cardId: 'history_owner_9',
    fallbackCardId: 'owner_kohan',
    numericId: 9,
    romanNumeral: 'IX',
    nameKey: 'owner.kohan.name',
    defaultName: 'KOHAN',
    titleKey: 'owner.kohan.title',
    defaultTitle: 'Server Owner & Heart of Mesopotamia',
    descKey: 'owner.kohan.desc',
    defaultDesc: 'One of the kindest people in the world and one of the greatest supporters of Edgar and the CREATIVE NEXUS community.',
    badgeKey: 'owner.kohan.badge',
    defaultBadge: 'Heart of Mesopotamia',
    status: 'present',
    country: 'iraq',
    defaultAccent: 'amber',
    defaultAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&auto=format&fit=crop&q=80',
    defaultDiscordHandle: 'kohan_official',
    defaultDiscordId: '1306936292197797929',
    defaultStats: {
      leadership: 98,
      activity: 97,
      management: 95,
      communication: 98,
      creativity: 97,
      reliability: 99,
    },
    era: 'Golden Era 2024',
    joinedYear: '2024',
    highlightType: 'warmth',
  },
  {
    cardId: 'history_owner_10',
    fallbackCardId: 'owner_luigi',
    numericId: 10,
    romanNumeral: 'X',
    nameKey: 'owner.luigi.name',
    defaultName: 'LUIGI',
    titleKey: 'owner.luigi.title',
    defaultTitle: 'Server Owner & Golden Vanguard',
    descKey: 'owner.luigi.desc',
    defaultDesc: 'A key custodian and owner sustaining the vibrancy, resilience, and strength of the Golden Era.',
    badgeKey: 'owner.luigi.badge',
    defaultBadge: 'Golden Vanguard',
    status: 'present',
    defaultAccent: 'cyan',
    defaultAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=400&auto=format&fit=crop&q=80',
    defaultDiscordHandle: 'luigi_vanguard',
    defaultDiscordId: '1371864097523765358',
    defaultStats: {
      leadership: 93,
      activity: 95,
      management: 92,
      communication: 91,
      creativity: 94,
      reliability: 96,
    },
    era: 'Golden Era 2024',
    joinedYear: '2024',
    highlightType: 'vanguard',
  },
  {
    cardId: 'history_owner_11',
    fallbackCardId: 'owner_yuzu',
    numericId: 11,
    romanNumeral: 'XI',
    nameKey: 'owner.yuzu.name',
    defaultName: 'YUZU',
    titleKey: 'owner.yuzu.title',
    defaultTitle: 'Server Owner & The Eternal Guardian',
    descKey: 'owner.yuzu.desc',
    defaultDesc: 'A dedicated owner and vital pillar in CREATIVE NEXUS, supporting Edgar and the community with unwavering devotion and leadership.',
    badgeKey: 'owner.yuzu.badge',
    defaultBadge: 'The Eternal Guardian',
    status: 'present',
    defaultAccent: 'emerald',
    defaultAvatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&auto=format&fit=crop&q=80',
    defaultDiscordHandle: 'yuzu_guardian',
    defaultStats: {
      leadership: 94,
      activity: 93,
      management: 94,
      communication: 93,
      creativity: 92,
      reliability: 97,
    },
    era: 'Golden Era 2024',
    joinedYear: '2024',
    highlightType: 'guardian',
  },
];

/**
 * Normalizes input key (e.g. 'owner_edgar', 'edgar', '9', 'kohan', 'history_owner_9')
 * into the primary cardId and matching base definition.
 */
export function findBaseOwner(key: string): BaseOwnerDefinition | undefined {
  if (!key) return undefined;
  const clean = key.toLowerCase().trim();

  // Direct matches
  const direct = BASE_OWNERS.find(
    (o) =>
      o.cardId.toLowerCase() === clean ||
      o.fallbackCardId?.toLowerCase() === clean ||
      o.defaultName.toLowerCase() === clean ||
      String(o.numericId) === clean
  );
  if (direct) return direct;

  // Partial or slug match
  if (clean === 'edgar' || clean.includes('edgar')) {
    return BASE_OWNERS.find((o) => o.cardId === 'owner_edgar');
  }
  if (clean === 'sh3la' || clean === 'she3la' || clean.includes('sh3la')) {
    return BASE_OWNERS.find((o) => o.cardId === 'history_owner_2');
  }
  if (clean === 'hamo' || clean.includes('hamo')) {
    return BASE_OWNERS.find((o) => o.cardId === 'history_owner_3');
  }
  if (clean === 'super' || clean.includes('super')) {
    return BASE_OWNERS.find((o) => o.cardId === 'history_owner_4');
  }
  if (clean === 'osama' || clean.includes('osama')) {
    return BASE_OWNERS.find((o) => o.cardId === 'history_owner_5');
  }
  if (clean === 'adham' || clean.includes('adham')) {
    return BASE_OWNERS.find((o) => o.cardId === 'history_owner_6');
  }
  if (clean === 'shadow' || clean.includes('shadow')) {
    return BASE_OWNERS.find((o) => o.cardId === 'history_owner_7');
  }
  if (clean === 'abysswolf' || clean.includes('abyss') || clean.includes('wolf')) {
    return BASE_OWNERS.find((o) => o.cardId === 'history_owner_8');
  }
  if (clean === 'kohan' || clean.includes('kohan')) {
    return BASE_OWNERS.find((o) => o.cardId === 'history_owner_9');
  }
  if (clean === 'luigi' || clean.includes('luigi')) {
    return BASE_OWNERS.find((o) => o.cardId === 'history_owner_10');
  }
  if (clean === 'yuzu' || clean.includes('yuzu')) {
    return BASE_OWNERS.find((o) => o.cardId === 'history_owner_11');
  }
  if (clean === 'kevin' || clean.includes('kevin')) {
    return BASE_OWNERS.find((o) => o.cardId === 'history_owner_1');
  }

  // Numeric extracted (e.g. 'history_owner_7' -> 7)
  const numMatch = clean.match(/\d+/);
  if (numMatch) {
    const num = parseInt(numMatch[0], 10);
    const byNum = BASE_OWNERS.find((o) => o.numericId === num);
    if (byNum) return byNum;
  }

  return undefined;
}
