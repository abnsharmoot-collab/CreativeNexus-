import { HandbookBook } from '../types/handbook';
import { Permission } from '../types/auth';

export interface ServerRule {
  id: number;
  title: string;
  body: string;
  category: 'community' | 'safety' | 'moderation';
  categoryLabelEn: string;
  categoryLabelAr: string;
}

export const OFFICIAL_SERVER_RULES: ServerRule[] = [
  {
    id: 1,
    title: '🤝 الاحترام أولاً',
    body: 'يُمنع إهانة أو سب أو التقليل من أي عضو أو مشرف داخل السيرفر.',
    category: 'community',
    categoryLabelEn: 'Community Conduct',
    categoryLabelAr: 'السلوك المجتمعي'
  },
  {
    id: 2,
    title: '🔞 ممنوع المحتوى الجنسي',
    body: 'يُمنع نشر أو طلب أي محتوى جنسي أو إباحي أو NSFW داخل السيرفر.',
    category: 'safety',
    categoryLabelEn: 'Safety & Security',
    categoryLabelAr: 'الأمان والحماية'
  },
  {
    id: 3,
    title: '🚫 ممنوع التحرش أو المضايقة',
    body: 'يُمنع التحرش بالأعضاء أو إرسال رسائل غير مرغوب فيها أو غير لائقة.',
    category: 'safety',
    categoryLabelEn: 'Safety & Security',
    categoryLabelAr: 'الأمان والحماية'
  },
  {
    id: 4,
    title: '💬 ممنوع السب الزائد',
    body: 'يُمنع استخدام الألفاظ البذيئة بشكل مزعج أو موجه ضد الآخرين.',
    category: 'community',
    categoryLabelEn: 'Community Conduct',
    categoryLabelAr: 'السلوك المجتمعي'
  },
  {
    id: 5,
    title: '📢 ممنوع السبام',
    body: 'يُمنع إرسال نفس الرسالة أو الإيموجي أو المنشن بشكل متكرر.',
    category: 'community',
    categoryLabelEn: 'Community Conduct',
    categoryLabelAr: 'السلوك المجتمعي'
  },
  {
    id: 6,
    title: '📣 ممنوع المنشن العشوائي',
    body: 'يُمنع عمل منشن للأعضاء أو الرتب بدون سبب أو بشكل مزعج.',
    category: 'community',
    categoryLabelEn: 'Community Conduct',
    categoryLabelAr: 'السلوك المجتمعي'
  },
  {
    id: 7,
    title: '🔗 ممنوع نشر الروابط المشبوهة',
    body: 'يُمنع إرسال روابط قد تكون ضارة أو احتيالية أو تحتوي على ملفات خطيرة.',
    category: 'safety',
    categoryLabelEn: 'Safety & Security',
    categoryLabelAr: 'الأمان والحماية'
  },
  {
    id: 8,
    title: '📢 ممنوع الإعلان بدون إذن',
    body: 'يُمنع الإعلان عن سيرفرات أو حسابات أو خدمات أخرى دون موافقة الإدارة.',
    category: 'community',
    categoryLabelEn: 'Community Conduct',
    categoryLabelAr: 'السلوك المجتمعي'
  },
  {
    id: 9,
    title: '🎭 ممنوع انتحال الشخصية',
    body: 'يُمنع انتحال شخصية عضو آخر أو أحد أفراد الإدارة.',
    category: 'safety',
    categoryLabelEn: 'Safety & Security',
    categoryLabelAr: 'الأمان والحماية'
  },
  {
    id: 10,
    title: '🕵️ ممنوع كشف المعلومات الخاصة',
    body: 'يُمنع نشر معلومات شخصية عن أي شخص دون موافقته.',
    category: 'safety',
    categoryLabelEn: 'Safety & Security',
    categoryLabelAr: 'الأمان والحماية'
  },
  {
    id: 11,
    title: '⚔️ ممنوع إثارة المشاكل',
    body: 'يُمنع افتعال المشاكل أو محاولة إشعال الخلافات بين الأعضاء.',
    category: 'community',
    categoryLabelEn: 'Community Conduct',
    categoryLabelAr: 'السلوك المجتمعي'
  },
  {
    id: 12,
    title: '🧨 ممنوع التخريب',
    body: 'يُمنع تخريب القنوات أو استغلال البوتات أو الصلاحيات بطريقة تضر بالسيرفر.',
    category: 'safety',
    categoryLabelEn: 'Safety & Security',
    categoryLabelAr: 'الأمان والحماية'
  },
  {
    id: 13,
    title: '🤖 ممنوع استغلال البوتات',
    body: 'يُمنع استخدام أوامر البوتات بطريقة مزعجة أو بهدف تعطيل السيرفر.',
    category: 'safety',
    categoryLabelEn: 'Safety & Security',
    categoryLabelAr: 'الأمان والحماية'
  },
  {
    id: 14,
    title: '🎙️ احترام الرومات الصوتية',
    body: 'يُمنع تشغيل أصوات مزعجة أو استخدام المايك بطريقة تزعج الآخرين.',
    category: 'community',
    categoryLabelEn: 'Community Conduct',
    categoryLabelAr: 'السلوك المجتمعي'
  },
  {
    id: 15,
    title: '🛑 احترام قرارات الإدارة',
    body: 'يجب الالتزام بتعليمات المشرفين والإدارة طالما أنها ضمن قوانين السيرفر.',
    category: 'moderation',
    categoryLabelEn: 'Moderation Authority',
    categoryLabelAr: 'القرارات الإدارية'
  },
  {
    id: 16,
    title: '🚨 ممنوع التهديد',
    body: 'يُمنع تهديد الأعضاء أو تخويفهم أو محاولة ابتزازهم.',
    category: 'safety',
    categoryLabelEn: 'Safety & Security',
    categoryLabelAr: 'الأمان والحماية'
  },
  {
    id: 17,
    title: '🖼️ ممنوع المحتوى غير اللائق',
    body: 'يُمنع نشر صور أو فيديوهات أو ملصقات غير مناسبة أو مخالفة لقوانين السيرفر.',
    category: 'safety',
    categoryLabelEn: 'Safety & Security',
    categoryLabelAr: 'الأمان والحماية'
  },
  {
    id: 18,
    title: '⚠️ الإبلاغ عن المخالفات',
    body: 'إذا رأيت مخالفة، قم بإبلاغ الإدارة بدل الدخول في مشكلة مع العضو.',
    category: 'community',
    categoryLabelEn: 'Community Conduct',
    categoryLabelAr: 'السلوك المجتمعي'
  },
  {
    id: 19,
    title: '👑 العقوبات بيد الإدارة',
    body: 'يحق للإدارة اتخاذ الإجراء المناسب ضد أي مخالفة، مثل التحذير أو الميوت أو التايم أوت أو الطرد أو البان، حسب شدة المخالفة.',
    category: 'moderation',
    categoryLabelEn: 'Moderation Authority',
    categoryLabelAr: 'القرارات الإدارية'
  },
  {
    id: 20,
    title: '🏳️‍🌈 منع الترويج للمثلية',
    body: 'يُمنع نشر أو الترويج للمحتوى أو العلاقات المثلية داخل السيرفر، كما يُمنع تحويل القنوات إلى نقاشات أو محتوى متعلق بها. ويُرجى الالتزام بقواعد السيرفر واحترام جميع الأعضاء دون إساءة أو تنمر.',
    category: 'moderation',
    categoryLabelEn: 'Moderation Authority',
    categoryLabelAr: 'القرارات الإدارية'
  }
];

export interface SystemPermissionDoc {
  key: Permission;
  nameEn: string;
  nameAr: string;
  descEn: string;
  descAr: string;
  tier: 'OWNER' | 'ADMIN' | 'STAFF';
}

export const OFFICIAL_PERMISSIONS: SystemPermissionDoc[] = [
  {
    key: 'VIEW_DASHBOARD',
    nameEn: 'View Dashboard',
    nameAr: 'عرض لوحة العمليات',
    descEn: 'Access the high-level server operations dashboard, health metrics, and live telemetry.',
    descAr: 'الاطلاع على لوحة العمليات والإحصائيات الحية ومؤشرات استقرار السيرفر.',
    tier: 'STAFF'
  },
  {
    key: 'VIEW_STAFF',
    nameEn: 'View Staff Directory',
    nameAr: 'استعراض طاقم الإدارة',
    descEn: 'View the staff directory, member cards, point tallies, and progression standings.',
    descAr: 'الاطلاع على قائمة الإداريين، بطاقاتهم، رصيد نقاطهم وتدرجهم الإداري.',
    tier: 'STAFF'
  },
  {
    key: 'VIEW_AUDIT_LOG',
    nameEn: 'View Audit Logs',
    nameAr: 'عرض سجل العمليات والتدقيق',
    descEn: 'Inspect irreversible historical records of staff changes, point transactions, and promotions.',
    descAr: 'الاطلاع على سجلات التدقيق التاريخية للعمليات وتعديلات الرتب وحركات النقاط.',
    tier: 'STAFF'
  },
  {
    key: 'ADD_POINTS',
    nameEn: 'Add Points',
    nameAr: 'إضافة النقاط الإدارية',
    descEn: 'Credit merit points to staff members for verified moderation duties and stream support.',
    descAr: 'منح نقاط استحقاق للإداريين نظير المهام الإشرافية وتنظيم فعاليات البث.',
    tier: 'ADMIN'
  },
  {
    key: 'REMOVE_POINTS',
    nameEn: 'Remove Points',
    nameAr: 'خصم النقاط الإدارية',
    descEn: 'Deduct points with mandatory documented reason for infractions or inactivity.',
    descAr: 'خصم نقاط مع إلزامية توثيق السبب للمخالفات أو فترات الخمول.',
    tier: 'ADMIN'
  },
  {
    key: 'MANAGE_POINTS',
    nameEn: 'Manage All Points',
    nameAr: 'إدارة كامل سجلات النقاط',
    descEn: 'Full administrative authority to audit, adjust, and reconcile staff point ledgers.',
    descAr: 'صلاحية إدارية شاملة لمراجعة وتسوية موازين النقاط لكافة الطاقم.',
    tier: 'ADMIN'
  },
  {
    key: 'EDIT_STAFF',
    nameEn: 'Edit Staff Profile',
    nameAr: 'تعديل بيانات الإداري',
    descEn: 'Update administrative notes, status flags, and performance records.',
    descAr: 'تحديث الملاحظات الإدارية وتوثيق تقارير الأداء الفردية.',
    tier: 'ADMIN'
  },
  {
    key: 'ADD_STAFF',
    nameEn: 'Add Staff Member',
    nameAr: 'تعيين إداري جديد',
    descEn: 'Induct newly qualified Discord members into the active staff tracking system.',
    descAr: 'ضم أعضاء مؤهلين من ديسكورد إلى قاعدة بيانات الإدارة المعتمدة.',
    tier: 'ADMIN'
  },
  {
    key: 'SUSPEND_STAFF',
    nameEn: 'Suspend Staff',
    nameAr: 'تجميد عضوية إداري',
    descEn: 'Temporarily freeze staff permissions and point progression pending review.',
    descAr: 'إيقاف الصلاحيات الإدارية وتجميد النشاط مؤقتاً لحين انتهاء التحقيق.',
    tier: 'ADMIN'
  },
  {
    key: 'REMOVE_STAFF',
    nameEn: 'Remove Staff',
    nameAr: 'استبعاد عضو من الإدارة',
    descEn: 'Permanently remove a staff member from the active roster with full audit trail.',
    descAr: 'استبعاد الإداري من الطاقم بشكل نهائي وتوثيق العملية في سجل التدقيق.',
    tier: 'ADMIN'
  },
  {
    key: 'MANAGE_STAFF',
    nameEn: 'Manage Staff Operations',
    nameAr: 'إدارة العمليات الإدارية',
    descEn: 'High-level supervision over team shifts, moderation protocols, and department allocation.',
    descAr: 'إشراف كلي على توزيع المهام وتنظيم النوبات وتوجيه الأقسام.',
    tier: 'ADMIN'
  },
  {
    key: 'MANAGE_ROLES',
    nameEn: 'Manage Discord Role Sync',
    nameAr: 'إدارة مزامنة رتب ديسكورد',
    descEn: 'Configure Discord role mapping, snowflake IDs, and synchronization webhooks.',
    descAr: 'ضبط معرّفات رتب ديسكورد (Snowflake IDs) وقواعد المزامنة مع المنصة.',
    tier: 'OWNER'
  },
  {
    key: 'MANAGE_SERVER_SETTINGS',
    nameEn: 'Manage Server Settings',
    nameAr: 'إدارة إعدادات السيرفر',
    descEn: 'Modify guild parameters, bot credentials, and platform integration bridges.',
    descAr: 'تعديل معايير السيرفر، ربط البوتات وبوابات الاتصال الآمنة.',
    tier: 'OWNER'
  },
  {
    key: 'OWNER_CONTROL',
    nameEn: 'Supreme Sovereign Control',
    nameAr: 'السيادة والسيطرة المطلقة للمالك',
    descEn: 'Exclusive sovereign prerogative of the Server Owner. Mandatory for final promotion approvals.',
    descAr: 'الولاية الحصرية لمالك السيرفر؛ إلزامية لاعتماد كافة طلبات ترقيات الرتب.',
    tier: 'OWNER'
  }
];

export const HANDBOOK_BOOKS: HandbookBook[] = [
  {
    id: 'guide-getting-started',
    bookNumber: 'GUIDE 01',
    titleEn: 'GETTING STARTED',
    titleAr: 'البداية والتعريف بالمنصة',
    subtitleEn: 'Platform Overview, Navigation & Access Rights',
    subtitleAr: 'نظرة عامة، التنقل، ومستويات الوصول',
    descriptionEn: 'Quick introduction to CREATIVE NEXUS: how to navigate the portal, sign in with Discord, and understand what each role can access.',
    descriptionAr: 'دليل سريع لمركز الابداع (CREATIVE NEXUS): كيفية التنقل بين الأقسام، تسجيل الدخول بديسكورد، وفهم مستويات الوصول والصلاحيات.',
    iconName: 'Compass',
    accentColor: 'cyan',
    gradient: 'from-[#2dd4bf]/20 via-[#14b8a6]/10 to-transparent',
    borderColor: 'border-[#2dd4bf]/30 hover:border-[#5eead4]/60',
    tagEn: 'Getting Started',
    tagAr: 'البداية',
    relatedPath: '/',
    chapters: [
      {
        id: 'ch-gs-what-is',
        chapterNumber: '01',
        titleEn: 'What is CREATIVE NEXUS?',
        titleAr: 'ما هو موقع مركز الابداع؟',
        subtitleEn: 'Official community hub for artist & streamer Edgar',
        subtitleAr: 'المنصة الرسمية لمجتمع الفنان والستريمر Edgar',
        readingTimeMinutes: 1
      },
      {
        id: 'ch-gs-navigation',
        chapterNumber: '02',
        titleEn: 'Navigation & Portals',
        titleAr: 'التنقل وأقسام الموقع',
        subtitleEn: 'Top navigation bar, mobile menu, and primary pages',
        subtitleAr: 'الشريط العلوي، القائمة الجانبية، والأقسام الرئيسية',
        readingTimeMinutes: 1
      },
      {
        id: 'ch-gs-signin',
        chapterNumber: '03',
        titleEn: 'Discord Sign-In',
        titleAr: 'تسجيل الدخول بديسكورد',
        subtitleEn: 'Fast and secure login with live profile & role sync',
        subtitleAr: 'دخول سريع وآمن مع مزامنة فورية للرتب والملف',
        readingTimeMinutes: 1
      },
      {
        id: 'ch-gs-access',
        chapterNumber: '04',
        titleEn: 'Access Tiers & Permissions',
        titleAr: 'مستويات الوصول والصلاحيات',
        subtitleEn: 'Visitors, Community Members, Staff, and Leadership',
        subtitleAr: 'الزوار، أعضاء المجتمع، الطاقم الإداري، والقيادة',
        readingTimeMinutes: 2
      }
    ]
  },
  {
    id: 'guide-profile',
    bookNumber: 'GUIDE 02',
    titleEn: 'YOUR PROFILE',
    titleAr: 'الملف الشخصي والحساب',
    subtitleEn: 'Discord Identity, Badges & Privacy',
    subtitleAr: 'بيانات ديسكورد، الأوسمة، والخصوصية',
    descriptionEn: 'Quick overview of your profile drawer: Discord identity, assigned server roles, unlocked badges, and data privacy.',
    descriptionAr: 'دليل ملفك الشخصي: بيانات ديسكورد المتزامنة، رتبك في السيرفر، الأوسمة المحققة، وأمان وخصوصية الحساب.',
    iconName: 'User',
    accentColor: 'cyan',
    gradient: 'from-[#5eead4]/20 via-[#2dd4bf]/10 to-transparent',
    borderColor: 'border-[#5eead4]/30 hover:border-[#5eead4]/60',
    tagEn: 'Profile',
    tagAr: 'الملف الشخصي',
    relatedPath: '/',
    chapters: [
      {
        id: 'ch-prof-card',
        chapterNumber: '01',
        titleEn: 'Profile Drawer & Discord Identity',
        titleAr: 'الملف الشخصي وبيانات ديسكورد',
        subtitleEn: 'Avatar, username, snowflake ID, and server roles',
        subtitleAr: 'الصورة، الاسم، المعرّف الرقمي، ورتب السيرفر',
        readingTimeMinutes: 1
      },
      {
        id: 'ch-prof-achieve',
        chapterNumber: '02',
        titleEn: 'Achievements & Progress',
        titleAr: 'الأوسمة ونسبة التقدم',
        subtitleEn: 'Unlocked badges summary and completion rate',
        subtitleAr: 'ملخص الأوسمة المكتسبة ونسبة إنجاز المهام',
        readingTimeMinutes: 1
      },
      {
        id: 'ch-prof-data',
        chapterNumber: '03',
        titleEn: 'Account Privacy & Data Safety',
        titleAr: 'خصوصية الحساب وأمان البيانات',
        subtitleEn: 'Only public Discord data is used; no passwords stored',
        subtitleAr: 'استخدام بيانات ديسكورد العامة فقط دون حفظ كلمات مرور',
        readingTimeMinutes: 1
      }
    ]
  },
  {
    id: 'guide-achievements',
    bookNumber: 'GUIDE 03',
    titleEn: 'ACHIEVEMENTS',
    titleAr: 'الأوسمة والإنجازات',
    subtitleEn: 'Categories, Automated Progress & Showcase',
    subtitleAr: 'التصنيفات، احتساب التقدم، ومقبس العرض',
    descriptionEn: 'How the achievements system works: categories, automatic progress tracking based on activity, secret badges, and the profile showcase.',
    descriptionAr: 'كيف يعمل نظام الأوسمة: التصنيفات، احتساب التقدم تلقائياً من النشاط، الأوسمة السرية، واستعراضها في المقابس.',
    iconName: 'Trophy',
    accentColor: 'amber',
    gradient: 'from-[#f6d98a]/20 via-[#d97706]/10 to-transparent',
    borderColor: 'border-[#f6d98a]/35 hover:border-[#f6d98a]/70',
    tagEn: 'Achievements',
    tagAr: 'الأوسمة',
    relatedPath: '/achievements',
    chapters: [
      {
        id: 'ch-ach-concept',
        chapterNumber: '01',
        titleEn: 'Achievement Categories',
        titleAr: 'تصنيفات الأوسمة',
        subtitleEn: 'Moderation, Community, Loyalty, Operations, and Special',
        subtitleAr: 'الإشراف، المجتمع، الولاء، العمليات، والأوسمة الخاصة',
        readingTimeMinutes: 1
      },
      {
        id: 'ch-ach-progress',
        chapterNumber: '02',
        titleEn: 'Progress Tracking & Secrets',
        titleAr: 'احتساب التقدم والأوسمة السرية',
        subtitleEn: 'Automatic calculations from account activity and hidden feats',
        subtitleAr: 'احتساب تلقائي من نشاط حسابك وإنجازات مخفية',
        readingTimeMinutes: 2
      },
      {
        id: 'ch-ach-display',
        chapterNumber: '03',
        titleEn: 'Showcase Sockets & Rarity',
        titleAr: 'مقابس العرض ودرجات الندرة',
        subtitleEn: 'Equipping badge sockets, glow borders, and rarity tiers',
        subtitleAr: 'تثبيت الأوسمة في المقابس، إطارات التوهج، ودرجات التميز',
        readingTimeMinutes: 1
      }
    ]
  },
  {
    id: 'guide-rank-points',
    bookNumber: 'GUIDE 04',
    titleEn: 'RANK & POINTS',
    titleAr: 'النقاط ومسار الترقية',
    subtitleEn: 'Merit Points, 34 Ranks Map & Promotion Rules',
    subtitleAr: 'نقاط الاستحقاق، 34 رتبة، وضوابط الترقية',
    descriptionEn: 'The staff merit point system and 34-tier rank progression: point thresholds, four major tiers, application steps, and Discord role separation.',
    descriptionAr: 'نظام نقاط الاستحقاق الإداري ومسار الترقية عبر 34 رتبة: عتبات النقاط، الأقسام الأربعة، خطوات التقديم، وتوضيح رتب ديسكورد.',
    iconName: 'TrendingUp',
    accentColor: 'amber',
    gradient: 'from-[#f6d98a]/25 via-[#2dd4bf]/10 to-transparent',
    borderColor: 'border-[#f6d98a]/40 hover:border-[#f6d98a]/80',
    tagEn: 'Ranks & Points',
    tagAr: 'النقاط والرتب',
    relatedPath: '/rank-points',
    chapters: [
      {
        id: 'ch-rnk-points',
        chapterNumber: '01',
        titleEn: 'Staff Points System',
        titleAr: 'نظام نقاط الاستحقاق',
        subtitleEn: 'How points are earned for stream support and moderation',
        subtitleAr: 'معايير منح النقاط للإشراف ومساندة بثوث Edgar',
        readingTimeMinutes: 1
      },
      {
        id: 'ch-rnk-map',
        chapterNumber: '02',
        titleEn: 'The 4 Major Progression Tiers',
        titleAr: 'الأقسام الأربعة لمسار الرتب',
        subtitleEn: 'Foundation (0-45), Core (50-110), Senior (120-200), Council (210-280+)',
        subtitleAr: 'التأسيسية، التشغيلية، الإشراف المتقدم، والمجلس الأعلى',
        readingTimeMinutes: 2
      },
      {
        id: 'ch-rnk-thresholds',
        chapterNumber: '03',
        titleEn: '34 Ranks & Point Milestones',
        titleAr: 'الرتب الـ 34 وعتبات النقاط',
        subtitleEn: 'Complete score table required for each rank tier',
        subtitleAr: 'جدول النقاط الدقيق المطلوب لكل رتبة إدارية',
        readingTimeMinutes: 2
      },
      {
        id: 'ch-rnk-discord-note',
        chapterNumber: '04',
        titleEn: 'Promotion Flow & Discord Roles',
        titleAr: 'خطوات الترقية وتوضيح رتب ديسكورد',
        subtitleEn: 'Owner Edgar approval required; Discord roles are separate',
        subtitleAr: 'اعتماد المالك إلزامي؛ ورتب ديسكورد لا تتغير تلقائياً',
        readingTimeMinutes: 1
      }
    ]
  },
  {
    id: 'guide-applications',
    bookNumber: 'GUIDE 05',
    titleEn: 'APPLICATIONS',
    titleAr: 'طلبات الترقية الإدارية',
    subtitleEn: 'Submissions, Status Tracking & Owner Approvals',
    subtitleAr: 'تقديم الطلبات، متابعة الحالة، واعتماد المالك',
    descriptionEn: 'How rank applications work: qualifying for a new tier, submitting with notes, tracking review status, and Owner Edgar’s approval.',
    descriptionAr: 'كيفية تقديم طلبات الترقية: التأهل بالنصاب، تقديم الطلب مع الملاحظات، متابعة حالة المراجعة، واعتماد المالك Edgar.',
    iconName: 'ClipboardList',
    accentColor: 'indigo',
    gradient: 'from-[#7c8cff]/20 via-[#2dd4bf]/10 to-transparent',
    borderColor: 'border-[#7c8cff]/35 hover:border-[#7c8cff]/70',
    tagEn: 'Applications',
    tagAr: 'الطلبات',
    relatedPath: '/rank-points',
    chapters: [
      {
        id: 'ch-app-submit',
        chapterNumber: '01',
        titleEn: 'Submitting a Rank Application',
        titleAr: 'تقديم طلب الترقية',
        subtitleEn: 'Threshold criteria, application button, and optional notes',
        subtitleAr: 'بلوغ نصاب النقاط، زر التقديم، وإضافة ملاحظات الإنجاز',
        readingTimeMinutes: 1
      },
      {
        id: 'ch-app-status',
        chapterNumber: '02',
        titleEn: 'Application Lifecycle & Statuses',
        titleAr: 'حالات الطلب ومراحل المراجعة',
        subtitleEn: 'Not Applied, Pending, Approved, and Rejected states',
        subtitleAr: 'غير مقدم، قيد المراجعة، تم الاعتماد، والطلب مرفوض',
        readingTimeMinutes: 1
      },
      {
        id: 'ch-app-review',
        chapterNumber: '03',
        titleEn: 'Owner Review & Subsequent Ranks',
        titleAr: 'اعتماد المالك والترقية التالية',
        subtitleEn: 'Sole review by Owner Edgar; fresh application per rank',
        subtitleAr: 'مراجعة المالك Edgar حصرياً؛ وطلب مستقل لكل رتبة جديدة',
        readingTimeMinutes: 1
      }
    ]
  },
  {
    id: 'guide-notifications',
    bookNumber: 'GUIDE 06',
    titleEn: 'NOTIFICATIONS',
    titleAr: 'مركز التنبيهات',
    subtitleEn: 'Alert Inbox, Unread Counters & Event Types',
    subtitleAr: 'صندوق التنبيهات، شارة غير المقروء، وأنواع الإشعارات',
    descriptionEn: 'Stay updated in real time: how the navbar bell works, unread counters, bulk read actions, and what dispatches you will receive.',
    descriptionAr: 'ابقَ على اطلاع لحظي: طريقة عمل جرس الإشعارات، عداد غير المقروء، التحديد السريع، وأهم التنبيهات الصادرة لحسابك.',
    iconName: 'Bell',
    accentColor: 'cyan',
    gradient: 'from-[#5eead4]/20 via-[#14b8a6]/10 to-transparent',
    borderColor: 'border-[#5eead4]/30 hover:border-[#5eead4]/60',
    tagEn: 'Notifications',
    tagAr: 'الإشعارات',
    relatedPath: '/notifications',
    chapters: [
      {
        id: 'ch-notif-center',
        chapterNumber: '01',
        titleEn: 'Notification Hub & Unread Badges',
        titleAr: 'مركز الإشعارات وشارة غير المقروء',
        subtitleEn: 'Navbar bell, dropdown preview, and mark-all-read action',
        subtitleAr: 'أيقونة الجرس، المعاينة السريعة، وتحديد الكل كمقروء',
        readingTimeMinutes: 1
      },
      {
        id: 'ch-notif-events',
        chapterNumber: '02',
        titleEn: 'Notification Types & Dispatches',
        titleAr: 'أنواع الإشعارات والتنبيهات',
        subtitleEn: 'Rank decisions, merit points, official broadcasts, and badges',
        subtitleAr: 'قرارات الترقية، تعديلات النقاط، الإعلانات، والأوسمة',
        readingTimeMinutes: 1
      }
    ]
  },
  {
    id: 'guide-announcements',
    bookNumber: 'GUIDE 07',
    titleEn: 'ANNOUNCEMENTS',
    titleAr: 'الإعلانات الرسمية',
    subtitleEn: 'Verified Dispatches, Pinned Notices & Reading Experience',
    subtitleAr: 'البيانات الرسمية، الإعلانات المثبتة، وأسلوب التصفح',
    descriptionEn: 'Official creator broadcasts, stream schedules, pinned alerts, formatted reading view, and high-resolution image lightboxes.',
    descriptionAr: 'بيانات السيرفر الرسمية، مواعيد بثوث Edgar، الإعلانات المثبتة، المقالات المنسقة، وتكبير الصور بدقة عالية.',
    iconName: 'Megaphone',
    accentColor: 'amber',
    gradient: 'from-[#f6d98a]/20 via-[#f97316]/10 to-transparent',
    borderColor: 'border-[#f6d98a]/30 hover:border-[#f6d98a]/60',
    tagEn: 'Announcements',
    tagAr: 'الإعلانات',
    relatedPath: '/announcements',
    chapters: [
      {
        id: 'ch-ann-official',
        chapterNumber: '01',
        titleEn: 'Official Broadcasts & Pinned Alerts',
        titleAr: 'البيانات المعتمدة والإعلانات المثبتة',
        subtitleEn: 'Verified leadership posts, timestamps, and top-pinned priority',
        subtitleAr: 'منشورات القيادة الموثقة، التواريخ، وأولوية التثبيت بالقمة',
        readingTimeMinutes: 1
      },
      {
        id: 'ch-ann-reading',
        chapterNumber: '02',
        titleEn: 'Reading Articles & Media Lightbox',
        titleAr: 'قراءة المقالات وتكبير الصور',
        subtitleEn: 'Clean formatted typography, fullscreen zoom, and sharing',
        subtitleAr: 'نصوص منسقة سهلة القراءة، استعراض الصور، ومشاركة الرابط',
        readingTimeMinutes: 1
      }
    ]
  },
  {
    id: 'guide-history',
    bookNumber: 'GUIDE 08',
    titleEn: 'HISTORY & ORIGINS',
    titleAr: 'التاريخ ونشأة السيرفر',
    subtitleEn: 'Server Origins & 4 Historical Eras',
    subtitleAr: 'نشأة السيرفر والحقب الأربعة',
    descriptionEn: 'The chronicle of CREATIVE NEXUS: how the community started with Edgar and the four development eras.',
    descriptionAr: 'سجل ذكريات وتاريخ مركز الابداع: قصة التأسيس مع الفنان Edgar والحقب التاريخية الأربعة.',
    iconName: 'History',
    accentColor: 'cyan',
    gradient: 'from-[#5eead4]/20 via-[#f6d98a]/10 to-transparent',
    borderColor: 'border-[#5eead4]/35 hover:border-[#f6d98a]/60',
    tagEn: 'History',
    tagAr: 'التاريخ',
    relatedPath: '/history',
    chapters: [
      {
        id: 'ch-hist-origins',
        chapterNumber: '01',
        titleEn: 'Server Origins & Community Vision',
        titleAr: 'نشأة السيرفر ورسالة المجتمع',
        subtitleEn: 'The founding vision with artist & streamer Edgar',
        subtitleAr: 'بداية المجتمع والرسالة الفنية والإبداعية للتأسيس',
        readingTimeMinutes: 1
      },
      {
        id: 'ch-hist-eras',
        chapterNumber: '02',
        titleEn: 'The 4 Historical Eras',
        titleAr: 'الحقب التاريخية الأربعة',
        subtitleEn: 'Genesis, Expansion, Institutional, and Modern Digital',
        subtitleAr: 'التأسيس، التوسع، التنظيم الإداري، والمنظومة الحديثة',
        readingTimeMinutes: 2
      }
    ]
  },
  {
    id: 'guide-rules',
    bookNumber: 'GUIDE 09',
    titleEn: 'SERVER RULES',
    titleAr: 'القوانين الرسمية',
    subtitleEn: 'The 20 Server Rules & Moderation Steps',
    subtitleAr: 'القوانين العشرون وخطوات التعامل الإداري',
    descriptionEn: 'The official 20 server rules preserved in authentic wording with search & category filters, plus the progressive moderation escalation steps.',
    descriptionAr: 'القوانين الرسمية العشرون المعتمدة بالسيرفر مع البحث والفلترة حسب التصنيف، إضافة إلى خطوات التدرج في العقوبات الإدارية.',
    iconName: 'ScrollText',
    accentColor: 'emerald',
    gradient: 'from-[#2dd4bf]/20 via-[#10b981]/10 to-transparent',
    borderColor: 'border-[#2dd4bf]/35 hover:border-[#5eead4]/60',
    tagEn: 'Server Rules',
    tagAr: 'القوانين الرسمية',
    chapters: [
      {
        id: 'ch-rules-list',
        chapterNumber: '01',
        titleEn: 'The 20 Official Rules',
        titleAr: 'القوانين الرسمية العشرون',
        subtitleEn: 'Full text with official numbering, categories, and quick search',
        subtitleAr: 'النص المعتمد مع الأرقام، التصنيفات، والبحث السريع',
        readingTimeMinutes: 3
      },
      {
        id: 'ch-rules-escalation',
        chapterNumber: '02',
        titleEn: 'Disciplinary Escalation Steps',
        titleAr: 'خطوات التعامل مع المخالفات',
        subtitleEn: 'Progressive stages: Reminder, Timeout, Kick, and Permanent Ban',
        subtitleAr: 'تدرج العقوبات: تنبيه، كتم مؤقت، طرد، وحظر نهائي',
        readingTimeMinutes: 1
      }
    ]
  },
  {
    id: 'guide-administration',
    bookNumber: 'GUIDE 10',
    titleEn: 'ADMINISTRATION',
    titleAr: 'الإدارة والسيادة العليا',
    subtitleEn: 'Owner System, Role Sync & Staff Operations',
    subtitleAr: 'نظام المالك، مزامنة الرتب، وإدارة الطاقم',
    descriptionEn: 'Administrative operations: Owner Edgar’s final authority, role synchronization with Discord, roster tools, and secure audit logging.',
    descriptionAr: 'العمليات الإدارية العليا: صلاحيات المالك Edgar، مزامنة رتب ديسكورد، أدوات التحكم بالطاقم، وسجلات التدقيق المحمية.',
    iconName: 'Crown',
    accentColor: 'amber',
    gradient: 'from-[#f6d98a]/25 via-[#7c8cff]/15 to-transparent',
    borderColor: 'border-[#f6d98a]/40 hover:border-[#f6d98a]/80',
    tagEn: 'Administration',
    tagAr: 'الإدارة العليا',
    requiresAuthRole: true,
    chapters: [
      {
        id: 'ch-admin-owner',
        chapterNumber: '01',
        titleEn: 'Owner System & Sovereign Authority',
        titleAr: 'منظومة المالك والسيادة العليا',
        subtitleEn: 'Creator Edgar as Guild Owner and sole promotion authority',
        subtitleAr: 'المالك Edgar كسلطة عليا وصاحب الاعتماد النهائي للترقيات',
        readingTimeMinutes: 2
      },
      {
        id: 'ch-admin-roles',
        chapterNumber: '02',
        titleEn: 'Owner Roles & Discord Sync',
        titleAr: 'رتب المالك ومزامنة ديسكورد',
        subtitleEn: 'Configured role IDs and dynamic synchronization',
        subtitleAr: 'معرّفات الرتب المضبوطة وقواعد المزامنة الديناميكية',
        readingTimeMinutes: 1
      },
      {
        id: 'ch-admin-staff-management',
        chapterNumber: '03',
        titleEn: 'Staff Management Operations',
        titleAr: 'إدارة الطاقم والعمليات',
        subtitleEn: 'Induct staff, notes, point adjustments, and status changes',
        subtitleAr: 'ضم الإداريين، الملاحظات، تعديل النقاط، وتحديث الحالة',
        readingTimeMinutes: 2
      },
      {
        id: 'ch-admin-sync',
        chapterNumber: '04',
        titleEn: 'Discord Sync & Audit Integrity',
        titleAr: 'نزاهة سجل التدقيق والأمان',
        subtitleEn: 'Irreversible audit records, token validation, and rate limits',
        subtitleAr: 'سجلات تدقيق غير قابلة للتعديل وحماية العمليات بالخادم',
        readingTimeMinutes: 1
      }
    ]
  }
];
