import { UnifiedItemDefinition } from '../types/items';

export const DEFAULT_UNIFIED_ITEMS: UnifiedItemDefinition[] = [
  // ========================================================
  // COMPANION GIFTS (Preserve existing affection items)
  // ========================================================
  {
    id: 'item_date_honey',
    name: 'Babylonian Golden Palm Honey',
    nameAr: 'عسل النخيل البابلي الذهبي',
    description: 'Pure amber honey harvested from the sacred date groves of the Euphrates. Sweet and comforting.',
    descriptionAr: 'عسل نقي بلون العنبر مستخلص من جنائن النخيل البابلية عند ضفاف الفرات، يبعث الدفء والسرور.',
    imageUrl: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=400&q=80',
    rarity: 'COMMON',
    category: 'COMPANION',
    targetCharacterId: 'char_ishtar',
    lovePoints: 25,
    packages: ['COMMON', 'UNCOMMON', 'RARE'],
    dropWeight: 65,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'item_celestial_rose',
    name: 'Quantum Crystal Starlight Rose',
    nameAr: 'وردة ضوء النجوم الكريستالية',
    description: 'A crystalline blossom nurtured under cosmic aurora lights. Never withers, glistening with starlight.',
    descriptionAr: 'زهرة بلورية نادرة زُرعت تحت شفق الأورورا الكونية، لا تذبل أبداً وتتلألأ بضوء النجوم الخالد.',
    imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=400&q=80',
    rarity: 'UNCOMMON',
    category: 'COMPANION',
    targetCharacterId: 'char_valkyrie',
    lovePoints: 50,
    packages: ['UNCOMMON', 'RARE', 'EPIC'],
    dropWeight: 45,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'item_lapis_pendant',
    name: 'Royal Lapis Lazuli Pendant',
    nameAr: 'قلادة اللازورد الملكية',
    description: 'Deep cobalt stone inlaid with 24k Mesopotamian gold runes. Sacred to the sovereign Queen of Heaven.',
    descriptionAr: 'حجر لازورد ملكي أزرق عميق مرصع بذهب عيار 24 ونقوش مسمارية، مكرّس لسيدة السماء العظمى.',
    imageUrl: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=400&q=80',
    rarity: 'RARE',
    category: 'COMPANION',
    targetCharacterId: 'char_ishtar',
    lovePoints: 90,
    packages: ['RARE', 'EPIC', 'LEGENDARY'],
    dropWeight: 30,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'item_temporal_hourglass',
    name: 'Hyperion Chrono Hourglass',
    nameAr: 'ساعة الرمل الزمني الكونية',
    description: 'Encases violet stardust that flows in reverse, capturing memories and timeless moments.',
    descriptionAr: 'تحتوي على غبار نجمي أرجواني يتدفق في الاتجاهين، تحفظ الذكريات وأثمن اللحظات التي لا تموت.',
    imageUrl: 'https://images.unsplash.com/photo-1509281373149-e957c6296406?auto=format&fit=crop&w=400&q=80',
    rarity: 'EPIC',
    category: 'COMPANION',
    targetCharacterId: 'char_chrono',
    lovePoints: 175,
    packages: ['EPIC', 'LEGENDARY'],
    dropWeight: 18,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'item_sovereign_ring',
    name: 'Sovereign Crown of Eternal Devotion',
    nameAr: 'إكليل السيادة والمحبة السرمدية',
    description: 'The pinnacle treasure of the Sanctuary. Universally adored by every character, granting immense Love Points.',
    descriptionAr: 'أندر وأعظم كنوز الملاذ على الإطلاق، تعشقه جميع الشخصيات بلا استثناء ويمنح فيضاً من نقاط المحبة.',
    imageUrl: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=400&q=80',
    rarity: 'LEGENDARY',
    category: 'COMPANION',
    targetCharacterId: 'ANY',
    lovePoints: 350,
    packages: ['LEGENDARY'],
    dropWeight: 8,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ========================================================
  // BATTLE CONSUMABLES (Usable in Rock-Paper-Scissors Battles)
  // ========================================================
  {
    id: 'item_nano_repair_patch',
    name: 'Nano-Cell Health Stimulus',
    nameAr: 'مستحلب النانو الخلوي (علاج صحة)',
    description: 'Rapidly synthesizes restorative nano-cells, recovering +35 Health instantly in combat. Free tactical action.',
    descriptionAr: 'يفرز خلايا نانوية علاجية نشطة، يستعيد فوراً +35 نقطة صحة أثناء المعركة. حركة تكتيكية حرة.',
    imageUrl: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=400&q=80',
    rarity: 'COMMON',
    category: 'BATTLE',
    battleEffect: {
      type: 'HEAL_HP',
      value: 35,
      durationTurns: 0,
      consumesTurn: false,
      maxUsesPerBattle: 2
    },
    packages: ['COMMON', 'UNCOMMON', 'RARE'],
    dropWeight: 50,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'item_hyperion_energy_flask',
    name: 'Hyperion Plasma Battery',
    nameAr: 'بطارية هايبريون البلازمية (استعادة جهد)',
    description: 'Overcharges tactical reserves, recovering +45 Stamina instantly to fuel Strikes and Heavies.',
    descriptionAr: 'تشحن الجهد القتالي والقدرة الحركية، تستعيد فوراً +45 نقطة لياقة لتنفيذ الهجمات السريعة والثقيلة.',
    imageUrl: 'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?auto=format&fit=crop&w=400&q=80',
    rarity: 'UNCOMMON',
    category: 'BATTLE',
    battleEffect: {
      type: 'RESTORE_STAMINA',
      value: 45,
      durationTurns: 0,
      consumesTurn: false,
      maxUsesPerBattle: 2
    },
    packages: ['COMMON', 'UNCOMMON', 'RARE', 'EPIC'],
    dropWeight: 40,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'item_aegis_kinetic_shield',
    name: 'Aegis Barrier Capsule',
    nameAr: 'كبسولة حاجز إيجيس الحركي (درع واقٍ)',
    description: 'Projects a hard-light protective barrier absorbing up to 40 incoming damage before health is damaged.',
    descriptionAr: 'يولّد درعاً ضوئياً صلباً يمتص حتى 40 نقطة ضرر قادم قبل وصوله إلى صحة المقاتل الأساسية.',
    imageUrl: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?auto=format&fit=crop&w=400&q=80',
    rarity: 'RARE',
    category: 'BATTLE',
    battleEffect: {
      type: 'GRANT_SHIELD',
      value: 40,
      durationTurns: 0,
      consumesTurn: false,
      maxUsesPerBattle: 1
    },
    packages: ['RARE', 'EPIC', 'LEGENDARY'],
    dropWeight: 25,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'item_overdrive_combat_stim',
    name: 'Overdrive Neural Serum',
    nameAr: 'محفز الأوفر درايف العصبي (تعزيز هجوم)',
    description: 'Hyper-activates combat synapses, granting +30% Attack Damage boost for 2 consecutive turns.',
    descriptionAr: 'ينشط النواقل العصبية القتالية، يمنح زيادة +30% على قوة الضرر الهجومي لمدة جولتين متتاليتين.',
    imageUrl: 'https://images.unsplash.com/photo-1507668077129-56e32842fceb?auto=format&fit=crop&w=400&q=80',
    rarity: 'EPIC',
    category: 'BATTLE',
    battleEffect: {
      type: 'BUFF_ATTACK',
      value: 30,
      durationTurns: 2,
      consumesTurn: false,
      maxUsesPerBattle: 1
    },
    packages: ['EPIC', 'LEGENDARY'],
    dropWeight: 15,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'item_celestial_ambrosia',
    name: 'Celestial Sovereign Ambrosia',
    nameAr: 'إكسير السيادة السماوية الأعظم',
    description: 'Supreme mythical draught that fully heals +75 HP, grants +50 Shield, and clears exhaustion in dire moments.',
    descriptionAr: 'جرعة أسطورية عليا تستعيد +75 صحة وتمنح +50 درعاً واقياً وتزيل الإنهاك في اللحظات الحرجة.',
    imageUrl: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=400&q=80',
    rarity: 'LEGENDARY',
    category: 'BATTLE',
    battleEffect: {
      type: 'HEAL_HP',
      value: 75,
      durationTurns: 0,
      consumesTurn: false,
      maxUsesPerBattle: 1
    },
    packages: ['LEGENDARY'],
    dropWeight: 8,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },

  // ========================================================
  // UPGRADE MATERIALS (Obtained from Duplicate Cards & Packs)
  // ========================================================
  {
    id: 'item_shard_common',
    name: 'Cyberite Shard',
    nameAr: 'شظية السايبريت',
    description: 'Refined crystal shard harvested from duplicate standard cards. Core crafting and enhancement catalyst.',
    descriptionAr: 'شظية متبلورة نقية مستخلصة من البطاقات المكررة الشائعة، محفز أساسي للترقية والتعزيز.',
    imageUrl: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&w=400&q=80',
    rarity: 'COMMON',
    category: 'UPGRADE_MATERIAL',
    packages: ['COMMON', 'UNCOMMON'],
    dropWeight: 40,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'item_shard_uncommon',
    name: 'Prism Energy Crystal',
    nameAr: 'بلورة طاقة الموشور',
    description: 'Gleaming emerald crystal forged from duplicate uncommon cards. High-density kinetic energy repository.',
    descriptionAr: 'بلورة زمردية لامعة مصهورة من البطاقات غير الشائعة المكررة، مخزن طاقة حركية عالي الكثافة.',
    imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=400&q=80',
    rarity: 'UNCOMMON',
    category: 'UPGRADE_MATERIAL',
    packages: ['UNCOMMON', 'RARE'],
    dropWeight: 30,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'item_shard_rare',
    name: 'Astral Core Fragment',
    nameAr: 'شظية النواة النجمية',
    description: 'Pulsing cobalt core fragment from duplicate rare cards. Resonates with tactical frequency.',
    descriptionAr: 'شظية نواة كوبالت نابضة من البطاقات النادرة المكررة، تتناغم بتردد تكتيكي استثنائي.',
    imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=400&q=80',
    rarity: 'RARE',
    category: 'UPGRADE_MATERIAL',
    packages: ['RARE', 'EPIC'],
    dropWeight: 20,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'item_shard_epic',
    name: 'Hyperion Chrono Shard',
    nameAr: 'شظية هايبريون الزمنية',
    description: 'Distorts surrounding dimensional flux. Gained from duplicate epic cards.',
    descriptionAr: 'تحني التدفق البعدي من حولها، يتم الحصول عليها من البطاقات الملحمية المكررة.',
    imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=400&q=80',
    rarity: 'EPIC',
    category: 'UPGRADE_MATERIAL',
    packages: ['EPIC', 'LEGENDARY'],
    dropWeight: 12,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'item_shard_legendary',
    name: 'Sovereign Solar Gem',
    nameAr: 'جوهرة الشمس السيادية',
    description: 'The supreme radiant stone yielded by duplicate legendary relics. Imbued with perpetual stellar solar power.',
    descriptionAr: 'الجوهرة المشعة العظمى الناتجة عن البطاقات الأسطورية المكررة، مفعمة بقوة شمسية خالدة.',
    imageUrl: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?auto=format&fit=crop&w=400&q=80',
    rarity: 'LEGENDARY',
    category: 'UPGRADE_MATERIAL',
    packages: ['LEGENDARY'],
    dropWeight: 5,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'item_shard_universal',
    name: 'Universal Starlight Catalyst',
    nameAr: 'المحفز النجمي الشامل',
    description: 'A transcendent prismatic catalyst that can substitute for any upgrade shard tier during card ascension.',
    descriptionAr: 'محفز منشوري فائق يمكن استخدامه كبديل لأي شظية ترقية أثناء ترقية وصعود البطاقات.',
    imageUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=400&q=80',
    rarity: 'HALLOWEEN_2026',
    category: 'UPGRADE_MATERIAL',
    packages: ['EPIC', 'LEGENDARY', 'HALLOWEEN_2026'],
    dropWeight: 3,
    isActive: true,
    isCustom: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export const DEFAULT_ITEMS = DEFAULT_UNIFIED_ITEMS;

if (typeof window !== 'undefined') {
  (window as any).DEFAULT_ITEMS = DEFAULT_UNIFIED_ITEMS;
}
if (typeof globalThis !== 'undefined') {
  (globalThis as any).DEFAULT_ITEMS = DEFAULT_UNIFIED_ITEMS;
}

