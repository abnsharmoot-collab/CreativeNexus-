import { CollectibleCardData } from '../types/cards';
import { DEFAULT_COLLECTIBLE_CARDS } from '../data/defaultCards';
import { OFFICIAL_SERVER_RULES } from '../data/handbookData';

export interface GenerateHtmlOptions {
  language?: 'ar' | 'en';
  theme?: 'teal' | 'gold';
  customCards?: CollectibleCardData[];
  includeAudioSynthesizer?: boolean;
}

/**
 * Generates a complete, self-contained, offline-ready single-file HTML website
 * capturing the entirety of the Creative Nexus portal (Home, History, Card Vault,
 * Codex, Staff, Announcements, Server Dashboard, Achievements) with interactive tabs,
 * bilingual switcher (Arabic/English), theme switcher, and 3D card inspector.
 */
export function generateWebsiteHtml(options: GenerateHtmlOptions = {}): string {
  const defaultLang = options.language || 'ar';
  const defaultTheme = options.theme || 'teal';
  const cards = (options.customCards && options.customCards.length > 0)
    ? options.customCards
    : DEFAULT_COLLECTIBLE_CARDS;

  // Serialize cards safely for embedded script
  const serializedCards = JSON.stringify(cards.map(c => ({
    id: c.id,
    name: c.name,
    rarity: c.rarity,
    element: c.element || 'NEUTRAL',
    description: c.description || '',
    lore: c.lore || '',
    imageUrl: c.imageUrl || '',
    overallRating: c.overallRating || 88,
    attack: c.attack || 85,
    defense: c.defense || 80,
    hp: c.hp || 90,
    stats: c.stats || [],
    abilities: c.abilities || [],
    cardNumber: c.cardNumber || 1,
    accentColor: c.accentColor || '#5eead4'
  })));

  const serializedRules = JSON.stringify(OFFICIAL_SERVER_RULES);

  return `<!DOCTYPE html>
<html lang="${defaultLang}" dir="${defaultLang === 'ar' ? 'rtl' : 'ltr'}" data-theme="${defaultTheme}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>مركز الإبداع | Creative Nexus - Offline Archive Edition</title>
  <meta name="description" content="Offline Single-File HTML Edition of Creative Nexus Community Portal, Card Vault, Codex, and History.">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&family=Cinzel:wght@600;700;800;900&family=Outfit:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  
  <style>
    :root {
      --bg-base: #010807;
      --bg-surface: #031412;
      --bg-card: rgba(4, 25, 23, 0.7);
      --border-color: rgba(94, 234, 212, 0.22);
      --border-highlight: #5eead4;
      --accent: #5eead4;
      --accent-glow: rgba(94, 234, 212, 0.45);
      --text-main: #eafffa;
      --text-muted: #8eb8b2;
      --gold-accent: #f59e0b;
      --font-ar: 'Cairo', system-ui, -apple-system, sans-serif;
      --font-en: 'Outfit', 'Inter', system-ui, -apple-system, sans-serif;
      --font-serif: 'Cinzel', 'Cairo', serif;
    }

    [data-theme="gold"] {
      --bg-base: #0f0a06;
      --bg-surface: #1a120b;
      --bg-card: rgba(30, 20, 12, 0.85);
      --border-color: rgba(245, 158, 11, 0.35);
      --border-highlight: #fbbf24;
      --accent: #f59e0b;
      --accent-glow: rgba(245, 158, 11, 0.55);
      --text-main: #fef3c7;
      --text-muted: #d4a373;
      --gold-accent: #fbbf24;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-font-smoothing: antialiased;
    }

    html, body {
      background-color: var(--bg-base);
      color: var(--text-main);
      font-family: var(--font-ar);
      min-height: 100vh;
      overflow-x: hidden;
      scroll-behavior: smooth;
      transition: background-color 0.3s ease, color 0.3s ease;
    }

    body[dir="ltr"] {
      font-family: var(--font-en);
    }

    /* Ambient Spatial Background */
    .spatial-bg {
      position: fixed;
      inset: 0;
      pointer-events: none;
      z-index: 0;
      overflow: hidden;
    }
    .spatial-mesh-1 {
      position: absolute;
      top: -150px;
      left: 50%;
      transform: translateX(-50%);
      width: 1000px;
      height: 600px;
      background: radial-gradient(circle, var(--accent-glow) 0%, transparent 70%);
      filter: blur(120px);
      opacity: 0.35;
    }
    .spatial-mesh-2 {
      position: absolute;
      bottom: -100px;
      right: -100px;
      width: 800px;
      height: 600px;
      background: radial-gradient(circle, rgba(6, 182, 212, 0.25) 0%, transparent 70%);
      filter: blur(140px);
      opacity: 0.3;
    }
    [data-theme="gold"] .spatial-mesh-2 {
      background: radial-gradient(circle, rgba(217, 119, 6, 0.3) 0%, transparent 70%);
    }

    /* Header & Navigation */
    header {
      position: sticky;
      top: 0;
      z-index: 100;
      background: rgba(2, 13, 11, 0.88);
      backdrop-filter: blur(20px);
      border-bottom: 1px solid var(--border-color);
      box-shadow: 0 10px 30px rgba(0,0,0,0.6);
      transition: all 0.3s ease;
    }
    [data-theme="gold"] header {
      background: rgba(15, 10, 6, 0.92);
    }

    .nav-container {
      max-width: 1280px;
      margin: 0 auto;
      padding: 0 1.25rem;
      height: 70px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      text-decoration: none;
      color: inherit;
      cursor: pointer;
    }
    .brand-emblem {
      width: 40px;
      height: 40px;
      border-radius: 12px;
      background: linear-gradient(135deg, var(--accent), #03443e);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 0 15px var(--accent-glow);
      border: 1px solid rgba(255, 255, 255, 0.3);
      font-size: 1.2rem;
      font-weight: 900;
      color: #010807;
    }
    [data-theme="gold"] .brand-emblem {
      background: linear-gradient(135deg, #fbbf24, #78350f);
      color: #1a0f06;
    }
    .brand-title {
      font-weight: 800;
      font-size: 1.15rem;
      letter-spacing: -0.02em;
      line-height: 1.1;
    }
    .brand-subtitle {
      font-size: 0.72rem;
      color: var(--text-muted);
      letter-spacing: 0.05em;
      text-transform: uppercase;
    }

    .nav-links {
      display: flex;
      align-items: center;
      gap: 0.35rem;
      list-style: none;
    }
    @media (max-width: 960px) {
      .nav-links {
        display: none;
      }
    }

    .nav-btn {
      background: transparent;
      border: 1px solid transparent;
      color: var(--text-muted);
      padding: 0.45rem 0.85rem;
      border-radius: 9999px;
      font-size: 0.85rem;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 0.4rem;
      transition: all 0.2s ease;
      font-family: inherit;
      text-decoration: none;
    }
    .nav-btn:hover {
      color: var(--accent);
      background: rgba(94, 234, 212, 0.08);
      border-color: rgba(94, 234, 212, 0.2);
    }
    .nav-btn.active {
      color: #010807;
      background: var(--accent);
      border-color: var(--accent);
      box-shadow: 0 0 14px var(--accent-glow);
    }
    [data-theme="gold"] .nav-btn.active {
      color: #1a0f06;
      background: var(--gold-accent);
      border-color: var(--gold-accent);
    }

    .nav-actions {
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .control-chip {
      background: rgba(4, 25, 23, 0.8);
      border: 1px solid var(--border-color);
      color: var(--text-main);
      padding: 0.35rem 0.65rem;
      border-radius: 9999px;
      font-size: 0.75rem;
      font-weight: 700;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 0.35rem;
      transition: all 0.2s ease;
      font-family: inherit;
    }
    .control-chip:hover {
      border-color: var(--accent);
      color: var(--accent);
      transform: translateY(-1px);
    }
    .control-chip.primary {
      background: linear-gradient(135deg, var(--accent), #14b8a6);
      color: #010807;
      border-color: transparent;
      box-shadow: 0 0 15px var(--accent-glow);
    }
    [data-theme="gold"] .control-chip.primary {
      background: linear-gradient(135deg, #fbbf24, #d97706);
      color: #1a0f06;
    }

    /* Main Container */
    main {
      position: relative;
      z-index: 10;
      max-width: 1280px;
      margin: 0 auto;
      padding: 2rem 1.25rem 5rem;
    }

    .tab-section {
      display: none;
      animation: fadeIn 0.3s ease forwards;
    }
    .tab-section.active {
      display: block;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(8px); }
      to { opacity: 1; transform: translateY(0); }
    }

    /* Hero Section */
    .hero-banner {
      background: radial-gradient(ellipse at top, rgba(94, 234, 212, 0.12) 0%, rgba(3, 20, 18, 0.8) 70%);
      border: 1px solid var(--border-color);
      border-radius: 28px;
      padding: 3.5rem 2rem;
      text-align: center;
      position: relative;
      overflow: hidden;
      margin-bottom: 2.5rem;
      box-shadow: 0 20px 60px rgba(0,0,0,0.5);
    }
    [data-theme="gold"] .hero-banner {
      background: radial-gradient(ellipse at top, rgba(245, 158, 11, 0.15) 0%, rgba(26, 18, 11, 0.9) 70%);
    }

    .hero-tag {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.35rem 0.9rem;
      border-radius: 9999px;
      background: rgba(94, 234, 212, 0.12);
      border: 1px solid rgba(94, 234, 212, 0.35);
      color: var(--accent);
      font-size: 0.8rem;
      font-weight: 700;
      margin-bottom: 1.2rem;
      letter-spacing: 0.05em;
      text-transform: uppercase;
    }

    .hero-title {
      font-size: clamp(2rem, 5vw, 3.4rem);
      font-weight: 900;
      line-height: 1.15;
      margin-bottom: 1rem;
      letter-spacing: -0.02em;
      background: linear-gradient(135deg, #ffffff 30%, var(--accent) 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    [data-theme="gold"] .hero-title {
      background: linear-gradient(135deg, #fffbeb 30%, #fbbf24 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .hero-desc {
      max-width: 720px;
      margin: 0 auto 2rem;
      font-size: 1.05rem;
      color: var(--text-muted);
      line-height: 1.7;
    }

    .hero-actions {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 1rem;
      flex-wrap: wrap;
    }

    /* Metrics Bar */
    .metrics-bar {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1rem;
      margin-bottom: 3rem;
    }
    .metric-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 18px;
      padding: 1.25rem 1.5rem;
      display: flex;
      align-items: center;
      gap: 1rem;
      backdrop-filter: blur(12px);
      box-shadow: 0 10px 25px rgba(0,0,0,0.3);
    }
    .metric-icon {
      width: 48px;
      height: 48px;
      border-radius: 14px;
      background: rgba(94, 234, 212, 0.1);
      border: 1px solid rgba(94, 234, 212, 0.3);
      color: var(--accent);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.4rem;
      flex-shrink: 0;
    }
    .metric-val {
      font-size: 1.5rem;
      font-weight: 800;
      color: var(--text-main);
      line-height: 1.1;
    }
    .metric-lbl {
      font-size: 0.78rem;
      color: var(--text-muted);
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }

    /* Section Headers */
    .section-head {
      margin-bottom: 1.75rem;
      display: flex;
      align-items: flex-end;
      justify-content: space-between;
      gap: 1rem;
      flex-wrap: wrap;
    }
    .section-title {
      font-size: 1.8rem;
      font-weight: 800;
      letter-spacing: -0.01em;
      display: flex;
      align-items: center;
      gap: 0.6rem;
    }
    .section-desc {
      color: var(--text-muted);
      font-size: 0.95rem;
      margin-top: 0.25rem;
    }

    /* Card Vault Gallery */
    .vault-toolbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
      flex-wrap: wrap;
      background: var(--bg-surface);
      border: 1px solid var(--border-color);
      padding: 0.75rem 1rem;
      border-radius: 18px;
      margin-bottom: 2rem;
    }
    .filter-chips {
      display: flex;
      align-items: center;
      gap: 0.4rem;
      flex-wrap: wrap;
    }
    .filter-chip {
      background: transparent;
      border: 1px solid transparent;
      color: var(--text-muted);
      padding: 0.35rem 0.8rem;
      border-radius: 9999px;
      font-size: 0.8rem;
      font-weight: 700;
      cursor: pointer;
      font-family: inherit;
      transition: all 0.2s;
    }
    .filter-chip:hover {
      color: var(--accent);
      background: rgba(94, 234, 212, 0.08);
    }
    .filter-chip.active {
      background: var(--accent);
      color: #010807;
      font-weight: 800;
      box-shadow: 0 0 10px var(--accent-glow);
    }
    [data-theme="gold"] .filter-chip.active {
      background: var(--gold-accent);
      color: #1a0f06;
    }

    .search-box {
      background: rgba(0,0,0,0.4);
      border: 1px solid var(--border-color);
      border-radius: 9999px;
      padding: 0.4rem 1rem;
      color: var(--text-main);
      font-size: 0.85rem;
      font-family: inherit;
      min-width: 220px;
      outline: none;
      transition: border-color 0.2s;
    }
    .search-box:focus {
      border-color: var(--accent);
      box-shadow: 0 0 10px var(--accent-glow);
    }

    .cards-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
      gap: 1.5rem;
    }

    .collectible-card {
      background: var(--bg-surface);
      border: 1px solid var(--border-color);
      border-radius: 20px;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      position: relative;
      transition: transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1), box-shadow 0.3s ease, border-color 0.3s ease;
      cursor: pointer;
    }
    .collectible-card:hover {
      transform: translateY(-6px) scale(1.01);
      box-shadow: 0 16px 40px rgba(0,0,0,0.6), 0 0 25px var(--accent-glow);
      border-color: var(--border-highlight);
    }

    .card-art-wrap {
      position: relative;
      width: 100%;
      height: 240px;
      background: #020908;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .card-art {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.5s ease;
    }
    .collectible-card:hover .card-art {
      transform: scale(1.05);
    }
    .card-art-fallback {
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      background: radial-gradient(circle at center, #0c2b27 0%, #010a08 100%);
      font-size: 3rem;
      color: var(--accent);
    }

    .card-rarity-badge {
      position: absolute;
      top: 12px;
      inset-inline-start: 12px;
      padding: 0.25rem 0.65rem;
      border-radius: 9999px;
      font-size: 0.7rem;
      font-weight: 800;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      backdrop-filter: blur(8px);
      box-shadow: 0 2px 8px rgba(0,0,0,0.6);
      z-index: 2;
    }
    .rarity-HALLOWEEN_2026, .rarity-MYTHIC { background: #b026ff; color: #ffffff; border: 1px solid #d946ef; }
    .rarity-LEGENDARY { background: #f59e0b; color: #1a0f06; border: 1px solid #fbbf24; }
    .rarity-EPIC { background: #9333ea; color: #ffffff; border: 1px solid #c084fc; }
    .rarity-RARE { background: #0284c7; color: #ffffff; border: 1px solid #38bdf8; }
    .rarity-UNCOMMON { background: #059669; color: #ffffff; border: 1px solid #34d399; }
    .rarity-COMMON { background: #475569; color: #ffffff; border: 1px solid #94a3b8; }

    .card-rating-ovr {
      position: absolute;
      top: 12px;
      inset-inline-end: 12px;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: rgba(0,0,0,0.75);
      border: 2px solid var(--accent);
      color: var(--accent);
      font-weight: 900;
      font-size: 0.95rem;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 0 10px var(--accent-glow);
      z-index: 2;
    }

    .card-body {
      padding: 1.25rem;
      display: flex;
      flex-direction: column;
      flex-grow: 1;
      justify-content: space-between;
      gap: 1rem;
    }
    .card-title {
      font-size: 1.15rem;
      font-weight: 800;
      color: var(--text-main);
      margin-bottom: 0.25rem;
    }
    .card-desc {
      font-size: 0.8rem;
      color: var(--text-muted);
      line-height: 1.5;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .card-stats-hud {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: rgba(0,0,0,0.35);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      padding: 0.5rem 0.75rem;
      font-size: 0.75rem;
      font-weight: 700;
    }
    .stat-pill {
      display: flex;
      align-items: center;
      gap: 0.3rem;
    }

    .card-inspect-btn {
      width: 100%;
      padding: 0.6rem;
      border-radius: 12px;
      background: rgba(94, 234, 212, 0.1);
      border: 1px solid var(--border-color);
      color: var(--accent);
      font-size: 0.82rem;
      font-weight: 700;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.4rem;
      transition: all 0.2s;
      font-family: inherit;
    }
    .collectible-card:hover .card-inspect-btn {
      background: var(--accent);
      color: #010807;
      border-color: var(--accent);
      box-shadow: 0 0 12px var(--accent-glow);
    }
    [data-theme="gold"] .collectible-card:hover .card-inspect-btn {
      background: var(--gold-accent);
      color: #1a0f06;
      border-color: var(--gold-accent);
    }

    /* 3D Card Inspector Modal */
    .modal-overlay {
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.88);
      backdrop-filter: blur(16px);
      z-index: 999;
      display: none;
      align-items: center;
      justify-content: center;
      padding: 1.5rem;
      animation: fadeIn 0.2s ease forwards;
    }
    .modal-overlay.open {
      display: flex;
    }

    .modal-container {
      background: var(--bg-surface);
      border: 1px solid var(--border-color);
      border-radius: 28px;
      max-width: 900px;
      width: 100%;
      max-height: 90vh;
      overflow-y: auto;
      box-shadow: 0 25px 80px rgba(0,0,0,0.8), 0 0 40px var(--accent-glow);
      position: relative;
      display: grid;
      grid-template-columns: 1fr 1.2fr;
      gap: 2rem;
      padding: 2.25rem;
    }
    @media (max-width: 768px) {
      .modal-container {
        grid-template-columns: 1fr;
        padding: 1.5rem;
        gap: 1.5rem;
      }
    }

    .modal-close-btn {
      position: absolute;
      top: 20px;
      inset-inline-end: 20px;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: rgba(0,0,0,0.5);
      border: 1px solid var(--border-color);
      color: var(--text-muted);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.2rem;
      cursor: pointer;
      transition: all 0.2s;
      z-index: 10;
    }
    .modal-close-btn:hover {
      color: var(--accent);
      border-color: var(--accent);
      transform: scale(1.1);
    }

    /* 3D Flip Card Viewport */
    .flipper-scene {
      perspective: 1200px;
      width: 100%;
      height: 420px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .flipper-card {
      width: 280px;
      height: 420px;
      position: relative;
      transform-style: preserve-3d;
      transition: transform 0.7s cubic-bezier(0.4, 0.2, 0.2, 1);
      border-radius: 20px;
      box-shadow: 0 20px 50px rgba(0,0,0,0.7);
    }
    .flipper-card.is-flipped {
      transform: rotateY(180deg);
    }
    .flipper-face {
      position: absolute;
      inset: 0;
      backface-visibility: hidden;
      border-radius: 20px;
      overflow: hidden;
      border: 2px solid var(--accent);
      background: #020e0c;
    }
    .flipper-front {
      display: flex;
      flex-direction: column;
    }
    .flipper-front img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .flipper-back {
      transform: rotateY(180deg);
      background: radial-gradient(circle at center, #062320 0%, #010807 100%);
      padding: 1.5rem;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      border: 2px solid var(--gold-accent);
    }

    /* History Timeline */
    .timeline {
      position: relative;
      margin: 2rem 0;
      padding-inline-start: 2rem;
      border-inline-start: 2px solid var(--border-color);
    }
    .timeline-node {
      position: relative;
      margin-bottom: 2.5rem;
    }
    .timeline-node::before {
      content: '';
      position: absolute;
      top: 6px;
      inset-inline-start: -2.45rem;
      width: 14px;
      height: 14px;
      border-radius: 50%;
      background: var(--accent);
      box-shadow: 0 0 12px var(--accent);
      border: 2px solid #010807;
    }
    .timeline-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 18px;
      padding: 1.5rem;
      box-shadow: 0 8px 30px rgba(0,0,0,0.3);
    }
    .timeline-era {
      display: inline-block;
      font-size: 0.75rem;
      font-weight: 800;
      color: var(--accent);
      text-transform: uppercase;
      letter-spacing: 0.08em;
      margin-bottom: 0.35rem;
    }
    .timeline-title {
      font-size: 1.25rem;
      font-weight: 800;
      margin-bottom: 0.5rem;
    }

    /* Codex Accordion / List */
    .codex-list {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    .rule-item {
      background: var(--bg-surface);
      border: 1px solid var(--border-color);
      border-radius: 16px;
      padding: 1.25rem 1.5rem;
      transition: border-color 0.2s, transform 0.2s;
    }
    .rule-item:hover {
      border-color: var(--accent);
      transform: translateX(4px);
    }
    [dir="rtl"] .rule-item:hover {
      transform: translateX(-4px);
    }
    .rule-num {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 28px;
      height: 28px;
      border-radius: 8px;
      background: rgba(94, 234, 212, 0.12);
      color: var(--accent);
      font-weight: 800;
      font-size: 0.8rem;
      margin-inline-end: 0.75rem;
    }

    /* Staff Roster Grid */
    .staff-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
      gap: 1.25rem;
    }
    .staff-card {
      background: var(--bg-surface);
      border: 1px solid var(--border-color);
      border-radius: 20px;
      padding: 1.5rem;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
      gap: 0.75rem;
      position: relative;
      overflow: hidden;
    }
    .staff-avatar {
      width: 72px;
      height: 72px;
      border-radius: 50%;
      background: #02201c;
      border: 2px solid var(--accent);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2rem;
      box-shadow: 0 0 15px var(--accent-glow);
    }

    /* Achievements Grid */
    .achievements-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 1rem;
    }
    .achievement-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 16px;
      padding: 1.25rem;
      display: flex;
      align-items: center;
      gap: 1rem;
    }
    .achievement-icon {
      width: 50px;
      height: 50px;
      border-radius: 14px;
      background: rgba(245, 158, 11, 0.15);
      border: 1px solid rgba(245, 158, 11, 0.4);
      color: var(--gold-accent);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
      flex-shrink: 0;
    }

    /* Footer */
    footer {
      border-top: 1px solid var(--border-color);
      background: rgba(2, 11, 10, 0.95);
      padding: 3rem 1.25rem 2rem;
      text-align: center;
      position: relative;
      z-index: 10;
    }
    .footer-content {
      max-width: 1280px;
      margin: 0 auto;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 1.25rem;
    }

    /* Utility Helpers */
    .btn-glow {
      background: var(--accent);
      color: #010807;
      font-weight: 800;
      padding: 0.75rem 1.75rem;
      border-radius: 9999px;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      border: none;
      cursor: pointer;
      font-family: inherit;
      font-size: 0.95rem;
      box-shadow: 0 0 20px var(--accent-glow);
      transition: all 0.2s ease;
    }
    .btn-glow:hover {
      transform: translateY(-2px);
      box-shadow: 0 0 30px var(--accent-glow);
    }
    [data-theme="gold"] .btn-glow {
      background: var(--gold-accent);
      color: #1a0f06;
    }

    .btn-secondary {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid var(--border-color);
      color: var(--text-main);
      font-weight: 700;
      padding: 0.75rem 1.5rem;
      border-radius: 9999px;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      cursor: pointer;
      font-family: inherit;
      font-size: 0.95rem;
      transition: all 0.2s ease;
    }
    .btn-secondary:hover {
      background: rgba(255, 255, 255, 0.1);
      border-color: var(--accent);
      color: var(--accent);
    }
  </style>
</head>
<body>
  <!-- Ambient Spatial Backing -->
  <div class="spatial-bg">
    <div class="spatial-mesh-1"></div>
    <div class="spatial-mesh-2"></div>
  </div>

  <!-- Header -->
  <header>
    <div class="nav-container">
      <a href="#home" class="brand" onclick="switchTab('home')">
        <div class="brand-emblem">⚡</div>
        <div>
          <div class="brand-title" data-ar="مركز الإبداع" data-en="Creative Nexus">مركز الإبداع</div>
          <div class="brand-subtitle" data-ar="الأرشيف الأثري المتكامل" data-en="Citadel Archive Edition">الأرشيف الأثري المتكامل</div>
        </div>
      </a>

      <!-- Desktop Nav Links -->
      <ul class="nav-links">
        <li><button class="nav-btn active" data-tab="home" onclick="switchTab('home')"><span data-ar="🏛️ الرئيسية" data-en="🏛️ Home">🏛️ الرئيسية</span></button></li>
        <li><button class="nav-btn" data-tab="vault" onclick="switchTab('vault')"><span data-ar="🃏 خزانة الآثار" data-en="🃏 Relic Vault">🃏 خزانة الآثار</span></button></li>
        <li><button class="nav-btn" data-tab="history" onclick="switchTab('history')"><span data-ar="📜 التاريخ" data-en="📜 History">📜 التاريخ</span></button></li>
        <li><button class="nav-btn" data-tab="codex" onclick="switchTab('codex')"><span data-ar="📖 الكتيب والقواعد" data-en="📖 Codex">📖 الكتيب والقواعد</span></button></li>
        <li><button class="nav-btn" data-tab="staff" onclick="switchTab('staff')"><span data-ar="🛡️ طاقم الإدارة" data-en="🛡️ Staff">🛡️ طاقم الإدارة</span></button></li>
        <li><button class="nav-btn" data-tab="achievements" onclick="switchTab('achievements')"><span data-ar="🏆 الإنجازات" data-en="🏆 Trophies">🏆 الإنجازات</span></button></li>
        <li><button class="nav-btn" data-tab="dashboard" onclick="switchTab('dashboard')"><span data-ar="📊 السيرفر" data-en="📊 Server">📊 السيرفر</span></button></li>
      </ul>

      <!-- Controls & Utilities -->
      <div class="nav-actions">
        <!-- Language Switch -->
        <button class="control-chip" id="lang-btn" onclick="toggleLanguage()" title="Toggle Language (العربية / English)">
          🌐 <span id="lang-lbl">EN</span>
        </button>

        <!-- Theme Switch -->
        <button class="control-chip" id="theme-btn" onclick="toggleTheme()" title="Toggle Theme (Emerald / Mesopotamian Gold)">
          🎨 <span id="theme-lbl">ذهب بابلي</span>
        </button>

        <!-- Ambient Sound Toggle -->
        <button class="control-chip" id="audio-btn" onclick="toggleAudio()" title="Archival Ambient Synthesizer">
          🎵 <span id="audio-lbl">صوت</span>
        </button>
      </div>
    </div>
  </header>

  <!-- Main Content Areas -->
  <main>
    <!-- TAB 1: HOME -->
    <section id="tab-home" class="tab-section active">
      <div class="hero-banner">
        <div class="hero-tag" data-ar="⚡ نسخة الأرشيف المستقلة الكاملة" data-en="⚡ Standalone Offline Master Archive">⚡ نسخة الأرشيف المستقلة الكاملة</div>
        <h1 class="hero-title" data-ar="بوابة مركز الإبداع والآثار السيبرانية" data-en="Creative Nexus Master Citadel Portal">بوابة مركز الإبداع والآثار السيبرانية</h1>
        <p class="hero-desc" data-ar="الموقع الرسمي الشامل لمجتمع ديسكورد مركز الإبداع — ملحمة التاريخ، دستور القوانين، خزانة البطاقات التجميعية النادرة، وقاعة أمجاد الطاقم." data-en="The comprehensive official chronicle of Creative Nexus Discord community — epic history, complete server codex, rare collectible card vault, and staff council directory.">
          الموقع الرسمي الشامل لمجتمع ديسكورد مركز الإبداع — ملحمة التاريخ، دستور القوانين، خزانة البطاقات التجميعية النادرة، وقاعة أمجاد الطاقم.
        </p>
        <div class="hero-actions">
          <button class="btn-glow" onclick="switchTab('vault')">
            <span data-ar="🃏 استكشف خزانة البطاقات النادرة" data-en="🃏 Explore Relic Card Vault">🃏 استكشف خزانة البطاقات النادرة</span>
          </button>
          <button class="btn-secondary" onclick="switchTab('history')">
            <span data-ar="📜 اقرأ ملحمة السيرفر" data-en="📜 Read Server Chronicle">📜 اقرأ ملحمة السيرفر</span>
          </button>
        </div>
      </div>

      <!-- Live Server Metrics -->
      <div class="metrics-bar">
        <div class="metric-card">
          <div class="metric-icon">👥</div>
          <div>
            <div class="metric-val">1,480+</div>
            <div class="metric-lbl" data-ar="عضو مسجل" data-en="Community Members">عضو مسجل</div>
          </div>
        </div>
        <div class="metric-card">
          <div class="metric-icon">⚡</div>
          <div>
            <div class="metric-val">340+</div>
            <div class="metric-lbl" data-ar="متصلون الآن" data-en="Active Online">متصلون الآن</div>
          </div>
        </div>
        <div class="metric-card">
          <div class="metric-icon">🎙️</div>
          <div>
            <div class="metric-val">18</div>
            <div class="metric-lbl" data-ar="غرفة صوتية نشطة" data-en="Voice Channels">غرفة صوتية نشطة</div>
          </div>
        </div>
        <div class="metric-card">
          <div class="metric-icon">🃏</div>
          <div>
            <div class="metric-val">${cards.length}</div>
            <div class="metric-lbl" data-ar="بطاقة أثرية محفوظة" data-en="Archived Relics">بطاقة أثرية محفوظة</div>
          </div>
        </div>
      </div>

      <!-- Quick Portals Grid -->
      <div class="section-head">
        <div>
          <h2 class="section-title" data-ar="أقسام البوابة الأثرية" data-en="Citadel Chambers">أقسام البوابة الأثرية</h2>
          <p class="section-desc" data-ar="تنقل بين غرف السيرفر ودساتيره التاريخية" data-en="Navigate through server halls and historical annals">تنقل بين غرف السيرفر ودساتيره التاريخية</p>
        </div>
      </div>

      <div class="cards-grid">
        <div class="collectible-card" onclick="switchTab('vault')">
          <div class="card-art-wrap">
            <div class="card-art-fallback">🃏</div>
          </div>
          <div class="card-body">
            <div>
              <div class="card-title" data-ar="خزانة البطاقات والآثار" data-en="Card Relic Vault">خزانة البطاقات والآثار</div>
              <div class="card-desc" data-ar="مجموعة كاملة من البطاقات الأسطورية مع فحص ثلاثي الأبعاد 3D ونظام القدرات والـ OVR." data-en="Full collection of collectible cards with interactive 3D inspection and stats.">مجموعة كاملة من البطاقات الأسطورية مع فحص ثلاثي الأبعاد 3D ونظام القدرات والـ OVR.</div>
            </div>
            <button class="card-inspect-btn"><span data-ar="فتح الخزانة ←" data-en="Open Vault →">فتح الخزانة ←</span></button>
          </div>
        </div>

        <div class="collectible-card" onclick="switchTab('history')">
          <div class="card-art-wrap">
            <div class="card-art-fallback">📜</div>
          </div>
          <div class="card-body">
            <div>
              <div class="card-title" data-ar="تاريخ وملحمة السيرفر" data-en="Chronicle of Kohan">تاريخ وملحمة السيرفر</div>
              <div class="card-desc" data-ar="العصور الكبرى من التأسيس إلى التوسع، وأرشيف ذكريات المالك إدغار كوهان." data-en="The grand epochs from genesis to revival, and the founder's memoirs.">العصور الكبرى من التأسيس إلى التوسع، وأرشيف ذكريات المالك إدغار كوهان.</div>
            </div>
            <button class="card-inspect-btn"><span data-ar="قراءة الملحمة ←" data-en="Read Chronicle →">قراءة الملحمة ←</span></button>
          </div>
        </div>

        <div class="collectible-card" onclick="switchTab('codex')">
          <div class="card-art-wrap">
            <div class="card-art-fallback">📖</div>
          </div>
          <div class="card-body">
            <div>
              <div class="card-title" data-ar="دستور القوانين والكتيب" data-en="Codex & Server Lawbook">دستور القوانين والكتيب</div>
              <div class="card-desc" data-ar="القواعد الرسمية للسلوك، آداب الغرف الصوتية، دليل الترقيات والعقوبات." data-en="Official community decorum, voice channel ethics, promotion protocols.">القواعد الرسمية للسلوك، آداب الغرف الصوتية، دليل الترقيات والعقوبات.</div>
            </div>
            <button class="card-inspect-btn"><span data-ar="عرض الدستور ←" data-en="View Codex →">عرض الدستور ←</span></button>
          </div>
        </div>
      </div>
    </section>

    <!-- TAB 2: CARD VAULT -->
    <section id="tab-vault" class="tab-section">
      <div class="section-head">
        <div>
          <h2 class="section-title">
            <span>🃏</span>
            <span data-ar="خزانة البطاقات والآثار الأسطورية" data-en="Card Relic Vault">خزانة البطاقات والآثار الأسطورية</span>
          </h2>
          <p class="section-desc" data-ar="انقر على أي بطاقة لتفعيل وضع الفحص ثلاثي الأبعاد، وعرض تفاصيل القوى والأختام الأثرية." data-en="Click any card to launch interactive 3D inspection, abilities dossier, and seals.">
            انقر على أي بطاقة لتفعيل وضع الفحص ثلاثي الأبعاد، وعرض تفاصيل القوى والأختام الأثرية.
          </p>
        </div>
      </div>

      <!-- Toolbar -->
      <div class="vault-toolbar">
        <div class="filter-chips" id="rarity-filters">
          <button class="filter-chip active" onclick="filterCards('ALL')"><span data-ar="الكل" data-en="All">الكل</span></button>
          <button class="filter-chip" onclick="filterCards('LEGENDARY')"><span data-ar="أسطوري" data-en="Legendary">أسطوري</span></button>
          <button class="filter-chip" onclick="filterCards('EPIC')"><span data-ar="ملحمي" data-en="Epic">ملحمي</span></button>
          <button class="filter-chip" onclick="filterCards('RARE')"><span data-ar="نادر" data-en="Rare">نادر</span></button>
          <button class="filter-chip" onclick="filterCards('UNCOMMON')"><span data-ar="غير شائع" data-en="Uncommon">غير شائع</span></button>
          <button class="filter-chip" onclick="filterCards('COMMON')"><span data-ar="شائع" data-en="Common">شائع</span></button>
        </div>

        <input 
          type="text" 
          id="card-search-input" 
          class="search-box" 
          placeholder="ابحث بالاسم أو القدرة..." 
          oninput="handleCardSearch(this.value)"
        />
      </div>

      <!-- Cards Grid -->
      <div class="cards-grid" id="cards-container">
        <!-- Rendered by JavaScript -->
      </div>
    </section>

    <!-- TAB 3: HISTORY -->
    <section id="tab-history" class="tab-section">
      <div class="section-head">
        <div>
          <h2 class="section-title">
            <span>📜</span>
            <span data-ar="ملحمة مركز الإبداع وتاريخ كوهان" data-en="The Chronicles of Creative Nexus">ملحمة مركز الإبداع وتاريخ كوهان</span>
          </h2>
          <p class="section-desc" data-ar="سجل تاريخي يوثق ولادة المجتمع من التأسيس العسير حتى النهضة المعاصرة." data-en="Historical chronicle documenting the community inception through its contemporary golden age.">
            سجل تاريخي يوثق ولادة المجتمع من التأسيس العسير حتى النهضة المعاصرة.
          </p>
        </div>
      </div>

      <div class="timeline">
        <div class="timeline-node">
          <div class="timeline-card">
            <span class="timeline-era">عصر البداية والتأسيس • 2023</span>
            <h3 class="timeline-title" data-ar="ولادة الفكرة وبناء الحصن الأول" data-en="Genesis & Citadel Foundation">ولادة الفكرة وبناء الحصن الأول</h3>
            <p class="card-desc" style="-webkit-line-clamp: none;" data-ar="قام المؤسس إدغار بإشعال أول شرارة لمركز الإبداع ليكون ملاذاً آمناً للمبدعين وأصحاب المواهب، حاملاً راية الاحترام والتميز." data-en="Founder Edgar sparked the initial vision of Creative Nexus as a bastion for creators, standing for excellence and mutual respect.">
              قام المؤسس إدغار بإشعال أول شرارة لمركز الإبداع ليكون ملاذاً آمناً للمبدعين وأصحاب المواهب، حاملاً راية الاحترام والتميز.
            </p>
          </div>
        </div>

        <div class="timeline-node">
          <div class="timeline-card">
            <span class="timeline-era">عصر الاختبار والمحنة • 2023</span>
            <h3 class="timeline-title" data-ar="عاصفة التحديات واختبار الولاء" data-en="The Great Trial">عاصفة التحديات واختبار الولاء</h3>
            <p class="card-desc" style="-webkit-line-clamp: none;" data-ar="واجه المجتمع عواصف رقمية وتحديات تنظيمية قاسية صقلت عزيمة الإدارة، وأثبتت صلابة الأركان التي لا تتزعزع." data-en="The community navigated tumultuous digital trials that tested loyalties and fortified the leadership foundation.">
              واجه المجتمع عواصف رقمية وتحديات تنظيمية قاسية صقلت عزيمة الإدارة، وأثبتت صلابة الأركان التي لا تتزعزع.
            </p>
          </div>
        </div>

        <div class="timeline-node">
          <div class="timeline-card">
            <span class="timeline-era">عصر النهضة والآثار • 2024</span>
            <h3 class="timeline-title" data-ar="افتتاح الخزانة الأثرية ونظام الرتب" data-en="The Renaissance & Relic Vaults">افتتاح الخزانة الأثرية ونظام الرتب</h3>
            <p class="card-desc" style="-webkit-line-clamp: none;" data-ar="إطلاق نظام البطاقات التجميعية النادرة، ووضع نظام نقاط الرتب الشفاف، مع دمج الهوية الأثرية البابلية الراقية." data-en="Unveiling of the rare collectible relics system, transparent rank points hierarchy, and ancient Babylonian aesthetics.">
              إطلاق نظام البطاقات التجميعية النادرة، ووضع نظام نقاط الرتب الشفاف، مع دمج الهوية الأثرية البابلية الراقية.
            </p>
          </div>
        </div>

        <div class="timeline-node">
          <div class="timeline-card">
            <span class="timeline-era">العصر المعاصر • 2025 - 2026</span>
            <h3 class="timeline-title" data-ar="الحصن المتكامل والمنظومة السيبرانية" data-en="The Sovereign Citadel">الحصن المتكامل والمنظومة السيبرانية</h3>
            <p class="card-desc" style="-webkit-line-clamp: none;" data-ar="تحول مركز الإبداع إلى منصة تفاعلية متكاملة تضم أنظمة القتال، غرف العمليات، الأرشيف السري، والمخطوطات الكاملة." data-en="Evolution into a comprehensive interactive web portal with real combat systems, secret archives, and full server codex.">
              تحول مركز الإبداع إلى منصة تفاعلية متكاملة تضم أنظمة القتال، غرف العمليات، الأرشيف السري، والمخطوطات الكاملة.
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- TAB 4: CODEX -->
    <section id="tab-codex" class="tab-section">
      <div class="section-head">
        <div>
          <h2 class="section-title">
            <span>📖</span>
            <span data-ar="دستور وقوانين سيرفر مركز الإبداع" data-en="Server Codex & Lawbook">دستور وقوانين سيرفر مركز الإبداع</span>
          </h2>
          <p class="section-desc" data-ar="اللائحة الرسمية المنظمة للحقوق والواجبات داخل المجتمع." data-en="Official server regulations and behavioral guidelines.">
            اللائحة الرسمية المنظمة للحقوق والواجبات داخل المجتمع.
          </p>
        </div>
      </div>

      <div class="codex-list" id="codex-container">
        <!-- Rendered by JS from OFFICIAL_SERVER_RULES -->
      </div>
    </section>

    <!-- TAB 5: STAFF -->
    <section id="tab-staff" class="tab-section">
      <div class="section-head">
        <div>
          <h2 class="section-title">
            <span>🛡️</span>
            <span data-ar="طاقم الإدارة ومجلس الحكماء" data-en="Citadel Council & Staff">طاقم الإدارة ومجلس الحكماء</span>
          </h2>
          <p class="section-desc" data-ar="قادة وحماة مركز الإبداع الساهرون على تطبيق العدالة والنظام." data-en="Guardians and leadership steering order and progress across the community.">
            قادة وحماة مركز الإبداع الساهرون على تطبيق العدالة والنظام.
          </p>
        </div>
      </div>

      <div class="staff-grid">
        <div class="staff-card">
          <div class="staff-avatar">👑</div>
          <div style="font-weight: 800; font-size: 1.15rem;">Edgar (كوهان)</div>
          <div class="card-rarity-badge rarity-LEGENDARY" style="position: static;">مؤسس السيرفر // Owner</div>
          <p class="card-desc" style="-webkit-line-clamp: none;">مؤسس مركز الإبداع وحامل التاج التاريخي، الموجه العام للمشاريع والسياسات.</p>
          <div class="card-stats-hud" style="width: 100%;">
            <span>نقاط القيادة</span>
            <span style="color: var(--accent);">99,999 PTS</span>
          </div>
        </div>

        <div class="staff-card">
          <div class="staff-avatar">⚡</div>
          <div style="font-weight: 800; font-size: 1.15rem;">Sovereign Council</div>
          <div class="card-rarity-badge rarity-EPIC" style="position: static;">مجلس الإدارة العليا // High Admins</div>
          <p class="card-desc" style="-webkit-line-clamp: none;">إدارة العمليات اليومية، تنظيم الفعاليات الكبرى، وحفظ أمن المجتمع.</p>
          <div class="card-stats-hud" style="width: 100%;">
            <span>صلاحيات النظام</span>
            <span style="color: var(--accent);">FULL ACCESS</span>
          </div>
        </div>

        <div class="staff-card">
          <div class="staff-avatar">🛡️</div>
          <div style="font-weight: 800; font-size: 1.15rem;">Moderation Vanguard</div>
          <div class="card-rarity-badge rarity-RARE" style="position: static;">فيلق المشرفين // Moderators</div>
          <p class="card-desc" style="-webkit-line-clamp: none;">مراقبة الغرف الصوتية والنصوص لضمان بيئة آمنة وخالية من المضايقات والسبام.</p>
          <div class="card-stats-hud" style="width: 100%;">
            <span>حالة الرقابة</span>
            <span style="color: #34d399;">24/7 ACTIVE</span>
          </div>
        </div>
      </div>
    </section>

    <!-- TAB 6: ACHIEVEMENTS -->
    <section id="tab-achievements" class="tab-section">
      <div class="section-head">
        <div>
          <h2 class="section-title">
            <span>🏆</span>
            <span data-ar="قاعة الأوسمة والإنجازات" data-en="Hall of Trophies & Milestones">قاعة الأوسمة والإنجازات</span>
          </h2>
          <p class="section-desc" data-ar="أوسمة استحقاق تمنح للأعضاء البارزين نظير مساهماتهم في مركز الإبداع." data-en="Accredited milestone badges rewarded for distinguished community achievements.">
            أوسمة استحقاق تمنح للأعضاء البارزين نظير مساهماتهم في مركز الإبداع.
          </p>
        </div>
      </div>

      <div class="achievements-grid">
        <div class="achievement-card">
          <div class="achievement-icon">⚡</div>
          <div>
            <div style="font-weight: 800; font-size: 1rem;">أول دماء التحدي</div>
            <div class="card-desc">المشاركة في أول معركة بالبطاقات داخل حلبة ديسكورد.</div>
          </div>
        </div>
        <div class="achievement-card">
          <div class="achievement-icon">🃏</div>
          <div>
            <div style="font-weight: 800; font-size: 1rem;">جامع الآثار الأسطوري</div>
            <div class="card-desc">امتلاك 10 بطاقات من الرتبة الأسطورية أو أعلى.</div>
          </div>
        </div>
        <div class="achievement-card">
          <div class="achievement-icon">📜</div>
          <div>
            <div style="font-weight: 800; font-size: 1rem;">حافظ المخطوطات</div>
            <div class="card-desc">قراءة جميع فصول ملحمة السيرفر ودستور القواعد.</div>
          </div>
        </div>
        <div class="achievement-card">
          <div class="achievement-icon">👑</div>
          <div>
            <div style="font-weight: 800; font-size: 1rem;">ولاء التاج الكوهاني</div>
            <div class="card-desc">إكمال سنة كاملة من العضوية الفعالة والنشاط اليومي.</div>
          </div>
        </div>
      </div>
    </section>

    <!-- TAB 7: SERVER DASHBOARD -->
    <section id="tab-dashboard" class="tab-section">
      <div class="section-head">
        <div>
          <h2 class="section-title">
            <span>📊</span>
            <span data-ar="لوحة معلومات سيرفر ديسكورد" data-en="Discord Server Dashboard">لوحة معلومات سيرفر ديسكورد</span>
          </h2>
          <p class="section-desc" data-ar="مؤشرات الاتصال المباشر ورابط الانضمام الفوري." data-en="Live server presence metrics and instant invite.">
            مؤشرات الاتصال المباشر ورابط الانضمام الفوري.
          </p>
        </div>
      </div>

      <div class="hero-banner" style="padding: 2.5rem 1.5rem;">
        <h3 class="hero-title" style="font-size: 2rem;" data-ar="انضم إلى عائلة مركز الإبداع على ديسكورد" data-en="Join Creative Nexus Discord">انضم إلى عائلة مركز الإبداع على ديسكورد</h3>
        <p class="hero-desc" data-ar="سيرفر نشط، فعاليات أسبوعية، معارك بطاقات، وغرف صوتية مفتوحة لتبادل الأفكار والإبداع." data-en="Active server, weekly tournaments, card battles, and vibrant voice rooms.">
          سيرفر نشط، فعاليات أسبوعية، معارك بطاقات، وغرف صوتية مفتوحة لتبادل الأفكار والإبداع.
        </p>
        <a href="https://discord.gg" target="_blank" rel="noopener noreferrer" class="btn-glow" style="font-size: 1.1rem; padding: 0.85rem 2.2rem;">
          <span>انضم إلينا الآن عبر ديسكورد ←</span>
        </a>
      </div>
    </section>
  </main>

  <!-- 3D Card Inspector Modal -->
  <div class="modal-overlay" id="card-modal" onclick="closeCardModal(event)">
    <div class="modal-container" onclick="event.stopPropagation()">
      <button class="modal-close-btn" onclick="closeCardModal()">✕</button>

      <!-- 3D Flipper Scene -->
      <div class="flipper-scene">
        <div class="flipper-card" id="flipper-card-el" onclick="flipActiveCard()">
          <!-- Front Face -->
          <div class="flipper-face flipper-front">
            <img id="modal-card-img" src="" alt="Card Artwork">
          </div>
          <!-- Back Face -->
          <div class="flipper-face flipper-back">
            <div>
              <div style="font-size: 0.75rem; color: var(--gold-accent); font-weight: 800; letter-spacing: 0.1em;">AUTHENTIC ARTIFACT // الأثر الموثق</div>
              <h4 id="modal-card-back-title" style="font-size: 1.1rem; font-weight: 900; margin-top: 0.4rem;"></h4>
            </div>
            <div>
              <div style="font-size: 0.8rem; font-style: italic; color: #fde68a; line-height: 1.5;" id="modal-card-lore"></div>
            </div>
            <div style="border-top: 1px dashed rgba(245, 158, 11, 0.4); padding-top: 0.5rem; font-size: 0.72rem; color: var(--text-muted);">
              SEAL: CITADEL-MUSEUM-VALIDATED
            </div>
          </div>
        </div>
      </div>

      <!-- Card Details & Actions -->
      <div style="display: flex; flex-direction: column; justify-content: space-between; gap: 1rem;">
        <div>
          <div style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; margin-bottom: 0.5rem;">
            <span class="card-rarity-badge" id="modal-card-rarity" style="position: static;"></span>
            <span style="font-family: monospace; font-size: 0.85rem; color: var(--text-muted);" id="modal-card-series"></span>
          </div>

          <h3 style="font-size: 1.8rem; font-weight: 900; margin-bottom: 0.5rem;" id="modal-card-title"></h3>
          <p style="font-size: 0.95rem; color: var(--text-muted); line-height: 1.6; margin-bottom: 1.5rem;" id="modal-card-desc"></p>

          <!-- Combat Stats Bars -->
          <div style="display: flex; flex-direction: column; gap: 0.75rem; margin-bottom: 1.5rem;">
            <div>
              <div style="display: flex; justify-content: space-between; font-size: 0.8rem; font-weight: 700; margin-bottom: 0.25rem;">
                <span>الهجوم // Attack</span>
                <span id="modal-stat-atk" style="color: #ff5e00;"></span>
              </div>
              <div style="height: 6px; background: rgba(255,255,255,0.1); border-radius: 9999px; overflow: hidden;">
                <div id="modal-bar-atk" style="height: 100%; background: #ff5e00; width: 80%;"></div>
              </div>
            </div>

            <div>
              <div style="display: flex; justify-content: space-between; font-size: 0.8rem; font-weight: 700; margin-bottom: 0.25rem;">
                <span>الدفاع // Defense</span>
                <span id="modal-stat-def" style="color: #38bdf8;"></span>
              </div>
              <div style="height: 6px; background: rgba(255,255,255,0.1); border-radius: 9999px; overflow: hidden;">
                <div id="modal-bar-def" style="height: 100%; background: #38bdf8; width: 80%;"></div>
              </div>
            </div>

            <div>
              <div style="display: flex; justify-content: space-between; font-size: 0.8rem; font-weight: 700; margin-bottom: 0.25rem;">
                <span>الصحة // Vitality</span>
                <span id="modal-stat-hp" style="color: #f43f5e;"></span>
              </div>
              <div style="height: 6px; background: rgba(255,255,255,0.1); border-radius: 9999px; overflow: hidden;">
                <div id="modal-bar-hp" style="height: 100%; background: #f43f5e; width: 80%;"></div>
              </div>
            </div>
          </div>
        </div>

        <div style="display: flex; gap: 0.75rem;">
          <button class="btn-glow" style="flex: 1; justify-content: center;" onclick="flipActiveCard()">
            <span>🔄 اقلب وجه البطاقة (3D Flip)</span>
          </button>
          <button class="btn-secondary" onclick="closeCardModal()">
            <span>إغلاق</span>
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer>
    <div class="footer-content">
      <div class="brand">
        <div class="brand-emblem">⚡</div>
        <div class="brand-title" data-ar="مركز الإبداع | Creative Nexus" data-en="Creative Nexus Official Portal">مركز الإبداع | Creative Nexus</div>
      </div>
      <p style="color: var(--text-muted); font-size: 0.85rem;" data-ar="الأرشيف الأثري الشامل — صمم كنسخة HTML مستقلة تعمل بدون إنترنت وبدون خادم." data-en="Complete Citadel Archive — Designed as a standalone offline HTML edition.">
        الأرشيف الأثري الشامل — صمم كنسخة HTML مستقلة تعمل بدون إنترنت وبدون خادم.
      </p>
      <div style="font-size: 0.75rem; color: var(--text-muted); opacity: 0.7;">
        © Creative Nexus Citadel • All Rights Reserved • Built for Discord Community
      </div>
    </div>
  </footer>

  <!-- Embedded Vanilla JS Engine -->
  <script>
    // Embedded Data
    const CARDS = ${serializedCards};
    const RULES = ${serializedRules};

    let currentTab = 'home';
    let currentFilter = 'ALL';
    let currentLang = '${defaultLang}';
    let currentTheme = '${defaultTheme}';
    let activeCardIndex = 0;
    let isFlipped = false;
    let audioContext = null;
    let ambientOscillator = null;
    let isAudioPlaying = false;

    // Switch Tabs
    function switchTab(tabId) {
      currentTab = tabId;
      document.querySelectorAll('.tab-section').forEach(el => el.classList.remove('active'));
      const target = document.getElementById('tab-' + tabId);
      if (target) target.classList.add('active');

      document.querySelectorAll('.nav-btn').forEach(btn => {
        if (btn.getAttribute('data-tab') === tabId) {
          btn.classList.add('active');
        } else {
          btn.classList.remove('active');
        }
      });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Language Toggle
    function toggleLanguage() {
      currentLang = currentLang === 'ar' ? 'en' : 'ar';
      document.documentElement.lang = currentLang;
      document.documentElement.dir = currentLang === 'ar' ? 'rtl' : 'ltr';
      document.body.setAttribute('dir', currentLang === 'ar' ? 'rtl' : 'ltr');
      document.getElementById('lang-lbl').textContent = currentLang === 'ar' ? 'EN' : 'عربي';

      // Update text in elements with data-ar and data-en
      document.querySelectorAll('[data-ar]').forEach(el => {
        const txt = el.getAttribute('data-' + currentLang);
        if (txt) el.textContent = txt;
      });
    }

    // Theme Toggle
    function toggleTheme() {
      currentTheme = currentTheme === 'teal' ? 'gold' : 'teal';
      document.documentElement.setAttribute('data-theme', currentTheme);
      document.getElementById('theme-lbl').textContent = currentTheme === 'teal' ? 'ذهب بابلي' : 'زمرد سيبراني';
    }

    // Ambient Sound Synthesizer (Zero External Dependencies)
    function toggleAudio() {
      try {
        if (!audioContext) {
          audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
        if (!isAudioPlaying) {
          audioContext.resume();
          const osc = audioContext.createOscillator();
          const gain = audioContext.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(108, audioContext.currentTime); // Sacred drone A2/C3
          gain.gain.setValueAtTime(0.04, audioContext.currentTime);
          osc.connect(gain);
          gain.connect(audioContext.destination);
          osc.start();
          ambientOscillator = osc;
          isAudioPlaying = true;
          document.getElementById('audio-lbl').textContent = 'إيقاف الصوت';
        } else {
          if (ambientOscillator) {
            ambientOscillator.stop();
            ambientOscillator.disconnect();
          }
          isAudioPlaying = false;
          document.getElementById('audio-lbl').textContent = 'صوت';
        }
      } catch (err) {
        console.warn('Audio not available:', err);
      }
    }

    // Render Cards in Vault
    function renderCards(list) {
      const container = document.getElementById('cards-container');
      if (!container) return;

      if (!list || list.length === 0) {
        container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: var(--text-muted);">لا توجد بطاقات مطابقة لبحثك</div>';
        return;
      }

      container.innerHTML = list.map((card, idx) => {
        const rarityClass = 'rarity-' + card.rarity;
        const ovr = card.overallRating || 88;
        return \`
          <div class="collectible-card" onclick="openCardModal(\${idx})">
            <div class="card-art-wrap">
              <span class="card-rarity-badge \${rarityClass}">\${card.rarity}</span>
              <div class="card-rating-ovr">\${ovr}</div>
              \${card.imageUrl 
                ? \`<img class="card-art" src="\${card.imageUrl}" alt="\${card.name}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />
                   <div class="card-art-fallback" style="display:none;">🃏</div>\`
                : \`<div class="card-art-fallback">🃏</div>\`
              }
            </div>
            <div class="card-body">
              <div>
                <div class="card-title">\${card.name}</div>
                <div class="card-desc">\${card.description || 'أثر قتالي محفوظ داخل خزانة مركز الإبداع.'}</div>
              </div>
              <div class="card-stats-hud">
                <span class="stat-pill">⚔️ \${card.attack || 85}</span>
                <span class="stat-pill">🛡️ \${card.defense || 80}</span>
                <span class="stat-pill">❤️ \${card.hp || 90}</span>
              </div>
              <button class="card-inspect-btn">
                <span>👁️ فحص الأثر 3D</span>
              </button>
            </div>
          </div>
        \`;
      }).join('');
    }

    // Filter Cards
    function filterCards(rarity) {
      currentFilter = rarity;
      document.querySelectorAll('#rarity-filters .filter-chip').forEach(btn => {
        btn.classList.remove('active');
      });
      event.target.classList.add('active');

      const filtered = rarity === 'ALL'
        ? CARDS
        : CARDS.filter(c => c.rarity === rarity);
      renderCards(filtered);
    }

    // Search Cards
    function handleCardSearch(query) {
      const q = query.toLowerCase().trim();
      if (!q) {
        renderCards(currentFilter === 'ALL' ? CARDS : CARDS.filter(c => c.rarity === currentFilter));
        return;
      }
      const filtered = CARDS.filter(c => 
        c.name.toLowerCase().includes(q) || 
        (c.description && c.description.toLowerCase().includes(q))
      );
      renderCards(filtered);
    }

    // Render Rules in Codex
    function renderRules() {
      const container = document.getElementById('codex-container');
      if (!container) return;

      container.innerHTML = RULES.map((r, i) => \`
        <div class="rule-item">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.4rem;">
            <div style="font-weight: 800; font-size: 1.05rem; display: flex; align-items: center;">
              <span class="rule-num">\${r.id}</span>
              <span>\${r.title}</span>
            </div>
            <span style="font-size: 0.75rem; color: var(--accent); background: rgba(94, 234, 212, 0.1); padding: 0.2rem 0.6rem; border-radius: 9999px;">
              \${r.categoryLabelAr || r.category}
            </span>
          </div>
          <p style="color: var(--text-muted); font-size: 0.9rem; line-height: 1.6; padding-inline-start: 2.5rem;">
            \${r.body}
          </p>
        </div>
      \`).join('');
    }

    // 3D Card Modal
    function openCardModal(cardIdx) {
      activeCardIndex = cardIdx;
      isFlipped = false;
      const card = CARDS[cardIdx];
      if (!card) return;

      document.getElementById('modal-card-title').textContent = card.name;
      document.getElementById('modal-card-back-title').textContent = card.name;
      document.getElementById('modal-card-desc').textContent = card.description || 'أثر قتالي تاريخي.';
      document.getElementById('modal-card-lore').textContent = card.lore || '"من عمق الزمان انطلقت هذه القوة لتشهد على عظمة المبتكرين في مركز الإبداع."';
      document.getElementById('modal-card-rarity').textContent = card.rarity;
      document.getElementById('modal-card-rarity').className = 'card-rarity-badge rarity-' + card.rarity;
      document.getElementById('modal-card-series').textContent = '#' + (card.cardNumber || (cardIdx + 1)) + ' // SERIES-01';

      const imgEl = document.getElementById('modal-card-img');
      imgEl.src = card.imageUrl || '';

      document.getElementById('modal-stat-atk').textContent = card.attack || 85;
      document.getElementById('modal-stat-def').textContent = card.defense || 80;
      document.getElementById('modal-stat-hp').textContent = card.hp || 90;

      document.getElementById('modal-bar-atk').style.width = Math.min(100, card.attack || 85) + '%';
      document.getElementById('modal-bar-def').style.width = Math.min(100, card.defense || 80) + '%';
      document.getElementById('modal-bar-hp').style.width = Math.min(100, card.hp || 90) + '%';

      const flipper = document.getElementById('flipper-card-el');
      flipper.classList.remove('is-flipped');

      const modal = document.getElementById('card-modal');
      modal.classList.add('open');
    }

    function closeCardModal(e) {
      if (e && e.target && e.target !== e.currentTarget && !e.target.classList.contains('modal-close-btn')) {
        return;
      }
      const modal = document.getElementById('card-modal');
      modal.classList.remove('open');
    }

    function flipActiveCard() {
      const flipper = document.getElementById('flipper-card-el');
      isFlipped = !isFlipped;
      if (isFlipped) {
        flipper.classList.add('is-flipped');
      } else {
        flipper.classList.remove('is-flipped');
      }
    }

    // Escape Key Listener
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const modal = document.getElementById('card-modal');
        if (modal) modal.classList.remove('open');
      }
    });

    // Initial Load
    document.addEventListener('DOMContentLoaded', () => {
      renderCards(CARDS);
      renderRules();
    });
  </script>
</body>
</html>`;
}

/**
 * Creates and triggers a download of the HTML file in the user's browser.
 */
export function downloadWebsiteHtmlFile(options: GenerateHtmlOptions = {}): { filename: string; size: number } {
  const htmlContent = generateWebsiteHtml(options);
  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const filename = `creative-nexus-complete-website-${new Date().toISOString().slice(0, 10)}.html`;
  
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  setTimeout(() => URL.revokeObjectURL(link.href), 10000);
  return { filename, size: blob.size };
}

/**
 * Opens a live preview of the standalone HTML file in a new browser tab/window.
 */
export function openWebsiteHtmlPreview(options: GenerateHtmlOptions = {}): void {
  const htmlContent = generateWebsiteHtml(options);
  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const blobUrl = URL.createObjectURL(blob);
  window.open(blobUrl, '_blank');
}
