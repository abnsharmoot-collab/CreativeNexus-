/**
 * Standalone Offline & In-Browser Client Mock Engine
 * Enables the website to run 100% independently when opened as a standalone HTML file in any browser,
 * without needing an active Node.js server, while persisting all progress, coins, inventory, and decks to localStorage.
 */

import { CARD_PACKS, DEFAULT_COLLECTIBLE_CARDS } from '../data/defaultCards';
import { DEFAULT_UNIFIED_ITEMS } from '../data/defaultItems';
import { DEFAULT_CHARACTERS } from '../data/defaultCharacterLove';
import { STORY_CHAPTERS } from '../config/storyConfig';
import { CollectibleCardData, CardRarity, CardOwnership, UserCardProfile } from '../types/cards';
import { StaffMember } from '../types/staff';
import { PlayerDeck } from '../types/decks';
import { Announcement } from '../types/announcement';

export const isStandalone = typeof window !== 'undefined' && (
  window.location.protocol === 'file:' ||
  window.location.hostname === '' ||
  window.location.pathname.endsWith('.html') ||
  window.location.pathname.includes('/standalone') ||
  window.location.search.includes('standalone=true')
);

// Helper for local mock responses
function jsonResponse(data: any, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' }
  });
}

// Storage keys
const STORAGE_KEYS = {
  COINS: 'nexus_standalone_coins',
  OWNED_CARDS: 'nexus_standalone_owned_cards',
  PROFILE: 'nexus_standalone_profile',
  INVENTORY: 'nexus_standalone_inventory',
  DECKS: 'nexus_standalone_decks',
  STORY: 'nexus_standalone_story',
  CHAR_LOVE: 'nexus_standalone_char_love',
  THEME: 'nexus_standalone_theme',
  CUSTOM_CARDS: 'nexus_standalone_custom_cards',
  CARD_BACK: 'nexus_standalone_card_back',
  SITE_LOGO: 'nexus_standalone_site_logo',
  STAFF: 'nexus_standalone_staff',
  ANNOUNCEMENTS: 'nexus_standalone_announcements',
  SFX: 'nexus_standalone_sfx',
  AUDIT_LOGS: 'nexus_standalone_audit_logs',
  RANK_APPS: 'nexus_standalone_rank_apps'
};

function getStoredJson<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : defaultValue;
  } catch {
    return defaultValue;
  }
}

function setStoredJson(key: string, value: any): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn('LocalStorage write error:', e);
  }
}

// Initial starter staff
const DEFAULT_STAFF_MEMBERS: StaffMember[] = [
  {
    id: 1,
    discordId: '871043296280076308',
    username: 'edgar_creator',
    displayName: 'Edgar (Server Owner)',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    rank: 'SUPER_ADMIN',
    points: 1250,
    status: 'ACTIVE',
    joinedAt: '2023-01-15T00:00:00.000Z',
    updatedAt: new Date().toISOString(),
    notes: 'Supreme Server Owner & Community Founder',
    history: [],
    pointTransactions: []
  },
  {
    id: 2,
    discordId: '831102094521532418',
    username: 'kohan_prime',
    displayName: 'Kohan (Chief Architect)',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
    rank: 'ADMINISTRATOR',
    points: 980,
    status: 'ACTIVE',
    joinedAt: '2023-03-20T00:00:00.000Z',
    updatedAt: new Date().toISOString(),
    notes: 'Chief Community Architect & Lore Keeper',
    history: [],
    pointTransactions: []
  },
  {
    id: 3,
    discordId: '1099135885699727460',
    username: 'enheduanna_archivist',
    displayName: 'Enheduanna',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&auto=format&fit=crop&q=80',
    rank: 'SENIOR_MODERATOR',
    points: 740,
    status: 'ACTIVE',
    joinedAt: '2023-06-10T00:00:00.000Z',
    updatedAt: new Date().toISOString(),
    notes: 'High Priestess of the Archives',
    history: [],
    pointTransactions: []
  },
  {
    id: 4,
    discordId: '1306936292197797929',
    username: 'ur_sentinel',
    displayName: 'Ur Sentinel',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
    rank: 'MODERATOR',
    points: 450,
    status: 'ACTIVE',
    joinedAt: '2023-09-01T00:00:00.000Z',
    updatedAt: new Date().toISOString(),
    notes: 'Gatekeeper of the Sanctum',
    history: [],
    pointTransactions: []
  }
];

// Initial starter announcements
const DEFAULT_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'announcement_standalone_launch',
    title: 'إطلاق النسخة المستقلة الرسمية لمركز الإبداع | Official Standalone Edition',
    content: 'مرحباً بجميع أعضاء مركز الإبداع! تم إطلاق النسخة المستقلة المتكاملة (Single-File Standalone HTML) التي تعمل بشكل مستقل تماماً في أي متصفح دون الحاجة لسيرفر. كافة الميزات من البطاقات والمعارك وشجرة الرتب والأرشيف التاريخي محفوظة وتعمل محلياً.',
    authorDisplayName: 'Edgar (Server Owner)',
    authorDiscordId: '871043296280076308',
    authorAvatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
    category: 'UPDATES',
    imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80',
    isPinned: true,
    isArchived: false,
    publishedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'announcement_card_tournament',
    title: 'بطولة المبارزات الاستراتيجية والبطاقات الأسطورية | Sovereign Duel Arena',
    content: 'تم فتح طور القصة ونظام المبارزات! اجمع بطاقاتك، ركب تشكيلتك التكتيكية في صانع التشكيلات (Deck Builder)، وتحدى زعماء الفصول لربح الكوينز والجوائز النادرة.',
    authorDisplayName: 'Kohan',
    authorDiscordId: '831102094521532418',
    authorAvatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
    category: 'EVENTS',
    imageUrl: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=800&q=80',
    isPinned: false,
    isArchived: false,
    publishedAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString()
  }
];

// Initialize starter data if empty
function initializeStandaloneState() {
  if (typeof window === 'undefined') return;

  if (!localStorage.getItem(STORAGE_KEYS.COINS)) {
    localStorage.setItem(STORAGE_KEYS.COINS, '5000');
  }

  if (!localStorage.getItem(STORAGE_KEYS.OWNED_CARDS)) {
    // Give player initial starter cards
    const initialOwnership: CardOwnership[] = DEFAULT_COLLECTIBLE_CARDS.slice(0, 8).map(card => ({
      cardId: card.id,
      firstAcquiredAt: new Date().toISOString(),
      lastAcquiredAt: new Date().toISOString(),
      count: 2,
      upgradedRarity: card.rarity
    }));
    setStoredJson(STORAGE_KEYS.OWNED_CARDS, initialOwnership);
  }

  if (!localStorage.getItem(STORAGE_KEYS.PROFILE)) {
    const defaultProfile: any = {
      discordId: '871043296280076308',
      coins: 5000,
      favoriteCardId: DEFAULT_COLLECTIBLE_CARDS[0]?.id || null,
      showcaseCardIds: DEFAULT_COLLECTIBLE_CARDS.slice(0, 3).map(c => c.id),
      selectedTitleId: 'archivist_prime',
      featuredBadgeIds: ['badge_founder', 'badge_collector_gold', 'badge_iraq_meso'],
      equippedCardBackUrl: '',
      dailyStreak: 3,
      lastDailyClaim: new Date(Date.now() - 86400000).toISOString(),
      totalPacksOpened: 12,
      totalAscensions: 4,
      totalBattlesWon: 8,
      pvpRating: 1450,
      pvpWins: 14,
      pvpLosses: 3,
      unlockedThemes: ['creative-nexus', 'kohan-iraqi'],
      unlockedFlags: ['flag_ur', 'flag_babylon', 'flag_nineveh']
    };
    setStoredJson(STORAGE_KEYS.PROFILE, defaultProfile);
  }

  if (!localStorage.getItem(STORAGE_KEYS.INVENTORY)) {
    const initialInventory: Record<string, { itemId: string; count: number }> = {};
    DEFAULT_UNIFIED_ITEMS.slice(0, 8).forEach(item => {
      initialInventory[item.id] = { itemId: item.id, count: 5 };
    });
    setStoredJson(STORAGE_KEYS.INVENTORY, initialInventory);
  }

  if (!localStorage.getItem(STORAGE_KEYS.DECKS)) {
    const starterCardIds = DEFAULT_COLLECTIBLE_CARDS.slice(0, 4).map(c => c.id);
    const starterDeck: PlayerDeck = {
      id: 'deck_starter_prime',
      userId: '871043296280076308',
      name: 'تشكيلة السيادة الأولى (Prime Deck)',
      banner: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80',
      cardIds: starterCardIds,
      itemIds: [DEFAULT_UNIFIED_ITEMS[0]?.id || 'item_date_honey'],
      isActive: true,
      power: 360,
      defense: 340,
      speed: 350,
      synergy: 92,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setStoredJson(STORAGE_KEYS.DECKS, [starterDeck]);
    try {
      localStorage.setItem('nexus_player_decks', JSON.stringify([starterDeck]));
    } catch {}
  }

  if (!localStorage.getItem(STORAGE_KEYS.STAFF)) {
    setStoredJson(STORAGE_KEYS.STAFF, DEFAULT_STAFF_MEMBERS);
  }

  if (!localStorage.getItem(STORAGE_KEYS.ANNOUNCEMENTS)) {
    setStoredJson(STORAGE_KEYS.ANNOUNCEMENTS, DEFAULT_ANNOUNCEMENTS);
  }
}

export function installStandaloneInterceptor() {
  if (typeof window === 'undefined') return;

  initializeStandaloneState();

  if (typeof window.fetch !== 'function') return;

  const originalFetch = window.fetch.bind(window);

  const customFetch = async function (input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
    const url = typeof input === 'string' ? input : input instanceof Request ? input.url : String(input);

    // If request is not an API call, delegate to original fetch
    if (!url.includes('/api/')) {
      return originalFetch(input, init);
    }

    // If on file: protocol or explicit standalone, handle locally
    if (isStandalone) {
      try {
        const mockRes = handleMockApi(url, init);
        if (mockRes) return mockRes;
      } catch (err) {
        console.warn('[Standalone API] Local handler notice:', err);
      }
    }

    // Try real fetch first for HTTP/HTTPS servers
    try {
      const res = await originalFetch(input, init);
      if (res.ok || res.status < 500) {
        return res;
      }
      // If server returned 404 or 500 for an API endpoint in offline/static preview, fallback
      const mockRes = handleMockApi(url, init);
      if (mockRes) return mockRes;
      return res;
    } catch (networkError) {
      // Server down or offline, fallback to standalone handler
      const mockRes = handleMockApi(url, init);
      if (mockRes) return mockRes;
      throw networkError;
    }
  };

  try {
    Object.defineProperty(window, 'fetch', {
      value: customFetch,
      writable: true,
      configurable: true,
      enumerable: true,
    });
  } catch {
    try {
      (window as any).fetch = customFetch;
    } catch {
      try {
        Object.defineProperty(Object.getPrototypeOf(window), 'fetch', {
          value: customFetch,
          writable: true,
          configurable: true,
          enumerable: true,
        });
      } catch (err) {
        console.warn('Standalone fetch interceptor could not be attached:', err);
      }
    }
  }
}

// Dispatch API routes locally
function handleMockApi(url: string, init?: RequestInit): Response | null {
  const method = (init?.method || 'GET').toUpperCase();
  const path = url.replace(/^https?:\/\/[^/]+/, '').split('?')[0];

  // 1. Auth routes
  if (path === '/api/auth/me') {
    return jsonResponse({
      authenticated: true,
      user: {
        id: 1,
        discordId: '871043296280076308',
        username: 'CreativeNexusExplorer',
        displayName: 'Creative Nexus Sovereign',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        isOwner: true,
        isAdmin: true,
        isModerator: true,
        permissions: ['ALL_PERMISSIONS']
      }
    });
  }

  if (path === '/api/auth/discord/config') {
    return jsonResponse({ configured: true, clientId: '1548702834755637369' });
  }

  if (path === '/api/auth/moderator-role-config') {
    return jsonResponse({ configured: true, roles: ['Owner', 'Admin', 'Archivist', 'Moderator'] });
  }

  // 2. Staff Management & Discord Sync
  if (path === '/api/staff') {
    const staffList = getStoredJson<StaffMember[]>(STORAGE_KEYS.STAFF, DEFAULT_STAFF_MEMBERS);
    if (method === 'POST') {
      const body = init?.body ? JSON.parse(String(init.body)) : {};
      const newStaff: StaffMember = {
        id: Date.now(),
        discordId: body.discordId || String(Date.now()),
        username: body.username || 'new_staff',
        displayName: body.displayName || body.username || 'New Staff',
        avatarUrl: body.avatarUrl || 'https://cdn.discordapp.com/embed/avatars/0.png',
        rank: body.rank || 'MODERATOR',
        points: Number(body.points) || 100,
        status: body.status || 'ACTIVE',
        notes: body.notes || '',
        joinedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        history: [],
        pointTransactions: []
      };
      staffList.push(newStaff);
      setStoredJson(STORAGE_KEYS.STAFF, staffList);
      return jsonResponse(newStaff, 201);
    }
    return jsonResponse(staffList);
  }

  if (path.startsWith('/api/staff/') && !path.includes('/points') && !path.includes('/discord-sync')) {
    const targetId = path.replace('/api/staff/', '').trim();
    const staffList = getStoredJson<StaffMember[]>(STORAGE_KEYS.STAFF, DEFAULT_STAFF_MEMBERS);
    const index = staffList.findIndex(s => String(s.id) === targetId || s.discordId === targetId);

    if (method === 'DELETE') {
      if (index !== -1) {
        staffList.splice(index, 1);
        setStoredJson(STORAGE_KEYS.STAFF, staffList);
      }
      return jsonResponse({ success: true });
    }

    if (method === 'PUT') {
      const body = init?.body ? JSON.parse(String(init.body)) : {};
      if (index !== -1) {
        staffList[index] = { ...staffList[index], ...body, updatedAt: new Date().toISOString() };
        setStoredJson(STORAGE_KEYS.STAFF, staffList);
        return jsonResponse(staffList[index]);
      }
      return jsonResponse({ error: 'Staff member not found' }, 404);
    }

    if (index !== -1) {
      return jsonResponse(staffList[index]);
    }
    return jsonResponse(staffList[0] || DEFAULT_STAFF_MEMBERS[0]);
  }

  if (path === '/api/staff/points' && method === 'POST') {
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    const { staffId, amount, type, reason } = body;
    const staffList = getStoredJson<StaffMember[]>(STORAGE_KEYS.STAFF, DEFAULT_STAFF_MEMBERS);
    const target = staffList.find(s => String(s.id) === String(staffId) || s.discordId === String(staffId));
    if (target) {
      const delta = type === 'REMOVE' ? -Math.abs(amount) : Math.abs(amount);
      target.points = Math.max(0, (target.points || 0) + delta);
      target.pointTransactions = target.pointTransactions || [];
      target.pointTransactions.unshift({
        id: Date.now(),
        staffId: target.id,
        amount: Math.abs(amount),
        type: type || 'ADD',
        reason: reason || 'Manual adjustment',
        note: null,
        performedBy: 'Edgar (Owner)',
        createdAt: new Date().toISOString()
      });
      setStoredJson(STORAGE_KEYS.STAFF, staffList);
      return jsonResponse({ success: true, member: target });
    }
    return jsonResponse({ success: true });
  }

  if (path === '/api/staff/discord-sync') {
    return jsonResponse({
      success: true,
      syncedAt: new Date().toISOString(),
      updatedCount: 4,
      message: 'Discord staff directory synchronized successfully!'
    });
  }

  // 3. Discord Server Widget & Live Status
  if (path === '/api/discord/server-status' || path === '/api/discord/widget') {
    return jsonResponse({
      success: true,
      guildId: '1337616297432842252',
      serverName: 'Creative Nexus | مركز الإبداع',
      onlineCount: 242,
      totalMembers: 580,
      staffCount: 16,
      channelsCount: 38,
      boostCount: 14,
      boostLevel: 2,
      instantInvite: 'https://discord.gg/7wEm4bhc',
      iconUrl: 'https://cdn.discordapp.com/icons/1337616297432842252/3fa0c7a525135a95cac97bd0128205cb.png?size=256'
    });
  }

  if (path === '/api/discord/guild-config') {
    return jsonResponse({
      success: true,
      guildId: '1337616297432842252',
      serverName: 'Creative Nexus | مركز الإبداع'
    });
  }

  // 4. Announcements
  if (path === '/api/announcements') {
    const list = getStoredJson<Announcement[]>(STORAGE_KEYS.ANNOUNCEMENTS, DEFAULT_ANNOUNCEMENTS);
    if (method === 'POST') {
      const body = init?.body ? JSON.parse(String(init.body)) : {};
      const newAnn: Announcement = {
        id: `ann_${Date.now()}`,
        title: body.title || 'إعلان جديد',
        content: body.content || '',
        authorDisplayName: body.authorDisplayName || 'Edgar',
        authorDiscordId: '871043296280076308',
        authorAvatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
        category: body.category || 'General',
        imageUrl: body.imageUrl,
        images: body.images,
        isPinned: Boolean(body.isPinned),
        isArchived: false,
        publishedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      list.unshift(newAnn);
      setStoredJson(STORAGE_KEYS.ANNOUNCEMENTS, list);
      return jsonResponse({ success: true, announcement: newAnn });
    }
    return jsonResponse({ success: true, announcements: list });
  }

  if (path.startsWith('/api/announcements/')) {
    const id = path.replace('/api/announcements/', '').trim();
    const list = getStoredJson<Announcement[]>(STORAGE_KEYS.ANNOUNCEMENTS, DEFAULT_ANNOUNCEMENTS);
    const ann = list.find(a => a.id === id);
    if (ann) {
      return jsonResponse({ success: true, announcement: ann });
    }
    return jsonResponse({ success: true, announcement: list[0] });
  }

  // 5. Cards catalog, collection & pack opening
  if (path === '/api/cards/catalog') {
    const customCards = getStoredJson<CollectibleCardData[]>(STORAGE_KEYS.CUSTOM_CARDS, []);
    const cards = customCards.length > 0 ? customCards : DEFAULT_COLLECTIBLE_CARDS;
    return jsonResponse({
      success: true,
      packs: CARD_PACKS,
      cards,
      totalCards: cards.length,
      ratingSettings: { fontSize: 13, offsetX: 0, offsetY: 0 }
    });
  }

  if (path === '/api/cards/me') {
    const profile = getStoredJson<any>(STORAGE_KEYS.PROFILE, {} as any);
    const ownedCards = getStoredJson<CardOwnership[]>(STORAGE_KEYS.OWNED_CARDS, []);
    return jsonResponse({
      success: true,
      profile,
      ownedCards
    });
  }

  if (path === '/api/cards/card-back') {
    const url = localStorage.getItem(STORAGE_KEYS.CARD_BACK) || '';
    return jsonResponse({ success: true, url });
  }

  if (path === '/api/cards/owner/card-back' && method === 'POST') {
    try {
      const body = init?.body ? JSON.parse(String(init.body)) : {};
      if (body.url !== undefined) {
        localStorage.setItem(STORAGE_KEYS.CARD_BACK, body.url);
      }
      return jsonResponse({ success: true, url: body.url });
    } catch {
      return jsonResponse({ success: true });
    }
  }

  if (path === '/api/cards/daily-claim' && method === 'POST') {
    const profile = getStoredJson<any>(STORAGE_KEYS.PROFILE, {} as any);
    profile.coins = (profile.coins || 0) + 250;
    profile.dailyStreak = (profile.dailyStreak || 0) + 1;
    profile.lastDailyClaim = new Date().toISOString();
    setStoredJson(STORAGE_KEYS.PROFILE, profile);
    return jsonResponse({
      success: true,
      claimedCoins: 250,
      newTotalCoins: profile.coins,
      dailyStreak: profile.dailyStreak,
      nextClaimInMs: 86400000
    });
  }

  if (path === '/api/cards/open-pack' && method === 'POST') {
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    const packRarity = (body.packType || 'COMMON') as CardRarity;
    const pack = CARD_PACKS.find(p => p.rarity === packRarity) || CARD_PACKS[0];

    const profile = getStoredJson<any>(STORAGE_KEYS.PROFILE, {} as any);
    const cost = pack.price || 10;
    if ((profile.coins || 0) < cost) {
      return jsonResponse({ error: 'Insufficient coins', success: false }, 400);
    }

    profile.coins -= cost;
    profile.totalPacksOpened = (profile.totalPacksOpened || 0) + 1;
    setStoredJson(STORAGE_KEYS.PROFILE, profile);

    const candidateCards = DEFAULT_COLLECTIBLE_CARDS.filter(c => c.rarity === packRarity);
    const pool = candidateCards.length > 0 ? candidateCards : DEFAULT_COLLECTIBLE_CARDS;
    const pickedCard = pool[Math.floor(Math.random() * pool.length)] || DEFAULT_COLLECTIBLE_CARDS[0];

    const ownedCards = getStoredJson<CardOwnership[]>(STORAGE_KEYS.OWNED_CARDS, []);
    const existing = ownedCards.find(o => o.cardId === pickedCard.id);
    let isNew = false;
    if (existing) {
      existing.count = (existing.count || 1) + 1;
    } else {
      isNew = true;
      ownedCards.push({
        cardId: pickedCard.id,
        firstAcquiredAt: new Date().toISOString(),
        lastAcquiredAt: new Date().toISOString(),
        count: 1,
        upgradedRarity: pickedCard.rarity
      });
    }
    setStoredJson(STORAGE_KEYS.OWNED_CARDS, ownedCards);

    return jsonResponse({
      success: true,
      card: pickedCard,
      cards: [pickedCard],
      isNew,
      newTotalCoins: profile.coins,
      rewardItems: []
    });
  }

  // 6. Card Upgrades
  if (path === '/api/cards/upgrade-config') {
    return jsonResponse({
      success: true,
      config: {
        COMMON: { targetRarity: 'UNCOMMON', requiredCards: 3, requiredCoins: 100, successRate: 100 },
        UNCOMMON: { targetRarity: 'RARE', requiredCards: 3, requiredCoins: 250, successRate: 90 },
        RARE: { targetRarity: 'EPIC', requiredCards: 3, requiredCoins: 500, successRate: 80 },
        EPIC: { targetRarity: 'LEGENDARY', requiredCards: 3, requiredCoins: 1000, successRate: 70 },
        LEGENDARY: { targetRarity: 'HALLOWEEN_2026', requiredCards: 3, requiredCoins: 2500, successRate: 60 },
        HALLOWEEN_2026: { targetRarity: null, requiredCards: 0, requiredCoins: 0, successRate: 0 }
      }
    });
  }

  if (path === '/api/cards/upgrade' && method === 'POST') {
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    const { cardId } = body;
    const ownedCards = getStoredJson<CardOwnership[]>(STORAGE_KEYS.OWNED_CARDS, []);
    const profile = getStoredJson<any>(STORAGE_KEYS.PROFILE, {});
    const existing = ownedCards.find(o => o.cardId === cardId);

    if (!existing || existing.count < 3) {
      return jsonResponse({
        success: true,
        isSuccess: true,
        message: 'تمت ترقية البطاقة وإضافة شظايا نادرة إلى رصيدك!',
        cardId,
        newRarity: existing?.upgradedRarity || 'RARE',
        awardedShards: 10
      });
    }

    existing.count = Math.max(1, existing.count - 2);
    existing.upgradedRarity = 'EPIC';
    existing.upgradedAt = new Date().toISOString();
    setStoredJson(STORAGE_KEYS.OWNED_CARDS, ownedCards);
    profile.coins = Math.max(0, (profile.coins || 0) - 100);
    profile.totalAscensions = (profile.totalAscensions || 0) + 1;
    setStoredJson(STORAGE_KEYS.PROFILE, profile);

    return jsonResponse({
      success: true,
      isSuccess: true,
      message: 'تهانينا! تمت ترقية البطاقة بنجاح فائق!',
      cardId,
      newRarity: 'EPIC',
      awardedShards: 5
    });
  }

  if (path === '/api/cards/duplicate-config') {
    return jsonResponse({
      success: true,
      config: {
        COMMON: { rewardCoins: 10, rewardShards: 2 },
        UNCOMMON: { rewardCoins: 25, rewardShards: 5 },
        RARE: { rewardCoins: 50, rewardShards: 10 },
        EPIC: { rewardCoins: 100, rewardShards: 20 },
        LEGENDARY: { rewardCoins: 250, rewardShards: 50 },
        HALLOWEEN_2026: { rewardCoins: 300, rewardShards: 60 }
      }
    });
  }

  if (path === '/api/cards/showcase' && method === 'POST') {
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    const profile = getStoredJson<any>(STORAGE_KEYS.PROFILE, {} as any);
    profile.showcaseCardIds = body.showcaseCardIds || [];
    setStoredJson(STORAGE_KEYS.PROFILE, profile);
    return jsonResponse({ success: true, showcaseCardIds: profile.showcaseCardIds });
  }

  if (path === '/api/cards/profile/customize' && method === 'POST') {
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    const profile = getStoredJson<any>(STORAGE_KEYS.PROFILE, {} as any);
    Object.assign(profile, body);
    setStoredJson(STORAGE_KEYS.PROFILE, profile);
    return jsonResponse({ success: true, profile });
  }

  if (path === '/api/cards/owner/give-coins' && method === 'POST') {
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    const profile = getStoredJson<any>(STORAGE_KEYS.PROFILE, {} as any);
    profile.coins = (profile.coins || 0) + (Number(body.amount) || 1000);
    setStoredJson(STORAGE_KEYS.PROFILE, profile);
    return jsonResponse({ success: true, newCoins: profile.coins });
  }

  // 7. Decks Management
  if (path === '/api/decks') {
    const decks = getStoredJson<PlayerDeck[]>(STORAGE_KEYS.DECKS, []);
    if (method === 'POST') {
      const body = init?.body ? JSON.parse(String(init.body)) : {};
      const newDeck: PlayerDeck = {
        id: body.id || `deck_${Date.now()}`,
        userId: '871043296280076308',
        name: body.name || 'Custom Deck',
        banner: body.banner,
        cardIds: body.cardIds || [],
        itemIds: body.itemIds || [],
        isActive: Boolean(body.isActive),
        power: 380,
        defense: 350,
        speed: 360,
        synergy: 95,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      if (newDeck.isActive) {
        decks.forEach(d => { d.isActive = false; });
      }

      const existingIdx = decks.findIndex(d => d.id === newDeck.id);
      if (existingIdx !== -1) {
        decks[existingIdx] = newDeck;
      } else {
        decks.push(newDeck);
      }
      setStoredJson(STORAGE_KEYS.DECKS, decks);
      try {
        localStorage.setItem('nexus_player_decks', JSON.stringify(decks));
      } catch {}
      return jsonResponse({ success: true, deck: newDeck });
    }
    return jsonResponse({ success: true, decks });
  }

  // 8. Items and inventory
  if (path === '/api/items') {
    return jsonResponse({ success: true, items: DEFAULT_UNIFIED_ITEMS });
  }

  if (path === '/api/items/my-inventory') {
    const inventory = getStoredJson<any>(STORAGE_KEYS.INVENTORY, {});
    return jsonResponse({ success: true, inventory, inventoryMap: inventory });
  }

  // 9. Combat arena
  if (path === '/api/combat/rules') {
    return jsonResponse({
      success: true,
      rules: {
        attackMultiplier: 1.0,
        defenseMultiplier: 1.0,
        energyCostPerTurn: 10
      }
    });
  }

  if (path === '/api/combat/preset') {
    return jsonResponse({ success: true, presets: [] });
  }

  if (path === '/api/combat/skills') {
    return jsonResponse({ success: true, skills: [] });
  }

  // 10. Story campaign
  if (path === '/api/story/chapters') {
    return jsonResponse({ success: true, chapters: STORY_CHAPTERS });
  }

  if (path === '/api/story/progress') {
    const progress = getStoredJson<any>(STORAGE_KEYS.STORY, {
      completedBattleIds: ['ch1_b1'],
      claimedFirstClearIds: ['ch1_b1'],
      unlockedBattleIds: ['ch1_b1', 'ch1_b2']
    });
    return jsonResponse({ success: true, progress });
  }

  if (path === '/api/story/complete-battle' && method === 'POST') {
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    const battleId = body.battleId || 'ch1_b1';
    const story = getStoredJson<any>(STORAGE_KEYS.STORY, {
      completedBattleIds: [],
      claimedFirstClearIds: [],
      unlockedBattleIds: ['ch1_b1']
    });

    if (!story.completedBattleIds.includes(battleId)) {
      story.completedBattleIds.push(battleId);
    }
    setStoredJson(STORAGE_KEYS.STORY, story);

    const profile = getStoredJson<any>(STORAGE_KEYS.PROFILE, {} as any);
    profile.coins = (profile.coins || 0) + 100;
    profile.totalBattlesWon = (profile.totalBattlesWon || 0) + 1;
    setStoredJson(STORAGE_KEYS.PROFILE, profile);

    return jsonResponse({
      success: true,
      coinsEarned: 100,
      xpEarned: 120,
      newTotalCoins: profile.coins
    });
  }

  // 11. Character Love
  if (path === '/api/character-love/characters') {
    const loveState = getStoredJson<any>(STORAGE_KEYS.CHAR_LOVE, {});
    const characters = DEFAULT_CHARACTERS.map(c => {
      const saved = loveState[c.id];
      if (saved) {
        return { ...c, ...saved };
      }
      return c;
    });
    return jsonResponse({ success: true, characters });
  }

  if (path === '/api/character-love/items') {
    return jsonResponse({ success: true, items: DEFAULT_UNIFIED_ITEMS.slice(0, 10) });
  }

  if (path === '/api/character-love/thresholds') {
    return jsonResponse({
      success: true,
      thresholds: [
        { level: 1, requiredPoints: 0, title: 'Neophyte', rewardCoins: 50 },
        { level: 2, requiredPoints: 100, title: 'Kindred', rewardCoins: 100 },
        { level: 3, requiredPoints: 300, title: 'Companion', rewardCoins: 200 },
        { level: 4, requiredPoints: 600, title: 'Beloved', rewardCoins: 350 },
        { level: 5, requiredPoints: 1000, title: 'Sovereign Bond', rewardCoins: 500 }
      ]
    });
  }

  if (path === '/api/character-love/give-gift' && method === 'POST') {
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    const { characterId, itemId, amount = 1 } = body;
    const loveState = getStoredJson<any>(STORAGE_KEYS.CHAR_LOVE, {});
    const char = loveState[characterId] || { currentLevel: 1, currentLovePoints: 0 };
    char.currentLovePoints = (char.currentLovePoints || 0) + (50 * amount);
    if (char.currentLovePoints >= 1000) char.currentLevel = 5;
    else if (char.currentLovePoints >= 600) char.currentLevel = 4;
    else if (char.currentLovePoints >= 300) char.currentLevel = 3;
    else if (char.currentLovePoints >= 100) char.currentLevel = 2;
    loveState[characterId] = char;
    setStoredJson(STORAGE_KEYS.CHAR_LOVE, loveState);

    return jsonResponse({
      success: true,
      lovePointsAdded: 50 * amount,
      newLovePoints: char.currentLovePoints,
      newLevel: char.currentLevel,
      didLevelUp: true
    });
  }

  // 12. Easter eggs & themes
  if (path === '/api/easter-eggs/status') {
    return jsonResponse({
      success: true,
      unlockedFlags: ['flag_ur', 'flag_babylon'],
      iraqiThemeUnlocked: true,
      secretRoomUnlocked: true
    });
  }

  if (path === '/api/easter-eggs/set-theme' && method === 'POST') {
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    localStorage.setItem(STORAGE_KEYS.THEME, body.theme || 'kohan-iraqi');
    return jsonResponse({ success: true, theme: body.theme });
  }

  // 13. Site logo & settings
  if (path === '/api/settings/site-logo') {
    const logo = getStoredJson<any>(STORAGE_KEYS.SITE_LOGO, {
      text: 'مركز الإبداع',
      subtitle: 'CREATIVE NEXUS',
      iconType: 'sparkles',
      glowColor: '#5eead4'
    });
    return jsonResponse({ success: true, logo });
  }

  if (path === '/api/settings/main-menu-background') {
    return jsonResponse({
      success: true,
      background: {
        imageUrl: '',
        opacity: 0.88,
        blur: 0,
        dim: 0.25
      }
    });
  }

  if (path === '/api/history/owner-card-backgrounds') {
    return jsonResponse({ success: true, backgrounds: [] });
  }

  if (path === '/api/history/owner-cards') {
    return jsonResponse({ success: true, cards: DEFAULT_COLLECTIBLE_CARDS.slice(0, 5) });
  }

  if (path === '/api/notifications') {
    return jsonResponse({
      success: true,
      notifications: [
        {
          id: 'notif_welcome',
          title: 'Welcome to Creative Nexus Standalone Edition',
          titleAr: 'مرحباً بك في مركز الإبداع - النسخة المتكاملة المستقلة',
          message: 'All features, cards, combat, and archives are running locally in your browser!',
          type: 'SYSTEM',
          isRead: false,
          createdAt: new Date().toISOString()
        }
      ]
    });
  }

  // Catch-all for any other /api routes
  return jsonResponse({ success: true, standalone: true });
}
