import { CollectibleCardData, CardAbility, CardStateItem } from '../types/cards';
import { 
  BattleCardEntity, 
  BattleLogEntry, 
  BattleActionType, 
  BattleSessionState,
  TacticalMomentum,
  TacticalStance,
  CombatMomentType,
  BattleActionOutcome,
  BattleDifficulty,
  CombatIntent,
  CombatIntentType,
  RoundClashResolution,
  ClashCategory,
  EnemyIntentType,
  EnemyIntentInfo,
  ClashResultData,
  CardCombatSkill,
  ACTION_CONFIGS
} from '../types/story';
import { evaluateAiActionScores, evaluateAiCardSwitch } from './aiCombatBrain';
import { VALID_ACTIONS, ACTIONS, validateAIAction } from '../config/combatActions';
import { MODERN_CARD_ASSETS } from '../assets/modernCardAssets';

export const FALLBACK_STARTER_CARDS: CollectibleCardData[] = [
  {
    id: 'starter_aegis_valkyrie',
    name: 'Aegis Valkyrie',
    title: 'Sentinels of Ur',
    rarity: 'RARE',
    packType: 'RARE',
    description: 'Elite frontline cyber-sentinel of the Sanctuary.',
    lore: 'Forged in the stellar forges of ancient Babylon.',
    imageUrl: MODERN_CARD_ASSETS.cardAegisValkyrie,
    attack: 75,
    defense: 80,
    hp: 100,
    element: 'STORM',
    power: 250,
    series: 'PROVING_GROUNDS',
    cardNumber: 1,
    accentColor: '#5eead4',
    abilities: [
      {
        id: 'ab_valkyrie_surge',
        name: 'Fortify',
        description: 'Reduce incoming damage by 70% for one turn.',
        type: 'ACTIVE',
        cooldown: 3,
        powerValue: 45
      }
    ]
  },
  {
    id: 'starter_apex_sovereign',
    name: 'Apex Sovereign',
    title: 'High Sovereign Prime',
    rarity: 'LEGENDARY',
    packType: 'LEGENDARY',
    description: 'Supreme overlord of the celestial proving grounds.',
    lore: 'Rules over the cosmic nexus with iron will.',
    imageUrl: MODERN_CARD_ASSETS.cardApexSovereign,
    attack: 90,
    defense: 70,
    hp: 100,
    element: 'FIRE',
    power: 260,
    series: 'PROVING_GROUNDS',
    cardNumber: 2,
    accentColor: '#f59e0b',
    abilities: [
      {
        id: 'ab_apex_overdrive',
        name: 'Rage',
        description: 'Next Heavy attack deals +50% damage.',
        type: 'ULTIMATE',
        cooldown: 3,
        powerValue: 60
      }
    ]
  },
  {
    id: 'starter_chrono_architect',
    name: 'Chrono Architect',
    title: 'Architect of Babylon',
    rarity: 'EPIC',
    packType: 'EPIC',
    description: 'Master of temporal battlefields and spatial shifts.',
    lore: 'Weaver of past, present, and future timelines.',
    imageUrl: MODERN_CARD_ASSETS.cardChronoArchitect,
    attack: 80,
    defense: 75,
    hp: 100,
    element: 'ASTRAL',
    power: 245,
    series: 'PROVING_GROUNDS',
    cardNumber: 3,
    accentColor: '#a855f7',
    abilities: [
      {
        id: 'ab_chrono_shift',
        name: 'Arcane Blast',
        description: 'Deals 25 damage regardless of normal matchup.',
        type: 'ACTIVE',
        cooldown: 2,
        powerValue: 40
      }
    ]
  },
  {
    id: 'starter_shadow_operative',
    name: 'Shadow Operative',
    title: 'Silent Blade of Ur',
    rarity: 'RARE',
    packType: 'RARE',
    description: 'Infiltrates deep behind enemy lines with high lethal precision.',
    lore: 'Trained in the silent halls beneath the ancient sanctuary.',
    imageUrl: MODERN_CARD_ASSETS.cardShadowOperative,
    attack: 85,
    defense: 65,
    hp: 100,
    element: 'ASTRAL',
    power: 240,
    series: 'PROVING_GROUNDS',
    cardNumber: 4,
    accentColor: '#38bdf8',
    abilities: [
      {
        id: 'ab_shadow_strike',
        name: 'Quickstep',
        description: 'Immediately dodge next incoming attack (deals 0 damage).',
        type: 'OFFENSIVE',
        cooldown: 3,
        powerValue: 42
      }
    ]
  }
];

// =========================================================================
// FIVE CANONICAL COMBAT SKILLS (USER SPECIFICATION)
// =========================================================================
export const DEFAULT_CARD_SKILLS: Record<string, CardCombatSkill> = {
  fortify: {
    id: 'skill_fortify',
    name: 'Fortify',
    nameAr: 'تحصين درعي',
    description: 'Reduce incoming damage by 70% for one turn.',
    descriptionAr: 'درع حصين يقلص الضرر المتلقى بنسبة 70% لجولة كاملة.',
    icon: 'Shield',
    type: 'DEFENSIVE',
    damage: 0,
    defenseModifier: 0.70,
    staminaCost: 15,
    energyCost: 30,
    cooldown: 3,
    currentCooldown: 0,
    duration: 1,
    target: 'SELF',
    priority: 2,
    startup: 0.2,
    interruptible: false,
    defenseInteraction: 'ABSORB',
    effects: { incomingDamageReduction: 0.70 }
  },
  rage: {
    id: 'skill_rage',
    name: 'Rage',
    nameAr: 'غضب هائج',
    description: 'Next Heavy attack deals +50% damage.',
    descriptionAr: 'الضربة الثقيلة القادمة تسدد +50% ضرر إضافي.',
    icon: 'Flame',
    type: 'BUFF',
    damage: 0,
    staminaCost: 20,
    energyCost: 40,
    cooldown: 3,
    currentCooldown: 0,
    duration: 1,
    target: 'SELF',
    priority: 1,
    startup: 0.2,
    interruptible: false,
    defenseInteraction: 'IGNORES_DEFENSE',
    effects: { heavyDamageMultiplier: 1.5 }
  },
  arcane_blast: {
    id: 'skill_arcane_blast',
    name: 'Arcane Blast',
    nameAr: 'انفجار سحري',
    description: 'Deals 25 damage regardless of normal matchup.',
    descriptionAr: 'يسدد 25 ضرر سحري لا يمكن صده مهما كانت وضعية الخصم.',
    icon: 'Sparkles',
    type: 'OFFENSIVE',
    damage: 25,
    staminaCost: 15,
    energyCost: 40,
    cooldown: 2,
    currentCooldown: 0,
    duration: 1,
    target: 'ENEMY',
    priority: 1,
    startup: 0.35,
    interruptible: true, // STRIKE interrupts it!
    defenseInteraction: 'IGNORES_DEFENSE',
    effects: { unblockable: true }
  },
  quickstep: {
    id: 'skill_quickstep',
    name: 'Quickstep',
    nameAr: 'خطوة خاطفة',
    description: 'Immediately dodge next incoming attack (deals 0 damage).',
    descriptionAr: 'تفادي فوري للهجوم القادم وتلقي 0 ضرر.',
    icon: 'Zap',
    type: 'DODGE',
    damage: 0,
    staminaCost: 15,
    energyCost: 35,
    cooldown: 3,
    currentCooldown: 0,
    duration: 1,
    target: 'SELF',
    priority: 1,
    startup: 0.15,
    interruptible: false,
    defenseInteraction: 'IGNORES_DEFENSE',
    effects: { dodgeNextAttack: true }
  },
  lifesteal: {
    id: 'skill_lifesteal',
    name: 'Lifesteal',
    nameAr: 'امتصاص الحياة',
    description: 'Deals 15 damage and heals user for 8 HP.',
    descriptionAr: 'يسدد 15 ضرر ويمتص 8 نقاط صحة لحساب المستخدم.',
    icon: 'Heart',
    type: 'LIFESTEAL',
    damage: 15,
    staminaCost: 15,
    energyCost: 35,
    cooldown: 2,
    currentCooldown: 0,
    duration: 1,
    target: 'ENEMY',
    priority: 1,
    startup: 0.30,
    interruptible: true,
    defenseInteraction: 'BLOCKED_BY_DEFENSE',
    effects: { healAmount: 8 }
  }
};

/**
 * Initializes battle card entities with 100 HP, 100 Stamina, 100 Max Energy, and unique skills.
 */
export function initializeBattleCards(cards: CollectibleCardData[] | undefined | null, sidePrefix: string): BattleCardEntity[] {
  // If cards are provided, use strictly the chosen cards (do not add extra cards if less than 4!)
  let safeCards = Array.isArray(cards) && cards.length > 0 ? [...cards.slice(0, 4)] : [];
  
  // Only if completely empty (0 cards selected), provide starter cards so battle can run
  if (safeCards.length === 0) {
    safeCards = [...FALLBACK_STARTER_CARDS.slice(0, 4)];
  }

  const squad = safeCards.slice(0, 4);

  const roles: ('VANGUARD' | 'STRIKER' | 'BULWARK' | 'TACTICIAN')[] = [
    'VANGUARD',
    'STRIKER',
    'BULWARK',
    'TACTICIAN'
  ];

  const archetypes: ('SCOUT' | 'BRUTE' | 'GUARDIAN' | 'MAGE' | 'BOSS' | 'ASSASSIN')[] = [
    'GUARDIAN',
    'BRUTE',
    'MAGE',
    'SCOUT'
  ];

  const skillKeys = ['fortify', 'rage', 'arcane_blast', 'quickstep', 'lifesteal'];

  return squad.map((card, idx) => {
    const atk = typeof card.attack === 'number' && card.attack > 0 ? card.attack : 75;
    const def = typeof card.defense === 'number' && card.defense > 0 ? card.defense : 65;

    // Standardized 100 Max HP base for balanced 15/30 damage combat
    const maxHp = 100;

    const rawRarity = (card.rarity || 'COMMON').toUpperCase();
    const hasCombatSkill = rawRarity === 'RARE' || rawRarity === 'EPIC' || rawRarity === 'LEGENDARY';

    const assignedSkillKey = skillKeys[idx % skillKeys.length];
    const baseSkill = DEFAULT_CARD_SKILLS[assignedSkillKey] || DEFAULT_CARD_SKILLS.fortify;
    const skillInstance: CardCombatSkill | undefined = hasCombatSkill ? {
      ...baseSkill,
      currentCooldown: 0
    } : undefined;

    const initialStates: CardStateItem[] = Array.isArray(card.states)
      ? card.states.map(s => ({ ...s, active: true }))
      : [];

    return {
      instanceId: `${sidePrefix}_card_${idx}_${card.id}`,
      card,
      maxHp,
      currentHp: maxHp,
      shield: 0,
      maxEnergy: 100,
      currentEnergy: 35, // Starting tactical energy
      maxStamina: 100,
      currentStamina: 100, // Full starting stamina
      isExhausted: false,
      skill: skillInstance,
      counterWindow: false,
      isStaggered: false,
      activeBuffs: undefined,
      attack: atk,
      defense: def,
      speed: 60 + idx * 5,
      clashMastery: 10 + (idx * 5),
      archetype: archetypes[idx % archetypes.length],
      specialAbilityType: 'STANDARD',
      isDefending: false,
      stance: 'NORMAL',
      defenseBuffTurns: 0,
      abilityCooldown: 0,
      isDefeated: false,
      selectedAbility: card.abilities?.[0],
      states: initialStates,
      element: card.element || (idx % 2 === 0 ? 'STONE' : 'LIGHTNING'),
      rarity: card.rarity || 'COMMON',
      formationRole: roles[idx % roles.length]
    };
  });
}

export function createInitialMomentum(): TacticalMomentum {
  return {
    comboCount: 0,
    maxCombo: 0,
    momentumPoints: 25,
    isComboPrimed: false
  };
}

export function countAliveCards(cards: BattleCardEntity[]): number {
  return cards.filter(c => !c.isDefeated && c.currentHp > 0).length;
}

export function getNextAliveCardIndex(cards: BattleCardEntity[], preferredIndex: number = 0): number {
  if (!cards || cards.length === 0) return -1;
  if (cards[preferredIndex] && !cards[preferredIndex].isDefeated && cards[preferredIndex].currentHp > 0) {
    return preferredIndex;
  }
  for (let i = 0; i < cards.length; i++) {
    const idx = (preferredIndex + i) % cards.length;
    if (cards[idx] && !cards[idx].isDefeated && cards[idx].currentHp > 0) {
      return idx;
    }
  }
  return -1;
}

export function determineInitiative(
  playerCard: BattleCardEntity | undefined,
  enemyCard: BattleCardEntity | undefined,
  playerMomentum: number = 0,
  enemyMomentum: number = 0
): 'PLAYER' | 'ENEMY' {
  if (!playerCard || playerCard.isDefeated) return 'ENEMY';
  if (!enemyCard || enemyCard.isDefeated) return 'PLAYER';

  const effectivePlayerSpeed = playerCard.speed + Math.round(playerMomentum * 0.15);
  const effectiveEnemySpeed = enemyCard.speed + Math.round(enemyMomentum * 0.15);

  return effectivePlayerSpeed >= effectiveEnemySpeed ? 'PLAYER' : 'ENEMY';
}

// =========================================================================
// STRATEGIC ENEMY INTENT GENERATOR
// =========================================================================
export function generateEnemyIntentInfo(
  enemyCard: BattleCardEntity,
  playerCard: BattleCardEntity | null,
  difficulty: BattleDifficulty = 'NORMAL',
  turnNumber: number = 1,
  existingState?: BattleSessionState
): { secretAction: CombatIntent; intentInfo: EnemyIntentInfo } {
  // Synthesize or use real battle state for intelligent AI decision scoring
  const synthState: BattleSessionState = existingState || ({
    battleId: 'synth_duel',
    battleName: 'Duel',
    phase: 'DUEL',
    roundPhase: 'CHOOSE',
    currentTurnSide: 'PLAYER',
    initiative: 'PLAYER',
    turnNumber,
    roundNumber: turnNumber,
    playerActiveIndex: 0,
    enemyActiveIndex: 0,
    playerCards: playerCard ? [playerCard] : [],
    enemyCards: [enemyCard],
    isActionRevealed: false,
    turnPlanningLocked: false,
    logs: []
  } as unknown as BattleSessionState);

  const aiReport = evaluateAiActionScores(synthState);
  const validatedAiAction = validateAIAction(aiReport.action || aiReport.chosenAction) || 'strike';
  let chosenType: CombatIntentType = validatedAiAction === 'heavy'
    ? 'HEAVY'
    : validatedAiAction === 'defense'
      ? 'DEFENSE'
      : validatedAiAction === 'skill'
        ? 'SKILL'
        : 'STRIKE';

  let intentType: EnemyIntentType = 'CALM';
  if (chosenType === 'HEAVY') {
    intentType = 'AGGRESSIVE';
  } else if (chosenType === 'DEFENSE') {
    intentType = 'DEFENSIVE';
  } else if (chosenType === 'SKILL') {
    intentType = 'CHARGING';
  } else {
    // STRIKE
    intentType = (enemyCard.currentHp / (enemyCard.maxHp || 100)) < 0.35 ? 'COUNTERING' : 'CALM';
  }

  // Derive normalized probabilities directly from tactical scores
  const strikeScore = Math.max(5, aiReport.scores?.strike?.totalScore || 20);
  const heavyScore = Math.max(5, aiReport.scores?.heavy?.totalScore || 15);
  const defendScore = Math.max(5, aiReport.scores?.defense?.totalScore || 15);
  const skillScore = Math.max(5, aiReport.scores?.skill?.totalScore || 10);
  const totalScoreSum = strikeScore + heavyScore + defendScore + skillScore;

  const probabilities = {
    strike: Math.round((strikeScore / totalScoreSum) * 100),
    heavy: Math.round((heavyScore / totalScoreSum) * 100),
    defend: Math.round((defendScore / totalScoreSum) * 100),
    skill: Math.round((skillScore / totalScoreSum) * 100)
  };

  let displayedType: EnemyIntentType = intentType;
  let isFake = false;
  if (difficulty === 'HARD' || difficulty === 'BOSS') {
    const fakeRoll = Math.random();
    if (fakeRoll < (difficulty === 'BOSS' ? 0.30 : 0.15)) {
      isFake = true;
      if (chosenType === 'HEAVY') displayedType = 'DEFENSIVE';
      else if (chosenType === 'DEFENSE') displayedType = 'AGGRESSIVE';
    }
  }

  const intentLabels: Record<EnemyIntentType, { en: string; ar: string; hint: string; hintAr: string; icon: string }> = {
    CALM: {
      en: 'CALM',
      ar: 'هادئ',
      hint: 'Balanced posture. Strike or moderate action expected.',
      hintAr: 'وضعية متوازنة. يتوقع هجوم سريع أو حركة معتدلة.',
      icon: 'Eye'
    },
    AGGRESSIVE: {
      en: 'AGGRESSIVE',
      ar: 'هجومي',
      hint: 'Aggressive posture! Heavy or Strike attack likely.',
      hintAr: 'وضعية هجومية! من المتوقع هجوم ثقيل أو سريع.',
      icon: 'Swords'
    },
    DEFENSIVE: {
      en: 'DEFENSIVE',
      ar: 'دفاعي',
      hint: 'Guarding stance. Preparing to block and counter.',
      hintAr: 'وضعية دفاعية. يتأهب لصد الهجوم والرد.',
      icon: 'Shield'
    },
    CHARGING: {
      en: 'CHARGING',
      ar: 'شحن طاقة',
      hint: 'Channeling skill or gathering stamina.',
      hintAr: 'يشحن مهارته أو يجمع الجهد.',
      icon: 'Zap'
    },
    DESPERATE: {
      en: 'DESPERATE',
      ar: 'يائس',
      hint: 'Low HP! Volatile attack incoming.',
      hintAr: 'صحة منخفضة! قد يشن هجوماً غير متوقع.',
      icon: 'Flame'
    },
    COUNTERING: {
      en: 'COUNTERING',
      ar: 'متربص',
      hint: 'Anticipates fast strike. Ready to parry.',
      hintAr: 'مستعد للصد واستغلال نافذة الهجوم المضاد.',
      icon: 'ShieldAlert'
    }
  };

  const currentMeta = intentLabels[displayedType] || intentLabels.CALM;

  const intentInfo: EnemyIntentInfo = {
    type: intentType,
    displayedType,
    isFake,
    label: currentMeta.en,
    labelAr: currentMeta.ar,
    iconName: currentMeta.icon,
    description: currentMeta.hint,
    descriptionAr: currentMeta.hintAr,
    hint: currentMeta.hint,
    hintAr: currentMeta.hintAr,
    predictedActionProbabilities: probabilities
  };

  return {
    secretAction: { side: 'ENEMY', type: chosenType },
    intentInfo
  };
}

// =========================================================================
// COMPLETE 4-ACTION STRATEGIC COMBAT RESOLUTION ENGINE
// Exact circular counter philosophy:
// STRIKE -> beats -> HEAVY
// HEAVY -> beats -> DEFENSE
// DEFENSE -> beats -> STRIKE
// =========================================================================
export function resolveRoundIntents(
  playerIntent: CombatIntent,
  enemyIntent: CombatIntent,
  currentState: BattleSessionState,
  isAr: boolean
): { nextState: BattleSessionState; clashResolution: RoundClashResolution } {
  const pActiveIdx = currentState.playerActiveIndex;
  const eActiveIdx = currentState.enemyActiveIndex;

  const nextPlayerCards = currentState.playerCards.map(c => ({ 
    ...c, 
    activeBuffs: c.activeBuffs ? { ...c.activeBuffs } : undefined,
    skill: { ...c.skill } 
  }));
  const nextEnemyCards = currentState.enemyCards.map(c => ({ 
    ...c, 
    activeBuffs: c.activeBuffs ? { ...c.activeBuffs } : undefined,
    skill: { ...c.skill } 
  }));

  let playerCard = nextPlayerCards[pActiveIdx];
  let enemyCard = nextEnemyCards[eActiveIdx];

  // 10. ADD A FINAL SAFETY CHECK IMMEDIATELY BEFORE RESOLVING COMBAT
  const rawPlayerAction = String(playerIntent?.type || '').toLowerCase();
  const rawEnemyAction = String(enemyIntent?.type || '').toLowerCase();
  const validPlayerAction = validateAIAction(rawPlayerAction);
  const validEnemyAction = validateAIAction(rawEnemyAction);

  if (!validPlayerAction || !VALID_ACTIONS.includes(validPlayerAction)) {
    console.error(`[Combat Engine] Fatal error: Invalid player action "${playerIntent?.type}". Must be one of: ${VALID_ACTIONS.join(', ')}`);
    throw new Error(`Invalid player action: "${playerIntent?.type}". Must be one of: strike, heavy, defense, skill.`);
  }

  if (!validEnemyAction || !VALID_ACTIONS.includes(validEnemyAction)) {
    console.error(`[Combat Engine] Fatal error: Invalid AI action "${enemyIntent?.type}". Must be one of: ${VALID_ACTIONS.join(', ')}`);
    throw new Error(`Invalid AI action: "${enemyIntent?.type}". Must be one of: strike, heavy, defense, skill.`);
  }

  // Canonical action mapping from validated IDs
  type ResolvedAction = 'STRIKE' | 'HEAVY' | 'DEFENSE' | 'SKILL' | 'ULTIMATE';
  const toIntentType = (a: typeof VALID_ACTIONS[number], originalType?: CombatIntentType): ResolvedAction => {
    if (originalType === 'ULTIMATE') return 'ULTIMATE';
    if (a === 'heavy') return 'HEAVY';
    if (a === 'defense') return 'DEFENSE';
    if (a === 'skill') return 'SKILL';
    return 'STRIKE';
  };

  const pAction = toIntentType(validPlayerAction, playerIntent.type);
  const eAction = toIntentType(validEnemyAction, enemyIntent.type);

  // Check Exhaustion states (Stamina <= 0)
  const isPlayerExhausted = playerCard.currentStamina <= 0;
  const isEnemyExhausted = enemyCard.currentStamina <= 0;

  // Track outcomes
  const playerOutcome: BattleActionOutcome = {
    action: pAction,
    actorSide: 'PLAYER',
    actorName: playerCard.card.name,
    targetName: enemyCard.card.name,
    damage: 0,
    isCrit: false,
    isGuardBreak: false,
    isBlocked: false,
    isParried: false,
    isDefeat: false,
    momentumGained: 0,
    description: '',
    descriptionAr: ''
  };

  const enemyOutcome: BattleActionOutcome = {
    action: eAction,
    actorSide: 'ENEMY',
    actorName: enemyCard.card.name,
    targetName: playerCard.card.name,
    damage: 0,
    isCrit: false,
    isGuardBreak: false,
    isBlocked: false,
    isParried: false,
    isDefeat: false,
    momentumGained: 0,
    description: '',
    descriptionAr: ''
  };

  let clashType: ClashCategory = 'CLASH';
  let bannerTitle = 'CLASH';
  let bannerTitleAr = 'اشتباك';
  let summary = '';
  let summaryAr = '';
  let clashData: ClashResultData | null = null;

  // Active buff modifiers from previous turn
  const pHeavyMult = playerCard.activeBuffs?.heavyDamageMultiplier || 1.0;
  const eHeavyMult = enemyCard.activeBuffs?.heavyDamageMultiplier || 1.0;

  const pDamageReduction = playerCard.activeBuffs?.damageReduction || 0;
  const eDamageReduction = enemyCard.activeBuffs?.damageReduction || 0;

  const pDodge = !!playerCard.activeBuffs?.dodgeNext;
  const eDodge = !!enemyCard.activeBuffs?.dodgeNext;

  // Clear one-time buffs used this round
  if (playerCard.activeBuffs) {
    if (pAction === 'HEAVY') playerCard.activeBuffs.heavyDamageMultiplier = 1.0;
    playerCard.activeBuffs.dodgeNext = false;
  }
  if (enemyCard.activeBuffs) {
    if (eAction === 'HEAVY') enemyCard.activeBuffs.heavyDamageMultiplier = 1.0;
    enemyCard.activeBuffs.dodgeNext = false;
  }

  // Counter window bonus from previous turn (+25% damage)
  const pCounterBonus = playerCard.counterWindow ? 1.25 : 1.0;
  const eCounterBonus = enemyCard.counterWindow ? 1.25 : 1.0;
  playerCard.counterWindow = false;
  enemyCard.counterWindow = false;

  // Clear previous staggers
  playerCard.isStaggered = false;
  enemyCard.isStaggered = false;

  // =========================================================================
  // CORE MATCHUP RESOLUTION
  // =========================================================================

  // 0. ULTIMATE OVERDRIVE (LEGENDARY & HALLOWEEN OVERDRIVE BURST)
  if (pAction === 'ULTIMATE') {
    const isPlayerHalloween = 
      (playerCard.rarity as string)?.toUpperCase() === 'HALLOWEEN_2026' ||
      (playerCard.card?.rarity as string)?.toUpperCase() === 'HALLOWEEN_2026' ||
      playerCard.card?.frameStyle === 'halloween_spectral' ||
      playerCard.card?.foilStyle === 'halloween_specter' ||
      Boolean(playerCard.card?.name && /halloween/i.test(playerCard.card.name));

    clashType = 'SKILL_UNBLOCKABLE';
    bannerTitle = isPlayerHalloween ? '🎃 HALLOWEEN SPECTRAL BURST' : 'ULTIMATE OVERDRIVE';
    bannerTitleAr = isPlayerHalloween ? '🎃 حركة الهالوين: ضربة طيفية خارقة' : 'حركة الجسد: القدرة القصوى!';
    const ultDmg = isPlayerHalloween
      ? Math.max(50, Math.round((playerCard.attack || 40) * 1.35))
      : Math.max(45, Math.round((playerCard.attack || 35) * 1.25));

    playerCard.currentStamina = Math.max(0, playerCard.currentStamina - 40);
    playerCard.currentEnergy = playerCard.currentStamina;

    enemyCard.currentHp = Math.max(0, enemyCard.currentHp - ultDmg);
    playerOutcome.damage = ultDmg;
    playerOutcome.isCrit = true;

    // Enemy might counter-attack with minor chip
    let eDmgTaken = 0;
    if (eAction === 'STRIKE') {
      eDmgTaken = 8;
      enemyCard.currentStamina = Math.max(0, enemyCard.currentStamina - 15);
    } else if (eAction === 'HEAVY') {
      eDmgTaken = 14;
      enemyCard.currentStamina = Math.max(0, enemyCard.currentStamina - 30);
    } else if (eAction === 'DEFENSE') {
      // Defender recovers full +25 defense stamina since opponent did not choose Heavy
      enemyCard.currentStamina = Math.min(enemyCard.maxStamina || 100, (enemyCard.currentStamina ?? 100) + 25);
    }
    playerCard.currentHp = Math.max(0, playerCard.currentHp - eDmgTaken);
    enemyOutcome.damage = eDmgTaken;

    summary = isPlayerHalloween
      ? `🎃 HALLOWEEN SPECTRAL ULTIMATE! Mythic Halloween card unleashed cursed witchfire dealing ${ultDmg} unblockable damage!`
      : `ULTIMATE OVERDRIVE! Legendary card unleashed supreme power dealing ${ultDmg} unblockable damage!`;
    summaryAr = isPlayerHalloween
      ? `🎃 ضربة الهالوين الطيفية القصوى! أطلقت بطاقة الهالوين لهيب الأرواح مسددة ${ultDmg} ضرر لا يمكن صده!`
      : `حركة الجسد القصوى الخارقة! أطلقت البطاقة الأسطورية قوتها السديمية العظمى مسددة ${ultDmg} ضرر لا يمكن صده!`;

    clashData = {
      isClash: true,
      playerClashPower: 50,
      enemyClashPower: 15,
      winner: 'PLAYER',
      bonusDamage: 15,
      clashTitle: bannerTitle,
      clashTitleAr: bannerTitleAr
    };
  }

  // 1. STRIKE vs STRIKE -> SPEED-DEPENDENT CLASH
  else if (pAction === 'STRIKE' && eAction === 'STRIKE') {
    const pSpeed = playerCard.speed || 60;
    const eSpeed = enemyCard.speed || 60;

    const playerAtk = playerCard.attack || 30;
    const enemyAtk = enemyCard.attack || 30;
    const basePlayerDmg = Math.max(15, Math.round((playerAtk * 0.45) * (isPlayerExhausted ? 0.8 : 1.0) * pCounterBonus));
    const baseEnemyDmg = Math.max(15, Math.round((enemyAtk * 0.45) * (isEnemyExhausted ? 0.8 : 1.0) * eCounterBonus));

    let pDmg = basePlayerDmg;
    let eDmg = baseEnemyDmg;
    let clashWinner: 'PLAYER' | 'ENEMY' | 'TIE' = 'TIE';

    if (pSpeed > eSpeed) {
      // Player card has higher speed: deals 100% damage, enemy damage debuffed by 30%
      pDmg = basePlayerDmg;
      eDmg = Math.max(1, Math.round(baseEnemyDmg * 0.70));
      clashWinner = 'PLAYER';
      clashType = 'SPEED_STRIKE';
      bannerTitle = 'SPEED ADVANTAGE';
      bannerTitleAr = 'أفضلية سرعة!';
      summary = `SPEED ADVANTAGE! Your higher Speed (${pSpeed} vs ${eSpeed}) dealt 100% Strike damage (${pDmg}), and debuffed enemy's incoming Strike damage by 30% (took ${eDmg} damage).`;
      summaryAr = `أفضلية سرعة! سرعتك الأعلى (${pSpeed} مقابل ${eSpeed}) سددت 100% من ضرر الهجوم (${pDmg})، وخفضت ضرر ضربة العدو بنسبة 30% (تلقيت ${eDmg} فقط)!`;
    } else if (eSpeed > pSpeed) {
      // Enemy card has higher speed: deals 100% damage, player damage debuffed by 30%
      eDmg = baseEnemyDmg;
      pDmg = Math.max(1, Math.round(basePlayerDmg * 0.70));
      clashWinner = 'ENEMY';
      clashType = 'SPEED_STRIKE';
      bannerTitle = 'ENEMY SPEED ADVANTAGE';
      bannerTitleAr = 'أفضلية سرعة للخصم!';
      summary = `SPEED DISADVANTAGE! Enemy higher Speed (${eSpeed} vs ${pSpeed}) dealt 100% Strike damage (${eDmg}), debuffing your Strike damage by 30% (dealt ${pDmg} damage).`;
      summaryAr = `أفضلية سرعة للخصم! سرعة الخصم الأعلى (${eSpeed} مقابل ${pSpeed}) سددت 100% ضرر (${eDmg})، وخفضت ضربتك بنسبة 30% (سددت ${pDmg} ضرر).`;
    } else {
      // Equal speed: standard clash
      clashWinner = 'TIE';
      clashType = 'CLASH';
      bannerTitle = 'CLASH';
      bannerTitleAr = 'اشتباك متكافئ';
      summary = `CLASH! Both fighters struck simultaneously with equal speed. Dealt ${pDmg} damage to enemy and took ${eDmg} damage.`;
      summaryAr = `اشتباك! نفذ كلا المقاتلين هجوماً بنفس السرعة. سددت ${pDmg} ضرر للعدو وتلقيت ${eDmg} ضرر.`;
    }

    // Apply stamina: STRIKE costs 15 STM
    playerCard.currentStamina = Math.max(0, playerCard.currentStamina - 15);
    enemyCard.currentStamina = Math.max(0, enemyCard.currentStamina - 15);
    playerCard.currentEnergy = playerCard.currentStamina;
    enemyCard.currentEnergy = enemyCard.currentStamina;

    enemyCard.currentHp = Math.max(0, enemyCard.currentHp - pDmg);
    playerCard.currentHp = Math.max(0, playerCard.currentHp - eDmg);

    playerOutcome.damage = pDmg;
    enemyOutcome.damage = eDmg;

    clashData = {
      isClash: true,
      playerClashPower: pSpeed,
      enemyClashPower: eSpeed,
      winner: clashWinner,
      bonusDamage: 0,
      clashTitle: bannerTitle,
      clashTitleAr: bannerTitleAr
    };
  }

  // 2. STRIKE vs HEAVY -> STRIKE WINS (INTERRUPTED)
  else if (pAction === 'STRIKE' && eAction === 'HEAVY') {
    clashType = 'INTERRUPTED';
    bannerTitle = 'INTERRUPTED';
    bannerTitleAr = 'تم قطع هجوم العدو!';

    const pDmg = Math.round((isPlayerExhausted ? 12 : 15) * pCounterBonus);

    // Strike user spends 15 stamina
    playerCard.currentStamina = Math.max(0, playerCard.currentStamina - 15);
    playerCard.currentEnergy = playerCard.currentStamina;

    // Heavy user loses 30 stamina for attempting attack
    enemyCard.currentStamina = Math.max(0, enemyCard.currentStamina - 30);
    enemyCard.currentEnergy = enemyCard.currentStamina;
    enemyCard.isStaggered = true;

    enemyCard.currentHp = Math.max(0, enemyCard.currentHp - pDmg);
    // Heavy deals 0 damage because it was interrupted before impact!
    playerOutcome.damage = pDmg;
    enemyOutcome.damage = 0;

    summary = `INTERRUPTED! Your fast Strike interrupted the enemy's slow Heavy attack before impact! Dealt ${pDmg} damage; enemy lost 30 Stamina.`;
    summaryAr = `تم قطع الهجوم! هجومك السريع قاطع الهجوم الثقيل للخصم قبل إتمامه! مسدداً ${pDmg} ضرر، وفقد العدو 30 نقطة جهد.`;

    clashData = {
      isClash: true,
      playerClashPower: 25,
      enemyClashPower: 0,
      winner: 'PLAYER',
      bonusDamage: 0,
      clashTitle: 'INTERRUPTED',
      clashTitleAr: 'قطع الهجوم'
    };
  }

  // 3. HEAVY vs STRIKE -> STRIKE WINS (INTERRUPTED)
  else if (pAction === 'HEAVY' && eAction === 'STRIKE') {
    clashType = 'INTERRUPTED';
    bannerTitle = 'INTERRUPTED';
    bannerTitleAr = 'تم قطع هجومك الثقيل!';

    const eDmg = Math.round((isEnemyExhausted ? 12 : 15) * eCounterBonus);

    // Enemy Strike spends 15 stamina
    enemyCard.currentStamina = Math.max(0, enemyCard.currentStamina - 15);
    enemyCard.currentEnergy = enemyCard.currentStamina;

    // Player Heavy loses 30 stamina
    playerCard.currentStamina = Math.max(0, playerCard.currentStamina - 30);
    playerCard.currentEnergy = playerCard.currentStamina;
    playerCard.isStaggered = true;

    playerCard.currentHp = Math.max(0, playerCard.currentHp - eDmg);
    playerOutcome.damage = 0;
    enemyOutcome.damage = eDmg;

    summary = `INTERRUPTED! Enemy Strike interrupted your Heavy attack before it landed! You took ${eDmg} damage and lost 30 Stamina.`;
    summaryAr = `تم قطع الهجوم! هجوم العدو السريع قاطع ضربتك الثقيلة قبل أن تكتمل! تلقيت ${eDmg} ضرر وخسرت 30 نقطة جهد.`;

    clashData = {
      isClash: true,
      playerClashPower: 0,
      enemyClashPower: 25,
      winner: 'ENEMY',
      bonusDamage: 0,
      clashTitle: 'INTERRUPTED',
      clashTitleAr: 'قطع الهجوم'
    };
  }

  // 4. STRIKE vs DEFENSE -> DEFENSE WINS (BLOCKED + COUNTER WINDOW)
  else if (pAction === 'STRIKE' && eAction === 'DEFENSE') {
    clashType = 'BLOCKED';
    bannerTitle = 'BLOCKED';
    bannerTitleAr = 'تم صد الهجوم';

    // 90% reduction: 15 * 0.10 = 1.5 -> 1 or 2 damage
    const mitigatedDmg = Math.max(1, Math.round(15 * 0.10));

    // Strike user spends 15 stamina
    playerCard.currentStamina = Math.max(0, playerCard.currentStamina - 15);
    playerCard.currentEnergy = playerCard.currentStamina;

    // Defender restores +25 stamina on successful block and opens COUNTER WINDOW
    enemyCard.currentStamina = Math.min(100, enemyCard.currentStamina + 25);
    enemyCard.currentEnergy = enemyCard.currentStamina;
    enemyCard.counterWindow = true;

    enemyCard.currentHp = Math.max(0, enemyCard.currentHp - mitigatedDmg);
    playerOutcome.damage = mitigatedDmg;
    playerOutcome.isBlocked = true;

    summary = `BLOCKED! Enemy Defense absorbed your Strike (only ${mitigatedDmg} damage dealt). Enemy restored +25 Stamina and opened a COUNTER WINDOW!`;
    summaryAr = `تم الصد! دفاع العدو امتص هجومك السريع (فقط ${mitigatedDmg} ضرر متلقى). استعاد العدو +25 نقطة جهد وفتح نافذة هجوم مضاد!`;

    clashData = {
      isClash: true,
      playerClashPower: 5,
      enemyClashPower: 20,
      winner: 'ENEMY',
      bonusDamage: 0,
      clashTitle: 'BLOCKED',
      clashTitleAr: 'تم الصد'
    };
  }

  // 5. DEFENSE vs STRIKE -> DEFENSE WINS (BLOCKED + COUNTER WINDOW)
  else if (pAction === 'DEFENSE' && eAction === 'STRIKE') {
    clashType = 'BLOCKED';
    bannerTitle = 'BLOCKED';
    bannerTitleAr = 'صد دفاعي محكم!';

    const mitigatedDmg = Math.max(1, Math.round(15 * 0.10));

    // Player blocks: restores +25 stamina, opens COUNTER WINDOW!
    playerCard.currentStamina = Math.min(100, playerCard.currentStamina + 25);
    playerCard.currentEnergy = playerCard.currentStamina;
    playerCard.counterWindow = true;

    // Enemy strike spends 15 stamina
    enemyCard.currentStamina = Math.max(0, enemyCard.currentStamina - 15);
    enemyCard.currentEnergy = enemyCard.currentStamina;

    playerCard.currentHp = Math.max(0, playerCard.currentHp - mitigatedDmg);
    enemyOutcome.damage = mitigatedDmg;
    enemyOutcome.isBlocked = true;

    summary = `BLOCKED! You raised your guard against the enemy Strike (took only ${mitigatedDmg} damage), recovered +25 Stamina, and gained a COUNTER WINDOW!`;
    summaryAr = `تم الصد! رفعت درعك أمام هجوم العدو السريع (تلقيت ${mitigatedDmg} ضرر فقط)، واستعدت +25 نقطة جهد وحصلت على نافذة هجوم مضاد!`;

    clashData = {
      isClash: true,
      playerClashPower: 20,
      enemyClashPower: 5,
      winner: 'PLAYER',
      bonusDamage: 0,
      clashTitle: 'COUNTER WINDOW',
      clashTitleAr: 'نافذة هجوم مضاد'
    };
  }

  // 6. HEAVY vs HEAVY -> HEAVY CLASH
  else if (pAction === 'HEAVY' && eAction === 'HEAVY') {
    clashType = 'HEAVY_CLASH';
    bannerTitle = 'HEAVY CLASH';
    bannerTitleAr = 'صراع الضربات الثقيلة!';

    const baseHeavy = 30;
    const pDmg = Math.round(baseHeavy * pHeavyMult * pCounterBonus);
    const eDmg = Math.round(baseHeavy * eHeavyMult * eCounterBonus);

    // Heavy Clash: both spend 30 stamina
    playerCard.currentStamina = Math.max(0, playerCard.currentStamina - 30);
    enemyCard.currentStamina = Math.max(0, enemyCard.currentStamina - 30);
    playerCard.currentEnergy = playerCard.currentStamina;
    enemyCard.currentEnergy = enemyCard.currentStamina;

    enemyCard.currentHp = Math.max(0, enemyCard.currentHp - pDmg);
    playerCard.currentHp = Math.max(0, playerCard.currentHp - eDmg);

    playerOutcome.damage = pDmg;
    enemyOutcome.damage = eDmg;
    playerOutcome.isCrit = true;
    enemyOutcome.isCrit = true;

    summary = `HEAVY CLASH! Both fighters unleashed devastating Heavy attacks! Massive impact dealing ${pDmg} to enemy and ${eDmg} to you.`;
    summaryAr = `صراع الضربات الثقيلة! أطلق كلا المقاتلين ضربة ثقيلة عنيفة! اصطدام هائل ألحق ${pDmg} ضرر بالعدو و ${eDmg} ضرر بك.`;

    clashData = {
      isClash: true,
      playerClashPower: 30,
      enemyClashPower: 30,
      winner: 'TIE',
      bonusDamage: 0,
      clashTitle: 'HEAVY CLASH',
      clashTitleAr: 'صراع الضربات الثقيلة'
    };
  }

  // 7. HEAVY vs DEFENSE -> HEAVY WINS (GUARD BREAK)
  else if (pAction === 'HEAVY' && eAction === 'DEFENSE') {
    clashType = 'GUARD_BREAK';
    bannerTitle = 'GUARD BREAK';
    bannerTitleAr = 'كسر الدفاع!';

    // Heavy breaks defense! 35% reduction of 30 -> 19-20 damage
    const rawDmg = Math.round(30 * pHeavyMult * pCounterBonus);
    const finalDmg = Math.round(rawDmg * (1 - 0.35)); // 20 damage

    // Attacker spends 30 stamina
    playerCard.currentStamina = Math.max(0, playerCard.currentStamina - 30);
    playerCard.currentEnergy = playerCard.currentStamina;

    // Defender recovers 70% of original defense stamina (18 stamina) instead of losing stamina
    const originalDefenseStamina = 25;
    const defStaminaGain = Math.round(originalDefenseStamina * 0.70); // 70% = 18 stamina
    enemyCard.currentStamina = Math.min(enemyCard.maxStamina || 100, (enemyCard.currentStamina ?? 100) + defStaminaGain);
    enemyCard.currentEnergy = enemyCard.currentStamina;
    enemyCard.isStaggered = true; // Staggered defender cannot counter!

    enemyCard.currentHp = Math.max(0, enemyCard.currentHp - finalDmg);
    playerOutcome.damage = finalDmg;
    playerOutcome.isGuardBreak = true;

    summary = `GUARD BREAK! Your Heavy blow broke through enemy Defense for ${finalDmg} damage! Defense stance absorbed force and recovered +${defStaminaGain} Stamina (70% of normal).`;
    summaryAr = `كسر الدفاع! ضربتك الثقيلة سحقت درع العدو مسددة ${finalDmg} ضرر! استعادت وضعية دفاع العدو +${defStaminaGain} جهد (70% من الجهد المعتاد).`;

    clashData = {
      isClash: true,
      playerClashPower: 35,
      enemyClashPower: 10,
      winner: 'PLAYER',
      bonusDamage: 0,
      clashTitle: 'GUARD BREAK',
      clashTitleAr: 'كسر الدفاع'
    };
  }

  // 8. DEFENSE vs HEAVY -> HEAVY WINS (GUARD BREAK, BUT DEFENSE GETS 70% STAMINA)
  else if (pAction === 'DEFENSE' && eAction === 'HEAVY') {
    clashType = 'GUARD_BREAK';
    bannerTitle = 'GUARD BREAK';
    bannerTitleAr = 'تهشم درعك!';

    const rawDmg = Math.round(30 * eHeavyMult * eCounterBonus);
    const finalDmg = Math.round(rawDmg * (1 - 0.35)); // 20 damage

    // Defender recovers 70% of original defense stamina (18 stamina) when facing Heavy
    const originalDefenseStamina = 25;
    const defStaminaGain = Math.round(originalDefenseStamina * 0.70); // 70% = 18 stamina
    playerCard.currentStamina = Math.min(playerCard.maxStamina || 100, (playerCard.currentStamina ?? 100) + defStaminaGain);
    playerCard.currentEnergy = playerCard.currentStamina;
    playerCard.isStaggered = true; // Player staggered!

    // Attacker spends 30 stamina
    enemyCard.currentStamina = Math.max(0, enemyCard.currentStamina - 30);
    enemyCard.currentEnergy = enemyCard.currentStamina;

    playerCard.currentHp = Math.max(0, playerCard.currentHp - finalDmg);
    enemyOutcome.damage = finalDmg;
    enemyOutcome.isGuardBreak = true;

    summary = `GUARD BREAK! Enemy Heavy attack broke through your Defense for ${finalDmg} damage! But your Defense stance restored +${defStaminaGain} Stamina (70% of normal Defense).`;
    summaryAr = `كسر الدفاع! اخترقت الضربة الثقيلة للعدو درعك مسددة ${finalDmg} ضرر! لكن وضعية دفاعك منحتك +${defStaminaGain} جهد (70% من جهد الدفاع المعتاد).`;

    clashData = {
      isClash: true,
      playerClashPower: 10,
      enemyClashPower: 35,
      winner: 'ENEMY',
      bonusDamage: 0,
      clashTitle: 'GUARD BREAK',
      clashTitleAr: 'كسر الدفاع'
    };
  }

  // 9. DEFENSE vs DEFENSE -> STANDOFF (STAMINA RECOVERY)
  else if (pAction === 'DEFENSE' && eAction === 'DEFENSE') {
    clashType = 'STANDOFF';
    bannerTitle = 'STANDOFF';
    bannerTitleAr = 'هدنة تكتيكية';

    // Standoff: No damage. Both recover full original defense stamina (+25)!
    const originalDefenseStamina = 25;
    playerCard.currentStamina = Math.min(playerCard.maxStamina || 100, (playerCard.currentStamina ?? 100) + originalDefenseStamina);
    enemyCard.currentStamina = Math.min(enemyCard.maxStamina || 100, (enemyCard.currentStamina ?? 100) + originalDefenseStamina);
    playerCard.currentEnergy = playerCard.currentStamina;
    enemyCard.currentEnergy = enemyCard.currentStamina;

    summary = 'STANDOFF! Both fighters raised defensive guards. No damage dealt; both recovered +25 Stamina.';
    summaryAr = 'هدنة تكتيكية! تأهب كلا المقاتلين للدفاع. لم يتلق أي طرف ضرراً؛ واستعاد كلاهما +25 نقطة جهد.';

    clashData = {
      isClash: true,
      playerClashPower: 0,
      enemyClashPower: 0,
      winner: 'TIE',
      bonusDamage: 0,
      clashTitle: 'STANDOFF',
      clashTitleAr: 'هدنة تكتيكية'
    };
  }

  // 10. SKILL SYSTEM MATCHUPS
  else {
    // Player used SKILL
    if (pAction === 'SKILL') {
      const skill = playerCard.skill;
      const staminaUsage = skill.staminaCost || 30;
      playerCard.currentStamina = Math.max(0, playerCard.currentStamina - staminaUsage);
      playerCard.currentEnergy = playerCard.currentStamina;
      playerCard.skill.currentCooldown = skill.cooldown;

      if (skill.type === 'BUFF') {
        playerCard.activeBuffs = {
          heavyDamageMultiplier: skill.effects?.heavyDamageMultiplier || 1.5,
          turnsRemaining: 1
        };
        clashType = 'TACTICAL_MANEUVER';
        bannerTitle = 'RAGE ACTIVATED';
        bannerTitleAr = 'تفعيل الغضب الهائج';
        summary = 'Rage activated! Your next Heavy attack will deal +50% damage!';
        summaryAr = 'تم تفعيل الغضب الهائج! ضربتك الثقيلة القادمة ستسدد +50% ضرر!';
      } else if (skill.type === 'DODGE') {
        playerCard.activeBuffs = {
          dodgeNext: true,
          turnsRemaining: 1
        };
        clashType = 'SKILL_DODGED';
        bannerTitle = 'QUICKSTEP';
        bannerTitleAr = 'خطوة خاطفة';
        summary = 'Quickstep activated! You prepared to dodge the next incoming attack.';
        summaryAr = 'تم تفعيل الخطوة الخاطفة! استعددت لتفادي الهجوم القادم بنجاح.';
      } else if (skill.type === 'DEFENSIVE') {
        playerCard.activeBuffs = {
          damageReduction: skill.effects?.incomingDamageReduction || 0.70,
          turnsRemaining: 1
        };
        clashType = 'SKILL_ABSORBED';
        bannerTitle = 'FORTIFIED';
        bannerTitleAr = 'تحصين درعي';
        summary = 'Fortify activated! Incoming damage reduced by 70% for one turn.';
        summaryAr = 'تم تفعيل التحصين! تقليص الضرر المتلقى بنسبة 70% لجولة كاملة.';
      } else if (skill.type === 'OFFENSIVE') {
        // If enemy used STRIKE and skill is interruptible, Strike interrupts it!
        if (eAction === 'STRIKE' && skill.interruptible) {
          clashType = 'INTERRUPTED';
          bannerTitle = 'INTERRUPTED';
          bannerTitleAr = 'تم قطع المهارة!';
          const eDmg = 15;
          playerCard.currentHp = Math.max(0, playerCard.currentHp - eDmg);
          enemyOutcome.damage = eDmg;
          playerOutcome.damage = 0;
          summary = 'INTERRUPTED! Enemy Strike was fast enough to disrupt your Arcane Blast during its startup!';
          summaryAr = 'تم قطع المهارة! هجوم العدو السريع باغت انفجارك السحري أثناء الشحن وقطعه!';
        } else {
          clashType = 'SKILL_UNBLOCKABLE';
          bannerTitle = 'ARCANE BLAST';
          bannerTitleAr = 'انفجار سحري';
          const dmg = skill.damage || 25;
          enemyCard.currentHp = Math.max(0, enemyCard.currentHp - dmg);
          playerOutcome.damage = dmg;
          summary = `Arcane Blast blasted through defenses for ${dmg} unblockable celestial damage!`;
          summaryAr = `اخترق الانفجار السحري كافة الدفاعات مسدداً ${dmg} ضرر سحري لا يمكن صده!`;
        }
      } else if (skill.type === 'LIFESTEAL') {
        if (eAction === 'STRIKE' && skill.interruptible) {
          clashType = 'INTERRUPTED';
          bannerTitle = 'INTERRUPTED';
          bannerTitleAr = 'تم قطع امتصاص الحياة!';
          const eDmg = 15;
          playerCard.currentHp = Math.max(0, playerCard.currentHp - eDmg);
          enemyOutcome.damage = eDmg;
          summary = 'Enemy Strike interrupted your Lifesteal attack during startup!';
          summaryAr = 'قاطع هجوم العدو السريع مهارة امتصاص الحياة أثناء انطلاقها!';
        } else {
          clashType = 'SPEED_STRIKE';
          bannerTitle = 'LIFESTEAL';
          bannerTitleAr = 'امتصاص الحياة';
          const dmg = skill.damage || 15;
          const heal = skill.effects?.healAmount || 8;
          enemyCard.currentHp = Math.max(0, enemyCard.currentHp - dmg);
          playerCard.currentHp = Math.min(playerCard.maxHp, playerCard.currentHp + heal);
          playerOutcome.damage = dmg;
          summary = `Lifesteal drained ${dmg} HP from the enemy and healed you for +${heal} HP!`;
          summaryAr = `امتصت الضربة ${dmg} صحة من الخصم وعالجت بطاقتك بمقدار +${heal} صحة!`;
        }
      }
    }

    // If enemy took an action while player used skill, apply enemy stamina
    if (eAction === 'STRIKE') {
      enemyCard.currentStamina = Math.max(0, enemyCard.currentStamina - 15);
    } else if (eAction === 'HEAVY') {
      enemyCard.currentStamina = Math.max(0, enemyCard.currentStamina - 30);
    } else if (eAction === 'DEFENSE') {
      enemyCard.currentStamina = Math.min(100, enemyCard.currentStamina + 25);
    }

    // Enemy used SKILL
    if (eAction === 'SKILL') {
      const eSkill = enemyCard.skill;
      const staminaUsage = eSkill.staminaCost || 35;
      enemyCard.currentStamina = Math.max(0, enemyCard.currentStamina - staminaUsage);
      enemyCard.currentEnergy = enemyCard.currentStamina;
      enemyCard.skill.currentCooldown = eSkill.cooldown;

      // If player took an action while enemy used skill, apply player stamina
      if (pAction === 'STRIKE') {
        playerCard.currentStamina = Math.max(0, playerCard.currentStamina - 15);
      } else if (pAction === 'HEAVY') {
        playerCard.currentStamina = Math.max(0, playerCard.currentStamina - 30);
      } else if (pAction === 'DEFENSE') {
        playerCard.currentStamina = Math.min(100, playerCard.currentStamina + 25);
      }

      if (eSkill.type === 'BUFF') {
        enemyCard.activeBuffs = {
          heavyDamageMultiplier: eSkill.effects?.heavyDamageMultiplier || 1.5,
          turnsRemaining: 1
        };
        clashType = 'TACTICAL_MANEUVER';
        bannerTitle = 'ENEMY RAGE';
        bannerTitleAr = 'غضب العدو';
        summary = 'Enemy channeled Rage! Next enemy Heavy will deal +50% damage.';
        summaryAr = 'شحن العدو غضباً هائجاً! ضربته الثقيلة القادمة ستسدد +50% ضرر.';
      } else if (eSkill.type === 'DEFENSIVE') {
        enemyCard.activeBuffs = {
          damageReduction: eSkill.effects?.incomingDamageReduction || 0.70,
          turnsRemaining: 1
        };
        clashType = 'SKILL_ABSORBED';
        bannerTitle = 'ENEMY FORTIFY';
        bannerTitleAr = 'تحصين درعي للعدو';
        summary = 'Enemy raised a Fortify shield, reducing incoming damage by 70%.';
        summaryAr = 'رفع العدو درع التحصين، مقلصاً الضرر المتلقى بنسبة 70%.';
      } else if (eSkill.type === 'OFFENSIVE') {
        if (pAction === 'STRIKE' && eSkill.interruptible) {
          clashType = 'INTERRUPTED';
          bannerTitle = 'INTERRUPTED';
          bannerTitleAr = 'قطعت مهارة العدو!';
          const pDmg = 15;
          enemyCard.currentHp = Math.max(0, enemyCard.currentHp - pDmg);
          playerOutcome.damage = pDmg;
          enemyOutcome.damage = 0;
          summary = 'Your Strike interrupted the enemy skill during startup!';
          summaryAr = 'هجومك السريع قاطع مهارة العدو أثناء شحنها!';
        } else {
          clashType = 'SKILL_UNBLOCKABLE';
          bannerTitle = 'ENEMY ARCANE BLAST';
          bannerTitleAr = 'انفجار العدو السحري';
          const dmg = eSkill.damage || 25;
          playerCard.currentHp = Math.max(0, playerCard.currentHp - dmg);
          enemyOutcome.damage = dmg;
          summary = `Enemy Arcane Blast dealt ${dmg} unblockable damage!`;
          summaryAr = `سدد انفجار العدو السحري ${dmg} ضرر لا يمكن تفاديه!`;
        }
      }
    }
  }

  // Check Card Defeat
  if (enemyCard.currentHp <= 0) {
    enemyCard.currentHp = 0;
    enemyCard.isDefeated = true;
    playerOutcome.isDefeat = true;
  }
  if (playerCard.currentHp <= 0) {
    playerCard.currentHp = 0;
    playerCard.isDefeated = true;
    enemyOutcome.isDefeat = true;
  }

  // Update Exhaustion flags
  playerCard.isExhausted = playerCard.currentStamina <= 0;
  enemyCard.isExhausted = enemyCard.currentStamina <= 0;

  // Decrease Skill Cooldowns
  if (playerCard.skill.currentCooldown > 0) {
    playerCard.skill.currentCooldown -= 1;
  }
  if (enemyCard.skill.currentCooldown > 0) {
    enemyCard.skill.currentCooldown -= 1;
  }

  // Passive stamina recovery: +7% stamina every turn a card is NOT CHOSEN
  nextPlayerCards.forEach((c, idx) => {
    if (idx !== pActiveIdx && !c.isDefeated && c.currentHp > 0) {
      const maxStam = c.maxStamina || 100;
      const unchosenGain = Math.round(maxStam * 0.07); // 7% of max stamina
      c.currentStamina = Math.min(maxStam, (c.currentStamina ?? 100) + unchosenGain);
      c.currentEnergy = c.currentStamina;
      c.isExhausted = c.currentStamina <= 0;
    }
  });

  nextEnemyCards.forEach((c, idx) => {
    if (idx !== eActiveIdx && !c.isDefeated && c.currentHp > 0) {
      const maxStam = c.maxStamina || 100;
      const unchosenGain = Math.round(maxStam * 0.07); // 7% of max stamina
      c.currentStamina = Math.min(maxStam, (c.currentStamina ?? 100) + unchosenGain);
      c.currentEnergy = c.currentStamina;
      c.isExhausted = c.currentStamina <= 0;
    }
  });

  // Check overall Victory / Defeat
  const pAlive = countAliveCards(nextPlayerCards);
  const eAlive = countAliveCards(nextEnemyCards);
  let nextPhase = currentState.phase;
  let winner: 'PLAYER' | 'ENEMY' | null = null;
  if (eAlive === 0 && pAlive > 0) {
    nextPhase = 'VICTORY';
    winner = 'PLAYER';
  } else if (pAlive === 0 && eAlive > 0) {
    nextPhase = 'DEFEAT';
    winner = 'ENEMY';
  }

  const clashResolution: RoundClashResolution = {
    roundNumber: currentState.roundNumber,
    playerIntent,
    enemyIntent,
    playerOutcome,
    enemyOutcome,
    firstActor: 'SIMULTANEOUS',
    clashType,
    bannerTitle,
    bannerTitleAr,
    summary,
    summaryAr
  };

  const nextState: BattleSessionState = {
    ...currentState,
    roundNumber: currentState.roundNumber + 1,
    turnNumber: currentState.turnNumber + 1,
    playerCards: nextPlayerCards,
    enemyCards: nextEnemyCards,
    playerActiveIndex: pActiveIdx,
    enemyActiveIndex: eActiveIdx,
    currentClashData: clashData,
    isActionRevealed: true,
    turnPlanningLocked: true,
    roundPhase: nextPhase === 'VICTORY' || nextPhase === 'DEFEAT' ? nextPhase : 'CHOOSE',
    phase: nextPhase,
    lastClashResolution: clashResolution,
    winner,
    logs: [
      {
        id: `log_${Date.now()}_${currentState.roundNumber}`,
        turnNumber: currentState.roundNumber,
        actorName: playerCard.card.name,
        actorSide: 'PLAYER' as const,
        action: pAction,
        damage: playerOutcome.damage,
        description: summary,
        descriptionAr: summaryAr,
        timestamp: new Date().toLocaleTimeString()
      },
      ...currentState.logs
    ].slice(0, 30)
  };

  return { nextState, clashResolution };
}

export function getStrategicAiIntent(
  state: BattleSessionState,
  difficulty: BattleDifficulty = 'NORMAL'
): CombatIntent {
  const enemyCard = state.enemyCards[state.enemyActiveIndex];
  const playerCard = state.playerCards[state.playerActiveIndex];

  if (!enemyCard || enemyCard.isDefeated || enemyCard.currentHp <= 0) {
    const nextIdx = getNextAliveCardIndex(state.enemyCards, 0);
    return { side: 'ENEMY', type: 'SWITCH', targetIndex: nextIdx !== -1 ? nextIdx : 0 };
  }

  // Check if intelligent AI switch recommends swapping cards
  const switchTarget = evaluateAiCardSwitch(state);
  if (switchTarget !== null && switchTarget !== state.enemyActiveIndex) {
    return { side: 'ENEMY', type: 'SWITCH', targetIndex: switchTarget };
  }

  const { secretAction } = generateEnemyIntentInfo(enemyCard, playerCard, difficulty, state.turnNumber, state);
  return secretAction;
}
