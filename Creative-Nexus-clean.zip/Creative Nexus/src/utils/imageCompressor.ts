/**
 * Utility to process and compress images for announcements.
 * Handles drag-and-drop files, file inputs, and image URLs.
 * Keeps document payloads lightweight and fast on mobile networks.
 */

export interface ProcessedImage {
  dataUrl: string;
  name: string;
  size: number;
}

/**
 * Compresses an image File using an HTMLCanvasElement.
 * @param file Input file from input[type=file] or drag-and-drop
 * @param maxDimension Maximum width or height (defaults to 1600px)
 * @param quality JPEG quality 0-1 (defaults to 0.85)
 */
export async function compressImageFile(
  file: File,
  maxDimension = 1280,
  quality = 0.80
): Promise<ProcessedImage> {
  return new Promise((resolve, reject) => {
    // If SVG or animated GIF, keep original if small (< 1.5MB)
    if ((file.type === 'image/gif' || file.type === 'image/svg+xml') && file.size < 1500000) {
      const reader = new FileReader();
      reader.onload = () => {
        resolve({
          dataUrl: reader.result as string,
          name: file.name,
          size: file.size
        });
      };
      reader.onerror = () => reject(new Error('Failed to read image file'));
      reader.readAsDataURL(file);
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        // Calculate scaling
        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve({
            dataUrl: e.target?.result as string,
            name: file.name,
            size: file.size
          });
          return;
        }

        // Fill background with subtle dark color matching theme for any PNG transparency
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(0, 0, width, height);

        // Draw and compress to JPEG for optimal size reduction
        ctx.drawImage(img, 0, 0, width, height);
        let compressedDataUrl = canvas.toDataURL('image/jpeg', quality);

        // If still large (>350KB), compress further to avoid Firestore document size limits
        if (compressedDataUrl.length > 450000) {
          compressedDataUrl = canvas.toDataURL('image/jpeg', 0.65);
        }

        // Approximate size of base64
        const approxSize = Math.round((compressedDataUrl.length * 3) / 4);

        resolve({
          dataUrl: compressedDataUrl,
          name: file.name,
          size: approxSize
        });
      };

      img.onerror = () => reject(new Error('Failed to decode image data'));
      img.src = e.target?.result as string;
    };

    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

/**
 * Validates a web image URL format.
 */
export function isValidImageUrl(url: string): boolean {
  if (!url || typeof url !== 'string') return false;
  const trimmed = url.trim();
  if (trimmed.startsWith('data:image/')) return true;
  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}
