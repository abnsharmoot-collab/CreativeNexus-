import { CardRarity } from '../types/cards';

export interface DeviceAudioSlot {
  dataUrl?: string;
  fileName?: string;
  fileSize?: number;
}

export interface RevealSfxConfig {
  volume: number; // 0.1 to 1.0
  deviceAudio?: {
    cut?: DeviceAudioSlot;      // Pack cut / tear sound from user's device
    pull?: DeviceAudioSlot;     // Card pull out sound from user's device
    reveal?: DeviceAudioSlot;   // Card rarity reveal sound from user's device
    legendary?: DeviceAudioSlot;// Legendary fanfare sound from user's device
  };
  enabled: boolean;
}

export const DEFAULT_SFX_CONFIG: RevealSfxConfig = {
  volume: 0.75,
  deviceAudio: {},
  enabled: true
};

// Singleton audio context for low latency
let sharedAudioCtx: AudioContext | null = null;
function getAudioContext(): AudioContext | null {
  try {
    if (!sharedAudioCtx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        sharedAudioCtx = new AudioCtx();
      }
    }
    if (sharedAudioCtx && sharedAudioCtx.state === 'suspended') {
      sharedAudioCtx.resume().catch(() => {});
    }
    return sharedAudioCtx;
  } catch {
    return null;
  }
}

// Safely play custom/device audio URL
export function playAudioUrl(url: string, volume: number = 0.75): Promise<boolean> {
  return new Promise((resolve) => {
    try {
      if (!url || !url.trim()) {
        resolve(false);
        return;
      }
      const audio = new Audio(url);
      audio.volume = Math.max(0.05, Math.min(1, volume));
      audio.onended = () => resolve(true);
      audio.onerror = () => resolve(false);
      audio.play().then(() => resolve(true)).catch(() => resolve(false));
    } catch {
      resolve(false);
    }
  });
}

/**
 * Plays sound effect for pack opening events.
 * If user uploaded a sound from their device for the slot, that device audio plays with top priority.
 * Otherwise, synthesizes a refined physical audio effect.
 */
export async function playRevealSound(
  event: 'cut' | 'pull' | 'reveal' | 'legendary' | 'hum' | 'crack' | 'rarity' | 'chime',
  rarity: CardRarity = 'COMMON',
  config: RevealSfxConfig = DEFAULT_SFX_CONFIG
) {
  if (!config.enabled) return;
  const vol = Math.max(0.1, Math.min(1.0, config.volume || 0.75));

  // Map legacy events to new animation actions
  const actionKey: 'cut' | 'pull' | 'reveal' | 'legendary' =
    event === 'cut' || event === 'crack'
      ? 'cut'
      : event === 'pull' || event === 'hum'
      ? 'pull'
      : event === 'legendary' || (event === 'chime' && rarity === 'LEGENDARY')
      ? 'legendary'
      : 'reveal';

  // 1. CHECK FOR DEVICE AUDIO FIRST
  const deviceSlot = config.deviceAudio?.[actionKey];
  if (deviceSlot?.dataUrl) {
    const played = await playAudioUrl(deviceSlot.dataUrl, vol);
    if (played) return;
  }

  // If legendary and no legendary slot, check reveal slot
  if (actionKey === 'legendary' && config.deviceAudio?.reveal?.dataUrl) {
    const played = await playAudioUrl(config.deviceAudio.reveal.dataUrl, vol);
    if (played) return;
  }

  // 2. SYNTHESIZED REFINED FALLBACK (Physical pack opening sounds)
  const ctx = getAudioContext();
  if (!ctx) return;
  const now = ctx.currentTime;

  if (actionKey === 'cut') {
    // Physical foil slice / tear sound: quick white-noise hiss + sharp acoustic snap
    const bufferSize = ctx.sampleRate * 0.18;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(1400, now);
    filter.frequency.linearRampToValueAtTime(3200, now + 0.15);

    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.35 * vol, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

    whiteNoise.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(ctx.destination);
    whiteNoise.start(now);

    // Subtle low thud of foil shearing
    const osc = ctx.createOscillator();
    const oscGain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(340, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.15);
    oscGain.gain.setValueAtTime(0.2 * vol, now);
    oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

    osc.connect(oscGain);
    oscGain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.16);
    return;
  }

  if (actionKey === 'pull') {
    // Smooth card slide out / aerodynamic whoosh
    const bufferSize = ctx.sampleRate * 0.35;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(450, now);
    filter.frequency.exponentialRampToValueAtTime(1200, now + 0.25);
    filter.Q.value = 3;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.02, now);
    gain.gain.linearRampToValueAtTime(0.25 * vol, now + 0.12);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    whiteNoise.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    whiteNoise.start(now);
    return;
  }

  if (actionKey === 'legendary') {
    // Radiant golden royal fanfare chord
    const freqs = [130.81, 196.00, 261.63, 329.63, 392.00, 523.25, 659.25]; // C3, G3, C4, E4, G4, C5, E5
    freqs.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.04);

      gain.gain.setValueAtTime(0.001, now + idx * 0.04);
      gain.gain.linearRampToValueAtTime((0.14 / Math.sqrt(freqs.length)) * vol, now + idx * 0.04 + 0.06);
      gain.gain.exponentialRampToValueAtTime(0.0005, now + 1.8);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.04);
      osc.stop(now + 1.9);
    });
    return;
  }

  // actionKey === 'reveal'
  const chords: Record<CardRarity, number[]> = {
    COMMON: [261.63, 329.63, 392.00], // C4, E4, G4
    UNCOMMON: [293.66, 369.99, 440.00, 587.33], // D4, F#4, A4, D5
    RARE: [349.23, 440.00, 523.25, 698.46], // F4, A4, C5, F5
    EPIC: [220.00, 329.63, 440.00, 554.37, 659.25], // A3, E4, A4, C#5, E5
    LEGENDARY: [130.81, 196.00, 261.63, 329.63, 392.00, 523.25],
    HALLOWEEN_2026: [110.00, 164.81, 220.00, 329.63, 440.00, 659.25]
  };
  const notes = chords[rarity] || chords.COMMON;
  notes.forEach((freq, idx) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now + idx * 0.04);

    gain.gain.setValueAtTime(0.001, now + idx * 0.04);
    gain.gain.linearRampToValueAtTime((0.12 / Math.sqrt(notes.length)) * vol, now + idx * 0.04 + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.0005, now + 1.2);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now + idx * 0.04);
    osc.stop(now + 1.3);
  });
}

/**
 * Fast digital audio tick for standalone 0 to 999 power counter
 */
export function playPowerCountTick(vol = 0.5, pitchRatio = 1.0) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    const baseFreq = 650 + pitchRatio * 750;
    osc.frequency.setValueAtTime(baseFreq, now);
    osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.5, now + 0.035);
    gain.gain.setValueAtTime(0.08 * vol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.035);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.04);
  } catch {}
}

/**
 * Fast subtle frequency tick when card color rolls through rarity hues
 */
export function playColorRollTick(vol = 0.35, freq = 500) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.exponentialRampToValueAtTime(freq * 1.25, now + 0.028);
    gain.gain.setValueAtTime(0.06 * vol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.028);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.03);
  } catch {}
}

/**
 * Crisp energetic resonance when card color stops firmly on target rarity color
 */
export function playColorLock(rarity: CardRarity = 'COMMON', vol = 0.6) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const baseFreq =
      rarity === 'LEGENDARY' ? 659.25 :
      rarity === 'EPIC' ? 554.37 :
      rarity === 'RARE' ? 440.00 :
      rarity === 'UNCOMMON' ? 369.99 : 329.63;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(baseFreq, now);
    osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.5, now + 0.22);
    gain.gain.setValueAtTime(0.2 * vol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.26);
  } catch {}
}

/**
 * Heavy power lock-in boom with sub-bass impact
 */
export function playPowerLockBoom(rarity: CardRarity = 'COMMON', vol = 0.75) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    // Sub-bass impact
    const subOsc = ctx.createOscillator();
    const subGain = ctx.createGain();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(140, now);
    subOsc.frequency.exponentialRampToValueAtTime(38, now + 0.35);
    subGain.gain.setValueAtTime(0.4 * vol, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
    subOsc.connect(subGain);
    subGain.connect(ctx.destination);
    subOsc.start(now);
    subOsc.stop(now + 0.42);

    // Harmonic lock chime
    const chimeFreq = rarity === 'LEGENDARY' ? 880 : rarity === 'EPIC' ? 740 : 587;
    const chimeOsc = ctx.createOscillator();
    const chimeGain = ctx.createGain();
    chimeOsc.type = 'triangle';
    chimeOsc.frequency.setValueAtTime(chimeFreq, now);
    chimeGain.gain.setValueAtTime(0.2 * vol, now);
    chimeGain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
    chimeOsc.connect(chimeGain);
    chimeGain.connect(ctx.destination);
    chimeOsc.start(now);
    chimeOsc.stop(now + 0.65);
  } catch {}
}

/**
 * Low frequency rising tremor and acceleration pulse for the shaking black card
 */
export function playChargeTremor(vol = 0.5) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(45, now);
    osc.frequency.exponentialRampToValueAtTime(160, now + 1.2);

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(120, now);
    filter.frequency.exponentialRampToValueAtTime(450, now + 1.2);

    gain.gain.setValueAtTime(0.05 * vol, now);
    gain.gain.linearRampToValueAtTime(0.28 * vol, now + 1.0);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 1.25);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 1.28);
  } catch {}
}

/**
 * Massive cinematic card reveal explosion boom
 */
export function playCardRevealBoom(rarity: CardRarity = 'COMMON', vol = 0.85) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    // Seismic sub-bass wave
    const sub = ctx.createOscillator();
    const subGain = ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(160, now);
    sub.frequency.exponentialRampToValueAtTime(32, now + 0.55);
    subGain.gain.setValueAtTime(0.55 * vol, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
    sub.connect(subGain);
    subGain.connect(ctx.destination);
    sub.start(now);
    sub.stop(now + 0.62);

    // Explosive acoustic transient / punch
    const bufferSize = ctx.sampleRate * 0.25;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }
    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuffer;
    const noiseFilter = ctx.createBiquadFilter();
    noiseFilter.type = 'lowpass';
    noiseFilter.frequency.setValueAtTime(800, now);
    noiseFilter.frequency.exponentialRampToValueAtTime(100, now + 0.22);
    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.4 * vol, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

    noise.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(ctx.destination);
    noise.start(now);

    // Rarity chord bloom
    const chords: Record<CardRarity, number[]> = {
      COMMON: [261.63, 329.63, 392.00],
      UNCOMMON: [293.66, 369.99, 440.00],
      RARE: [349.23, 440.00, 523.25],
      EPIC: [440.00, 554.37, 659.25],
      LEGENDARY: [523.25, 659.25, 783.99, 1046.50],
      HALLOWEEN_2026: [440.00, 587.33, 783.99, 1174.66]
    };

    const notes = chords[rarity] || chords.COMMON;
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = rarity === 'LEGENDARY' ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(freq, now + 0.02 * idx);
      gain.gain.setValueAtTime(0.18 * vol, now + 0.02 * idx);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.75 + idx * 0.1);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + 0.02 * idx);
      osc.stop(now + 0.8 + idx * 0.1);
    });
  } catch {}
}

/**
 * Crisp, punchy arcade item drop / pop sound inspired by high-stakes reward reveals
 */
export function playItemRevealSound(rarity: CardRarity = 'COMMON', vol = 0.75) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    // Quick punch
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(780, now + 0.12);
    gain.gain.setValueAtTime(0.32 * vol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.38);

    // Harmonic sparkle chord
    const chord = rarity === 'LEGENDARY' || rarity === 'HALLOWEEN_2026'
      ? [659, 830, 987, 1318]
      : rarity === 'EPIC'
      ? [587, 740, 880]
      : rarity === 'RARE'
      ? [493, 622, 740]
      : [440, 554, 659];

    chord.forEach((freq, idx) => {
      const cOsc = ctx.createOscillator();
      const cGain = ctx.createGain();
      cOsc.type = 'sine';
      cOsc.frequency.setValueAtTime(freq, now + 0.04 + idx * 0.035);
      cGain.gain.setValueAtTime(0.14 * vol, now + 0.04 + idx * 0.035);
      cGain.gain.exponentialRampToValueAtTime(0.001, now + 0.55 + idx * 0.05);
      cOsc.connect(cGain);
      cGain.connect(ctx.destination);
      cOsc.start(now + 0.04 + idx * 0.035);
      cOsc.stop(now + 0.6 + idx * 0.05);
    });
  } catch {}
}
