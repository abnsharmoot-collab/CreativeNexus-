import { BattleCardEntity, BattleSessionState } from '../types/story';
import { 
  VALID_ACTIONS, 
  ValidCombatAction, 
  ACTIONS, 
  validateCombatAction, 
  getAvailableCombatActions,
  canCardUseSkill 
} from '../config/combatActions';

export interface ActionScoreBreakdown {
  action: ValidCombatAction;
  totalScore: number;
  baseScore: number;
  resourceScore: number;
  healthScore: number;
  counterScore: number;
  antiRepetitionScore: number;
  rarityBonus: number;
  reasons: string[];
}

export interface AiDecisionReport {
  action: ValidCombatAction;
  chosenAction: ValidCombatAction;
  chosenType: 'STRIKE' | 'HEAVY' | 'DEFENSE' | 'SKILL';
  cardId: string;
  reason: string;
  confidence: number;
  predictedPlayerAction: ValidCombatAction;
  availableActions: ValidCombatAction[];
  scores: Record<ValidCombatAction, ActionScoreBreakdown>;
  rejectedHistory: Array<{ rejectedAction: string; reason: string }>;
  summary: string;
}

// Global debug state for Owner Debug Mode inspection
let lastAiDebugReport: AiDecisionReport | null = null;
let consecutiveCorruptedAttempts = 0;

export function getLastAiDebugReport(): AiDecisionReport | null {
  return lastAiDebugReport;
}

/**
 * Predicts the player's most probable next action using battle state heuristics.
 */
export function predictPlayerNextAction(
  state: BattleSessionState,
  playerCard: BattleCardEntity
): ValidCombatAction {
  const pStamina = playerCard.currentStamina ?? 100;
  const pHpPct = (playerCard.currentHp / (playerCard.maxHp || 100)) * 100;
  const pBuffs = playerCard.activeBuffs;
  const logs = state.logs || [];

  // 1. If player has active Rage buff (+50% next Heavy), they will almost certainly use HEAVY
  if (pBuffs?.heavyDamageMultiplier && pBuffs.heavyDamageMultiplier > 1.2 && pStamina >= 25) {
    return 'heavy';
  }

  // 2. If player is exhausted (stamina <= 15), player CANNOT use Heavy, and usually DEFENDS to recover +25 STM
  if (pStamina <= 15) {
    return 'defense';
  }

  // 3. Inspect player's last 2 actions from logs
  const playerRecentActions: string[] = [];
  for (const log of logs) {
    if (log.actorSide === 'PLAYER') {
      const act = String(log.action).toLowerCase();
      playerRecentActions.push(act);
      if (playerRecentActions.length >= 3) break;
    }
  }

  const lastAction = playerRecentActions[0];

  // If player defended last turn, they are unlikely to defend twice in a row if their stamina recovered
  if (lastAction === 'defense' && pStamina > 50) {
    return 'strike';
  }

  // If player used STRIKE repeatedly (2+ times), they often escalate to HEAVY or switch to DEFENSE
  if (playerRecentActions.length >= 2 && playerRecentActions[0] === 'strike' && playerRecentActions[1] === 'strike') {
    return pStamina >= 30 ? 'heavy' : 'defense';
  }

  // If player HP is critical (< 30%), player is more prone to DEFENSE or survival Skill
  if (pHpPct < 30) {
    return 'defense';
  }

  // Default balanced expectation: strike
  return 'strike';
}

/**
 * Core internal scoring function for ONE available action.
 */
function scoreAction(
  action: ValidCombatAction,
  enemyCard: BattleCardEntity,
  playerCard: BattleCardEntity,
  predictedPlayerAction: ValidCombatAction,
  strikeConsecutive: number,
  heavyConsecutive: number,
  defendConsecutive: number
): ActionScoreBreakdown {
  const aiHp = enemyCard.currentHp;
  const aiMaxHp = enemyCard.maxHp || 100;
  const aiHpPct = (aiHp / aiMaxHp) * 100;

  const playerHp = playerCard.currentHp;
  const aiStamina = enemyCard.currentStamina ?? 100;
  const playerStamina = playerCard.currentStamina ?? 100;

  const aiRarity = (enemyCard.rarity || enemyCard.card?.rarity || 'COMMON').toUpperCase();
  const skill = enemyCard.skill;

  let baseScore = 40;
  let resourceScore = 0;
  let healthScore = 0;
  let counterScore = 0;
  let antiRepetitionScore = 0;
  let rarityBonus = 0;
  const reasons: string[] = [];

  // =========================================================================
  // 1. ACTION: STRIKE (Speed, 15 STM, Beats Heavy)
  // =========================================================================
  if (action === 'strike') {
    baseScore = 48;

    if (aiStamina < 15) {
      resourceScore -= 70;
      reasons.push('Low stamina for Strike');
    } else if (aiStamina < 30) {
      resourceScore += 10;
      reasons.push('Efficient low-cost attack');
    }

    if (predictedPlayerAction === 'heavy') {
      counterScore += 45;
      reasons.push('Counters predicted Heavy attack');
    } else if (predictedPlayerAction === 'defense') {
      counterScore -= 25;
      reasons.push('Predicted Defense would block Strike');
    }

    if ((enemyCard.speed || 60) > (playerCard.speed || 60)) {
      counterScore += 12;
      reasons.push('Speed superiority gives strike clash priority');
    }

    const estStrikeDmg = Math.round((enemyCard.attack || 30) * 0.45);
    if (playerHp <= estStrikeDmg) {
      healthScore += 50;
      reasons.push('Lethal strike opportunity');
    }

    // Anti-repetition penalty
    if (strikeConsecutive === 1) {
      antiRepetitionScore -= 30;
      reasons.push('Penalty: Avoid repeating Strike consecutively');
    } else if (strikeConsecutive >= 2) {
      antiRepetitionScore -= 75;
      reasons.push('Severe Penalty: Prevent 3 consecutive Strikes');
    }
  }

  // =========================================================================
  // 2. ACTION: HEAVY (Massive Damage, 25 STM, Breaks Defense)
  // =========================================================================
  else if (action === 'heavy') {
    baseScore = 44;

    if (aiStamina < 25) {
      resourceScore -= 85;
      reasons.push('Insufficient stamina for Heavy blow');
    } else if (aiStamina >= 65) {
      resourceScore += 22;
      reasons.push('Abundant stamina allows heavy hammer');
    }

    if (enemyCard.activeBuffs?.heavyDamageMultiplier && enemyCard.activeBuffs.heavyDamageMultiplier > 1.2) {
      resourceScore += 55;
      reasons.push('Rage buff primed (+50% Heavy damage)');
    }

    if (predictedPlayerAction === 'defense') {
      counterScore += 50;
      reasons.push('Heavy triggers Guard Break against Defense');
    } else if (predictedPlayerAction === 'strike') {
      counterScore -= 25;
      reasons.push('Opponent Strike could interrupt Heavy');
    }

    if (playerStamina <= 10) {
      counterScore += 30;
      reasons.push('Player exhausted: Heavy deals full damage');
    }

    const estHeavyDmg = Math.round((enemyCard.attack || 30) * 0.9);
    if (playerHp <= estHeavyDmg) {
      healthScore += 55;
      reasons.push('Lethal heavy strike opportunity');
    }

    if (heavyConsecutive >= 1) {
      antiRepetitionScore -= 45;
      reasons.push('Penalty: Avoid repeating Heavy');
    }
  }

  // =========================================================================
  // 3. ACTION: DEFENSE (Restores +25 STM, Blocks Strike)
  // =========================================================================
  else if (action === 'defense') {
    baseScore = 38;

    if (aiStamina <= 20) {
      resourceScore += 65;
      reasons.push('Crucial defense to replenish stamina');
    } else if (aiStamina <= 40) {
      resourceScore += 28;
      reasons.push('Replenish stamina reserves');
    } else if (aiStamina >= 90) {
      resourceScore -= 35;
      reasons.push('Stamina already full');
    }

    if (aiHpPct < 35) {
      healthScore += 32;
      reasons.push('Low HP survival defense');
    }

    if (predictedPlayerAction === 'strike') {
      counterScore += 45;
      reasons.push('Parries Strike and triggers counter window');
    } else if (predictedPlayerAction === 'heavy') {
      counterScore -= 60;
      reasons.push('Danger: Guard Break from predicted Heavy');
    }

    if (defendConsecutive >= 1 && aiStamina > 55) {
      antiRepetitionScore -= 50;
      reasons.push('Penalty: Do not defend repeatedly');
    }
  }

  // =========================================================================
  // 4. ACTION: SKILL (Signature Card Skill - Rare, Epic, Legendary Only)
  // =========================================================================
  else if (action === 'skill') {
    baseScore = 42;
    rarityBonus += aiRarity === 'LEGENDARY' ? 25 : aiRarity === 'EPIC' ? 20 : 15;
    reasons.push(`${aiRarity} skill activation`);

    const skillType = skill?.type;
    if (skillType === 'DEFENSIVE') {
      if (aiHpPct < 50 || predictedPlayerAction === 'heavy') {
        healthScore += 50;
        reasons.push('Fortify mitigates heavy damage');
      }
    } else if (skillType === 'BUFF') {
      if (aiStamina >= 50) {
        counterScore += 48;
        reasons.push('Rage sets up lethal Heavy attack');
      }
    } else if (skillType === 'OFFENSIVE') {
      if (predictedPlayerAction === 'defense') {
        counterScore += 55;
        reasons.push('Arcane Blast punches through guard');
      }
      if (playerHp <= (skill?.damage || 25)) {
        healthScore += 60;
        reasons.push('Skill damage finishes opponent');
      }
    } else if (skillType === 'LIFESTEAL') {
      if (aiHpPct < 75) {
        healthScore += 45;
        reasons.push('Lifesteal recovers vital health');
      }
    }
  }

  const totalScore = Math.max(0, baseScore + resourceScore + healthScore + counterScore + antiRepetitionScore + rarityBonus);

  return {
    action,
    totalScore,
    baseScore,
    resourceScore,
    healthScore,
    counterScore,
    antiRepetitionScore,
    rarityBonus,
    reasons
  };
}

/**
 * Intelligent AI Decision Scoring System:
 * 1. Analyzes battlefield
 * 2. Builds explicit available actions (Strike, Heavy, Defense, and Skill only when qualified)
 * 3. Scores ONLY available actions
 * 4. Selects ONE action with highest score
 * 5. Strictly validates output against VALID_ACTIONS
 * 6. Rejects invalid results, recalculates, and guarantees valid action output
 */
export function evaluateAiActionScores(
  state: BattleSessionState
): AiDecisionReport {
  const rejectedHistory: Array<{ rejectedAction: string; reason: string }> = [];

  const enemyCard = state.enemyCards[state.enemyActiveIndex];
  const playerCard = state.playerCards[state.playerActiveIndex];

  const fallbackCardId = enemyCard?.instanceId || enemyCard?.card?.id || 'enemy_card';

  if (!enemyCard || !playerCard) {
    const fallbackReport: AiDecisionReport = {
      action: 'strike',
      chosenAction: 'strike',
      chosenType: 'STRIKE',
      cardId: fallbackCardId,
      reason: 'Safe default strike (battlefield empty)',
      confidence: 50,
      predictedPlayerAction: 'strike',
      availableActions: ['strike', 'defense'],
      scores: {} as Record<ValidCombatAction, ActionScoreBreakdown>,
      rejectedHistory: [],
      summary: 'Fallback strike executed'
    };
    lastAiDebugReport = fallbackReport;
    return fallbackReport;
  }

  // 1. BUILD EXPLICIT AVAILABLE CANDIDATE ACTIONS
  const availableActions = getAvailableCombatActions(enemyCard);

  // 2. PREDICT PLAYER INTENT
  const predictedPlayerAction = predictPlayerNextAction(state, playerCard);

  // 3. TRACK RECENT AI ACTIONS FOR ANTI-REPETITION
  const logs = state.logs || [];
  const aiRecentActions: string[] = [];
  for (const log of logs) {
    if (log.actorSide === 'ENEMY') {
      const act = String(log.action).toLowerCase();
      aiRecentActions.push(act);
      if (aiRecentActions.length >= 4) break;
    }
  }

  const lastAiAction = aiRecentActions[0];
  const secondLastAiAction = aiRecentActions[1];
  const strikeConsecutive = (lastAiAction === 'strike' ? 1 : 0) + (lastAiAction === 'strike' && secondLastAiAction === 'strike' ? 1 : 0);
  const heavyConsecutive = (lastAiAction === 'heavy' ? 1 : 0);
  const defendConsecutive = (lastAiAction === 'defense' ? 1 : 0);

  // 4. SCORE ONLY AVAILABLE ACTIONS
  const scores: Partial<Record<ValidCombatAction, ActionScoreBreakdown>> = {};
  for (const action of availableActions) {
    scores[action] = scoreAction(
      action,
      enemyCard,
      playerCard,
      predictedPlayerAction,
      strikeConsecutive,
      heavyConsecutive,
      defendConsecutive
    );
  }

  // 5. SORT BY TOTAL SCORE
  const scoredList = Object.values(scores).sort((a, b) => (b?.totalScore || 0) - (a?.totalScore || 0));
  let candidateAction = scoredList[0]?.action;

  // 6. VALIDATION GATEWAY: Strictly validate selected action
  let validatedAction = validateCombatAction(candidateAction);

  // If candidate is invalid (e.g. somehow generic "action" or null):
  if (!validatedAction) {
    rejectedHistory.push({
      rejectedAction: String(candidateAction),
      reason: 'Invalid action ID rejected by AI validation gateway'
    });
    consecutiveCorruptedAttempts += 1;

    // Recalculate: pick first valid action from available actions
    for (const validFallback of availableActions) {
      if (VALID_ACTIONS.includes(validFallback)) {
        validatedAction = validFallback;
        break;
      }
    }

    // Emergency safe fallback if still invalid
    if (!validatedAction) {
      validatedAction = 'strike';
    }
  } else {
    consecutiveCorruptedAttempts = 0;
  }

  // Double check reset condition
  if (consecutiveCorruptedAttempts >= 2) {
    console.warn('[AI Brain] RESET AI DECISION STATE: consecutive corrupted actions detected.');
    validatedAction = 'strike';
    consecutiveCorruptedAttempts = 0;
  }

  const bestBreakdown = scores[validatedAction] || {
    action: validatedAction,
    totalScore: 50,
    baseScore: 50,
    resourceScore: 0,
    healthScore: 0,
    counterScore: 0,
    antiRepetitionScore: 0,
    rarityBonus: 0,
    reasons: ['Calculated tactical decision']
  };

  const topReason = bestBreakdown.reasons[0] || `Selected ${ACTIONS[validatedAction].name} based on tactical advantage`;
  const summary = `AI selected ${ACTIONS[validatedAction].name} (Score: ${bestBreakdown.totalScore}) vs predicted ${ACTIONS[predictedPlayerAction].name}. Reason: ${topReason}`;

  const report: AiDecisionReport = {
    action: validatedAction,
    chosenAction: validatedAction,
    chosenType: (validatedAction === 'heavy' ? 'HEAVY' : validatedAction === 'defense' ? 'DEFENSE' : validatedAction === 'skill' ? 'SKILL' : 'STRIKE'),
    cardId: enemyCard.instanceId || enemyCard.card.id,
    reason: topReason,
    confidence: Math.min(99, Math.max(40, bestBreakdown.totalScore)),
    predictedPlayerAction,
    availableActions,
    scores: scores as Record<ValidCombatAction, ActionScoreBreakdown>,
    rejectedHistory,
    summary
  };

  lastAiDebugReport = report;
  return report;
}

/**
 * Intelligent Card Switcher for bench fighters.
 */
export function evaluateAiCardSwitch(
  state: BattleSessionState
): number | null {
  const currentCard = state.enemyCards[state.enemyActiveIndex];
  if (!currentCard) return null;

  const hpPct = (currentCard.currentHp / (currentCard.maxHp || 100)) * 100;
  if (hpPct > 20 && !currentCard.isDefeated) {
    return null;
  }

  let bestIdx = -1;
  let bestScore = -1;

  state.enemyCards.forEach((c, idx) => {
    if (idx === state.enemyActiveIndex) return;
    if (c.isDefeated || c.currentHp <= 0) return;

    const rarity = (c.rarity || c.card?.rarity || 'COMMON').toUpperCase();
    const rarityWeight = rarity === 'LEGENDARY' ? 30 : rarity === 'EPIC' ? 20 : rarity === 'RARE' ? 10 : 0;
    const cardScore = c.currentHp + rarityWeight + (c.currentStamina ?? 100) * 0.2;

    if (cardScore > bestScore) {
      bestScore = cardScore;
      bestIdx = idx;
    }
  });

  return bestIdx !== -1 ? bestIdx : null;
}
