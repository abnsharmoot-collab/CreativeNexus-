import React from 'react';
import {
  CharacterImageGradientConfig,
  CharacterAudioConfig,
  CharacterSoundClip
} from '../types/characterLove';

/**
 * Builds CSS mask-image styles for character edge fading without affecting card background
 */
export function buildMaskImageStyle(gradient?: CharacterImageGradientConfig): React.CSSProperties {
  if (!gradient || !gradient.enabled) {
    return {};
  }

  const start = Math.max(0, Math.min(100, gradient.startPercent ?? 0));
  const end = Math.max(0, Math.min(100, gradient.endPercent ?? 100));
  const opacity = typeof gradient.opacity === 'number' ? Math.max(0, Math.min(1, gradient.opacity)) : 1;
  const solidColor = `rgba(0, 0, 0, ${opacity})`;
  const transparentColor = 'rgba(0, 0, 0, 0)';

  let maskVal = '';
  if (gradient.direction === 'radial') {
    maskVal = `radial-gradient(circle at center, ${solidColor} ${start}%, ${transparentColor} ${end}%)`;
  } else if (gradient.direction === 'angle') {
    const angle = gradient.angle ?? 180;
    maskVal = `linear-gradient(${angle}deg, ${solidColor} ${start}%, ${transparentColor} ${end}%)`;
  } else {
    // Standard linear directions
    const dirMap: Record<string, string> = {
      'to-bottom': 'to bottom',
      'to-top': 'to top',
      'to-left': 'to left',
      'to-right': 'to right'
    };
    const dir = dirMap[gradient.direction] || 'to bottom';
    maskVal = `linear-gradient(${dir}, ${solidColor} ${start}%, ${transparentColor} ${end}%)`;
  }

  return {
    maskImage: maskVal,
    WebkitMaskImage: maskVal
  };
}

/**
 * Image Preloader Cache to guarantee zero loading delay or flickering
 */
const preloadedImageCache = new Set<string>();

export function preloadImages(urls: (string | undefined | null)[]): void {
  urls.forEach(url => {
    if (!url || preloadedImageCache.has(url)) return;
    try {
      const img = new Image();
      img.src = url;
      preloadedImageCache.add(url);
    } catch {}
  });
}

/**
 * Audio Preloader & Playback Pool
 * Ensures sounds never overlap and are preloaded for instant responsiveness
 */
const audioPool = new Map<string, HTMLAudioElement>();
let activeAudioElement: HTMLAudioElement | null = null;

export function stopCurrentAudio(): void {
  if (activeAudioElement) {
    try {
      activeAudioElement.pause();
      activeAudioElement.currentTime = 0;
    } catch {}
    activeAudioElement = null;
  }
}

export function preloadAudioClip(url: string): HTMLAudioElement | null {
  if (!url) return null;
  let audio = audioPool.get(url);
  if (!audio) {
    try {
      audio = new Audio(url);
      audio.preload = 'auto';
      audio.load();
      audioPool.set(url, audio);
    } catch (err) {
      return null;
    }
  }
  return audio;
}

export function preloadCharacterAudio(audioConfig?: CharacterAudioConfig): void {
  if (!audioConfig || !audioConfig.enabled) return;
  if (audioConfig.audioUrl) {
    preloadAudioClip(audioConfig.audioUrl);
  }
  if (Array.isArray(audioConfig.sounds)) {
    audioConfig.sounds.forEach(clip => {
      if (clip.url) preloadAudioClip(clip.url);
    });
  }
}

/**
 * Plays a single sound with volume
 */
export function playSoundUrl(url: string, volumePercent = 80): void {
  if (!url) return;
  stopCurrentAudio();

  let audio = audioPool.get(url);
  if (!audio) {
    audio = preloadAudioClip(url);
  }
  if (!audio) return;

  try {
    audio.currentTime = 0;
    const vol = Math.max(0, Math.min(1, volumePercent / 100));
    audio.volume = vol;
    activeAudioElement = audio;

    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise.catch(err => {
        console.warn('Audio playback notice:', err?.message);
      });
    }
  } catch (err) {
    console.warn('Failed to play sound:', err);
  }
}

/**
 * Plays a random sound from the character's collection without consecutive repeats
 */
export function playRandomCharacterSound(
  audioConfig?: CharacterAudioConfig,
  lastPlayedId?: string | null
): { playedId: string | null; playedName: string | null } {
  if (!audioConfig || !audioConfig.enabled) {
    return { playedId: null, playedName: null };
  }

  // Check if multiple sounds collection exists
  const soundClips = (audioConfig.sounds || []).filter(s => Boolean(s.url));
  const masterVolume = audioConfig.volume ?? 80;

  if (soundClips.length > 0) {
    // Avoid repeating the same sound twice consecutively if more than 1 sound exists
    let eligible = soundClips;
    if (soundClips.length > 1 && lastPlayedId) {
      const filtered = soundClips.filter(s => s.id !== lastPlayedId);
      if (filtered.length > 0) {
        eligible = filtered;
      }
    }

    const picked = eligible[Math.floor(Math.random() * eligible.length)];
    const finalVolume = typeof picked.volume === 'number' ? picked.volume : masterVolume;
    playSoundUrl(picked.url, finalVolume);
    return { playedId: picked.id, playedName: picked.name };
  }

  // Fallback to legacy single audioUrl if collection is empty
  if (audioConfig.audioUrl) {
    playSoundUrl(audioConfig.audioUrl, masterVolume);
    return { playedId: 'legacy_single', playedName: audioConfig.audioName || 'Default Sound' };
  }

  return { playedId: null, playedName: null };
}

/**
 * Read File as Data URL (image or audio)
 */
export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
