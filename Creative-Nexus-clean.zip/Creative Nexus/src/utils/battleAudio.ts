// Web Audio API Synthesizer for Tactical Card Battles
// Zero external network dependencies, high reliability, zero latency

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  try {
    if (!audioCtx && typeof window !== 'undefined') {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        audioCtx = new AudioContextClass();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume().catch(() => {});
    }
    return audioCtx;
  } catch {
    return null;
  }
}

export type BattleSoundType =
  | 'SWORD_CLASH'
  | 'HEAVY_SLAM'
  | 'SHIELD_BLOCK'
  | 'GUARD_BREAK'
  | 'PARRY_PING'
  | 'ENERGY_SURGE'
  | 'OVERDRIVE_BURST'
  | 'CARD_DEFEAT'
  | 'VICTORY_FANFARE'
  | 'DEFEAT_CHORD'
  | 'FORMATION_SUMMON'
  | 'TACTICAL_SELECT'
  | 'CARD_POP_FORWARD'
  | 'HUD_SLIDE'
  | 'CARD_RETURN_TRAY'
  // Dedicated Combat Action Sounds
  | 'ACTION_STRIKE'
  | 'ACTION_HEAVY'
  | 'ACTION_DEFENSE'
  | 'ACTION_SKILL'
  | 'ACTION_CRITICAL'
  | 'ACTION_COUNTER'
  | 'ACTION_STANDOFF'
  // Legendary Curated Preset Sounds
  | 'LEGENDARY_STRIKE_CELESTIAL'
  | 'LEGENDARY_STRIKE_VOID'
  | 'LEGENDARY_STRIKE_THUNDER'
  | 'LEGENDARY_HEAVY_TITAN'
  | 'LEGENDARY_HEAVY_METEOR'
  | 'LEGENDARY_HEAVY_SEISMIC'
  | 'LEGENDARY_DEFENSE_AEGIS'
  | 'LEGENDARY_DEFENSE_PRISMATIC'
  | 'LEGENDARY_DEFENSE_CYBER'
  | 'LEGENDARY_SKILL_SUPERNOVA'
  | 'LEGENDARY_SKILL_CELESTIAL'
  | 'LEGENDARY_SKILL_GODSPEED';

export function playBattleSound(type: BattleSoundType, volume: number = 0.65): void {
  const ctx = getAudioContext();
  if (!ctx) return;
  const now = ctx.currentTime;
  const vol = Math.max(0.05, Math.min(1.0, volume));

  switch (type) {
    case 'SWORD_CLASH': {
      // White noise blade friction + metallic high ring
      const bufferSize = ctx.sampleRate * 0.12;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.2));

      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      const noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(0.4 * vol, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
      noise.connect(noiseGain);
      noiseGain.connect(ctx.destination);
      noise.start(now);

      // Metallic ring
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(1800, now);
      osc.frequency.exponentialRampToValueAtTime(800, now + 0.25);
      oscGain.gain.setValueAtTime(0.3 * vol, now);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.connect(oscGain);
      oscGain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.25);
      break;
    }

    case 'HEAVY_SLAM': {
      // Sub bass boom + low distortion crunch
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(140, now);
      osc.frequency.exponentialRampToValueAtTime(35, now + 0.35);

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(350, now);
      filter.frequency.exponentialRampToValueAtTime(60, now + 0.35);

      oscGain.gain.setValueAtTime(0.6 * vol, now);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

      osc.connect(filter);
      filter.connect(oscGain);
      oscGain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.4);
      break;
    }

    case 'SHIELD_BLOCK': {
      // Resonant kinetic gong
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(540, now);
      osc.frequency.exponentialRampToValueAtTime(220, now + 0.3);
      oscGain.gain.setValueAtTime(0.5 * vol, now);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

      osc.connect(oscGain);
      oscGain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.3);
      break;
    }

    case 'GUARD_BREAK': {
      // Crystalline glass shatter + shockwave
      for (let i = 0; i < 4; i++) {
        const osc = ctx.createOscillator();
        const oscGain = ctx.createGain();
        osc.type = 'sine';
        const freq = 1200 + i * 450 + Math.random() * 200;
        osc.frequency.setValueAtTime(freq, now + i * 0.03);
        osc.frequency.exponentialRampToValueAtTime(200, now + 0.4);
        oscGain.gain.setValueAtTime(0.25 * vol, now + i * 0.03);
        oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
        osc.connect(oscGain);
        oscGain.connect(ctx.destination);
        osc.start(now + i * 0.03);
        osc.stop(now + 0.4);
      }
      break;
    }

    case 'PARRY_PING': {
      // High-pitched kinetic deflection ping
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(2400, now);
      osc.frequency.exponentialRampToValueAtTime(1400, now + 0.28);
      oscGain.gain.setValueAtTime(0.45 * vol, now);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
      osc.connect(oscGain);
      oscGain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.28);
      break;
    }

    case 'ENERGY_SURGE': {
      // Rising plasma hum
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.35);
      oscGain.gain.setValueAtTime(0.35 * vol, now);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc.connect(oscGain);
      oscGain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.35);
      break;
    }

    case 'OVERDRIVE_BURST': {
      // Majestic chord burst with swelling sub bass
      const freqs = [220, 277.18, 329.63, 440, 554.37];
      freqs.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const oscGain = ctx.createGain();
        osc.type = idx === 0 ? 'sawtooth' : 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.04);
        osc.frequency.linearRampToValueAtTime(freq * 1.5, now + 0.6);
        oscGain.gain.setValueAtTime(0.2 * vol, now + idx * 0.04);
        oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
        osc.connect(oscGain);
        oscGain.connect(ctx.destination);
        osc.start(now + idx * 0.04);
        osc.stop(now + 0.7);
      });
      break;
    }

    case 'CARD_DEFEAT': {
      // Low dissolution static + falling tone
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(300, now);
      osc.frequency.exponentialRampToValueAtTime(45, now + 0.6);
      oscGain.gain.setValueAtTime(0.4 * vol, now);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
      osc.connect(oscGain);
      oscGain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.65);
      break;
    }

    case 'VICTORY_FANFARE': {
      // Triad chords: C - E - G - C
      const notes = [261.63, 329.63, 392.00, 523.25, 659.25];
      notes.forEach((note, i) => {
        const osc = ctx.createOscillator();
        const oscGain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(note, now + i * 0.12);
        oscGain.gain.setValueAtTime(0.3 * vol, now + i * 0.12);
        oscGain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.12 + 0.5);
        osc.connect(oscGain);
        oscGain.connect(ctx.destination);
        osc.start(now + i * 0.12);
        osc.stop(now + i * 0.12 + 0.5);
      });
      break;
    }

    case 'DEFEAT_CHORD': {
      const notes = [220, 261.63, 311.13]; // A diminished
      notes.forEach((note) => {
        const osc = ctx.createOscillator();
        const oscGain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(note, now);
        osc.frequency.exponentialRampToValueAtTime(note * 0.7, now + 0.8);
        oscGain.gain.setValueAtTime(0.3 * vol, now);
        oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);
        osc.connect(oscGain);
        oscGain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.8);
      });
      break;
    }

    case 'FORMATION_SUMMON': {
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.exponentialRampToValueAtTime(640, now + 0.3);
      oscGain.gain.setValueAtTime(0.25 * vol, now);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      osc.connect(oscGain);
      oscGain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.3);
      break;
    }

    case 'TACTICAL_SELECT': {
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(1200, now + 0.08);
      oscGain.gain.setValueAtTime(0.2 * vol, now);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      osc.connect(oscGain);
      oscGain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.08);
      break;
    }

    case 'CARD_POP_FORWARD': {
      // Crisp aerodynamic air whoosh + harmonic chime lifting up
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.22);
      gain.gain.setValueAtTime(0.25 * vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.24);

      // Shimmer overlay
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(1200, now + 0.05);
      osc2.frequency.exponentialRampToValueAtTime(1600, now + 0.2);
      gain2.gain.setValueAtTime(0.12 * vol, now + 0.05);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.05);
      osc2.stop(now + 0.2);
      break;
    }

    case 'HUD_SLIDE': {
      // Sleek mechanical cybernetic servo slide
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(330, now + 0.18);
      gain.gain.setValueAtTime(0.18 * vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.18);

      // Soft high click at end
      const clickOsc = ctx.createOscillator();
      const clickGain = ctx.createGain();
      clickOsc.type = 'sine';
      clickOsc.frequency.setValueAtTime(950, now + 0.14);
      clickGain.gain.setValueAtTime(0.08 * vol, now + 0.14);
      clickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      clickOsc.connect(clickGain);
      clickGain.connect(ctx.destination);
      clickOsc.start(now + 0.14);
      clickOsc.stop(now + 0.18);
      break;
    }

    case 'CARD_RETURN_TRAY': {
      // Gentle descending aerodynamic whoosh + soft dock tap
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(650, now);
      osc.frequency.exponentialRampToValueAtTime(260, now + 0.22);
      gain.gain.setValueAtTime(0.22 * vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.24);

      // Soft dock tap
      const tap = ctx.createOscillator();
      const tapGain = ctx.createGain();
      tap.type = 'triangle';
      tap.frequency.setValueAtTime(180, now + 0.2);
      tap.frequency.exponentialRampToValueAtTime(90, now + 0.27);
      tapGain.gain.setValueAtTime(0.2 * vol, now + 0.2);
      tapGain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
      tap.connect(tapGain);
      tapGain.connect(ctx.destination);
      tap.start(now + 0.2);
      tap.stop(now + 0.28);
      break;
    }

    // =========================================================================
    // DEDICATED COMBAT ACTION SOUNDS
    // =========================================================================

    case 'ACTION_STRIKE': {
      // 1. Aerodynamic high-velocity razor blade cut whip
      const bufferSize = Math.floor(ctx.sampleRate * 0.15);
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.18));
      }
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      const bFilter = ctx.createBiquadFilter();
      bFilter.type = 'bandpass';
      bFilter.frequency.setValueAtTime(3200, now);
      bFilter.frequency.exponentialRampToValueAtTime(1200, now + 0.14);
      bFilter.Q.value = 3.5;

      const nGain = ctx.createGain();
      nGain.gain.setValueAtTime(0.55 * vol, now);
      nGain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

      noise.connect(bFilter);
      bFilter.connect(nGain);
      nGain.connect(ctx.destination);
      noise.start(now);

      // 2. High-frequency slicing metallic ring
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(2400, now);
      osc.frequency.exponentialRampToValueAtTime(980, now + 0.22);
      oscGain.gain.setValueAtTime(0.4 * vol, now);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

      osc.connect(oscGain);
      oscGain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.22);
      break;
    }

    case 'ACTION_HEAVY': {
      // 1. Massive earthquake sub-bass drop (35Hz)
      const subOsc = ctx.createOscillator();
      const subGain = ctx.createGain();
      subOsc.type = 'sawtooth';
      subOsc.frequency.setValueAtTime(160, now);
      subOsc.frequency.exponentialRampToValueAtTime(28, now + 0.45);

      const subFilter = ctx.createBiquadFilter();
      subFilter.type = 'lowpass';
      subFilter.frequency.setValueAtTime(450, now);
      subFilter.frequency.exponentialRampToValueAtTime(50, now + 0.45);

      subGain.gain.setValueAtTime(0.85 * vol, now);
      subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.48);

      subOsc.connect(subFilter);
      subFilter.connect(subGain);
      subGain.connect(ctx.destination);
      subOsc.start(now);
      subOsc.stop(now + 0.48);

      // 2. Heavy anvil distortion crunch impact
      const crunchOsc = ctx.createOscillator();
      const crunchGain = ctx.createGain();
      crunchOsc.type = 'triangle';
      crunchOsc.frequency.setValueAtTime(280, now);
      crunchOsc.frequency.exponentialRampToValueAtTime(65, now + 0.25);
      crunchGain.gain.setValueAtTime(0.5 * vol, now);
      crunchGain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

      crunchOsc.connect(crunchGain);
      crunchGain.connect(ctx.destination);
      crunchOsc.start(now);
      crunchOsc.stop(now + 0.28);
      break;
    }

    case 'ACTION_DEFENSE': {
      // 1. Resonant kinetic crystalline forcefield gong
      const gongOsc = ctx.createOscillator();
      const gongGain = ctx.createGain();
      gongOsc.type = 'sine';
      gongOsc.frequency.setValueAtTime(480, now);
      gongOsc.frequency.exponentialRampToValueAtTime(220, now + 0.38);
      gongGain.gain.setValueAtTime(0.5 * vol, now);
      gongGain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

      gongOsc.connect(gongGain);
      gongGain.connect(ctx.destination);
      gongOsc.start(now);
      gongOsc.stop(now + 0.4);

      // 2. High protective crystalline harmonic ring (1800Hz -> 880Hz)
      const ringOsc = ctx.createOscillator();
      const ringGain = ctx.createGain();
      ringOsc.type = 'triangle';
      ringOsc.frequency.setValueAtTime(1760, now);
      ringOsc.frequency.exponentialRampToValueAtTime(880, now + 0.45);
      ringGain.gain.setValueAtTime(0.3 * vol, now);
      ringGain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

      ringOsc.connect(ringGain);
      ringGain.connect(ctx.destination);
      ringOsc.start(now);
      ringOsc.stop(now + 0.45);
      break;
    }

    case 'ACTION_SKILL': {
      // Celestial harmonic chord arpeggio (C - G - D - A) + plasma energy surge
      const skillNotes = [261.63, 392.00, 587.33, 880.00, 1174.66];
      skillNotes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
        const startT = now + idx * 0.05;
        osc.frequency.setValueAtTime(freq, startT);
        osc.frequency.exponentialRampToValueAtTime(freq * 1.3, startT + 0.35);

        gain.gain.setValueAtTime(0.24 * vol, startT);
        gain.gain.exponentialRampToValueAtTime(0.001, startT + 0.45);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startT);
        osc.stop(startT + 0.45);
      });
      break;
    }

    case 'ACTION_CRITICAL': {
      // Explosive supersonic thunder crack + metallic ring
      const blastOsc = ctx.createOscillator();
      const blastGain = ctx.createGain();
      blastOsc.type = 'sawtooth';
      blastOsc.frequency.setValueAtTime(360, now);
      blastOsc.frequency.exponentialRampToValueAtTime(45, now + 0.3);
      blastGain.gain.setValueAtTime(0.7 * vol, now);
      blastGain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      blastOsc.connect(blastGain);
      blastGain.connect(ctx.destination);
      blastOsc.start(now);
      blastOsc.stop(now + 0.35);

      // High glass ping
      const highOsc = ctx.createOscillator();
      const highGain = ctx.createGain();
      highOsc.type = 'sine';
      highOsc.frequency.setValueAtTime(3200, now);
      highOsc.frequency.exponentialRampToValueAtTime(1400, now + 0.4);
      highGain.gain.setValueAtTime(0.5 * vol, now);
      highGain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

      highOsc.connect(highGain);
      highGain.connect(ctx.destination);
      highOsc.start(now);
      highOsc.stop(now + 0.45);
      break;
    }

    case 'ACTION_COUNTER': {
      // Sharp kinetic deflection ping + reverse whoosh
      const parryOsc = ctx.createOscillator();
      const parryGain = ctx.createGain();
      parryOsc.type = 'sine';
      parryOsc.frequency.setValueAtTime(2600, now);
      parryOsc.frequency.exponentialRampToValueAtTime(1800, now + 0.25);
      parryGain.gain.setValueAtTime(0.5 * vol, now);
      parryGain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

      parryOsc.connect(parryGain);
      parryGain.connect(ctx.destination);
      parryOsc.start(now);
      parryOsc.stop(now + 0.25);
      break;
    }

    case 'ACTION_STANDOFF': {
      // Grinding cross-blade friction vibration
      const grindOsc = ctx.createOscillator();
      const grindGain = ctx.createGain();
      grindOsc.type = 'triangle';
      grindOsc.frequency.setValueAtTime(420, now);
      grindOsc.frequency.linearRampToValueAtTime(480, now + 0.3);
      grindGain.gain.setValueAtTime(0.35 * vol, now);
      grindGain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      grindOsc.connect(grindGain);
      grindGain.connect(ctx.destination);
      grindOsc.start(now);
      grindOsc.stop(now + 0.35);
      break;
    }

    // =========================================================================
    // LEGENDARY PRESETS
    // =========================================================================

    case 'LEGENDARY_STRIKE_CELESTIAL': {
      // Ethereal crystalline katana slash
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      osc1.type = 'sine';
      osc2.type = 'triangle';
      osc1.frequency.setValueAtTime(1920, now);
      osc2.frequency.setValueAtTime(2880, now);
      osc1.frequency.exponentialRampToValueAtTime(640, now + 0.28);
      osc2.frequency.exponentialRampToValueAtTime(960, now + 0.28);
      gain.gain.setValueAtTime(0.45 * vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);
      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.3);
      osc2.stop(now + 0.3);
      break;
    }

    case 'LEGENDARY_STRIKE_VOID': {
      // Deep abyssal void cut
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(420, now);
      osc.frequency.exponentialRampToValueAtTime(75, now + 0.3);
      gain.gain.setValueAtTime(0.5 * vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.32);
      break;
    }

    case 'LEGENDARY_STRIKE_THUNDER': {
      // Rapid lightning whip
      for (let i = 0; i < 3; i++) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(1400 + i * 600, now + i * 0.04);
        osc.frequency.exponentialRampToValueAtTime(180, now + i * 0.04 + 0.15);
        gain.gain.setValueAtTime(0.25 * vol, now + i * 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.04 + 0.16);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + i * 0.04);
        osc.stop(now + i * 0.04 + 0.16);
      }
      break;
    }

    case 'LEGENDARY_HEAVY_TITAN': {
      // Seismic titan hammer with sub-woofer shake
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.exponentialRampToValueAtTime(24, now + 0.55);
      gain.gain.setValueAtTime(0.9 * vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.58);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.58);
      break;
    }

    case 'LEGENDARY_HEAVY_METEOR': {
      // Falling meteor crash
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.linearRampToValueAtTime(450, now + 0.08);
      osc.frequency.exponentialRampToValueAtTime(32, now + 0.5);
      gain.gain.setValueAtTime(0.85 * vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.52);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.52);
      break;
    }

    case 'LEGENDARY_HEAVY_SEISMIC': {
      // Earth-splitting tectonic rumble
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(95, now);
      osc.frequency.exponentialRampToValueAtTime(20, now + 0.65);
      gain.gain.setValueAtTime(0.9 * vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.7);
      break;
    }

    case 'LEGENDARY_DEFENSE_AEGIS': {
      // Golden temple sanctuary gong
      const chords = [330, 440, 554.37, 659.25];
      chords.forEach(f => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(f, now);
        osc.frequency.exponentialRampToValueAtTime(f * 0.95, now + 0.6);
        gain.gain.setValueAtTime(0.25 * vol, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.65);
      });
      break;
    }

    case 'LEGENDARY_DEFENSE_PRISMATIC': {
      // Prismatic crystal mirror deflection
      const freqs = [1046.5, 1318.51, 1567.98, 2093.0];
      freqs.forEach((f, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(f, now + i * 0.03);
        osc.frequency.exponentialRampToValueAtTime(f * 0.8, now + i * 0.03 + 0.35);
        gain.gain.setValueAtTime(0.2 * vol, now + i * 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.03 + 0.4);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + i * 0.03);
        osc.stop(now + i * 0.03 + 0.4);
      });
      break;
    }

    case 'LEGENDARY_DEFENSE_CYBER': {
      // High-tech matrix energy barrier
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(880, now);
      osc.frequency.exponentialRampToValueAtTime(320, now + 0.25);
      gain.gain.setValueAtTime(0.4 * vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.28);
      break;
    }

    case 'LEGENDARY_SKILL_SUPERNOVA': {
      // Cosmic supernova explosion with swelling resonance
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(120, now);
      osc.frequency.exponentialRampToValueAtTime(780, now + 0.3);
      osc.frequency.exponentialRampToValueAtTime(55, now + 0.7);
      gain.gain.setValueAtTime(0.6 * vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.75);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.75);
      break;
    }

    case 'LEGENDARY_SKILL_CELESTIAL': {
      // Ethereal god hymn
      const notes = [440, 554.37, 659.25, 880, 1108.73, 1318.51];
      notes.forEach((f, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(f, now + i * 0.04);
        gain.gain.setValueAtTime(0.2 * vol, now + i * 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.04 + 0.6);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + i * 0.04);
        osc.stop(now + i * 0.04 + 0.6);
      });
      break;
    }

    case 'LEGENDARY_SKILL_GODSPEED': {
      // Hyperdrive warp acceleration
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(200, now);
      osc.frequency.exponentialRampToValueAtTime(3200, now + 0.35);
      gain.gain.setValueAtTime(0.5 * vol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.38);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.38);
      break;
    }
  }
}

// =============================================================================
// CUSTOMIZABLE LEGENDARY AUDIO SYSTEM
// =============================================================================

export type CombatActionType = 'strike' | 'heavy' | 'defense' | 'skill';

export interface ActionSoundConfig {
  presetId?: string; // preset key or 'custom'
  customAudioUrl?: string; // base64 or audio URL
  customAudioName?: string;
  volume?: number; // 0.1 to 1.5 (default 1.0)
  pitchMultiplier?: number; // 0.5 to 2.0 (default 1.0)
}

export interface LegendaryCombatSfxConfig {
  volume: number; // Master volume
  enabled: boolean;
  actions: Record<CombatActionType, ActionSoundConfig>;
  cardOverrides?: Record<string, Partial<Record<CombatActionType, ActionSoundConfig>>>;
}

export const DEFAULT_LEGENDARY_COMBAT_SFX: LegendaryCombatSfxConfig = {
  volume: 1.0,
  enabled: true,
  actions: {
    strike: { presetId: 'celestial', volume: 1.0, pitchMultiplier: 1.0 },
    heavy: { presetId: 'titan', volume: 1.0, pitchMultiplier: 1.0 },
    defense: { presetId: 'aegis', volume: 1.0, pitchMultiplier: 1.0 },
    skill: { presetId: 'supernova', volume: 1.0, pitchMultiplier: 1.0 }
  },
  cardOverrides: {}
};

export const ACTION_PRESET_OPTIONS: Record<CombatActionType, Array<{ id: string; name: string; nameAr: string; soundType: BattleSoundType }>> = {
  strike: [
    { id: 'celestial', name: 'Celestial Katana', nameAr: 'سيف كوني سماوي', soundType: 'LEGENDARY_STRIKE_CELESTIAL' },
    { id: 'void', name: 'Void Dagger', nameAr: 'خنجر العدم', soundType: 'LEGENDARY_STRIKE_VOID' },
    { id: 'thunder', name: 'Thunder Slash', nameAr: 'صاعقة البرق', soundType: 'LEGENDARY_STRIKE_THUNDER' },
    { id: 'default', name: 'Standard Agile Strike', nameAr: 'هجوم سريع قياسي', soundType: 'ACTION_STRIKE' }
  ],
  heavy: [
    { id: 'titan', name: 'Titan Hammer', nameAr: 'مطرقة التيتان', soundType: 'LEGENDARY_HEAVY_TITAN' },
    { id: 'meteor', name: 'Meteor Impact', nameAr: 'ارتطام النيزك', soundType: 'LEGENDARY_HEAVY_METEOR' },
    { id: 'seismic', name: 'Tectonic Quake', nameAr: 'زلزال تكتوني', soundType: 'LEGENDARY_HEAVY_SEISMIC' },
    { id: 'default', name: 'Standard Heavy Slam', nameAr: 'ضربة ثقيلة قياسية', soundType: 'ACTION_HEAVY' }
  ],
  defense: [
    { id: 'aegis', name: 'Aegis Bastion', nameAr: 'حصن إيجيس المقدس', soundType: 'LEGENDARY_DEFENSE_AEGIS' },
    { id: 'prismatic', name: 'Prismatic Mirror', nameAr: 'مرآة بلورية عاكسة', soundType: 'LEGENDARY_DEFENSE_PRISMATIC' },
    { id: 'cyber', name: 'Cybernetic Grid', nameAr: 'درع سايبراني', soundType: 'LEGENDARY_DEFENSE_CYBER' },
    { id: 'default', name: 'Standard Defense Barrier', nameAr: 'حاجز دفاعي قياسي', soundType: 'ACTION_DEFENSE' }
  ],
  skill: [
    { id: 'supernova', name: 'Supernova Detonation', nameAr: 'انفجار المستعر الأعظم', soundType: 'LEGENDARY_SKILL_SUPERNOVA' },
    { id: 'celestial', name: 'Celestial Hymn', nameAr: 'ترنيمة سماوية مقدسة', soundType: 'LEGENDARY_SKILL_CELESTIAL' },
    { id: 'godspeed', name: 'Godspeed Velocity', nameAr: 'سرعة الإله الخارقة', soundType: 'LEGENDARY_SKILL_GODSPEED' },
    { id: 'default', name: 'Standard Tactical Skill', nameAr: 'مهارة تكتيكية قياسية', soundType: 'ACTION_SKILL' }
  ]
};

const LOCAL_STORAGE_LEGENDARY_SFX_KEY = 'cr_legendary_combat_sfx_v1';
let cachedLegendaryConfig: LegendaryCombatSfxConfig = DEFAULT_LEGENDARY_COMBAT_SFX;

// Load config from LocalStorage synchronously
export function getLegendaryCombatSfxConfig(): LegendaryCombatSfxConfig {
  if (typeof window === 'undefined') return DEFAULT_LEGENDARY_COMBAT_SFX;
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_LEGENDARY_SFX_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      cachedLegendaryConfig = {
        ...DEFAULT_LEGENDARY_COMBAT_SFX,
        ...parsed,
        actions: {
          ...DEFAULT_LEGENDARY_COMBAT_SFX.actions,
          ...(parsed.actions || {})
        },
        cardOverrides: {
          ...(parsed.cardOverrides || {})
        }
      };
    }
  } catch {
    // Keep fallback
  }
  return cachedLegendaryConfig;
}

// Save config to LocalStorage & async POST to server
export async function saveLegendaryCombatSfxConfig(newConfig: Partial<LegendaryCombatSfxConfig>): Promise<LegendaryCombatSfxConfig> {
  const current = getLegendaryCombatSfxConfig();
  const merged: LegendaryCombatSfxConfig = {
    ...current,
    ...newConfig,
    actions: {
      ...current.actions,
      ...(newConfig.actions || {})
    },
    cardOverrides: {
      ...(current.cardOverrides || {}),
      ...(newConfig.cardOverrides || {})
    }
  };

  cachedLegendaryConfig = merged;

  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(LOCAL_STORAGE_LEGENDARY_SFX_KEY, JSON.stringify(merged));
    } catch (e) {
      console.warn('LocalStorage save error for legendary sfx:', e);
    }
  }

  // Attempt async sync to server
  try {
    await fetch('/api/cards/legendary-combat-sfx', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ sfxConfig: merged })
    });
  } catch {
    // Local persistence is authoritative
  }

  return merged;
}

// Fetch from server on startup
export async function fetchServerLegendaryCombatSfx(): Promise<LegendaryCombatSfxConfig> {
  try {
    const res = await fetch('/api/cards/legendary-combat-sfx');
    if (res.ok) {
      const data = await res.json();
      if (data.success && data.sfxConfig) {
        return saveLegendaryCombatSfxConfig(data.sfxConfig);
      }
    }
  } catch {
    // Silently retain local config
  }
  return getLegendaryCombatSfxConfig();
}

// Play custom audio buffer / audio tag with volume & pitch
export async function playCustomAudio(url: string, volume: number = 1.0, pitchMultiplier: number = 1.0): Promise<void> {
  try {
    const audio = new Audio(url);
    audio.volume = Math.max(0.05, Math.min(1.0, volume));
    if (pitchMultiplier !== 1.0) {
      audio.playbackRate = Math.max(0.5, Math.min(2.0, pitchMultiplier));
    }
    await audio.play();
  } catch (err) {
    console.warn('Custom audio playback failed, falling back to synthesizer:', err);
    playBattleSound('ACTION_STRIKE', volume);
  }
}

/**
 * Universal Combat Action Sound Player
 * Automatically handles:
 * - Specific action sound (Strike, Heavy, Defense, Skill)
 * - Legendary card customization (custom audio upload OR curated epic presets)
 * - Volume & pitch scaling
 * - Clash outcomes (Blocked, Guard Break, Critical, Standoff)
 */
export async function playCombatActionSound(
  action: CombatActionType | string,
  options?: {
    card?: { id?: string; rarity?: string; card?: { rarity?: string } } | null;
    isBlocked?: boolean;
    isCrit?: boolean;
    isGuardBreak?: boolean;
    volume?: number;
  }
): Promise<void> {
  const normAction = (action || 'strike').toLowerCase() as CombatActionType;
  const card = options?.card;
  const rawRarity = (card?.rarity || (card as any)?.card?.rarity || '').toUpperCase();
  const isLegendary = rawRarity === 'LEGENDARY';
  const cardId = card?.id;

  const baseVol = options?.volume ?? 0.85;

  // 1. Check if card is Legendary and has customization
  if (isLegendary) {
    const config = getLegendaryCombatSfxConfig();
    if (config.enabled) {
      const cardSpecific = cardId && config.cardOverrides ? config.cardOverrides[cardId]?.[normAction] : null;
      const actionConfig: ActionSoundConfig = cardSpecific || config.actions?.[normAction] || { presetId: 'default' };

      const vol = (actionConfig.volume ?? 1.0) * (config.volume ?? 1.0) * baseVol;

      // Custom uploaded file
      if (actionConfig.customAudioUrl) {
        await playCustomAudio(actionConfig.customAudioUrl, vol, actionConfig.pitchMultiplier ?? 1.0);
        handleOutcomeSounds(options, vol);
        return;
      }

      // Preset chosen
      const presetId = actionConfig.presetId || 'default';
      const presetList = ACTION_PRESET_OPTIONS[normAction] || [];
      const foundPreset = presetList.find(p => p.id === presetId);
      if (foundPreset) {
        playBattleSound(foundPreset.soundType, vol);
        handleOutcomeSounds(options, vol);
        return;
      }
    }
  }

  // 2. Standard dedicated action synthesizer
  switch (normAction) {
    case 'strike':
      playBattleSound('ACTION_STRIKE', baseVol);
      break;
    case 'heavy':
      playBattleSound('ACTION_HEAVY', baseVol);
      break;
    case 'defense':
      playBattleSound('ACTION_DEFENSE', baseVol);
      break;
    case 'skill':
      playBattleSound('ACTION_SKILL', baseVol);
      break;
    default:
      playBattleSound('SWORD_CLASH', baseVol);
      break;
  }

  handleOutcomeSounds(options, baseVol);
}

function handleOutcomeSounds(options?: { isBlocked?: boolean; isCrit?: boolean; isGuardBreak?: boolean }, vol: number = 0.8) {
  if (!options) return;

  if (options.isGuardBreak) {
    setTimeout(() => playBattleSound('GUARD_BREAK', vol), 100);
  } else if (options.isBlocked) {
    setTimeout(() => playBattleSound('SHIELD_BLOCK', vol * 0.9), 60);
  } else if (options.isCrit) {
    setTimeout(() => playBattleSound('ACTION_CRITICAL', vol), 80);
  }
}

