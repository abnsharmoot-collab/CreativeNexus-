/**
 * Universal Video Helper
 * Robustly normalizes, parses, and provides reliable playback for ANY video source:
 * - YouTube (standard watch URLs with any query param order, shortened youtu.be, shorts, embeds, live, mobile, no-cookie)
 * - Vimeo (standard, unlisted with hash, player links, channel links)
 * - Streamable
 * - Google Drive (shared links, preview links, download links)
 * - Dropbox (converts dl=0 to raw=1 for direct streaming)
 * - Loom (share links -> embed)
 * - Dailymotion (dailymotion.com and dai.ly links)
 * - Twitch (clips and video highlights)
 * - Imgur (gifv -> mp4, gallery -> mp4)
 * - Giphy (gif page -> mp4)
 * - Direct video files (.mp4, .webm, .mov, .ogg, .ogv, .m4v, .mkv, .avi, .flv, .3gp, .ts, blob:, data:)
 * - Cloud/CDN storage URLs (Discord, AWS S3, Supabase, Firebase Storage, Cloudinary, etc.)
 */

export type VideoSourceType =
  | 'direct'
  | 'youtube'
  | 'vimeo'
  | 'streamable'
  | 'google_drive'
  | 'loom'
  | 'dailymotion'
  | 'twitch'
  | 'iframe';

export interface ParsedVideoSource {
  type: VideoSourceType;
  rawUrl: string;
  directUrl?: string;
  embedUrl?: string;
  videoId?: string;
  isIframe: boolean;
  format?: string;
}

export function parseUniversalVideoUrl(url: string | undefined | null): ParsedVideoSource | null {
  if (!url || typeof url !== 'string') return null;
  const trimmed = url.trim();
  if (!trimmed) return null;

  // 1. YouTube
  // Handles:
  // - https://www.youtube.com/watch?v=VIDEO_ID
  // - https://www.youtube.com/watch?feature=shared&v=VIDEO_ID&t=15s
  // - https://youtu.be/VIDEO_ID?si=...
  // - https://www.youtube.com/shorts/VIDEO_ID
  // - https://www.youtube.com/embed/VIDEO_ID
  // - https://www.youtube.com/live/VIDEO_ID
  // - https://www.youtube.com/v/VIDEO_ID
  // - https://m.youtube.com/watch?v=VIDEO_ID
  // - https://www.youtube-nocookie.com/embed/VIDEO_ID
  try {
    if (
      trimmed.includes('youtube.com') ||
      trimmed.includes('youtu.be') ||
      trimmed.includes('youtube-nocookie.com')
    ) {
      let videoId: string | null = null;

      // Check youtu.be/ID
      const shortMatch = trimmed.match(/youtu\.be\/([a-zA-Z0-9_-]{11})/i);
      if (shortMatch && shortMatch[1]) {
        videoId = shortMatch[1];
      }

      // Check /shorts/ID, /embed/ID, /live/ID, /v/ID
      if (!videoId) {
        const pathMatch = trimmed.match(
          /youtube(?:-nocookie)?\.com\/(?:shorts|embed|live|v)\/([a-zA-Z0-9_-]{11})/i
        );
        if (pathMatch && pathMatch[1]) {
          videoId = pathMatch[1];
        }
      }

      // Check ?v=ID anywhere in query params
      if (!videoId) {
        const vParamMatch = trimmed.match(/[?&]v=([a-zA-Z0-9_-]{11})/i);
        if (vParamMatch && vParamMatch[1]) {
          videoId = vParamMatch[1];
        }
      }

      if (videoId) {
        return {
          type: 'youtube',
          rawUrl: trimmed,
          videoId,
          embedUrl: `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&mute=0&controls=0&modestbranding=1&rel=0&enablejsapi=1&playsinline=1&iv_load_policy=3&loop=0`,
          isIframe: true
        };
      }
    }
  } catch {}

  // 2. Vimeo
  // Handles:
  // - https://vimeo.com/123456789
  // - https://vimeo.com/123456789/abcdef123 (unlisted)
  // - https://player.vimeo.com/video/123456789
  // - https://vimeo.com/channels/staffpicks/123456789
  // - https://vimeo.com/groups/name/videos/123456789
  try {
    if (trimmed.includes('vimeo.com')) {
      const vimeoMatch = trimmed.match(/vimeo\.com\/(?:video\/|channels\/[^/]+\/|groups\/[^/]+\/videos\/)?([0-9]+)(?:\/([a-zA-Z0-9]+))?/i);
      if (vimeoMatch && vimeoMatch[1]) {
        const videoId = vimeoMatch[1];
        const unlistedHash = vimeoMatch[2];
        const hashParam = unlistedHash ? `h=${unlistedHash}&` : '';
        return {
          type: 'vimeo',
          rawUrl: trimmed,
          videoId,
          embedUrl: `https://player.vimeo.com/video/${videoId}?${hashParam}autoplay=1&muted=0&controls=0&badge=0&autopause=0&playsinline=1`,
          isIframe: true
        };
      }
    }
  } catch {}

  // 3. Streamable
  // Match streamable.com/CODE or streamable.com/e/CODE
  try {
    if (trimmed.includes('streamable.com')) {
      const streamableMatch = trimmed.match(/streamable\.com\/(?:e\/)?([a-zA-Z0-9]+)/i);
      if (streamableMatch && streamableMatch[1]) {
        const videoId = streamableMatch[1];
        return {
          type: 'streamable',
          rawUrl: trimmed,
          videoId,
          embedUrl: `https://streamable.com/e/${videoId}?autoplay=1&nocontrols=1`,
          isIframe: true
        };
      }
    }
  } catch {}

  // 4. Google Drive
  // Match drive.google.com/file/d/ID or drive.google.com/open?id=ID
  try {
    if (trimmed.includes('drive.google.com')) {
      const gdriveMatch = trimmed.match(
        /drive\.google\.com\/(?:file\/d\/|open\?id=|uc\?id=)([a-zA-Z0-9_-]+)/i
      );
      if (gdriveMatch && gdriveMatch[1]) {
        const fileId = gdriveMatch[1];
        return {
          type: 'google_drive',
          rawUrl: trimmed,
          videoId: fileId,
          directUrl: `https://drive.google.com/uc?export=download&id=${fileId}`,
          embedUrl: `https://drive.google.com/file/d/${fileId}/preview`,
          isIframe: true
        };
      }
    }
  } catch {}

  // 5. Loom
  // Match loom.com/share/ID
  try {
    if (trimmed.includes('loom.com')) {
      const loomMatch = trimmed.match(/loom\.com\/(?:share|embed)\/([a-zA-Z0-9_-]+)/i);
      if (loomMatch && loomMatch[1]) {
        const videoId = loomMatch[1];
        return {
          type: 'loom',
          rawUrl: trimmed,
          videoId,
          embedUrl: `https://www.loom.com/embed/${videoId}?autoplay=1&hide_owner=true&hide_share=true&hide_title=true`,
          isIframe: true
        };
      }
    }
  } catch {}

  // 6. Dailymotion
  // Match dailymotion.com/video/ID or dai.ly/ID
  try {
    if (trimmed.includes('dailymotion.com') || trimmed.includes('dai.ly')) {
      const dmMatch = trimmed.match(/(?:dailymotion\.com\/(?:video|embed\/video)\/|dai\.ly\/)([a-zA-Z0-9]+)/i);
      if (dmMatch && dmMatch[1]) {
        const videoId = dmMatch[1];
        return {
          type: 'dailymotion',
          rawUrl: trimmed,
          videoId,
          embedUrl: `https://www.dailymotion.com/embed/video/${videoId}?autoplay=1&mute=0&controls=0&ui-logo=0`,
          isIframe: true
        };
      }
    }
  } catch {}

  // 7. Twitch Clips
  try {
    if (trimmed.includes('clips.twitch.tv') || trimmed.includes('twitch.tv')) {
      const clipMatch = trimmed.match(/(?:clips\.twitch\.tv\/|twitch\.tv\/[^/]+\/clip\/)([a-zA-Z0-9_-]+)/i);
      if (clipMatch && clipMatch[1]) {
        const clipId = clipMatch[1];
        const hostname = typeof window !== 'undefined' ? window.location.hostname : 'localhost';
        return {
          type: 'twitch',
          rawUrl: trimmed,
          videoId: clipId,
          embedUrl: `https://clips.twitch.tv/embed?clip=${clipId}&parent=${hostname}&autoplay=true`,
          isIframe: true
        };
      }
    }
  } catch {}

  // 8. Dropbox
  // Replace dl=0 with raw=1 for direct streaming in native HTML5 <video>
  if (trimmed.includes('dropbox.com')) {
    const directDropbox = trimmed
      .replace(/[?&]dl=0/g, '')
      .replace(/[?&]dl=1/g, '') + (trimmed.includes('?') ? '&raw=1' : '?raw=1');
    return {
      type: 'direct',
      rawUrl: trimmed,
      directUrl: directDropbox,
      isIframe: false,
      format: 'video/mp4'
    };
  }

  // 9. Imgur (gifv -> mp4, or direct image link -> mp4)
  if (trimmed.includes('imgur.com')) {
    if (trimmed.endsWith('.gifv')) {
      return {
        type: 'direct',
        rawUrl: trimmed,
        directUrl: trimmed.replace('.gifv', '.mp4'),
        isIframe: false,
        format: 'video/mp4'
      };
    }
    const imgurMatch = trimmed.match(/imgur\.com\/(?:gallery\/)?([a-zA-Z0-9]+)/i);
    if (imgurMatch && imgurMatch[1] && !trimmed.endsWith('.jpg') && !trimmed.endsWith('.png')) {
      return {
        type: 'direct',
        rawUrl: trimmed,
        directUrl: `https://i.imgur.com/${imgurMatch[1]}.mp4`,
        isIframe: false,
        format: 'video/mp4'
      };
    }
  }

  // 10. Giphy (gif page -> mp4)
  if (trimmed.includes('giphy.com')) {
    const giphyMatch = trimmed.match(/giphy\.com\/gifs\/(?:.*-)?([a-zA-Z0-9]+)$/i);
    if (giphyMatch && giphyMatch[1]) {
      return {
        type: 'direct',
        rawUrl: trimmed,
        directUrl: `https://media.giphy.com/media/${giphyMatch[1]}/giphy.mp4`,
        isIframe: false,
        format: 'video/mp4'
      };
    }
  }

  // 11. Determine format for direct video files
  let format: string | undefined;
  const lowerUrl = trimmed.toLowerCase();
  if (lowerUrl.includes('.webm')) {
    format = 'video/webm';
  } else if (lowerUrl.includes('.mp4') || lowerUrl.includes('.m4v')) {
    format = 'video/mp4';
  } else if (lowerUrl.includes('.mov')) {
    format = 'video/quicktime';
  } else if (lowerUrl.includes('.ogg') || lowerUrl.includes('.ogv')) {
    format = 'video/ogg';
  } else if (lowerUrl.startsWith('data:video/')) {
    const match = lowerUrl.match(/^data:(video\/[^;]+);/);
    if (match) format = match[1];
  }

  // 12. Generic Direct Video File (MP4, WebM, MOV, Ogg, M4V, Blob, Data URL, Discord CDN, S3, Supabase, Cloudinary)
  return {
    type: 'direct',
    rawUrl: trimmed,
    directUrl: trimmed,
    isIframe: false,
    format
  };
}
