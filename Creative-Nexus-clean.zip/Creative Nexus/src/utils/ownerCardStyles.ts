export interface AccentColorConfig {
  id: string;
  nameAr: string;
  nameEn: string;
  hex: string;
  borderClass: string;
  hoverBorderClass: string;
  shadowClass: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  textGradient: string;
  avatarBorder: string;
  initialsBg: string;
}

export const ACCENT_COLOR_MAP: Record<string, AccentColorConfig> = {
  amber: {
    id: 'amber',
    nameAr: 'ذهبي ملكي',
    nameEn: 'Royal Gold',
    hex: '#f59e0b',
    borderClass: 'border-amber-500/40',
    hoverBorderClass: 'hover:border-amber-400/90',
    shadowClass: 'hover:shadow-[0_8px_30px_rgba(245,158,11,0.22)]',
    badgeBg: 'bg-amber-950/70',
    badgeText: 'text-amber-300',
    badgeBorder: 'border-amber-500/40',
    textGradient: 'from-amber-200 via-yellow-100 to-amber-400',
    avatarBorder: 'border-amber-500/40 text-amber-200 group-hover:border-amber-400/70',
    initialsBg: 'from-amber-950/40 to-slate-900',
  },
  emerald: {
    id: 'emerald',
    nameAr: 'زمردي ناصع',
    nameEn: 'Emerald Green',
    hex: '#10b981',
    borderClass: 'border-emerald-500/40',
    hoverBorderClass: 'hover:border-emerald-400/90',
    shadowClass: 'hover:shadow-[0_8px_30px_rgba(16,185,129,0.22)]',
    badgeBg: 'bg-emerald-950/70',
    badgeText: 'text-emerald-300',
    badgeBorder: 'border-emerald-500/40',
    textGradient: 'from-emerald-200 via-teal-100 to-emerald-400',
    avatarBorder: 'border-emerald-500/40 text-emerald-200 group-hover:border-emerald-400/70',
    initialsBg: 'from-emerald-950/40 to-slate-900',
  },
  rose: {
    id: 'rose',
    nameAr: 'وردي مخملي',
    nameEn: 'Velvet Rose',
    hex: '#f43f5e',
    borderClass: 'border-rose-500/40',
    hoverBorderClass: 'hover:border-rose-400/90',
    shadowClass: 'hover:shadow-[0_8px_30px_rgba(244,63,94,0.22)]',
    badgeBg: 'bg-rose-950/70',
    badgeText: 'text-rose-300',
    badgeBorder: 'border-rose-500/40',
    textGradient: 'from-rose-200 via-pink-100 to-rose-400',
    avatarBorder: 'border-rose-500/40 text-rose-200 group-hover:border-rose-400/70',
    initialsBg: 'from-rose-950/40 to-slate-900',
  },
  cyan: {
    id: 'cyan',
    nameAr: 'فيروزي جليدي',
    nameEn: 'Arctic Cyan',
    hex: '#06b6d4',
    borderClass: 'border-cyan-500/40',
    hoverBorderClass: 'hover:border-cyan-400/90',
    shadowClass: 'hover:shadow-[0_8px_30px_rgba(6,182,212,0.22)]',
    badgeBg: 'bg-cyan-950/70',
    badgeText: 'text-cyan-300',
    badgeBorder: 'border-cyan-500/40',
    textGradient: 'from-cyan-200 via-teal-100 to-cyan-400',
    avatarBorder: 'border-cyan-500/40 text-cyan-200 group-hover:border-cyan-400/70',
    initialsBg: 'from-cyan-950/40 to-slate-900',
  },
  purple: {
    id: 'purple',
    nameAr: 'بنفسجي أرجواني',
    nameEn: 'Royal Purple',
    hex: '#a855f7',
    borderClass: 'border-purple-500/40',
    hoverBorderClass: 'hover:border-purple-400/90',
    shadowClass: 'hover:shadow-[0_8px_30px_rgba(168,85,247,0.22)]',
    badgeBg: 'bg-purple-950/70',
    badgeText: 'text-purple-300',
    badgeBorder: 'border-purple-500/40',
    textGradient: 'from-purple-200 via-fuchsia-100 to-purple-400',
    avatarBorder: 'border-purple-500/40 text-purple-200 group-hover:border-purple-400/70',
    initialsBg: 'from-purple-950/40 to-slate-900',
  },
  red: {
    id: 'red',
    nameAr: 'أحمر قرمزي',
    nameEn: 'Crimson Red',
    hex: '#ef4444',
    borderClass: 'border-red-500/40',
    hoverBorderClass: 'hover:border-red-400/90',
    shadowClass: 'hover:shadow-[0_8px_30px_rgba(239,68,68,0.22)]',
    badgeBg: 'bg-red-950/70',
    badgeText: 'text-red-300',
    badgeBorder: 'border-red-500/40',
    textGradient: 'from-red-200 via-rose-100 to-red-400',
    avatarBorder: 'border-red-500/40 text-red-200 group-hover:border-red-400/70',
    initialsBg: 'from-red-950/40 to-slate-900',
  },
  orange: {
    id: 'orange',
    nameAr: 'شعلة نارية',
    nameEn: 'Blaze Orange',
    hex: '#f97316',
    borderClass: 'border-orange-500/40',
    hoverBorderClass: 'hover:border-orange-400/90',
    shadowClass: 'hover:shadow-[0_8px_30px_rgba(249,115,22,0.22)]',
    badgeBg: 'bg-orange-950/70',
    badgeText: 'text-orange-300',
    badgeBorder: 'border-orange-500/40',
    textGradient: 'from-orange-200 via-amber-100 to-orange-400',
    avatarBorder: 'border-orange-500/40 text-orange-200 group-hover:border-orange-400/70',
    initialsBg: 'from-orange-950/40 to-slate-900',
  },
  yellow: {
    id: 'yellow',
    nameAr: 'شمس ساطعة',
    nameEn: 'Solar Honey',
    hex: '#eab308',
    borderClass: 'border-yellow-500/40',
    hoverBorderClass: 'hover:border-yellow-400/90',
    shadowClass: 'hover:shadow-[0_8px_30px_rgba(234,179,8,0.22)]',
    badgeBg: 'bg-yellow-950/70',
    badgeText: 'text-yellow-300',
    badgeBorder: 'border-yellow-500/40',
    textGradient: 'from-yellow-200 via-amber-100 to-yellow-400',
    avatarBorder: 'border-yellow-500/40 text-yellow-200 group-hover:border-yellow-400/70',
    initialsBg: 'from-yellow-950/40 to-slate-900',
  },
  blue: {
    id: 'blue',
    nameAr: 'أزرق ملكي',
    nameEn: 'Sapphire Blue',
    hex: '#3b82f6',
    borderClass: 'border-blue-500/40',
    hoverBorderClass: 'hover:border-blue-400/90',
    shadowClass: 'hover:shadow-[0_8px_30px_rgba(59,130,246,0.22)]',
    badgeBg: 'bg-blue-950/70',
    badgeText: 'text-blue-300',
    badgeBorder: 'border-blue-500/40',
    textGradient: 'from-blue-200 via-sky-100 to-blue-400',
    avatarBorder: 'border-blue-500/40 text-blue-200 group-hover:border-blue-400/70',
    initialsBg: 'from-blue-950/40 to-slate-900',
  },
  amethyst: {
    id: 'amethyst',
    nameAr: 'جمشت بلوري',
    nameEn: 'Crystal Amethyst',
    hex: '#8b5cf6',
    borderClass: 'border-violet-500/40',
    hoverBorderClass: 'hover:border-violet-400/90',
    shadowClass: 'hover:shadow-[0_8px_30px_rgba(139,92,246,0.25)]',
    badgeBg: 'bg-violet-950/70',
    badgeText: 'text-violet-300',
    badgeBorder: 'border-violet-500/40',
    textGradient: 'from-violet-200 via-fuchsia-100 to-purple-400',
    avatarBorder: 'border-violet-500/40 text-violet-200 group-hover:border-violet-400/70',
    initialsBg: 'from-violet-950/40 to-slate-900',
  },
  mint: {
    id: 'mint',
    nameAr: 'نعناع سماوي',
    nameEn: 'Celestial Mint',
    hex: '#2dd4bf',
    borderClass: 'border-teal-400/40',
    hoverBorderClass: 'hover:border-teal-300/90',
    shadowClass: 'hover:shadow-[0_8px_30px_rgba(45,212,191,0.25)]',
    badgeBg: 'bg-teal-950/70',
    badgeText: 'text-teal-300',
    badgeBorder: 'border-teal-400/40',
    textGradient: 'from-teal-200 via-emerald-100 to-teal-400',
    avatarBorder: 'border-teal-400/40 text-teal-200 group-hover:border-teal-300/70',
    initialsBg: 'from-teal-950/40 to-slate-900',
  },
  platinum: {
    id: 'platinum',
    nameAr: 'بلاتينوم فضي',
    nameEn: 'Silver Platinum',
    hex: '#e2e8f0',
    borderClass: 'border-slate-300/40',
    hoverBorderClass: 'hover:border-slate-200/90',
    shadowClass: 'hover:shadow-[0_8px_30px_rgba(226,232,240,0.25)]',
    badgeBg: 'bg-slate-900/80',
    badgeText: 'text-slate-200',
    badgeBorder: 'border-slate-300/40',
    textGradient: 'from-white via-slate-100 to-slate-300',
    avatarBorder: 'border-slate-300/40 text-white group-hover:border-slate-200/70',
    initialsBg: 'from-slate-800 to-slate-950',
  }
};

export function getAccentColor(colorId?: string): AccentColorConfig {
  if (!colorId) return ACCENT_COLOR_MAP.amber;
  return ACCENT_COLOR_MAP[colorId] || ACCENT_COLOR_MAP.amber;
}

export function toRomanNumeral(num: number): string {
  if (num <= 0) return 'I';
  const romanMap: [number, string][] = [
    [1000, 'M'], [900, 'CM'], [500, 'D'], [400, 'CD'],
    [100, 'C'], [90, 'XC'], [50, 'L'], [40, 'XL'],
    [10, 'X'], [9, 'IX'], [5, 'V'], [4, 'IV'], [1, 'I']
  ];
  let result = '';
  let n = Math.floor(num);
  for (const [val, sym] of romanMap) {
    while (n >= val) {
      result += sym;
      n -= val;
    }
  }
  return result || String(num);
}

