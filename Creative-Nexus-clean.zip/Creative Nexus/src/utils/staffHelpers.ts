import { StaffRank, StaffStatus } from '../types/staff';

export interface RankBadgeConfig {
  label: string;
  labelAr: string;
  bgClass: string;
  textClass: string;
  borderClass: string;
  glowClass: string;
  dotClass: string;
  gradientClass: string;
}

export function getRankBadgeConfig(rank: StaffRank): RankBadgeConfig {
  switch (rank) {
    case 'SUPER_ADMIN':
      return {
        label: 'Super Admin',
        labelAr: 'إدارة عليا',
        bgClass: 'bg-amber-500/10',
        textClass: 'text-amber-400',
        borderClass: 'border-amber-500/30',
        glowClass: 'shadow-amber-500/20',
        dotClass: 'bg-amber-400',
        gradientClass: 'from-amber-500/20 to-rose-500/20'
      };
    case 'SENIOR_ADMINISTRATOR':
      return {
        label: 'Senior Administrator',
        labelAr: 'مسؤول أول',
        bgClass: 'bg-purple-500/10',
        textClass: 'text-purple-400',
        borderClass: 'border-purple-500/30',
        glowClass: 'shadow-purple-500/20',
        dotClass: 'bg-purple-400',
        gradientClass: 'from-purple-500/20 to-indigo-500/20'
      };
    case 'ADMINISTRATOR':
      return {
        label: 'Administrator',
        labelAr: 'مسؤول إدارة',
        bgClass: 'bg-indigo-500/10',
        textClass: 'text-indigo-400',
        borderClass: 'border-indigo-500/30',
        glowClass: 'shadow-indigo-500/20',
        dotClass: 'bg-indigo-400',
        gradientClass: 'from-indigo-500/20 to-blue-500/20'
      };
    case 'SENIOR_MODERATOR':
      return {
        label: 'Senior Moderator',
        labelAr: 'مشرف أول',
        bgClass: 'bg-cyan-500/10',
        textClass: 'text-cyan-400',
        borderClass: 'border-cyan-500/30',
        glowClass: 'shadow-cyan-500/20',
        dotClass: 'bg-cyan-400',
        gradientClass: 'from-cyan-500/20 to-teal-500/20'
      };
    case 'MODERATOR':
    default:
      return {
        label: 'Moderator',
        labelAr: 'مشرف',
        bgClass: 'bg-emerald-500/10',
        textClass: 'text-emerald-400',
        borderClass: 'border-emerald-500/30',
        glowClass: 'shadow-emerald-500/20',
        dotClass: 'bg-emerald-400',
        gradientClass: 'from-emerald-500/20 to-teal-500/20'
      };
  }
}

export function getStatusBadgeConfig(status: StaffStatus) {
  switch (status) {
    case 'ACTIVE':
      return {
        label: 'Active',
        labelAr: 'نشط',
        bgClass: 'bg-emerald-500/10',
        textClass: 'text-emerald-400',
        borderClass: 'border-emerald-500/25',
        dotClass: 'bg-emerald-400'
      };
    case 'SUSPENDED':
      return {
        label: 'Suspended',
        labelAr: 'موقوف مؤقتاً',
        bgClass: 'bg-rose-500/10',
        textClass: 'text-rose-400',
        borderClass: 'border-rose-500/25',
        dotClass: 'bg-rose-400'
      };
    case 'REMOVED':
    default:
      return {
        label: 'Removed',
        labelAr: 'مستبعد',
        bgClass: 'bg-slate-500/10',
        textClass: 'text-slate-400',
        borderClass: 'border-slate-500/25',
        dotClass: 'bg-slate-400'
      };
  }
}

export function formatRelativeTime(dateString: string, isAr: boolean = false): string {
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return isAr ? 'غير معروف' : 'Unknown';
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffInSeconds < 60) {
      return isAr ? 'الآن' : 'Just now';
    }
    const diffInMinutes = Math.floor(diffInSeconds / 60);
    if (diffInMinutes < 60) {
      return isAr ? `منذ ${diffInMinutes} دقيقة` : `${diffInMinutes}m ago`;
    }
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) {
      return isAr ? `منذ ${diffInHours} ساعة` : `${diffInHours}h ago`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 30) {
      return isAr ? `منذ ${diffInDays} يوم` : `${diffInDays}d ago`;
    }
    return date.toLocaleDateString(isAr ? 'ar-EG' : 'en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  } catch {
    return isAr ? 'غير معروف' : 'Unknown';
  }
}
