import { AuditEventType, AuditEventCategory } from '../types/auditLog';

// Persistent visitor ID for anonymous guest tracking
const VISITOR_ID_KEY = 'cn_visitor_id';

export function getOrCreateVisitorId(): string {
  try {
    let id = localStorage.getItem(VISITOR_ID_KEY);
    if (!id || id.length < 8) {
      const rand = Math.random().toString(36).substring(2, 10);
      const time = Date.now().toString(36);
      id = `v_${time}_${rand}`;
      localStorage.setItem(VISITOR_ID_KEY, id);
    }
    // Also sync cookie for server awareness
    document.cookie = `cn_visitor_id=${id}; path=/; max-age=31536000; SameSite=Lax`;
    return id;
  } catch {
    return 'v_unknown';
  }
}

export interface TrackEventOptions {
  eventType?: AuditEventType;
  category?: AuditEventCategory | string;
  path?: string;
  targetElement?: string;
  details?: Record<string, any> | string;
}

// Queue / debounce state to prevent telemetry storms
let lastSentAction = '';
let lastSentTime = 0;

/**
 * Send an audit telemetry event to the backend
 */
export async function trackEvent(
  action: string,
  options: TrackEventOptions = {}
): Promise<void> {
  const now = Date.now();
  // Prevent duplicate events within 500ms
  if (action === lastSentAction && now - lastSentTime < 500) {
    return;
  }
  lastSentAction = action;
  lastSentTime = now;

  try {
    const visitorId = getOrCreateVisitorId();
    const currentPath = options.path || window.location.pathname;

    // Use sendBeacon if available for unload/background resilience, otherwise fetch
    const payload = JSON.stringify({
      action: action.slice(0, 300),
      eventType: options.eventType || 'INTERACTION',
      category: options.category || 'UI',
      path: currentPath,
      targetElement: options.targetElement?.slice(0, 200),
      details: options.details,
      visitorId
    });

    if (typeof navigator !== 'undefined' && typeof navigator.sendBeacon === 'function' && options.eventType === 'AUTH_LOGOUT') {
      const blob = new Blob([payload], { type: 'application/json' });
      navigator.sendBeacon('/api/audit-log/event', blob);
      return;
    }

    await fetch('/api/audit-log/event', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      credentials: 'include',
      body: payload
    });
  } catch (err) {
    // Silent fail - analytics must never crash the UI
  }
}

/**
 * Track route / page transitions
 */
export function trackPageView(pathname: string): void {
  const friendlyNames: Record<string, string> = {
    '/': 'Home Archive',
    '/announcements': 'Announcements Board',
    '/history': 'Community History',
    '/codex': 'Administrative Codex',
    '/guidebook': 'Administrative Codex',
    '/server-dashboard': 'Live Server Dashboard',
    '/settings': 'Platform Settings',
    '/staff-management': 'Staff Management Roster',
    '/rank-points': 'Rank Points & Promotions',
    '/achievements': 'Community Achievements',
    '/classified-archive': 'Secret Classified Archive',
    '/audit-log': 'Owner Audit Log'
  };

  const name = friendlyNames[pathname] || `Page ${pathname}`;
  trackEvent(`Visited ${name} (${pathname})`, {
    eventType: 'PAGE_VIEW',
    category: 'NAVIGATION',
    path: pathname,
    targetElement: `Route: ${pathname}`
  });
}

/**
 * Initialize global click listener to automatically log user interactions
 */
let isListenerInitialized = false;

export function initGlobalClickTracker(): () => void {
  if (isListenerInitialized || typeof window === 'undefined') {
    return () => {};
  }
  isListenerInitialized = true;

  // Make sure visitor ID exists on boot
  getOrCreateVisitorId();

  const clickHandler = (event: MouseEvent) => {
    try {
      const target = event.target as HTMLElement | null;
      if (!target) return;

      // Find closest interactive element
      const interactiveEl = target.closest<HTMLElement>(
        'button, a, [role="button"], input[type="button"], input[type="submit"], [data-audit-action]'
      );

      if (!interactiveEl) return;

      // Explicit custom audit action attribute
      const customAction = interactiveEl.getAttribute('data-audit-action');
      if (customAction) {
        trackEvent(customAction, {
          eventType: 'CLICK',
          category: 'UI',
          targetElement: interactiveEl.tagName.toLowerCase()
        });
        return;
      }

      // Determine human-readable label
      const explicitLabel = 
        interactiveEl.getAttribute('aria-label') ||
        interactiveEl.getAttribute('title') ||
        interactiveEl.getAttribute('data-title');

      let innerText = (interactiveEl.innerText || interactiveEl.textContent || '').trim();
      // Clean up text if too long (e.g. nested lists)
      if (innerText.length > 50) {
        innerText = innerText.substring(0, 47) + '...';
      }

      const tagName = interactiveEl.tagName.toLowerCase();
      const href = interactiveEl.getAttribute('href');
      const elementId = interactiveEl.id ? `#${interactiveEl.id}` : '';

      const label = explicitLabel || innerText || href || elementId || tagName;

      // Ignore empty or whitespace-only labels
      if (!label || label.length < 2) return;

      // Ignore password fields or sensitive typing targets
      if (interactiveEl instanceof HTMLInputElement && interactiveEl.type === 'password') {
        return;
      }

      let actionDesc = '';
      if (tagName === 'a') {
        actionDesc = `Clicked link: "${label}"${href ? ` -> ${href}` : ''}`;
      } else if (tagName === 'button' || interactiveEl.getAttribute('role') === 'button') {
        actionDesc = `Clicked button: "${label}"`;
      } else {
        actionDesc = `Interacted with ${tagName}: "${label}"`;
      }

      trackEvent(actionDesc, {
        eventType: 'CLICK',
        category: 'UI',
        targetElement: `${tagName}${elementId ? ` (${elementId})` : ''}: ${label}`
      });
    } catch {
      // Ignore click tracking exceptions
    }
  };

  document.addEventListener('click', clickHandler, { passive: true, capture: true });

  return () => {
    document.removeEventListener('click', clickHandler, { capture: true });
    isListenerInitialized = false;
  };
}
