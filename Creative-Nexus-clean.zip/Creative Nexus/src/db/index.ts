import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from './schema';

let poolConfig: any = {};

if (process.env.SQL_HOST) {
  poolConfig = {
    user: process.env.SQL_USER,
    password: process.env.SQL_PASSWORD,
    database: process.env.SQL_DB_NAME,
    host: process.env.SQL_HOST,
  };
} else if (process.env.DATABASE_URL && process.env.DATABASE_URL.startsWith('postgres') && !process.env.DATABASE_URL.includes('user:password@host:port')) {
  poolConfig = { connectionString: process.env.DATABASE_URL };
} else {
  // Mock fallback to prevent connection hanging when DB is unconfigured
  poolConfig = {};
}

// Only connect if we have a valid configuration, else create a dummy pool that immediately fails or just let drizzle use a disconnected pool
const pool = new Pool(Object.keys(poolConfig).length > 0 ? poolConfig : undefined);

// Defensively handle pool errors so background connection drops do not crash the Node process
pool.on('error', (err) => {
  console.warn('Database pool background notice (handled):', err?.message);
});

// Wrap db in a proxy to safely ignore queries when database is unconfigured
const rawDb = drizzle(pool, { schema });

const createMockChain = (): any => {
  const chain = new Proxy(() => {}, {
    get: (target, prop) => {
      if (prop === 'then') {
        return (resolve: any) => resolve([]);
      }
      if (prop === 'catch') {
        return (reject: any) => chain;
      }
      return chain;
    },
    apply: () => chain
  });
  return chain;
};

export const db = new Proxy(rawDb, {
  get: (target, prop) => {
    if (Object.keys(poolConfig).length === 0) {
      // Mock drizzle object methods when DB is unconfigured
      if (prop === 'insert' || prop === 'select' || prop === 'update' || prop === 'delete' || prop === 'query') {
        return createMockChain();
      }
    }
    return target[prop as keyof typeof target];
  }
}) as any;
