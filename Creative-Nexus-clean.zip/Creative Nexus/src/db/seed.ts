import { db } from './index';
import { staff, staffHistory } from './schema';

async function seed() {
  console.log('Database ready. No demo staff seeded.');
  process.exit(0);
}

seed().catch(err => {
  console.error('Seed failed:', err);
  process.exit(1);
});
