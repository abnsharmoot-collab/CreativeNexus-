import { defineConfig } from 'drizzle-kit';

export default defineConfig({
  schema: './src/db/schema.ts',
  out: './drizzle',
  dialect: 'postgresql',
  dbCredentials: {
    user: process.env.SQL_ADMIN_USER || 'ai_studio_admin',
    password: process.env.SQL_ADMIN_PASSWORD || 'HMIaJ5x^Fjg_9qg(',
    database: process.env.SQL_DB_NAME || 'cloud_sql_development_database',
    host: process.env.SQL_HOST || '/app/cloudsql/fine-tuner-zlkcn:europe-west3:ai-studio-8df6a314'
  },
});
