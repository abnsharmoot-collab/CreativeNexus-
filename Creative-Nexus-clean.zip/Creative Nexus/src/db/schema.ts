import { pgTable, serial, text, integer, timestamp, varchar, pgEnum } from 'drizzle-orm/pg-core';

export const rankEnum = pgEnum('staff_rank', [
  'MODERATOR',
  'SENIOR_MODERATOR',
  'ADMINISTRATOR',
  'SENIOR_ADMINISTRATOR',
  'SUPER_ADMIN'
]);

export const statusEnum = pgEnum('staff_status', [
  'ACTIVE',
  'SUSPENDED',
  'REMOVED'
]);

export const actionEnum = pgEnum('history_action', [
  'STAFF_ADDED',
  'STAFF_EDITED',
  'PROMOTED',
  'DEMOTED',
  'SUSPENDED',
  'REACTIVATED',
  'REMOVED',
  'POINTS_CHANGED'
]);

export const staff = pgTable('staff', {
  id: serial('id').primaryKey(),
  discordId: varchar('discord_id', { length: 255 }).notNull().unique(),
  username: varchar('username', { length: 255 }).notNull(),
  displayName: varchar('display_name', { length: 255 }).notNull(),
  avatarUrl: text('avatar_url').notNull(),
  rank: rankEnum('rank').notNull().default('MODERATOR'),
  points: integer('points').notNull().default(0),
  status: statusEnum('status').notNull().default('ACTIVE'),
  notes: text('notes'),
  joinedAt: timestamp('joined_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow()
});

export const staffHistory = pgTable('staff_history', {
  id: serial('id').primaryKey(),
  staffId: integer('staff_id').references(() => staff.id).notNull(),
  action: actionEnum('action').notNull(),
  description: text('description').notNull(),
  performedBy: varchar('performed_by', { length: 255 }).notNull().default('SYSTEM'),
  createdAt: timestamp('created_at').notNull().defaultNow()
});

export const pointTransactionTypeEnum = pgEnum('point_transaction_type', [
  'ADD',
  'REMOVE'
]);

export const staffPointTransaction = pgTable('staff_point_transaction', {
  id: serial('id').primaryKey(),
  staffId: integer('staff_id').references(() => staff.id).notNull(),
  amount: integer('amount').notNull(),
  type: pointTransactionTypeEnum('type').notNull(),
  reason: text('reason').notNull(),
  note: text('note'),
  performedBy: varchar('performed_by', { length: 255 }).notNull().default('SYSTEM'),
  createdAt: timestamp('created_at').notNull().defaultNow()
});

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  discordId: varchar('discord_id', { length: 255 }).notNull().unique(),
  username: varchar('username', { length: 255 }).notNull(),
  displayName: varchar('display_name', { length: 255 }),
  avatar: text('avatar'),
  avatarUrl: text('avatar_url'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
  lastLoginAt: timestamp('last_login_at').notNull().defaultNow()
});

export const serverConfig = pgTable('server_config', {
  id: serial('id').primaryKey(),
  key: varchar('key', { length: 255 }).notNull().unique(),
  value: text('value').notNull(),
  updatedBy: varchar('updated_by', { length: 255 }),
  updatedAt: timestamp('updated_at').notNull().defaultNow()
});

export type DbUser = typeof users.$inferSelect;
export type NewDbUser = typeof users.$inferInsert;
export type DbServerConfig = typeof serverConfig.$inferSelect;
export type NewDbServerConfig = typeof serverConfig.$inferInsert;

