export type CombatActionType = 'STRIKE' | 'HEAVY' | 'DEFENSE' | 'SKILL';

export type CombatOutcomeType = 
  | 'CLASH' 
  | 'HEAVY_CLASH' 
  | 'INTERRUPTED' 
  | 'BLOCKED' 
  | 'GUARD_BREAK' 
  | 'STANDOFF' 
  | 'SKILL_HIT' 
  | 'SKILL_INTERRUPTED'
  | 'SKILL_BLOCKED';

export interface ActionSettingItem {
  damage: number;
  staminaCost: number;
  energyDelta: number; // positive = gain, negative = consume
  startupSeconds: number;
  recoverySeconds: number;
  speedMultiplier: number;
  critChance?: number;
  guardBreakPower?: number;
  staggerDurationSeconds?: number;
  strikeDamageReduction?: number; // for DEFENSE (e.g. 0.90 = 90%)
  heavyDamageReduction?: number;  // for DEFENSE (e.g. 0.35 = 35%)
  counterWindowSeconds?: number;  // for DEFENSE (e.g. 0.5s)
  counterBonusDamage?: number;    // bonus damage during counter (e.g. 20)
  standoffStaminaRecovery?: number; // stamina gained during DEFENSE vs DEFENSE
}

export interface MatchupCellRule {
  winner: 'PLAYER' | 'OPPONENT' | 'TIE';
  result: CombatOutcomeType;
  bannerText: string;
  bannerTextAr: string;
  playerDamageMultiplier: number;
  opponentDamageMultiplier: number;
  playerStagger: boolean;
  opponentStagger: boolean;
  guardBreak: boolean;
  counterWindowGranted: 'PLAYER' | 'OPPONENT' | 'NONE';
  staminaRecoveryPlayer?: number;
  staminaRecoveryOpponent?: number;
}

export type MatchupMatrix = Record<`${CombatActionType}_vs_${CombatActionType}`, MatchupCellRule>;

export interface CombatSkillDefinition {
  id: string;
  name: string;
  nameAr?: string;
  description: string;
  descriptionAr?: string;
  icon: string;
  type: 'buff' | 'attack' | 'defense' | 'heal' | 'special';
  category: 'BERSERKER' | 'ASSASSIN' | 'GUARDIAN' | 'MAGE' | 'VAMPIRE' | 'UNIVERSAL';
  rarity: 'COMMON' | 'RARE' | 'EPIC' | 'LEGENDARY';
  damage: number;
  healing: number;
  shield: number;
  staminaCost: number;
  energyCost: number;
  cooldown: number;
  duration: number;
  priority: 0 | 1 | 2 | 3; // 0=Normal, 1=Fast, 2=Special, 3=Ultimate
  startupSeconds: number;
  recoverySeconds: number;
  interruptible: boolean;
  effects: {
    stun?: boolean;
    stagger?: boolean;
    guardBreak?: boolean;
    counter?: boolean;
    dodge?: boolean;
    heal?: boolean;
    lifesteal?: boolean;
    buff?: boolean;
    debuff?: boolean;
    dot?: boolean;
    energyDrain?: boolean;
    staminaDrain?: boolean;
    heavyDamageMultiplier?: number;
  };
  matchupRules: {
    vsStrike: 'interrupted' | 'absorb' | 'clash' | 'independent';
    vsHeavy: 'interrupt_heavy' | 'penetrated' | 'clash' | 'independent' | 'absorb' | 'reduced_50';
    vsDefense: 'guard_break' | 'reduced_50' | 'blocked' | 'independent';
    vsSkill: 'priority_compare' | 'both_resolve';
  };
  animation: string;
  sound: string;
}

export interface CombatRulesConfig {
  presetName: 'Classic' | 'Fast Combat' | 'Hardcore' | 'High Damage' | 'Defensive' | 'Custom';
  actions: {
    STRIKE: ActionSettingItem;
    HEAVY: ActionSettingItem;
    DEFENSE: ActionSettingItem;
  };
  matchupMatrix: MatchupMatrix;
  skills: CombatSkillDefinition[];
  staminaConfig: {
    maxStamina: number;
    staminaRegenPerTurn: number;
    exhaustionThreshold: number; // usually 0
    exhaustionPenaltyStrikeReduction: number; // 0.20 = -20% damage
    exhaustionDisablesHeavy: boolean;
    exhaustionDefenseWeaknessMultiplier: number; // 0.30
  };
  energyConfig: {
    maxEnergy: number;
    strikeGain: number;
    heavyGain: number;
    defenseGain: number;
  };
  updatedAt: string;
  updatedBy?: string;
}

export interface CombatRoundRequest {
  playerAction: CombatActionType;
  playerSkillId?: string;
  opponentAction?: CombatActionType;
  opponentSkillId?: string;
  playerState: {
    hp: number;
    maxHp: number;
    stamina: number;
    maxStamina: number;
    energy: number;
    maxEnergy: number;
    isExhausted: boolean;
    activeSkillCooldowns: Record<string, number>;
    statusEffects?: string[];
  };
  opponentState: {
    hp: number;
    maxHp: number;
    stamina: number;
    maxStamina: number;
    energy: number;
    maxEnergy: number;
    isExhausted: boolean;
    activeSkillCooldowns: Record<string, number>;
    statusEffects?: string[];
  };
  presetOverride?: string;
}

export interface CombatRoundResult {
  playerAction: CombatActionType;
  opponentAction: CombatActionType;
  winner: 'player' | 'opponent' | 'tie';
  result: CombatOutcomeType;
  bannerTitle: string;
  bannerTitleAr: string;
  playerDamageTaken: number;
  opponentDamageTaken: number;
  playerDamageDealt: number;
  opponentDamageDealt: number;
  playerStaminaDelta: number;
  opponentStaminaDelta: number;
  playerEnergyDelta: number;
  opponentEnergyDelta: number;
  playerHpAfter: number;
  opponentHpAfter: number;
  playerStaminaAfter: number;
  opponentStaminaAfter: number;
  playerEnergyAfter: number;
  opponentEnergyAfter: number;
  playerExhaustedAfter: boolean;
  opponentExhaustedAfter: boolean;
  counterWindowActive: boolean;
  isPlayerStaggered: boolean;
  isOpponentStaggered: boolean;
  isPlayerGuardBroken: boolean;
  isOpponentGuardBroken: boolean;
  statusEffectsPlayer: string[];
  statusEffectsOpponent: string[];
  playerActiveCooldowns: Record<string, number>;
  opponentActiveCooldowns: Record<string, number>;
  battleLogText: string;
  battleLogTextAr: string;
  animationKey: string;
  soundKey: string;
}

// ----------------------------------------------------
// DEFAULT STRATEGIC COMBAT RULES
// ----------------------------------------------------
export const DEFAULT_COMBAT_SKILLS: CombatSkillDefinition[] = [
  {
    id: 'berserker_rage',
    name: 'Rage',
    nameAr: 'غضب هائج',
    description: 'Next Heavy deals +50% devastating damage.',
    descriptionAr: 'الضربة الثقيلة القادمة تلحق ضرراً إضافياً بنسبة 50%.',
    icon: 'Flame',
    type: 'buff',
    category: 'BERSERKER',
    rarity: 'RARE',
    damage: 0,
    healing: 0,
    shield: 0,
    staminaCost: 20,
    energyCost: 35,
    cooldown: 3,
    duration: 1,
    priority: 1,
    startupSeconds: 0.3,
    recoverySeconds: 0.3,
    interruptible: false,
    effects: {
      buff: true,
      heavyDamageMultiplier: 1.5
    },
    matchupRules: {
      vsStrike: 'absorb',
      vsHeavy: 'clash',
      vsDefense: 'guard_break',
      vsSkill: 'priority_compare'
    },
    animation: 'rage_activate',
    sound: 'ENERGY_SURGE'
  },
  {
    id: 'assassin_quickstep',
    name: 'Quickstep',
    nameAr: 'مراوغة خاطفة',
    description: 'Immediately dodge and evade the next incoming attack.',
    descriptionAr: 'تفادي فوري ومراوغة للهجوم القادم.',
    icon: 'Zap',
    type: 'defense',
    category: 'ASSASSIN',
    rarity: 'EPIC',
    damage: 0,
    healing: 0,
    shield: 20,
    staminaCost: 15,
    energyCost: 30,
    cooldown: 3,
    duration: 1,
    priority: 2,
    startupSeconds: 0.1,
    recoverySeconds: 0.2,
    interruptible: false,
    effects: {
      dodge: true
    },
    matchupRules: {
      vsStrike: 'absorb',
      vsHeavy: 'absorb',
      vsDefense: 'independent',
      vsSkill: 'priority_compare'
    },
    animation: 'quickstep_dodge',
    sound: 'FORMATION_SUMMON'
  },
  {
    id: 'guardian_fortify',
    name: 'Fortify',
    nameAr: 'تحصين حديدي',
    description: 'Reduce all incoming damage by 70% for one turn.',
    descriptionAr: 'تقليص كافة الأضرار القادمة بنسبة 70% لجولة كاملة.',
    icon: 'Shield',
    type: 'buff',
    category: 'GUARDIAN',
    rarity: 'RARE',
    damage: 0,
    healing: 0,
    shield: 40,
    staminaCost: 15,
    energyCost: 25,
    cooldown: 2,
    duration: 1,
    priority: 2,
    startupSeconds: 0.2,
    recoverySeconds: 0.4,
    interruptible: false,
    effects: {
      buff: true
    },
    matchupRules: {
      vsStrike: 'absorb',
      vsHeavy: 'reduced_50',
      vsDefense: 'independent',
      vsSkill: 'priority_compare'
    },
    animation: 'fortify_shield',
    sound: 'SHIELD_BLOCK'
  },
  {
    id: 'mage_arcane_blast',
    name: 'Arcane Blast',
    nameAr: 'انفجار سحري',
    description: 'Deals 25 direct arcane damage regardless of normal defense.',
    descriptionAr: 'يلحق 25 ضرراً سحرياً مباشراً متجاوزاً دفاع الخصم.',
    icon: 'Sparkles',
    type: 'attack',
    category: 'MAGE',
    rarity: 'LEGENDARY',
    damage: 25,
    healing: 0,
    shield: 0,
    staminaCost: 20,
    energyCost: 40,
    cooldown: 3,
    duration: 1,
    priority: 2,
    startupSeconds: 0.5,
    recoverySeconds: 0.5,
    interruptible: true,
    effects: {
      guardBreak: true
    },
    matchupRules: {
      vsStrike: 'interrupted',
      vsHeavy: 'interrupt_heavy',
      vsDefense: 'guard_break',
      vsSkill: 'priority_compare'
    },
    animation: 'arcane_burst',
    sound: 'ENERGY_SURGE'
  },
  {
    id: 'vampire_lifesteal',
    name: 'Lifesteal',
    nameAr: 'امتصاص الحياة',
    description: 'Deals 15 damage and heals user for 8 HP.',
    descriptionAr: 'يلحق 15 ضرراً بالخصم ويستعيد 8 نقاط صحة.',
    icon: 'Heart',
    type: 'heal',
    category: 'VAMPIRE',
    rarity: 'EPIC',
    damage: 15,
    healing: 8,
    shield: 0,
    staminaCost: 18,
    energyCost: 35,
    cooldown: 2,
    duration: 1,
    priority: 1,
    startupSeconds: 0.35,
    recoverySeconds: 0.4,
    interruptible: true,
    effects: {
      lifesteal: true,
      heal: true
    },
    matchupRules: {
      vsStrike: 'clash',
      vsHeavy: 'penetrated',
      vsDefense: 'reduced_50',
      vsSkill: 'priority_compare'
    },
    animation: 'vampire_drain',
    sound: 'TACTICAL_SELECT'
  }
];

export const DEFAULT_MATCHUP_MATRIX: MatchupMatrix = {
  // STRIKE
  STRIKE_vs_STRIKE: {
    winner: 'TIE',
    result: 'CLASH',
    bannerText: 'CLASH',
    bannerTextAr: 'اشتباك متكافئ',
    playerDamageMultiplier: 1.0,
    opponentDamageMultiplier: 1.0,
    playerStagger: false,
    opponentStagger: false,
    guardBreak: false,
    counterWindowGranted: 'NONE'
  },
  STRIKE_vs_HEAVY: {
    winner: 'PLAYER',
    result: 'INTERRUPTED',
    bannerText: 'INTERRUPTED',
    bannerTextAr: 'إلغاء هجوم الخصم!',
    playerDamageMultiplier: 1.0,
    opponentDamageMultiplier: 0,
    playerStagger: false,
    opponentStagger: true,
    guardBreak: false,
    counterWindowGranted: 'NONE'
  },
  STRIKE_vs_DEFENSE: {
    winner: 'OPPONENT',
    result: 'BLOCKED',
    bannerText: 'BLOCKED',
    bannerTextAr: 'صد دفاعي محكم',
    playerDamageMultiplier: 0.10, // 90% reduced = 1-2 dmg
    opponentDamageMultiplier: 0,
    playerStagger: true,
    opponentStagger: false,
    guardBreak: false,
    counterWindowGranted: 'OPPONENT'
  },
  STRIKE_vs_SKILL: {
    winner: 'PLAYER',
    result: 'SKILL_INTERRUPTED',
    bannerText: 'SKILL INTERRUPTED',
    bannerTextAr: 'قطع مهارة الخصم!',
    playerDamageMultiplier: 1.0,
    opponentDamageMultiplier: 0,
    playerStagger: false,
    opponentStagger: true,
    guardBreak: false,
    counterWindowGranted: 'NONE'
  },

  // HEAVY
  HEAVY_vs_STRIKE: {
    winner: 'OPPONENT',
    result: 'INTERRUPTED',
    bannerText: 'INTERRUPTED',
    bannerTextAr: 'تم قطع هجومك الثقيل!',
    playerDamageMultiplier: 0,
    opponentDamageMultiplier: 1.0,
    playerStagger: true,
    opponentStagger: false,
    guardBreak: false,
    counterWindowGranted: 'NONE'
  },
  HEAVY_vs_HEAVY: {
    winner: 'TIE',
    result: 'HEAVY_CLASH',
    bannerText: 'HEAVY CLASH',
    bannerTextAr: 'اصطدام ضربات ثقيلة!',
    playerDamageMultiplier: 1.0,
    opponentDamageMultiplier: 1.0,
    playerStagger: true,
    opponentStagger: true,
    guardBreak: false,
    counterWindowGranted: 'NONE'
  },
  HEAVY_vs_DEFENSE: {
    winner: 'PLAYER',
    result: 'GUARD_BREAK',
    bannerText: 'GUARD BREAK',
    bannerTextAr: 'تحطيم الدفاع!',
    playerDamageMultiplier: 0.65, // 35% reduction = ~19-20 dmg
    opponentDamageMultiplier: 0,
    playerStagger: false,
    opponentStagger: true,
    guardBreak: true,
    counterWindowGranted: 'NONE'
  },
  HEAVY_vs_SKILL: {
    winner: 'PLAYER',
    result: 'GUARD_BREAK',
    bannerText: 'HEAVY LEG KICK',
    bannerTextAr: 'ركلة ثقيلة بالقدم!',
    playerDamageMultiplier: 1.0,
    opponentDamageMultiplier: 0.35,
    playerStagger: false,
    opponentStagger: true,
    guardBreak: true,
    counterWindowGranted: 'NONE'
  },

  // DEFENSE
  DEFENSE_vs_STRIKE: {
    winner: 'PLAYER',
    result: 'BLOCKED',
    bannerText: 'BLOCKED',
    bannerTextAr: 'صد هجوم العدو!',
    playerDamageMultiplier: 0,
    opponentDamageMultiplier: 0.10,
    playerStagger: false,
    opponentStagger: true,
    guardBreak: false,
    counterWindowGranted: 'PLAYER'
  },
  DEFENSE_vs_HEAVY: {
    winner: 'OPPONENT',
    result: 'GUARD_BREAK',
    bannerText: 'GUARD BREAK',
    bannerTextAr: 'تحطم درعك!',
    playerDamageMultiplier: 0,
    opponentDamageMultiplier: 0.65,
    playerStagger: true,
    opponentStagger: false,
    guardBreak: true,
    counterWindowGranted: 'NONE'
  },
  DEFENSE_vs_DEFENSE: {
    winner: 'TIE',
    result: 'STANDOFF',
    bannerText: 'STANDOFF',
    bannerTextAr: 'وقفة ترقب واسترداد',
    playerDamageMultiplier: 0,
    opponentDamageMultiplier: 0,
    playerStagger: false,
    opponentStagger: false,
    guardBreak: false,
    counterWindowGranted: 'NONE',
    staminaRecoveryPlayer: 5,
    staminaRecoveryOpponent: 5
  },
  DEFENSE_vs_SKILL: {
    winner: 'OPPONENT',
    result: 'SKILL_BLOCKED',
    bannerText: 'SKILL MITIGATED',
    bannerTextAr: 'تقليص المهارة',
    playerDamageMultiplier: 0,
    opponentDamageMultiplier: 0.5,
    playerStagger: false,
    opponentStagger: false,
    guardBreak: false,
    counterWindowGranted: 'NONE'
  },

  // SKILL
  SKILL_vs_STRIKE: {
    winner: 'OPPONENT',
    result: 'SKILL_INTERRUPTED',
    bannerText: 'SKILL INTERRUPTED',
    bannerTextAr: 'تم مقاطعة مهارتك!',
    playerDamageMultiplier: 0,
    opponentDamageMultiplier: 1.0,
    playerStagger: true,
    opponentStagger: false,
    guardBreak: false,
    counterWindowGranted: 'NONE'
  },
  SKILL_vs_HEAVY: {
    winner: 'PLAYER',
    result: 'SKILL_HIT',
    bannerText: 'SKILL IMPACT',
    bannerTextAr: 'إصابة مهارة مباشرة',
    playerDamageMultiplier: 1.0,
    opponentDamageMultiplier: 0,
    playerStagger: false,
    opponentStagger: true,
    guardBreak: true,
    counterWindowGranted: 'NONE'
  },
  SKILL_vs_DEFENSE: {
    winner: 'PLAYER',
    result: 'SKILL_HIT',
    bannerText: 'SKILL BREACH',
    bannerTextAr: 'اختراق المهارة للدفاع',
    playerDamageMultiplier: 0.7,
    opponentDamageMultiplier: 0,
    playerStagger: false,
    opponentStagger: false,
    guardBreak: false,
    counterWindowGranted: 'NONE'
  },
  SKILL_vs_SKILL: {
    winner: 'TIE',
    result: 'CLASH',
    bannerText: 'ARCANE CLASH',
    bannerTextAr: 'تصادم المهارات',
    playerDamageMultiplier: 1.0,
    opponentDamageMultiplier: 1.0,
    playerStagger: false,
    opponentStagger: false,
    guardBreak: false,
    counterWindowGranted: 'NONE'
  }
};

export const DEFAULT_COMBAT_RULES: CombatRulesConfig = {
  presetName: 'Classic',
  actions: {
    STRIKE: {
      damage: 15,
      staminaCost: 10,
      energyDelta: 8,
      startupSeconds: 0.25,
      recoverySeconds: 0.30,
      speedMultiplier: 1.0,
      critChance: 0.1
    },
    HEAVY: {
      damage: 30,
      staminaCost: 25,
      energyDelta: 12,
      startupSeconds: 0.70,
      recoverySeconds: 0.60,
      speedMultiplier: 0.55,
      guardBreakPower: 1.0,
      staggerDurationSeconds: 0.8
    },
    DEFENSE: {
      damage: 0,
      staminaCost: 8, // 8 on block
      energyDelta: 5,
      startupSeconds: 0.15,
      recoverySeconds: 0.25,
      speedMultiplier: 1.2,
      strikeDamageReduction: 0.90, // 90%
      heavyDamageReduction: 0.35,  // 35%
      counterWindowSeconds: 0.5,
      counterBonusDamage: 20,
      standoffStaminaRecovery: 5
    }
  },
  matchupMatrix: DEFAULT_MATCHUP_MATRIX,
  skills: DEFAULT_COMBAT_SKILLS,
  staminaConfig: {
    maxStamina: 100,
    staminaRegenPerTurn: 10,
    exhaustionThreshold: 0,
    exhaustionPenaltyStrikeReduction: 0.20,
    exhaustionDisablesHeavy: true,
    exhaustionDefenseWeaknessMultiplier: 0.30
  },
  energyConfig: {
    maxEnergy: 100,
    strikeGain: 8,
    heavyGain: 12,
    defenseGain: 5
  },
  updatedAt: new Date().toISOString()
};

// Combat Presets catalogue
export const COMBAT_PRESETS: Record<string, Partial<CombatRulesConfig>> = {
  'Classic': {
    presetName: 'Classic',
    actions: DEFAULT_COMBAT_RULES.actions
  },
  'Fast Combat': {
    presetName: 'Fast Combat',
    actions: {
      STRIKE: { ...DEFAULT_COMBAT_RULES.actions.STRIKE, damage: 18, staminaCost: 8, startupSeconds: 0.18 },
      HEAVY: { ...DEFAULT_COMBAT_RULES.actions.HEAVY, damage: 35, staminaCost: 20, startupSeconds: 0.50 },
      DEFENSE: { ...DEFAULT_COMBAT_RULES.actions.DEFENSE, staminaCost: 6, standoffStaminaRecovery: 10 }
    }
  },
  'Hardcore': {
    presetName: 'Hardcore',
    actions: {
      STRIKE: { ...DEFAULT_COMBAT_RULES.actions.STRIKE, staminaCost: 15 },
      HEAVY: { ...DEFAULT_COMBAT_RULES.actions.HEAVY, staminaCost: 35, damage: 40 },
      DEFENSE: { ...DEFAULT_COMBAT_RULES.actions.DEFENSE, staminaCost: 14, strikeDamageReduction: 0.80 }
    }
  },
  'High Damage': {
    presetName: 'High Damage',
    actions: {
      STRIKE: { ...DEFAULT_COMBAT_RULES.actions.STRIKE, damage: 25 },
      HEAVY: { ...DEFAULT_COMBAT_RULES.actions.HEAVY, damage: 50 },
      DEFENSE: { ...DEFAULT_COMBAT_RULES.actions.DEFENSE, counterBonusDamage: 30 }
    }
  },
  'Defensive': {
    presetName: 'Defensive',
    actions: {
      STRIKE: { ...DEFAULT_COMBAT_RULES.actions.STRIKE, damage: 12 },
      HEAVY: { ...DEFAULT_COMBAT_RULES.actions.HEAVY, damage: 25 },
      DEFENSE: { ...DEFAULT_COMBAT_RULES.actions.DEFENSE, strikeDamageReduction: 0.95, heavyDamageReduction: 0.50, counterBonusDamage: 25 }
    }
  }
};
