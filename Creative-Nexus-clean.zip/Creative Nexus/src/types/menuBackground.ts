export interface MainMenuBackgroundConfig {
  imageUrl: string;
  opacity: number; // 0 to 1, default ~0.65
  blur: number; // 0 to 50px, default ~10
  dim: number; // 0 to 1, dark overlay tint, default ~0.4
  objectPosition?: string; // 'center', 'top', 'bottom', etc.
  scope?: 'hero' | 'full_page'; // 'hero' or 'full_page'
  theme?: 'creative-nexus' | 'kohan-iraqi';
  isSyncedWithMainMenu?: boolean;
  updatedBy?: string;
  updatedAt?: string;
}

export interface PresetBackground {
  id: string;
  theme?: 'creative-nexus' | 'kohan-iraqi';
  nameAr: string;
  nameEn: string;
  url: string;
  defaultBlur: number;
  defaultOpacity: number;
  defaultDim: number;
  previewUrl: string;
}
