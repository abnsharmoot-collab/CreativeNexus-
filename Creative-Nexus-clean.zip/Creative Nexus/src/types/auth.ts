export type AccessLevel = 'OWNER' | 'STAFF' | 'MEMBER';

export type UserRole = 'OWNER' | 'STAFF' | 'MEMBER' | 'SUPER_ADMIN' | 'ADMIN' | 'MODERATOR';

export type Permission =
  | 'VIEW_DASHBOARD'
  | 'VIEW_STAFF'
  | 'MANAGE_STAFF'
  | 'ADD_STAFF'
  | 'EDIT_STAFF'
  | 'REMOVE_STAFF'
  | 'SUSPEND_STAFF'
  | 'MANAGE_POINTS'
  | 'ADD_POINTS'
  | 'REMOVE_POINTS'
  | 'VIEW_AUDIT_LOG'
  | 'MANAGE_ROLES'
  | 'MANAGE_SERVER_SETTINGS'
  | 'OWNER_CONTROL';

export interface DiscordUser {
  id: number | string;
  discordId: string; // Primary identity
  username: string;
  displayName: string;
  avatarUrl: string;
  role: UserRole;
  accessLevel?: AccessLevel;
  isOwner?: boolean;
  isStaff?: boolean;
  staffRank?: string;
  staffPoints?: number;
  permissions: Permission[];
  isMember: boolean;
  isGuildOwner?: boolean;
  discordRoles?: string[];
  roleNames?: string[];
  discoveredAs?: 'OWNER' | 'STAFF' | 'MEMBER' | 'SUPER_ADMIN' | 'ADMIN' | 'MODERATOR';
  matchedReason?: string;
  matchedRole?: string;
  matchedRoleId?: string;
}

export interface DiscoveryResult {
  discoveredAs: 'OWNER' | 'STAFF' | 'MEMBER' | 'SUPER_ADMIN' | 'ADMIN' | 'MODERATOR';
  role: UserRole;
  accessLevel?: AccessLevel;
  matchedReason: string;
  matchedRole?: string;
  matchedRoleId?: string;
  configuredModeratorRole?: string;
}

export interface ModeratorRoleConfig {
  guildId?: string;
  guildOwnerId?: string;
  moderatorRoleName: string;
  moderatorRoleNames: string[];
  moderatorRoleId: string;
  availableRoles?: Array<{ id: string; name: string; color?: number }>;
}

export interface OAuthConfig {
  configured: boolean;
  clientId: string | null;
  redirectUri: string;
  appUrl: string | null;
  guildId?: string;
  oauthUrl?: string;
  syncedRedirectUri?: string;
}

export interface AuthContextType {
  user: DiscordUser | null;
  isAuthenticated: boolean;
  loading: boolean;
  role: UserRole;
  accessLevel: AccessLevel;
  isOwner: boolean;
  isStaff: boolean;
  permissions: Permission[];
  isMember: boolean;
  hasPermission: (permission: Permission) => boolean;
  oauthConfig: OAuthConfig | null;
  moderatorRoleConfig: ModeratorRoleConfig | null;
  updateModeratorRoleConfig: (newRoleName: string, newRoleId?: string) => Promise<{ success: boolean; message?: string }>;
  lastDiscovery: DiscoveryResult | null;
  dismissDiscovery: () => void;
  botOAuthUrl: string;
  loginWithDiscord: (urlOverride?: string) => Promise<void>;
  exchangeCode: (code: string) => Promise<boolean>;
  loginWithDirect: (userData: {
    discordId: string;
    username: string;
    displayName: string;
    avatarUrl?: string;
    roleNames?: string[];
    customRole?: string;
  }) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  checkAuth: () => Promise<void>;
  refreshSession: () => Promise<void>;
  error: string | null;
  clearError: () => void;
  showConfigGuide: boolean;
  setShowConfigGuide: (show: boolean) => void;
  isLoginModalOpen: boolean;
  setIsLoginModalOpen: (open: boolean) => void;
}
