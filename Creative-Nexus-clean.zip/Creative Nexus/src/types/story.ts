import { CollectibleCardData, CardAbility, CardStateItem } from './cards';

export type BattleDifficulty = 'NORMAL' | 'HARD' | 'ELITE' | 'BOSS' | 'CHAPTER_FINALE';

export interface StoryBattleDefinition {
  id: string;
  chapterId: string;
  battleNumber: number;
  name: string;
  nameAr: string;
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  introText: string;
  introTextAr: string;
  difficulty: BattleDifficulty;
  fightType?: 'NORMAL' | 'BOSS' | 'CHAPTER_FINALE';
  isChapterFinale?: boolean;
  enemyCommanderName: string;
  enemyCommanderNameAr?: string;
  enemyCommanderAvatar?: string;
  backgroundImageUrl?: string;
  customCharacterName?: string;
  customCharacterNameAr?: string;
  enemyDeckCardIds: string[]; // Up to 4 cards
  enemyCards?: CollectibleCardData[]; // Populated enemy cards
  enemyDeckOverrides?: Partial<CollectibleCardData>[];
  rewardCoins: number;
  rewardXp: number;
  firstClearBonusCoins: number;
  unlockRequirementId: string | null; // ID of previous battle required, or null for battle 1
}

export interface StoryChapterDefinition {
  id: string;
  chapterNumber: number;
  title: string;
  titleAr: string;
  subtitle: string;
  subtitleAr: string;
  description: string;
  descriptionAr: string;
  bannerImageUrl?: string;
  accentColor?: string;
  badgeText?: string;
  badgeTextAr?: string;
  battles: StoryBattleDefinition[];
}

export interface UserStoryProgress {
  userId: string;
  completedBattleIds: string[];
  claimedRewardBattleIds: string[]; // first clear rewards claimed
  totalBattlesWon: number;
  totalBattlesLost: number;
  updatedAt: string;
}

// ----------------------------------------------------
// TACTICAL COMBAT ARCHITECTURE & ENGINE ENTITIES
// ----------------------------------------------------

export type TacticalStance = 'NORMAL' | 'DEFENDING' | 'EMPOWERED' | 'EXHAUSTED' | 'STUNNED' | 'COUNTER';

export type CombatMomentType =
  | 'NORMAL'
  | 'CRITICAL'
  | 'GUARD_BREAK'
  | 'BLOCKED'
  | 'PARRIED'
  | 'ABILITY_BURST'
  | 'OVERDRIVE'
  | 'CARD_DEFEATED'
  | 'LAST_STAND'
  | 'SYNERGY_RESONANCE'
  | 'FORMATION_SWAP';

export type CombatAnimationStage =
  | 'IDLE'
  | 'ENTRANCE'
  | 'APPROACH'
  | 'STRIKE'
  | 'HEAVY_STRIKE'
  | 'IMPACT'
  | 'RECOIL'
  | 'DEFEND_PULSE'
  | 'PARRY_FLASH'
  | 'ABILITY_CHARGE'
  | 'ABILITY_RELEASE'
  | 'OVERDRIVE_CINEMATIC'
  | 'GUARD_SHATTER'
  | 'DEFEAT_COLLAPSE';

export interface TacticalMomentum {
  comboCount: number;
  maxCombo: number;
  momentumPoints: number; // 0 to 100
  isComboPrimed: boolean;
  lastAction?: BattleActionType;
}

// ENEMY INTENT SYSTEM (Behavioral Tells)
export type EnemyIntentType = 
  | 'CALM' 
  | 'AGGRESSIVE' 
  | 'DEFENSIVE' 
  | 'CHARGING' 
  | 'DESPERATE' 
  | 'COUNTERING';

export interface EnemyIntentInfo {
  type: EnemyIntentType;
  displayedType: EnemyIntentType;
  isFake?: boolean;
  label: string;
  labelAr: string;
  iconName: string;
  description: string;
  descriptionAr: string;
  hint: string;
  hintAr: string;
  predictedActionProbabilities?: {
    strike: number;
    heavy: number;
    defend: number;
    skill: number;
  };
}

export type EnemyArchetype = 'SCOUT' | 'BRUTE' | 'GUARDIAN' | 'MAGE' | 'BOSS' | 'ASSASSIN';

export type CardSpecialAbility = 
  | 'PREDICT' 
  | 'COUNTER_STANCE' 
  | 'AMBUSH' 
  | 'ARMOR_BREAK' 
  | 'REGENERATION' 
  | 'STANDARD';

export type SkillType = 'BUFF' | 'OFFENSIVE' | 'DEFENSIVE' | 'LIFESTEAL' | 'DODGE' | 'UTILITY';
export type SkillPriority = 0 | 1 | 2 | 3; // 0: Normal, 1: Fast, 2: Special, 3: Ultimate

export interface CardCombatSkill {
  id: string;
  name: string;
  nameAr?: string;
  description: string;
  descriptionAr?: string;
  icon: string;
  type: SkillType;
  damage: number;
  defenseModifier?: number;
  staminaCost: number;
  energyCost: number;
  cooldown: number; // Base turns cooldown
  currentCooldown: number; // 0 = READY
  duration: number; // Duration in turns
  target: 'SELF' | 'ENEMY';
  priority: SkillPriority;
  startup: number;
  interruptible: boolean; // If true, STRIKE interrupts it during startup
  defenseInteraction: 'IGNORES_DEFENSE' | 'BLOCKED_BY_DEFENSE' | 'ABSORB';
  effects?: {
    heavyDamageMultiplier?: number; // e.g. 1.5 for Berserker Rage
    dodgeNextAttack?: boolean; // e.g. Assassin Quickstep
    incomingDamageReduction?: number; // e.g. 0.70 for Guardian Fortify
    healAmount?: number; // e.g. 8 for Vampire Lifesteal
    unblockable?: boolean; // e.g. Mage Arcane Blast
  };
}

export interface BattleCardEntity {
  instanceId: string;
  card: CollectibleCardData;
  maxHp: number;
  currentHp: number;
  shield: number; // Active shield point absorption
  maxStamina: number; // Maximum 100 Stamina
  currentStamina: number; // Current Stamina
  maxEnergy?: number; // Kept for backwards compatibility
  currentEnergy?: number; // Kept for backwards compatibility
  isExhausted: boolean; // Stamina = 0 (damage -20%, cannot use Heavy)
  skill: CardCombatSkill;
  counterWindow?: boolean; // Short counter opportunity from blocking strike
  isStaggered?: boolean; // Staggered from Interrupted or Guard Break
  activeBuffs?: {
    heavyDamageMultiplier?: number;
    dodgeNext?: boolean;
    damageReduction?: number;
    turnsRemaining: number;
  };
  attack: number;
  defense: number;
  speed: number;
  clashMastery: number; // Bonus Clash Power % (e.g. 0 to 25)
  archetype?: EnemyArchetype;
  specialAbilityType?: CardSpecialAbility;
  isDefending: boolean;
  stance: TacticalStance;
  defenseBuffTurns: number;
  abilityCooldown: number; // 0 = ready
  isDefeated: boolean;
  selectedAbility?: CardAbility;
  states: CardStateItem[];
  element: string;
  rarity: string;
  formationRole?: 'VANGUARD' | 'STRIKER' | 'BULWARK' | 'TACTICIAN';
}

export interface ClashResultData {
  isClash: boolean;
  playerClashPower: number;
  enemyClashPower: number;
  winner: 'PLAYER' | 'ENEMY' | 'TIE';
  bonusDamage: number;
  clashTitle: string;
  clashTitleAr: string;
}

export interface CombatActionConfig {
  type: CombatIntentType;
  staminaCost: number;
  staminaGain?: number;
  energyCost?: number;
  energyGain?: number;
  priority: number;
  baseDamage?: number;
  speed?: number;
  startup?: number;
  recovery?: number;
  strikeDamageReduction?: number;
  heavyDamageReduction?: number;
  label: string;
  labelAr: string;
  icon: string;
  description?: string;
  descriptionAr?: string;
}

export const ACTION_CONFIGS: Record<CombatIntentType, CombatActionConfig> = {
  STRIKE: {
    type: 'STRIKE',
    staminaCost: 10,
    priority: 1, // Fast
    speed: 1.0,
    startup: 0.25,
    recovery: 0.30,
    baseDamage: 15,
    label: 'Strike',
    labelAr: 'هجوم سريع',
    icon: 'Swords',
    description: 'Fast, low-risk attack. Costs 10 Stamina. Beats Heavy, countered by Defense.',
    descriptionAr: 'هجوم سريع منخفض المخاطر. يستهلك 10 نقاط جهد/تحمل. يهزم الثقيل، ويصده الدفاع.'
  },
  HEAVY: {
    type: 'HEAVY',
    staminaCost: 25,
    priority: 0, // Slow
    speed: 0.55,
    startup: 0.70,
    recovery: 0.60,
    baseDamage: 30,
    label: 'Heavy',
    labelAr: 'هجوم ثقيل',
    icon: 'Flame',
    description: 'Powerful guard-breaking blow. Costs 25 Stamina. Beats Defense, interrupted by Strike.',
    descriptionAr: 'ضربة قوية كاسرة للدفاع. تستهلك 25 نقطة جهد/تحمل. تهزم الدفاع، ويقطعها الهجوم السريع.'
  },
  DEFENSE: {
    type: 'DEFENSE',
    staminaCost: 8,
    staminaGain: 10, // On standoff
    priority: 2, // Reactive
    strikeDamageReduction: 0.90, // 90% reduction
    heavyDamageReduction: 0.35, // 35% reduction
    label: 'Defense',
    labelAr: 'دفاع محكم',
    icon: 'Shield',
    description: 'Raise guard. Costs 8 Stamina on block. Mitigates 90% strike damage and opens counter window.',
    descriptionAr: 'رفع الدرع الواقي. يستهلك 8 نقاط جهد عند الصد، ويقلص 90% من ضرر الهجوم السريع.'
  },
  DEFEND: {
    type: 'DEFEND',
    staminaCost: 8,
    staminaGain: 10,
    priority: 2,
    strikeDamageReduction: 0.90,
    heavyDamageReduction: 0.35,
    label: 'Defense',
    labelAr: 'دفاع محكم',
    icon: 'Shield',
    description: 'Raise guard. Costs 8 Stamina on block.',
    descriptionAr: 'رفع الدرع الواقي. يستهلك 8 نقاط جهد عند الصد.'
  },
  SKILL: {
    type: 'SKILL',
    staminaCost: 30,
    priority: 2,
    label: 'Skill',
    labelAr: 'مهارة تكتيكية',
    icon: 'Sparkles',
    description: 'Executes card signature combat skill. Costs 30 Stamina.',
    descriptionAr: 'تنفيذ المهارة القتالية الخاصة للبطاقة. تستهلك 30 نقطة جهد/تحمل.'
  },
  ABILITY: {
    type: 'ABILITY',
    staminaCost: 30,
    priority: 2,
    label: 'Skill',
    labelAr: 'مهارة تكتيكية',
    icon: 'Sparkles',
    description: 'Executes card signature combat skill. Costs 30 Stamina.',
    descriptionAr: 'تنفيذ المهارة القتالية الخاصة للبطاقة. تستهلك 30 نقطة جهد/تحمل.'
  },
  ULTIMATE: {
    type: 'ULTIMATE',
    staminaCost: 40,
    priority: 3,
    label: 'Ultimate',
    labelAr: 'قدرة قصوى',
    icon: 'Sparkles',
    description: 'Devastating overdrive skill.',
    descriptionAr: 'القدرة القصوى الخارقة للبطاقة.'
  },
  PARRY: {
    type: 'PARRY',
    staminaCost: 8,
    priority: 3,
    label: 'Parry',
    labelAr: 'صد هجومي',
    icon: 'ShieldAlert'
  },
  SWITCH: {
    type: 'SWITCH',
    staminaCost: 0,
    priority: 0,
    label: 'Switch',
    labelAr: 'تبديل',
    icon: 'Swords'
  }
};

export type BattlePhase =
  | 'PREVIEW'
  | 'VS_SCREEN'
  | 'ARENA_ENTRANCE'
  | 'COMBAT_ACTIVE'
  | 'ROUND_RESOLVING'
  | 'VICTORY'
  | 'DEFEAT';

export type CombatIntentType = 
  | 'STRIKE' 
  | 'HEAVY' 
  | 'DEFENSE' 
  | 'DEFEND'
  | 'SKILL' 
  | 'ABILITY' 
  | 'PARRY' 
  | 'ULTIMATE' 
  | 'SWITCH';

// Legacy action type alias for backwards compatibility
export type BattleActionType = 
  | 'ATTACK' 
  | 'HEAVY_STRIKE' 
  | 'DEFEND' 
  | 'DEFENSE'
  | 'PARRY' 
  | 'ABILITY' 
  | 'SKILL'
  | 'OVERDRIVE'
  | 'SWITCH_LEAD'
  | CombatIntentType;

export interface CombatIntent {
  side: 'PLAYER' | 'ENEMY';
  type: CombatIntentType;
  targetIndex?: number;
  abilityId?: string;
}

export type ClashCategory =
  | 'CLASH'
  | 'INTERRUPTED'
  | 'BLOCKED'
  | 'COUNTER_WINDOW'
  | 'HEAVY_CLASH'
  | 'GUARD_BREAK'
  | 'STAGGER'
  | 'STANDOFF'
  | 'SKILL_DODGED'
  | 'SKILL_ABSORBED'
  | 'SKILL_UNBLOCKABLE'
  | 'PARRY_COUNTER'
  | 'GUARD_CRUSH'
  | 'SPEED_STRIKE'
  | 'CLASH_TRADE'
  | 'DEFENSIVE_HOLD'
  | 'ULTIMATE_OVERWHELM'
  | 'TACTICAL_MANEUVER'
  | 'PARRY_WHIFF';

export interface RoundClashResolution {
  roundNumber: number;
  playerIntent: CombatIntent;
  enemyIntent: CombatIntent;
  playerOutcome: BattleActionOutcome;
  enemyOutcome: BattleActionOutcome;
  firstActor: 'PLAYER' | 'ENEMY' | 'SIMULTANEOUS';
  clashType: ClashCategory;
  bannerTitle: string;
  bannerTitleAr: string;
  summary: string;
  summaryAr: string;
  specialMoment?: CombatMomentType;
  playerParrySuccess?: boolean;
  enemyParrySuccess?: boolean;
  playerGuardBroken?: boolean;
  enemyGuardBroken?: boolean;
}

export type RoundCombatPhase = 
  | 'READ'
  | 'CHOOSE'
  | 'REVEAL'
  | 'RESOLVE'
  | 'IMPACT'
  | 'AFTERMATH'
  | 'VICTORY'
  | 'DEFEAT';

export interface BattleActionOutcome {
  action: BattleActionType;
  actorSide: 'PLAYER' | 'ENEMY';
  actorName: string;
  targetName: string;
  damage: number;
  isCrit: boolean;
  isGuardBreak: boolean;
  isBlocked: boolean;
  isParried?: boolean;
  isDefeat: boolean;
  momentType?: CombatMomentType;
  abilityName?: string;
  statusApplied?: string;
  momentumGained: number;
  description: string;
  descriptionAr?: string;
}

export interface BattleLogEntry {
  id: string;
  turnNumber: number;
  actorName: string;
  actorSide: 'PLAYER' | 'ENEMY';
  action: BattleActionType;
  targetName?: string;
  damage?: number;
  abilityName?: string;
  description: string;
  descriptionAr?: string;
  isDefeatEvent?: boolean;
  defeatedCardName?: string;
  momentType?: CombatMomentType;
  timestamp: string;
}

export interface BattleSessionState {
  battleId: string;
  battleName: string;
  turnNumber: number;
  roundNumber: number;
  currentTurnSide: 'PLAYER' | 'ENEMY';
  initiative: 'PLAYER' | 'ENEMY';
  playerCards: BattleCardEntity[]; // STRICT MAXIMUM 4 CARDS
  enemyCards: BattleCardEntity[];  // STRICT MAXIMUM 4 CARDS
  playerActiveIndex: number;
  enemyActiveIndex: number;
  playerActiveFighterId?: string | null;
  enemyActiveFighterId?: string | null;
  playerSwitchCooldown?: number;
  enemySwitchCooldown?: number;
  pendingFighterSelection?: 'PLAYER' | 'ENEMY' | 'BOTH' | null;
  playerMomentum: TacticalMomentum;
  enemyMomentum: TacticalMomentum;
  phase: BattlePhase;
  roundPhase?: RoundCombatPhase;
  selectedPlayerIntent?: CombatIntent | null;
  selectedEnemyIntent?: CombatIntent | null;
  currentEnemyIntent?: EnemyIntentInfo | null;
  currentClashData?: ClashResultData | null;
  turnPlanningLocked?: boolean;
  isActionRevealed?: boolean;
  lastClashResolution?: RoundClashResolution | null;
  isLastStand?: boolean;
  lastStandSide?: 'PLAYER' | 'ENEMY' | 'BOTH' | null;
  playerPatternHistory?: CombatIntentType[];
  aiPersonality?: 'AGGRESSIVE' | 'DEFENSIVE' | 'TACTICAL' | 'BERSERKER' | 'CONTROL';
  activeMoment: CombatMomentType | null;
  lastOutcome?: BattleActionOutcome;
  logs: BattleLogEntry[];
  winner: 'PLAYER' | 'ENEMY' | null;
  coinsEarned: number;
  xpEarned: number;
  isFirstClear: boolean;
}
