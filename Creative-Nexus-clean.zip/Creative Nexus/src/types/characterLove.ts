import { CardRarity } from './cards';

export type GradientFadeDirection =
  | 'to-top'
  | 'to-bottom'
  | 'to-left'
  | 'to-right'
  | 'radial'
  | 'angle';

export interface CharacterImageGradientConfig {
  enabled: boolean;
  direction: GradientFadeDirection;
  angle?: number; // 0 - 360 deg
  startPercent: number; // 0 - 100% where solid ends / begins
  endPercent: number; // 0 - 100% where it reaches transparency
  opacity?: number; // 0 - 1
  fadeIntensity?: number; // 0 - 100
}

export interface CharacterSoundClip {
  id: string;
  name: string;
  url: string; // Data URL or URL of the audio file
  volume?: number; // Individual volume 0-100 (defaults to master or 80)
}

export interface CharacterAudioConfig {
  enabled: boolean;
  audioUrl?: string; // Legacy fallback single audio
  audioName?: string;
  volume: number; // 0 - 100 master volume
  sounds?: CharacterSoundClip[]; // Collection of audio files for random playback
}

export interface CharacterClickTransformConfig {
  enabled: boolean;
  imageUrl?: string; // Replacement PNG on click
  mode: 'timed' | 'toggle'; // 'timed' returns after durationMs, 'toggle' toggles back on click
  durationMs: number; // Duration in ms for timed mode (e.g. 1200ms)
}

export interface CharacterPositionConfig {
  scale?: number;
  offsetX?: number;
  offsetY?: number;
  imageWidth?: number | string;
  imageHeight?: number | string;
  layering?: 'front' | 'behind_pedestal' | 'popout_overflow' | 'contained';
  overflowMode?: 'visible' | 'clipped';
  zIndex?: number;
  mouthX?: number; // Offset from center in px for drag-to-feed mouth drop zone
  mouthY?: number; // Offset from center in px for drag-to-feed mouth drop zone
}

export interface CharacterStage {
  id: string;
  stageNumber: number; // 1, 2, 3, etc.
  name: string;
  nameAr: string;
  requiredLevel: number;
  requiredPoints?: number; // Optional configured points requirement
  passiveCoinReward?: number; // Configured coins generated every 12 hours for this specific stage
  imageUrl: string; // Transparent PNG or portrait for this specific love stage
  quote?: string;
  quoteAr?: string;
  perkDescription?: string;
  perkDescriptionAr?: string;
  mouthX?: number;
  mouthY?: number;
}

export interface CharacterDefinition {
  id: string;
  name: string;
  nameAr: string;
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  avatarUrl: string; // Default transparent PNG
  stages: CharacterStage[];
  themeColor: string; // e.g. '#f43f5e', '#a855f7', '#06b6d4', '#f59e0b'
  accentGradient?: string;
  lovedItemIds?: string[]; // IDs of items this character specifically loves for bonus affection

  // 1. Positioning & Sizing Controls
  scale?: number; // 0.2 to 3.0 (default 1.0)
  offsetX?: number; // -400 to 400 px (default 0)
  offsetY?: number; // -400 to 400 px (default 0)
  imageWidth?: number | string; // e.g. 'auto', 340, '100%'
  imageHeight?: number | string; // e.g. 'auto', 540, '120%'
  layering?: 'front' | 'behind_pedestal' | 'popout_overflow' | 'contained';
  overflowMode?: 'visible' | 'clipped';
  zIndex?: number;
  mouthX?: number; // Mouth X offset from center for feeding
  mouthY?: number; // Mouth Y offset from center for feeding

  // Card dimensions & layout synchronization
  cardHeight?: number; // Custom card height in px (e.g. 480, 520, 560, auto)
  cardWidth?: number; // Custom card max width in px (e.g. 420, 480, 520)

  // 2. Image Gradient / Transparent Fade
  gradientFade?: CharacterImageGradientConfig;

  // 5. Custom Audio
  audioConfig?: CharacterAudioConfig;

  // 6. Click Transformations
  clickTransform?: CharacterClickTransformConfig;

  // 7. Random Gifts Configured for this Character
  randomGifts?: CharacterRandomGift[];

  order: number;
  isActive: boolean;
  isCustom?: boolean;
  createdBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CharacterRandomGift {
  id: string;
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  imageUrl: string; // Transparent PNG or artwork URL
  rarity: CardRarity; // 'COMMON' | 'UNCOMMON' | 'RARE' | 'EPIC' | 'LEGENDARY'
  characterId: string; // Specific character ID or 'ANY'
  dropChance: number; // Configurable probability % or weight (e.g. 25 = 25%)
  rewardCoins?: number; // Coin bonus given with gift
  rewardLovePoints?: number; // Bonus love affection points
  rewardItemId?: string; // Optional inventory gift item ID to add
  isCustom?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

import { UnifiedItemDefinition, UserItemOwnership, ItemCategory, BattleItemEffectConfig } from './items';
export type { ItemCategory, BattleItemEffectConfig };

// Alias LoveItemDefinition to UnifiedItemDefinition for 100% backwards-compatibility
export type LoveItemDefinition = UnifiedItemDefinition;

export interface UserCharacterProgress {
  characterId: string;
  lovePoints: number;
  level: number;
  currentStageNumber: number;
  totalGiftsGiven: number;
  favoriteGiftId?: string;
  lastInteractedAt: string;
  unlockedStageNumbers: number[];
  lastPassiveCoinClaimAt?: string; // Track 12-hour passive coin claims
  lastRandomGiftClaimAt?: string; // Track random gift interactions
  lastSpecialRewardClaimAt?: string; // Track 3-day special random reward claims
}

export type SpecialRewardType = 'PACKAGE' | 'ITEM';

export interface SpecialRewardDefinition {
  id: string;
  type: SpecialRewardType;
  name: string;
  nameAr: string;
  rarity: CardRarity;
  packageId?: CardRarity; // 'COMMON' | 'UNCOMMON' | 'RARE' | 'EPIC' | 'LEGENDARY'
  itemId?: string; // Reference to LoveItemDefinition id
  dropWeight: number; // Probability weight (e.g. 20)
  bonusCoins?: number; // Optional coin bonus
  bonusLovePoints?: number; // Optional love points bonus
  iconUrl?: string;
  description?: string;
  descriptionAr?: string;
  isActive: boolean;
}

export interface SpecialRewardsConfig {
  cycleHours: number; // Default 72 (3 days)
  rewards: SpecialRewardDefinition[];
  updatedAt: string;
  updatedBy?: string;
}

export interface ClaimSpecialRewardResult {
  success: boolean;
  characterId: string;
  reward: SpecialRewardDefinition;
  awardedType: SpecialRewardType;
  awardedPackageId?: CardRarity;
  awardedItemId?: string;
  awardedItemName?: string;
  awardedItemNameAr?: string;
  drawnCard?: any;
  coinsAwarded: number;
  lovePointsAwarded: number;
  newBalance: number;
  lastSpecialRewardClaimAt: string;
  nextSpecialRewardAvailableAt: string;
  message?: string;
}

export interface ClaimPassiveCoinsResult {
  success: boolean;
  characterId: string;
  coinsAwarded: number;
  newBalance: number;
  stageNumber: number;
  lastPassiveCoinClaimAt: string;
  nextClaimAvailableAt: string;
  message?: string;
}

export interface TriggerRandomGiftResult {
  success: boolean;
  giftDropped: boolean;
  gift?: CharacterRandomGift;
  coinsAwarded?: number;
  lovePointsAwarded?: number;
  itemAddedToInventory?: boolean;
  newCoinsBalance?: number;
  newLovePoints?: number;
  lastClaimAt?: string;
  message?: string;
}

// Alias UserLoveItemOwnership to UserItemOwnership for unified inventory compatibility
export type UserLoveItemOwnership = UserItemOwnership;

export interface LoveLevelThreshold {
  level: number;
  requiredPoints: number;
  titleEn: string;
  titleAr: string;
}

export interface GiveGiftResult {
  success: boolean;
  characterId: string;
  itemId: string;
  pointsAwarded: number;
  isBelovedGift: boolean;
  previousPoints: number;
  newPoints: number;
  previousLevel: number;
  newLevel: number;
  leveledUp: boolean;
  newStageUnlocked: boolean;
  currentStage: CharacterStage;
  remainingItemCount: number;
  progress: UserCharacterProgress;
  message?: string;
}

// Default Level Thresholds (Configurable by Owner)
export const DEFAULT_LOVE_LEVEL_THRESHOLDS: LoveLevelThreshold[] = [
  { level: 1, requiredPoints: 0, titleEn: 'New Companion', titleAr: 'رفيق جديد' },
  { level: 2, requiredPoints: 80, titleEn: 'Fond Acquaintance', titleAr: 'ألفة ناضرة' },
  { level: 3, requiredPoints: 200, titleEn: 'Devoted Bond', titleAr: 'رابطة مخلصة' },
  { level: 4, requiredPoints: 420, titleEn: 'Cherished Heart', titleAr: 'قلب عزيز' },
  { level: 5, requiredPoints: 750, titleEn: 'Soulbound Radiance', titleAr: 'ضياء الأرواح' },
  { level: 6, requiredPoints: 1200, titleEn: 'Eternal Devotion', titleAr: 'وفاء سرمدي' },
  { level: 7, requiredPoints: 1800, titleEn: 'Celestial Sovereign', titleAr: 'سيادة سماوية' },
  { level: 8, requiredPoints: 2600, titleEn: 'Transcendent Harmony', titleAr: 'تناغم أسمى' },
  { level: 9, requiredPoints: 3600, titleEn: 'Infinite Affinity', titleAr: 'عشق لامتناهٍ' },
  { level: 10, requiredPoints: 5000, titleEn: 'Supreme Sanctuary Love', titleAr: 'قداسة المحبة العليا' },
];

// Helper: calculate Level and progress percentage from total points
export function calculateLevelFromPoints(points: number, thresholds: LoveLevelThreshold[] = DEFAULT_LOVE_LEVEL_THRESHOLDS): {
  level: number;
  currentThreshold: LoveLevelThreshold;
  nextThreshold: LoveLevelThreshold | null;
  progressPercent: number;
} {
  const sorted = [...thresholds].sort((a, b) => a.level - b.level);
  let currentLevel = 1;

  for (const t of sorted) {
    if (points >= t.requiredPoints) {
      currentLevel = t.level;
    } else {
      break;
    }
  }

  const currentThreshold = sorted.find(t => t.level === currentLevel) || sorted[0];
  const nextThreshold = sorted.find(t => t.level === currentLevel + 1) || null;

  let progressPercent = 100;
  if (nextThreshold) {
    const range = nextThreshold.requiredPoints - currentThreshold.requiredPoints;
    const currentOver = points - currentThreshold.requiredPoints;
    progressPercent = range > 0 ? Math.min(100, Math.max(0, Math.round((currentOver / range) * 100))) : 100;
  }

  return {
    level: currentLevel,
    currentThreshold,
    nextThreshold,
    progressPercent
  };
}

// Helper: compute active stage for a character given a level
export function computeActiveStage(character: CharacterDefinition, level: number): CharacterStage {
  if (!character.stages || character.stages.length === 0) {
    return {
      id: `${character.id}_stage_1`,
      stageNumber: 1,
      name: 'Stage 1',
      nameAr: 'المرحلة 1',
      requiredLevel: 1,
      imageUrl: character.avatarUrl
    };
  }

  const sortedStages = [...character.stages].sort((a, b) => a.stageNumber - b.stageNumber);
  let active = sortedStages[0];

  for (const stage of sortedStages) {
    if (level >= stage.requiredLevel) {
      active = stage;
    }
  }

  return active;
}
