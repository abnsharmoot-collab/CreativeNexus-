export type NotificationType =
  | 'RANK_APPLICATION_SUBMITTED'
  | 'RANK_APPLICATION_APPROVED'
  | 'RANK_APPLICATION_REJECTED'
  | 'POINTS_ADDED'
  | 'POINTS_REMOVED'
  | 'ACHIEVEMENT_EARNED'
  | 'STAFF_STATUS_CHANGED'
  | 'ANNOUNCEMENT'
  | 'THEME_UNLOCKED';

export interface AppNotification {
  id: string;
  recipientDiscordId: string;
  type: NotificationType;
  title: string;
  description: string;
  read: boolean;
  readAt?: string | null;
  link?: string | null;
  createdAt: string;
  metadata?: Record<string, any>;
}

export interface UserNotificationStateDoc {
  discordId: string;
  readIds?: string[];
  readAllBefore?: string | null;
  updatedAt: string;
}

export interface NotificationStats {
  totalCount: number;
  unreadCount: number;
}
