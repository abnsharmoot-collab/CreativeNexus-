export type CardRarity = 'COMMON' | 'UNCOMMON' | 'RARE' | 'EPIC' | 'LEGENDARY';

export type CardType = 'ATTACK' | 'DEFENSE' | 'UTILITY' | 'SUPPORT' | 'LEADER' | 'EVENT';

export type CardFrame = 'standard' | 'golden' | 'obsidian' | 'celestial' | 'runic' | 'meso';

export interface CardStats {
  attack?: number;
  defense?: number;
  energy?: number;
  health?: number;
}

export interface CardDefinition {
  id: string;
  name: string;
  nameAr?: string;
  rarity: CardRarity;
  type: CardType;
  artwork: string;
  frame: string;
  abilityName: string;
  abilityNameAr?: string;
  abilityDescription: string;
  abilityDescriptionAr?: string;
  description: string;
  descriptionAr?: string;
  collection: string;
  active: boolean;
  introVideo?: string;
  introVideoEnabled?: boolean;
  stats?: CardStats;
  tags?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface PackDefinition {
  id: string;
  name: string;
  nameAr: string;
  rarity: CardRarity;
  cost: number;
  description: string;
  descriptionAr: string;
  artwork?: string;
  accentColor: string;
  availableCount?: number;
  isAvailable?: boolean;
}

export interface UserCollectionItem {
  cardId: string;
  quantity: number;
  firstObtainedAt: string;
  lastObtainedAt: string;
  card: CardDefinition;
}

export interface UserWallet {
  discordId: string;
  coins: number;
  lastDailyClaimAt?: string | null;
  canClaimDaily: boolean;
  nextClaimInMs: number;
}

export interface CoinTransaction {
  id: string;
  discordId: string;
  targetUsername?: string;
  targetDisplayName?: string;
  amount: number;
  type: 'DAILY_CLAIM' | 'OWNER_GRANT' | 'PACK_PURCHASE';
  reason: string;
  performedBy: string;
  cardId?: string;
  timestamp: string;
}

export interface CollectionSummary {
  totalCards: number;
  totalUnique: number;
  totalAvailableUnique: number;
  rarityCounts: Record<CardRarity, number>;
}
