export interface ServerBooster {
  userId: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  premiumSince: string;
  monthsBoosting: number;
}

export interface ServerAnalyticsData {
  serverName: string;
  guildId: string;
  timeframe: 'today' | 'week' | 'month';
  lastUpdated: string;
  boosters: ServerBooster[];
  overview: {
    totalMembers: number;
    onlineMembers: number;
    idleMembers: number;
    dndMembers: number;
    offlineMembers: number;
    activeStaffCount: number;
    boostTier: number;
    boostCount: number;
    pingMs: number;
    gatewayStatus: string;
    uptimePercent: number;
    verificationLevel: string;
    explicitContentFilter: string;
  };
  messages: {
    today: number;
    yesterday: number;
    growthTodayPercent: number;
    thisWeek: number;
    prevWeek: number;
    growthWeekPercent: number;
    thisMonth: number;
    velocityPerMinute: number;
    peakHours: string;
    hourlyToday: Array<{ hour: string; count: number }>;
    weeklyTrend: Array<{ day: string; count: number }>;
    monthlyTrend: Array<{ day: string; count: number }>;
    channelLeaderboard: Array<{
      id: string;
      name: string;
      messages: number;
      percentage: number;
      category: string;
    }>;
  };
  membersGrowth: {
    today: { joined: number; left: number; net: number; growthRate: string };
    week: { joined: number; left: number; net: number; growthRate: string };
    month: { joined: number; left: number; net: number; growthRate: string };
    retention7Day: number;
    retention30Day: number;
    joinLeaveRatio?: number;
    peakJoinDay?: string;
    peakJoinHour?: string;
    hourlyJoinsTrend?: Array<{ hour: string; joined: number; left: number }>;
    dailyJoinsTrend: Array<{ day: string; joined: number; left: number }>;
    monthlyJoinsTrend: Array<{ day: string; joined: number; left: number }>;
    topInviteSources: Array<{
      source: string;
      joins: number;
      percentage: number;
    }>;
  };
  voiceAndStreaming: {
    activeVoiceUsers: number;
    activeChannelsCount: number;
    totalVoiceHoursWeek: number;
    edgarStream: {
      isLive: boolean;
      title: string;
      viewers: number;
      startedAt: string;
      game: string;
    };
    voiceRooms: Array<{
      name: string;
      users: number;
      max: number;
      bitrate: string;
    }>;
  };
  moderation: {
    autoModBlockedLinksToday: number;
    autoModSpamFilteredToday: number;
    warningsIssuedToday: number;
    timeoutsIssuedToday: number;
    bansIssuedToday: number;
    avgResponseTimeSeconds: number;
    activeModeratorsOnDuty: Array<{
      name: string;
      role: string;
      status: 'online' | 'idle' | 'dnd';
      avatar: string;
    }>;
  };
  recentLiveEvents: Array<{
    id: string;
    type: 'JOIN' | 'MOD' | 'STREAM' | 'ROLE' | 'BOOST';
    message: string;
    time: string;
    icon: string;
  }>;
}
