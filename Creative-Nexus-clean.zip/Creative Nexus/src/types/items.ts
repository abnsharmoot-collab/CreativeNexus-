import { CardRarity } from './cards';

export type ItemCategory = 'BATTLE' | 'COMPANION' | 'UPGRADE_MATERIAL' | 'SPECIAL';

export type BattleItemEffectType = 
  | 'HEAL_HP'
  | 'RESTORE_STAMINA'
  | 'GRANT_SHIELD'
  | 'BUFF_ATTACK'
  | 'BUFF_DEFENSE';

export interface BattleItemEffectConfig {
  type: BattleItemEffectType;
  value: number; // e.g. +35 HP, +40 Stamina, +30 Shield, +25% Atk, +30% Def
  durationTurns?: number; // 0 for instant, 1-3 for temporary buffs
  consumesTurn?: boolean; // whether using item counts as player's round action or free instant action
  maxUsesPerBattle?: number; // limit e.g. 1 or 2 per battle
}

export interface UnifiedItemDefinition {
  id: string;
  name: string;
  nameAr?: string;
  description: string;
  descriptionAr?: string;
  imageUrl: string; // Transparent PNG / artwork URL
  rarity: CardRarity; // 'COMMON' | 'UNCOMMON' | 'RARE' | 'EPIC' | 'LEGENDARY' | 'HALLOWEEN_2026'
  category?: ItemCategory; // 'BATTLE' | 'COMPANION' | 'UPGRADE_MATERIAL' | 'SPECIAL'
  maxStack?: number; // default 99
  
  // Companion specific
  targetCharacterId?: string; // Specific character ID or 'ANY' for universal
  lovePoints?: number; // Affection points awarded (e.g. 20, 50, 100, 250)

  // Battle specific
  battleEffect?: BattleItemEffectConfig;

  // Package distribution (which packs can drop this item)
  packages: CardRarity[]; // e.g. ['COMMON', 'UNCOMMON', 'RARE', 'EPIC', 'LEGENDARY']
  dropWeight?: number; // 1 - 100 weight in pack drop roll

  isActive?: boolean; // whether item can drop or be used
  isCustom?: boolean;
  createdBy?: string;
  createdAt: string;
  updatedAt: string;
}

// User inventory item
export interface UserItemOwnership {
  itemId: string;
  count: number;
  firstAcquiredAt: string;
  lastAcquiredAt: string;
  itemData?: Partial<UnifiedItemDefinition>;
}

// Duplicate cards reward configuration
export type DuplicateRewardMode = 'CONVERT_TO_COINS' | 'UPGRADE_MATERIALS' | 'HYBRID_BOTH';

export interface DuplicateCardRewardConfig {
  enabled: boolean;
  mode: DuplicateRewardMode;
  coinsByRarity: Record<CardRarity, number>;
  materialsByRarity: Record<CardRarity, { itemId: string; count: number }>;
  updatedAt: string;
  updatedBy?: string;
}

export interface DuplicateRewardAwarded {
  mode: DuplicateRewardMode;
  coinsAwarded: number;
  materialsAwarded: {
    itemId: string;
    name: string;
    nameAr?: string;
    count: number;
    imageUrl?: string;
    rarity: CardRarity;
  }[];
  message: string;
  messageAr: string;
}

export const DEFAULT_DUPLICATE_REWARD_CONFIG: DuplicateCardRewardConfig = {
  enabled: true,
  mode: 'UPGRADE_MATERIALS',
  coinsByRarity: {
    COMMON: 0,
    UNCOMMON: 0,
    RARE: 0,
    EPIC: 0,
    LEGENDARY: 0,
    HALLOWEEN_2026: 0
  },
  materialsByRarity: {
    COMMON: { itemId: 'item_shard_common', count: 1 },
    UNCOMMON: { itemId: 'item_shard_uncommon', count: 1 },
    RARE: { itemId: 'item_shard_rare', count: 1 },
    EPIC: { itemId: 'item_shard_epic', count: 1 },
    LEGENDARY: { itemId: 'item_shard_legendary', count: 1 },
    HALLOWEEN_2026: { itemId: 'item_shard_universal', count: 2 }
  },
  updatedAt: new Date().toISOString()
};
