import { StaffMember } from './staff';
import { RankApplication } from './rankMap';

export type AchievementCategory = 
  | 'progression' 
  | 'points' 
  | 'activity' 
  | 'promotions' 
  | 'applications' 
  | 'special' 
  | 'sections'
  | 'packages'
  | 'cards'
  | 'community';

export interface AchievementCategoryInfo {
  id: AchievementCategory;
  name: string;
  nameAr: string;
  icon: string;
  badgeColor: string;
}

export interface RoleMultiplierInfo {
  multiplier: number;
  label: string;
  labelAr: string;
  badgeClass: string;
}

/**
 * Calculates the role coin doubler / multiplier based on user authority.
 * Strict boundary: Minimum 1.0x (Regular member), Maximum 3.0x (Owner / High Council Manager).
 * Progressively distributed across the staff ladder.
 */
export function getRoleCoinMultiplier(
  role?: string,
  staffRank?: string,
  isOwner?: boolean,
  staffPoints?: number
): RoleMultiplierInfo {
  // 1. Sovereign Owner / High Council Manager (Max 3.0x strictly)
  if (
    isOwner || 
    role === 'OWNER' || 
    staffRank === 'OWNER' || 
    staffRank === 'HIGH_COUNCIL_MANAGER' || 
    (typeof staffPoints === 'number' && staffPoints >= 280)
  ) {
    return {
      multiplier: 3.0,
      label: '3.0x Sovereign Owner Multiplier',
      labelAr: 'مضاعف المالك الأقصى 3.0x',
      badgeClass: 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-amber-500/20'
    };
  }

  // 2. High Council / Super Admin (2.75x)
  if (
    role === 'SUPER_ADMIN' || 
    staffRank === 'SUPER_ADMIN' || 
    (typeof staffPoints === 'number' && staffPoints >= 175)
  ) {
    return {
      multiplier: 2.75,
      label: '2.75x High Council Multiplier',
      labelAr: 'مضاعف المجلس الأعلى 2.75x',
      badgeClass: 'bg-purple-500/20 text-purple-200 border-purple-500/40 shadow-purple-500/20'
    };
  }

  // 3. Administrator / Senior Administrator (2.5x)
  if (
    role === 'ADMIN' || 
    role === 'ADMINISTRATOR' || 
    staffRank === 'ADMINISTRATOR' || 
    staffRank === 'SENIOR_ADMINISTRATOR'
  ) {
    return {
      multiplier: 2.5,
      label: '2.5x Administrator Multiplier',
      labelAr: 'مضاعف الإدارة العليا 2.5x',
      badgeClass: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40 shadow-indigo-500/20'
    };
  }

  // 4. Guard / Senior Moderator (2.0x)
  if (
    staffRank === 'SENIOR_MODERATOR' || 
    (typeof staffPoints === 'number' && staffPoints >= 95)
  ) {
    return {
      multiplier: 2.0,
      label: '2.0x Guard Multiplier',
      labelAr: 'مضاعف الحرس المعتمد 2.0x',
      badgeClass: 'bg-sky-500/20 text-sky-300 border-sky-500/40 shadow-sky-500/20'
    };
  }

  // 5. Moderator / Grand Staff (1.5x)
  if (
    role === 'MODERATOR' || 
    staffRank === 'MODERATOR' || 
    (typeof staffPoints === 'number' && staffPoints >= 52)
  ) {
    return {
      multiplier: 1.5,
      label: '1.5x Moderator Multiplier',
      labelAr: 'مضاعف المشرفين 1.5x',
      badgeClass: 'bg-teal-500/20 text-teal-300 border-teal-500/40 shadow-teal-500/20'
    };
  }

  // 6. Junior / Field Staff (1.25x)
  if (
    role === 'STAFF' || 
    staffRank === 'STAFF' || 
    (typeof staffPoints === 'number' && staffPoints > 0)
  ) {
    return {
      multiplier: 1.25,
      label: '1.25x Field Staff Multiplier',
      labelAr: 'مضاعف طاقم الإدارة 1.25x',
      badgeClass: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-emerald-500/20'
    };
  }

  // 7. Regular Member (1.0x Base)
  return {
    multiplier: 1.0,
    label: '1.0x Standard Rate',
    labelAr: 'المعدل القياسي 1.0x',
    badgeClass: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30'
  };
}

export interface AchievementEvaluationData {
  staffMember?: StaffMember;
  points: number;
  historyEventsCount: number;
  pointTransactionsCount: number;
  totalActionsCount: number;
  ownerPromotionCount: number;
  applicationsSubmittedCount: number;
  applicationsApprovedCount: number;
  isStaffRecognized: boolean;
  unlockedSections: {
    staff: boolean;
    grandStaff: boolean;
    guard: boolean;
    highCouncil: boolean;
  };
  completedSections: {
    staff: boolean;
    grandStaff: boolean;
    guard: boolean;
    highCouncil: boolean;
  };
  secretGameGoalReached?: boolean;
  secretGameSurvivalTime?: number;
  // --- Synchronized User Actions across Website and Card Packages ---
  totalPacksOpened: number;
  cardsOwnedCount: number;
  hasLegendaryCard: boolean;
  hasEpicCard: boolean;
  hasMythicCard: boolean;
  totalDailyClaims: number;
  hasFavoriteCard: boolean;
  hasShowcaseCards: boolean;
  hasCustomBanner: boolean;
  hasCustomTitle: boolean;
  handbookExplored: boolean;
  historyExplored: boolean;
  easterEggFound: boolean;
  coins: number;
}

export interface AchievementDefinition {
  id: string;
  number: number;
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  category: AchievementCategory;
  iconName: string;
  targetValue: number;
  unit: string;
  unitAr: string;
  theme?: 'cyan' | 'yellow' | 'purple' | 'white' | 'amber' | 'emerald' | 'indigo' | 'rose';
  coinReward?: number; // 1-5 coins for simple/medium, 30-80 for hard
  staffOnly?: boolean; // True for administrative achievements, false for everyone
  isHard?: boolean; // Highlights hard/legendary achievements
  evaluate: (data: AchievementEvaluationData) => {
    isUnlocked: boolean;
    currentProgress: number;
    maxProgress: number;
  };
}

export function getAchievementCoinReward(def: AchievementDefinition): number {
  if (typeof def.coinReward === 'number') return def.coinReward;

  // Specific high-difficulty mappings (Hard / So hard: 60 - 80 coins)
  if (
    def.id === 'special_the_summit' || 
    def.id === 'section_high_council_completed' || 
    def.id === 'card_celestial_sovereign' ||
    def.id === 'rank_high_council_section_complete' ||
    def.id === 'points_280'
  ) {
    return 80; // So hard maximum (80 coins)
  }
  if (def.id === 'special_secret_game_legend' || def.id === 'pack_sovereign') {
    return 75; // So hard (75 coins)
  }
  if (def.id === 'card_first_mythic') {
    return 70; // So hard (70 coins)
  }
  if (def.id === 'special_iraqi_flag_seeker' || def.id === 'activity_100') {
    return 65; // So hard (65 coins)
  }
  if (def.id === 'pack_master') {
    return 60; // Hard (60 coins)
  }

  // Medium difficulty (30 - 50 coins)
  if (
    def.id === 'card_grand_archivist' || 
    def.id === 'points_200' || 
    def.id === 'promo_elite' ||
    def.id === 'rank_high_council'
  ) {
    return 50; // Medium-High (50 coins)
  }
  if (
    def.id === 'section_guard_completed' || 
    def.id === 'special_the_council' ||
    def.id === 'rank_guardian_section_complete' ||
    def.id === 'points_150' ||
    def.id === 'card_first_legendary' ||
    def.id === 'app_climber'
  ) {
    return 45; // Medium (45 coins)
  }
  if (def.id === 'points_100') {
    return 40; // Medium (40 coins)
  }
  if (
    def.id === 'special_the_guard' || 
    def.id === 'section_grand_staff_completed' ||
    def.id === 'rank_guardian' ||
    def.id === 'rank_grand_staff_section_complete' ||
    def.id === 'promo_climbing' ||
    def.id === 'activity_50' ||
    def.id === 'card_master'
  ) {
    return 35; // Medium (35 coins)
  }
  if (
    def.id === 'points_50' || 
    def.id === 'app_patient' || 
    def.id === 'pack_enthusiast'
  ) {
    return 30; // Medium start (30 coins)
  }

  // Easy / Standard milestones (5 - 20 coins each)
  if (
    def.id === 'rank_grand_staff' || 
    def.id === 'activity_25' || 
    def.id === 'special_grand_entrance' ||
    def.id === 'section_staff_completed'
  ) {
    return 20; // 20 coins
  }
  if (
    def.id === 'card_adept' || 
    def.id === 'daily_streak' ||
    def.id === 'points_25'
  ) {
    return 18; // 18 coins
  }
  if (
    def.id === 'rank_rising_staff' || 
    def.id === 'promo_rising' || 
    def.id === 'app_approved' ||
    def.id === 'pack_collector_bronze' ||
    def.id === 'card_first_epic' ||
    def.id === 'profile_customizer_showcase'
  ) {
    return 15; // 15 coins
  }
  if (
    def.id === 'rank_point_collector' || 
    def.id === 'activity_10' || 
    def.id === 'special_rank_up' ||
    def.id === 'profile_device_banner'
  ) {
    return 12; // 12 coins
  }
  if (
    def.id === 'rank_first_step' || 
    def.id === 'promo_first' || 
    def.id === 'special_new_beginning' ||
    def.id === 'card_novice' ||
    def.id === 'profile_customizer_favorite' ||
    def.id === 'profile_title_equipped' ||
    def.id === 'handbook_scholar' ||
    def.id === 'history_explorer'
  ) {
    return 10; // 10 coins
  }
  if (
    def.id === 'points_10' || 
    def.id === 'app_first' || 
    def.id === 'pack_first_open' ||
    def.id === 'daily_first_claim'
  ) {
    return 8; // 8 coins
  }

  // Minimum fallback for any new missions: 5 coins
  return 5;
}

export interface UserAchievementDoc {
  discordId: string;
  unlocked: Record<string, string>; // achievementId -> ISO date
  seen: string[]; // array of achievement IDs already seen
  claimed?: Record<string, { claimedAt: string; baseCoins?: number; coinsAwarded: number; multiplier: number }>; // achievementId -> claim details
  updatedAt: string;
}

export const ACHIEVEMENT_CATEGORIES: AchievementCategoryInfo[] = [
  {
    id: 'packages',
    name: 'Card Packs',
    nameAr: 'حزم البطاقات',
    icon: '📦',
    badgeColor: 'border-amber-500/40 text-amber-300 bg-amber-950/40'
  },
  {
    id: 'cards',
    name: 'Card Vault',
    nameAr: 'مجموعة البطاقات',
    icon: '🃏',
    badgeColor: 'border-cyan-500/40 text-cyan-300 bg-cyan-950/40'
  },
  {
    id: 'community',
    name: 'Community & Portal',
    nameAr: 'المجتمع والموقع',
    icon: '🌐',
    badgeColor: 'border-emerald-500/40 text-emerald-300 bg-emerald-950/40'
  },
  {
    id: 'progression',
    name: 'Progression',
    nameAr: 'تدرج الرتب',
    icon: '🏆',
    badgeColor: 'border-cyan-500/40 text-cyan-300 bg-cyan-950/40'
  },
  {
    id: 'points',
    name: 'Points',
    nameAr: 'النقاط الإدارية',
    icon: '⭐',
    badgeColor: 'border-amber-500/40 text-amber-300 bg-amber-950/40'
  },
  {
    id: 'activity',
    name: 'Staff Activity',
    nameAr: 'نشاط الإدارة',
    icon: '🛡️',
    badgeColor: 'border-teal-500/40 text-teal-300 bg-teal-950/40'
  },
  {
    id: 'promotions',
    name: 'Promotions',
    nameAr: 'الترقيات المعتمدة',
    icon: '📈',
    badgeColor: 'border-indigo-500/40 text-indigo-300 bg-indigo-950/40'
  },
  {
    id: 'applications',
    name: 'Applications',
    nameAr: 'طلبات الترقية',
    icon: '📝',
    badgeColor: 'border-sky-500/40 text-sky-300 bg-sky-950/40'
  },
  {
    id: 'special',
    name: 'Special Feats',
    nameAr: 'إنجازات خاصة',
    icon: '👑',
    badgeColor: 'border-purple-500/40 text-purple-300 bg-purple-950/40'
  },
  {
    id: 'sections',
    name: 'Section Completion',
    nameAr: 'إكمال المراحل',
    icon: '🏛️',
    badgeColor: 'border-slate-300/50 text-white bg-slate-800/80'
  }
];

export function isStaffOnlyAchievement(def: AchievementDefinition): boolean {
  if (typeof def.staffOnly === 'boolean') return def.staffOnly;
  return ['progression', 'points', 'activity', 'promotions', 'applications', 'sections'].includes(def.category);
}

export const ALL_ACHIEVEMENTS: AchievementDefinition[] = [
  // ━━━━━━━━━━━━━━━━━━
  // RANK PROGRESSION ACHIEVEMENTS (1 - 10)
  // ━━━━━━━━━━━━━━━━━━
  {
    id: 'rank_first_step',
    number: 1,
    name: 'First Step',
    nameAr: 'الخطوة الأولى',
    description: 'Complete your first Staff action.',
    descriptionAr: 'أكمل أول إجراء أو نشاط إداري لك في السيرفر.',
    category: 'progression',
    iconName: 'Footprints',
    targetValue: 1,
    unit: 'action',
    unitAr: 'إجراء',
    theme: 'cyan',
    evaluate: (data) => ({
      isUnlocked: data.totalActionsCount >= 1,
      currentProgress: Math.min(1, data.totalActionsCount),
      maxProgress: 1
    })
  },
  {
    id: 'rank_point_collector',
    number: 2,
    name: 'Point Collector',
    nameAr: 'جامع النقاط',
    description: 'Reach 10 points.',
    descriptionAr: 'حقق 10 نقاط إدارية في رصيدك.',
    category: 'progression',
    iconName: 'Coins',
    targetValue: 10,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'cyan',
    evaluate: (data) => ({
      isUnlocked: data.points >= 10,
      currentProgress: Math.min(10, data.points),
      maxProgress: 10
    })
  },
  {
    id: 'rank_rising_staff',
    number: 3,
    name: 'Rising Staff',
    nameAr: 'إداري صاعد',
    description: 'Reach 25 points.',
    descriptionAr: 'حقق 25 نقطة واصعد في سلم التدرج الإداري.',
    category: 'progression',
    iconName: 'TrendingUp',
    targetValue: 25,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'cyan',
    evaluate: (data) => ({
      isUnlocked: data.points >= 25,
      currentProgress: Math.min(25, data.points),
      maxProgress: 25
    })
  },
  {
    id: 'rank_grand_staff',
    number: 4,
    name: 'Grand Staff',
    nameAr: 'جراند ستاف',
    description: 'Reach 60 points.',
    descriptionAr: 'حقق 60 نقطة وارتقِ في مسار جراند ستاف المرموق.',
    category: 'progression',
    iconName: 'Sparkles',
    targetValue: 60,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'yellow',
    evaluate: (data) => ({
      isUnlocked: data.points >= 60,
      currentProgress: Math.min(60, data.points),
      maxProgress: 60
    })
  },
  {
    id: 'rank_guardian',
    number: 5,
    name: 'Guardian',
    nameAr: 'الحارس المعتمد',
    description: 'Reach 95 points.',
    descriptionAr: 'حقق 95 نقطة وتأهل لمرحلة الحرس المخلصين.',
    category: 'progression',
    iconName: 'Shield',
    targetValue: 95,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'purple',
    evaluate: (data) => ({
      isUnlocked: data.points >= 95,
      currentProgress: Math.min(95, data.points),
      maxProgress: 95
    })
  },
  {
    id: 'rank_high_council',
    number: 6,
    name: 'High Council',
    nameAr: 'المجلس الأعلى',
    description: 'Reach 175 points.',
    descriptionAr: 'حقق 175 نقطة وادخل بوابة المجلس الأعلى.',
    category: 'progression',
    iconName: 'Crown',
    targetValue: 175,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'white',
    evaluate: (data) => ({
      isUnlocked: data.points >= 175,
      currentProgress: Math.min(175, data.points),
      maxProgress: 175
    })
  },
  {
    id: 'rank_staff_section_complete',
    number: 7,
    name: 'Staff Section Complete',
    nameAr: 'اكتمال مرحلة الإدارة',
    description: 'Complete the entire Staff section.',
    descriptionAr: 'أكمل مرحلة طاقم الإدارة بالكامل وتجاوز رتبة General Staff.',
    category: 'progression',
    iconName: 'CheckCheck',
    targetValue: 52,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'cyan',
    evaluate: (data) => ({
      isUnlocked: data.completedSections.staff,
      currentProgress: Math.min(52, data.points),
      maxProgress: 52
    })
  },
  {
    id: 'rank_grand_staff_section_complete',
    number: 8,
    name: 'Grand Staff Section Complete',
    nameAr: 'اكتمال مرحلة جراند ستاف',
    description: 'Complete the entire CN GRAND STAFF section.',
    descriptionAr: 'أكمل مرحلة جراند ستاف بالكامل وتجاوز رتبة Grand Staff Manager.',
    category: 'progression',
    iconName: 'Medal',
    targetValue: 95,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'yellow',
    evaluate: (data) => ({
      isUnlocked: data.completedSections.grandStaff,
      currentProgress: Math.min(95, data.points),
      maxProgress: 95
    })
  },
  {
    id: 'rank_guardian_section_complete',
    number: 9,
    name: 'Guardian Section Complete',
    nameAr: 'اكتمال مرحلة الحرس',
    description: 'Complete the entire CN GUARD section.',
    descriptionAr: 'أكمل مرحلة CN GUARD بالكامل وتجاوز رتبة Guardians Manager.',
    category: 'progression',
    iconName: 'ShieldCheck',
    targetValue: 175,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'purple',
    evaluate: (data) => ({
      isUnlocked: data.completedSections.guard,
      currentProgress: Math.min(175, data.points),
      maxProgress: 175
    })
  },
  {
    id: 'rank_high_council_section_complete',
    number: 10,
    name: 'High Council Section Complete',
    nameAr: 'اكتمال مرحلة المجلس الأعلى',
    description: 'Complete the entire CN HIGH COUNCIL section.',
    descriptionAr: 'أكمل مرحلة المجلس الأعلى وتصل إلى القمة القصوى (280 نقطة).',
    category: 'progression',
    iconName: 'Trophy',
    targetValue: 280,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'white',
    evaluate: (data) => ({
      isUnlocked: data.completedSections.highCouncil,
      currentProgress: Math.min(280, data.points),
      maxProgress: 280
    })
  },

  // ━━━━━━━━━━━━━━━━━━
  // PROMOTION ACHIEVEMENTS (11 - 14)
  // ━━━━━━━━━━━━━━━━━━
  {
    id: 'promo_first',
    number: 11,
    name: 'First Promotion',
    nameAr: 'أول ترقية معتمدة',
    description: 'Receive your first Owner-approved promotion.',
    descriptionAr: 'احصل على أول ترقية معتمدة وموثقة من مالك السيرفر.',
    category: 'promotions',
    iconName: 'Award',
    targetValue: 1,
    unit: 'promotion',
    unitAr: 'ترقية',
    theme: 'indigo',
    evaluate: (data) => ({
      isUnlocked: data.ownerPromotionCount >= 1,
      currentProgress: Math.min(1, data.ownerPromotionCount),
      maxProgress: 1
    })
  },
  {
    id: 'promo_rising',
    number: 12,
    name: 'Rising Through The Ranks',
    nameAr: 'صعود في السلّم',
    description: 'Receive 3 Owner-approved promotions.',
    descriptionAr: 'احصل على 3 ترقيات معتمدة من مالك السيرفر.',
    category: 'promotions',
    iconName: 'TrendingUp',
    targetValue: 3,
    unit: 'promotions',
    unitAr: 'ترقيات',
    theme: 'indigo',
    evaluate: (data) => ({
      isUnlocked: data.ownerPromotionCount >= 3,
      currentProgress: Math.min(3, data.ownerPromotionCount),
      maxProgress: 3
    })
  },
  {
    id: 'promo_climbing',
    number: 13,
    name: 'Climbing The Ladder',
    nameAr: 'تسلق القمة',
    description: 'Receive 5 Owner-approved promotions.',
    descriptionAr: 'احصل على 5 ترقيات رسمية وموثقة من مالك السيرفر.',
    category: 'promotions',
    iconName: 'Flame',
    targetValue: 5,
    unit: 'promotions',
    unitAr: 'ترقيات',
    theme: 'indigo',
    evaluate: (data) => ({
      isUnlocked: data.ownerPromotionCount >= 5,
      currentProgress: Math.min(5, data.ownerPromotionCount),
      maxProgress: 5
    })
  },
  {
    id: 'promo_elite',
    number: 14,
    name: 'Elite Progression',
    nameAr: 'تدرج النخبة',
    description: 'Receive 10 Owner-approved promotions.',
    descriptionAr: 'احصل على 10 ترقيات معتمدة من مالك السيرفر لتصل لمستوى النخبة.',
    category: 'promotions',
    iconName: 'Sparkles',
    targetValue: 10,
    unit: 'promotions',
    unitAr: 'ترقيات',
    theme: 'indigo',
    evaluate: (data) => ({
      isUnlocked: data.ownerPromotionCount >= 10,
      currentProgress: Math.min(10, data.ownerPromotionCount),
      maxProgress: 10
    })
  },

  // ━━━━━━━━━━━━━━━━━━
  // POINT ACHIEVEMENTS (15 - 21)
  // ━━━━━━━━━━━━━━━━━━
  {
    id: 'points_10',
    number: 15,
    name: '10 Points',
    nameAr: '10 نقاط',
    description: 'Reach 10 total points.',
    descriptionAr: 'اجمع 10 نقاط إجمالية في مسيرتك الإدارية.',
    category: 'points',
    iconName: 'Star',
    targetValue: 10,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'amber',
    evaluate: (data) => ({
      isUnlocked: data.points >= 10,
      currentProgress: Math.min(10, data.points),
      maxProgress: 10
    })
  },
  {
    id: 'points_25',
    number: 16,
    name: '25 Points',
    nameAr: '25 نقطة',
    description: 'Reach 25 total points.',
    descriptionAr: 'اجمع 25 نقطة إجمالية في رصيدك.',
    category: 'points',
    iconName: 'Zap',
    targetValue: 25,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'amber',
    evaluate: (data) => ({
      isUnlocked: data.points >= 25,
      currentProgress: Math.min(25, data.points),
      maxProgress: 25
    })
  },
  {
    id: 'points_50',
    number: 17,
    name: '50 Points',
    nameAr: '50 نقطة',
    description: 'Reach 50 total points.',
    descriptionAr: 'اجمع 50 نقطة واقترب من بوابة جراند ستاف.',
    category: 'points',
    iconName: 'Target',
    targetValue: 50,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'amber',
    evaluate: (data) => ({
      isUnlocked: data.points >= 50,
      currentProgress: Math.min(50, data.points),
      maxProgress: 50
    })
  },
  {
    id: 'points_100',
    number: 18,
    name: '100 Points',
    nameAr: '100 نقطة',
    description: 'Reach 100 total points.',
    descriptionAr: 'اجمع 100 نقطة واجتز حاجز المائة نقطة بامتياز.',
    category: 'points',
    iconName: 'Gem',
    targetValue: 100,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'amber',
    evaluate: (data) => ({
      isUnlocked: data.points >= 100,
      currentProgress: Math.min(100, data.points),
      maxProgress: 100
    })
  },
  {
    id: 'points_150',
    number: 19,
    name: '150 Points',
    nameAr: '150 نقطة',
    description: 'Reach 150 total points.',
    descriptionAr: 'اجمع 150 نقطة لتثبت التزامك الاستثنائي في السيرفر.',
    category: 'points',
    iconName: 'Flame',
    targetValue: 150,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'amber',
    evaluate: (data) => ({
      isUnlocked: data.points >= 150,
      currentProgress: Math.min(150, data.points),
      maxProgress: 150
    })
  },
  {
    id: 'points_200',
    number: 20,
    name: '200 Points',
    nameAr: '200 نقطة',
    description: 'Reach 200 total points.',
    descriptionAr: 'اجمع 200 نقطة وتجاوز المائتين في صفوة إداريي السيرفر.',
    category: 'points',
    iconName: 'Crown',
    targetValue: 200,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'amber',
    evaluate: (data) => ({
      isUnlocked: data.points >= 200,
      currentProgress: Math.min(200, data.points),
      maxProgress: 200
    })
  },
  {
    id: 'points_280',
    number: 21,
    name: '280 Points',
    nameAr: '280 نقطة — قمة المجلس',
    description: 'Reach 280 points and reach HIGH COUNCIL MANAGER eligibility.',
    descriptionAr: 'حقق 280 نقطة وتأهل لأعلى رتبة إدارية في السيرفر: High Council Manager.',
    category: 'points',
    iconName: 'Trophy',
    targetValue: 280,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'white',
    evaluate: (data) => ({
      isUnlocked: data.points >= 280,
      currentProgress: Math.min(280, data.points),
      maxProgress: 280
    })
  },

  // ━━━━━━━━━━━━━━━━━━
  // STAFF ACTIVITY ACHIEVEMENTS (22 - 26)
  // ━━━━━━━━━━━━━━━━━━
  {
    id: 'activity_first',
    number: 22,
    name: 'First Action',
    nameAr: 'العمل الإداري الأول',
    description: 'Complete your first recorded Staff action.',
    descriptionAr: 'سجّل أول نشاط إداري موثق في سجلات السيرفر.',
    category: 'activity',
    iconName: 'Activity',
    targetValue: 1,
    unit: 'action',
    unitAr: 'نشاط',
    theme: 'emerald',
    evaluate: (data) => ({
      isUnlocked: data.totalActionsCount >= 1,
      currentProgress: Math.min(1, data.totalActionsCount),
      maxProgress: 1
    })
  },
  {
    id: 'activity_10',
    number: 23,
    name: 'Active Staff',
    nameAr: 'إداري نشط',
    description: 'Complete 10 recorded Staff actions.',
    descriptionAr: 'أنجز 10 أنشطة إدارية مسجلة.',
    category: 'activity',
    iconName: 'CheckCircle2',
    targetValue: 10,
    unit: 'actions',
    unitAr: 'أنشطة',
    theme: 'emerald',
    evaluate: (data) => ({
      isUnlocked: data.totalActionsCount >= 10,
      currentProgress: Math.min(10, data.totalActionsCount),
      maxProgress: 10
    })
  },
  {
    id: 'activity_25',
    number: 24,
    name: 'Dedicated Staff',
    nameAr: 'إداري متفانٍ',
    description: 'Complete 25 recorded Staff actions.',
    descriptionAr: 'أنجز 25 نشاطاً إدارياً موثقاً بتفانٍ مستمر.',
    category: 'activity',
    iconName: 'ShieldAlert',
    targetValue: 25,
    unit: 'actions',
    unitAr: 'أنشطة',
    theme: 'emerald',
    evaluate: (data) => ({
      isUnlocked: data.totalActionsCount >= 25,
      currentProgress: Math.min(25, data.totalActionsCount),
      maxProgress: 25
    })
  },
  {
    id: 'activity_50',
    number: 25,
    name: 'Veteran Staff',
    nameAr: 'إداري متمرس',
    description: 'Complete 50 recorded Staff actions.',
    descriptionAr: 'أنجز 50 نشاطاً موثقاً لتثبت خبرتك كإداري خبير.',
    category: 'activity',
    iconName: 'ShieldCheck',
    targetValue: 50,
    unit: 'actions',
    unitAr: 'أنشطة',
    theme: 'emerald',
    evaluate: (data) => ({
      isUnlocked: data.totalActionsCount >= 50,
      currentProgress: Math.min(50, data.totalActionsCount),
      maxProgress: 50
    })
  },
  {
    id: 'activity_100',
    number: 26,
    name: 'Staff Veteran',
    nameAr: 'أسطورة النشاط الإداري',
    description: 'Complete 100 recorded Staff actions.',
    descriptionAr: 'أنجز 100 نشاط إداري مسجل لتصبح أسطورة معتمدة في النشاط.',
    category: 'activity',
    iconName: 'Award',
    targetValue: 100,
    unit: 'actions',
    unitAr: 'أنشطة',
    theme: 'emerald',
    evaluate: (data) => ({
      isUnlocked: data.totalActionsCount >= 100,
      currentProgress: Math.min(100, data.totalActionsCount),
      maxProgress: 100
    })
  },

  // ━━━━━━━━━━━━━━━━━━
  // APPLICATION ACHIEVEMENTS (27 - 30)
  // ━━━━━━━━━━━━━━━━━━
  {
    id: 'app_first',
    number: 27,
    name: 'First Application',
    nameAr: 'الطلب الأول',
    description: 'Submit your first rank application.',
    descriptionAr: 'قدّم أول طلب ترقية لك عبر نظام الرتب.',
    category: 'applications',
    iconName: 'FileText',
    targetValue: 1,
    unit: 'application',
    unitAr: 'طلب',
    theme: 'cyan',
    evaluate: (data) => ({
      isUnlocked: data.applicationsSubmittedCount >= 1,
      currentProgress: Math.min(1, data.applicationsSubmittedCount),
      maxProgress: 1
    })
  },
  {
    id: 'app_approved',
    number: 28,
    name: 'Approved',
    nameAr: 'طلب معتمد',
    description: 'Receive your first approved rank application.',
    descriptionAr: 'احصل على أول موافقة رسمية لطلب ترقيتك من المالك.',
    category: 'applications',
    iconName: 'CheckCircle',
    targetValue: 1,
    unit: 'approval',
    unitAr: 'موافقة',
    theme: 'cyan',
    evaluate: (data) => ({
      isUnlocked: data.applicationsApprovedCount >= 1,
      currentProgress: Math.min(1, data.applicationsApprovedCount),
      maxProgress: 1
    })
  },
  {
    id: 'app_patient',
    number: 29,
    name: 'Patient Progression',
    nameAr: 'صبر واستحقاق',
    description: 'Have 3 rank applications approved.',
    descriptionAr: 'احصل على 3 طلبات ترقية معتمدة بصبر واجتهاد.',
    category: 'applications',
    iconName: 'Hourglass',
    targetValue: 3,
    unit: 'approvals',
    unitAr: 'موافقات',
    theme: 'cyan',
    evaluate: (data) => ({
      isUnlocked: data.applicationsApprovedCount >= 3,
      currentProgress: Math.min(3, data.applicationsApprovedCount),
      maxProgress: 3
    })
  },
  {
    id: 'app_climber',
    number: 30,
    name: 'Climber',
    nameAr: 'المتسلق المتألق',
    description: 'Have 5 rank applications approved.',
    descriptionAr: 'احصل على 5 طلبات ترقية معتمدة وموثقة من الإدارة العليا.',
    category: 'applications',
    iconName: 'Mountain',
    targetValue: 5,
    unit: 'approvals',
    unitAr: 'موافقات',
    theme: 'cyan',
    evaluate: (data) => ({
      isUnlocked: data.applicationsApprovedCount >= 5,
      currentProgress: Math.min(5, data.applicationsApprovedCount),
      maxProgress: 5
    })
  },

  // ━━━━━━━━━━━━━━━━━━
  // SPECIAL ACHIEVEMENTS (31 - 36)
  // ━━━━━━━━━━━━━━━━━━
  {
    id: 'special_new_beginning',
    number: 31,
    name: 'New Beginning',
    nameAr: 'بداية جديدة',
    description: 'Become officially recognized as Staff for the first time.',
    descriptionAr: 'احصل على الاعتراف الرسمي كعضو في طاقم إدارة CREATINE NEXUS.',
    category: 'special',
    iconName: 'Compass',
    targetValue: 1,
    unit: 'status',
    unitAr: 'حالة',
    theme: 'purple',
    evaluate: (data) => ({
      isUnlocked: data.isStaffRecognized,
      currentProgress: data.isStaffRecognized ? 1 : 0,
      maxProgress: 1
    })
  },
  {
    id: 'special_rank_up',
    number: 32,
    name: 'Rank Up',
    nameAr: 'ارتقاء رتبة',
    description: 'Reach a new progression rank for the first time.',
    descriptionAr: 'ارتقِ إلى رتبة جديدة وتجاوز مستوى البداية بنجاح (5 نقاط أو أكثر).',
    category: 'special',
    iconName: 'ArrowUpRight',
    targetValue: 5,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'purple',
    evaluate: (data) => ({
      isUnlocked: data.points >= 5,
      currentProgress: Math.min(5, data.points),
      maxProgress: 5
    })
  },
  {
    id: 'special_grand_entrance',
    number: 33,
    name: 'Grand Entrance',
    nameAr: 'الدخول الكبير',
    description: 'Enter CN GRAND STAFF for the first time.',
    descriptionAr: 'ادخل مرحلة CN GRAND STAFF الذهبية لأول مرة (52 نقطة).',
    category: 'special',
    iconName: 'DoorOpen',
    targetValue: 52,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'yellow',
    evaluate: (data) => ({
      isUnlocked: data.points >= 52 || data.unlockedSections.grandStaff,
      currentProgress: Math.min(52, data.points),
      maxProgress: 52
    })
  },
  {
    id: 'special_the_guard',
    number: 34,
    name: 'The Guard',
    nameAr: 'صف الحرس',
    description: 'Enter CN GUARD for the first time.',
    descriptionAr: 'ادخل مرحلة CN GUARD البنفسجية لأول مرة (95 نقطة).',
    category: 'special',
    iconName: 'Shield',
    targetValue: 95,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'purple',
    evaluate: (data) => ({
      isUnlocked: data.points >= 95 || data.unlockedSections.guard,
      currentProgress: Math.min(95, data.points),
      maxProgress: 95
    })
  },
  {
    id: 'special_the_council',
    number: 35,
    name: 'The Council',
    nameAr: 'مجلس الكبار',
    description: 'Enter CN HIGH COUNCIL for the first time.',
    descriptionAr: 'ادخل مرحلة CN HIGH COUNCIL الملكية لأول مرة (175 نقطة).',
    category: 'special',
    iconName: 'Crown',
    targetValue: 175,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'white',
    evaluate: (data) => ({
      isUnlocked: data.points >= 175 || data.unlockedSections.highCouncil,
      currentProgress: Math.min(175, data.points),
      maxProgress: 175
    })
  },
  {
    id: 'special_the_summit',
    number: 36,
    name: 'The Summit',
    nameAr: 'قمة الهرم الإداري',
    description: 'Reach HIGH COUNCIL MANAGER eligibility at 280 points.',
    descriptionAr: 'وصل إلى قمة السيرفر الإدارية المؤهلة لأعلى رتبة: High Council Manager عند 280 نقطة.',
    category: 'special',
    iconName: 'MountainSnow',
    targetValue: 280,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'white',
    evaluate: (data) => ({
      isUnlocked: data.points >= 280,
      currentProgress: Math.min(280, data.points),
      maxProgress: 280
    })
  },
  {
    id: 'special_secret_game_legend',
    number: 41,
    name: 'Secret Game Legend',
    nameAr: 'أسطورة اللعبة السرية',
    description: 'Discover the hidden secret game and survive for 2:00 minutes.',
    descriptionAr: 'اعثر على اللعبة السرية في السيرفر واصمد فيها لمدة دقيقتين كاملتين.',
    category: 'special',
    iconName: 'Gamepad2',
    targetValue: 120,
    unit: 's',
    unitAr: 'ثانية',
    theme: 'amber',
    evaluate: (data) => ({
      isUnlocked: Boolean(data.secretGameGoalReached || (data.secretGameSurvivalTime && data.secretGameSurvivalTime >= 120)),
      currentProgress: Math.min(120, data.secretGameSurvivalTime || 0),
      maxProgress: 120
    })
  },

  // ━━━━━━━━━━━━━━━━━━
  // RANK SECTION ACHIEVEMENTS (37 - 40)
  // ━━━━━━━━━━━━━━━━━━
  {
    id: 'section_staff_completed',
    number: 37,
    name: 'Staff Completed',
    nameAr: 'إكمال قسم الإدارة',
    description: 'Complete the Staff progression section.',
    descriptionAr: 'إتمام كامل رتب قسم الإدارة وبلوغ عتبة فتح جراند ستاف.',
    category: 'sections',
    iconName: 'CheckCircle2',
    targetValue: 52,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'cyan',
    evaluate: (data) => ({
      isUnlocked: data.completedSections.staff,
      currentProgress: Math.min(52, data.points),
      maxProgress: 52
    })
  },
  {
    id: 'section_grand_staff_completed',
    number: 38,
    name: 'Grand Staff Completed',
    nameAr: 'إكمال قسم جراند ستاف',
    description: 'Complete CN GRAND STAFF.',
    descriptionAr: 'إتمام كامل رتب قسم جراند ستاف وبلوغ عتبة فتح الحرس.',
    category: 'sections',
    iconName: 'Award',
    targetValue: 95,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'yellow',
    evaluate: (data) => ({
      isUnlocked: data.completedSections.grandStaff,
      currentProgress: Math.min(95, data.points),
      maxProgress: 95
    })
  },
  {
    id: 'section_guard_completed',
    number: 39,
    name: 'Guard Completed',
    nameAr: 'إكمال قسم الحرس',
    description: 'Complete CN GUARD.',
    descriptionAr: 'إتمام كامل رتب قسم الحرس وبلوغ عتبة فتح المجلس الأعلى.',
    category: 'sections',
    iconName: 'ShieldCheck',
    targetValue: 175,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'purple',
    evaluate: (data) => ({
      isUnlocked: data.completedSections.guard,
      currentProgress: Math.min(175, data.points),
      maxProgress: 175
    })
  },
  {
    id: 'section_high_council_completed',
    number: 40,
    name: 'High Council Completed',
    nameAr: 'إكمال المجلس الأعلى',
    description: 'Complete CN HIGH COUNCIL.',
    descriptionAr: 'إتمام كامل رتب المجلس الأعلى وبلوغ ذروة الإدارة القصوى.',
    category: 'sections',
    iconName: 'Crown',
    targetValue: 280,
    unit: 'PTS',
    unitAr: 'نقطة',
    theme: 'white',
    evaluate: (data) => ({
      isUnlocked: data.completedSections.highCouncil,
      currentProgress: Math.min(280, data.points),
      maxProgress: 280
    })
  },

  // ━━━━━━━━━━━━━━━━━━
  // COMMUNITY, PACKAGE & CARD VAULT ACHIEVEMENTS (FOR EVERYONE) (42 - 62)
  // ━━━━━━━━━━━━━━━━━━
  {
    id: 'pack_first_open',
    number: 42,
    name: 'First Unboxing',
    nameAr: 'فتح أول حزمة',
    description: 'Open your very first collectible card pack in the Vault.',
    descriptionAr: 'افتح أول حزمة بطاقات قابلة للتجميع في خزانة السيرفر.',
    category: 'packages',
    iconName: 'Package',
    targetValue: 1,
    unit: 'pack',
    unitAr: 'حزمة',
    theme: 'amber',
    coinReward: 3,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: data.totalPacksOpened >= 1,
      currentProgress: Math.min(1, data.totalPacksOpened || 0),
      maxProgress: 1
    })
  },
  {
    id: 'pack_collector_bronze',
    number: 43,
    name: 'Bronze Unboxer',
    nameAr: 'جامع الحزم البرونزي',
    description: 'Open 5 collectible card packs.',
    descriptionAr: 'افتح 5 حزم بطاقات في خزانة البطاقات.',
    category: 'packages',
    iconName: 'PackageOpen',
    targetValue: 5,
    unit: 'packs',
    unitAr: 'حزم',
    theme: 'amber',
    coinReward: 5,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: data.totalPacksOpened >= 5,
      currentProgress: Math.min(5, data.totalPacksOpened || 0),
      maxProgress: 5
    })
  },
  {
    id: 'pack_enthusiast',
    number: 44,
    name: 'Vault Enthusiast',
    nameAr: 'عاشق الحزم الملكية',
    description: 'Open 15 collectible card packs.',
    descriptionAr: 'افتح 15 حزمة بطاقات ووسع أرشيفك الملكي.',
    category: 'packages',
    iconName: 'Sparkles',
    targetValue: 15,
    unit: 'packs',
    unitAr: 'حزم',
    theme: 'yellow',
    coinReward: 12,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: data.totalPacksOpened >= 15,
      currentProgress: Math.min(15, data.totalPacksOpened || 0),
      maxProgress: 15
    })
  },
  {
    id: 'pack_master',
    number: 45,
    name: 'Vault Unboxing Master',
    nameAr: 'سيد حزم البطاقات',
    description: 'Open 35 collectible card packs.',
    descriptionAr: 'افتح 35 حزمة بطاقات وكن خبيراً في صيد النوادر.',
    category: 'packages',
    iconName: 'Flame',
    targetValue: 35,
    unit: 'packs',
    unitAr: 'حزم',
    theme: 'purple',
    coinReward: 35,
    staffOnly: false,
    isHard: true,
    evaluate: (data) => ({
      isUnlocked: data.totalPacksOpened >= 35,
      currentProgress: Math.min(35, data.totalPacksOpened || 0),
      maxProgress: 35
    })
  },
  {
    id: 'pack_sovereign',
    number: 46,
    name: 'Babylonian Treasury',
    nameAr: 'خزائن بابل الأسطورية',
    description: 'Open 75 collectible card packs.',
    descriptionAr: 'افتح 75 حزمة بطاقات وامتلك ثروات بابل القديمة.',
    category: 'packages',
    iconName: 'Crown',
    targetValue: 75,
    unit: 'packs',
    unitAr: 'حزم',
    theme: 'white',
    coinReward: 70,
    staffOnly: false,
    isHard: true,
    evaluate: (data) => ({
      isUnlocked: data.totalPacksOpened >= 75,
      currentProgress: Math.min(75, data.totalPacksOpened || 0),
      maxProgress: 75
    })
  },
  {
    id: 'card_novice',
    number: 47,
    name: 'Card Collector Novice',
    nameAr: 'جامع بطاقات مبتدئ',
    description: 'Collect and own 5 distinct cards in your Card Vault.',
    descriptionAr: 'امتلك 5 بطاقات قابلة للتجميع في أرشيفك.',
    category: 'cards',
    iconName: 'Layers',
    targetValue: 5,
    unit: 'cards',
    unitAr: 'بطاقات',
    theme: 'cyan',
    coinReward: 3,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: data.cardsOwnedCount >= 5,
      currentProgress: Math.min(5, data.cardsOwnedCount || 0),
      maxProgress: 5
    })
  },
  {
    id: 'card_adept',
    number: 48,
    name: 'Card Collector Adept',
    nameAr: 'جامع بطاقات متقدم',
    description: 'Own 15 cards in your Card Vault collection.',
    descriptionAr: 'امتلك 15 بطاقة فريدة في خزانة البطاقات.',
    category: 'cards',
    iconName: 'Layers',
    targetValue: 15,
    unit: 'cards',
    unitAr: 'بطاقات',
    theme: 'cyan',
    coinReward: 5,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: data.cardsOwnedCount >= 15,
      currentProgress: Math.min(15, data.cardsOwnedCount || 0),
      maxProgress: 15
    })
  },
  {
    id: 'card_master',
    number: 49,
    name: 'Card Collector Master',
    nameAr: 'سيد أرشيف البطاقات',
    description: 'Own 30 cards in your Card Vault collection.',
    descriptionAr: 'امتلك 30 بطاقة وبلغ مرتبة الأساتذة في الجمع.',
    category: 'cards',
    iconName: 'Award',
    targetValue: 30,
    unit: 'cards',
    unitAr: 'بطاقات',
    theme: 'yellow',
    coinReward: 15,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: data.cardsOwnedCount >= 30,
      currentProgress: Math.min(30, data.cardsOwnedCount || 0),
      maxProgress: 30
    })
  },
  {
    id: 'card_grand_archivist',
    number: 50,
    name: 'Grand Archivist',
    nameAr: 'كبير الأرشيفيين الملكي',
    description: 'Own 50 cards in your Card Vault collection.',
    descriptionAr: 'امتلك 50 بطاقة وأحكم السيطرة على أرشيف المملكة.',
    category: 'cards',
    iconName: 'ShieldCheck',
    targetValue: 50,
    unit: 'cards',
    unitAr: 'بطاقات',
    theme: 'purple',
    coinReward: 50,
    staffOnly: false,
    isHard: true,
    evaluate: (data) => ({
      isUnlocked: data.cardsOwnedCount >= 50,
      currentProgress: Math.min(50, data.cardsOwnedCount || 0),
      maxProgress: 50
    })
  },
  {
    id: 'card_celestial_sovereign',
    number: 51,
    name: 'Celestial Sovereign',
    nameAr: 'العاهل السماوي المطلق',
    description: 'Own 100 cards in your Card Vault collection.',
    descriptionAr: 'امتلك 100 بطاقة وحقق أقصى أسطورة في جمع البطاقات.',
    category: 'cards',
    iconName: 'Crown',
    targetValue: 100,
    unit: 'cards',
    unitAr: 'بطاقات',
    theme: 'white',
    coinReward: 80,
    staffOnly: false,
    isHard: true,
    evaluate: (data) => ({
      isUnlocked: data.cardsOwnedCount >= 100,
      currentProgress: Math.min(100, data.cardsOwnedCount || 0),
      maxProgress: 100
    })
  },
  {
    id: 'card_first_epic',
    number: 52,
    name: 'Epic Discovery',
    nameAr: 'اكتشاف ملحمي',
    description: 'Pull or own at least 1 Epic rarity card.',
    descriptionAr: 'احصل على أول بطاقة نادرة من تصنيف EPIC الملحمي.',
    category: 'cards',
    iconName: 'Sparkles',
    targetValue: 1,
    unit: 'epic',
    unitAr: 'ملحمية',
    theme: 'purple',
    coinReward: 4,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: Boolean(data.hasEpicCard || data.hasLegendaryCard || data.hasMythicCard),
      currentProgress: (data.hasEpicCard || data.hasLegendaryCard || data.hasMythicCard) ? 1 : 0,
      maxProgress: 1
    })
  },
  {
    id: 'card_first_legendary',
    number: 53,
    name: 'Legendary Pulled',
    nameAr: 'سحب بطاقة أسطورية',
    description: 'Pull or own at least 1 Legendary rarity card.',
    descriptionAr: 'احصل على أول بطاقة أسطورية LEGENDARY ذهبية نادرة.',
    category: 'cards',
    iconName: 'Flame',
    targetValue: 1,
    unit: 'legendary',
    unitAr: 'أسطورية',
    theme: 'yellow',
    coinReward: 15,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: Boolean(data.hasLegendaryCard || data.hasMythicCard),
      currentProgress: (data.hasLegendaryCard || data.hasMythicCard) ? 1 : 0,
      maxProgress: 1
    })
  },
  {
    id: 'card_first_mythic',
    number: 54,
    name: 'Divine Sovereign Relic',
    nameAr: 'تحفة الملوك المعظمة',
    description: 'Own an elite Sovereign or Mythic power card.',
    descriptionAr: 'امتلك بطاقة سيادية فائقة القوة بتصنيف OVR 95 فما فوق.',
    category: 'cards',
    iconName: 'Crown',
    targetValue: 1,
    unit: 'relic',
    unitAr: 'تحفة',
    theme: 'white',
    coinReward: 35,
    staffOnly: false,
    isHard: true,
    evaluate: (data) => ({
      isUnlocked: Boolean(data.hasMythicCard),
      currentProgress: data.hasMythicCard ? 1 : 0,
      maxProgress: 1
    })
  },
  {
    id: 'daily_first_claim',
    number: 55,
    name: 'Daily Diligence',
    nameAr: 'مواظبة الخزينة اليومية',
    description: 'Claim your daily coin reward from the Card Vault.',
    descriptionAr: 'احصل على مكافأتك اليومية من العملات في خزانة البطاقات.',
    category: 'community',
    iconName: 'Coins',
    targetValue: 1,
    unit: 'claim',
    unitAr: 'استلام',
    theme: 'emerald',
    coinReward: 2,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: data.totalDailyClaims >= 1,
      currentProgress: Math.min(1, data.totalDailyClaims || 0),
      maxProgress: 1
    })
  },
  {
    id: 'daily_streak',
    number: 56,
    name: 'Treasury Devotion',
    nameAr: 'إخلاص الخزينة',
    description: 'Claim your daily coin rewards at least 5 times.',
    descriptionAr: 'استلم مكافأة الخزينة اليومية 5 مرات على الأقل.',
    category: 'community',
    iconName: 'Zap',
    targetValue: 5,
    unit: 'claims',
    unitAr: 'مرات',
    theme: 'emerald',
    coinReward: 6,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: data.totalDailyClaims >= 5,
      currentProgress: Math.min(5, data.totalDailyClaims || 0),
      maxProgress: 5
    })
  },
  {
    id: 'profile_customizer_favorite',
    number: 57,
    name: 'Signature Champion',
    nameAr: 'بطل الملف الشخصي',
    description: 'Feature a favorite card as your signature champion in Profile 2.0.',
    descriptionAr: 'عين بطاقتك المفضلة كبطل معتمد يزين واجهة ملفك الشخصي 2.0.',
    category: 'community',
    iconName: 'Heart',
    targetValue: 1,
    unit: 'favorite',
    unitAr: 'مفضلة',
    theme: 'rose',
    coinReward: 3,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: Boolean(data.hasFavoriteCard),
      currentProgress: data.hasFavoriteCard ? 1 : 0,
      maxProgress: 1
    })
  },
  {
    id: 'profile_customizer_showcase',
    number: 58,
    name: 'Showcase Curator',
    nameAr: 'منسق المعرض الملكي',
    description: 'Curate a full 5-card showcase in Profile 2.0.',
    descriptionAr: 'املأ خانات معرض البطاقات الخمس بالكامل في ملفك الشخصي.',
    category: 'community',
    iconName: 'LayoutGrid',
    targetValue: 1,
    unit: 'showcase',
    unitAr: 'معرض',
    theme: 'cyan',
    coinReward: 4,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: Boolean(data.hasShowcaseCards),
      currentProgress: data.hasShowcaseCards ? 1 : 0,
      maxProgress: 1
    })
  },
  {
    id: 'profile_device_banner',
    number: 59,
    name: 'Sanctuary Identity',
    nameAr: 'غلاف الملاذ المخصص',
    description: 'Upload a custom banner from your device or equip a sanctuary banner.',
    descriptionAr: 'ارفع غلافاً من جهازك أو اختر غلافاً مميزاً للملف الشخصي.',
    category: 'community',
    iconName: 'Image',
    targetValue: 1,
    unit: 'banner',
    unitAr: 'غلاف',
    theme: 'amber',
    coinReward: 5,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: Boolean(data.hasCustomBanner),
      currentProgress: data.hasCustomBanner ? 1 : 0,
      maxProgress: 1
    })
  },
  {
    id: 'profile_title_equipped',
    number: 60,
    name: 'Honored Epithet',
    nameAr: 'اللقب الشرفي',
    description: 'Equip an unlocked prestige title on your profile.',
    descriptionAr: 'فعل لقباً شرفياً يظهر بجوار اسمك في مختلف أقسام الموقع.',
    category: 'community',
    iconName: 'Award',
    targetValue: 1,
    unit: 'title',
    unitAr: 'لقب',
    theme: 'yellow',
    coinReward: 2,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: Boolean(data.hasCustomTitle),
      currentProgress: data.hasCustomTitle ? 1 : 0,
      maxProgress: 1
    })
  },
  {
    id: 'special_iraqi_flag_seeker',
    number: 61,
    name: 'Mesopotamian Seeker',
    nameAr: 'باحث الرموز العراقية',
    description: 'Discover the hidden Mesopotamian / Iraqi Flag easter egg.',
    descriptionAr: 'اعثر على بيضة العلم العراقي التراثية المخبأة في الملاذ.',
    category: 'special',
    iconName: 'Compass',
    targetValue: 1,
    unit: 'egg',
    unitAr: 'بيضة سرية',
    theme: 'amber',
    coinReward: 35,
    staffOnly: false,
    isHard: true,
    evaluate: (data) => ({
      isUnlocked: Boolean(data.easterEggFound),
      currentProgress: data.easterEggFound ? 1 : 0,
      maxProgress: 1
    })
  },
  {
    id: 'handbook_scholar',
    number: 62,
    name: 'Handbook Scholar',
    nameAr: 'عالم الدليل المنهجي',
    description: 'Explore the documentation, guides, or rules in the Codex.',
    descriptionAr: 'اطلع على كتب المعرفة والأدلة والقوانين في موسوعة السيرفر.',
    category: 'community',
    iconName: 'BookOpen',
    targetValue: 1,
    unit: 'book',
    unitAr: 'دليل',
    theme: 'cyan',
    coinReward: 3,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: Boolean(data.handbookExplored),
      currentProgress: data.handbookExplored ? 1 : 0,
      maxProgress: 1
    })
  },
  {
    id: 'history_explorer',
    number: 63,
    name: 'Mesopotamian Historian',
    nameAr: 'مؤرخ حضارة الرافدين',
    description: 'Explore the sanctuary history timeline, founding fathers, and eras.',
    descriptionAr: 'استكشف الجدول الزمني لتاريخ السيرفر، والمؤسسين، ومراحل الإبداع.',
    category: 'community',
    iconName: 'Shield',
    targetValue: 1,
    unit: 'era',
    unitAr: 'حقبة',
    theme: 'yellow',
    coinReward: 3,
    staffOnly: false,
    evaluate: (data) => ({
      isUnlocked: Boolean(data.historyExplored),
      currentProgress: data.historyExplored ? 1 : 0,
      maxProgress: 1
    })
  }
];
