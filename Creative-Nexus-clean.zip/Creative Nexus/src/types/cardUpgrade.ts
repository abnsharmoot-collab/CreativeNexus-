import { CardRarity, CardStatItem } from './cards';

export interface CardUpgradeTransitionRule {
  id: string; // e.g. 'COMMON_TO_UNCOMMON'
  fromRarity: CardRarity;
  toRarity: CardRarity;
  requiredDuplicates: number;  // Required duplicates of the SAME card (e.g. 1, 4, 2, etc.)
  requiredShardItemId: string; // e.g. 'item_shard_common'
  requiredShardCount: number;  // e.g. 1, 0 if none
  successRatePercent: number;  // e.g. 85 (85%), 50 (50%), etc.
  consumeShardsOnFailure: boolean; // default true
  consumeDuplicatesOnFailure?: boolean; // default false (or configurable)
  statMultiplier: number;      // e.g. 1.15 (15% boost)
  flatAttackBoost: number;     // e.g. 10
  flatDefenseBoost: number;    // e.g. 8
  flatHpBoost: number;         // e.g. 12
  description?: string;
  descriptionAr?: string;
}

export interface CardUpgradeSystemConfig {
  enabled: boolean;
  allowUniversalShards: boolean;
  universalShardItemId: string;
  legendaryMaxTierNotice?: string;
  legendaryMaxTierNoticeAr?: string;
  transitions: Record<string, CardUpgradeTransitionRule>;
  updatedAt: string;
  updatedBy?: string;
}

export interface CardUpgradeAttemptResult {
  success: boolean;
  cardId: string;
  cardName: string;
  cardNameAr?: string;
  previousRarity: CardRarity;
  newRarity: CardRarity;
  duplicatesConsumed: number;
  remainingDuplicates: number;
  shardsConsumed: number;
  consumedItemId: string;
  consumedItemName: string;
  remainingShardCount: number;
  roll: number;
  neededRoll: number;
  previousOvr: number;
  newOvr: number;
  updatedCard: {
    id: string;
    rarity: CardRarity;
    attack: number;
    defense: number;
    hp: number;
    overallRating: number;
    powerRating: number;
    stats: CardStatItem[];
    upgradeLevel: number;
  };
  message: string;
  messageAr: string;
}

export const RARITY_PROGRESSION: CardRarity[] = [
  'COMMON',
  'UNCOMMON',
  'RARE',
  'EPIC',
  'LEGENDARY'
];

export function getNextRarityTier(currentRarity: CardRarity): CardRarity | null {
  const idx = RARITY_PROGRESSION.indexOf(currentRarity);
  if (idx < 0 || idx >= RARITY_PROGRESSION.length - 1) {
    return null;
  }
  return RARITY_PROGRESSION[idx + 1];
}

export const DEFAULT_CARD_UPGRADE_CONFIG: CardUpgradeSystemConfig = {
  enabled: true,
  allowUniversalShards: true,
  universalShardItemId: 'item_shard_universal',
  legendaryMaxTierNotice: 'Legendary is the pinnacle rarity tier. Sovereign cards have attained maximum mastery and cannot be upgraded further.',
  legendaryMaxTierNoticeAr: 'الفئة الأسطورية هي ذروة القوة. بلغت البطاقات السيادية أقصى درجات الإتقان ولا يمكن ترقيتها لما هو أبعد.',
  updatedAt: new Date().toISOString(),
  transitions: {
    COMMON_TO_UNCOMMON: {
      id: 'COMMON_TO_UNCOMMON',
      fromRarity: 'COMMON',
      toRarity: 'UNCOMMON',
      requiredDuplicates: 1,
      requiredShardItemId: 'item_shard_common',
      requiredShardCount: 0,
      successRatePercent: 85,
      consumeShardsOnFailure: true,
      consumeDuplicatesOnFailure: false,
      statMultiplier: 1.15,
      flatAttackBoost: 10,
      flatDefenseBoost: 8,
      flatHpBoost: 12,
      description: 'Refines matrix with 1 duplicate copy to Uncommon tier (+15% power).',
      descriptionAr: 'يصقل مصفوفة البطاقة بنسخة مكررة واحدة إلى الفئة غير الشائعة (+15% قوة).'
    },
    UNCOMMON_TO_RARE: {
      id: 'UNCOMMON_TO_RARE',
      fromRarity: 'UNCOMMON',
      toRarity: 'RARE',
      requiredDuplicates: 4,
      requiredShardItemId: 'item_shard_uncommon',
      requiredShardCount: 0,
      successRatePercent: 50,
      consumeShardsOnFailure: true,
      consumeDuplicatesOnFailure: false,
      statMultiplier: 1.20,
      flatAttackBoost: 15,
      flatDefenseBoost: 12,
      flatHpBoost: 18,
      description: 'Infuses astral energy with 4 duplicate copies to ascend to Rare tier (+20% power).',
      descriptionAr: 'يشحن البطاقة بـ 4 نسخ مكررة لترقيتها إلى الفئة النادرة (+20% قوة).'
    },
    RARE_TO_EPIC: {
      id: 'RARE_TO_EPIC',
      fromRarity: 'RARE',
      toRarity: 'EPIC',
      requiredDuplicates: 2,
      requiredShardItemId: 'item_shard_rare',
      requiredShardCount: 1,
      successRatePercent: 25,
      consumeShardsOnFailure: true,
      consumeDuplicatesOnFailure: false,
      statMultiplier: 1.25,
      flatAttackBoost: 22,
      flatDefenseBoost: 18,
      flatHpBoost: 25,
      description: 'Forges hyperion chronocrystal with 2 duplicate copies + 1 Upgrade Shard to elevate to Epic (+25% power).',
      descriptionAr: 'يصهر بلورة هايبريون مع نسختين مكررتين وشظية ترقية للارتقاء إلى الفئة الملحمية (+25% قوة).'
    },
    EPIC_TO_LEGENDARY: {
      id: 'EPIC_TO_LEGENDARY',
      fromRarity: 'EPIC',
      toRarity: 'LEGENDARY',
      requiredDuplicates: 3,
      requiredShardItemId: 'item_shard_epic',
      requiredShardCount: 2,
      successRatePercent: 10,
      consumeShardsOnFailure: true,
      consumeDuplicatesOnFailure: false,
      statMultiplier: 1.30,
      flatAttackBoost: 30,
      flatDefenseBoost: 25,
      flatHpBoost: 35,
      description: 'Awakens sovereign divinity with 3 duplicate copies + 2 Epic Shards into Legendary tier (+30% power).',
      descriptionAr: 'يوقظ الجوهر السيادي بـ 3 نسخ مكررة وشظيتي ترقية ملحمية للارتقاء إلى الفئة الأسطورية (+30% قوة).'
    }
  }
};
