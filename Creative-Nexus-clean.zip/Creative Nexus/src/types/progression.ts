import { CardRarity, CollectibleCardData } from './cards';

export type TitleUnlockType =
  | 'DEFAULT'
  | 'CARDS_UNIQUE'
  | 'CARDS_TOTAL'
  | 'PACKS_OPENED'
  | 'LEGENDARY_OWNED'
  | 'LEVEL_REACHED'
  | 'SETS_COMPLETED';

export interface PlayerTitle {
  id: string;
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  rarity: CardRarity;
  unlockCondition: {
    type: TitleUnlockType;
    target: number;
  };
}

export type BadgeUnlockType =
  | 'DEFAULT'
  | 'PACKS_OPENED'
  | 'DAILY_CLAIM'
  | 'CARDS_UNIQUE'
  | 'CARDS_TOTAL'
  | 'LEGENDARY_OWNED'
  | 'LEVEL_REACHED'
  | 'COINS_HELD'
  | 'SETS_COMPLETED';

export type BadgeCategory = 'COLLECTION' | 'PACKS' | 'LEVEL' | 'RARITY' | 'ECONOMY' | 'DAILY_CLAIM' | 'SPECIAL';

export interface PlayerBadge {
  id: string;
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  icon: string;
  rarity: CardRarity;
  category: BadgeCategory;
  unlockCondition: {
    type: BadgeUnlockType;
    target: number;
  };
}

export interface LevelProgression {
  level: number;
  currentXp: number;
  currentLevelStartExp: number;
  nextLevelRequiredExp: number;
  xpIntoLevel: number;
  xpNeededForNextLevel: number;
  progressPercent: number;
}

export interface CollectionStatistics {
  totalCards: number;
  uniqueCards: number;
  legendaryCount: number;
  epicCount: number;
  rareCount: number;
  uncommonCount: number;
  commonCount: number;
  setsCompleted: number;
  packsOpened: number;
  coinsEarned: number;
  accountLevel: number;
}

export interface StaffModeratorInfo {
  isStaff: boolean;
  isModerator: boolean;
  rank: string; // e.g. 'MODERATOR', 'SENIOR_MODERATOR', 'ADMINISTRATOR', etc.
  rankName: string; // e.g. 'Senior Moderator' or Tier Name
  rankNameAr?: string;
  level: number; // Tier Level (e.g. 1 to 35)
  tierId: string;
  tierSection: string;
  tierSectionAr?: string;
  points: number;
  minPoints: number;
  maxPoints: number;
  progressPercent: number;
  nextTierName?: string;
  nextTierPoints?: number;
  status?: string;
  joinedAt?: string;
  notes?: string;
}

export interface PlayerProfileData {
  discordId: string;
  username: string;
  displayName: string;
  avatarUrl?: string;
  role?: 'OWNER' | 'SUPER_ADMIN' | 'ADMIN' | 'MODERATOR' | 'STAFF' | 'MEMBER';
  isOwner?: boolean;
  isStaff?: boolean;
  isModerator?: boolean;
  staffInfo?: StaffModeratorInfo | null;
  discordRoles?: string[];
  roleNames?: string[];
  joinedAt?: string;
  favoriteCardId?: string | null;
  favoriteCard?: CollectibleCardData | null;
  showcaseCardIds: string[];
  showcaseCards: CollectibleCardData[];
  selectedTitleId?: string | null;
  selectedTitle?: PlayerTitle | null;
  featuredBadgeIds: string[];
  featuredBadges: PlayerBadge[];
  level: number;
  xp: number;
  progression: LevelProgression;
  stats: CollectionStatistics;
  unlockedTitles: PlayerTitle[];
  allTitles: PlayerTitle[];
  unlockedBadges: PlayerBadge[];
  allBadges: PlayerBadge[];
  coins: number;
  canClaimDaily: boolean;
  nextDailyClaimAvailableAt?: string;
  cosmetics?: {
    profileFrame?: string;
    profileBackground?: string;
    nameplate?: string;
    cardBack?: string;
  };
  bannerUrl?: string | null;
}

export interface ProfileCustomizePayload {
  favoriteCardId?: string | null;
  showcaseCardIds?: string[];
  selectedTitleId?: string | null;
  featuredBadgeIds?: string[];
  bannerUrl?: string | null;
}
