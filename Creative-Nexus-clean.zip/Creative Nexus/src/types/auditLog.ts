export type AuditEventType =
  | 'AUTH_LOGIN'
  | 'AUTH_LOGOUT'
  | 'PAGE_VIEW'
  | 'CLICK'
  | 'INTERACTION'
  | 'ADMIN_ACTION'
  | 'SECURITY_EVENT';

export type AuditEventCategory =
  | 'AUTH'
  | 'NAVIGATION'
  | 'UI'
  | 'EASTER_EGG'
  | 'ADMIN'
  | 'STAFF'
  | 'ANNOUNCEMENTS'
  | 'APPLICATION'
  | 'GENERAL';

export interface AuditLogEntry {
  id: string;
  timestamp: string; // ISO string
  timestampMs: number;
  eventType: AuditEventType;
  action: string;
  category?: AuditEventCategory | string;
  details?: Record<string, any> | string;
  
  // User identity info
  userId: string; // Discord ID or 'guest_<visitorId>'
  username: string; // e.g. "kohan_official" or "Guest_a89f"
  displayName: string; // e.g. "Ahmed | Server Owner" or "Guest Visitor"
  avatarUrl?: string;
  role: 'OWNER' | 'SUPER_ADMIN' | 'ADMIN' | 'MODERATOR' | 'STAFF' | 'MEMBER' | 'GUEST';
  isGuest: boolean;
  
  // Contextual info
  path: string; // e.g. "/", "/staff-management", "/codex"
  targetElement?: string; // e.g. "Button: Sync Discord", "Card: Iraqi Flag"
  ip?: string;
  userAgent?: string;
}

export interface AuditLogStats {
  totalEvents: number;
  totalLogins: number;
  totalPageViews: number;
  totalInteractions: number;
  totalAdminActions: number;
  uniqueUsers: number;
  uniqueGuests: number;
  lastActiveTime?: string;
}

export interface AuditLogFilterOptions {
  eventType?: string;
  category?: string;
  userType?: 'all' | 'authenticated' | 'guests';
  searchQuery?: string;
  limit?: number;
}
