export interface UserEasterEggDoc {
  discordId: string;
  username?: string;
  displayName?: string;
  collectedFlagIds: string[];
  flagsCount: number;
  allFlagsDiscovered?: boolean;
  kohanRoomUnlocked: boolean;
  saddamBestTime?: number;
  saddamGameGoalReached?: boolean;
  saddamMissionCompleted?: boolean;
  finalRewardGranted?: boolean;
  secretKohanGameCompleted?: boolean;
  iraqiThemeUnlocked: boolean;
  iraqiThemeActive: boolean;
  activeTheme?: 'creative-nexus' | 'kohan-iraqi';
  claimedAt?: string;
  rewardClaimedAt?: string;
  updatedAt: string;
}

export interface CollectFlagResult {
  success: boolean;
  isNew: boolean;
  flagId: string;
  flagsCount: number;
  unlockedAll: boolean;
}

export type AppThemeType = 'creative-nexus' | 'kohan-iraqi';

export interface EasterEggContextType {
  // Easter Egg Collectibles: Iraqi Flags & Saddam Game Goal System
  collectedFlagIds: string[];
  flagsCount: number;
  totalFlags: number;
  kohanRoomUnlocked: boolean;
  saddamBestTime: number;
  saddamGameGoalReached: boolean;
  saddamMissionCompleted: boolean;
  finalRewardGranted: boolean;
  secretKohanGameCompleted: boolean;
  recordGameBestSurvival: (timeSecs: number) => Promise<void>;
  iraqiThemeUnlocked: boolean;
  iraqiThemeActive: boolean;
  activeTheme: AppThemeType;
  setActiveTheme: (theme: AppThemeType) => Promise<boolean>;
  isFlagCollected: (flagId: string) => boolean;
  collectFlag: (flagId: string) => Promise<CollectFlagResult>;
  toggleIraqiTheme: (active?: boolean) => Promise<void>;
  setThemePreference: (theme: AppThemeType) => Promise<boolean>;
  claimIraqiTheme: (overrideFlags?: string[], overrideBestTime?: number) => Promise<boolean>;
  resetFlagsProgress: () => Promise<void>;

  // Easter Egg #3: Kohan Secret Room Mini-Game
  isKohanGameOpen: boolean;
  setIsKohanGameOpen: (open: boolean) => void;

  // Secret Archive Revelation State (Only accessible when revealed by authenticated user)
  isSecretArchiveRevealed: boolean;
  revealSecretArchive: () => void;
  hideSecretArchive: () => void;

  // Secret Progress Panel & Overlays
  isSecretProgressOpen: boolean;
  setIsSecretProgressOpen: (open: boolean) => void;
  recentFlagCollected: { id: string; number: number } | null;
  dismissRecentFlagBanner: () => void;
  showUnlockCelebration: boolean;
  dismissUnlockCelebration: () => void;
  showThemeUnlockedOverlay: boolean;
  dismissThemeUnlockedOverlay: () => void;
}
