export type StaffRank = 'MODERATOR' | 'SENIOR_MODERATOR' | 'ADMINISTRATOR' | 'SENIOR_ADMINISTRATOR' | 'SUPER_ADMIN';
export type StaffStatus = 'ACTIVE' | 'SUSPENDED' | 'REMOVED';
export type StaffSortOption = 'POINTS_DESC' | 'POINTS_ASC' | 'NAME_ASC' | 'NAME_DESC' | 'JOINED_DESC' | 'JOINED_ASC';
export type StaffViewMode = 'grid' | 'table';

export interface StaffHistoryEvent {
  id: string | number;
  staffId: string | number;
  action: 'STAFF_ADDED' | 'STAFF_EDITED' | 'PROMOTED' | 'DEMOTED' | 'SUSPENDED' | 'REACTIVATED' | 'REMOVED' | 'POINTS_CHANGED';
  description: string;
  performedBy: string;
  createdAt: string;
}

export type PointTransactionType = 'ADD' | 'REMOVE';

export interface StaffPointTransaction {
  id: string | number;
  staffId: string | number;
  amount: number;
  type: PointTransactionType;
  reason: string;
  note: string | null;
  performedBy: string;
  createdAt: string;
}

export interface StaffMember {
  id: string | number;
  discordId: string;
  username: string;
  displayName: string;
  avatarUrl: string;
  rank: StaffRank;
  points: number;
  status: StaffStatus;
  joinedAt: string;
  updatedAt: string;
  notes: string | null;
  history?: StaffHistoryEvent[];
  pointTransactions?: StaffPointTransaction[];
}

export interface DiscordRole {
  id: string; // Discord Snowflake ID (Source of Truth)
  name: string;
  color: number;
  colorHex: string;
  position: number;
  permissions?: string;
  isMock?: boolean;
}

export interface StaffRolesConfig {
  guildId: string;
  guildOwnerId: string;
  serverName: string;
  staffRoleIds: string[]; // Source of Truth
  availableRoles: DiscordRole[];
  botConnected: boolean;
  isOwner: boolean;
  sourceOfTruth: 'DISCORD_ROLE_IDS';
}

