import { CollectibleCardData } from './cards';

export interface SynergyBreakdownItem {
  id: string;
  title: string;
  titleAr: string;
  desc: string;
  descAr: string;
  bonus: number;
  type: 'ELEMENT' | 'RARITY' | 'FORMATION' | 'TACTICAL';
}

export interface DeckStatsResult {
  power: number;
  defense: number;
  speed: number;
  synergy: number;
  synergyBreakdown: SynergyBreakdownItem[];
}

export interface PlayerDeck {
  id: string;
  userId: string;
  name: string;
  banner?: string;
  cardIds: string[]; // STRICT MAXIMUM 4 cards
  itemIds?: string[]; // Up to 4 chosen battle consumable items
  isActive: boolean;
  power: number;
  defense: number;
  speed: number;
  synergy: number;
  createdAt: string;
  updatedAt: string;
}

export interface DeckWithCards extends PlayerDeck {
  cards: CollectibleCardData[];
}

export const MAX_DECK_CARDS = 4;
export const MIN_DECK_CARDS = 1;
export const MAX_DECK_CONSUMABLES = 4;

/**
 * Deck visual identity banner presets
 */
export const DECK_BANNER_PRESETS = [
  { id: 'astral_void', name: 'Astral Void', nameAr: 'الفراغ النجمي', gradient: 'from-purple-900 via-indigo-950 to-slate-950', border: 'border-purple-500/40', accent: '#a855f7' },
  { id: 'solar_gold', name: 'Solar Sovereign', nameAr: 'السيادة الشمسية', gradient: 'from-amber-600 via-yellow-900 to-stone-950', border: 'border-amber-500/40', accent: '#f59e0b' },
  { id: 'emerald_matrix', name: 'Emerald Aegis', nameAr: 'الدرع الزمردي', gradient: 'from-emerald-700 via-teal-950 to-slate-950', border: 'border-emerald-500/40', accent: '#10b981' },
  { id: 'cyber_cyan', name: 'Cyber Chrono', nameAr: 'الكرونو السيبراني', gradient: 'from-cyan-700 via-blue-950 to-slate-950', border: 'border-cyan-500/40', accent: '#06b6d4' },
  { id: 'crimson_fury', name: 'Crimson Storm', nameAr: 'العاصفة القرمزية', gradient: 'from-rose-800 via-red-950 to-stone-950', border: 'border-rose-500/40', accent: '#f43f5e' }
];

/**
 * Calculate deck metrics strictly derived from existing card data with explainable synergy factors
 */
export function calculateDeckStats(cards: CollectibleCardData[]): DeckStatsResult {
  if (!cards || cards.length === 0) {
    return {
      power: 0,
      defense: 0,
      speed: 0,
      synergy: 0,
      synergyBreakdown: []
    };
  }

  // 1. Total Power
  const totalPower = cards.reduce((sum, c) => {
    const cardPower = typeof c.powerRating === 'number'
      ? c.powerRating
      : typeof c.power === 'number'
      ? c.power
      : (c.attack || 70);
    return sum + cardPower;
  }, 0);

  // 2. Total Defense
  const totalDefense = cards.reduce((sum, c) => sum + (c.defense || 65), 0);

  // 3. Total Speed
  const totalSpeed = cards.reduce((sum, c) => {
    const speedStat = c.stats?.find(
      s => s.id === 'speed' || s.name.toLowerCase().includes('agility') || s.name.toLowerCase().includes('speed')
    )?.value;
    return sum + (typeof speedStat === 'number' ? speedStat : 65);
  }, 0);

  // 4. Synergy analysis
  const synergyBreakdown: SynergyBreakdownItem[] = [];
  let synergyScore = 20;

  synergyBreakdown.push({
    id: 'syn_baseline',
    title: 'Core Vanguard Formation',
    titleAr: 'تشكيل الطليعة الأساسي',
    desc: 'Foundational 4-card matrix coherence.',
    descAr: 'ترابط مصفوفة البطاقات القتالية الأساسية.',
    bonus: 20,
    type: 'FORMATION'
  });

  // Element resonance
  const elementCounts: Record<string, number> = {};
  cards.forEach(c => {
    const el = c.element || 'STONE';
    elementCounts[el] = (elementCounts[el] || 0) + 1;
  });

  const maxSameElement = Math.max(...Object.values(elementCounts), 0);
  const dominantElement = Object.keys(elementCounts).find(k => elementCounts[k] === maxSameElement);
  const uniqueElements = Object.keys(elementCounts).length;

  if (maxSameElement === 4) {
    synergyScore += 40;
    synergyBreakdown.push({
      id: 'syn_mono_element',
      title: `${dominantElement} Pure Harmonic Resonance`,
      titleAr: `تناغم عنصري تام (${dominantElement})`,
      desc: 'All 4 cards share identical elemental affinity, amplifying kinetic conduits.',
      descAr: 'كافة البطاقات الأربع تتشارك نفس العنصر مما يعزز تدفق الطاقة الحركية.',
      bonus: 40,
      type: 'ELEMENT'
    });
  } else if (maxSameElement === 3) {
    synergyScore += 26;
    synergyBreakdown.push({
      id: 'syn_tri_element',
      title: `${dominantElement} Triad Dominance`,
      titleAr: `سيادة ثلاثية العناصر (${dominantElement})`,
      desc: 'Three aligned elements provide strong formation reinforcement.',
      descAr: 'ثلاث بطاقات من نفس العنصر توفر تدريعاً متماسكاً للتشكيلة.',
      bonus: 26,
      type: 'ELEMENT'
    });
  } else if (maxSameElement === 2) {
    synergyScore += 16;
    synergyBreakdown.push({
      id: 'syn_dual_element',
      title: 'Dual Conduit Synchronization',
      titleAr: 'تزامن عنصري ثنائي',
      desc: 'Two paired elements channel complementary kinetic power.',
      descAr: 'بطاقتان من نفس العنصر تُنشئان قناة طاقة متكاملة.',
      bonus: 16,
      type: 'ELEMENT'
    });
  }

  if (uniqueElements === 4) {
    synergyScore += 30;
    synergyBreakdown.push({
      id: 'syn_rainbow_spectrum',
      title: 'Spectrum Versatility Harmony',
      titleAr: 'تناغم الطيف المتعدد الشامل',
      desc: 'Four diverse elements provide tactical flexibility against hostile shields.',
      descAr: 'أربعة عناصر متنوعة تمنح مرونة تكتيكية عالية لاختراق دروع العدو.',
      bonus: 30,
      type: 'TACTICAL'
    });
  }

  // Rarity synergy: Legendary commander bonus
  const hasLegendary = cards.some(c => c.rarity === 'LEGENDARY');
  const hasEpic = cards.some(c => c.rarity === 'EPIC');

  if (hasLegendary) {
    synergyScore += 14;
    synergyBreakdown.push({
      id: 'syn_legendary_lead',
      title: 'Legendary Archon Leadership',
      titleAr: 'قيادة بطولية أسطورية',
      desc: 'Presence of a Legendary vanguard anchors squad morale.',
      descAr: 'وجود بطاقة أسطورية يرفع من عزيمة وتماسك الفريق.',
      bonus: 14,
      type: 'RARITY'
    });
  }

  if (hasEpic) {
    synergyScore += 8;
    synergyBreakdown.push({
      id: 'syn_epic_empower',
      title: 'Epic Resonance Field',
      titleAr: 'حقل الرنين الملحمي',
      desc: 'High-tier cyber-relic stabilizes ability cooldown harmonics.',
      descAr: 'بطاقة ملحمية تُثبت توافق دورات القدرات الخاصة.',
      bonus: 8,
      type: 'RARITY'
    });
  }

  // Full 4-card quad formation bonus
  if (cards.length === 4) {
    synergyScore += 10;
    synergyBreakdown.push({
      id: 'syn_full_quad',
      title: 'Complete 4-Card Vanguard',
      titleAr: 'تشكيل رباعي كامل (4/4)',
      desc: 'Full battle squad deployed for maximum tactical presence.',
      descAr: 'نشر كامل لـ 4 بطاقات يمنح حضوراً ميدانياً شاملاً.',
      bonus: 10,
      type: 'FORMATION'
    });
  }

  return {
    power: totalPower,
    defense: totalDefense,
    speed: totalSpeed,
    synergy: Math.min(100, synergyScore),
    synergyBreakdown
  };
}
