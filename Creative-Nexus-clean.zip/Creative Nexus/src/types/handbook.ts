import React from 'react';

export interface HandbookChapter {
  id: string;
  chapterNumber: string;
  titleEn: string;
  titleAr: string;
  subtitleEn?: string;
  subtitleAr?: string;
  readingTimeMinutes: number;
}

export interface HandbookBook {
  id: string;
  bookNumber: string; // e.g., "GUIDE 01"
  titleEn: string;
  titleAr: string;
  subtitleEn: string;
  subtitleAr: string;
  descriptionEn: string;
  descriptionAr: string;
  iconName: string;
  accentColor: 'cyan' | 'amber' | 'purple' | 'emerald' | 'blue' | 'rose' | 'indigo' | 'sky';
  gradient: string;
  borderColor: string;
  tagEn: string;
  tagAr: string;
  chapters: HandbookChapter[];
  relatedPath?: string;
  requiresAuthRole?: boolean;
}
