export type CardRarity = 'COMMON' | 'UNCOMMON' | 'RARE' | 'EPIC' | 'LEGENDARY' | 'HALLOWEEN_2026';

export type CardElement = 'STONE' | 'FIRE' | 'STORM' | 'ASTRAL' | 'WATER';

export type AbilityCategory =
  | 'PASSIVE'
  | 'ACTIVE'
  | 'TRIGGERED'
  | 'TRIGGER'
  | 'OFFENSIVE'
  | 'DEFENSIVE'
  | 'UTILITY'
  | 'ULTIMATE';

// Retain AbilityType alias for backwards-compatibility
export type AbilityType = AbilityCategory;

export interface CardAbility {
  id: string;
  name: string;
  description: string;
  type: AbilityCategory;
  value?: number;
  duration?: number; // in turns or seconds
  cooldown?: number; // in turns
  trigger?: string; // e.g. "On Summon", "When Health < 30%", "Turn Start"
  target?: string; // e.g. "Self", "Single Enemy", "All Allies"
  enabled?: boolean;
  cost?: number; // energy/action cost
  powerValue?: number;
}

// ----------------------------------------------------
// EXTENSIBLE CARD STATS SYSTEM
// ----------------------------------------------------
export interface CardStatItem {
  id: string;
  name: string; // e.g. "Attack", "Defense", "Speed", "Wisdom", "Vitality", etc.
  value: number; // 0 - 100
  maxValue?: number;
  icon?: string; // e.g. "swords" | "shield" | "heart" | "zap" | "flame" | "sparkles" | "crown" | "star"
  color?: string; // hex color for stat badge/bar
}

export interface GlobalCardStatDefinition {
  id: string;
  name: string;
  defaultValue: number;
  maxValue?: number;
  icon: string;
  color: string;
  description?: string;
}

export const DEFAULT_GLOBAL_CARD_STATS: GlobalCardStatDefinition[] = [
  { id: 'attack', name: 'Attack', defaultValue: 75, maxValue: 100, icon: 'swords', color: '#f43f5e', description: 'Offensive striking capability' },
  { id: 'defense', name: 'Defense', defaultValue: 70, maxValue: 100, icon: 'shield', color: '#06b6d4', description: 'Kinetic armor and barrier shielding' },
  { id: 'hp', name: 'Vitality', defaultValue: 80, maxValue: 100, icon: 'heart', color: '#10b981', description: 'Endurance and life reserve' },
  { id: 'speed', name: 'Agility', defaultValue: 65, maxValue: 100, icon: 'zap', color: '#f59e0b', description: 'Turn initiative and evasion' },
  { id: 'intelligence', name: 'Wisdom', defaultValue: 75, maxValue: 100, icon: 'sparkles', color: '#a855f7', description: 'Astral arcane focus and cooldown recovery' }
];

export const DEFAULT_CARD_STATS: CardStatItem[] = [
  { id: 'attack', name: 'Attack', value: 75, maxValue: 100, icon: 'swords', color: '#f43f5e' },
  { id: 'defense', name: 'Defense', value: 70, maxValue: 100, icon: 'shield', color: '#06b6d4' },
  { id: 'hp', name: 'Vitality', value: 80, maxValue: 100, icon: 'heart', color: '#10b981' },
  { id: 'speed', name: 'Agility', value: 65, maxValue: 100, icon: 'zap', color: '#f59e0b' },
  { id: 'intelligence', name: 'Wisdom', value: 75, maxValue: 100, icon: 'sparkles', color: '#a855f7' }
];

export function getDefaultCardStats(initialAttack = 75, initialDefense = 70, initialHp = 80): CardStatItem[] {
  const safeAtk = initialAttack > 100 ? Math.round(initialAttack / 10) : initialAttack;
  const safeDef = initialDefense > 100 ? Math.round(initialDefense / 10) : initialDefense;
  const safeHp = initialHp > 100 ? Math.round(initialHp / 10) : initialHp;
  return [
    { id: 'attack', name: 'Attack', value: Math.min(100, Math.max(10, safeAtk)), maxValue: 100, icon: 'swords', color: '#f43f5e' },
    { id: 'defense', name: 'Defense', value: Math.min(100, Math.max(10, safeDef)), maxValue: 100, icon: 'shield', color: '#06b6d4' },
    { id: 'hp', name: 'Vitality', value: Math.min(100, Math.max(10, safeHp)), maxValue: 100, icon: 'heart', color: '#10b981' },
    { id: 'speed', name: 'Agility', value: 65, maxValue: 100, icon: 'zap', color: '#f59e0b' },
    { id: 'intelligence', name: 'Wisdom', value: 75, maxValue: 100, icon: 'sparkles', color: '#a855f7' }
  ];
}

// ----------------------------------------------------
// UNIFIED CARD STATS EXTRACTION & RECOVERY
// ----------------------------------------------------
export function getUnifiedCardStats(card?: Partial<CollectibleCardData> | null): CardStatItem[] {
  if (!card) return getDefaultCardStats();

  // If card already has a populated unified stats array, use it
  if (Array.isArray(card.stats) && card.stats.length > 0) {
    return card.stats.map(s => ({
      id: s.id || `stat-${Math.random().toString(36).slice(2, 7)}`,
      name: s.name || 'Stat',
      value: Math.min(100, Math.max(0, s.value > 100 ? Math.round(s.value / 10) : (s.value ?? 50))),
      maxValue: s.maxValue || 100,
      icon: s.icon || 'zap',
      color: s.color || '#f59e0b'
    }));
  }

  // If customStats is present, use it
  if (Array.isArray(card.customStats) && card.customStats.length > 0) {
    return card.customStats.map(s => ({
      id: s.id || `stat-${Math.random().toString(36).slice(2, 7)}`,
      name: s.name || 'Stat',
      value: Math.min(100, Math.max(0, s.value > 100 ? Math.round(s.value / 10) : (s.value ?? 50))),
      maxValue: s.maxValue || 100,
      icon: s.icon || 'zap',
      color: s.color || '#f59e0b'
    }));
  }

  // Otherwise, construct standard unified stats from attack, defense, hp
  const atk = typeof card.attack === 'number' ? (card.attack > 100 ? Math.round(card.attack / 10) : card.attack) : 75;
  const def = typeof card.defense === 'number' ? (card.defense > 100 ? Math.round(card.defense / 10) : card.defense) : 70;
  const hp = typeof card.hp === 'number' ? (card.hp > 100 ? Math.round(card.hp / 10) : card.hp) : 80;

  return getDefaultCardStats(atk, def, hp);
}

// ----------------------------------------------------
// DYNAMIC OVERALL (OVR) RATING CALCULATION (0 - 100 SCALE)
// ----------------------------------------------------
export function calculateCardOverallRating(stats?: CardStatItem[], rarity: CardRarity = 'COMMON'): number {
  if (!stats || stats.length === 0) {
    const baseRarity: Record<CardRarity, number> = {
      COMMON: 68,
      UNCOMMON: 76,
      RARE: 84,
      EPIC: 91,
      LEGENDARY: 98,
      HALLOWEEN_2026: 99
    };
    return baseRarity[rarity] || 75;
  }
  const sum = stats.reduce((acc, s) => acc + (typeof s.value === 'number' ? s.value : 50), 0);
  const avg = sum / stats.length;
  const rarityBonus: Record<CardRarity, number> = {
    COMMON: 0,
    UNCOMMON: 2,
    RARE: 4,
    EPIC: 7,
    LEGENDARY: 10,
    HALLOWEEN_2026: 12
  };
  return Math.min(100, Math.max(10, Math.round(avg * 0.92 + (rarityBonus[rarity] || 0))));
}

// ----------------------------------------------------
// DYNAMIC POWER RATING CALCULATION (0 - 100 SCALE)
// ----------------------------------------------------
export function calculateCardPowerRating(
  stats?: CardStatItem[],
  rarity: CardRarity = 'COMMON',
  abilitiesCount = 0
): number {
  if (!stats || stats.length === 0) {
    const baseRarity: Record<CardRarity, number> = {
      COMMON: 48,
      UNCOMMON: 62,
      RARE: 75,
      EPIC: 88,
      LEGENDARY: 98,
      HALLOWEEN_2026: 99
    };
    return baseRarity[rarity] || 50;
  }

  // Calculate normalized stat ratio (0 - 1.0)
  const totalRatio = stats.reduce((acc, s) => {
    const max = s.maxValue && s.maxValue > 0 ? s.maxValue : 100;
    const ratio = Math.max(0, Math.min(1.0, (s.value || 0) / max));
    return acc + ratio;
  }, 0);

  const avgNormalizedStat = (totalRatio / stats.length) * 100; // 0 - 100 scale

  // Rarity weighting & base floors on 0 - 100 scale
  const rarityConfig: Record<CardRarity, { base: number; multiplier: number }> = {
    COMMON: { base: 30, multiplier: 0.32 },
    UNCOMMON: { base: 45, multiplier: 0.40 },
    RARE: { base: 60, multiplier: 0.48 },
    EPIC: { base: 74, multiplier: 0.58 },
    LEGENDARY: { base: 88, multiplier: 0.72 },
    HALLOWEEN_2026: { base: 92, multiplier: 0.78 }
  };

  const { base, multiplier } = rarityConfig[rarity] || rarityConfig.COMMON;
  const abilityWeight = Math.min(8, abilitiesCount * 2);

  const calculated = Math.round(base + (avgNormalizedStat * multiplier * 0.14) + abilityWeight);
  return Math.max(10, Math.min(100, calculated));
}

// ----------------------------------------------------
// TEMPORARY CARD STATES (GAMEPLAY ARCHITECTURE)
// ----------------------------------------------------
export type CardStateType =
  | 'NORMAL'
  | 'BUFFED'
  | 'DEBUFFED'
  | 'STUNNED'
  | 'PROTECTED'
  | 'EXHAUSTED'
  | 'HIDDEN'
  | 'ENRAGED';

export interface CardStateItem {
  id: string;
  name: CardStateType | string;
  duration: number; // in turns or rounds (0 = permanent until cleansed)
  effect: string;
  value?: number;
  source?: string;
  active: boolean;
}

export const CARD_STATE_PRESETS: { type: CardStateType; label: string; defaultEffect: string; color: string }[] = [
  { type: 'NORMAL', label: 'Normal', defaultEffect: 'Standard baseline combat state.', color: 'text-slate-300' },
  { type: 'BUFFED', label: 'Buffed', defaultEffect: 'Stats increased by divine/technological matrix.', color: 'text-amber-300' },
  { type: 'DEBUFFED', label: 'Debuffed', defaultEffect: 'Attributes suppressed by enemy anomaly.', color: 'text-purple-300' },
  { type: 'STUNNED', label: 'Stunned', defaultEffect: 'Unable to cast active abilities for turn duration.', color: 'text-yellow-300' },
  { type: 'PROTECTED', label: 'Protected', defaultEffect: 'Absorbs next instances of direct damage.', color: 'text-emerald-300' },
  { type: 'EXHAUSTED', label: 'Exhausted', defaultEffect: 'Energy reserves depleted; doubled cooldowns.', color: 'text-rose-300' },
  { type: 'HIDDEN', label: 'Hidden', defaultEffect: 'Untargetable by single-target hostile protocols.', color: 'text-cyan-300' },
  { type: 'ENRAGED', label: 'Enraged', defaultEffect: 'Massive power boost at the expense of defenses.', color: 'text-orange-400' }
];

export type CardFoilStyle =
  | 'standard'
  | 'holographic'
  | 'cosmic'
  | 'gold_embossed'
  | 'prismatic_crystal'
  | 'cyber_matrix'
  | 'astral_supernova'
  | 'aurora_emerald'
  | 'crimson_inferno'
  | 'obsidian_mirror'
  | 'halloween_specter';

export type HolographicBehavior =
  | 'none'
  | 'diagonal_sweep'
  | 'horizontal_sweep'
  | 'vertical_sweep'
  | 'prismatic_shift'
  | 'iridescent_flow'
  | 'radial_gleam'
  | 'edge_shimmer'
  | 'holographic_wave'
  | 'full_foil';

export type FoilIntensity = 'low' | 'medium' | 'high' | 'ultra';

export type CardFrameStyle =
  | 'auto'
  | 'ornate_legendary'
  | 'crystal_epic'
  | 'runic_rare'
  | 'cyber_sleek'
  | 'mesopotamian_gold'
  | 'minimalist'
  | 'halloween_spectral';

export type CardCornerStyle =
  | 'auto'
  | 'wings'
  | 'gems'
  | 'runes'
  | 'claws'
  | 'mesopotamian'
  | 'minimal'
  | 'none';

export type CardGlowIntensity = 'none' | 'subtle' | 'radiant' | 'blazing' | 'celestial';

export type CardBackgroundTheme =
  | 'auto'
  | 'dark_slate'
  | 'deep_obsidian'
  | 'void_nebula'
  | 'ancient_gold'
  | 'emerald_marble';

export interface CollectibleCardData {
  id: string;
  name: string;
  title: string;
  rarity: CardRarity;
  packType: CardRarity;
  cardType?: string; // e.g. "Warrior", "Relic", "Archon", "Spell", "Entity", "Commander"
  description: string;
  lore: string;
  imageUrl: string;
  attack: number;
  defense: number;
  hp: number;
  element: CardElement;
  power: number; // Legacy or calculated power
  powerRating?: number; // Calculated dynamic power rating
  overallRating?: number; // Overall rating (OVR)
  stats?: CardStatItem[]; // Unified stats list
  customStats?: CardStatItem[]; // Flexible numerical stats
  abilities?: CardAbility[];
  cardStates?: CardStateItem[]; // Structured temporary card states
  states?: CardStateItem[]; // Active states list
  series: string;
  cardNumber: number;
  accentColor: string;
  foilStyle?: CardFoilStyle;
  foilColor?: string; // Custom specular reflection color
  foilIntensity?: FoilIntensity; // 'low' | 'medium' | 'high' | 'ultra'
  foilOpacity?: number; // 0 - 100 percentage
  holographicBehavior?: HolographicBehavior;
  reflectionStrength?: number; // 0 - 100
  reflectionSpeed?: number; // 0.5 - 2.0 speed multiplier
  reflectionWidth?: number; // 10 - 100 percentage
  reflectionAngle?: number; // deg
  surfaceShine?: number; // 0 - 100
  metallicStrength?: number; // 0 - 100
  edgeReflection?: number; // 0 - 100
  iridescence?: number; // 0 - 100
  revealVideoUrl?: string; // Optional Legendary card reveal video
  isActive?: boolean; // Card is active and can drop from packs
  isCustom?: boolean;
  createdBy?: string;
  createdAt?: string;
  updatedAt?: string;

  // Custom styling overrides for owners
  nameColor?: string;
  borderColor?: string;
  glowColor?: string;
  glowIntensity?: CardGlowIntensity;
  frameStyle?: CardFrameStyle;
  cornerStyle?: CardCornerStyle;
  badgeStyle?: 'auto' | 'crest' | 'cartouche' | 'engraved_plate' | 'clean_minimal';
  backgroundTheme?: CardBackgroundTheme;
  ratingFontSize?: number; // Custom font size for upper right rating number (in px)
  ratingOffsetX?: number; // Custom offset from right edge in px
  ratingOffsetY?: number; // Custom offset from top edge in px
  ratingSize?: 'sm' | 'md' | 'lg' | 'xl';
}

export interface CardOwnership {
  cardId: string;
  count: number;
  firstAcquiredAt: string;
  lastAcquiredAt: string;
  upgradedRarity?: CardRarity;
  upgradeLevel?: number;
  upgradedStats?: CardStatItem[];
  customAttack?: number;
  customDefense?: number;
  customHp?: number;
  upgradedAt?: string;
}

export interface UserCardProfile {
  discordId: string;
  username: string;
  displayName: string;
  avatarUrl?: string;
  coins: number;
  isUnlimitedCoins?: boolean;
  lastDailyClaim?: string;
  nextDailyClaimAvailableAt?: string;
  canClaimDaily: boolean;
  totalPacksOpened: number;
  cards: Record<string, CardOwnership>;
  showcaseCardIds: string[];
  favoriteCardId?: string | null;
  selectedTitleId?: string | null;
  unlockedTitleIds?: string[];
  featuredBadgeIds?: string[];
  unlockedBadgeIds?: string[];
  xp?: number;
  level?: number;
  setsCompletedCount?: number;
  cosmetics?: {
    profileFrame?: string;
    profileBackground?: string;
    nameplate?: string;
    cardBack?: string;
  };
  bannerUrl?: string | null;
  claimedAchievements?: Record<string, { claimedAt: string; baseCoins?: number; coinsAwarded: number; multiplier: number }>;
  updatedAt?: string;
}

export interface PackDefinition {
  id: CardRarity;
  name: string;
  rarity: CardRarity;
  price: number;
  description: string;
  themeColor: string;
  accentHex: string;
  badgeBg: string;
  cuneiformRune: string;
  guaranteeText: string;
  chancesText: string;
  imageUrl?: string;
  openImageUrl?: string; // Picture of the package when opened in reveal modal
}

export interface PackCustomizationSettings {
  name?: string;
  imageUrl?: string;      // Catalog / shop image
  openImageUrl?: string;  // Card open image in reveal modal
}

export type CoinTransactionType =
  | 'DAILY_CLAIM'
  | 'PACK_PURCHASE'
  | 'OWNER_GRANT'
  | 'INITIAL_BONUS'
  | 'STORY_REWARD'
  | 'ACHIEVEMENT_CLAIM'
  | 'ADMIN_GIFT'
  | 'COMPANION_PASSIVE_COINS'
  | 'COMPANION_SPECIAL_REWARD';

export interface CoinTransaction {
  id: string;
  type: CoinTransactionType;
  userId: string;
  username: string;
  amount: number;
  balanceAfter: number;
  performedBy: string;
  reason?: string;
  details?: Record<string, any>;
  createdAt: string;
}

import type { LoveItemDefinition } from './characterLove';
import type { DuplicateRewardAwarded, UnifiedItemDefinition } from './items';

export interface PackRewardItem {
  id: string;
  name: string;
  nameAr?: string;
  description?: string;
  descriptionAr?: string;
  imageUrl: string;
  rarity: CardRarity;
  category: 'BATTLE' | 'COMPANION' | 'UPGRADE_MATERIAL' | 'SPECIAL';
  count: number;
  battleEffect?: any;
  lovePoints?: number;
}

export interface PackOpenResult {
  success: boolean;
  openedCard: CollectibleCardData;
  isNew: boolean;
  duplicateCount: number;
  remainingCoins: number;
  cards: Record<string, CardOwnership>;
  message?: string;
  droppedItem?: LoveItemDefinition | UnifiedItemDefinition | null;
  droppedItems?: (LoveItemDefinition | UnifiedItemDefinition | PackRewardItem)[] | null;
  duplicateReward?: DuplicateRewardAwarded | null;
}

