import { StaffMember } from './staff';

export type ApplicationStatus = 'NOT_APPLIED' | 'PENDING' | 'APPROVED' | 'REJECTED';

export interface RankApplication {
  id: string;
  staffId: string;
  discordId: string;
  displayName: string;
  avatarUrl?: string;
  currentPoints: number;
  currentTierId: string;
  targetTierId: string;
  status: ApplicationStatus;
  appliedAt?: string | null;
  reviewedAt?: string | null;
  reviewedBy?: string | null;
  reviewNote?: string | null;
  updatedAt: string;
}

export type RankSectionId = 'staff' | 'grand_staff' | 'guard' | 'high_council';

export interface RankSectionInfo {
  id: RankSectionId;
  name: string;
  nameAr: string;
  badgeAr: string;
  badgeEn: string;
  pointRange: string;
  iconColor: string;
  theme: 'standard' | 'yellow' | 'purple' | 'white';
  unlockThreshold: number;
  unlockRequirementAr: string;
  unlockRequirementEn: string;
  descriptionAr: string;
  descriptionEn: string;
}

export interface RankTier {
  id: string;
  name: string;
  nameAr: string;
  minPoints: number;
  maxPoints: number;
  pointsLabel: string;
  section: RankSectionId;
  track?: 'team' | 'girl' | 'standard';
  description: string;
  descriptionAr: string;
  roleHint: string;
  colorScheme: {
    badgeBg: string;
    badgeText: string;
    border: string;
    glow: string;
    gradient: string;
    iconBg: string;
    iconColor: string;
  };
}

export const RANK_SECTIONS: RankSectionInfo[] = [
  {
    id: 'staff',
    name: 'Existing Staff',
    nameAr: 'طاقم الإدارة',
    badgeAr: 'المرحلة الأولى',
    badgeEn: 'SECTION 1 — STAFF',
    pointRange: '0–51 PTS',
    iconColor: 'text-cyan-400',
    theme: 'standard',
    unlockThreshold: 0,
    unlockRequirementAr: 'متاح لكافة أعضاء الإدارة المعتمدين',
    unlockRequirementEn: 'Unlocked for all recognized staff',
    descriptionAr: 'المسار الإداري الأساسي لسيرفر CREATINE NEXUS (0–51 نقطة).',
    descriptionEn: 'The core staff progression path for CREATINE NEXUS (0–51 PTS).'
  },
  {
    id: 'grand_staff',
    name: 'CN GRAND STAFF',
    nameAr: 'جراند ستاف CN',
    badgeAr: 'المرحلة الثانية',
    badgeEn: 'SECTION 2 — GRAND STAFF',
    pointRange: '52–88+ PTS',
    iconColor: 'text-amber-400',
    theme: 'yellow',
    unlockThreshold: 52,
    unlockRequirementAr: 'يتطلب إكمال رتبة القيادة العامة (52 نقطة)',
    unlockRequirementEn: 'Requires completing General Staff (52 PTS)',
    descriptionAr: 'رتب كبار الطاقم والمسؤولين والمشرفين المخضرمين (52–94 نقطة).',
    descriptionEn: 'Grand staff tier of senior officers, overseers and managers (52–94 PTS).'
  },
  {
    id: 'guard',
    name: 'CN GUARD',
    nameAr: 'حرس CN',
    badgeAr: 'المرحلة الثالثة',
    badgeEn: 'SECTION 3 — CN GUARD',
    pointRange: '95–160+ PTS',
    iconColor: 'text-purple-400',
    theme: 'purple',
    unlockThreshold: 95,
    unlockRequirementAr: 'يتطلب إكمال رتبة مدير الجراند ستاف (95 نقطة)',
    unlockRequirementEn: 'Requires completing Grand Staff Manager (95 PTS)',
    descriptionAr: 'حراس السيرفر وحماة النظام الأوفياء وسياج الأمان للمجتمع (95–174 نقطة).',
    descriptionEn: 'Guardians defending server integrity, order and peace (95–174 PTS).'
  },
  {
    id: 'high_council',
    name: 'CN HIGH COUNCIL',
    nameAr: 'مجلس CN الأعلى',
    badgeAr: 'المرحلة الرابعة النخبوية',
    badgeEn: 'SECTION 4 — HIGH COUNCIL',
    pointRange: '175–280+ PTS',
    iconColor: 'text-slate-100',
    theme: 'white',
    unlockThreshold: 175,
    unlockRequirementAr: 'يتطلب إكمال رتبة مدير الحراس (175 نقطة)',
    unlockRequirementEn: 'Requires completing Guardians Manager (175 PTS)',
    descriptionAr: 'مجلس القيادة والسيادة العليا لنخبة أوصياء وقادة السيرفر (175–280+ نقطة).',
    descriptionEn: 'Supreme governing high council leading CREATINE NEXUS (175–280+ PTS).'
  }
];

export const RANK_TIERS: RankTier[] = [
  // ━━━━━━━━━━━━━━━━━━
  // SECTION 1 — EXISTING STAFF (0–51 PTS)
  // ━━━━━━━━━━━━━━━━━━
  {
    id: 'cn_team',
    name: 'CN Team',
    nameAr: 'فريق CN',
    minPoints: 0,
    maxPoints: 4,
    pointsLabel: '0–4 PTS',
    section: 'staff',
    track: 'team',
    description: 'Entry gateway into the general CREATINE NEXUS staff team.',
    descriptionAr: 'بوابة الانضمام الأولى إلى طاقم عمل سيرفر CREATINE NEXUS العام.',
    roleHint: '— CN Team',
    colorScheme: {
      badgeBg: 'bg-cyan-500/15',
      badgeText: 'text-cyan-300',
      border: 'border-cyan-500/30',
      glow: 'shadow-cyan-500/10',
      gradient: 'from-cyan-500/20 via-cyan-600/10 to-transparent',
      iconBg: 'bg-cyan-500/10',
      iconColor: 'text-cyan-400'
    }
  },
  {
    id: 'cn_staff_girl',
    name: 'CN Staff Girl',
    nameAr: 'إداريات CN',
    minPoints: 0,
    maxPoints: 4,
    pointsLabel: '0–4 PTS',
    section: 'staff',
    track: 'girl',
    description: 'Dedicated sisterhood entry wing for female staff in CREATINE NEXUS.',
    descriptionAr: 'الجناح الإداري النسائي المخصص لطاقم الفتيات في CREATINE NEXUS.',
    roleHint: '— CN Staff Girl',
    colorScheme: {
      badgeBg: 'bg-pink-500/15',
      badgeText: 'text-pink-300',
      border: 'border-pink-500/30',
      glow: 'shadow-pink-500/10',
      gradient: 'from-pink-500/20 via-purple-600/10 to-transparent',
      iconBg: 'bg-pink-500/10',
      iconColor: 'text-pink-400'
    }
  },
  {
    id: 'trial_staff',
    name: 'Trial Staff',
    nameAr: 'إداري متدرب',
    minPoints: 5,
    maxPoints: 7,
    pointsLabel: '5–7 PTS',
    section: 'staff',
    track: 'standard',
    description: 'Active probationary period observing server moderation and community protocols.',
    descriptionAr: 'المرحلة التدريبية والتقييمية لمراقبة سلوك المحادثات والالتزام بالبروتوكولات.',
    roleHint: 'Trial Moderator',
    colorScheme: {
      badgeBg: 'bg-teal-500/15',
      badgeText: 'text-teal-300',
      border: 'border-teal-500/30',
      glow: 'shadow-teal-500/10',
      gradient: 'from-teal-500/20 via-emerald-600/10 to-transparent',
      iconBg: 'bg-teal-500/10',
      iconColor: 'text-teal-400'
    }
  },
  {
    id: 'junior_staff',
    name: 'Junior Staff',
    nameAr: 'إداري مبتدئ',
    minPoints: 8,
    maxPoints: 11,
    pointsLabel: '8–11 PTS',
    section: 'staff',
    track: 'standard',
    description: 'Confirmed junior moderator managing everyday chat interactions and member questions.',
    descriptionAr: 'إداري مبتدئ معتمد يدير تفاعلات الأعضاء اليومية ويجيب على الاستفسارات.',
    roleHint: 'Junior Staff',
    colorScheme: {
      badgeBg: 'bg-sky-500/15',
      badgeText: 'text-sky-300',
      border: 'border-sky-500/30',
      glow: 'shadow-sky-500/10',
      gradient: 'from-sky-500/20 via-blue-600/10 to-transparent',
      iconBg: 'bg-sky-500/10',
      iconColor: 'text-sky-400'
    }
  },
  {
    id: 'staff_member',
    name: 'Staff Member',
    nameAr: 'عضو إدارة رسمي',
    minPoints: 12,
    maxPoints: 16,
    pointsLabel: '12–16 PTS',
    section: 'staff',
    track: 'standard',
    description: 'Established staff pillar handling event oversight and routine ticket moderation.',
    descriptionAr: 'عضو أساسي ومستقر في الطاقم يشرف على فعاليات الدردشة والتذاكر الإدارية.',
    roleHint: 'Staff Member',
    colorScheme: {
      badgeBg: 'bg-blue-500/15',
      badgeText: 'text-blue-300',
      border: 'border-blue-500/30',
      glow: 'shadow-blue-500/10',
      gradient: 'from-blue-500/20 via-indigo-600/10 to-transparent',
      iconBg: 'bg-blue-500/10',
      iconColor: 'text-blue-400'
    }
  },
  {
    id: 'senior_staff',
    name: 'Senior Staff',
    nameAr: 'إداري أول',
    minPoints: 17,
    maxPoints: 21,
    pointsLabel: '17–21 PTS',
    section: 'staff',
    track: 'standard',
    description: 'Seasoned staff member mentoring newer moderators and maintaining community peace.',
    descriptionAr: 'إداري متمرس ذو خبرة يوجه الأعضاء الجدد ويحفظ استقرار السيرفر وسلامته.',
    roleHint: 'Senior Staff',
    colorScheme: {
      badgeBg: 'bg-indigo-500/15',
      badgeText: 'text-indigo-300',
      border: 'border-indigo-500/30',
      glow: 'shadow-indigo-500/10',
      gradient: 'from-indigo-500/20 via-violet-600/10 to-transparent',
      iconBg: 'bg-indigo-500/10',
      iconColor: 'text-indigo-400'
    }
  },
  {
    id: 'head_staff',
    name: 'Head Staff',
    nameAr: 'رئيس طاقم',
    minPoints: 22,
    maxPoints: 27,
    pointsLabel: '22–27 PTS',
    section: 'staff',
    track: 'standard',
    description: 'Division head coordinating active moderation shifts and stream event duties.',
    descriptionAr: 'رئيس قسم يشرف على نوبات الإشراف وينسق مع المشرفين أثناء بثوث إدغار.',
    roleHint: 'Head Staff',
    colorScheme: {
      badgeBg: 'bg-violet-500/15',
      badgeText: 'text-violet-300',
      border: 'border-violet-500/30',
      glow: 'shadow-violet-500/10',
      gradient: 'from-violet-500/20 via-purple-600/10 to-transparent',
      iconBg: 'bg-violet-500/10',
      iconColor: 'text-violet-400'
    }
  },
  {
    id: 'lead_staff',
    name: 'Lead Staff',
    nameAr: 'قائد إداري',
    minPoints: 28,
    maxPoints: 33,
    pointsLabel: '28–33 PTS',
    section: 'staff',
    track: 'standard',
    description: 'Senior leadership commanding teams during high-volume raids and big community events.',
    descriptionAr: 'قيادة إدارية ميدانية تقود الطاقم في الفعاليات الضخمة والأوقات المزدحمة.',
    roleHint: 'Lead Staff',
    colorScheme: {
      badgeBg: 'bg-purple-500/15',
      badgeText: 'text-purple-300',
      border: 'border-purple-500/30',
      glow: 'shadow-purple-500/10',
      gradient: 'from-purple-500/20 via-fuchsia-600/10 to-transparent',
      iconBg: 'bg-purple-500/10',
      iconColor: 'text-purple-400'
    }
  },
  {
    id: 'executive_staff',
    name: 'Executive Staff',
    nameAr: 'إداري تنفيذي',
    minPoints: 34,
    maxPoints: 39,
    pointsLabel: '34–39 PTS',
    section: 'staff',
    track: 'standard',
    description: 'Strategic executive overseeing cross-channel moderation policies and server bot setups.',
    descriptionAr: 'إدارة تنفيذية تضع السياسات العامة للإشراف وتتابع إعدادات البوتات والتنظيم.',
    roleHint: 'Executive Staff',
    colorScheme: {
      badgeBg: 'bg-fuchsia-500/15',
      badgeText: 'text-fuchsia-300',
      border: 'border-fuchsia-500/30',
      glow: 'shadow-fuchsia-500/10',
      gradient: 'from-fuchsia-500/20 via-rose-600/10 to-transparent',
      iconBg: 'bg-fuchsia-500/10',
      iconColor: 'text-fuchsia-400'
    }
  },
  {
    id: 'organizer_staff',
    name: 'Organizer Staff',
    nameAr: 'إداري منظم',
    minPoints: 40,
    maxPoints: 44,
    pointsLabel: '40–44 PTS',
    section: 'staff',
    track: 'standard',
    description: 'Master organizer architecting server tournaments, giveaways, and creator collaborations.',
    descriptionAr: 'منسق بطولات ومسابقات كبرى، وتوزيع الجوائز بالتعاون مع الفنان إدغار.',
    roleHint: 'Organizer Staff',
    colorScheme: {
      badgeBg: 'bg-amber-500/15',
      badgeText: 'text-amber-300',
      border: 'border-amber-500/30',
      glow: 'shadow-amber-500/10',
      gradient: 'from-amber-500/20 via-orange-600/10 to-transparent',
      iconBg: 'bg-amber-500/10',
      iconColor: 'text-amber-400'
    }
  },
  {
    id: 'core_staff',
    name: 'Core Staff',
    nameAr: 'إدارة عليا / أساسية',
    minPoints: 45,
    maxPoints: 49,
    pointsLabel: '45–49 PTS',
    section: 'staff',
    track: 'standard',
    description: 'Inner circle custodians entrusted with server-wide administrative oversight.',
    descriptionAr: 'النواة الإدارية العليا الموثوقة بصلاحيات الإشراف الإداري الشامل والمباشر.',
    roleHint: 'Core Staff',
    colorScheme: {
      badgeBg: 'bg-rose-500/15',
      badgeText: 'text-rose-300',
      border: 'border-rose-500/30',
      glow: 'shadow-rose-500/10',
      gradient: 'from-rose-500/20 via-purple-600/10 to-transparent',
      iconBg: 'bg-rose-500/10',
      iconColor: 'text-rose-400'
    }
  },
  {
    id: 'general_staff',
    name: 'General Staff',
    nameAr: 'القيادة العامة',
    minPoints: 50,
    maxPoints: 51,
    pointsLabel: '50–51 PTS',
    section: 'staff',
    track: 'standard',
    description: 'Peak of the core staff ladder; completing this rank unlocks the CN GRAND STAFF tier.',
    descriptionAr: 'قمة الهرم الإداري الأساسي؛ إكمال هذه الرتبة يفتح رسمياً مسار CN GRAND STAFF.',
    roleHint: 'General Staff',
    colorScheme: {
      badgeBg: 'bg-gradient-to-r from-amber-500/20 to-cyan-500/20',
      badgeText: 'text-amber-200',
      border: 'border-amber-400/40',
      glow: 'shadow-amber-500/20',
      gradient: 'from-amber-500/20 via-cyan-500/15 to-purple-600/10',
      iconBg: 'bg-amber-500/15',
      iconColor: 'text-amber-300'
    }
  },

  // ━━━━━━━━━━━━━━━━━━
  // SECTION 2 — 🟡 CN GRAND STAFF (Yellow Identity) (52–88+ PTS)
  // ━━━━━━━━━━━━━━━━━━
  {
    id: 'new_grand_staff',
    name: 'New Grand Staff',
    nameAr: 'جراند ستاف جديد',
    minPoints: 52,
    maxPoints: 53,
    pointsLabel: '52 PTS',
    section: 'grand_staff',
    track: 'standard',
    description: 'First milestone of the prestigious Grand Staff chapter.',
    descriptionAr: 'المحطة الأولى في رتب كبار الإدارة المعتمدة.',
    roleHint: 'Grand Staff Novice',
    colorScheme: {
      badgeBg: 'bg-amber-500/15',
      badgeText: 'text-amber-300',
      border: 'border-amber-500/30',
      glow: 'shadow-amber-500/15',
      gradient: 'from-amber-500/20 via-yellow-600/10 to-transparent',
      iconBg: 'bg-amber-500/15',
      iconColor: 'text-amber-400'
    }
  },
  {
    id: 'junior_grand_staff',
    name: 'Junior Grand Staff',
    nameAr: 'جراند ستاف مبتدئ',
    minPoints: 54,
    maxPoints: 55,
    pointsLabel: '54 PTS',
    section: 'grand_staff',
    track: 'standard',
    description: 'Active contributor within the Grand Staff tier.',
    descriptionAr: 'عضو نشط ومؤثر في مسار الجراند ستاف.',
    roleHint: 'Junior Grand Staff',
    colorScheme: {
      badgeBg: 'bg-amber-500/15',
      badgeText: 'text-amber-300',
      border: 'border-amber-500/35',
      glow: 'shadow-amber-500/15',
      gradient: 'from-amber-500/20 via-yellow-600/10 to-transparent',
      iconBg: 'bg-amber-500/15',
      iconColor: 'text-amber-400'
    }
  },
  {
    id: 'grand_staff_member',
    name: 'Grand Staff Member',
    nameAr: 'عضو جراند ستاف',
    minPoints: 56,
    maxPoints: 57,
    pointsLabel: '56 PTS',
    section: 'grand_staff',
    track: 'standard',
    description: 'Fully recognized member of the CN Grand Staff assembly.',
    descriptionAr: 'عضو معتمد ومثبت في رتب الجراند ستاف المتقدمة.',
    roleHint: 'Grand Staff Member',
    colorScheme: {
      badgeBg: 'bg-amber-500/20',
      badgeText: 'text-amber-300',
      border: 'border-amber-500/40',
      glow: 'shadow-amber-500/20',
      gradient: 'from-amber-500/25 via-yellow-600/15 to-transparent',
      iconBg: 'bg-amber-500/20',
      iconColor: 'text-amber-300'
    }
  },
  {
    id: 'grand_staff_officer',
    name: 'Grand Staff Officer',
    nameAr: 'ضابط جراند ستاف',
    minPoints: 58,
    maxPoints: 59,
    pointsLabel: '58 PTS',
    section: 'grand_staff',
    track: 'standard',
    description: 'Tactical coordinator supervising key server operations.',
    descriptionAr: 'ضابط ميداني يشرف على العمليات الإدارية المركزية.',
    roleHint: 'Grand Staff Officer',
    colorScheme: {
      badgeBg: 'bg-yellow-500/20',
      badgeText: 'text-yellow-300',
      border: 'border-yellow-500/40',
      glow: 'shadow-yellow-500/20',
      gradient: 'from-yellow-500/25 via-amber-600/15 to-transparent',
      iconBg: 'bg-yellow-500/20',
      iconColor: 'text-yellow-300'
    }
  },
  {
    id: 'cn_grand_staff',
    name: 'CN Grand Staff',
    nameAr: 'جراند ستاف CN',
    minPoints: 60,
    maxPoints: 64,
    pointsLabel: '60 PTS',
    section: 'grand_staff',
    track: 'standard',
    description: 'Central pillar of the CN Grand Staff echelon.',
    descriptionAr: 'العمود الفقري ورتبة الشرف المركزية لجراند ستاف CN.',
    roleHint: 'CN Grand Staff',
    colorScheme: {
      badgeBg: 'bg-amber-400/20',
      badgeText: 'text-amber-200',
      border: 'border-amber-400/45',
      glow: 'shadow-amber-400/25',
      gradient: 'from-amber-400/25 via-yellow-500/15 to-transparent',
      iconBg: 'bg-amber-400/25',
      iconColor: 'text-amber-200'
    }
  },
  {
    id: 'sentinel_grand_staff',
    name: 'Sentinel Grand Staff',
    nameAr: 'حارس جراند ستاف',
    minPoints: 65,
    maxPoints: 69,
    pointsLabel: '65 PTS',
    section: 'grand_staff',
    track: 'standard',
    description: 'Vigilant defender overseeing protocol adherence.',
    descriptionAr: 'حارس يقظ وموجه رئيسي لحماية التماسك الإداري.',
    roleHint: 'Sentinel Grand Staff',
    colorScheme: {
      badgeBg: 'bg-amber-500/20',
      badgeText: 'text-amber-200',
      border: 'border-amber-400/50',
      glow: 'shadow-amber-400/25',
      gradient: 'from-amber-500/25 via-yellow-600/15 to-transparent',
      iconBg: 'bg-amber-500/25',
      iconColor: 'text-amber-300'
    }
  },
  {
    id: 'high_grand_staff',
    name: 'High Grand Staff',
    nameAr: 'جراند ستاف متقدم',
    minPoints: 70,
    maxPoints: 75,
    pointsLabel: '70 PTS',
    section: 'grand_staff',
    track: 'standard',
    description: 'Elite officer handling complex decisions with seasoned acumen.',
    descriptionAr: 'رتبة عليا تتولى القرارات الحساسة والإشراف المباشر.',
    roleHint: 'High Grand Staff',
    colorScheme: {
      badgeBg: 'bg-yellow-400/25',
      badgeText: 'text-yellow-200',
      border: 'border-yellow-400/50',
      glow: 'shadow-yellow-400/30',
      gradient: 'from-yellow-400/30 via-amber-500/20 to-transparent',
      iconBg: 'bg-yellow-400/25',
      iconColor: 'text-yellow-200'
    }
  },
  {
    id: 'overseer_grand_staff',
    name: 'Overseer Grand Staff',
    nameAr: 'مشرف جراند ستاف',
    minPoints: 76,
    maxPoints: 81,
    pointsLabel: '76 PTS',
    section: 'grand_staff',
    track: 'standard',
    description: 'Strategic supervisor steering moderation directives.',
    descriptionAr: 'مشرف استراتيجي يوجه الطواقم ويحافظ على ثبات المعايير.',
    roleHint: 'Overseer Grand Staff',
    colorScheme: {
      badgeBg: 'bg-amber-400/25',
      badgeText: 'text-amber-200',
      border: 'border-amber-400/55',
      glow: 'shadow-amber-400/30',
      gradient: 'from-amber-400/30 via-yellow-500/20 to-transparent',
      iconBg: 'bg-amber-400/30',
      iconColor: 'text-amber-200'
    }
  },
  {
    id: 'core_grand_staff',
    name: 'Core Grand Staff',
    nameAr: 'النواة العليا للجراند ستاف',
    minPoints: 82,
    maxPoints: 87,
    pointsLabel: '82 PTS',
    section: 'grand_staff',
    track: 'standard',
    description: 'Inner circle leader of the Grand Staff council.',
    descriptionAr: 'نواة القيادة العليا المسؤولة عن سلامة مجلس الجراند ستاف.',
    roleHint: 'Core Grand Staff',
    colorScheme: {
      badgeBg: 'bg-amber-300/25',
      badgeText: 'text-amber-100',
      border: 'border-amber-300/60',
      glow: 'shadow-amber-300/35',
      gradient: 'from-amber-300/30 via-yellow-500/20 to-transparent',
      iconBg: 'bg-amber-300/30',
      iconColor: 'text-amber-100'
    }
  },
  {
    id: 'grand_staff_manager',
    name: 'Grand Staff Manager',
    nameAr: 'مدير الجراند ستاف',
    minPoints: 88,
    maxPoints: 94,
    pointsLabel: '88 PTS',
    section: 'grand_staff',
    track: 'standard',
    description: 'Supreme manager of the Grand Staff; completing this rank unlocks the CN GUARD chapter.',
    descriptionAr: 'مدير عام الجراند ستاف وأعلى هرم المرحلة؛ إكمالها يفتح رسمياً مسار CN GUARD.',
    roleHint: 'Grand Staff Manager',
    colorScheme: {
      badgeBg: 'bg-gradient-to-r from-amber-400/30 to-yellow-500/30',
      badgeText: 'text-amber-100',
      border: 'border-amber-300/70',
      glow: 'shadow-amber-300/40',
      gradient: 'from-amber-400/35 via-yellow-400/20 to-transparent',
      iconBg: 'bg-amber-400/30',
      iconColor: 'text-amber-100'
    }
  },

  // ━━━━━━━━━━━━━━━━━━
  // SECTION 3 — 🟣 CN GUARD (Purple Identity) (95–160+ PTS)
  // ━━━━━━━━━━━━━━━━━━
  {
    id: 'new_guardian',
    name: 'New Guardian',
    nameAr: 'حارس جديد',
    minPoints: 95,
    maxPoints: 102,
    pointsLabel: '95 PTS',
    section: 'guard',
    track: 'standard',
    description: 'Sworn inductee into the noble CN Guard order.',
    descriptionAr: 'فارس جديد ينضم إلى فيلق حرس CREATINE NEXUS النبيل.',
    roleHint: 'CN Guardian Initiate',
    colorScheme: {
      badgeBg: 'bg-purple-500/15',
      badgeText: 'text-purple-300',
      border: 'border-purple-500/30',
      glow: 'shadow-purple-500/15',
      gradient: 'from-purple-500/20 via-fuchsia-600/10 to-transparent',
      iconBg: 'bg-purple-500/15',
      iconColor: 'text-purple-400'
    }
  },
  {
    id: 'junior_guardian',
    name: 'Junior Guardian',
    nameAr: 'حارس مبتدئ',
    minPoints: 103,
    maxPoints: 111,
    pointsLabel: '103 PTS',
    section: 'guard',
    track: 'standard',
    description: 'Demonstrated loyalty standing watch over key community gateways.',
    descriptionAr: 'حارس مبتدئ أثبت تفانيه في حراسة أقسام وقنوات السيرفر.',
    roleHint: 'Junior Guardian',
    colorScheme: {
      badgeBg: 'bg-purple-500/20',
      badgeText: 'text-purple-300',
      border: 'border-purple-500/35',
      glow: 'shadow-purple-500/20',
      gradient: 'from-purple-500/25 via-fuchsia-600/15 to-transparent',
      iconBg: 'bg-purple-500/20',
      iconColor: 'text-purple-300'
    }
  },
  {
    id: 'verified_guardian',
    name: 'Verified Guardian',
    nameAr: 'حارس موثق',
    minPoints: 112,
    maxPoints: 121,
    pointsLabel: '112 PTS',
    section: 'guard',
    track: 'standard',
    description: 'Tested and proven shieldbearer of CREATINE NEXUS security.',
    descriptionAr: 'حارس موثق اجتاز الاختبارات وحمل لواء حماية السيرفر.',
    roleHint: 'Verified Guardian',
    colorScheme: {
      badgeBg: 'bg-purple-500/25',
      badgeText: 'text-purple-200',
      border: 'border-purple-500/40',
      glow: 'shadow-purple-500/25',
      gradient: 'from-purple-500/30 via-violet-600/15 to-transparent',
      iconBg: 'bg-purple-500/25',
      iconColor: 'text-purple-200'
    }
  },
  {
    id: 'trusted_guardian',
    name: 'Trusted Guardian',
    nameAr: 'حارس موثوق',
    minPoints: 122,
    maxPoints: 132,
    pointsLabel: '122 PTS',
    section: 'guard',
    track: 'standard',
    description: 'Highly trusted defender authorized with immediate incident response.',
    descriptionAr: 'حارس موثوق بصلاحيات الرد السريع لحفظ النظام والأمان.',
    roleHint: 'Trusted Guardian',
    colorScheme: {
      badgeBg: 'bg-violet-500/25',
      badgeText: 'text-violet-200',
      border: 'border-violet-500/45',
      glow: 'shadow-violet-500/25',
      gradient: 'from-violet-500/30 via-purple-600/20 to-transparent',
      iconBg: 'bg-violet-500/25',
      iconColor: 'text-violet-200'
    }
  },
  {
    id: 'high_guardian',
    name: 'High Guardian',
    nameAr: 'حارس متقدم',
    minPoints: 133,
    maxPoints: 144,
    pointsLabel: '133 PTS',
    section: 'guard',
    track: 'standard',
    description: 'Senior commander within the Guardian hierarchy.',
    descriptionAr: 'قائد حرس متقدم يتولى قيادة العمليات الدفاعية الكبرى.',
    roleHint: 'High Guardian',
    colorScheme: {
      badgeBg: 'bg-purple-400/25',
      badgeText: 'text-purple-100',
      border: 'border-purple-400/50',
      glow: 'shadow-purple-400/30',
      gradient: 'from-purple-400/30 via-fuchsia-500/20 to-transparent',
      iconBg: 'bg-purple-400/30',
      iconColor: 'text-purple-100'
    }
  },
  {
    id: 'core_guardian',
    name: 'Core Guardian',
    nameAr: 'حارس أساسي',
    minPoints: 145,
    maxPoints: 159,
    pointsLabel: '145 PTS',
    section: 'guard',
    track: 'standard',
    description: 'Inner core protector holding the highest defensive mandate.',
    descriptionAr: 'نواة الحرس المركزية وركيزة الحماية الدفاعية العليا.',
    roleHint: 'Core Guardian',
    colorScheme: {
      badgeBg: 'bg-fuchsia-500/25',
      badgeText: 'text-fuchsia-100',
      border: 'border-fuchsia-400/55',
      glow: 'shadow-fuchsia-400/30',
      gradient: 'from-fuchsia-500/30 via-purple-600/20 to-transparent',
      iconBg: 'bg-fuchsia-500/30',
      iconColor: 'text-fuchsia-100'
    }
  },
  {
    id: 'guardians_manager',
    name: 'Guardians Manager',
    nameAr: 'مدير الحراس',
    minPoints: 160,
    maxPoints: 174,
    pointsLabel: '160 PTS',
    section: 'guard',
    track: 'standard',
    description: 'Master commander of all guardians; completing this rank unlocks the CN HIGH COUNCIL.',
    descriptionAr: 'مدير عام فيلق الحراس وأعلى رتبة فيه؛ إكمالها يفتح رسمياً مسار CN HIGH COUNCIL.',
    roleHint: 'Guardians Manager',
    colorScheme: {
      badgeBg: 'bg-gradient-to-r from-purple-400/30 to-fuchsia-500/30',
      badgeText: 'text-purple-100',
      border: 'border-purple-300/65',
      glow: 'shadow-purple-400/40',
      gradient: 'from-purple-400/35 via-violet-500/25 to-transparent',
      iconBg: 'bg-purple-400/35',
      iconColor: 'text-purple-100'
    }
  },

  // ━━━━━━━━━━━━━━━━━━
  // SECTION 4 — ⚪ CN HIGH COUNCIL (White / Elegant Elite Identity) (175–280+ PTS)
  // ━━━━━━━━━━━━━━━━━━
  {
    id: 'new_council_member',
    name: 'New Council Member',
    nameAr: 'عضو مجلس جديد',
    minPoints: 175,
    maxPoints: 189,
    pointsLabel: '175 PTS',
    section: 'high_council',
    track: 'standard',
    description: 'Initial ascension into the revered High Council chamber.',
    descriptionAr: 'أولى خطوات الانضمام إلى غرفة المجلس الأعلى المهيب.',
    roleHint: 'High Council Initiate',
    colorScheme: {
      badgeBg: 'bg-slate-100/15',
      badgeText: 'text-slate-100',
      border: 'border-slate-300/40',
      glow: 'shadow-white/10',
      gradient: 'from-slate-100/20 via-slate-300/10 to-transparent',
      iconBg: 'bg-slate-100/20',
      iconColor: 'text-white'
    }
  },
  {
    id: 'high_council_member',
    name: 'High Council Member',
    nameAr: 'عضو المجلس المتقدم',
    minPoints: 190,
    maxPoints: 204,
    pointsLabel: '190 PTS',
    section: 'high_council',
    track: 'standard',
    description: 'Senior councilor taking part in macro-level community governance.',
    descriptionAr: 'عضو مجلس متمرس يشارك في صياغة قرارات الإدارة العليا.',
    roleHint: 'High Council Member',
    colorScheme: {
      badgeBg: 'bg-slate-100/20',
      badgeText: 'text-white',
      border: 'border-slate-200/50',
      glow: 'shadow-white/15',
      gradient: 'from-slate-100/25 via-slate-200/15 to-transparent',
      iconBg: 'bg-slate-100/25',
      iconColor: 'text-white'
    }
  },
  {
    id: 'grand_council_member',
    name: 'Grand Council Member',
    nameAr: 'عضو المجلس الأعلى',
    minPoints: 205,
    maxPoints: 224,
    pointsLabel: '205 PTS',
    section: 'high_council',
    track: 'standard',
    description: 'Distinguished statesman with sovereign voice on community policy.',
    descriptionAr: 'عضو وقور ذو مكانة رفيعة ورأي نافذ في رسم مسار السيرفر.',
    roleHint: 'Grand Council Member',
    colorScheme: {
      badgeBg: 'bg-slate-100/25',
      badgeText: 'text-white',
      border: 'border-slate-200/60',
      glow: 'shadow-white/20',
      gradient: 'from-white/30 via-slate-200/15 to-transparent',
      iconBg: 'bg-slate-100/30',
      iconColor: 'text-white'
    }
  },
  {
    id: 'council_regent',
    name: 'Council Regent',
    nameAr: 'وصي المجلس',
    minPoints: 225,
    maxPoints: 249,
    pointsLabel: '225 PTS',
    section: 'high_council',
    track: 'standard',
    description: 'Imperial regent entrusted with high executive authority.',
    descriptionAr: 'وصي تنفيذي موثوق بصلاحيات عليا لحماية استقرار السيرفر.',
    roleHint: 'Council Regent',
    colorScheme: {
      badgeBg: 'bg-white/25',
      badgeText: 'text-white',
      border: 'border-white/70',
      glow: 'shadow-white/25',
      gradient: 'from-white/35 via-slate-100/20 to-transparent',
      iconBg: 'bg-white/30',
      iconColor: 'text-slate-900'
    }
  },
  {
    id: 'grand_council_regent',
    name: 'Grand Council Regent',
    nameAr: 'وصي المجلس الأعلى',
    minPoints: 250,
    maxPoints: 279,
    pointsLabel: '250 PTS',
    section: 'high_council',
    track: 'standard',
    description: 'Supreme viceroy answering directly to the Owner and Sovereign circle.',
    descriptionAr: 'الوصي الأعلى للمجلس والممثل المباشر لمالك السيرفر Edgar.',
    roleHint: 'Grand Council Regent',
    colorScheme: {
      badgeBg: 'bg-white/30',
      badgeText: 'text-white',
      border: 'border-white/80',
      glow: 'shadow-white/30',
      gradient: 'from-white/40 via-slate-100/25 to-transparent',
      iconBg: 'bg-white/35',
      iconColor: 'text-slate-950'
    }
  },
  {
    id: 'high_council_manager',
    name: 'HIGH COUNCIL MANAGER',
    nameAr: 'مدير المجلس الأعلى',
    minPoints: 280,
    maxPoints: 9999,
    pointsLabel: '280 PTS',
    section: 'high_council',
    track: 'standard',
    description: 'The supreme zenith of the CREATINE NEXUS progression map.',
    descriptionAr: 'قمة الهرم المطلقة وأعلى رتبة إدارية شرفية في تاريخ السيرفر.',
    roleHint: 'High Council Supreme Manager',
    colorScheme: {
      badgeBg: 'bg-gradient-to-r from-white/35 via-slate-100/30 to-amber-300/20',
      badgeText: 'text-white',
      border: 'border-white ring-2 ring-white/40',
      glow: 'shadow-[0_0_30px_rgba(255,255,255,0.35)]',
      gradient: 'from-white/45 via-slate-100/30 to-transparent',
      iconBg: 'bg-white',
      iconColor: 'text-slate-950'
    }
  }
];

// Linear ordered list for forward progression (single standard path)
export const PROGRESSION_PATH_TIERS: RankTier[] = [...RANK_TIERS];

// Helper to check if a section is unlocked
export function isSectionUnlocked(
  sectionId: RankSectionId,
  userPoints: number,
  isOwner: boolean = false
): boolean {
  if (isOwner) return true;
  const section = RANK_SECTIONS.find(s => s.id === sectionId);
  if (!section) return true;
  return userPoints >= section.unlockThreshold;
}

// Determine which checkpoint tier a staff member currently occupies based strictly on their CURRENT points
export function getTierForPoints(
  points: number, 
  memberRoles: string[] = [], 
  notes: string = ''
): RankTier {
  const p = Math.max(0, points || 0);

  // SECTION 4: CN HIGH COUNCIL
  if (p >= 280) return RANK_TIERS[34]; // high_council_manager (280)
  if (p >= 250) return RANK_TIERS[33]; // grand_council_regent (250)
  if (p >= 225) return RANK_TIERS[32]; // council_regent (225)
  if (p >= 205) return RANK_TIERS[31]; // grand_council_member (205)
  if (p >= 190) return RANK_TIERS[30]; // high_council_member (190)
  if (p >= 175) return RANK_TIERS[29]; // new_council_member (175)

  // SECTION 3: CN GUARD
  if (p >= 160) return RANK_TIERS[28]; // guardians_manager (160)
  if (p >= 145) return RANK_TIERS[27]; // core_guardian (145)
  if (p >= 133) return RANK_TIERS[26]; // high_guardian (133)
  if (p >= 122) return RANK_TIERS[25]; // trusted_guardian (122)
  if (p >= 112) return RANK_TIERS[24]; // verified_guardian (112)
  if (p >= 103) return RANK_TIERS[23]; // junior_guardian (103)
  if (p >= 95)  return RANK_TIERS[22]; // new_guardian (95)

  // SECTION 2: CN GRAND STAFF
  if (p >= 88) return RANK_TIERS[21]; // grand_staff_manager (88)
  if (p >= 82) return RANK_TIERS[20]; // core_grand_staff (82)
  if (p >= 76) return RANK_TIERS[19]; // overseer_grand_staff (76)
  if (p >= 70) return RANK_TIERS[18]; // high_grand_staff (70)
  if (p >= 65) return RANK_TIERS[17]; // sentinel_grand_staff (65)
  if (p >= 60) return RANK_TIERS[16]; // cn_grand_staff (60)
  if (p >= 58) return RANK_TIERS[15]; // grand_staff_officer (58)
  if (p >= 56) return RANK_TIERS[14]; // grand_staff_member (56)
  if (p >= 54) return RANK_TIERS[13]; // junior_grand_staff (54)
  if (p >= 52) return RANK_TIERS[12]; // new_grand_staff (52)

  // SECTION 1: EXISTING STAFF
  if (p >= 50) return RANK_TIERS[11]; // general_staff (50–51)
  if (p >= 45) return RANK_TIERS[10]; // core_staff (45–49)
  if (p >= 40) return RANK_TIERS[9];  // organizer_staff (40–44)
  if (p >= 34) return RANK_TIERS[8];  // executive_staff (34–39)
  if (p >= 28) return RANK_TIERS[7];  // lead_staff (28–33)
  if (p >= 22) return RANK_TIERS[6];  // head_staff (22–27)
  if (p >= 17) return RANK_TIERS[5];  // senior_staff (17–21)
  if (p >= 12) return RANK_TIERS[4];  // staff_member (12–16)
  if (p >= 8)  return RANK_TIERS[3];  // junior_staff (8–11)
  if (p >= 5)  return RANK_TIERS[2];  // trial_staff (5–7)
  
  // 0–4 PTS
  const isGirlTrack = memberRoles.some(r => r.toLowerCase().includes('girl') || r.toLowerCase().includes('بنات')) ||
                      notes.toLowerCase().includes('girl') || notes.toLowerCase().includes('بنت');
  if (isGirlTrack) return RANK_TIERS[1];
  return RANK_TIERS[0];
}

// Ordered steps for progression calculations
const ORDERED_STEPS: RankTier[] = [
  RANK_TIERS[0],  // cn_team (0-4)
  RANK_TIERS[2],  // trial_staff (5-7)
  RANK_TIERS[3],  // junior_staff (8-11)
  RANK_TIERS[4],  // staff_member (12-16)
  RANK_TIERS[5],  // senior_staff (17-21)
  RANK_TIERS[6],  // head_staff (22-27)
  RANK_TIERS[7],  // lead_staff (28-33)
  RANK_TIERS[8],  // executive_staff (34-39)
  RANK_TIERS[9],  // organizer_staff (40-44)
  RANK_TIERS[10], // core_staff (45-49)
  RANK_TIERS[11], // general_staff (50-51)
  RANK_TIERS[12], // new_grand_staff (52)
  RANK_TIERS[13], // junior_grand_staff (54)
  RANK_TIERS[14], // grand_staff_member (56)
  RANK_TIERS[15], // grand_staff_officer (58)
  RANK_TIERS[16], // cn_grand_staff (60)
  RANK_TIERS[17], // sentinel_grand_staff (65)
  RANK_TIERS[18], // high_grand_staff (70)
  RANK_TIERS[19], // overseer_grand_staff (76)
  RANK_TIERS[20], // core_grand_staff (82)
  RANK_TIERS[21], // grand_staff_manager (88)
  RANK_TIERS[22], // new_guardian (95)
  RANK_TIERS[23], // junior_guardian (103)
  RANK_TIERS[24], // verified_guardian (112)
  RANK_TIERS[25], // trusted_guardian (122)
  RANK_TIERS[26], // high_guardian (133)
  RANK_TIERS[27], // core_guardian (145)
  RANK_TIERS[28], // guardians_manager (160)
  RANK_TIERS[29], // new_council_member (175)
  RANK_TIERS[30], // high_council_member (190)
  RANK_TIERS[31], // grand_council_member (205)
  RANK_TIERS[32], // council_regent (225)
  RANK_TIERS[33], // grand_council_regent (250)
  RANK_TIERS[34], // high_council_manager (280)
];

// Get next tier and remaining points
export function getNextTierInfo(points: number): {
  currentTier: RankTier;
  nextTier: RankTier | null;
  remainingPoints: number;
  progressPercent: number;
  isMaxTier: boolean;
} {
  const p = Math.max(0, points || 0);
  const currentTier = getTierForPoints(p);

  if (p >= 280) {
    return {
      currentTier: RANK_TIERS[34],
      nextTier: null,
      remainingPoints: 0,
      progressPercent: 100,
      isMaxTier: true
    };
  }

  // Find next tier in line
  let nextTier: RankTier = ORDERED_STEPS[1]; // trial_staff by default

  for (let i = 0; i < ORDERED_STEPS.length; i++) {
    if (ORDERED_STEPS[i].minPoints > p) {
      nextTier = ORDERED_STEPS[i];
      break;
    }
  }

  const remainingPoints = Math.max(0, nextTier.minPoints - p);
  const span = Math.max(1, nextTier.minPoints - currentTier.minPoints);
  const currentProgress = Math.max(0, p - currentTier.minPoints);
  const progressPercent = Math.min(100, Math.round((currentProgress / span) * 100));

  return {
    currentTier,
    nextTier,
    remainingPoints,
    progressPercent,
    isMaxTier: false
  };
}

// Group staff members by tier ID
export function groupStaffByTier(
  staffList: StaffMember[]
): Record<string, StaffMember[]> {
  const groups: Record<string, StaffMember[]> = {};
  for (const tier of RANK_TIERS) {
    groups[tier.id] = [];
  }

  for (const member of staffList) {
    if (member.status === 'REMOVED') continue;
    const tier = getTierForPoints(member.points || 0, [], member.notes || '');
    if (groups[tier.id]) {
      groups[tier.id].push(member);
    } else {
      groups.cn_team.push(member);
    }
  }

  // Sort each tier group by points descending, then by display name
  for (const key of Object.keys(groups)) {
    groups[key].sort((a, b) => {
      const pDiff = (b.points || 0) - (a.points || 0);
      if (pDiff !== 0) return pDiff;
      return (a.displayName || a.username).localeCompare(b.displayName || b.username);
    });
  }

  return groups;
}
