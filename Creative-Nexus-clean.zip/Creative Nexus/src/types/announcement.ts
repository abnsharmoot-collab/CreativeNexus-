export interface Announcement {
  id: string;
  title: string;
  content: string;
  authorDisplayName: string;
  authorDiscordId: string;
  authorAvatarUrl?: string;
  category?: string;
  imageUrl?: string;
  images?: string[];
  isPinned: boolean;
  isArchived?: boolean;
  publishedAt: string;
  updatedAt: string;
}

export type AnnouncementCategory = 
  | 'Community' 
  | 'Update' 
  | 'Event' 
  | 'Important' 
  | 'Maintenance' 
  | 'Rules' 
  | 'General';

export const ANNOUNCEMENT_CATEGORIES: { id: AnnouncementCategory; labelEn: string; labelAr: string; color: string }[] = [
  { id: 'Important', labelEn: 'Important', labelAr: 'هام للغاية', color: 'bg-rose-500/15 text-rose-300 border-rose-500/30' },
  { id: 'Update', labelEn: 'Update', labelAr: 'تحديث', color: 'bg-archive-cyan/15 text-archive-cyan border-archive-cyan/30' },
  { id: 'Event', labelEn: 'Event', labelAr: 'فعالية', color: 'bg-amber-500/15 text-amber-300 border-amber-500/30' },
  { id: 'Community', labelEn: 'Community', labelAr: 'مجتمعي', color: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30' },
  { id: 'Rules', labelEn: 'Rules', labelAr: 'إرشادات وقوانين', color: 'bg-purple-500/15 text-purple-300 border-purple-500/30' },
  { id: 'Maintenance', labelEn: 'Maintenance', labelAr: 'صيانة', color: 'bg-orange-500/15 text-orange-300 border-orange-500/30' },
  { id: 'General', labelEn: 'General', labelAr: 'عام', color: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' }
];
