import { useState, useEffect, useRef, type RefObject } from 'react';

export interface UseScroll3DTiltOptions {
  cardRef: RefObject<HTMLDivElement | null>;
  isAlternate?: boolean;
  isHovered?: boolean;
  hoverRotateX?: number;
  hoverRotateY?: number;
  maxTiltX?: number;
  maxTiltY?: number;
  accentColorHex?: string;
  glowIntensity?: number;
  enabled?: boolean;
}

export interface UseScroll3DTiltReturn {
  rotateX: number;
  rotateY: number;
  transform: string;
  lightenProgress: number; // 0 to 1
  isIlluminated: boolean;
  glarePos: { x: number; y: number };
  glareOpacity: number;
  filterStyle: string;
  boxShadowStyle: string;
  auraScale: number;
  auraOpacity: number;
  scrollDirection: 'down' | 'up' | null;
  isScrolling: boolean;
}

export function useScroll3DTilt({
  cardRef,
  isAlternate = false,
  isHovered = false,
  hoverRotateX = 0,
  hoverRotateY = 0,
  maxTiltX = 2.8,
  maxTiltY = 1.8,
  accentColorHex = '#f59e0b',
  glowIntensity = 0.5,
  enabled = true,
}: UseScroll3DTiltOptions): UseScroll3DTiltReturn {
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [lightenProgress, setLightenProgress] = useState(0);
  const [glarePos, setGlarePos] = useState({ x: 50, y: 35 });
  const [glareOpacity, setGlareOpacity] = useState(0);
  const [scrollDirection, setScrollDirection] = useState<'down' | 'up' | null>(null);
  const [isScrolling, setIsScrolling] = useState(false);

  const currentValues = useRef({
    rx: 0,
    ry: 0,
    lighten: 0,
    glareX: 50,
    glareY: 35,
    glareOp: 0,
  });

  const lastScrollY = useRef(typeof window !== 'undefined' ? window.scrollY : 0);
  const scrollTimeout = useRef<number | null>(null);
  const velocityRef = useRef(0);
  const rafId = useRef<number | null>(null);
  const prefersReducedMotion = useRef(false);

  useEffect(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
      prefersReducedMotion.current = mq.matches;
      const onChange = (e: MediaQueryListEvent) => {
        prefersReducedMotion.current = e.matches;
      };
      mq.addEventListener('change', onChange);
      return () => mq.removeEventListener('change', onChange);
    }
  }, []);

  useEffect(() => {
    if (!enabled || typeof window === 'undefined') return;

    let isComponentMounted = true;

    const handleScroll = () => {
      const currentY = window.scrollY;
      const delta = currentY - lastScrollY.current;
      lastScrollY.current = currentY;

      if (Math.abs(delta) > 0.5) {
        const dir = delta > 0 ? 'down' : 'up';
        setScrollDirection(dir);
        // Normalize velocity between -1 and 1
        velocityRef.current = Math.max(-1, Math.min(1, delta / 25));
        setIsScrolling(true);

        if (scrollTimeout.current) {
          window.clearTimeout(scrollTimeout.current);
        }

        scrollTimeout.current = window.setTimeout(() => {
          if (isComponentMounted) {
            setIsScrolling(false);
            velocityRef.current = 0;
          }
        }, 220);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });

    // Animation frame physics loop
    const updatePhysics = () => {
      if (!isComponentMounted) return;

      const card = cardRef.current;
      if (!card) {
        rafId.current = requestAnimationFrame(updatePhysics);
        return;
      }

      const rect = card.getBoundingClientRect();
      const winHeight = window.innerHeight;

      // Card center relative to screen center
      const cardCenterY = rect.top + rect.height / 2;
      const screenCenterY = winHeight / 2;
      // -1 at top of screen, 0 at center, +1 at bottom
      const distFromCenter = (cardCenterY - screenCenterY) / (winHeight / 2);

      // Check if card is near or within viewport
      const isInView = rect.bottom > -150 && rect.top < winHeight + 150;

      let targetTiltX = 0;
      let targetTiltY = 0;
      let targetLighten = 0;
      let targetGlareX = isAlternate ? 42 : 58;
      let targetGlareY = 35;
      let targetGlareOp = 0;

      if (isInView && !prefersReducedMotion.current) {
        // Proximity to center viewport (1.0 at center, drops to 0 at edges)
        const proximity = Math.max(0, 1 - Math.abs(distFromCenter) * 1.15);

        // Viewport position tilt (slight angle looking toward the center of the user's screen)
        // When card is below center (distFromCenter > 0): tilts up slightly (-deg)
        // When card is above center (distFromCenter < 0): tilts down slightly (+deg)
        const posTiltX = -distFromCenter * 1.4;

        // Dynamic directional scroll inertia:
        // When scrolling down (velocity > 0): top edge eases backward (-1.2deg)
        // When scrolling up/going back (velocity < 0): top edge eases forward (+1.2deg)
        const scrollInertiaX = -velocityRef.current * 1.3;

        // Combined subtle Tilt X bounded to maxTiltX ("just a little bit")
        const rawTiltX = posTiltX + scrollInertiaX;
        targetTiltX = Math.max(-maxTiltX, Math.min(maxTiltX, rawTiltX));

        // Horizontal Tilt Y:
        // Subtle perspective convergence towards the central timeline spine
        // If isAlternate (right side): angle slightly to the left (-1.1 deg)
        // If not isAlternate (left side): angle slightly to the right (+1.1 deg)
        const spineTiltY = isAlternate ? -1.1 : 1.1;
        targetTiltY = Math.max(-maxTiltY, Math.min(maxTiltY, spineTiltY));

        // Lighten Up calculation:
        // Rises smoothly as the card traverses the viewport focus zone
        // Boosted during active scroll in either direction (moving down or going back)
        const activeScrollBonus = Math.abs(velocityRef.current) * 0.35;
        targetLighten = Math.min(1, proximity * 0.75 + activeScrollBonus);

        // Specular glare sweep tracks scroll movement:
        // As you scroll down (distFromCenter goes +1 -> -1), glare moves from top (20%) to bottom (80%)
        // As you scroll up/go back, glare moves smoothly back up to the top!
        targetGlareY = Math.round(Math.max(15, Math.min(85, 50 - distFromCenter * 35)));
        targetGlareOp = Math.min(0.24, 0.05 + targetLighten * 0.19);
      } else if (isInView && prefersReducedMotion.current) {
        // Reduced motion: subtle lighten without tilt
        const proximity = Math.max(0, 1 - Math.abs(distFromCenter) * 1.15);
        targetLighten = Math.min(0.6, proximity * 0.6);
        targetGlareOp = targetLighten * 0.12;
      }

      // If user is directly hovering this card with cursor, let hover mouse coordinates take priority
      if (isHovered && !prefersReducedMotion.current) {
        targetTiltX = hoverRotateX;
        targetTiltY = hoverRotateY;
        targetLighten = Math.max(targetLighten, 0.85);
        targetGlareOp = Math.max(targetGlareOp, 0.2);
      }

      // Spring / Lerp smoothing factors for 60fps butteriness
      const lerpFactor = isHovered ? 0.2 : 0.12;
      const lightenLerp = 0.14;

      currentValues.current.rx += (targetTiltX - currentValues.current.rx) * lerpFactor;
      currentValues.current.ry += (targetTiltY - currentValues.current.ry) * lerpFactor;
      currentValues.current.lighten += (targetLighten - currentValues.current.lighten) * lightenLerp;
      currentValues.current.glareY += (targetGlareY - currentValues.current.glareY) * lerpFactor;
      currentValues.current.glareOp += (targetGlareOp - currentValues.current.glareOp) * lightenLerp;

      // Update state with minimal threshold
      setRotateX(Number(currentValues.current.rx.toFixed(2)));
      setRotateY(Number(currentValues.current.ry.toFixed(2)));
      setLightenProgress(Number(currentValues.current.lighten.toFixed(3)));
      setGlarePos({ x: targetGlareX, y: Math.round(currentValues.current.glareY) });
      setGlareOpacity(Number(currentValues.current.glareOp.toFixed(3)));

      rafId.current = requestAnimationFrame(updatePhysics);
    };

    rafId.current = requestAnimationFrame(updatePhysics);

    return () => {
      isComponentMounted = false;
      window.removeEventListener('scroll', handleScroll);
      if (scrollTimeout.current) clearTimeout(scrollTimeout.current);
      if (rafId.current) cancelAnimationFrame(rafId.current);
    };
  }, [enabled, isAlternate, isHovered, hoverRotateX, hoverRotateY, maxTiltX, maxTiltY]);

  // Derived styling values
  const isIlluminated = lightenProgress > 0.15;
  
  // Transform string with 3D perspective and gentle scale boost on peak illumination
  const scaleValue = prefersReducedMotion.current 
    ? 1 
    : 1 + (isHovered ? 0.012 : lightenProgress * 0.006);

  const translateYValue = prefersReducedMotion.current
    ? 0
    : (isHovered ? -4 : -lightenProgress * 2.5);

  const transform = prefersReducedMotion.current
    ? 'perspective(1200px) rotateX(0deg) rotateY(0deg) translateY(0px) scale3d(1, 1, 1)'
    : `perspective(1200px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(${translateYValue.toFixed(1)}px) scale3d(${scaleValue.toFixed(3)}, ${scaleValue.toFixed(3)}, ${scaleValue.toFixed(3)})`;

  // Lighten-up filter
  const brightnessBoost = 1 + lightenProgress * 0.12;
  const contrastBoost = 1 + lightenProgress * 0.02;
  const filterStyle = lightenProgress > 0.05
    ? `brightness(${brightnessBoost.toFixed(3)}) contrast(${contrastBoost.toFixed(3)})`
    : 'none';

  // Dynamic box shadow with accent glow blooming during scroll through / lighten
  const hex = accentColorHex || '#f59e0b';
  const effectiveGlow = glowIntensity + lightenProgress * 0.45;
  const glowAlphaHex = Math.min(255, Math.max(0, Math.round(effectiveGlow * 130)))
    .toString(16)
    .padStart(2, '0');
  const glowRadius = Math.round(14 + effectiveGlow * 38);
  const insetAlpha = (0.12 + lightenProgress * 0.18).toFixed(2);

  const boxShadowStyle = `0 ${Math.round(20 + lightenProgress * 12)}px ${Math.round(50 + lightenProgress * 20)}px rgba(0,0,0,0.88), 0 0 ${glowRadius}px ${hex}${glowAlphaHex}, inset 0 1px 2px rgba(255,255,255,${insetAlpha})`;

  // Ambient aura behind card
  const auraScale = 0.95 + lightenProgress * 0.22;
  const auraOpacity = 0.35 + lightenProgress * 0.45;

  return {
    rotateX,
    rotateY,
    transform,
    lightenProgress,
    isIlluminated,
    glarePos,
    glareOpacity,
    filterStyle,
    boxShadowStyle,
    auraScale,
    auraOpacity,
    scrollDirection,
    isScrolling,
  };
}
