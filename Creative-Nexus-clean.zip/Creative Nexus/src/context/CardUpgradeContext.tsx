import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useAuth } from './AuthContext';
import { useCards } from './CardContext';
import { useItems } from './ItemContext';
import {
  CardUpgradeSystemConfig,
  CardUpgradeAttemptResult,
  DEFAULT_CARD_UPGRADE_CONFIG
} from '../types/cardUpgrade';

interface CardUpgradeContextType {
  upgradeConfig: CardUpgradeSystemConfig;
  loading: boolean;
  fetchUpgradeConfig: () => Promise<void>;
  saveOwnerUpgradeConfig: (config: Partial<CardUpgradeSystemConfig>) => Promise<{
    success: boolean;
    config: CardUpgradeSystemConfig;
  }>;
  attemptUpgradeCard: (cardId: string, preferredShardItemId?: string) => Promise<CardUpgradeAttemptResult>;
}

const CardUpgradeContext = createContext<CardUpgradeContextType | undefined>(undefined);

export const CardUpgradeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated } = useAuth();
  const { fetchCatalog } = useCards();
  const { fetchInventory } = useItems();
  const [upgradeConfig, setUpgradeConfig] = useState<CardUpgradeSystemConfig>(DEFAULT_CARD_UPGRADE_CONFIG);
  const [loading, setLoading] = useState<boolean>(true);

  // Fetch upgrade config
  const fetchUpgradeConfig = useCallback(async () => {
    try {
      const res = await fetch('/api/cards/upgrade-config');
      if (res.ok) {
        const data = await res.json();
        if (data.config) {
          setUpgradeConfig(data.config);
        }
      }
    } catch (err) {
      console.warn('CardUpgradeContext: Note fetching config:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchUpgradeConfig();
  }, [fetchUpgradeConfig]);

  // Save upgrade config (Owner only)
  const saveOwnerUpgradeConfig = useCallback(async (config: Partial<CardUpgradeSystemConfig>) => {
    const res = await fetch('/api/cards/owner/upgrade-config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(config)
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to update card upgrade configuration');
    }
    setUpgradeConfig(data.config);
    return data;
  }, []);

  // Attempt to upgrade a card
  const attemptUpgradeCard = useCallback(async (cardId: string, preferredShardItemId?: string) => {
    if (!isAuthenticated) {
      throw new Error('You must be signed in to upgrade cards.');
    }

    const res = await fetch('/api/cards/upgrade', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ cardId, preferredShardItemId })
    });

    const data: CardUpgradeAttemptResult = await res.json();
    if (!res.ok) {
      throw new Error((data as any).error || data.message || 'Upgrade attempt failed');
    }

    // Refresh user catalog and inventory
    await Promise.all([fetchCatalog(), fetchInventory()]);

    return data;
  }, [isAuthenticated, fetchCatalog, fetchInventory]);

  return (
    <CardUpgradeContext.Provider
      value={{
        upgradeConfig,
        loading,
        fetchUpgradeConfig,
        saveOwnerUpgradeConfig,
        attemptUpgradeCard
      }}
    >
      {children}
    </CardUpgradeContext.Provider>
  );
};

export const useCardUpgrade = () => {
  const context = useContext(CardUpgradeContext);
  if (!context) {
    throw new Error('useCardUpgrade must be used within a CardUpgradeProvider');
  }
  return context;
};
