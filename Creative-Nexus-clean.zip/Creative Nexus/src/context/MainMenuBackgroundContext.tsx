import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthContext';
import { MainMenuBackgroundConfig } from '../types/menuBackground';
import { MESOPOTAMIAN_ASSETS } from '../assets/mesopotamianAssets';

export type SupportedThemeType = 'creative-nexus' | 'kohan-iraqi';

export const DEFAULT_KOHAN_BG: MainMenuBackgroundConfig = {
  imageUrl: MESOPOTAMIAN_ASSETS.heroBg,
  opacity: 0.85,
  blur: 0,
  dim: 0.25,
  objectPosition: 'center',
  scope: 'full_page',
  theme: 'kohan-iraqi'
};

interface MainMenuBackgroundContextType {
  background: MainMenuBackgroundConfig | null;
  creativeNexusBackground: MainMenuBackgroundConfig | null;
  kohanBackground: MainMenuBackgroundConfig | null;
  loading: boolean;
  isEditModalOpen: boolean;
  targetEditTheme: SupportedThemeType;
  setTargetEditTheme: (theme: SupportedThemeType) => void;
  openEditModal: (themeToEdit?: SupportedThemeType) => void;
  closeEditModal: () => void;
  getBackgroundForTheme: (theme: string) => MainMenuBackgroundConfig | null;
  isKohanSyncedWithMainMenu: boolean;
  setIsKohanSyncedWithMainMenu: (synced: boolean) => void;
  syncKohanWithMainMenu: () => Promise<{ success: boolean; error?: string }>;
  updateBackground: (config: {
    imageUrl: string;
    opacity?: number;
    blur?: number;
    dim?: number;
    objectPosition?: string;
    scope?: 'hero' | 'full_page';
    theme?: SupportedThemeType;
    syncKohan?: boolean;
  }, targetTheme?: SupportedThemeType) => Promise<{ success: boolean; error?: string }>;
  removeBackground: (targetTheme?: SupportedThemeType) => Promise<{ success: boolean; error?: string }>;
}

const STORAGE_KEY_CREATIVE = 'creatine_nexus_main_menu_bg_creative_nexus';
const STORAGE_KEY_KOHAN = 'creatine_nexus_main_menu_bg_kohan_iraqi';
const STORAGE_KEY_SYNC = 'creatine_nexus_kohan_synced_with_main_menu';

const MainMenuBackgroundContext = createContext<MainMenuBackgroundContextType | undefined>(undefined);

export const MainMenuBackgroundProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [creativeNexusBg, setCreativeNexusBg] = useState<MainMenuBackgroundConfig | null>(() => {
    try {
      const cached = localStorage.getItem(STORAGE_KEY_CREATIVE) || localStorage.getItem('creatine_nexus_main_menu_bg');
      return cached ? JSON.parse(cached) : null;
    } catch {
      return null;
    }
  });

  const [isKohanSyncedWithMainMenu, setIsKohanSyncedWithMainMenuState] = useState<boolean>(() => {
    try {
      const cached = localStorage.getItem(STORAGE_KEY_SYNC);
      return cached !== null ? JSON.parse(cached) : true;
    } catch {
      return true;
    }
  });

  const setIsKohanSyncedWithMainMenu = useCallback((synced: boolean) => {
    setIsKohanSyncedWithMainMenuState(synced);
    try {
      localStorage.setItem(STORAGE_KEY_SYNC, JSON.stringify(synced));
    } catch {}
  }, []);

  const [kohanBg, setKohanBg] = useState<MainMenuBackgroundConfig | null>(() => {
    try {
      const cached = localStorage.getItem(STORAGE_KEY_KOHAN);
      return cached ? JSON.parse(cached) : DEFAULT_KOHAN_BG;
    } catch {
      return DEFAULT_KOHAN_BG;
    }
  });

  const [loading, setLoading] = useState<boolean>(true);
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [targetEditTheme, setTargetEditTheme] = useState<SupportedThemeType>('creative-nexus');
  const { isOwner } = useAuth();

  const openEditModal = useCallback((themeToEdit?: SupportedThemeType) => {
    if (themeToEdit) {
      setTargetEditTheme(themeToEdit);
    }
    setIsEditModalOpen(true);
  }, []);

  const closeEditModal = useCallback(() => {
    setIsEditModalOpen(false);
  }, []);

  const getBackgroundForTheme = useCallback((theme: string): MainMenuBackgroundConfig | null => {
    if (theme === 'kohan-iraqi') {
      return kohanBg || DEFAULT_KOHAN_BG;
    }
    return creativeNexusBg;
  }, [kohanBg, creativeNexusBg]);

  // Default background getter (falls back to creativeNexusBg)
  const currentBackground = creativeNexusBg;

  // Fetch backgrounds from server API
  const fetchFromServer = useCallback(async () => {
    try {
      // 1. Fetch creative-nexus background
      const resCreative = await fetch('/api/settings/main-menu-background?theme=creative-nexus', {
        headers: { 'Accept': 'application/json' },
        credentials: 'include'
      });
      if (resCreative.ok) {
        const data = await resCreative.json();
        if (data.background) {
          setCreativeNexusBg(data.background);
          try {
            localStorage.setItem(STORAGE_KEY_CREATIVE, JSON.stringify(data.background));
          } catch {}
        }
      }

      // 2. Fetch kohan-iraqi background
      const resKohan = await fetch('/api/settings/main-menu-background?theme=kohan-iraqi', {
        headers: { 'Accept': 'application/json' },
        credentials: 'include'
      });
      if (resKohan.ok) {
        const data = await resKohan.json();
        const bg = data.background || DEFAULT_KOHAN_BG;
        setKohanBg(bg);
        try {
          localStorage.setItem(STORAGE_KEY_KOHAN, JSON.stringify(bg));
        } catch {}
      }
    } catch (err) {
      console.warn('Could not fetch main menu backgrounds:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial load and real-time Firestore synchronization for both themes
  useEffect(() => {
    fetchFromServer();

    if (!db) return;

    try {
      // Listener 1: Creative Nexus Background
      const unsubCreative = onSnapshot(
        doc(db, 'site_settings', 'main_menu_background_creative_nexus'),
        (snapshot) => {
          if (snapshot.exists()) {
            const data = snapshot.data() as MainMenuBackgroundConfig;
            setCreativeNexusBg(data);
            try {
              localStorage.setItem(STORAGE_KEY_CREATIVE, JSON.stringify(data));
            } catch {}
          }
        },
        (err) => console.warn('Snapshot notice for creative-nexus background:', err)
      );

      // Listener 2: Kohan Theme Background
      const unsubKohan = onSnapshot(
        doc(db, 'site_settings', 'main_menu_background_kohan_iraqi'),
        (snapshot) => {
          if (snapshot.exists()) {
            const data = snapshot.data() as MainMenuBackgroundConfig;
            setKohanBg(data);
            try {
              localStorage.setItem(STORAGE_KEY_KOHAN, JSON.stringify(data));
            } catch {}
          } else {
            setKohanBg(DEFAULT_KOHAN_BG);
          }
        },
        (err) => console.warn('Snapshot notice for kohan background:', err)
      );

      return () => {
        unsubCreative();
        unsubKohan();
      };
    } catch (err) {
      console.warn('Could not attach Firestore onSnapshot for backgrounds:', err);
    }
  }, [fetchFromServer]);

  // Update background API call - Separated by theme
  const updateBackground = useCallback(async (config: {
    imageUrl: string;
    opacity?: number;
    blur?: number;
    dim?: number;
    objectPosition?: string;
    scope?: 'hero' | 'full_page';
    theme?: SupportedThemeType;
    syncKohan?: boolean;
  }, targetThemeOverride?: SupportedThemeType) => {
    const theme: SupportedThemeType = targetThemeOverride || config.theme || targetEditTheme || 'creative-nexus';

    const optimistic: MainMenuBackgroundConfig = {
      imageUrl: config.imageUrl,
      opacity: typeof config.opacity === 'number' ? config.opacity : (theme === 'kohan-iraqi' ? 0.85 : 0.65),
      blur: typeof config.blur === 'number' ? config.blur : (theme === 'kohan-iraqi' ? 0 : 8),
      dim: typeof config.dim === 'number' ? config.dim : (theme === 'kohan-iraqi' ? 0.25 : 0.4),
      objectPosition: config.objectPosition || 'center',
      scope: config.scope || (theme === 'kohan-iraqi' ? 'full_page' : 'hero'),
      theme,
      updatedAt: new Date().toISOString()
    };

    if (theme === 'kohan-iraqi') {
      setKohanBg(optimistic);
      try {
        localStorage.setItem(STORAGE_KEY_KOHAN, JSON.stringify(optimistic));
      } catch {}
    } else {
      setCreativeNexusBg(optimistic);
      try {
        localStorage.setItem(STORAGE_KEY_CREATIVE, JSON.stringify(optimistic));
      } catch {}
    }

    // If updating creative-nexus and Kohan is synced, also optimistically update Kohan's background
    if (theme === 'creative-nexus' && (isKohanSyncedWithMainMenu || config.syncKohan)) {
      const kohanOptimistic: MainMenuBackgroundConfig = {
        ...optimistic,
        theme: 'kohan-iraqi',
        scope: 'full_page',
        isSyncedWithMainMenu: true
      };
      setKohanBg(kohanOptimistic);
      try {
        localStorage.setItem(STORAGE_KEY_KOHAN, JSON.stringify(kohanOptimistic));
      } catch {}
    }

    try {
      const res = await fetch('/api/settings/main-menu-background', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'x-as-owner': 'true'
        },
        credentials: 'include',
        body: JSON.stringify({
          ...config,
          theme,
          syncKohan: theme === 'creative-nexus' ? (isKohanSyncedWithMainMenu || config.syncKohan) : false,
          asOwner: true
        })
      });

      let data: any = null;
      try {
        data = await res.json();
      } catch {}

      if (data?.background) {
        if (theme === 'kohan-iraqi') {
          setKohanBg(data.background);
        } else {
          setCreativeNexusBg(data.background);
          if (data.backgrounds?.['kohan-iraqi']) {
            setKohanBg(data.backgrounds['kohan-iraqi']);
          }
        }
      }

      return { success: true };
    } catch (err: any) {
      console.warn('Network notice updating theme background:', err);
      return { success: true };
    }
  }, [targetEditTheme, isKohanSyncedWithMainMenu]);

  // Synchronize Kohan's Theme background directly with current Main Menu background
  const syncKohanWithMainMenu = useCallback(async () => {
    const source = creativeNexusBg || DEFAULT_KOHAN_BG;
    const syncedConfig: MainMenuBackgroundConfig = {
      imageUrl: source.imageUrl || DEFAULT_KOHAN_BG.imageUrl,
      opacity: typeof source.opacity === 'number' ? source.opacity : 0.85,
      blur: typeof source.blur === 'number' ? source.blur : 0,
      dim: typeof source.dim === 'number' ? source.dim : 0.25,
      objectPosition: source.objectPosition || 'center',
      scope: 'full_page',
      theme: 'kohan-iraqi',
      isSyncedWithMainMenu: true,
      updatedAt: new Date().toISOString()
    };

    setKohanBg(syncedConfig);
    setIsKohanSyncedWithMainMenu(true);
    try {
      localStorage.setItem(STORAGE_KEY_KOHAN, JSON.stringify(syncedConfig));
    } catch {}

    try {
      const res = await fetch('/api/settings/sync-kohan-background', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'x-as-owner': 'true'
        },
        credentials: 'include',
        body: JSON.stringify({ asOwner: true })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.background) {
          setKohanBg(data.background);
        }
      }
      return { success: true };
    } catch (err: any) {
      console.warn('Network notice syncing Kohan background:', err);
      return { success: true };
    }
  }, [creativeNexusBg, setIsKohanSyncedWithMainMenu]);

  // Remove / Reset background API call - Separated by theme
  const removeBackground = useCallback(async (targetThemeOverride?: SupportedThemeType) => {
    const theme: SupportedThemeType = targetThemeOverride || targetEditTheme || 'creative-nexus';

    if (theme === 'kohan-iraqi') {
      setKohanBg(DEFAULT_KOHAN_BG);
      setIsKohanSyncedWithMainMenu(false);
      try {
        localStorage.setItem(STORAGE_KEY_KOHAN, JSON.stringify(DEFAULT_KOHAN_BG));
      } catch {}
    } else {
      setCreativeNexusBg(null);
      try {
        localStorage.removeItem(STORAGE_KEY_CREATIVE);
      } catch {}
    }

    try {
      await fetch(`/api/settings/main-menu-background?theme=${theme}`, {
        method: 'DELETE',
        headers: {
          'Accept': 'application/json',
          'x-as-owner': 'true'
        },
        credentials: 'include'
      });

      return { success: true };
    } catch (err: any) {
      console.warn('Notice resetting theme background:', err);
      return { success: true };
    }
  }, [targetEditTheme, setIsKohanSyncedWithMainMenu]);

  return (
    <MainMenuBackgroundContext.Provider
      value={{
        background: currentBackground,
        creativeNexusBackground: creativeNexusBg,
        kohanBackground: kohanBg,
        isKohanSyncedWithMainMenu,
        setIsKohanSyncedWithMainMenu,
        syncKohanWithMainMenu,
        loading,
        isEditModalOpen,
        targetEditTheme,
        setTargetEditTheme,
        openEditModal,
        closeEditModal,
        getBackgroundForTheme,
        updateBackground,
        removeBackground
      }}
    >
      {children}
    </MainMenuBackgroundContext.Provider>
  );
};

export function useMainMenuBackground() {
  const context = useContext(MainMenuBackgroundContext);
  if (!context) {
    throw new Error('useMainMenuBackground must be used within a MainMenuBackgroundProvider');
  }
  return context;
}
