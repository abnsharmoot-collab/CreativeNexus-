import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';

interface DownloadHtmlContextType {
  isDownloadModalOpen: boolean;
  openDownloadModal: () => void;
  closeDownloadModal: () => void;
}

const DownloadHtmlContext = createContext<DownloadHtmlContextType | undefined>(undefined);

export const DownloadHtmlProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  const openDownloadModal = useCallback(() => {
    setIsDownloadModalOpen(true);
  }, []);

  const closeDownloadModal = useCallback(() => {
    setIsDownloadModalOpen(false);
  }, []);

  return (
    <DownloadHtmlContext.Provider
      value={{
        isDownloadModalOpen,
        openDownloadModal,
        closeDownloadModal,
      }}
    >
      {children}
    </DownloadHtmlContext.Provider>
  );
};

export function useDownloadHtml(): DownloadHtmlContextType {
  const context = useContext(DownloadHtmlContext);
  if (!context) {
    return {
      isDownloadModalOpen: false,
      openDownloadModal: () => {
        if (typeof window !== 'undefined') {
          window.open('/standalone.html', '_blank');
        }
      },
      closeDownloadModal: () => {}
    };
  }
  return context;
}
