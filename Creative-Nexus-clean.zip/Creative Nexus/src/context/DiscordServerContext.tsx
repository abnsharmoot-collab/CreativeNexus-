import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

export interface DiscordChannel {
  id: string;
  name: string;
  type: number;
}

export interface DiscordServerInfo {
  guildId: string;
  serverName: string;
  onlineCount: number;
  totalMembers: number;
  staffCount: number;
  channelsCount: number;
  boostCount?: number;
  iconUrl?: string;
  bannerUrl?: string;
  instantInvite: string;
  channels: DiscordChannel[];
  isLive: boolean;
  syncSource?: string;
  botInGuild?: boolean;
  botInviteUrl?: string;
  lastSyncedAt: string;
}

export interface DiscordServerContextType {
  serverInfo: DiscordServerInfo;
  guildId: string;
  setGuildId: (id: string) => void;
  isLoading: boolean;
  isLive: boolean;
  refreshServerInfo: (overrideGuildId?: string) => Promise<void>;
  updateGuildConfig: (config: {
    guildId: string;
    instantInvite?: string;
    inviteCode?: string;
    botToken?: string;
  }) => Promise<{ success: boolean; message: string }>;
}

const DEFAULT_SERVER_INFO: DiscordServerInfo = {
  guildId: '1337616297432842252',
  serverName: 'Creative Nexus || مركز الابداع',
  onlineCount: 78,
  totalMembers: 580,
  staffCount: 11,
  channelsCount: 7,
  boostCount: 4,
  iconUrl: 'https://cdn.discordapp.com/icons/1337616297432842252/3fa0c7a525135a95cac97bd0128205cb.png?size=256',
  bannerUrl: 'https://cdn.discordapp.com/banners/1337616297432842252/0611545c6859b6fb38783fe9be02ba00.png?size=1024',
  instantInvite: 'https://discord.gg/7wEm4bhc',
  channels: [
    { id: '2', name: '💬│chat', type: 0 },
    { id: '1355959770485358723', name: '⇜𝐖𝐞𝐥𝐜𝐨𝐦𝐞⥐', type: 0 },
    { id: '1', name: '📢│announcements', type: 0 },
    { id: '3', name: '🎨│edgar-art-showcase', type: 0 },
    { id: '4', name: '🔴│live-streams', type: 0 },
    { id: '5', name: '🔊│creatine-voice-hub', type: 2 },
    { id: '6', name: '👑│owners-sanctuary', type: 0 }
  ],
  isLive: true,
  syncSource: 'discord_invite_api',
  lastSyncedAt: new Date().toISOString()
};

const DiscordServerContext = createContext<DiscordServerContextType | undefined>(undefined);

export const DiscordServerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [guildId, setGuildIdState] = useState<string>(() => {
    const saved = localStorage.getItem('creatine_nexus_guild_id');
    if (!saved || saved === '1080000000000000000') {
      return '1337616297432842252';
    }
    return saved;
  });
  const [serverInfo, setServerInfo] = useState<DiscordServerInfo>(DEFAULT_SERVER_INFO);
  const [isLoading, setIsLoading] = useState(false);

  const setGuildId = (newId: string) => {
    const cleanId = newId.trim();
    setGuildIdState(cleanId);
    localStorage.setItem('creatine_nexus_guild_id', cleanId);
  };

  const refreshServerInfo = useCallback(async (overrideGuildId?: string) => {
    const targetGuildId = overrideGuildId || (guildId !== '1080000000000000000' ? guildId : '');
    setIsLoading(true);
    try {
      const url = targetGuildId 
        ? `/api/discord/server-status?guildId=${encodeURIComponent(targetGuildId)}`
        : `/api/discord/server-status`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        if (data.guildId && data.guildId !== '1080000000000000000') {
          setGuildIdState(data.guildId);
          localStorage.setItem('creatine_nexus_guild_id', data.guildId);
        }
        setServerInfo(prev => ({
          ...prev,
          guildId: data.guildId || prev.guildId,
          serverName: data.serverName || prev.serverName,
          onlineCount: Number(data.onlineCount) ?? prev.onlineCount,
          totalMembers: Number(data.totalMembers) ?? prev.totalMembers,
          staffCount: Number(data.staffCount) ?? prev.staffCount,
          channelsCount: Number(data.channelsCount) || (data.channels?.length ?? prev.channelsCount),
          boostCount: typeof data.boostCount === 'number' ? data.boostCount : prev.boostCount,
          iconUrl: data.iconUrl || prev.iconUrl,
          bannerUrl: data.bannerUrl || prev.bannerUrl,
          instantInvite: data.instantInvite || prev.instantInvite,
          channels: Array.isArray(data.channels) && data.channels.length > 0 ? data.channels : prev.channels,
          isLive: Boolean(data.isLive),
          syncSource: data.syncSource || prev.syncSource,
          botInGuild: data.botInGuild,
          botInviteUrl: data.botInviteUrl,
          lastSyncedAt: data.lastSyncedAt || new Date().toISOString()
        }));
      }
    } catch (err) {
      console.warn('Failed to fetch Discord server status:', err);
    } finally {
      setIsLoading(false);
    }
  }, [guildId]);

  // Sync guild configuration with backend
  const updateGuildConfig = async (config: {
    guildId: string;
    instantInvite?: string;
    inviteCode?: string;
    botToken?: string;
  }) => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/discord/guild-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      const data = await res.json();
      if (res.ok) {
        setGuildId(config.guildId);
        await refreshServerInfo(config.guildId);
        return { success: true, message: data.message || 'Guild configuration updated' };
      }
      return { success: false, message: data.error || 'Failed to update Guild configuration' };
    } catch (err: any) {
      return { success: false, message: err?.message || 'Connection failed' };
    } finally {
      setIsLoading(false);
    }
  };

  // Initial load
  useEffect(() => {
    refreshServerInfo();
    // Poll every 60 seconds for live member and presence updates
    const interval = setInterval(() => {
      refreshServerInfo();
    }, 60000);
    return () => clearInterval(interval);
  }, [refreshServerInfo]);

  return (
    <DiscordServerContext.Provider
      value={{
        serverInfo,
        guildId,
        setGuildId,
        isLoading,
        isLive: serverInfo.isLive,
        refreshServerInfo,
        updateGuildConfig
      }}
    >
      {children}
    </DiscordServerContext.Provider>
  );
};

export const useDiscordServer = () => {
  const context = useContext(DiscordServerContext);
  if (!context) {
    throw new Error('useDiscordServer must be used within a DiscordServerProvider');
  }
  return context;
};
