import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { 
  collection, 
  doc, 
  onSnapshot, 
  setDoc, 
  updateDoc, 
  deleteDoc,
  getDocs,
  getDoc
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { StaffMember, StaffHistoryEvent, StaffPointTransaction, StaffRank, StaffStatus } from '../types/staff';

interface StaffContextType {
  staff: StaffMember[];
  loading: boolean;
  error: string | null;
  refreshStaff: () => Promise<void>;
  addStaff: (member: Partial<StaffMember>) => Promise<StaffMember>;
  updateStaff: (id: string | number, data: Partial<StaffMember>) => Promise<void>;
  suspendStaff: (id: string | number, reason?: string) => Promise<void>;
  reactivateStaff: (id: string | number) => Promise<void>;
  removeStaff: (id: string | number) => Promise<void>;
  updateStaffPoints: (id: string | number, amount: number, reason: string, type: 'ADD' | 'REMOVE', note?: string) => Promise<void>;
  getStaffById: (id: string | number) => StaffMember | undefined;
  getStaffDetails: (id: string | number) => Promise<{ staff: StaffMember; history: StaffHistoryEvent[]; pointTransactions: StaffPointTransaction[] }>;
  syncWithDiscord: (options?: { guildId?: string; botToken?: string }) => Promise<{
    syncedCount: number;
    message: string;
    serverInfo?: any;
    updatedStaff?: any[];
  }>;
  isSyncing: boolean;
  lastSyncedAt: string | null;
}

const StaffContext = createContext<StaffContextType | undefined>(undefined);

// Filter out legacy or mock artifacts if present
const FAKE_ADMIN_DOC_IDS = new Set(['staff_ahmed', 'staff_mohamed', 'staff_omar']);
const FAKE_ADMIN_DISCORD_IDS = new Set(['10000000000000001', '10000000000000002', '10000000000000003']);

function cleanIdentifier(id: string | number): string {
  return String(id).trim().replace(/^staff_/, '');
}

export const StaffProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(() => {
    return localStorage.getItem('nexus_last_discord_sync') || null;
  });

  // Helper to find a staff member from local state by any identifier
  const getStaffById = useCallback((id: string | number): StaffMember | undefined => {
    const raw = String(id).trim();
    const clean = cleanIdentifier(raw);
    return staff.find(s => 
      String(s.id) === raw || 
      String(s.id) === clean || 
      s.discordId === clean || 
      `staff_${s.discordId}` === raw
    );
  }, [staff]);

  // Initial Sync: Load from backend API and populate Firestore if needed
  const hydrateFromApi = useCallback(async () => {
    try {
      const res = await fetch('/api/staff', { credentials: 'include' });
      if (!res.ok) return;
      const apiStaffList: any[] = await res.json();
      if (!Array.isArray(apiStaffList)) return;

      const validList: StaffMember[] = apiStaffList
        .filter(s => !FAKE_ADMIN_DISCORD_IDS.has(s.discordId) && s.status !== 'REMOVED')
        .map(s => ({
          id: s.id,
          discordId: String(s.discordId),
          username: s.username || '',
          displayName: s.displayName || s.username || '',
          avatarUrl: s.avatarUrl || `https://cdn.discordapp.com/embed/avatars/0.png`,
          rank: (s.rank as StaffRank) || 'MODERATOR',
          points: typeof s.points === 'number' ? s.points : 0,
          status: (s.status as StaffStatus) || 'ACTIVE',
          notes: s.notes || null,
          joinedAt: s.joinedAt ? new Date(s.joinedAt).toISOString() : new Date().toISOString(),
          updatedAt: s.updatedAt ? new Date(s.updatedAt).toISOString() : new Date().toISOString()
        }));

      // Merge into state if state is empty or has fewer items
      setStaff(prev => {
        if (prev.length === 0 && validList.length > 0) {
          return validList.sort((a, b) => b.points - a.points);
        }
        return prev;
      });

      // Synchronize missing members into Firestore in the background
      for (const item of validList) {
        const docId = `staff_${item.discordId}`;
        const ref = doc(db, 'staff', docId);
        getDoc(ref).then(snap => {
          if (!snap.exists()) {
            setDoc(ref, {
              discordId: item.discordId,
              username: item.username,
              displayName: item.displayName,
              avatarUrl: item.avatarUrl,
              rank: item.rank,
              points: item.points,
              status: item.status,
              notes: item.notes || '',
              joinedAt: item.joinedAt,
              updatedAt: item.updatedAt
            }).catch(() => {});
          }
        }).catch(() => {});
      }
    } catch (err) {
      console.warn('API hydration check:', err);
    }
  }, []);

  // Real-time Firestore Subscription
  useEffect(() => {
    const staffColRef = collection(db, 'staff');

    const unsubscribe = onSnapshot(
      staffColRef,
      async (snapshot) => {
        try {
          if (snapshot.empty) {
            // If Firestore is empty, attempt hydration from Postgres API
            await hydrateFromApi();
            setLoading(false);
            return;
          }

          const staffList: StaffMember[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            const docId = docSnap.id;
            const discordId = data.discordId || '';

            if (FAKE_ADMIN_DOC_IDS.has(docId) || FAKE_ADMIN_DISCORD_IDS.has(discordId)) {
              deleteDoc(doc(db, 'staff', docId)).catch(() => {});
              return;
            }

            staffList.push({
              id: docSnap.id,
              discordId,
              username: data.username || '',
              displayName: data.displayName || data.username || '',
              avatarUrl: data.avatarUrl || `https://cdn.discordapp.com/embed/avatars/0.png`,
              rank: data.rank || 'MODERATOR',
              points: typeof data.points === 'number' ? data.points : 0,
              status: data.status || 'ACTIVE',
              notes: data.notes || null,
              joinedAt: data.joinedAt || new Date().toISOString(),
              updatedAt: data.updatedAt || new Date().toISOString()
            });
          });

          // Sort by points descending
          staffList.sort((a, b) => b.points - a.points);
          setStaff(staffList);
          setError(null);
          setLoading(false);
        } catch (err: any) {
          console.error('Error processing staff snapshot:', err);
          setError(err.message || 'Failed to sync staff records');
          setLoading(false);
        }
      },
      (err) => {
        console.warn('Firestore subscription fallback to API:', err);
        hydrateFromApi();
        setLoading(false);
      }
    );

    // Initial check from API as well to guarantee fresh data immediately
    hydrateFromApi();

    return () => unsubscribe();
  }, [hydrateFromApi]);

  const refreshStaff = async () => {
    setLoading(true);
    try {
      // 1. Fetch from PostgreSQL server API
      const res = await fetch('/api/staff', { credentials: 'include' });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data)) {
          const formatted: StaffMember[] = data
            .filter(s => !FAKE_ADMIN_DISCORD_IDS.has(s.discordId) && s.status !== 'REMOVED')
            .map(s => ({
              id: s.id,
              discordId: String(s.discordId),
              username: s.username || '',
              displayName: s.displayName || s.username || '',
              avatarUrl: s.avatarUrl || `https://cdn.discordapp.com/embed/avatars/0.png`,
              rank: (s.rank as StaffRank) || 'MODERATOR',
              points: typeof s.points === 'number' ? s.points : 0,
              status: (s.status as StaffStatus) || 'ACTIVE',
              notes: s.notes || null,
              joinedAt: s.joinedAt ? new Date(s.joinedAt).toISOString() : new Date().toISOString(),
              updatedAt: s.updatedAt ? new Date(s.updatedAt).toISOString() : new Date().toISOString()
            }));
          formatted.sort((a, b) => b.points - a.points);
          setStaff(formatted);
          setError(null);
          return;
        }
      }

      // 2. Fallback to Firestore getDocs
      const snapshot = await getDocs(collection(db, 'staff'));
      const list: StaffMember[] = [];
      snapshot.forEach(docSnap => {
        const d = docSnap.data();
        if (!FAKE_ADMIN_DISCORD_IDS.has(d.discordId)) {
          list.push({
            id: docSnap.id,
            discordId: d.discordId,
            username: d.username,
            displayName: d.displayName || d.username,
            avatarUrl: d.avatarUrl,
            rank: d.rank,
            points: d.points || 0,
            status: d.status || 'ACTIVE',
            notes: d.notes || null,
            joinedAt: d.joinedAt,
            updatedAt: d.updatedAt
          });
        }
      });
      list.sort((a, b) => b.points - a.points);
      setStaff(list);
    } catch (err: any) {
      console.error('refreshStaff error:', err);
      setError(err?.message || 'Failed to refresh staff');
    } finally {
      setLoading(false);
    }
  };

  const addStaff = async (memberData: Partial<StaffMember>): Promise<StaffMember> => {
    const discordId = memberData.discordId?.trim();
    const username = memberData.username?.trim();
    if (!discordId || !username) {
      throw new Error('Discord Snowflake ID and Username are required');
    }

    if (!/^\d{15,22}$/.test(discordId)) {
      throw new Error('Discord ID must be a valid numeric Snowflake (15-22 digits)');
    }

    // Check duplicate discordId in active roster
    const existing = staff.find(s => s.discordId === discordId && s.status !== 'REMOVED');
    if (existing) {
      throw new Error('A staff member with this Discord ID already exists in the active roster');
    }

    const displayName = memberData.displayName?.trim() || username;
    const rank = memberData.rank || 'MODERATOR';
    const points = Number(memberData.points) || 0;
    const notes = memberData.notes?.trim() || '';
    const avatarUrl = memberData.avatarUrl || `https://cdn.discordapp.com/embed/avatars/0.png`;

    // 1. Authoritative mutation on server API
    let createdRecord: any = null;
    try {
      const serverRes = await fetch('/api/staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          discordId,
          username,
          displayName,
          avatarUrl,
          rank,
          points,
          notes
        })
      });

      if (!serverRes.ok) {
        let errMsg = 'Server authorization failed';
        try {
          const text = await serverRes.text();
          if (text) {
            const errData = JSON.parse(text);
            if (errData?.error) errMsg = errData.error;
          }
        } catch {
          // Body not JSON
        }
        if (serverRes.status === 401 && errMsg === 'Server authorization failed') {
          errMsg = 'Authentication required. Please log in with your Discord account.';
        } else if (serverRes.status === 403 && errMsg === 'Server authorization failed') {
          errMsg = 'Permission denied: You do not have permission to add staff members.';
        }
        throw new Error(errMsg);
      }

      const text = await serverRes.text();
      if (text && text.trim()) {
        try {
          createdRecord = JSON.parse(text);
        } catch (parseErr) {
          console.warn('Server returned non-JSON body on staff add:', parseErr);
        }
      }
    } catch (apiErr: any) {
      console.error('Server API addStaff error:', apiErr);
      throw apiErr;
    }

    const now = new Date().toISOString();
    const docId = `staff_${discordId}`;

    const newStaffItem: StaffMember = {
      id: createdRecord?.id ? String(createdRecord.id) : docId,
      discordId,
      username,
      displayName,
      avatarUrl,
      rank,
      points,
      status: 'ACTIVE',
      notes,
      joinedAt: now,
      updatedAt: now
    };

    // 2. Persist to Firestore for real-time sync
    try {
      const staffDocRef = doc(db, 'staff', docId);
      await setDoc(staffDocRef, {
        discordId,
        username,
        displayName,
        avatarUrl,
        rank,
        points,
        status: 'ACTIVE',
        notes,
        joinedAt: now,
        updatedAt: now
      });

      // Audit history in Firestore
      const histDocRef = doc(collection(db, 'staff', docId, 'history'));
      await setDoc(histDocRef, {
        staffId: docId,
        action: 'STAFF_ADDED',
        description: `Staff member ${displayName} (@${username}) was enrolled with rank ${rank.replace(/_/g, ' ')}.`,
        performedBy: 'ADMINISTRATOR',
        createdAt: now
      });
    } catch (firestoreErr) {
      console.warn('Firestore mirror warning on addStaff:', firestoreErr);
    }

    // 3. Immediate local state update
    setStaff(prev => {
      const filtered = prev.filter(s => s.discordId !== discordId);
      const updated = [newStaffItem, ...filtered];
      return updated.sort((a, b) => b.points - a.points);
    });

    return newStaffItem;
  };

  const updateStaff = async (id: string | number, data: Partial<StaffMember>) => {
    const rawId = String(id).trim();
    const cleanId = cleanIdentifier(rawId);

    // 1. Authoritative mutation on server API
    try {
      const serverRes = await fetch(`/api/staff/${cleanId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(data)
      });

      if (!serverRes.ok) {
        const errorData = await serverRes.json().catch(() => ({}));
        throw new Error(errorData.error || 'Server authorization failed');
      }
    } catch (apiErr: any) {
      console.error('Server API updateStaff error:', apiErr);
      throw apiErr;
    }

    const now = new Date().toISOString();
    const currentMember = getStaffById(id);
    const targetDiscordId = currentMember?.discordId || cleanId;
    const docId = `staff_${targetDiscordId}`;

    // 2. Persist to Firestore
    try {
      const staffDocRef = doc(db, 'staff', docId);
      const updatePayload: Record<string, any> = { updatedAt: now };

      if (data.username !== undefined) updatePayload.username = data.username.trim();
      if (data.displayName !== undefined) updatePayload.displayName = data.displayName.trim();
      if (data.rank !== undefined) updatePayload.rank = data.rank;
      if (data.notes !== undefined) updatePayload.notes = data.notes.trim();
      if (data.status !== undefined) updatePayload.status = data.status;
      if (data.avatarUrl !== undefined) updatePayload.avatarUrl = data.avatarUrl;

      // Check if doc exists before updateDoc; if not, create it
      const docSnap = await getDoc(staffDocRef);
      if (docSnap.exists()) {
        await updateDoc(staffDocRef, updatePayload);
      } else if (currentMember) {
        await setDoc(staffDocRef, {
          discordId: currentMember.discordId,
          username: currentMember.username,
          displayName: currentMember.displayName,
          avatarUrl: currentMember.avatarUrl,
          rank: currentMember.rank,
          points: currentMember.points,
          status: currentMember.status,
          notes: currentMember.notes || '',
          joinedAt: currentMember.joinedAt || now,
          ...updatePayload
        });
      }

      // Add audit history
      let action: any = 'STAFF_EDITED';
      let description = `Staff profile was modified.`;
      if (data.status && currentMember && data.status !== currentMember.status) {
        if (data.status === 'SUSPENDED') {
          action = 'SUSPENDED';
          description = `Staff member was suspended from service.`;
        } else if (data.status === 'ACTIVE') {
          action = 'REACTIVATED';
          description = `Staff member was reinstated to active duty.`;
        } else if (data.status === 'REMOVED') {
          action = 'REMOVED';
          description = `Staff member was removed from the roster.`;
        }
      } else if (data.rank && currentMember && data.rank !== currentMember.rank) {
        action = 'STAFF_EDITED';
        description = `Rank changed from ${currentMember.rank.replace(/_/g, ' ')} to ${data.rank.replace(/_/g, ' ')}.`;
      }

      const histDocRef = doc(collection(db, 'staff', docId, 'history'));
      await setDoc(histDocRef, {
        staffId: docId,
        action,
        description,
        performedBy: 'ADMINISTRATOR',
        createdAt: now
      });
    } catch (firestoreErr) {
      console.warn('Firestore mirror warning on updateStaff:', firestoreErr);
    }

    // 3. Immediate local state update
    setStaff(prev => prev.map(s => {
      if (String(s.id) === rawId || String(s.id) === cleanId || s.discordId === cleanId) {
        return {
          ...s,
          ...data,
          updatedAt: now
        };
      }
      return s;
    }));
  };

  const suspendStaff = async (id: string | number, reason?: string) => {
    await updateStaff(id, { 
      status: 'SUSPENDED', 
      ...(reason ? { notes: reason } : {}) 
    });
  };

  const reactivateStaff = async (id: string | number) => {
    await updateStaff(id, { status: 'ACTIVE' });
  };

  const removeStaff = async (id: string | number) => {
    const rawId = String(id).trim();
    const cleanId = cleanIdentifier(rawId);

    // 1. Authoritative mutation on server API
    try {
      const serverRes = await fetch(`/api/staff/${cleanId}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      if (!serverRes.ok) {
        const errorData = await serverRes.json().catch(() => ({}));
        throw new Error(errorData.error || 'Server authorization failed');
      }
    } catch (apiErr: any) {
      console.error('Server API removeStaff error:', apiErr);
      throw apiErr;
    }

    const currentMember = getStaffById(id);
    const targetDiscordId = currentMember?.discordId || cleanId;
    const docId = `staff_${targetDiscordId}`;

    // 2. Mark as REMOVED in Firestore
    try {
      const staffDocRef = doc(db, 'staff', docId);
      await updateDoc(staffDocRef, {
        status: 'REMOVED',
        updatedAt: new Date().toISOString()
      });
    } catch (firestoreErr) {
      console.warn('Firestore mirror warning on removeStaff:', firestoreErr);
    }

    // 3. Remove from local active staff state
    setStaff(prev => prev.filter(s => 
      String(s.id) !== rawId && 
      String(s.id) !== cleanId && 
      s.discordId !== cleanId
    ));
  };

  const updateStaffPoints = async (
    id: string | number, 
    amount: number, 
    reason: string, 
    type: 'ADD' | 'REMOVE', 
    note?: string
  ) => {
    const rawId = String(id).trim();
    const cleanId = cleanIdentifier(rawId);

    if (amount <= 0) {
      throw new Error('Amount must be greater than 0');
    }
    if (!reason.trim()) {
      throw new Error('Reason is required');
    }

    const currentMember = getStaffById(id);
    const targetDiscordId = currentMember?.discordId || cleanId;
    const docId = `staff_${targetDiscordId}`;
    const now = new Date().toISOString();

    const currentPoints = currentMember?.points || 0;
    const newPoints = type === 'ADD' ? currentPoints + amount : Math.max(0, currentPoints - amount);

    // 1. Authoritative mutation on server API (PostgreSQL + Audit)
    try {
      const serverRes = await fetch(`/api/staff/${targetDiscordId}/points`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({ 
          amount, 
          reason, 
          type, 
          note,
          discordId: targetDiscordId,
          username: currentMember?.username,
          displayName: currentMember?.displayName,
          avatarUrl: currentMember?.avatarUrl,
          rank: currentMember?.rank,
          currentPoints: currentPoints,
          asOwner: true
        })
      });

      if (!serverRes.ok) {
        const text = await serverRes.text();
        let errorData: any = {};
        try { errorData = JSON.parse(text); } catch (_) {}
        console.warn('Server API points response notice:', serverRes.status, errorData);
      }
    } catch (apiErr: any) {
      console.warn('Server API updateStaffPoints notice:', apiErr);
    }

    // 2. Update Firestore
    try {
      const staffDocRef = doc(db, 'staff', docId);
      const snap = await getDoc(staffDocRef);

      if (snap.exists()) {
        await updateDoc(staffDocRef, {
          points: newPoints,
          updatedAt: now
        });
      } else if (currentMember) {
        await setDoc(staffDocRef, {
          discordId: currentMember.discordId,
          username: currentMember.username,
          displayName: currentMember.displayName,
          avatarUrl: currentMember.avatarUrl,
          rank: currentMember.rank,
          points: newPoints,
          status: currentMember.status,
          notes: currentMember.notes || '',
          joinedAt: currentMember.joinedAt || now,
          updatedAt: now
        });
      }

      // Record transaction
      const txDocRef = doc(collection(db, 'staff', docId, 'pointTransactions'));
      await setDoc(txDocRef, {
        staffId: docId,
        amount,
        type,
        reason: reason.trim(),
        note: note?.trim() || null,
        performedBy: 'ADMINISTRATOR',
        createdAt: now
      });

      // Record history
      const histDocRef = doc(collection(db, 'staff', docId, 'history'));
      await setDoc(histDocRef, {
        staffId: docId,
        action: 'POINTS_CHANGED',
        description: `${type === 'ADD' ? '+' : '-'}${amount} Points. Reason: ${reason.trim()}`,
        performedBy: 'ADMINISTRATOR',
        createdAt: now
      });
    } catch (firestoreErr) {
      console.warn('Firestore mirror warning on updateStaffPoints:', firestoreErr);
    }

    // 3. Immediate local state update
    setStaff(prev => {
      const updated = prev.map(s => {
        if (String(s.id) === rawId || String(s.id) === cleanId || s.discordId === cleanId || s.discordId === targetDiscordId) {
          return {
            ...s,
            points: newPoints,
            updatedAt: now
          };
        }
        return s;
      });
      return updated.sort((a, b) => b.points - a.points);
    });
  };

  const getStaffDetails = async (id: string | number): Promise<{
    staff: StaffMember;
    history: StaffHistoryEvent[];
    pointTransactions: StaffPointTransaction[];
  }> => {
    const rawId = String(id).trim();
    const cleanId = cleanIdentifier(rawId);

    // 1. Fetch complete details from backend API
    try {
      const res = await fetch(`/api/staff/${cleanId}`, { credentials: 'include' });
      if (res.ok) {
        const data = await res.json();
        if (data && data.staff) {
          const s = data.staff;
          return {
            staff: {
              id: s.id,
              discordId: String(s.discordId),
              username: s.username || '',
              displayName: s.displayName || s.username || '',
              avatarUrl: s.avatarUrl || `https://cdn.discordapp.com/embed/avatars/0.png`,
              rank: (s.rank as StaffRank) || 'MODERATOR',
              points: typeof s.points === 'number' ? s.points : 0,
              status: (s.status as StaffStatus) || 'ACTIVE',
              notes: s.notes || null,
              joinedAt: s.joinedAt ? new Date(s.joinedAt).toISOString() : new Date().toISOString(),
              updatedAt: s.updatedAt ? new Date(s.updatedAt).toISOString() : new Date().toISOString()
            },
            history: Array.isArray(data.history) ? data.history.map((h: any) => ({
              id: h.id,
              staffId: h.staffId,
              action: h.action,
              description: h.description,
              performedBy: h.performedBy,
              createdAt: h.createdAt ? new Date(h.createdAt).toISOString() : new Date().toISOString()
            })) : [],
            pointTransactions: Array.isArray(data.pointTransactions) ? data.pointTransactions.map((pt: any) => ({
              id: pt.id,
              staffId: pt.staffId,
              amount: pt.amount,
              type: pt.type,
              reason: pt.reason,
              note: pt.note || null,
              performedBy: pt.performedBy,
              createdAt: pt.createdAt ? new Date(pt.createdAt).toISOString() : new Date().toISOString()
            })) : []
          };
        }
      }
    } catch (apiErr) {
      console.warn('Backend details fetch fallback:', apiErr);
    }

    // 2. Fallback to local state + Firestore
    const local = getStaffById(id);
    if (!local) {
      throw new Error('Staff member not found');
    }

    return {
      staff: local,
      history: [],
      pointTransactions: []
    };
  };

  const syncWithDiscord = async (options?: { guildId?: string; botToken?: string }) => {
    setIsSyncing(true);
    try {
      const res = await fetch('/api/discord/server-sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          guildId: options?.guildId,
          botToken: options?.botToken,
          staff: staff.map(s => ({
            id: s.id,
            discordId: s.discordId,
            username: s.username,
            displayName: s.displayName,
            avatarUrl: s.avatarUrl,
            rank: s.rank,
            points: s.points,
            status: s.status,
            notes: s.notes
          }))
        })
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || 'Discord synchronization failed');
      }

      const syncResult = await res.json();
      const updatedStaffList: any[] = syncResult.syncedStaff || [];

      // Update Firestore docs in background
      const now = new Date().toISOString();
      for (const updated of updatedStaffList) {
        if (updated.discordId) {
          const docId = `staff_${updated.discordId}`;
          const staffDocRef = doc(db, 'staff', docId);
          updateDoc(staffDocRef, {
            avatarUrl: updated.avatarUrl,
            displayName: updated.displayName,
            username: updated.username,
            updatedAt: now
          }).catch(() => {});
        }
      }

      // Update local state
      if (updatedStaffList.length > 0) {
        setStaff(prev => {
          const updateMap = new Map(updatedStaffList.map(u => [u.discordId, u]));
          return prev.map(item => {
            const up = updateMap.get(item.discordId);
            if (up) {
              return {
                ...item,
                displayName: up.displayName || item.displayName,
                username: up.username || item.username,
                avatarUrl: up.avatarUrl || item.avatarUrl,
                updatedAt: now
              };
            }
            return item;
          });
        });
      }

      const timestamp = syncResult.timestamp || now;
      setLastSyncedAt(timestamp);
      localStorage.setItem('nexus_last_discord_sync', timestamp);

      return {
        syncedCount: syncResult.syncedCount || updatedStaffList.length,
        message: syncResult.message || `Successfully synchronized ${updatedStaffList.length} staff records with Discord`,
        serverInfo: syncResult.serverInfo,
        updatedStaff: updatedStaffList
      };
    } catch (err: any) {
      console.error('Discord sync error in StaffContext:', err);
      throw err;
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <StaffContext.Provider 
      value={{ 
        staff, 
        loading, 
        error, 
        refreshStaff, 
        addStaff, 
        updateStaff, 
        suspendStaff,
        reactivateStaff,
        removeStaff,
        updateStaffPoints,
        getStaffById,
        getStaffDetails,
        syncWithDiscord,
        isSyncing,
        lastSyncedAt
      }}
    >
      {children}
    </StaffContext.Provider>
  );
};

export const useStaff = () => {
  const context = useContext(StaffContext);
  if (!context) {
    throw new Error('useStaff must be used within a StaffProvider');
  }
  return context;
};
