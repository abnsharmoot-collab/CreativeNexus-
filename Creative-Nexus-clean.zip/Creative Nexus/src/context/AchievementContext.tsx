import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthContext';
import { useStaff } from './StaffContext';
import { useRankApplications } from './RankApplicationContext';
import { useCards } from './CardContext';
import { 
  ALL_ACHIEVEMENTS, 
  AchievementDefinition, 
  AchievementEvaluationData,
  UserAchievementDoc,
  getAchievementCoinReward,
  getRoleCoinMultiplier,
  RoleMultiplierInfo,
  isStaffOnlyAchievement
} from '../types/achievements';
import { isSectionUnlocked } from '../types/rankMap';
import { StaffMember } from '../types/staff';
import { playColorLock } from '../utils/cardRevealAudio';

export interface UserAchievementStatus {
  definition: AchievementDefinition;
  isUnlocked: boolean;
  unlockedAt: string | null;
  isNew: boolean; // Unlocked but not yet seen
  currentProgress: number;
  maxProgress: number;
  progressPercent: number;
  isClaimed: boolean;
  claimedAt: string | null;
  coinsAwarded: number;
  baseReward: number;
  multiplier: number;
  calculatedReward: number;
  canClaim: boolean;
}

export interface AchievementStats {
  total: number;
  unlockedCount: number;
  completionPercent: number;
  unseenCount: number;
  totalClaimableCount: number;
  totalClaimedCoins: number;
}

interface AchievementContextType {
  achievements: UserAchievementStatus[];
  stats: AchievementStats;
  loading: boolean;
  roleMultiplier: RoleMultiplierInfo;
  isStaff: boolean;
  unseenNewlyUnlockedIds: string[];
  markAsSeen: (achievementIds: string[]) => Promise<void>;
  claimReward: (achievementId: string) => Promise<{ success: boolean; coinsAwarded?: number; multiplier?: number; message?: string }>;
  claimAllRewards: () => Promise<{ totalCoins: number; count: number }>;
  evaluateMemberAchievements: (member: StaffMember) => UserAchievementStatus[];
}

const AchievementContext = createContext<AchievementContextType | undefined>(undefined);

const LOCAL_STORAGE_PREFIX = 'creatine_nexus_achievements_v1_';

export const AchievementProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isAuthenticated, role } = useAuth();
  const { staff } = useStaff();
  const { applications } = useRankApplications();
  const { profile, catalog, refreshProfile } = useCards();

  const discordId = user?.discordId || '';

  // Persistent storage state for the logged-in user
  const [unlockedMap, setUnlockedMap] = useState<Record<string, string>>({});
  const [seenIds, setSeenIds] = useState<string[]>([]);
  const [claimedMap, setClaimedMap] = useState<Record<string, { claimedAt: string; baseCoins?: number; coinsAwarded: number; multiplier: number }>>({});
  const [loading, setLoading] = useState<boolean>(true);
  const [secretGameTrigger, setSecretGameTrigger] = useState<number>(0);

  // Listen for secret game updates or website actions to trigger achievement updates in real-time
  useEffect(() => {
    const handleGameUpdate = () => {
      setSecretGameTrigger((prev) => prev + 1);
    };
    window.addEventListener('kohan_saddam_best_time_updated', handleGameUpdate);
    window.addEventListener('creatine_theme_unlocked', handleGameUpdate);
    window.addEventListener('creatine_flag_discovered', handleGameUpdate);
    window.addEventListener('storage', handleGameUpdate);
    return () => {
      window.removeEventListener('kohan_saddam_best_time_updated', handleGameUpdate);
      window.removeEventListener('creatine_theme_unlocked', handleGameUpdate);
      window.removeEventListener('creatine_flag_discovered', handleGameUpdate);
      window.removeEventListener('storage', handleGameUpdate);
    };
  }, []);

  // Load from LocalStorage immediately for zero latency
  useEffect(() => {
    if (!discordId) {
      setUnlockedMap({});
      setSeenIds([]);
      setClaimedMap({});
      setLoading(false);
      return;
    }

    try {
      const stored = localStorage.getItem(`${LOCAL_STORAGE_PREFIX}${discordId}`);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.unlocked) setUnlockedMap(parsed.unlocked);
        if (Array.isArray(parsed.seen)) setSeenIds(parsed.seen);
        if (parsed.claimed) setClaimedMap(parsed.claimed);
      }
    } catch (e) {
      console.warn('Could not read cached achievements from localStorage', e);
    }
    setLoading(false);
  }, [discordId]);

  // Synchronize profile claimedAchievements when profile updates from CardContext
  useEffect(() => {
    if (profile?.claimedAchievements) {
      setClaimedMap(prev => {
        const merged = { ...prev, ...profile.claimedAchievements };
        return merged;
      });
    }
  }, [profile?.claimedAchievements]);

  // Keep refs to prevent circular dependencies in sync effects
  const unlockedMapRef = React.useRef(unlockedMap);
  unlockedMapRef.current = unlockedMap;
  const seenIdsRef = React.useRef(seenIds);
  seenIdsRef.current = seenIds;
  const claimedMapRef = React.useRef(claimedMap);
  claimedMapRef.current = claimedMap;

  // Sync with Firestore user_achievements document
  useEffect(() => {
    if (!discordId) return;

    let unsubscribe: (() => void) | null = null;
    try {
      const userAchievementsRef = doc(db, 'user_achievements', discordId);
      unsubscribe = onSnapshot(
        userAchievementsRef,
        (snapshot) => {
          if (snapshot.exists()) {
            const data = snapshot.data() as Partial<UserAchievementDoc>;
            if (data.unlocked) {
              setUnlockedMap((prev) => {
                const incoming = data.unlocked || {};
                const prevKeys = Object.keys(prev);
                const inKeys = Object.keys(incoming);
                if (
                  prevKeys.length === inKeys.length &&
                  inKeys.every((k) => prev[k] === incoming[k])
                ) {
                  return prev;
                }
                return { ...prev, ...incoming };
              });
            }
            if (Array.isArray(data.seen)) {
              setSeenIds((prev) => {
                const incomingSet = new Set(data.seen || []);
                const combined = Array.from(new Set([...prev, ...(data.seen || [])]));
                if (combined.length === prev.length && prev.every((id) => incomingSet.has(id))) {
                  return prev;
                }
                return combined;
              });
            }
            if (data.claimed) {
              setClaimedMap((prev) => ({ ...prev, ...data.claimed }));
            }
          }
        },
        (error) => {
          console.warn('Notice: Firestore user_achievements snapshot fallback:', error.message);
        }
      );
    } catch (err: any) {
      console.warn('Notice: Firestore listener error for user_achievements:', err?.message);
    }

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [discordId]);

  // Find currently logged-in user in staff directory
  const currentStaffMember = useMemo(() => {
    if (!discordId) return undefined;
    return staff.find((s) => s.discordId === discordId && s.status !== 'REMOVED');
  }, [discordId, staff]);

  // Resolve user staff status
  const isOwner = Boolean(
    user?.isOwner || 
    role === 'OWNER' || 
    ['871043296280076308', '831102094521532418', '1099135885699727460', '1306936292197797929', '1371864097523765358'].includes(discordId)
  );

  const isStaff = Boolean(
    isOwner ||
    role === 'ADMIN' || 
    role === 'SUPER_ADMIN' || 
    role === 'MODERATOR' || 
    role === 'STAFF' || 
    Boolean(currentStaffMember)
  );

  const staffPoints = currentStaffMember?.points ?? (isOwner ? 9999 : 0);

  // Compute progressive role coin multiplier strictly bounded up to 3.0x max
  const roleMultiplier: RoleMultiplierInfo = useMemo(() => {
    return getRoleCoinMultiplier(role, currentStaffMember?.rank, isOwner, staffPoints);
  }, [role, currentStaffMember?.rank, isOwner, staffPoints]);

  // Helper to compile real evaluation data for user actions, packages, cards, and staff metrics
  const buildEvaluationData = useCallback(
    (targetStaffMember?: StaffMember): AchievementEvaluationData => {
      let secretGameSurvivalTime = 0;
      let secretGameGoalReached = false;
      let easterEggFound = false;

      try {
        const storedTime = localStorage.getItem('kohan_saddam_survival_best_time');
        if (storedTime) {
          secretGameSurvivalTime = parseInt(storedTime, 10) || 0;
        }
        const storedEggs = localStorage.getItem('creatine_iraqi_easter_eggs_v2');
        if (storedEggs) {
          const parsed = JSON.parse(storedEggs);
          if (parsed.saddamGameGoalReached || (parsed.saddamBestTime && parsed.saddamBestTime >= 120) || parsed.iraqiThemeUnlocked) {
            secretGameGoalReached = true;
          }
          if (parsed.flagsFoundCount && parsed.flagsFoundCount > 0) {
            easterEggFound = true;
          }
          if (parsed.saddamBestTime && parsed.saddamBestTime > secretGameSurvivalTime) {
            secretGameSurvivalTime = parsed.saddamBestTime;
          }
        }
        if (localStorage.getItem('creatine_iraqi_flag_found') === 'true') {
          easterEggFound = true;
        }
      } catch {}

      if (secretGameSurvivalTime >= 120) {
        secretGameGoalReached = true;
      }

      // Check handbook and history exploration actions
      const handbookExplored = Boolean(
        localStorage.getItem('cn_handbook_progress') || 
        localStorage.getItem('creatine_handbook_explored') ||
        localStorage.getItem('codex_last_chapter')
      );

      const historyExplored = Boolean(
        localStorage.getItem('cn_history_explored') || 
        localStorage.getItem('creatine_history_explored') ||
        localStorage.getItem('nexus_history_read')
      );

      // Extract card and pack ownership stats from user profile
      const cardsMap = profile?.cards || {};
      const ownedCardIds = Object.keys(cardsMap).filter(id => (cardsMap[id]?.count || 0) > 0);
      const cardsOwnedCount = ownedCardIds.length;

      const hasLegendaryCard = ownedCardIds.some(id => catalog.find(c => c.id === id)?.rarity === 'LEGENDARY');
      const hasEpicCard = ownedCardIds.some(id => catalog.find(c => c.id === id)?.rarity === 'EPIC');
      const hasMythicCard = ownedCardIds.some(id => {
        const card = catalog.find(c => c.id === id);
        return card && ((card.overallRating || 0) >= 95 || (card.powerRating || 0) >= 95);
      });

      const totalPacksOpened = profile?.totalPacksOpened || 0;
      const totalDailyClaims = profile?.lastDailyClaim ? 1 : 0;
      const hasFavoriteCard = Boolean(profile?.favoriteCardId);
      const hasShowcaseCards = Boolean(profile?.showcaseCardIds && profile.showcaseCardIds.length >= 3);
      const hasCustomBanner = Boolean(profile?.bannerUrl);
      const hasCustomTitle = Boolean(profile?.selectedTitleId);
      const userCoins = profile?.coins || 0;

      const points = targetStaffMember?.points || (isOwner ? 9999 : 0);
      const historyList = targetStaffMember?.history || [];
      const pointTransactionsList = targetStaffMember?.pointTransactions || [];
      const totalActions = historyList.length + pointTransactionsList.length;

      const historyPromotions = historyList.filter(
        (h) => h.action === 'PROMOTED' || h.description.toLowerCase().includes('promot')
      ).length;

      const userApps = applications.filter((a) => a.discordId === (targetStaffMember?.discordId || discordId));
      const applicationsSubmitted = userApps.filter(
        (a) => a.status !== 'NOT_APPLIED' || !!a.appliedAt
      ).length;
      const applicationsApproved = userApps.filter((a) => a.status === 'APPROVED').length;
      const totalOwnerPromotions = Math.max(historyPromotions, applicationsApproved);

      const isRecognizedStaff = Boolean(targetStaffMember?.status === 'ACTIVE' || targetStaffMember?.joinedAt || isStaff);

      const grandStaffUnlocked = isSectionUnlocked('grand_staff', points, false);
      const guardUnlocked = isSectionUnlocked('guard', points, false);
      const highCouncilUnlocked = isSectionUnlocked('high_council', points, false);

      const staffCompleted = points >= 52 || grandStaffUnlocked;
      const grandStaffCompleted = points >= 95 || guardUnlocked;
      const guardCompleted = points >= 175 || highCouncilUnlocked;
      const highCouncilCompleted = points >= 280;

      return {
        staffMember: targetStaffMember,
        points,
        historyEventsCount: historyList.length,
        pointTransactionsCount: pointTransactionsList.length,
        totalActionsCount: totalActions,
        ownerPromotionCount: totalOwnerPromotions,
        applicationsSubmittedCount: applicationsSubmitted,
        applicationsApprovedCount: applicationsApproved,
        isStaffRecognized: isRecognizedStaff,
        secretGameGoalReached,
        secretGameSurvivalTime,
        totalPacksOpened,
        cardsOwnedCount,
        hasLegendaryCard,
        hasEpicCard,
        hasMythicCard,
        totalDailyClaims,
        hasFavoriteCard,
        hasShowcaseCards,
        hasCustomBanner,
        hasCustomTitle,
        handbookExplored,
        historyExplored,
        easterEggFound,
        coins: userCoins,
        unlockedSections: {
          staff: true,
          grandStaff: grandStaffUnlocked,
          guard: guardUnlocked,
          highCouncil: highCouncilUnlocked
        },
        completedSections: {
          staff: staffCompleted,
          grandStaff: grandStaffCompleted,
          guard: guardCompleted,
          highCouncil: highCouncilCompleted
        }
      };
    },
    [applications, secretGameTrigger, profile, catalog, isOwner, isStaff, discordId]
  );

  // Evaluate achievements for any given staff member
  const evaluateMemberAchievements = useCallback(
    (member: StaffMember): UserAchievementStatus[] => {
      const evalData = buildEvaluationData(member);
      const isSelf = member.discordId === discordId;

      return ALL_ACHIEVEMENTS.map((definition) => {
        const { isUnlocked: conditionMet, currentProgress, maxProgress } = definition.evaluate(evalData);
        
        const existingUnlockDate = isSelf ? unlockedMap[definition.id] : null;
        const isUnlocked = conditionMet || !!existingUnlockDate;
        const unlockedAt = existingUnlockDate || (conditionMet ? new Date().toISOString() : null);

        const isNew = isSelf && isUnlocked && !seenIds.includes(definition.id);
        const progressPercent = Math.min(100, Math.round((currentProgress / maxProgress) * 100));

        const claimInfo = claimedMap[definition.id];
        const isClaimed = Boolean(claimInfo);
        const baseReward = getAchievementCoinReward(definition);
        const calculatedReward = Math.round(baseReward * roleMultiplier.multiplier);
        const canClaim = isUnlocked && !isClaimed;

        return {
          definition,
          isUnlocked,
          unlockedAt,
          isNew,
          currentProgress,
          maxProgress,
          progressPercent,
          isClaimed,
          claimedAt: claimInfo?.claimedAt || null,
          coinsAwarded: claimInfo?.coinsAwarded || 0,
          baseReward,
          multiplier: roleMultiplier.multiplier,
          calculatedReward,
          canClaim
        };
      });
    },
    [buildEvaluationData, discordId, unlockedMap, seenIds, claimedMap, roleMultiplier.multiplier]
  );

  // Evaluate for the authenticated user
  const userAchievements = useMemo((): UserAchievementStatus[] => {
    const evalData = buildEvaluationData(currentStaffMember);

    return ALL_ACHIEVEMENTS.map((definition) => {
      const { isUnlocked: conditionMet, currentProgress, maxProgress } = definition.evaluate(evalData);
      
      const existingUnlockDate = unlockedMap[definition.id];
      const isUnlocked = conditionMet || !!existingUnlockDate;
      const unlockedAt = existingUnlockDate || (conditionMet ? new Date().toISOString() : null);

      const isNew = isUnlocked && !seenIds.includes(definition.id);
      const progressPercent = Math.min(100, Math.round((currentProgress / maxProgress) * 100));

      const claimInfo = claimedMap[definition.id];
      const isClaimed = Boolean(claimInfo);
      const baseReward = getAchievementCoinReward(definition);
      const calculatedReward = Math.round(baseReward * roleMultiplier.multiplier);
      const canClaim = isUnlocked && !isClaimed;

      return {
        definition,
        isUnlocked,
        unlockedAt,
        isNew,
        currentProgress,
        maxProgress,
        progressPercent,
        isClaimed,
        claimedAt: claimInfo?.claimedAt || null,
        coinsAwarded: claimInfo?.coinsAwarded || 0,
        baseReward,
        multiplier: roleMultiplier.multiplier,
        calculatedReward,
        canClaim
      };
    });
  }, [buildEvaluationData, currentStaffMember, unlockedMap, seenIds, claimedMap, roleMultiplier.multiplier]);

  // Track last synced unlock signature to avoid infinite effect loops
  const lastSyncedSignatureRef = React.useRef<string>('');

  // Update persistent storage when new achievements are detected
  useEffect(() => {
    if (!discordId) return;

    // Filter unlocked items
    const newlyUnlockedItems = userAchievements.filter(
      (item) => item.isUnlocked && !unlockedMapRef.current[item.definition.id]
    );

    if (newlyUnlockedItems.length === 0) return;

    const newKeysSignature = newlyUnlockedItems.map((i) => i.definition.id).sort().join(',');
    if (lastSyncedSignatureRef.current === newKeysSignature) return;
    lastSyncedSignatureRef.current = newKeysSignature;

    setUnlockedMap((prev) => {
      const updated = { ...prev };
      let changed = false;
      newlyUnlockedItems.forEach((item) => {
        if (!updated[item.definition.id]) {
          updated[item.definition.id] = item.unlockedAt || new Date().toISOString();
          changed = true;
        }
      });
      if (!changed) return prev;

      const payload: UserAchievementDoc = {
        discordId,
        unlocked: updated,
        seen: seenIdsRef.current,
        claimed: claimedMapRef.current,
        updatedAt: new Date().toISOString()
      };

      // Save to localStorage
      try {
        localStorage.setItem(`${LOCAL_STORAGE_PREFIX}${discordId}`, JSON.stringify(payload));
      } catch (e) {
        console.warn('LocalStorage save failed for achievements', e);
      }

      // Save to Firestore
      try {
        const userAchievementsRef = doc(db, 'user_achievements', discordId);
        setDoc(userAchievementsRef, payload, { merge: true }).catch((err) => {
          console.warn('Firestore user_achievements sync notice:', err.message);
        });
      } catch (err) {
        console.warn('Firestore sync attempt notice:', err);
      }

      return updated;
    });
  }, [discordId, userAchievements]);

  // List of newly unlocked achievements that haven't been seen yet
  const unseenNewlyUnlockedIds = useMemo(() => {
    return userAchievements.filter((a) => a.isNew).map((a) => a.definition.id);
  }, [userAchievements]);

  // Mark achievements as seen
  const markAsSeen = useCallback(
    async (idsToMark: string[]) => {
      if (!discordId || idsToMark.length === 0) return;

      const newSeenSet = new Set([...seenIds, ...idsToMark]);
      const newSeenArray = Array.from(newSeenSet);

      setSeenIds(newSeenArray);

      const payload = {
        discordId,
        unlocked: unlockedMap,
        seen: newSeenArray,
        claimed: claimedMap,
        updatedAt: new Date().toISOString()
      };

      try {
        localStorage.setItem(`${LOCAL_STORAGE_PREFIX}${discordId}`, JSON.stringify(payload));
      } catch (e) {}

      try {
        const userAchievementsRef = doc(db, 'user_achievements', discordId);
        await setDoc(userAchievementsRef, payload, { merge: true });
      } catch (err: any) {
        console.warn('Notice: Firestore markAsSeen update fallback:', err?.message);
      }
    },
    [discordId, seenIds, unlockedMap, claimedMap]
  );

  // Claim achievement reward action
  const claimReward = useCallback(
    async (achievementId: string) => {
      if (!discordId) {
        return { success: false, message: 'Please log in with Discord first.' };
      }

      try {
        const res = await fetch('/api/cards/claim-achievement', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ achievementId })
        });
        const data = await res.json();
        if (!res.ok) {
          return { success: false, message: data.error || 'Failed to claim reward' };
        }

        // Update local claimed state
        setClaimedMap((prev) => {
          const updated = {
            ...prev,
            [achievementId]: {
              claimedAt: data.claimedAt || new Date().toISOString(),
              baseCoins: data.baseCoins,
              coinsAwarded: data.coinsAwarded,
              multiplier: data.multiplier
            }
          };

          try {
            localStorage.setItem(
              `${LOCAL_STORAGE_PREFIX}${discordId}`,
              JSON.stringify({
                discordId,
                unlocked: unlockedMapRef.current,
                seen: seenIdsRef.current,
                claimed: updated,
                updatedAt: new Date().toISOString()
              })
            );
          } catch {}

          return updated;
        });

        // Trigger celebratory chime sound
        playColorLock('LEGENDARY', 0.85);

        // Refresh card coins balance
        await refreshProfile();

        return {
          success: true,
          coinsAwarded: data.coinsAwarded,
          multiplier: data.multiplier,
          message: data.message
        };
      } catch (err: any) {
        return { success: false, message: err?.message || 'Network error claiming reward' };
      }
    },
    [discordId, refreshProfile]
  );

  // Claim all currently claimable rewards in sequence
  const claimAllRewards = useCallback(async () => {
    const claimable = userAchievements.filter((a) => a.canClaim);
    if (!claimable.length) return { totalCoins: 0, count: 0 };
    let totalCoins = 0;
    let count = 0;
    for (const ach of claimable) {
      const res = await claimReward(ach.definition.id);
      if (res.success && res.coinsAwarded) {
        totalCoins += res.coinsAwarded;
        count++;
      }
    }
    return { totalCoins, count };
  }, [userAchievements, claimReward]);

  // Overall statistics
  const stats: AchievementStats = useMemo(() => {
    const total = ALL_ACHIEVEMENTS.length;
    const unlockedCount = userAchievements.filter((a) => a.isUnlocked).length;
    const completionPercent = total > 0 ? Math.round((unlockedCount / total) * 100) : 0;
    const unseenCount = unseenNewlyUnlockedIds.length;
    const totalClaimableCount = userAchievements.filter((a) => a.canClaim).length;
    const totalClaimedCoins = Object.values(claimedMap).reduce((acc: number, c: any) => acc + (c?.coinsAwarded || 0), 0);

    return {
      total,
      unlockedCount,
      completionPercent,
      unseenCount,
      totalClaimableCount,
      totalClaimedCoins
    };
  }, [userAchievements, unseenNewlyUnlockedIds, claimedMap]);

  return (
    <AchievementContext.Provider
      value={{
        achievements: userAchievements,
        stats,
        loading,
        roleMultiplier,
        isStaff,
        unseenNewlyUnlockedIds,
        markAsSeen,
        claimReward,
        claimAllRewards,
        evaluateMemberAchievements
      }}
    >
      {children}
    </AchievementContext.Provider>
  );
};

export const useAchievements = () => {
  const context = useContext(AchievementContext);
  if (!context) {
    throw new Error('useAchievements must be used within an AchievementProvider');
  }
  return context;
};

