import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { collection, onSnapshot, doc, setDoc, deleteDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from './AuthContext';

export interface OwnerStats {
  leadership: number;
  activity: number;
  management: number;
  communication: number;
  creativity: number;
  reliability: number;
}

export interface OwnerTimelineItem {
  year: string;
  title: string;
  subtitle?: string;
  description?: string;
}

export interface OwnerPhotoSlide {
  id?: string;
  image?: string;
  title?: string;
  caption?: string;
  alt?: string;
  palette?: 'dawn' | 'alpine' | 'dusk' | 'mist';
  seed?: number;
}

export interface OwnerCardBackground {
  cardId: string;
  imageUrl?: string | null;
  backgroundImage?: string | null; // Alias for imageUrl
  characterImageUrl?: string | null; // Dedicated artwork/illustration/transparent PNG for Owner Profile Page
  avatarUrl?: string | null; // Dedicated square/round modern avatar for Owner Profile
  username?: string;
  discordUsername?: string;
  discordId?: string;
  isDiscordLinked?: boolean;
  quote?: string;
  bio?: string;
  specialty?: string;
  responsibilities?: string;
  joinedDate?: string;
  level?: string;
  stats?: Partial<OwnerStats>;
  socials?: {
    discord?: string;
    twitter?: string;
    youtube?: string;
    twitch?: string;
    github?: string;
    [key: string]: string | undefined;
  };
  achievements?: string[];
  historyTimeline?: OwnerTimelineItem[];
  photoReel?: OwnerPhotoSlide[];
  overlayOpacity?: number; // 0 to 1, default ~0.45
  blur?: number; // 0 to 40px, default 0
  objectPosition?: string; // 'center', 'top', 'bottom', etc.
  blendMode?: string;
  name?: string;
  displayName?: string;
  roleTitle?: string;
  subtitle?: string;
  badge?: string;
  accentColor?: string; // 'amber' | 'emerald' | 'rose' | 'purple' | 'cyan' | 'red' | 'orange' | 'yellow'
  effect?: string; // 'none' | 'romantic' | 'fire' | 'stars' | 'guardian' | 'cyber' | 'solar'
  glowIntensity?: number; // 0 to 1
  borderStyle?: string; // 'glow' | 'pulse' | 'shimmer' | 'solid'
  order?: number;
  status?: 'present' | 'former';
  country?: string;
  isCustom?: boolean;
  removed?: boolean;

  // Character artwork size & placement customization
  hideCharacter?: boolean; // When true, removes character above and displays only background image
  showOnlyBackground?: boolean; // Alias for hideCharacter
  characterScale?: number; // 0.4 to 2.5, default 1.0 (100%)
  characterOffsetX?: number; // -200px to +200px, default 0
  characterOffsetY?: number; // -200px to +200px, default 0
  characterAlignment?: 'center' | 'bottom' | 'top' | 'left' | 'right';
  characterFit?: 'contain' | 'cover';

  // Card height & dimensions customization
  cardHeightPreset?: 'compact' | 'standard' | 'tall' | 'epic'; // 440px, 520px, 600px, 680px
  cardHeight?: number; // optional custom height in px (e.g. 420 - 750)

  // Buttons customization & clean cinematic mode
  hideEditButton?: boolean; // Hides the floating "Customize Card" button on the card face
  hideBadgeButton?: boolean; // Hides badge action & secret game button
  hideStatusBadge?: boolean; // Hides status pill (present/former)
  hideAllButtons?: boolean; // Clean artistic mode: hides all buttons & controls from card face

  updatedBy?: string;
  updatedAt?: string;
}

export type OwnerCardCustomization = OwnerCardBackground;

export interface ActiveCardEditTarget {
  cardId: string;
  ownerName: string;
  defaultAccent?: string;
  fallbackCardId?: string;
  displayName?: string;
  roleTitle?: string;
  subtitle?: string;
  badge?: string;
  country?: string;
  status?: 'present' | 'former';
  order?: number;
  isCustom?: boolean;
}

interface OwnerCardBackgroundsContextType {
  backgrounds: Record<string, OwnerCardCustomization>;
  allCustomCards: OwnerCardCustomization[];
  loading: boolean;
  getBackground: (cardId: string, fallbackCardId?: string) => OwnerCardCustomization | undefined;
  getCustomization: (cardId: string, fallbackCardId?: string) => OwnerCardCustomization | undefined;
  updateBackground: (
    cardId: string,
    params: {
      imageUrl?: string | null;
      overlayOpacity?: number;
      blur?: number;
      objectPosition?: string;
      blendMode?: string;
    }
  ) => Promise<{ success: boolean; error?: string }>;
  updateCard: (params: Partial<OwnerCardCustomization> & { cardId: string }) => Promise<{ success: boolean; error?: string }>;
  reorderCards: (items: Array<{ cardId: string; order: number }>) => Promise<{ success: boolean; error?: string }>;
  deleteCard: (cardId: string) => Promise<{ success: boolean; error?: string }>;
  createCard: (cardData: Partial<OwnerCardCustomization>) => Promise<{ success: boolean; cardId?: string; error?: string }>;
  removeBackground: (cardId: string) => Promise<{ success: boolean; error?: string }>;
  openEditModal: (target: ActiveCardEditTarget) => void;
  openCreateCardModal: () => void;
  closeEditModal: () => void;
  isModalOpen: boolean;
  activeCardForEdit: ActiveCardEditTarget | null;
  refreshBackgrounds: () => Promise<void>;
}

const OwnerCardBackgroundsContext = createContext<OwnerCardBackgroundsContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'creatine_nexus_owner_cards';

// Pairs connecting Current Era card IDs with their corresponding Historical Timeline card IDs
const CARD_ALIAS_MAP: Record<string, string> = {
  'owner_edgar': 'history_owner_0',
  'history_owner_0': 'owner_edgar',
  'owner_kevin': 'history_owner_1',
  'history_owner_1': 'owner_kevin',
  'owner_sh3la': 'history_owner_2',
  'history_owner_2': 'owner_sh3la',
  'owner_viper': 'history_owner_3',
  'history_owner_3': 'owner_viper',
  'owner_hamo': 'history_owner_3',
  'owner_kroos': 'history_owner_4',
  'history_owner_4': 'owner_kroos',
  'owner_super': 'history_owner_4',
  'owner_hamody': 'history_owner_5',
  'history_owner_5': 'owner_hamody',
  'owner_osama': 'history_owner_5',
  'owner_ammar': 'history_owner_6',
  'history_owner_6': 'owner_ammar',
  'owner_adham': 'history_owner_6',
  'owner_shadow': 'history_owner_7',
  'history_owner_7': 'owner_shadow',
  'owner_abysswolf': 'history_owner_8',
  'history_owner_8': 'owner_abysswolf',
  'owner_kohan': 'history_owner_9',
  'history_owner_9': 'owner_kohan',
  'owner_luigi': 'history_owner_10',
  'history_owner_10': 'owner_luigi',
  'owner_yuzu': 'history_owner_11',
  'history_owner_11': 'owner_yuzu',
};

export const OwnerCardBackgroundsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [backgrounds, setBackgrounds] = useState<Record<string, OwnerCardCustomization>>(() => {
    try {
      const cached = localStorage.getItem(LOCAL_STORAGE_KEY);
      return cached ? JSON.parse(cached) : {};
    } catch {
      return {};
    }
  });
  const [loading, setLoading] = useState<boolean>(true);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [activeCardForEdit, setActiveCardForEdit] = useState<ActiveCardEditTarget | null>(null);

  const { isOwner } = useAuth();

  // Helper to persist to localStorage safely
  const persistToLocalStorage = (data: Record<string, OwnerCardCustomization>) => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
      console.warn('LocalStorage quota or write notice:', e);
    }
  };

  // Fetch backgrounds and customizations from API
  const refreshBackgrounds = useCallback(async () => {
    try {
      const res = await fetch('/api/history/owner-card-backgrounds', {
        headers: { 'Accept': 'application/json' },
        credentials: 'include'
      });
      if (res.ok) {
        const data = await res.json();
        if (data.backgrounds && typeof data.backgrounds === 'object') {
          setBackgrounds(prev => {
            const next = {
              ...prev,
              ...data.backgrounds
            };
            persistToLocalStorage(next);
            return next;
          });
        }
      }
    } catch (err) {
      console.warn('Could not fetch owner card customizations from API:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  // Listen to Firestore collection in real-time
  useEffect(() => {
    refreshBackgrounds();

    if (!db) return;

    try {
      const unsubscribe = onSnapshot(
        collection(db, 'history_owner_cards'),
        (snapshot) => {
          const map: Record<string, OwnerCardCustomization> = {};
          snapshot.docs.forEach((doc) => {
            const data = doc.data() as OwnerCardCustomization;
            map[doc.id] = { ...data, cardId: doc.id };
          });
          setBackgrounds(prev => {
            const next = { ...prev, ...map };
            persistToLocalStorage(next);
            return next;
          });
          setLoading(false);
        },
        (error) => {
          try {
            handleFirestoreError(error, OperationType.LIST, 'history_owner_cards');
          } catch (e) {
            console.warn('Firestore fetch notice for history_owner_cards, using cache:', e);
          }
          refreshBackgrounds();
        }
      );

      return () => unsubscribe();
    } catch (err) {
      console.warn('Firestore snapshot setup notice for history_owner_cards:', err);
    }
  }, [refreshBackgrounds]);

  // Lookup background or customization with alias/fallback and freshest timestamp
  const getBackground = useCallback((cardId: string, fallbackCardId?: string): OwnerCardCustomization | undefined => {
    if (!cardId) return undefined;
    const direct = backgrounds[cardId];
    const fallback = fallbackCardId ? backgrounds[fallbackCardId] : undefined;
    const aliasId = CARD_ALIAS_MAP[cardId];
    const alias = aliasId ? backgrounds[aliasId] : undefined;

    const candidates = [direct, fallback, alias].filter(Boolean) as OwnerCardCustomization[];
    if (candidates.length === 0) return undefined;
    if (candidates.length === 1) return candidates[0];

    // Whichever entry has the most recent update timestamp takes precedence
    return candidates.sort((a, b) => {
      const timeA = a.updatedAt ? new Date(a.updatedAt).getTime() : 0;
      const timeB = b.updatedAt ? new Date(b.updatedAt).getTime() : 0;
      return timeB - timeA;
    })[0];
  }, [backgrounds]);

  const getCustomization = getBackground;

  // Open modal for editing a specific card
  const openEditModal = useCallback((target: ActiveCardEditTarget) => {
    setActiveCardForEdit(target);
    setIsModalOpen(true);
  }, []);

  // Open modal to add a brand new card
  const openCreateCardModal = useCallback(() => {
    const newId = `custom_owner_${Date.now()}`;
    setActiveCardForEdit({
      cardId: newId,
      ownerName: 'NEW LEADER',
      displayName: '',
      roleTitle: 'Server Owner',
      subtitle: '',
      badge: '',
      defaultAccent: 'amber',
      isCustom: true
    });
    setIsModalOpen(true);
  }, []);

  const closeEditModal = useCallback(() => {
    setIsModalOpen(false);
    setActiveCardForEdit(null);
  }, []);

  // Update card with full customization (names, colors, effects, background, order)
  const updateCard = useCallback(async (params: Partial<OwnerCardCustomization> & { cardId: string }) => {
    const cleanCardId = params.cardId.trim();
    const now = new Date().toISOString();

    // Collect all linked card IDs (e.g. history_owner_3, owner_viper, owner_hamo)
    const linkedIds = new Set<string>([cleanCardId]);
    const directAlias = CARD_ALIAS_MAP[cleanCardId];
    if (directAlias) linkedIds.add(directAlias);
    Object.entries(CARD_ALIAS_MAP).forEach(([k, v]) => {
      if (k === cleanCardId || v === cleanCardId || (directAlias && (k === directAlias || v === directAlias))) {
        linkedIds.add(k);
        linkedIds.add(v);
      }
    });

    const finalAvatar = params.avatarUrl !== undefined ? params.avatarUrl : (params.imageUrl || undefined);
    const finalImage = params.imageUrl !== undefined ? params.imageUrl : (params.backgroundImage || params.avatarUrl || undefined);

    const updatedDoc: OwnerCardCustomization = {
      ...params,
      ...(finalAvatar !== undefined ? { avatarUrl: finalAvatar } : {}),
      ...(finalImage !== undefined ? { imageUrl: finalImage, backgroundImage: finalImage } : {}),
      cardId: cleanCardId,
      updatedAt: now
    };

    // 1. Optimistically update local state & localStorage immediately so cards reflect changes instantly
    setBackgrounds(prev => {
      const next: Record<string, OwnerCardCustomization> = { ...prev };
      linkedIds.forEach((id) => {
        next[id] = { ...prev[id], ...updatedDoc, cardId: id };
      });
      persistToLocalStorage(next);
      return next;
    });

    // 2. Direct Firestore write if available for all linked keys
    if (db) {
      try {
        const promises = Array.from(linkedIds).map((id) =>
          setDoc(doc(db, 'history_owner_cards', id), { ...updatedDoc, cardId: id }, { merge: true })
        );
        await Promise.all(promises);
      } catch (fErr) {
        console.warn('Direct Firestore write notice for owner cards:', fErr);
      }
    }

    // 3. Server API call for authoritative audit log & cache synchronization
    try {
      const res = await fetch('/api/history/owner-cards', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify(params)
      });

      if (res.ok) {
        const data = await res.json();
        if (data.card) {
          setBackgrounds(prev => {
            const next = { ...prev };
            linkedIds.forEach(id => {
              next[id] = { ...data.card, cardId: id };
            });
            persistToLocalStorage(next);
            return next;
          });
        }
      }
    } catch (err: any) {
      console.warn('Server API sync notice (saved locally and to firestore):', err);
    }

    return { success: true };
  }, []);

  // Alias updateBackground
  const updateBackground = useCallback(async (
    cardId: string,
    params: {
      imageUrl?: string | null;
      overlayOpacity?: number;
      blur?: number;
      objectPosition?: string;
      blendMode?: string;
    }
  ) => {
    return updateCard({ cardId, ...params });
  }, [updateCard]);

  // Reorder cards
  const reorderCards = useCallback(async (items: Array<{ cardId: string; order: number }>) => {
    // 1. Optimistically update local state & localStorage
    setBackgrounds(prev => {
      const next = { ...prev };
      items.forEach(it => {
        if (next[it.cardId]) {
          next[it.cardId] = { ...next[it.cardId], order: it.order };
        }
        const aliasId = CARD_ALIAS_MAP[it.cardId];
        if (aliasId && next[aliasId]) {
          next[aliasId] = { ...next[aliasId], order: it.order };
        }
      });
      persistToLocalStorage(next);
      return next;
    });

    // 2. Direct Firestore writes
    if (db) {
      try {
        const now = new Date().toISOString();
        for (const it of items) {
          await setDoc(doc(db, 'history_owner_cards', it.cardId), { order: it.order, updatedAt: now }, { merge: true });
          const aliasId = CARD_ALIAS_MAP[it.cardId];
          if (aliasId) {
            await setDoc(doc(db, 'history_owner_cards', aliasId), { order: it.order, updatedAt: now }, { merge: true });
          }
        }
      } catch (fErr) {
        console.warn('Direct Firestore write notice for card reorder:', fErr);
      }
    }

    // 3. Server API call
    try {
      await fetch('/api/history/owner-cards/reorder', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({ items })
      });
    } catch (err: any) {
      console.warn('Server API sync notice for reorder:', err);
    }

    return { success: true };
  }, []);

  // Delete card
  const deleteCard = useCallback(async (cardId: string) => {
    const cleanCardId = cardId.trim();
    const aliasId = CARD_ALIAS_MAP[cleanCardId];

    // 1. Optimistically remove from state & localStorage
    setBackgrounds(prev => {
      const next = { ...prev };
      delete next[cleanCardId];
      if (aliasId) delete next[aliasId];
      persistToLocalStorage(next);
      return next;
    });

    // 2. Direct Firestore deletion
    if (db) {
      try {
        await deleteDoc(doc(db, 'history_owner_cards', cleanCardId));
        if (aliasId) {
          await deleteDoc(doc(db, 'history_owner_cards', aliasId));
        }
      } catch (fErr) {
        console.warn('Direct Firestore delete notice:', fErr);
      }
    }

    // 3. Server API call
    try {
      await fetch(`/api/history/owner-cards/${encodeURIComponent(cleanCardId)}`, {
        method: 'DELETE',
        headers: { 'Accept': 'application/json' },
        credentials: 'include'
      });
    } catch (err: any) {
      console.warn('Server API delete notice:', err);
    }

    return { success: true };
  }, []);

  // Create card
  const createCard = useCallback(async (cardData: Partial<OwnerCardCustomization>) => {
    const cardId = cardData.cardId || `custom_owner_${Date.now()}`;
    const result = await updateCard({
      ...cardData,
      cardId,
      isCustom: true
    });
    return { ...result, cardId };
  }, [updateCard]);

  // Remove background only
  const removeBackground = useCallback(async (cardId: string) => {
    const existing = backgrounds[cardId];
    if (existing) {
      return updateCard({
        cardId,
        imageUrl: null,
        blur: 0,
        overlayOpacity: 0.45
      });
    }
    return deleteCard(cardId);
  }, [backgrounds, updateCard, deleteCard]);

  const allCustomCards = Object.values(backgrounds).filter((c: OwnerCardCustomization) => !c.removed);

  return (
    <OwnerCardBackgroundsContext.Provider
      value={{
        backgrounds,
        allCustomCards,
        loading,
        getBackground,
        getCustomization,
        updateBackground,
        updateCard,
        reorderCards,
        deleteCard,
        createCard,
        removeBackground,
        openEditModal,
        openCreateCardModal,
        closeEditModal,
        isModalOpen,
        activeCardForEdit,
        refreshBackgrounds
      }}
    >
      {children}
    </OwnerCardBackgroundsContext.Provider>
  );
};

export function useOwnerCardBackgrounds() {
  const context = useContext(OwnerCardBackgroundsContext);
  if (!context) {
    throw new Error('useOwnerCardBackgrounds must be used within an OwnerCardBackgroundsProvider');
  }
  return context;
}
