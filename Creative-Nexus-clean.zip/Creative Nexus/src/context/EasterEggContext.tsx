import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthContext';
import { EasterEggContextType, CollectFlagResult, UserEasterEggDoc, AppThemeType } from '../types/easterEggs';
import { TOTAL_IRAQI_FLAGS, IRAQI_FLAG_LOCATIONS } from '../config/easterEggs';
import { easterEggSound } from '../utils/easterEggAudio';

const EasterEggContext = createContext<EasterEggContextType | undefined>(undefined);

const VALID_IRAQI_FLAG_IDS = Object.keys(IRAQI_FLAG_LOCATIONS);
const LOCAL_STORAGE_PREFIX = 'creatine_nexus_easter_eggs_v1_';
const SADDAM_BEST_TIME_KEY = 'kohan_saddam_survival_best_time';
const GOAL_SURVIVAL_SECONDS = 120; // 2:00 survival goal

export const EasterEggProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isAuthenticated, isOwner } = useAuth();
  const discordId = isAuthenticated && user?.discordId ? user.discordId : 'guest';

  // Core collectible & unlock state
  const [collectedFlagIds, setCollectedFlagIds] = useState<string[]>([]);
  const [kohanRoomUnlocked, setKohanRoomUnlocked] = useState<boolean>(false);
  const [iraqiThemeUnlocked, setIraqiThemeUnlocked] = useState<boolean>(false);
  const [iraqiThemeActive, setIraqiThemeActive] = useState<boolean>(false);
  const [activeTheme, setActiveTheme] = useState<AppThemeType>('creative-nexus');
  const [finalRewardGranted, setFinalRewardGranted] = useState<boolean>(false);
  const [secretKohanGameCompleted, setSecretKohanGameCompleted] = useState<boolean>(false);
  const [saddamMissionCompleted, setSaddamMissionCompleted] = useState<boolean>(false);

  // Saddam game survival tracking
  const [saddamBestTime, setSaddamBestTime] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(SADDAM_BEST_TIME_KEY);
      return saved ? Math.max(0, parseInt(saved, 10) || 0) : 0;
    } catch {
      return 0;
    }
  });
  const [saddamGameGoalReached, setSaddamGameGoalReached] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(SADDAM_BEST_TIME_KEY);
      return saved ? (parseInt(saved, 10) || 0) >= GOAL_SURVIVAL_SECONDS : false;
    } catch {
      return false;
    }
  });

  // Kohan Secret Room Mini-Game
  const [isKohanGameOpen, setIsKohanGameOpen] = useState<boolean>(false);

  // Secret Archive Revelation State (Only accessible when triggered by authenticated user)
  const [isSecretArchiveRevealed, setIsSecretArchiveRevealed] = useState<boolean>(false);

  // Secret Progress Panel & Overlays
  const [isSecretProgressOpen, setIsSecretProgressOpen] = useState<boolean>(false);
  const [recentFlagCollected, setRecentFlagCollected] = useState<{ id: string; number: number } | null>(null);
  const [showUnlockCelebration, setShowUnlockCelebration] = useState<boolean>(false);
  const [showThemeUnlockedOverlay, setShowThemeUnlockedOverlay] = useState<boolean>(false);

  // Keep refs for asynchronous / event handlers
  const collectedFlagIdsRef = useRef(collectedFlagIds);
  collectedFlagIdsRef.current = collectedFlagIds;
  const kohanRoomUnlockedRef = useRef(kohanRoomUnlocked);
  kohanRoomUnlockedRef.current = kohanRoomUnlocked;
  const iraqiThemeUnlockedRef = useRef(iraqiThemeUnlocked);
  iraqiThemeUnlockedRef.current = iraqiThemeUnlocked;
  const iraqiThemeActiveRef = useRef(iraqiThemeActive);
  iraqiThemeActiveRef.current = iraqiThemeActive;
  const activeThemeRef = useRef(activeTheme);
  activeThemeRef.current = activeTheme;
  const saddamBestTimeRef = useRef(saddamBestTime);
  saddamBestTimeRef.current = saddamBestTime;
  const saddamGameGoalReachedRef = useRef(saddamGameGoalReached);
  saddamGameGoalReachedRef.current = saddamGameGoalReached;
  const finalRewardGrantedRef = useRef(finalRewardGranted);
  finalRewardGrantedRef.current = finalRewardGranted;
  const secretKohanGameCompletedRef = useRef(secretKohanGameCompleted);
  secretKohanGameCompletedRef.current = secretKohanGameCompleted;
  const saddamMissionCompletedRef = useRef(saddamMissionCompleted);
  saddamMissionCompletedRef.current = saddamMissionCompleted;

  // Real-time HTML document theme application
  useEffect(() => {
    if (typeof document === 'undefined') return;
    if (activeTheme === 'kohan-iraqi') {
      document.documentElement.classList.add('theme-iraqi');
      document.documentElement.setAttribute('data-theme', 'iraqi');
    } else {
      document.documentElement.classList.remove('theme-iraqi');
      document.documentElement.removeAttribute('data-theme');
    }
  }, [activeTheme]);

  // Sync state to localStorage (secondary cache only; Firestore is source of truth)
  const saveToLocalStorage = useCallback((
    flags: string[],
    roomUnlocked: boolean,
    themeUnlocked: boolean,
    themeActive: boolean,
    themeType: AppThemeType,
    bestTime?: number,
    goalReached?: boolean,
    rewardGranted?: boolean
  ) => {
    if (!isAuthenticated || !user?.discordId) return;
    try {
      const storageKey = `${LOCAL_STORAGE_PREFIX}${user.discordId}`;
      const payload = {
        collectedFlagIds: flags,
        flagsCount: flags.length,
        kohanRoomUnlocked: roomUnlocked,
        iraqiThemeUnlocked: themeUnlocked,
        iraqiThemeActive: themeActive,
        activeTheme: themeType,
        saddamBestTime: typeof bestTime === 'number' ? bestTime : saddamBestTimeRef.current,
        saddamGameGoalReached: typeof goalReached === 'boolean' ? goalReached : saddamGameGoalReachedRef.current,
        finalRewardGranted: typeof rewardGranted === 'boolean' ? rewardGranted : finalRewardGrantedRef.current,
        secretKohanGameCompleted: typeof rewardGranted === 'boolean' ? rewardGranted : secretKohanGameCompletedRef.current,
        updatedAt: new Date().toISOString(),
      };
      localStorage.setItem(storageKey, JSON.stringify(payload));
    } catch (e) {
      console.warn('Failed to save easter egg cache to localStorage', e);
    }
  }, [isAuthenticated, user?.discordId]);

  const KNOWN_OWNER_IDS = ['871043296280076308', '831102094521532418', '1099135885699727460', '1306936292197797929', '1371864097523765358'];

  const isOwnerUser = Boolean(
    isOwner || 
    user?.isOwner || 
    user?.role === 'OWNER' || 
    user?.isGuildOwner || 
    (user?.discordId ? KNOWN_OWNER_IDS.includes(String(user.discordId)) : false) ||
    user?.discordId === '871043296280076308' ||
    import.meta.env.DEV
  );

  // Load from cache on mount or when user identity changes
  useEffect(() => {
    // 1. OWNER OVERRIDE: All server themes automatically open for owners!
    if (isOwnerUser) {
      setIraqiThemeUnlocked(true);
      setKohanRoomUnlocked(true);
      setFinalRewardGranted(true);
      setSecretKohanGameCompleted(true);
      setSaddamGameGoalReached(true);
      setSaddamMissionCompleted(true);
      setSaddamBestTime(prev => Math.max(prev, GOAL_SURVIVAL_SECONDS));
      return;
    }

    // 2. Read persistent storage for authenticated or local player
    const userKey = user?.discordId ? `${LOCAL_STORAGE_PREFIX}${user.discordId}` : `${LOCAL_STORAGE_PREFIX}local_player`;
    try {
      const stored = localStorage.getItem(userKey) || localStorage.getItem(`${LOCAL_STORAGE_PREFIX}guest`);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed.collectedFlagIds)) {
          setCollectedFlagIds(parsed.collectedFlagIds);
        }
        if (typeof parsed.kohanRoomUnlocked === 'boolean') {
          setKohanRoomUnlocked(parsed.kohanRoomUnlocked);
        }
        if (typeof parsed.iraqiThemeUnlocked === 'boolean') {
          setIraqiThemeUnlocked(parsed.iraqiThemeUnlocked);
        }
        if (typeof parsed.finalRewardGranted === 'boolean') {
          setFinalRewardGranted(parsed.finalRewardGranted);
        }
        if (typeof parsed.secretKohanGameCompleted === 'boolean') {
          setSecretKohanGameCompleted(parsed.secretKohanGameCompleted);
        }
        if (parsed.iraqiThemeUnlocked || parsed.finalRewardGranted) {
          if (parsed.activeTheme === 'kohan-iraqi' || parsed.activeTheme === 'creative-nexus') {
            setActiveTheme(parsed.activeTheme);
            setIraqiThemeActive(parsed.activeTheme === 'kohan-iraqi');
          } else if (typeof parsed.iraqiThemeActive === 'boolean') {
            setIraqiThemeActive(parsed.iraqiThemeActive);
            if (parsed.iraqiThemeActive) setActiveTheme('kohan-iraqi');
          }
        }
        if (typeof parsed.saddamBestTime === 'number' && parsed.saddamBestTime > 0) {
          setSaddamBestTime(parsed.saddamBestTime);
          if (parsed.saddamBestTime >= GOAL_SURVIVAL_SECONDS) {
            setSaddamGameGoalReached(true);
            setSaddamMissionCompleted(true);
          }
        }
      }
    } catch (e) {
      console.warn('Could not read cached easter eggs from localStorage', e);
    }
  }, [isOwnerUser, user?.discordId]);

  // Listen for local Saddam survival game updates from window event
  useEffect(() => {
    const handleGameTimeUpdate = (event: CustomEvent<{ time: number }>) => {
      const time = event.detail?.time;
      if (typeof time === 'number') {
        recordGameBestSurvival(time);
      }
    };

    window.addEventListener('kohan_saddam_best_time_updated' as any, handleGameTimeUpdate as any);
    return () => {
      window.removeEventListener('kohan_saddam_best_time_updated' as any, handleGameTimeUpdate as any);
    };
  }, []);

  // Proactive Mission Completion Watcher & Owner Auto-Unlock
  // As soon as BOTH missions are completed (5 flags found AND 2:00 survival achieved) OR if owner:
  // AUTOMATICALLY grant and unlock all themes immediately!
  useEffect(() => {
    const hasFlags = collectedFlagIds.length >= TOTAL_IRAQI_FLAGS;
    const hasSaddamGoal = saddamGameGoalReached || saddamBestTime >= GOAL_SURVIVAL_SECONDS || saddamMissionCompleted;
    const missionsCompleted = hasFlags && hasSaddamGoal;

    if (isOwnerUser || missionsCompleted) {
      let justUnlocked = false;
      if (!iraqiThemeUnlocked) {
        setIraqiThemeUnlocked(true);
        justUnlocked = true;
      }
      if (!kohanRoomUnlocked) {
        setKohanRoomUnlocked(true);
      }
      if (!finalRewardGranted) {
        setFinalRewardGranted(true);
      }
      if (!secretKohanGameCompleted) {
        setSecretKohanGameCompleted(true);
      }
      if (!saddamMissionCompleted) {
        setSaddamMissionCompleted(true);
      }
      if (!saddamGameGoalReached) {
        setSaddamGameGoalReached(true);
      }

      // If just unlocked through mission completion, celebrate with sound & overlay
      if (justUnlocked && missionsCompleted && !isOwnerUser) {
        try {
          easterEggSound.playSecretRoomUnlockedSound();
        } catch {}
        setShowThemeUnlockedOverlay(true);
      }

      saveToLocalStorage(
        collectedFlagIds.length > 0 ? collectedFlagIds : (isOwnerUser ? Array.from(VALID_IRAQI_FLAG_IDS) : []),
        true,
        true,
        iraqiThemeActiveRef.current,
        activeThemeRef.current,
        Math.max(saddamBestTime, GOAL_SURVIVAL_SECONDS),
        true,
        true
      );
    }
  }, [
    isOwnerUser,
    collectedFlagIds,
    saddamGameGoalReached,
    saddamBestTime,
    saddamMissionCompleted,
    iraqiThemeUnlocked,
    kohanRoomUnlocked,
    finalRewardGranted,
    secretKohanGameCompleted,
    saveToLocalStorage
  ]);

  // Server-Authoritative Claim Function: Guarantees reward is granted
  const claimIraqiTheme = useCallback(async (
    overrideFlags?: string[],
    overrideBestTime?: number
  ): Promise<boolean> => {
    const isOwnerUser = Boolean(isOwner || user?.isOwner || user?.role === 'OWNER' || user?.discordId === '871043296280076308');

    // 0. OWNER OVERRIDE: Always grant immediately
    if (isOwnerUser) {
      setFinalRewardGranted(true);
      setSecretKohanGameCompleted(true);
      setSaddamMissionCompleted(true);
      setSaddamGameGoalReached(true);
      setIraqiThemeUnlocked(true);
      setKohanRoomUnlocked(true);
      setIraqiThemeActive(true);
      setActiveTheme('kohan-iraqi');
      return true;
    }

    const flagsToSend = overrideFlags || collectedFlagIdsRef.current;
    const timeToSend = typeof overrideBestTime === 'number' ? overrideBestTime : saddamBestTimeRef.current;

    // Requirement 1: All 5 flags must be discovered
    if (flagsToSend.length < TOTAL_IRAQI_FLAGS) {
      console.warn(`Cannot claim reward: ${TOTAL_IRAQI_FLAGS}/${TOTAL_IRAQI_FLAGS} flags required, found:`, flagsToSend.length);
      return false;
    }

    // Requirement 2 & 3: Full 2:00 (120 seconds) survival must be achieved
    if (timeToSend < GOAL_SURVIVAL_SECONDS && !saddamGameGoalReachedRef.current && !saddamMissionCompletedRef.current) {
      console.warn('Cannot claim reward: 2:00 Saddam game survival goal required.');
      return false;
    }

    // Immediately grant locally so user NEVER misses out even if offline or network drops!
    setFinalRewardGranted(true);
    setSecretKohanGameCompleted(true);
    setSaddamMissionCompleted(true);
    setSaddamGameGoalReached(true);
    setIraqiThemeUnlocked(true);
    setKohanRoomUnlocked(true);
    setIraqiThemeActive(true);
    setActiveTheme('kohan-iraqi');

    saveToLocalStorage(flagsToSend, true, true, true, 'kohan-iraqi', Math.max(timeToSend, GOAL_SURVIVAL_SECONDS), true, true);

    if (isAuthenticated) {
      try {
        const res = await fetch('/api/easter-eggs/claim-iraqi-theme', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            collectedFlagIds: flagsToSend,
            saddamBestTime: Math.max(timeToSend, GOAL_SURVIVAL_SECONDS),
            saddamGameGoalReached: true,
            saddamMissionCompleted: true
          })
        });

        const data = await res.json();
        if (data.alreadyClaimed || res.ok) {
          return true;
        }
      } catch (err) {
        console.warn('Background sync for reward notice:', err);
      }
    }

    return true;
  }, [isOwner, user, isAuthenticated, saveToLocalStorage]);

  // Record Saddam underground game best survival time
  // Saddam game remains completely playable and replayable at all times!
  const recordGameBestSurvival = useCallback(async (timeSecs: number): Promise<void> => {
    const validTime = Math.max(0, Math.floor(timeSecs));
    try {
      localStorage.setItem(SADDAM_BEST_TIME_KEY, validTime.toString());
    } catch {
      // Non-blocking
    }

    setSaddamMissionCompleted(true);

    setSaddamBestTime(prev => {
      const newBest = Math.max(prev, validTime);
      const reachedGoal = newBest >= GOAL_SURVIVAL_SECONDS;
      if (reachedGoal) {
        setSaddamGameGoalReached(true);
      }

      saveToLocalStorage(
        collectedFlagIdsRef.current,
        kohanRoomUnlockedRef.current,
        iraqiThemeUnlockedRef.current,
        iraqiThemeActiveRef.current,
        activeThemeRef.current,
        newBest,
        reachedGoal,
        finalRewardGrantedRef.current
      );

      // Check if both requirements are fulfilled AND reward has NOT been granted yet
      if (
        !finalRewardGrantedRef.current &&
        reachedGoal &&
        collectedFlagIdsRef.current.length >= TOTAL_IRAQI_FLAGS
      ) {
        if (isAuthenticated) {
          claimIraqiTheme(collectedFlagIdsRef.current, newBest).then((claimed) => {
            if (claimed) {
              easterEggSound.playSecretRoomUnlockedSound();
              setShowThemeUnlockedOverlay(true);
            }
          });
        }
      }

      return newBest;
    });

    if (isAuthenticated) {
      try {
        await fetch('/api/easter-eggs/record-game-time', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ survivalTime: validTime })
        });
      } catch (err) {
        console.warn('Could not record game time on server:', err);
      }
    }
  }, [isAuthenticated, claimIraqiTheme, saveToLocalStorage]);

  // Access Revocation upon Logout (Preserves owner status and completed themes)
  useEffect(() => {
    if (!isAuthenticated && !isOwnerUser) {
      setIsSecretArchiveRevealed(false);
      setIsKohanGameOpen(false);
      setIsSecretProgressOpen(false);
      setShowUnlockCelebration(false);
      setShowThemeUnlockedOverlay(false);
    }
  }, [isAuthenticated, isOwnerUser]);

  // Safe setter for Kohan Secret Game: Strictly enforces authentication
  // Game remains playable indefinitely for authenticated users!
  const handleSetIsKohanGameOpen = useCallback((open: boolean) => {
    if (open && !isAuthenticated) {
      console.warn('Secret game blocked: Authentication required.');
      return;
    }
    setIsKohanGameOpen(open);
    if (open) {
      setIsSecretArchiveRevealed(true);
    }
  }, [isAuthenticated]);

  // Secret Archive Revelation Controls
  const revealSecretArchive = useCallback(() => {
    if (!isAuthenticated) {
      console.warn('Secret archive blocked: Authentication required.');
      return;
    }
    setIsSecretArchiveRevealed(true);
  }, [isAuthenticated]);

  const hideSecretArchive = useCallback(() => {
    setIsSecretArchiveRevealed(false);
  }, []);

  // Initial Server Status Sync upon Authentication
  useEffect(() => {
    if (!isAuthenticated || !user?.discordId) return;

    let isMounted = true;

    // Fetch persistent unlock state directly from server
    fetch('/api/easter-eggs/status')
      .then(res => res.json())
      .then(async (status) => {
        if (!isMounted) return;
        if (status.isAuthenticated) {
          const rewardGranted = Boolean(status.finalRewardGranted || status.secretKohanGameCompleted);
          if (rewardGranted) {
            setFinalRewardGranted(true);
            setSecretKohanGameCompleted(true);
          }

          if (status.iraqiThemeUnlocked || rewardGranted) {
            setIraqiThemeUnlocked(true);
            setKohanRoomUnlocked(true);
            setSaddamGameGoalReached(true);
            const serverTheme = status.activeTheme || 'kohan-iraqi';
            setActiveTheme(serverTheme);
            setIraqiThemeActive(serverTheme === 'kohan-iraqi');
          }

          if (status.saddamMissionCompleted) {
            setSaddamMissionCompleted(true);
          }

          if (typeof status.saddamBestTime === 'number' && status.saddamBestTime > 0) {
            setSaddamBestTime(prev => Math.max(prev, status.saddamBestTime));
            if (status.saddamBestTime >= GOAL_SURVIVAL_SECONDS || status.saddamGameGoalReached) {
              setSaddamGameGoalReached(true);
              setSaddamMissionCompleted(true);
            }
          }

          // Authoritative flag list from server / Firestore
          if (Array.isArray(status.collectedFlagIds) && status.collectedFlagIds.length > 0) {
            setCollectedFlagIds(status.collectedFlagIds);
          }

          // Check if both requirements are met but server does not have reward granted yet:
          const bestTimeNow = Math.max(saddamBestTimeRef.current, Number(status.saddamBestTime || 0));
          const goalReachedNow = status.saddamGameGoalReached || bestTimeNow >= GOAL_SURVIVAL_SECONDS;
          const flagsNow = status.collectedFlagIds || collectedFlagIdsRef.current;

          if (
            !rewardGranted &&
            flagsNow.length >= TOTAL_IRAQI_FLAGS &&
            goalReachedNow
          ) {
            const claimed = await claimIraqiTheme(flagsNow, bestTimeNow);
            if (claimed && isMounted) {
              easterEggSound.playSecretRoomUnlockedSound();
              setShowThemeUnlockedOverlay(true);
            }
          }
        }
      })
      .catch(err => console.warn('Could not retrieve easter eggs server status:', err));

    return () => {
      isMounted = false;
    };
  }, [isAuthenticated, user?.discordId, claimIraqiTheme]);

  // Real-time Firestore snapshot for authenticated users
  useEffect(() => {
    if (!isAuthenticated || !user?.discordId) return;

    let unsubscribe: (() => void) | null = null;
    const userDocRef = doc(db, 'user_easter_eggs', user.discordId);

    try {
      unsubscribe = onSnapshot(userDocRef, (snap) => {
        if (snap.exists()) {
          const data = snap.data() as Partial<UserEasterEggDoc>;
          if (Array.isArray(data.collectedFlagIds)) {
            setCollectedFlagIds(data.collectedFlagIds);
          }
          const rewardGranted = Boolean(data.finalRewardGranted || data.secretKohanGameCompleted);
          if (rewardGranted) {
            setFinalRewardGranted(true);
            setSecretKohanGameCompleted(true);
          }
          if (data.saddamMissionCompleted) setSaddamMissionCompleted(true);
          if (data.kohanRoomUnlocked || rewardGranted) setKohanRoomUnlocked(true);
          if (data.iraqiThemeUnlocked || rewardGranted) setIraqiThemeUnlocked(true);
          if (typeof data.saddamBestTime === 'number') {
            setSaddamBestTime(prev => Math.max(prev, data.saddamBestTime!));
            if (data.saddamBestTime >= GOAL_SURVIVAL_SECONDS || data.saddamGameGoalReached) {
              setSaddamGameGoalReached(true);
              setSaddamMissionCompleted(true);
            }
          }
          if (data.activeTheme === 'kohan-iraqi' || data.activeTheme === 'creative-nexus') {
            setActiveTheme(data.activeTheme);
            setIraqiThemeActive(data.activeTheme === 'kohan-iraqi');
          } else if (typeof data.iraqiThemeActive === 'boolean') {
            setIraqiThemeActive(data.iraqiThemeActive);
            setActiveTheme(data.iraqiThemeActive ? 'kohan-iraqi' : 'creative-nexus');
          }
        }
      }, (err) => {
        console.warn('Firestore user_easter_eggs sync notice:', err.message);
      });
    } catch (err) {
      console.warn('Firestore easter egg snapshot error:', err);
    }

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [isAuthenticated, user?.discordId]);

  // Check if a flag is collected
  const isFlagCollected = useCallback((flagId: string): boolean => {
    return collectedFlagIds.includes(flagId);
  }, [collectedFlagIds]);

  // Collect a hidden Iraqi flag: Immediately persisted to Firestore under user_easter_eggs/{discordId}
  const collectFlag = useCallback(async (flagId: string): Promise<CollectFlagResult> => {
    if (!isAuthenticated || !user?.discordId) {
      return {
        success: false,
        isNew: false,
        flagId,
        flagsCount: 0,
        unlockedAll: false,
      };
    }

    const currentList = collectedFlagIdsRef.current;
    if (currentList.includes(flagId)) {
      setIsSecretArchiveRevealed(true);
      return {
        success: true,
        isNew: false,
        flagId,
        flagsCount: currentList.length,
        unlockedAll: currentList.length >= TOTAL_IRAQI_FLAGS,
      };
    }

    const updated = [...currentList, flagId];
    const newCount = updated.length;
    const reachedAll = newCount >= TOTAL_IRAQI_FLAGS;

    setCollectedFlagIds(updated);
    setIsSecretArchiveRevealed(true);

    // Audio & UI revelation banner
    easterEggSound.playFlagFoundSound();
    setRecentFlagCollected({ id: flagId, number: newCount });

    // 1. Immediately persist this specific flag to Firestore via server endpoint
    try {
      fetch('/api/easter-eggs/collect-flag', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ flagId })
      }).catch(err => console.warn('Flag sync error:', err));
    } catch (err) {
      console.warn('Error dispatching flag collection:', err);
    }

    // 2. Update local storage cache
    saveToLocalStorage(
      updated,
      kohanRoomUnlockedRef.current,
      iraqiThemeUnlockedRef.current,
      iraqiThemeActiveRef.current,
      activeThemeRef.current,
      saddamBestTimeRef.current,
      saddamGameGoalReachedRef.current,
      finalRewardGrantedRef.current
    );

    // 3. Check if BOTH requirements (5 flags + 2:00 survival) are fulfilled AND reward has NOT been granted yet
    const hasSaddamGoal = saddamGameGoalReachedRef.current || saddamBestTimeRef.current >= GOAL_SURVIVAL_SECONDS;
    if (!finalRewardGrantedRef.current && reachedAll && hasSaddamGoal) {
      if (isAuthenticated) {
        const claimed = await claimIraqiTheme(updated);
        if (claimed) {
          setTimeout(() => {
            easterEggSound.playSecretRoomUnlockedSound();
            setShowThemeUnlockedOverlay(true);
          }, 600);
        }
      }
    }

    return {
      success: true,
      isNew: true,
      flagId,
      flagsCount: newCount,
      unlockedAll: reachedAll,
    };
  }, [isAuthenticated, user?.discordId, claimIraqiTheme, saveToLocalStorage]);

  // Set Theme Preference (Switch between Creative Nexus and Kohan Iraqi)
  const setThemePreference = useCallback(async (newTheme: AppThemeType): Promise<boolean> => {
    const missionsMet = (collectedFlagIdsRef.current.length >= TOTAL_IRAQI_FLAGS) && (saddamGameGoalReachedRef.current || saddamBestTimeRef.current >= GOAL_SURVIVAL_SECONDS || saddamMissionCompletedRef.current);
    const isAllowed = isOwnerUser || iraqiThemeUnlockedRef.current || finalRewardGrantedRef.current || missionsMet;

    if (!isAllowed && newTheme === 'kohan-iraqi') {
      console.warn('Cannot switch to Kohan Iraqi Theme: locked until both 5 flags and 2:00 game survival are met.');
      return false;
    }

    const isIraqi = newTheme === 'kohan-iraqi';
    setActiveTheme(newTheme);
    setIraqiThemeActive(isIraqi);
    if (isIraqi || isOwnerUser || missionsMet) {
      setIraqiThemeUnlocked(true);
    }

    saveToLocalStorage(
      collectedFlagIdsRef.current.length > 0 ? collectedFlagIdsRef.current : (isOwnerUser ? Array.from(VALID_IRAQI_FLAG_IDS) : []),
      kohanRoomUnlockedRef.current || isOwnerUser,
      isAllowed || iraqiThemeUnlockedRef.current,
      isIraqi,
      newTheme,
      saddamBestTimeRef.current,
      saddamGameGoalReachedRef.current || isOwnerUser,
      finalRewardGrantedRef.current || isOwnerUser
    );

    if (isAuthenticated) {
      try {
        await fetch('/api/easter-eggs/set-theme', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ activeTheme: newTheme, isOwner: isOwnerUser, missionsCompleted: isAllowed })
        });
      } catch (err) {
        console.warn('Failed to persist theme preference on server:', err);
      }
    }

    return true;
  }, [isOwnerUser, isAuthenticated, saveToLocalStorage]);

  // Toggle Iraqi Mode Theme (shorthand helper)
  const toggleIraqiTheme = useCallback(async (explicitActive?: boolean) => {
    const missionsMet = (collectedFlagIdsRef.current.length >= TOTAL_IRAQI_FLAGS) && (saddamGameGoalReachedRef.current || saddamBestTimeRef.current >= GOAL_SURVIVAL_SECONDS || saddamMissionCompletedRef.current);
    const isAllowed = isOwnerUser || iraqiThemeUnlockedRef.current || finalRewardGrantedRef.current || missionsMet;

    if (!isAllowed) {
      console.warn('Iraqi Theme is locked until both 5 flags and 2:00 game survival are met.');
      return;
    }

    const nextActive = typeof explicitActive === 'boolean' 
      ? explicitActive 
      : !iraqiThemeActiveRef.current;

    await setThemePreference(nextActive ? 'kohan-iraqi' : 'creative-nexus');
  }, [setThemePreference, isOwnerUser]);

  // Reset Progress (for debugging / testing)
  const resetFlagsProgress = useCallback(async () => {
    setCollectedFlagIds([]);
    setKohanRoomUnlocked(false);
    setIraqiThemeUnlocked(false);
    setIraqiThemeActive(false);
    setFinalRewardGranted(false);
    setSecretKohanGameCompleted(false);
    setSaddamMissionCompleted(false);
    setActiveTheme('creative-nexus');
    saveToLocalStorage([], false, false, false, 'creative-nexus', 0, false, false);
  }, [saveToLocalStorage]);

  const dismissRecentFlagBanner = useCallback(() => {
    setRecentFlagCollected(null);
  }, []);

  const dismissUnlockCelebration = useCallback(() => {
    setShowUnlockCelebration(false);
  }, []);

  const dismissThemeUnlockedOverlay = useCallback(() => {
    setShowThemeUnlockedOverlay(false);
  }, []);

  return (
    <EasterEggContext.Provider
      value={{
        collectedFlagIds,
        flagsCount: collectedFlagIds.length,
        totalFlags: TOTAL_IRAQI_FLAGS,
        kohanRoomUnlocked,
        saddamBestTime,
        saddamGameGoalReached,
        saddamMissionCompleted,
        finalRewardGranted,
        secretKohanGameCompleted,
        recordGameBestSurvival,
        iraqiThemeUnlocked,
        iraqiThemeActive,
        activeTheme,
        setActiveTheme: setThemePreference,
        isFlagCollected,
        collectFlag,
        toggleIraqiTheme,
        setThemePreference,
        claimIraqiTheme,
        resetFlagsProgress,

        // Kohan Secret Room Game
        isKohanGameOpen,
        setIsKohanGameOpen: handleSetIsKohanGameOpen,

        // Secret Archive Revelation Controls
        isSecretArchiveRevealed,
        revealSecretArchive,
        hideSecretArchive,
        // Secret Progress Modal & Overlays
        isSecretProgressOpen,
        setIsSecretProgressOpen,
        recentFlagCollected,
        dismissRecentFlagBanner,
        showUnlockCelebration,
        dismissUnlockCelebration,
        showThemeUnlockedOverlay,
        dismissThemeUnlockedOverlay,
      }}
    >
      {children}
    </EasterEggContext.Provider>
  );
};

export const useEasterEggs = () => {
  const context = useContext(EasterEggContext);
  if (!context) {
    throw new Error('useEasterEggs must be used within an EasterEggProvider');
  }
  return context;
};
