import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'en' | 'ar';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<string, Record<Language, string>> = {
  // Navbar
  'nav.home': { en: 'Home', ar: 'الرئيسية' },
  'nav.announcements': { en: 'Announcements', ar: 'الإعلانات' },
  'nav.notifications': { en: 'Notifications', ar: 'الإشعارات' },
  'nav.history': { en: 'Server History', ar: 'تاريخ السيرفر' },
  'nav.owners': { en: 'Owners Hall', ar: 'قاعة الأونرز' },
  'nav.why': { en: 'Features', ar: 'مميزاتنا' },
  'nav.vibe': { en: 'Channels', ar: 'القنوات' },
  'nav.codex': { en: 'Guidebook', ar: 'دليل الموقع' },
  'nav.handbook': { en: 'Guidebook', ar: 'دليل الموقع' },
  'nav.guidebook': { en: 'Guidebook', ar: 'دليل الموقع' },
  'nav.events': { en: 'Events', ar: 'الفعاليات' },
  'nav.staff': { en: 'Staff', ar: 'الإدارة' },
  'nav.archive': { en: 'Archive', ar: 'الأرشيف' },
  'nav.join': { en: 'Join us', ar: 'انضم إلينا' },
  'nav.joinServer': { en: 'Join the server', ar: 'انضم للسيرفر' },

  // Hero Reference
  'hero.hi': { en: 'Welcome to', ar: 'مرحبا بك في' },
  'hero.title': { en: 'Creative Nexus', ar: 'مركز الإبداع' },
  'hero.eyebrow': { en: '# CREATIVE NEXUS — COMMUNITY', ar: '# مـركـز الإبـداع — نـكـسـس' },
  'hero.headline': { en: 'Where Passion Meets Innovation', ar: 'حيث يلتقي الشغف بالابتكار' },
  'hero.joinBtn': { en: 'Join Discord Server', ar: 'انضم إلى سيرفر الديسكورد' },
  'hero.exploreBtn': { en: 'Explore History', ar: 'استكشف تاريخنا' },
  'hero.dashboardBtn': { en: 'Server Dashboard', ar: 'لوحة السيرفر' },
  'hero.tag': { en: 'Where creators connect', ar: 'نقطة التقاء المبدعين' },
  'hero.subtitle': { en: 'Where creators connect', ar: 'نقطة التقاء المبدعين' },
  'hero.desc': { 
    en: 'The premier community for creators, developers, designers, and tech enthusiasts. Connect with like-minded minds, showcase your creations, and grow in an inspiring sanctuary.', 
    ar: 'المجتمع العربي الأرقى لصناع المحتوى، المطورين، المصممين، وعشاق التقنية. انضم إلى آلاف المبدعين وابدأ رحلتك الآن في مركز الإبداع.' 
  },
  'hero.explore': { en: 'Explore channels', ar: 'اكتشف القنوات' },
  'hero.chips.design': { en: 'design', ar: 'التصميم' },
  'hero.chips.games': { en: 'games', ar: 'الألعاب' },
  'hero.chips.discussions': { en: 'discussions', ar: 'المناقشات' },

  // Creative Nexus Features (Why Section)
  'features.stat1Label': { en: 'Active Members', ar: 'أعضاء نشطين' },
  'features.stat2Label': { en: 'Live Community', ar: 'تفاعل متواصل' },
  'features.stat3Label': { en: 'Dedicated Hubs', ar: 'قسم وروم مخصص' },
  'features.stat4Label': { en: 'Authentic Community', ar: 'مجتمع عربي أصيل' },
  'features.eyebrow': { en: 'COMMUNITY PLATFORM', ar: 'مزايا المنصة والمجتمع' },
  'features.heading': { en: 'An Ecosystem for Every Creator', ar: 'بيئة متكاملة لكل مبدع' },
  'features.subheading': { en: 'Explore the core archives, official portals, and interactive systems built for our community.', ar: 'استكشف الأرشيف التاريخي، البوابات الرسمية، والأنظمة التفاعلية المخصصة لأعضاء مجتمعنا.' },
  'features.feat1Title': { en: 'Archival History & Chronicles', ar: 'سجل التاريخ وسدانة السيرفر' },
  'features.feat1Desc': { en: 'An interactive historical vault chronicling server epochs, recorded owners from Kevin to the Golden Era, and sacred relics.', ar: 'أرشيف تاريخي تفاعلي يوثق فصول ومحطات السيرفر منذ تأسيسه، وسجل الملاك المتعاقبين، والآثار والميثاق الخالد.' },
  'features.feat2Title': { en: 'Community Codex & Rules', ar: 'دستور وقوانين السيرفر' },
  'features.feat2Desc': { en: 'The comprehensive server constitution detailing code of conduct, channel guidelines, moderation policies, and member standards.', ar: 'الدستور الشامل وقوانين السيرفر المعتمدة التي توضح لوائح الرومات، قواعد السلوك، وإرشادات الانضباط لجميع الأعضاء.' },
  'features.feat3Title': { en: 'Ranks & Promotion Portal', ar: 'نظام الرتب والترقيات' },
  'features.feat3Desc': { en: 'Review server rank tiers, calculate required points, and submit official rank promotion applications directly to staff.', ar: 'استكشف رتب السيرفر المعتمدة ونقاط الترقية المطلوبة، وقدم طلبات الترقية الرسمية مباشرة لمراجعة الإدارة.' },
  'features.feat4Title': { en: 'Achievements & Milestones', ar: 'منظومة الإنجازات والأوسمة' },
  'features.feat4Desc': { en: 'An interactive badge and quest system celebrating member milestones, contributions, and community accomplishments.', ar: 'نظام تفاعلي للأوسمة والإنجازات يحتفي بنشاط الأعضاء ومساهماتهم المميزة داخل السيرفر.' },
  'features.feat5Title': { en: 'Staff & Guardian Administration', ar: 'إدارة الطاقم وسجل المشرفين' },
  'features.feat5Desc': { en: 'The verified staff hierarchy, activity ratings, moderation duties, and personalized guardian dossiers.', ar: 'الهيكل الإداري المعتمد، تقييمات النشاط، وسجلات الحراس والمشرفين القائمين على حماية وتنظيم المجتمع.' },
  'features.feat6Title': { en: 'Live Broadcasts & Notifications', ar: 'البث المباشر والإعلانات الرسمية' },
  'features.feat6Desc': { en: 'Real-time synchronization with Discord guild events, official bulletin announcements, and live alerts.', ar: 'مزامنة حية ومباشرة مع فعاليات ديسكورد، ونشرة الإعلانات والقرارات الرسمية ومركز الإشعارات الفوري.' },

  // Vibe Section
  'vibe.eyebrow': { en: 'COMMUNITY VIBE', ar: 'أجواء السيرفر' },
  'vibe.heading': { en: 'Live Channel Previews', ar: 'استكشف قنواتنا الحية' },
  'vibe.subheading': { en: 'Get an authentic glimpse into our daily conversations, creative showcases, and gaming lobbies.', ar: 'نظرة واقعية من داخل رومات السيرفر وكيف يتشارك الأعضاء الإبداع والمرح.' },

  // Join Banner
  'banner.eyebrow': { en: 'START YOUR JOURNEY', ar: 'ابدأ رحلتك الآن' },
  'banner.heading': { en: 'Ready to join Creative Nexus?', ar: 'مستعد تكون جزءاً من مركز الإبداع؟' },
  'banner.subheading': { en: 'Connect with thousands of fellow creators, share your passions, and attend our upcoming live events.', ar: 'انضم إلى آلاف المبدعين، استعرض أعمالك، وشارك في الفعاليات القادمة اليوم.' },
  'banner.button': { en: 'Join Discord Server', ar: 'انضم إلى سيرفر الديسكورد' },

  // Why Creative Nexus (Bento)
  'why.title': { en: 'Why Creative Nexus?', ar: 'ليه مركز الإبداع؟' },
  'why.desc': { en: 'Four reasons creators stay.', ar: 'أربعة أسباب تخلي المبدعين يكملوا معنا.' },
  'why.f1.title': { en: 'A creator community', ar: 'مجتمع مبدعين' },
  'why.f1.desc': { en: 'Talk with people who share your passion and ambition.', ar: 'تواصل مع أشخاص يشاركونك نفس الشغف والطموح.' },
  'why.f2.title': { en: 'A safe space', ar: 'بيئة آمنة' },
  'why.f2.desc': { en: 'Clear rules and an active team for your comfort.', ar: 'قوانين واضحة وإدارة نشطة لضمان راحتك.' },
  'why.f3.title': { en: 'Varied content', ar: 'محتوى متنوع' },
  'why.f3.desc': { en: 'From design talk to games and events.', ar: 'من نقاشات التصميم إلى الألعاب والفعاليات.' },
  'why.f4.title': { en: 'Real opportunities', ar: 'فرص حقيقية' },
  'why.f4.desc': { en: 'Share your work, get feedback and find collaborators.', ar: 'شارك أعمالك، خد تغذية راجعة، ولاقي شركاء للتعاون.' },

  // Vibe / Channels Preview
  'vibe.title': { en: 'Feel the vibe inside', ar: 'اكتشف الأجواء من جوّه' },
  'vibe.desc': { en: 'A quick look at how we share, talk and play together.', ar: 'لمحة سريعة عن طريقتنا في المشاركة والحوار واللعب مع بعض.' },
  'vibe.cta': { en: 'Join the conversation', ar: 'شاركنا الحوار' },
  'vibe.inputPlaceholder': { en: 'Message in #general-discussion...', ar: 'اكتب رسالة في #المناقشات-العامة...' },

  // Join CTA
  'join.title': { en: 'Ready to join the creators?', ar: 'جاهز تنضم للمبدعين؟' },
  'join.desc': { en: 'Your seat at the Nexus is open. Jump in and say hi.', ar: 'مكانك في مركز الإبداع جاهز. ادخل وقول أهلاً.' },
  'join.btn': { en: 'Join the Discord server', ar: 'انضم إلى سيرفر ديسكورد' },

  // Intro - Edgar's Creative Community (Replaces Curators of History)
  'intro.badge': { en: 'THE ARTIST & STREAMER SANCTUARY', ar: 'مجتمع الفنان والستريمر EDGAR' },
  'intro.title': { en: 'The Creative Realm of Edgar', ar: 'مملكة الفنان والستريمر Edgar' },
  'intro.desc': { en: 'CREATIVE NEXUS is the official Discord community belonging to the artist and streamer Edgar. Built to bring together passionate fans, creators, and gamers from across the globe, this server is a sanctuary for showcasing raw creativity, sharing unique art and talents, laughing in lively voice channels, tuning into exciting live streams, and having pure, unadulterated fun together.', ar: 'سيرفر مركز الابداع (CREATIVE NEXUS) هو المجتمع والملتقى الرسمي التابع للفنان وصانع المحتوى والستريمر Edgar. صُمم هذا السيرفر ليجمع عشاقه ومتابعيه ومحبيه من شتى بقاع العالم في بيت واحد دافئ؛ ليكون منصتكم الحرة لإطلاق العنان للمواهب، استعراض الفنون والإبداعات، عيش لحظات البثوث المباشرة التفاعلية، خوض الألعاب والتحديات، وقضاء أمتع الأوقات والضحك في أجواء ملهمة ومرحة.' },
  'intro.feature.creativity': { en: 'Showcase Creativity & Art', ar: 'استعراض الإبداع والفنون' },
  'intro.feature.creativity.desc': { en: 'Share illustrations, design, music, and ideas with fellow creators.', ar: 'شارك رسوماتك، تصاميمك، وإبداعاتك مع نخبة من المواهب الشغوفة.' },
  'intro.feature.streams': { en: 'Live Streams & Highlights', ar: 'بثوث إدغار المباشرة' },
  'intro.feature.streams.desc': { en: 'Tune into Edgar’s live streams, react in real time, and share epic moments.', ar: 'تابع بثوث إدغار الحية مباشرة، تفاعل مع كل لقطة، وعش المتعة الحقيقية.' },
  'intro.feature.fun': { en: 'Endless Fun & Community Vibes', ar: 'مرح وفعاليات وألعاب لا تنتهي' },
  'intro.feature.fun.desc': { en: 'Hang out in active voice rooms, play games, and enjoy great camaraderie.', ar: 'سوالف وضحك في الغرف الصوتية، بطولات ألعاب، وأجواء أخوية لا تُنسى.' },
  'intro.feature.edgar': { en: 'United Under Edgar’s Vision', ar: 'مجتمع متماسك بقيادة إدغار' },
  'intro.feature.edgar.desc': { en: 'A welcoming, supportive family celebrating Edgar and every member.', ar: 'عائلة راقية ومرحبة تحتفي بكل عضو وتساند مسيرة الفنان إدغار.' },

  // Stats
  'stat.members': { en: 'Sanctuary Members', ar: 'أعضاء السيرفر' },
  'stat.events': { en: 'Live Events & Streams', ar: 'البثوث والفعاليات' },
  'stat.staff': { en: 'Community Guardians', ar: 'طاقم الإدارة' },
  'stat.year': { en: 'Year Founded', ar: 'تاريخ التأسيس' },

  // Footer
  'footer.manifesto': { en: 'Manifesto', ar: 'البيان' },
  'footer.rules': { en: 'Rules', ar: 'القوانين' },
  'footer.contact': { en: 'Contact', ar: 'تواصل معنا' },
  'footer.enter': { en: 'Join Edgar\'s Server', ar: 'دخول سيرفر إدغار' },
  'footer.copyright': { en: '© 2026 Creatine Nexus. Dedicated to Edgar & Community.', ar: '© 2026 مركز الابداع. مكرس لـ Edgar ومجتمعه.' },
  'footer.est': { en: 'EST. 2020', ar: 'تأسست 2020' },
  
  // Logo
  'logo.subtitle': { en: "Edgar's Community", ar: 'مجتمع إدغار' },

  // History Page
  'history.subtitle': { en: 'The Archive', ar: 'الأرشيف' },
  'history.quote': { en: '"Every community has a story. This is ours."', ar: '"كل مجتمع له قصة. هذه هي قصتنا."' },
  
  'history.1.year': { en: '2024', ar: '2024' },
  'history.1.title': { en: 'THE BEGINNING', ar: 'البداية' },
  'history.1.desc': { en: 'Creatine Nexus was forged from a shared vision to create a sanctuary for dedicated individuals. A small group of founding members laid the foundation, establishing the core principles and the first archives of our community.', ar: 'تأسس مركز الابداع من رؤية مشتركة لإنشاء ملاذ للأفراد المخلصين. وضعت مجموعة صغيرة من الأعضاء المؤسسين الأساس، وأرست المبادئ الأساسية والأرشيفات الأولى لمجتمعنا.' },
  
  'history.2.year': { en: '2025', ar: '2025' },
  'history.2.title': { en: 'THE EXPANSION', ar: 'التوسع' },
  'history.2.desc': { en: 'As our numbers grew, so did our ambitions. The archives expanded, new halls were constructed, and the community blossomed into a vibrant network of scholars, creators, and enthusiasts. The Nexus became a beacon of structured discourse.', ar: 'مع نمو أعدادنا، زادت طموحاتنا. توسعت الأرشيفات، وتم بناء قاعات جديدة، وازدهر المجتمع ليصبح شبكة نابضة بالحياة من العلماء والمبدعين والمتحمسين. أصبح المركز منارة للخطاب المنظم.' },
  
  'history.3.year': { en: '2026', ar: '2026' },
  'history.3.title': { en: 'A NEW ERA', ar: 'حقبة جديدة' },
  'history.3.desc': { en: 'We step into a new chapter, bringing the ancient archives into the modern digital age. The community stands stronger than ever, united by history and looking forward to the future.', ar: 'ندخل فصلاً جديداً، وننقل الأرشيفات القديمة إلى العصر الرقمي الحديث. يقف المجتمع أقوى من أي وقت مضى، متحداً بالتاريخ ويتطلع إلى المستقبل.' },

  // The Owners of Creative Nexus
  'history.owners.sectionTitle': { en: 'THE OWNERS OF CREATIVE NEXUS', ar: 'ملاك مركز الابداع' },
  'history.owners.sectionSubtitle': { en: 'The Archival Chronicle of Leadership', ar: 'السجل التاريخي لقادة السيرفر' },
  'history.owners.sectionDesc': { en: 'A sacred visual timeline honoring the visionary leaders and historical custodians who guided and shaped the destiny of CREATIVE NEXUS through every chapter.', ar: 'سجل زمني بصري يخلد ذكرى القادة والحراس التاريخيين الذين قادوا وشكلوا مسيرة سيرفر مركز الابداع عبر جميع فصوله.' },
  
  'history.owners.filter.all': { en: 'All Custodians', ar: 'جميع الملاك' },
  'history.owners.filter.present': { en: 'Currently Present', ar: 'المتواجدون حالياً' },
  'history.owners.filter.former': { en: 'Former Guardians', ar: 'القادة السابقون' },

  'history.status.present': { en: 'Currently present', ar: 'متواجد حالياً' },
  'history.status.former': { en: 'No longer with the server', ar: 'لم يعد متواجداً في السيرفر' },

  'country.iraq': { en: 'Iraq', ar: 'العراق' },
  'country.uae': { en: 'United Arab Emirates', ar: 'الإمارات العربية المتحدة' },
  'country.egypt': { en: 'Egypt', ar: 'جمهورية مصر العربية' },

  // Homepage Owner Showcase
  'home.owners.subtitle': { en: 'THE ARCHITECTS OF OUR REALM', ar: 'صناع المجد والأثر' },
  'home.owners.title': { en: 'Leadership & Sovereign Custodians', ar: 'سدنة السيرفر وقادته' },
  'home.owners.desc': { en: 'Honoring the visionaries who founded, nurtured, and currently champion the spirit of CREATIVE NEXUS into modern greatness.', ar: 'تحية تقدير وإجلال للقادة الذين رسخوا دعائم مركز الابداع (CREATIVE NEXUS) ويواصلون قيادة مجتمعه نحو آفاق المستقبل.' },
  'home.owners.viewAll': { en: 'Explore Complete Historical Chronicle (7 Owners)', ar: 'استعراض السجل التاريخي الشامل لجميع الملاك (7)' },

  // Edgar - Current Server Owner
  'owner.edgar.name': { en: 'Edgar', ar: 'Edgar' },
  'owner.edgar.title': { en: 'Server Owner', ar: 'مالك السيرفر' },
  'owner.edgar.nationality': { en: 'Egyptian', ar: 'مصري' },
  'owner.edgar.role': { en: 'Artist, Live Streamer & Server Owner', ar: 'الفنان، الستريمر ومالك السيرفر' },
  'owner.edgar.desc': { en: 'The artist, content creator, and live streamer at the heart of CREATIVE NEXUS. Edgar built this sanctuary to bring together his fans, celebrate creative arts, host captivating live streams, and offer a joyful home where everyone can express talent and have unforgettable fun.', ar: 'الفنان المبدع، صانع المحتوى والستريمر الذي ينبض سيرفر مركز الابداع بروحه وإبداعه. أسس إدغار هذا المكان ليجمع كل معجبيه ومتابعيه، محتفياً بالفنون، ومقدماً أمتع البثوث المباشرة، ليكون السيرفر مساحة دائمة للفرح، الإبداع، وأروع الأوقات المشتركة.' },
  'owner.edgar.badge': { en: 'The Creative Sovereign & Streamer', ar: 'الستريمر والفنان السيادي' },

  // Sh3la Special Fire Title
  'owner.sh3la.fireBadge': { en: 'The Eternal Flame', ar: 'الشعلة الخالدة' },
  'owner.sh3la.fireDesc': { en: 'One of the most monumental administrators in server history. His incandescent spirit, fiery loyalty, and unmatched tenure forged the bedrock of CREATIVE NEXUS.', ar: 'أحد أعظم وأهم الإداريين في تاريخ السيرفر. أشعلت روحه المتوقدة وتفانيه المتقد أطول وأهم فصول مركز الابداع، تاركاً إرثاً لا ينطفئ.' },

  // Owners
  'owner.1.name': { en: 'Kevin', ar: 'Kevin' },
  'owner.1.title': { en: 'Server Owner', ar: 'مالك السيرفر' },
  'owner.1.desc': { en: 'Co-founder of CREATIVE NEXUS who helped Edgar establish the server structure.', ar: 'أحد مؤسسي مركز الابداع والذي ساعد إيدجر في تأسيس وترتيب بنية السيرفر.' },
  'owner.1.badge': { en: 'The Genesis', ar: 'البداية والتأسيس' },

  'owner.2.name': { en: 'Sh3la', ar: 'Sh3la' },
  'owner.2.title': { en: 'Server Owner', ar: 'مالك السيرفر' },
  'owner.2.desc': { en: 'One of the most important figures in server history. A brother, mentor, and unwavering pillar.', ar: 'أحد أهم الشخصيات والقيادات في تاريخ السيرفر. كان أخاً ومرشداً وسنداً لا يتزعزع لإيدجر.' },
  'owner.2.badge': { en: 'The Golden Chapter', ar: 'الفصل الذهبي' },

  'owner.hamo.name': { en: 'Hamo', ar: 'حمو' },
  'owner.hamo.title': { en: 'Server Owner', ar: 'مالك السيرفر' },
  'owner.hamo.desc': { en: 'The server developer who contributed greatly to server history and became an Owner.', ar: 'مبرمج السيرفر الذي ساهم ببراعة في تطوير وبرمجة بنية السيرفر وأصبح أحد ملاكه.' },
  'owner.hamo.badge': { en: 'The Programmer', ar: 'المبرمج' },

  'owner.super.name': { en: 'Super', ar: 'Super' },
  'owner.super.title': { en: 'Server Owner', ar: 'مالك السيرفر' },
  'owner.super.desc': { en: 'The youngest and one of the kindest among them, navigating the server through turbulent times.', ar: 'الأصغر سناً ومن أطيبهم، ساند السيرفر في أصعب وأدق فتراته.' },
  'owner.super.badge': { en: 'The Young Luminary', ar: 'النجم الشاب' },

  'owner.osama.name': { en: 'Osama', ar: 'Osama' },
  'owner.osama.title': { en: 'Server Owner', ar: 'مالك السيرفر' },
  'owner.osama.desc': { en: 'A distinguished leader and beloved figure in server history.', ar: 'قائد مميز وشخصية محبوبة تركت بصمة طيبة في مسيرة السيرفر.' },
  'owner.osama.badge': { en: 'The Horizon Voyager', ar: 'المستكشف' },

  'owner.adham.name': { en: 'Adham', ar: 'Adham' },
  'owner.adham.title': { en: 'Former Owner', ar: 'مالك سابق' },
  'owner.adham.desc': { en: 'One of the administrators and leaders who took part in a crucial chapter of the server alongside Super and Osama.', ar: 'أحد الإداريين والقادة الذين خاضوا مرحلة حساسة في مسيرة السيرفر مع سوبر وأسامة.' },
  'owner.adham.badge': { en: 'The Vanguard', ar: 'حارس المرحلة' },

  'owner.shadow.name': { en: 'SHADOW', ar: 'SHADOW' },
  'owner.shadow.title': { en: 'Server Owner', ar: 'مالكة السيرفر' },
  'owner.shadow.desc': { en: 'The wife of the server owner and an enduring pillar of care and strength.', ar: 'زوجة مالك السيرفر وإحدى أهم ركائز الدعم والاستقرار في المجتمع.' },
  'owner.shadow.badge': { en: 'Eternal Heart', ar: 'القلب الخالد' },

  'owner.abysswolf.name': { en: 'ABYSSWOLF', ar: 'ABYSSWOLF' },
  'owner.abysswolf.title': { en: 'Server Owner', ar: 'مالك السيرفر' },
  'owner.abysswolf.desc': { en: 'The second kindest person in the world, loyal leader, and chief architect of the Golden Era.', ar: 'من أطيب الأشخاص في العالم، قائد وفيّ، والداعم الأكبر لإيدجر في تدشين العصر الذهبي.' },
  'owner.abysswolf.badge': { en: 'The Radiant Protector', ar: 'الحامي النبيل' },

  'owner.kohan.name': { en: 'KOHAN', ar: 'KOHAN' },
  'owner.kohan.title': { en: 'Server Owner', ar: 'مالك السيرفر' },
  'owner.kohan.desc': { en: 'One of the kindest people in the world and one of the greatest supporters of Edgar.', ar: 'من أطيب الأشخاص في العالم، وأحد أكبر الداعمين لإيدجر ومسيرة السيرفر.' },
  'owner.kohan.badge': { en: 'Heart of Mesopotamia', ar: 'قلب بلاد الرافدين' },

  'owner.luigi.name': { en: 'LUIGI', ar: 'LUIGI' },
  'owner.luigi.title': { en: 'Server Owner', ar: 'مالك السيرفر' },
  'owner.luigi.desc': { en: 'A key custodian and owner sustaining the vibrancy and strength of the Golden Era.', ar: 'أحد ملاك السيرفر الحاليين المساهمين في مواصلة بناء وازدهار العصر الذهبي.' },
  'owner.luigi.badge': { en: 'Golden Vanguard', ar: 'الدرع الذهبي' },

  'owner.yuzu.name': { en: 'YUZU', ar: 'YUZU' },
  'owner.yuzu.title': { en: 'Server Owner', ar: 'مالك السيرفر' },
  'owner.yuzu.desc': { en: 'A dedicated owner and vital pillar in CREATIVE NEXUS, supporting Edgar and the community with unwavering devotion and leadership.', ar: 'أحد ملاك السيرفر وركيزة أساسية في مركز الابداع، يقف إلى جانب إيدجر والمجتمع بتفانٍ وحرص قيادي دائم.' },
  'owner.yuzu.badge': { en: 'The Eternal Guardian', ar: 'الحامي الأبدي' },

  // Owner Character Showcase & Management
  'owner.character.edit': { en: 'Edit Character', ar: 'تعديل الشخصية' },
  'owner.character.title': { en: 'Owner Showcase Character', ar: 'شخصية المالك الاستعراضية' },
  'owner.character.desc': { en: 'Upload transparent PNG character artwork representing this Owner on their chronicle card.', ar: 'ارفع شخصية أنمي أو لعبة بصيغة PNG شفافة لتظهر بشكل استعراضي وفخم داخل البطاقة.' },
  'owner.character.upload': { en: 'Upload PNG Image', ar: 'رفع ملف (PNG شفاف)' },
  'owner.character.url': { en: 'Image Link URL', ar: 'رابط مباشر' },
  'owner.character.save': { en: 'Save Character', ar: 'حفظ الشخصية' },
  'owner.character.remove': { en: 'Remove Character', ar: 'إزالة الشخصية' },
  'owner.character.clear': { en: 'Clear Preview', ar: 'مسح المعاينة' },
  'owner.character.preview': { en: 'Live Card Preview', ar: 'معاينة مباشرة في البطاقة' },

  // History Room Enhancements
  'history.nav.eras': { en: 'Community Eras', ar: 'عصور المجتمع' },
  'history.nav.sovereign': { en: 'Server Owner', ar: 'مالك السيرفر' },
  'history.nav.owners': { en: 'Custodians Chronicle', ar: 'سجل الملاك' },
  'history.nav.relics': { en: 'Archival Relics', ar: 'الآثار التاريخية' },
  'history.nav.creed': { en: 'Sanctuary Creed', ar: 'عهد السيرفر' },
  'history.search.placeholder': { en: 'Search eras, owners, nationalities, relics...', ar: 'ابحث في العصور، الملاك، الجنسيات، الآثار...' },
  'history.search.noResults': { en: 'No archival records found matching your query.', ar: 'لم يتم العثور على سجلات تاريخية تطابق بحثك.' },
  'history.stats.years': { en: 'Years of Legacy', ar: 'سنوات من العراقة' },
  'history.stats.owners': { en: 'Recorded Custodians', ar: 'السدنة والملاك الموثقون' },
  'history.stats.members': { en: 'Sanctuary Citizens', ar: 'أبناء السيرفر' },
  'history.stats.intact': { en: 'Archival Integrity', ar: 'سلامة التوثيق' },
  'history.eras.badge': { en: 'Recorded Epochs', ar: 'العصور الموثقة' },
  'history.eras.details': { en: 'Historical Highlights', ar: 'أهم محطات الحقبة' },
  'history.relics.title': { en: 'The Sacred Relics of CREATIVE NEXUS', ar: 'آثار ومقدسات مركز الابداع' },
  'history.relics.subtitle': { en: 'LEGENDARY TOTEMS & EMBLEMS', ar: 'رموز العهد والمجد' },
  'history.relics.desc': { en: 'Symbolic emblems forged across our server eras, commemorating valor, brotherhood, unyielding flame, and perpetual unity.', ar: 'رموز أثرية تشكلت عبر فصول السيرفر لتجسد قيم الإخاء والشغف والولاء الأبدي الذي جمع مجتمعنا.' },
  'history.relics.inspect': { en: 'Inspect Inscription', ar: 'تفحص النقش' },
  'history.creed.title': { en: 'The Archival Creed of the Realm', ar: 'ميثاق السيرفر الأبدي' },
  'history.creed.text': { en: '“In CREATIVE NEXUS, no word fades into oblivion. We preserve not merely dates and titles, but the living spirit of brotherhood, loyalty, and fierce ambition that forges an eternal sanctuary.”', ar: '«في مركز الابداع (CREATIVE NEXUS)، لا تسقط ذكرى في طي النسيان. نحن لا نوثق مجرد تواريخ وألقاب، بل نحفظ الروح الحية للإخاء والتفاني والولاء النبيل الذي بنى صرحاً أبدياً لا يزول.»' },
  'history.creed.copied': { en: 'Creed copied to clipboard!', ar: 'تم نسخ الميثاق إلى الحافظة!' },
  'history.creed.copy': { en: 'Copy Sanctuary Creed', ar: 'نسخ ميثاق السيرفر' },

  // Staff Management
  'staff.title': { en: 'Staff Management', ar: 'إدارة طاقم العمل' },
  'staff.desc': { en: 'Manage which Discord roles are recognized as staff members.', ar: 'إدارة رتب الديسكورد المعترف بها كأعضاء في طاقم الإدارة.' },
  'staff.roles.sectionTitle': { en: 'Staff Roles', ar: 'رتب الإدارة' },
  'staff.roles.sectionDesc': { en: 'Configure which Discord roles from CREATIVE NEXUS grant official staff status and moderation privileges.', ar: 'تحديد رتب ديسكورد من سيرفر مركز الابداع التي تمنح رتبة إداري وصلاحيات الإشراف.' },
  'staff.roles.configureBtn': { en: 'Configure Staff Roles', ar: 'تهيئة رتب الإدارة' },
  'staff.roles.activeCount': { en: 'Configured Roles', ar: 'الرتب المعتمدة' },
  'staff.roles.botStatusLive': { en: 'Discord Bot Live', ar: 'متصل ببوت الديسكورد' },
  'staff.roles.botStatusMock': { en: 'Bot Offline (Mock Preview)', ar: 'البوت غير متصل (عرض تجريبي)' },
  'staff.roles.sourceTruthNotice': { en: 'Role IDs are the source of truth.', ar: 'معرفات الرتب (Role IDs) هي المرجع الأساسي للصلاحيات.' },
  'staff.roles.ownerOnlyNotice': { en: 'Only the server owner can modify staff role configurations.', ar: 'مالك السيرفر فقط هو المخول بتعديل إعدادات رتب الإدارة.' },
  'staff.roles.emptyTitle': { en: 'No Staff Roles Configured', ar: 'لم يتم تحديد رتب إدارة بعد' },
  'staff.roles.emptyDesc': { en: 'Click "Configure Staff Roles" to select Discord roles recognized as staff members.', ar: 'انقر على "تهيئة رتب الإدارة" لاختيار رتب الديسكورد المعتمدة كطاقم عمل.' },
  'staff.roles.modalTitle': { en: 'Configure Staff Roles', ar: 'تهيئة رتب الإدارة' },
  'staff.roles.modalDesc': { en: 'Select which Discord roles from the connected CREATIVE NEXUS server should be considered staff/moderator roles.', ar: 'اختر رتب الديسكورد من سيرفر مركز الابداع المتصل التي يجب اعتبارها رتب إداريين ومشرفين.' },
  'staff.roles.searchPlaceholder': { en: 'Search roles by name or Role ID...', ar: 'البحث عن رتبة بالاسم أو المعرف (Role ID)...' },
  'staff.roles.selectedBadge': { en: 'Selected Roles', ar: 'الرتب المحددة' },
  'staff.roles.availableBadge': { en: 'Available Server Roles', ar: 'رتب السيرفر المتاحة' },
  'staff.roles.saveBtn': { en: 'Save Staff Roles', ar: 'حفظ رتب الإدارة' },
  'staff.roles.saving': { en: 'Saving Role IDs...', ar: 'جاري حفظ معرفات الرتب...' },
  'staff.roles.saveSuccess': { en: 'Staff roles updated successfully!', ar: 'تم تحديث رتب الإدارة بنجاح!' },
  'staff.roles.clearAll': { en: 'Clear Selection', ar: 'إلغاء التحديد' },
  'staff.roles.mockTag': { en: 'Mock Role', ar: 'رتبة تجريبية' },
  'staff.roles.serverRoleTag': { en: 'Discord Role', ar: 'رتبة ديسكورد' },
  'staff.total': { en: 'Total Staff', ar: 'إجمالي الإداريين' },
  'staff.active': { en: 'Active', ar: 'نشط' },
  'staff.suspended': { en: 'Suspended', ar: 'موقوف' },
  'staff.totalPoints': { en: 'Total Points', ar: 'إجمالي النقاط' },
  
  'staff.search': { en: 'Search by username, name, or ID...', ar: 'البحث بالاسم، المعرف، أو اليوزر...' },
  'staff.filter.all': { en: 'All Staff', ar: 'جميع الإداريين' },
  'staff.filter.status': { en: 'All Statuses', ar: 'جميع الحالات' },
  'staff.filter.rank': { en: 'All Ranks', ar: 'جميع الرتب' },
  
  'staff.add': { en: 'Add Staff', ar: 'إضافة إداري' },
  'staff.add.title': { en: 'Add New Staff Member', ar: 'إضافة عضو إدارة جديد' },
  'staff.add.cancel': { en: 'Cancel', ar: 'إلغاء' },
  'staff.add.submit': { en: 'Add Staff', ar: 'إضافة إداري' },

  'staff.profile.view': { en: 'View', ar: 'عرض' },
  'staff.profile.edit': { en: 'Edit Staff', ar: 'تعديل الإداري' },
  'staff.profile.rank': { en: 'Change Rank', ar: 'تغيير الرتبة' },
  'staff.profile.suspend': { en: 'Suspend Staff', ar: 'إيقاف الإداري' },
  'staff.profile.remove': { en: 'Remove Staff', ar: 'إزالة الإداري' },

  'staff.details.joined': { en: 'Joined', ar: 'تاريخ الانضمام' },
  'staff.details.activity': { en: 'Last Activity', ar: 'آخر نشاط' },
  'staff.details.points': { en: 'Points', ar: 'النقاط' },
  'staff.details.status': { en: 'Status', ar: 'الحالة' },
  
  'staff.section.points': { en: 'Points Summary', ar: 'ملخص النقاط' },
  'staff.section.history': { en: 'Staff History', ar: 'سجل الإداري' },
  'staff.btn.addPoints': { en: 'Add Points', ar: 'إضافة نقاط' },
  'staff.btn.removePoints': { en: 'Remove Points', ar: 'خصم نقاط' },

  // Points System
  'points.current': { en: 'Current Points', ar: 'النقاط الحالية' },
  'points.earned': { en: 'Earned', ar: 'المكتسبة' },
  'points.removed': { en: 'Removed', ar: 'المخصومة' },
  'points.transactions': { en: 'Transactions', ar: 'العمليات' },
  'points.history': { en: 'Point History', ar: 'سجل النقاط' },
  'points.reason': { en: 'Reason', ar: 'السبب' },
  'points.note': { en: 'Note', ar: 'ملاحظة' },
  'points.insufficient': { en: 'Insufficient points', ar: 'نقاط غير كافية' },
  'points.added': { en: 'Added by', ar: 'تمت الإضافة بواسطة' },
  'points.removedBy': { en: 'Removed by', ar: 'تم الخصم بواسطة' },

  // Authentication & Discord
  'auth.login': { en: 'Log in with Discord', ar: 'تسجيل الدخول عبر ديسكورد' },
  'auth.loginDesc': { en: 'Sign in with your Discord account to access your roles and dashboard.', ar: 'سجل دخولك بحساب ديسكورد للوصول إلى رتبك ولوحة الإدارة.' },
  'auth.logout': { en: 'Logout', ar: 'تسجيل الخروج' },
  'auth.profile': { en: 'Profile', ar: 'الملف الشخصي' },
  'auth.dashboard': { en: 'Dashboard', ar: 'لوحة التحكم' },
  'auth.required.title': { en: 'Discord Login Required', ar: 'تسجيل الدخول عبر ديسكورد مطلوب' },
  'auth.required.desc': { en: 'Please log in with your Discord account to access the private staff management dashboard.', ar: 'يرجى تسجيل الدخول باستخدام حساب ديسكورد للوصول إلى لوحة إدارة الطاقم الخاصة.' },
  'auth.connecting': { en: 'Connecting to Discord...', ar: 'جاري الاتصال بديسكورد...' },
  'auth.loggedAs': { en: 'Signed in as', ar: 'مسجل الدخول كـ' },

  // Server Dashboard (Bento Grid)
  'nav.dashboard': { en: 'Server Dashboard', ar: 'لوحة السيرفر' },
  'dashboard.badge': { en: 'MODERATOR & OWNER SUITE', ar: 'بوابة الملاك والمشرفين' },
  'dashboard.title': { en: 'Server Intelligence & Operations', ar: 'لوحة قيادة وإحصائيات السيرفر' },
  'dashboard.subtitle': { en: 'Live telemetry, real-time message volume, member influx, and operational command for Creatine Nexus.', ar: 'إحصائيات حية، رصد حجم الرسائل، حركة انضمام الأعضاء، وغرفة العمليات الرقابية لسيرفر مركز الإبداع.' },
  'dashboard.restricted': { en: 'Restricted Access', ar: 'منطقة مقيدة الصلاحية' },
  'dashboard.restrictedDesc': { en: 'This operations dashboard is strictly reserved for Server Owners and Moderators. Please log in with an authorized Discord staff account.', ar: 'هذه اللوحة مخصصة حصرياً لمالكي ومشرفي السيرفر (Owners & Moderators). يرجى تسجيل الدخول بحساب ديسكورد إداري معتمد.' },
  'dashboard.timeframe.today': { en: 'Today (24h)', ar: 'اليوم (24 س)' },
  'dashboard.timeframe.week': { en: 'This Week (7d)', ar: 'هذا الأسبوع (7 أ)' },
  'dashboard.timeframe.month': { en: 'This Month (30d)', ar: 'هذا الشهر (30 ي)' },
  'dashboard.messages.title': { en: 'Chat Volume & Velocity', ar: 'حجم وتدفق الرسائل' },
  'dashboard.messages.desc': { en: 'Real-time message traffic across all public and community channels.', ar: 'معدل إرسال الرسائل الحي عبر كافة قنوات السيرفر العامة والمجتمعية.' },
  'dashboard.messages.today': { en: 'Sent Today', ar: 'رسائل اليوم' },
  'dashboard.messages.week': { en: 'Sent This Week', ar: 'رسائل هذا الأسبوع' },
  'dashboard.messages.velocity': { en: 'Velocity', ar: 'سرعة الدردشة' },
  'dashboard.messages.perMin': { en: 'msgs / min', ar: 'رسالة / د' },
  'dashboard.messages.peak': { en: 'Peak Hours', ar: 'ساعات الذروة' },
  'dashboard.messages.channelBreakdown': { en: 'Channel Breakdown', ar: 'توزيع القنوات الأكثر تفاعلاً' },
  'dashboard.members.title': { en: 'Member Influx & Retention', ar: 'حركة انضمام الأعضاء والاحتفاظ' },
  'dashboard.members.desc': { en: 'New recruits joined vs departures with verified 7-day retention rates.', ar: 'الوافدون الجدد مقابل المغادرين مع نسبة بقاء واستقرار الأعضاء.' },
  'dashboard.members.joinedToday': { en: 'Joined Today', ar: 'انضموا اليوم' },
  'dashboard.members.joinedWeek': { en: 'Joined This Week', ar: 'انضموا هذا الأسبوع' },
  'dashboard.members.leftToday': { en: 'Left Today', ar: 'غادروا اليوم' },
  'dashboard.members.leftWeek': { en: 'Left This Week', ar: 'غادروا هذا الأسبوع' },
  'dashboard.members.netGrowth': { en: 'Net Growth', ar: 'صافي النمو' },
  'dashboard.members.retention': { en: '7-Day Retention Rate', ar: 'نسبة الاستقرار بعد 7 أيام' },
  'dashboard.members.topSources': { en: 'Top Invitation Sources', ar: 'أبرز مصادر الدعوات' },
  'dashboard.voice.title': { en: 'Voice Hub & Stream Monitor', ar: 'القنوات الصوتية وبث إدغار' },
  'dashboard.voice.active': { en: 'In Voice Channels', ar: 'في الغرف الصوتية الآن' },
  'dashboard.voice.channels': { en: 'Active Voice Rooms', ar: 'الغرف الصوتية النشطة' },
  'dashboard.voice.totalHours': { en: 'Voice Hours This Week', ar: 'ساعات التحدث الصوتية هذا الأسبوع' },
  'dashboard.stream.live': { en: 'EDGAR IS LIVE', ar: 'بث إدغار مباشر الآن' },
  'dashboard.stream.viewers': { en: 'Active Stream Viewers', ar: 'متابعو البث المباشر' },
  'dashboard.mod.title': { en: 'Moderation Shield', ar: 'درع الرقابة التلقائية' },
  'dashboard.mod.autoMod': { en: 'AutoMod Intercepts', ar: 'روابط محظورة تلقائياً' },
  'dashboard.mod.spamBlocked': { en: 'Spam Filtered', ar: 'رسائل سبام محجوبة' },
  'dashboard.mod.responseTime': { en: 'Avg Response Time', ar: 'متوسط سرعة استجابة الإدارة' },
  'dashboard.boost.title': { en: 'Server Boost & Tier', ar: 'مستوى تعزيز السيرفر (Boost)' },
  'dashboard.boost.level': { en: 'Level 3 Unlocked', ar: 'المستوى 3 مفعل' },
  'dashboard.boost.count': { en: 'Server Boosts', ar: 'عدد البوستات' },
  'dashboard.staff.title': { en: 'Active Staff on Duty', ar: 'الإداريون المناوبون' },
  'dashboard.gateway.title': { en: 'Infrastructure & Gateway', ar: 'استقرار البوابة والشبكة' },
  'dashboard.gateway.ping': { en: 'Gateway Ping', ar: 'سرعة استجابة البوابة' },
  'dashboard.gateway.uptime': { en: 'Uptime', ar: 'نسبة الاستقرار' },
  'dashboard.gateway.filter': { en: 'Media Filter', ar: 'فلتر الوسائط المتعددة' },
  'dashboard.events.title': { en: 'Live Event Stream', ar: 'سجل العمليات المباشرة' },
  'dashboard.refresh': { en: 'Live Refresh', ar: 'تحديث فوري' },
  'dashboard.switchRole': { en: 'Quick Switch Demo Role', ar: 'تبديل رتبة التجربة' },

  // Notification Center
  'notifications.title': { en: 'Notification Center', ar: 'مركز الإشعارات' },
  'notifications.subtitle': { en: 'Live chronological stream of server events, promotions, point adjustments, and medals', ar: 'سجل زمني حي لفعاليات السيرفر، الترقيات، تعديلات النقاط، والميداليات الشرفية' },
  'notifications.unread': { en: 'Unread', ar: 'غير مقروء' },
  'notifications.all': { en: 'All Notifications', ar: 'جميع الإشعارات' },
  'notifications.markAllRead': { en: 'Mark all as read', ar: 'تحديد الكل كمقروء' },
  'notifications.markRead': { en: 'Mark as read', ar: 'تحديد كمقروء' },
  'notifications.empty': { en: 'No notifications to display', ar: 'لا توجد إشعارات لعرضها' },
  'notifications.emptyDesc': { en: 'Your archive stream is clear. New events and status alerts will appear here.', ar: 'سجلك نظيف ومحدث. ستظهر التنبيهات والأحداث الجديدة هنا فور حدوثها.' },
  'notifications.emptyUnread': { en: 'You are all caught up!', ar: 'لقد قرأت جميع الإشعارات!' },
  'notifications.viewAll': { en: 'View All Notifications', ar: 'عرض جميع الإشعارات' },
  'notifications.recent': { en: 'Recent Notifications', ar: 'أحدث الإشعارات' },
  'notifications.filterAll': { en: 'All', ar: 'الكل' },
  'notifications.filterUnread': { en: 'Unread Only', ar: 'غير المقروء فقط' },
  'notifications.filterPoints': { en: 'Points', ar: 'النقاط' },
  'notifications.filterRank': { en: 'Rank Applications', ar: 'طلبات الترقية' },
  'notifications.filterAchievement': { en: 'Achievements', ar: 'الإنجازات' },
  'notifications.filterStaff': { en: 'Staff Record', ar: 'سجل الإدارة' },
  'notifications.filterAnnouncement': { en: 'Announcements', ar: 'الإعلانات' },
  'notifications.openTarget': { en: 'Navigate to target', ar: 'الانتقال إلى الصفحة المعنية' },
  'notifications.delete': { en: 'Delete', ar: 'حذف' },
  'notifications.swipeHint': { en: 'Swipe left to mark read or delete', ar: 'اسحب لليسار للتحديد كمقروء أو الحذف' },
  'notifications.justNow': { en: 'Just now', ar: 'الآن' },
  'notifications.minsAgo': { en: 'm ago', ar: 'د مضت' },
  'notifications.hoursAgo': { en: 'h ago', ar: 'س مضت' },
  'notifications.daysAgo': { en: 'd ago', ar: 'يوم مضى' }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('ar');

  useEffect(() => {
    const saved = localStorage.getItem('language') as Language;
    if (saved && (saved === 'en' || saved === 'ar')) {
      setLanguageState(saved);
    } else {
      setLanguageState('ar');
    }
  }, []);

  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  const setLanguage = (lang: Language) => {
    localStorage.setItem('language', lang);
    setLanguageState(lang);
  };

  const t = (key: string) => {
    return translations[key]?.[language] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
