import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  collection, 
  doc, 
  onSnapshot, 
  setDoc, 
  updateDoc, 
  serverTimestamp,
  getDocs 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { RankApplication, ApplicationStatus, getTierForPoints, RANK_TIERS } from '../types/rankMap';
import { StaffMember } from '../types/staff';

interface RankApplicationContextType {
  applications: RankApplication[];
  loading: boolean;
  error: string | null;
  getStatusForMember: (discordId: string, member?: StaffMember, targetTierId?: string) => ApplicationStatus;
  getApplicationForMember: (discordId: string, targetTierId?: string) => RankApplication | undefined;
  applyForRank: (member: StaffMember, targetTierId?: string) => Promise<{ success: boolean; message?: string }>;
  approveApplication: (appId: string, reviewerName: string, note?: string) => Promise<{ success: boolean; message?: string }>;
  rejectApplication: (appId: string, reviewerName: string, note?: string) => Promise<{ success: boolean; message?: string }>;
  quickApproveMember: (member: StaffMember, reviewerName: string, targetTierId?: string) => Promise<{ success: boolean; message?: string }>;
}

const RankApplicationContext = createContext<RankApplicationContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'creatine_nexus_rank_apps_v1';

export const RankApplicationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [applications, setApplications] = useState<RankApplication[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Sync with Firestore in real time
  useEffect(() => {
    let unsubscribe: (() => void) | null = null;

    try {
      const rankAppsRef = collection(db, 'rank_applications');
      unsubscribe = onSnapshot(
        rankAppsRef,
        (snapshot) => {
          const list: RankApplication[] = [];
          snapshot.forEach((d) => {
            const data = d.data();
            const currentPts = typeof data.currentPoints === 'number' ? data.currentPoints : 0;
            list.push({
              id: d.id,
              staffId: data.staffId || d.id,
              discordId: data.discordId || '',
              displayName: data.displayName || 'Staff Member',
              avatarUrl: data.avatarUrl || '',
              currentPoints: currentPts,
              currentTierId: data.currentTierId || 'cn_team',
              targetTierId: data.targetTierId || data.currentTierId || getTierForPoints(currentPts).id,
              status: (data.status as ApplicationStatus) || 'NOT_APPLIED',
              appliedAt: data.appliedAt || null,
              reviewedAt: data.reviewedAt || null,
              reviewedBy: data.reviewedBy || null,
              reviewNote: data.reviewNote || null,
              updatedAt: data.updatedAt || new Date().toISOString()
            });
          });

          setApplications(list);
          setLoading(false);
          try {
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(list));
          } catch (e) {
            // Storage quota warning ignored
          }
        },
        (err) => {
          console.warn('Notice: Firestore rank_applications snapshot fallback:', err.message);
          // Fall back to local storage cache
          try {
            const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
            if (saved) {
              setApplications(JSON.parse(saved));
            }
          } catch {}
          setLoading(false);
        }
      );
    } catch (initErr: any) {
      console.warn('Notice: Firebase initialization fallback for rank apps:', initErr?.message);
      setLoading(false);
    }

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  const getApplicationForMember = useCallback((discordId: string, targetTierId?: string): RankApplication | undefined => {
    if (!discordId) return undefined;
    if (targetTierId) {
      const matches = applications
        .filter(app => (app.discordId === discordId || app.staffId === discordId) && app.targetTierId === targetTierId)
        .sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
      return matches[0];
    }
    const memberApps = applications
      .filter(app => app.discordId === discordId || app.staffId === discordId)
      .sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
    return memberApps[0];
  }, [applications]);

  const getStatusForMember = useCallback((
    discordId: string, 
    member?: StaffMember, 
    targetTierId?: string
  ): ApplicationStatus => {
    if (!discordId) return 'NOT_APPLIED';

    // The rank tier to evaluate: explicit targetTierId OR derived from member's current points
    const tierToCheck = targetTierId || (member ? getTierForPoints(member.points || 0).id : undefined);

    if (tierToCheck) {
      const appForTier = applications.find(app => 
        (app.discordId === discordId || app.staffId === discordId) && 
        app.targetTierId === tierToCheck
      );

      // If an application exists specifically for this target rank, return its status
      if (appForTier) {
        return appForTier.status;
      }

      // CRITICAL RULE: If no application exists for this target rank, return 'NOT_APPLIED'!
      // Past approvals for previous ranks remain preserved in history,
      // but do not carry over to the new rank.
      return 'NOT_APPLIED';
    }

    // Fallback if no tier could be determined: check most recent application
    const memberApps = applications
      .filter(app => app.discordId === discordId || app.staffId === discordId)
      .sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));

    if (memberApps.length > 0) {
      return memberApps[0].status;
    }

    return 'NOT_APPLIED';
  }, [applications]);

  const applyForRank = useCallback(async (
    member: StaffMember, 
    targetTierId?: string
  ): Promise<{ success: boolean; message?: string }> => {
    try {
      const eligibleTier = getTierForPoints(member.points || 0);
      const targetId = targetTierId || eligibleTier.id;
      // Track application per target rank so previous approved ranks are kept permanently
      const appId = `app_${member.discordId}_${targetId}`;
      const now = new Date().toISOString();

      const newApp: RankApplication = {
        id: appId,
        staffId: String(member.id || member.discordId),
        discordId: member.discordId,
        displayName: member.displayName || member.username,
        avatarUrl: member.avatarUrl || '',
        currentPoints: member.points || 0,
        currentTierId: eligibleTier.id,
        targetTierId: targetId,
        status: 'PENDING',
        appliedAt: now,
        reviewedAt: null,
        reviewedBy: null,
        reviewNote: null,
        updatedAt: now
      };

      // Optimistic update - update only the app for this specific target rank, keeping all other ranks
      setApplications(prev => {
        const filtered = prev.filter(a => a.id !== appId && !(a.discordId === member.discordId && a.targetTierId === targetId));
        const updated = [...filtered, newApp];
        try { localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated)); } catch {}
        return updated;
      });

      // Write to Firestore
      const docRef = doc(db, 'rank_applications', appId);
      await setDoc(docRef, newApp, { merge: true });

      return { success: true, message: 'Application submitted successfully for Owner review.' };
    } catch (err: any) {
      console.error('Error submitting rank application:', err);
      return { success: false, message: err.message || 'Failed to submit application' };
    }
  }, []);

  const approveApplication = useCallback(async (
    appId: string, 
    reviewerName: string, 
    note?: string
  ): Promise<{ success: boolean; message?: string }> => {
    try {
      const now = new Date().toISOString();
      let updatedApp: RankApplication | null = null;

      setApplications(prev => {
        const next = prev.map(app => {
          if (app.id === appId) {
            updatedApp = {
              ...app,
              status: 'APPROVED' as ApplicationStatus,
              reviewedAt: now,
              reviewedBy: reviewerName,
              reviewNote: note || null,
              updatedAt: now
            };
            return updatedApp;
          }
          return app;
        });
        try { localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(next)); } catch {}
        return next;
      });

      // Write to Firestore
      const docRef = doc(db, 'rank_applications', appId);
      await updateDoc(docRef, {
        status: 'APPROVED',
        reviewedAt: now,
        reviewedBy: reviewerName,
        reviewNote: note || null,
        updatedAt: now
      });

      return { success: true, message: 'Application approved.' };
    } catch (err: any) {
      console.error('Error approving application:', err);
      return { success: false, message: err.message || 'Failed to approve application' };
    }
  }, []);

  const rejectApplication = useCallback(async (
    appId: string, 
    reviewerName: string, 
    note?: string
  ): Promise<{ success: boolean; message?: string }> => {
    try {
      const now = new Date().toISOString();

      setApplications(prev => {
        const next = prev.map(app => {
          if (app.id === appId) {
            return {
              ...app,
              status: 'NOT_APPLIED' as ApplicationStatus,
              reviewedAt: now,
              reviewedBy: reviewerName,
              reviewNote: note || null,
              updatedAt: now
            };
          }
          return app;
        });
        try { localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(next)); } catch {}
        return next;
      });

      // Write to Firestore
      const docRef = doc(db, 'rank_applications', appId);
      await updateDoc(docRef, {
        status: 'NOT_APPLIED',
        reviewedAt: now,
        reviewedBy: reviewerName,
        reviewNote: note || null,
        updatedAt: now
      });

      return { success: true, message: 'Application rejected.' };
    } catch (err: any) {
      console.error('Error rejecting application:', err);
      return { success: false, message: err.message || 'Failed to reject application' };
    }
  }, []);

  const quickApproveMember = useCallback(async (
    member: StaffMember, 
    reviewerName: string,
    targetTierId?: string
  ): Promise<{ success: boolean; message?: string }> => {
    try {
      const eligibleTier = getTierForPoints(member.points || 0);
      const targetId = targetTierId || eligibleTier.id;
      const targetTierObj = RANK_TIERS.find(t => t.id === targetId) || eligibleTier;
      const appId = `app_${member.discordId}_${targetId}`;
      const now = new Date().toISOString();

      const approvedApp: RankApplication = {
        id: appId,
        staffId: String(member.id || member.discordId),
        discordId: member.discordId,
        displayName: member.displayName || member.username,
        avatarUrl: member.avatarUrl || '',
        currentPoints: member.points || 0,
        currentTierId: eligibleTier.id,
        targetTierId: targetId,
        status: 'APPROVED',
        appliedAt: now,
        reviewedAt: now,
        reviewedBy: reviewerName,
        reviewNote: 'Directly approved by Owner',
        updatedAt: now
      };

      setApplications(prev => {
        const filtered = prev.filter(a => a.id !== appId && !(a.discordId === member.discordId && a.targetTierId === targetId));
        const updated = [...filtered, approvedApp];
        try { localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated)); } catch {}
        return updated;
      });

      const docRef = doc(db, 'rank_applications', appId);
      await setDoc(docRef, approvedApp, { merge: true });

      return { success: true, message: `Rank ${targetTierObj.name} approved for ${member.displayName || member.username}.` };
    } catch (err: any) {
      console.error('Error in quick approve:', err);
      return { success: false, message: err.message || 'Failed to approve rank' };
    }
  }, []);

  return (
    <RankApplicationContext.Provider
      value={{
        applications,
        loading,
        error,
        getStatusForMember,
        getApplicationForMember,
        applyForRank,
        approveApplication,
        rejectApplication,
        quickApproveMember
      }}
    >
      {children}
    </RankApplicationContext.Provider>
  );
};

export const useRankApplications = (): RankApplicationContextType => {
  const context = useContext(RankApplicationContext);
  if (!context) {
    throw new Error('useRankApplications must be used within a RankApplicationProvider');
  }
  return context;
};
