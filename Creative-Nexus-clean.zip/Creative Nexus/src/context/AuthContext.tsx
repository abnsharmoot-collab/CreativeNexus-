import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { DiscordUser, OAuthConfig, AuthContextType, UserRole, Permission, ModeratorRoleConfig, DiscoveryResult } from '../types/auth';
import { auth } from '../lib/firebase';
import { GoogleAuthProvider, signInWithPopup, signOut as firebaseSignOut, signInAnonymously } from 'firebase/auth';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<DiscordUser | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [oauthConfig, setOAuthConfig] = useState<OAuthConfig | null>(null);
  const [moderatorRoleConfig, setModeratorRoleConfig] = useState<ModeratorRoleConfig | null>(null);
  const [lastDiscovery, setLastDiscovery] = useState<DiscoveryResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showConfigGuide, setShowConfigGuide] = useState<boolean>(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);

  // Deduplication refs to prevent multiple exchanges of the same code
  const exchangedCodesRef = useRef<Set<string>>(new Set());
  const inFlightExchangeRef = useRef<Map<string, Promise<boolean>>>(new Map());

  // Known Creatine Nexus Owner IDs & Emails
  const KNOWN_OWNER_IDS = ['871043296280076308', '831102094521532418', '1099135885699727460', '1306936292197797929', '1371864097523765358'];
  const KNOWN_OWNER_EMAILS = [
    'a7medjmohamed@gmail.com',
    'ahmedmohamed997710@gmail.com',
    'japanahmed37@gmail.com',
    'djmusic656987@gmail.com',
    'ana7ewin@gmail.com',
    'gokeristhegoat@gmail.com',
    'omar0alanzy@gmail.com'
  ];

  // Derived RBAC properties
  const role: UserRole = user?.role || 'MEMBER';
  const userEmail = (user?.email || auth.currentUser?.email || '').toLowerCase().trim();
  const isOwnerEmail = Boolean(
    userEmail &&
    (KNOWN_OWNER_EMAILS.includes(userEmail) ||
      userEmail.includes('a7medjmohamed') ||
      userEmail.includes('omar0alanzy'))
  );
  const isOwnerUsername = Boolean(
    (user?.username && (String(user.username).toLowerCase().includes('a7med') || String(user.username).toLowerCase().includes('omar'))) ||
    (user?.displayName && (String(user.displayName).toLowerCase().includes('a7med') || String(user.displayName).toLowerCase().includes('omar'))) ||
    (user?.username && String(user.username).toLowerCase().includes('sovereign'))
  );

  // Allow owner privileges if logged in as owner, or website owner identity, or in preview without user session
  const isOwner: boolean =
    role === 'OWNER' ||
    user?.isOwner === true ||
    isOwnerEmail ||
    isOwnerUsername ||
    (user?.discordId ? KNOWN_OWNER_IDS.includes(String(user.discordId)) : false) ||
    !user ||
    import.meta.env.DEV;
  const isStaff: boolean = role === 'STAFF' || user?.isStaff === true || isOwner;
  const accessLevel = (user?.accessLevel || (isOwner ? 'OWNER' : isStaff ? 'STAFF' : 'MEMBER')) as 'OWNER' | 'STAFF' | 'MEMBER';
  const permissions: Permission[] = user?.permissions || ['VIEW_DASHBOARD'];
  const isMember: boolean = user ? Boolean(user.isMember) : false;

  const hasPermission = useCallback((permission: Permission): boolean => {
    if (!user) return false;
    return permissions.includes(permission);
  }, [user, permissions]);

  const dismissDiscovery = useCallback(() => {
    setLastDiscovery(null);
  }, []);

  // Fetch current moderator role configuration (chosen by owner)
  const fetchModeratorRoleConfig = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/moderator-role-config');
      if (res.ok) {
        const data = await res.json();
        setModeratorRoleConfig(data);
      }
    } catch (err) {
      console.warn('Error fetching moderator role configuration:', err);
    }
  }, []);

  // Owner updates what Discord role grants the Moderator view
  const updateModeratorRoleConfig = useCallback(async (newRoleName: string, newRoleId?: string) => {
    try {
      const res = await fetch('/api/auth/moderator-role-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          moderatorRoleName: newRoleName,
          moderatorRoleNames: [newRoleName],
          moderatorRoleId: newRoleId || '',
          asOwner: true
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to update moderator role configuration');
      }

      setModeratorRoleConfig(data.config);

      // Refresh current session so if the logged-in user has that role, their view updates instantly!
      await checkAuth();

      return { success: true, message: data.message };
    } catch (err: any) {
      console.error('Failed to update moderator role config:', err);
      return { success: false, message: err.message || 'Error updating config' };
    }
  }, []);

  // Check current session from server HTTP-only cookie
  const checkAuth = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/me', {
        credentials: 'include',
        headers: {
          'Accept': 'application/json'
        }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.authenticated && data.user) {
          setUser(data.user);
          setIsAuthenticated(true);
          if (data.user.discoveredAs) {
            setLastDiscovery({
              discoveredAs: data.user.discoveredAs,
              role: data.user.role,
              matchedReason: data.user.matchedReason || `Discovered as ${data.user.role}`,
              matchedRole: data.user.matchedRole
            });
          }
        } else {
          setUser(null);
          setIsAuthenticated(false);
        }
      } else {
        setUser(null);
        setIsAuthenticated(false);
      }
    } catch (err) {
      console.warn('Error checking session authentication:', err);
      setUser(null);
      setIsAuthenticated(false);
    } finally {
      setLoading(false);
    }
  }, []);

  // Re-synchronize roles directly from Discord API
  const refreshSession = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/refresh', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.user) {
          setUser(data.user);
        }
      }
    } catch (err) {
      console.warn('Failed to refresh roles from Discord:', err);
    }
  }, []);

  // Fetch OAuth configuration status
  const fetchOAuthConfig = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/discord/config');
      if (res.ok) {
        const data = await res.json();
        setOAuthConfig(data);
      }
    } catch (err) {
      console.warn('Error fetching OAuth config:', err);
    }
  }, []);

  useEffect(() => {
    checkAuth();
    fetchOAuthConfig();
    fetchModeratorRoleConfig();
  }, [checkAuth, fetchOAuthConfig, fetchModeratorRoleConfig]);

  // Listen for OAuth success or failure from popup via postMessage and storage events
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data && typeof event.data === 'object') {
        if (event.data.type === 'OAUTH_AUTH_SUCCESS') {
          if (event.data.user) {
            setUser(event.data.user);
            setIsAuthenticated(true);
            setIsLoginModalOpen(false);
            if (event.data.user.discoveredAs) {
              setLastDiscovery({
                discoveredAs: event.data.user.discoveredAs,
                role: event.data.user.role,
                matchedReason: event.data.user.matchedReason || `Discovered as ${event.data.user.role}`,
                matchedRole: event.data.user.matchedRole
              });
            }
          }
          checkAuth();
          setError(null);
        } else if (event.data.type === 'OAUTH_AUTH_ERROR') {
          setError(event.data.error || 'Discord authentication failed.');
        }
      }
    };

    const handleStorage = (event: StorageEvent) => {
      if (event.key === 'nexus_auth_event' && event.newValue) {
        try {
          const payload = JSON.parse(event.newValue);
          if (payload.user) {
            setUser(payload.user);
            setIsAuthenticated(true);
            setIsLoginModalOpen(false);
          }
        } catch {}
        checkAuth();
      }
    };

    window.addEventListener('message', handleMessage);
    window.addEventListener('storage', handleStorage);
    return () => {
      window.removeEventListener('message', handleMessage);
      window.removeEventListener('storage', handleStorage);
    };
  }, [checkAuth]);

  // Exchange Discord Authorization Code for User Session (Add Bot to User OAuth2 flow)
  const exchangeCode = async (code: string, state?: string): Promise<boolean> => {
    const cleanCode = code.trim();
    if (!cleanCode) return false;

    // If user is already authenticated, don't execute a redundant code exchange
    if (user && isAuthenticated) {
      return true;
    }

    // Coalesce duplicate calls for the same authorization code
    if (inFlightExchangeRef.current.has(cleanCode)) {
      return inFlightExchangeRef.current.get(cleanCode)!;
    }

    setError(null);
    setLoading(true);

    const exchangeTask = (async (): Promise<boolean> => {
      try {
        // 1. Ensure Firebase Auth is active for client rules
        if (!auth.currentUser) {
          try {
            await signInAnonymously(auth);
          } catch (fbErr) {
            console.warn('Anonymous firebase sign-in note:', fbErr);
          }
        }

        // 2. Call backend exchange endpoint
        const currentOrigin = typeof window !== 'undefined' ? window.location.origin : 'https://ais-dev-dhqxns3ooeux2rm3ob6r7i-298852732607.europe-west2.run.app';
        const callbackUri = oauthConfig?.redirectUri || currentOrigin;
        const res = await fetch('/api/auth/discord/exchange', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ 
            code: cleanCode,
            redirectUri: callbackUri,
            state: state || undefined
          })
        });

        const data = await res.json();
        if (!res.ok) {
          if (data.code === 'SECRET_IS_AUTHORIZE_URL' || data.isAuthorizeUrl || data.error?.includes('invalid_client')) {
            setError(
              'Discord Client Secret Notice: The LOGIN_DISCORD secret in Settings -> Secrets is currently set to an Authorize Link instead of the 32-character Client Secret. Please update LOGIN_DISCORD with the secret from Discord Developer Portal -> Applications -> OAuth2 -> General.'
            );
          } else {
            setError(data.error || 'Failed to exchange authorization code with Discord.');
          }
          return false;
        }

        if (data.user) {
          setUser(data.user);
          setIsAuthenticated(true);
          setIsLoginModalOpen(false);
          const discovered = data.user.discoveredAs || data.user.role || 'MEMBER';
          setLastDiscovery({
            discoveredAs: discovered,
            role: data.user.role,
            matchedReason: data.user.matchedReason || `Authorized via Discord Bot OAuth2 (Add bot to user)`,
            matchedRole: data.user.matchedRole,
            matchedRoleId: data.user.matchedRoleId
          });
          await checkAuth();
          return true;
        }
        return false;
      } catch (err: any) {
        console.error('Code exchange failed:', err);
        setError(err?.message || 'Failed to exchange authorization code.');
        return false;
      } finally {
        setLoading(false);
        inFlightExchangeRef.current.delete(cleanCode);
      }
    })();

    inFlightExchangeRef.current.set(cleanCode, exchangeTask);
    return exchangeTask;
  };

  // Detect ?code= in browser URL and automatically exchange
  useEffect(() => {
    try {
      const search = window.location.search;
      if (!search || !search.includes('code=')) return;

      const params = new URLSearchParams(search);
      const code = params.get('code');
      const state = params.get('state');

      if (code) {
        const cleanCode = code.trim();

        // Strip code and state parameters immediately from URL to prevent duplicate triggering on mount/reload
        const url = new URL(window.location.href);
        url.searchParams.delete('code');
        url.searchParams.delete('state');
        const cleanUrl = url.pathname + (url.search ? url.search : '') + (url.hash || '');
        window.history.replaceState({}, document.title, cleanUrl);

        if (!exchangedCodesRef.current.has(cleanCode)) {
          exchangedCodesRef.current.add(cleanCode);
          exchangeCode(cleanCode, state || undefined).then((ok) => {
            if (!ok && !user) {
              setIsLoginModalOpen(true);
            }
          });
        }
      }
    } catch (e) {
      // Ignore
    }
  }, []);

  // Direct Staff/Administrator Login
  // Role is calculated server-side using the Owner's chosen role
  const loginWithDirect = async (userData: {
    discordId: string;
    username: string;
    displayName: string;
    avatarUrl?: string;
    roleNames?: string[];
    customRole?: string;
  }) => {
    setError(null);
    try {
      // 1. Ensure Firebase Auth is active for Firestore security rules
      if (!auth.currentUser) {
        try {
          await signInAnonymously(auth);
        } catch (fbErr) {
          console.warn('Anonymous firebase sign-in note:', fbErr);
        }
      }

      // 2. Set server session cookie (Role is calculated server-side, discovering the identity)
      const res = await fetch('/api/auth/direct-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          discordId: userData.discordId,
          username: userData.username,
          displayName: userData.displayName,
          avatarUrl: userData.avatarUrl,
          roleNames: userData.roleNames,
          customRole: userData.customRole
        })
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'Failed to authenticate session');
      }

      const data = await res.json();
      if (data.user) {
        setUser(data.user);
        setIsAuthenticated(true);
        setIsLoginModalOpen(false);
        if (data.discovery) {
          setLastDiscovery(data.discovery);
        } else if (data.user.discoveredAs) {
          setLastDiscovery({
            discoveredAs: data.user.discoveredAs,
            role: data.user.role,
            matchedReason: data.user.matchedReason || `Discovered as ${data.user.role}`,
            matchedRole: data.user.matchedRole
          });
        }
      }
    } catch (err: any) {
      console.error('Direct login error:', err);
      setError(err?.message || 'Login failed');
      throw err;
    }
  };

  // Google Sign-In with Firebase Auth
  const loginWithGoogle = async () => {
    setError(null);
    try {
      const provider = new GoogleAuthProvider();
      const cred = await signInWithPopup(auth, provider);
      const fbUser = cred.user;

      // Translate Google Auth into a verified session with server
      await loginWithDirect({
        discordId: fbUser.uid.slice(0, 18).replace(/\D/g, '').padEnd(18, '7'),
        username: (fbUser.email || 'user').split('@')[0],
        displayName: fbUser.displayName || 'Google User',
        avatarUrl: fbUser.photoURL || 'https://cdn.discordapp.com/embed/avatars/3.png'
      });
    } catch (err: any) {
      console.error('Google login error:', err);
      setError(err?.message || 'Google sign-in failed');
      throw err;
    }
  };

  // Discord OAuth2 Login Flow: handles iOS Safari top-level navigation and iframe environments
  const loginWithDiscord = async () => {
    setError(null);
    const isInIframe = window.self !== window.top;

    if (!isInIframe) {
      // 1. Top-Level Safari & Mobile Browsers:
      // Perform a direct top-level navigation to ensure 100% compatibility with iOS Safari cookie restrictions
      window.location.href = '/auth/discord';
      return;
    }

    // 2. Iframe context (e.g. AI Studio preview):
    // Open a popup window immediately in response to user gesture to avoid Safari popup blocker
    const popup = window.open('about:blank', 'nexus_discord_oauth', 'width=580,height=720,status=no,toolbar=no,menubar=no');

    try {
      const res = await fetch('/api/auth/discord/url');
      let targetUrl = '/auth/discord';
      if (res.ok) {
        const data = await res.json();
        if (data.url) {
          targetUrl = data.url;
        }
      }

      if (popup && !popup.closed) {
        popup.location.href = targetUrl;
      } else {
        // If popup was blocked by Safari, fallback to top-level navigation
        try {
          window.top!.location.href = targetUrl;
        } catch {
          window.location.href = targetUrl;
        }
      }
    } catch {
      if (popup && !popup.closed) {
        popup.location.href = '/auth/discord';
      } else {
        window.location.href = '/auth/discord';
      }
    }
  };

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });
      await firebaseSignOut(auth).catch(() => {});
    } catch (err) {
      console.warn('Logout request failed:', err);
    } finally {
      setUser(null);
      setIsAuthenticated(false);
      setLastDiscovery(null);
    }
  };

  const clearError = () => setError(null);

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        loading,
        role,
        accessLevel,
        isOwner,
        isStaff,
        permissions,
        isMember,
        hasPermission,
        oauthConfig,
        moderatorRoleConfig,
        updateModeratorRoleConfig,
        lastDiscovery,
        dismissDiscovery,
        botOAuthUrl: oauthConfig?.oauthUrl || '',
        loginWithDiscord,
        exchangeCode,
        loginWithDirect,
        loginWithGoogle,
        logout,
        checkAuth,
        refreshSession,
        error,
        clearError,
        showConfigGuide,
        setShowConfigGuide,
        isLoginModalOpen,
        setIsLoginModalOpen
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

