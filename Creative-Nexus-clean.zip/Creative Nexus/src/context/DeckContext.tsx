import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { PlayerDeck, MAX_DECK_CARDS, calculateDeckStats } from '../types/decks';
import { CollectibleCardData } from '../types/cards';
import { useAuth } from './AuthContext';
import { useCards } from './CardContext';

interface DeckContextType {
  decks: PlayerDeck[];
  activeDeck: PlayerDeck | null;
  activeDeckCards: CollectibleCardData[];
  loading: boolean;
  error: string | null;
  saveDeck: (deckData: {
    id?: string;
    name: string;
    banner?: string;
    cardIds: string[];
    itemIds?: string[];
    isActive?: boolean;
  }) => Promise<{ success: boolean; deck?: PlayerDeck; error?: string }>;
  setActiveDeck: (deckId: string) => Promise<{ success: boolean; error?: string }>;
  deleteDeck: (deckId: string) => Promise<{ success: boolean; error?: string }>;
  refreshDecks: () => Promise<void>;
  getDeckCards: (deck: PlayerDeck) => CollectibleCardData[];
}

const DeckContext = createContext<DeckContextType | undefined>(undefined);

export const DeckProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, user } = useAuth();
  const { catalog, profile, refreshProfile } = useCards();

  const [decks, setDecks] = useState<PlayerDeck[]>(() => {
    try {
      const saved = localStorage.getItem('nexus_player_decks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Helper to resolve card instances from card IDs
  const getDeckCards = useCallback(
    (deck: PlayerDeck): CollectibleCardData[] => {
      if (!deck || !Array.isArray(deck.cardIds)) return [];
      return deck.cardIds
        .map(id => catalog.find(c => c.id === id))
        .filter((c): c is CollectibleCardData => Boolean(c));
    },
    [catalog]
  );

  // Active Deck memo
  const activeDeck = useMemo(() => {
    return decks.find(d => d.isActive) || decks[0] || null;
  }, [decks]);

  const activeDeckCards = useMemo(() => {
    if (!activeDeck) return [];
    return getDeckCards(activeDeck);
  }, [activeDeck, getDeckCards]);

  // Fetch decks from backend API
  const refreshDecks = useCallback(async () => {
    if (!isAuthenticated) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const res = await fetch('/api/decks', { credentials: 'include' });
      const data = await res.json();

      if (data.success && Array.isArray(data.decks)) {
        setDecks(data.decks);
        try {
          localStorage.setItem('nexus_player_decks', JSON.stringify(data.decks));
        } catch {}
      }
    } catch (err: any) {
      console.warn('DeckContext: Error fetching decks:', err?.message);
      setError(err?.message || 'Failed to load decks');
    } finally {
      setLoading(false);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    refreshDecks();
  }, [refreshDecks]);

  // Save / Update a deck
  const saveDeck = async (deckData: {
    id?: string;
    name: string;
    banner?: string;
    cardIds: string[];
    itemIds?: string[];
    isActive?: boolean;
  }): Promise<{ success: boolean; deck?: PlayerDeck; error?: string }> => {
    try {
      const res = await fetch('/api/decks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(deckData)
      });
      const data = await res.json();

      if (data.success && data.deck) {
        setDecks(prev => {
          let updated: PlayerDeck[];
          const isAct = Boolean(deckData.isActive);
          const existingIdx = prev.findIndex(d => d.id === data.deck.id);

          if (isAct) {
            prev = prev.map(d => ({ ...d, isActive: false }));
          }

          if (existingIdx >= 0) {
            updated = [...prev];
            updated[existingIdx] = data.deck;
          } else {
            updated = [data.deck, ...prev];
          }

          try {
            localStorage.setItem('nexus_player_decks', JSON.stringify(updated));
          } catch {}
          return updated;
        });

        await refreshProfile();
        return { success: true, deck: data.deck };
      }

      return { success: false, error: data.error || 'Failed to save deck' };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Network error saving deck' };
    }
  };

  // Set active deck
  const setActiveDeck = async (deckId: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch(`/api/decks/${deckId}/set-active`, {
        method: 'POST',
        credentials: 'include'
      });
      const data = await res.json();

      if (data.success) {
        setDecks(prev => {
          const updated = prev.map(d => ({
            ...d,
            isActive: d.id === deckId
          }));
          try {
            localStorage.setItem('nexus_player_decks', JSON.stringify(updated));
          } catch {}
          return updated;
        });
        return { success: true };
      }

      return { success: false, error: data.error || 'Failed to set active deck' };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Network error setting active deck' };
    }
  };

  // Delete a deck
  const deleteDeck = async (deckId: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch(`/api/decks/${deckId}`, {
        method: 'DELETE',
        credentials: 'include'
      });
      const data = await res.json();

      if (data.success) {
        setDecks(prev => {
          const filtered = prev.filter(d => d.id !== deckId);
          if (filtered.length > 0 && !filtered.some(d => d.isActive)) {
            filtered[0].isActive = true;
          }
          try {
            localStorage.setItem('nexus_player_decks', JSON.stringify(filtered));
          } catch {}
          return filtered;
        });
        return { success: true };
      }

      return { success: false, error: data.error || 'Failed to delete deck' };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Network error deleting deck' };
    }
  };

  return (
    <DeckContext.Provider
      value={{
        decks,
        activeDeck,
        activeDeckCards,
        loading,
        error,
        saveDeck,
        setActiveDeck,
        deleteDeck,
        refreshDecks,
        getDeckCards
      }}
    >
      {children}
    </DeckContext.Provider>
  );
};

export const useDecks = () => {
  const context = useContext(DeckContext);
  if (!context) {
    throw new Error('useDecks must be used within a DeckProvider');
  }
  return context;
};
