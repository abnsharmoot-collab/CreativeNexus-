import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback, useMemo } from 'react';
import { collection, onSnapshot, doc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Announcement } from '../types/announcement';

interface CreateAnnouncementData {
  title: string;
  content: string;
  category?: string;
  isPinned?: boolean;
  authorDisplayName?: string;
  imageUrl?: string;
  images?: string[];
}

interface UpdateAnnouncementData {
  title?: string;
  content?: string;
  category?: string;
  isPinned?: boolean;
  isArchived?: boolean;
  authorDisplayName?: string;
  imageUrl?: string;
  images?: string[];
}

interface AnnouncementContextType {
  announcements: Announcement[];
  pinnedAnnouncements: Announcement[];
  regularAnnouncements: Announcement[];
  filteredAnnouncements: Announcement[];
  loading: boolean;
  error: string | null;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  categories: string[];
  refreshAnnouncements: () => Promise<void>;
  getAnnouncementById: (id: string) => Promise<Announcement | null>;
  createAnnouncement: (data: CreateAnnouncementData) => Promise<Announcement>;
  updateAnnouncement: (id: string, data: UpdateAnnouncementData) => Promise<Announcement>;
  togglePin: (id: string, isPinned?: boolean) => Promise<boolean>;
  deleteAnnouncement: (id: string) => Promise<void>;
}

const AnnouncementContext = createContext<AnnouncementContextType | undefined>(undefined);

export const AnnouncementProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Primary live listener from Firestore with fallback to REST API
  useEffect(() => {
    let unsubscribe: (() => void) | null = null;

    try {
      const announcementsColl = collection(db, 'announcements');
      unsubscribe = onSnapshot(
        announcementsColl,
        (snapshot) => {
          const loaded: Announcement[] = [];
          snapshot.forEach((d) => {
            const data = d.data();
            if (data.isArchived !== true) {
              loaded.push({
                id: d.id,
                title: data.title || '',
                content: data.content || '',
                authorDisplayName: data.authorDisplayName || 'Owner',
                authorDiscordId: data.authorDiscordId || '',
                authorAvatarUrl: data.authorAvatarUrl || '',
                category: data.category || 'General',
                imageUrl: data.imageUrl || undefined,
                images: Array.isArray(data.images) ? data.images : undefined,
                isPinned: Boolean(data.isPinned),
                isArchived: Boolean(data.isArchived),
                publishedAt: data.publishedAt || new Date().toISOString(),
                updatedAt: data.updatedAt || new Date().toISOString()
              });
            }
          });

          // Sort pinned first, then by date descending
          loaded.sort((a, b) => {
            if (a.isPinned && !b.isPinned) return -1;
            if (!a.isPinned && b.isPinned) return 1;
            return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
          });

          setAnnouncements(loaded);
          setLoading(false);
          setError(null);
        },
        (err) => {
          console.warn('Firestore live listener note, using REST API:', err.message);
          // Fallback to REST API
          fetchFromRestApi();
        }
      );
    } catch (err) {
      console.warn('Error setting up onSnapshot listener:', err);
      fetchFromRestApi();
    }

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  const fetchFromRestApi = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/announcements');
      if (!res.ok) {
        throw new Error(`Failed to fetch announcements (${res.status})`);
      }
      const data = await res.json();
      setAnnouncements(Array.isArray(data) ? data : []);
      setError(null);
    } catch (err: any) {
      console.error('Error fetching announcements:', err);
      setError(err.message || 'Failed to load announcements');
    } finally {
      setLoading(false);
    }
  };

  const refreshAnnouncements = useCallback(async () => {
    await fetchFromRestApi();
  }, []);

  // Fetch individual announcement
  const getAnnouncementById = useCallback(async (id: string): Promise<Announcement | null> => {
    // Check local cache first
    const cached = announcements.find((a) => a.id === id);
    if (cached) return cached;

    try {
      // Try Firestore directly
      try {
        const docRef = doc(db, 'announcements', id);
        const snap = await getDoc(docRef);
        if (snap.exists()) {
          const data = snap.data();
          return {
            id: snap.id,
            title: data.title || '',
            content: data.content || '',
            authorDisplayName: data.authorDisplayName || 'Owner',
            authorDiscordId: data.authorDiscordId || '',
            authorAvatarUrl: data.authorAvatarUrl || '',
            category: data.category || 'General',
            imageUrl: data.imageUrl || undefined,
            images: Array.isArray(data.images) ? data.images : undefined,
            isPinned: Boolean(data.isPinned),
            isArchived: Boolean(data.isArchived),
            publishedAt: data.publishedAt || new Date().toISOString(),
            updatedAt: data.updatedAt || new Date().toISOString()
          };
        }
      } catch (fErr) {
        // Fallback to REST API
      }

      const res = await fetch(`/api/announcements/${id}`);
      if (!res.ok) return null;
      return await res.json();
    } catch (err) {
      console.error('Error getting announcement by ID:', err);
      return null;
    }
  }, [announcements]);

  // Create announcement (Owner only - enforced server-side)
  const createAnnouncement = useCallback(async (data: CreateAnnouncementData): Promise<Announcement> => {
    const res = await fetch('/api/announcements', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(data)
    });

    const body = await res.json();
    if (!res.ok) {
      throw new Error(body.error || 'Failed to create announcement');
    }

    const created: Announcement = body.announcement;
    setAnnouncements((prev) => {
      const next = [created, ...prev.filter((a) => a.id !== created.id)];
      next.sort((a, b) => {
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
      });
      return next;
    });

    return created;
  }, []);

  // Update announcement (Owner only - enforced server-side)
  const updateAnnouncement = useCallback(async (id: string, data: UpdateAnnouncementData): Promise<Announcement> => {
    const res = await fetch(`/api/announcements/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(data)
    });

    const body = await res.json();
    if (!res.ok) {
      throw new Error(body.error || 'Failed to update announcement');
    }

    const updated: Announcement = body.announcement;
    setAnnouncements((prev) => {
      const next = prev.map((a) => (a.id === id ? updated : a));
      next.sort((a, b) => {
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
      });
      return next;
    });

    return updated;
  }, []);

  // Toggle pin state (Owner only - enforced server-side)
  const togglePin = useCallback(async (id: string, isPinned?: boolean): Promise<boolean> => {
    const res = await fetch(`/api/announcements/${id}/pin`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ isPinned })
    });

    const body = await res.json();
    if (!res.ok) {
      throw new Error(body.error || 'Failed to toggle pin');
    }

    const newPinState = body.isPinned;
    setAnnouncements((prev) => {
      const next = prev.map((a) => (a.id === id ? { ...a, isPinned: newPinState } : a));
      next.sort((a, b) => {
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
      });
      return next;
    });

    return newPinState;
  }, []);

  // Delete announcement (Owner only - enforced server-side)
  const deleteAnnouncement = useCallback(async (id: string): Promise<void> => {
    const res = await fetch(`/api/announcements/${id}`, {
      method: 'DELETE',
      credentials: 'include'
    });

    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.error || 'Failed to delete announcement');
    }

    setAnnouncements((prev) => prev.filter((a) => a.id !== id));
  }, []);

  // Pinned vs regular lists
  const pinnedAnnouncements = useMemo(() => {
    return announcements.filter((a) => a.isPinned);
  }, [announcements]);

  const regularAnnouncements = useMemo(() => {
    return announcements.filter((a) => !a.isPinned);
  }, [announcements]);

  // Unique categories list
  const categories = useMemo(() => {
    const set = new Set<string>();
    announcements.forEach((a) => {
      if (a.category && a.category.trim()) {
        set.add(a.category.trim());
      }
    });
    return Array.from(set);
  }, [announcements]);

  // Filtered list by category and search query
  const filteredAnnouncements = useMemo(() => {
    return announcements.filter((a) => {
      // Category filter
      if (selectedCategory !== 'ALL' && a.category?.toLowerCase() !== selectedCategory.toLowerCase()) {
        return false;
      }
      // Search query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesTitle = a.title.toLowerCase().includes(q);
        const matchesContent = a.content.toLowerCase().includes(q);
        const matchesAuthor = a.authorDisplayName.toLowerCase().includes(q);
        const matchesCategory = a.category?.toLowerCase().includes(q);
        return matchesTitle || matchesContent || matchesAuthor || matchesCategory;
      }
      return true;
    });
  }, [announcements, selectedCategory, searchQuery]);

  return (
    <AnnouncementContext.Provider
      value={{
        announcements,
        pinnedAnnouncements,
        regularAnnouncements,
        filteredAnnouncements,
        loading,
        error,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        categories,
        refreshAnnouncements,
        getAnnouncementById,
        createAnnouncement,
        updateAnnouncement,
        togglePin,
        deleteAnnouncement
      }}
    >
      {children}
    </AnnouncementContext.Provider>
  );
};

export const useAnnouncements = (): AnnouncementContextType => {
  const context = useContext(AnnouncementContext);
  if (!context) {
    throw new Error('useAnnouncements must be used within an AnnouncementProvider');
  }
  return context;
};
