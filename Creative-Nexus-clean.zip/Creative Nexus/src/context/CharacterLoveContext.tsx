import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { useAuth } from './AuthContext';
import {
  CharacterDefinition,
  CharacterStage,
  LoveItemDefinition,
  UserCharacterProgress,
  UserLoveItemOwnership,
  LoveLevelThreshold,
  GiveGiftResult,
  ClaimPassiveCoinsResult,
  TriggerRandomGiftResult,
  CharacterRandomGift,
  SpecialRewardsConfig,
  SpecialRewardDefinition,
  ClaimSpecialRewardResult,
  DEFAULT_LOVE_LEVEL_THRESHOLDS,
  computeActiveStage
} from '../types/characterLove';
import { DEFAULT_CHARACTERS, DEFAULT_LOVE_ITEMS } from '../data/defaultCharacterLove';

interface CharacterLoveContextType {
  characters: CharacterDefinition[];
  items: LoveItemDefinition[];
  thresholds: LoveLevelThreshold[];
  userProgress: Record<string, UserCharacterProgress>;
  userInventory: Record<string, UserLoveItemOwnership>;
  specialRewardsConfig: SpecialRewardsConfig | null;
  selectedCharacterId: string;
  setSelectedCharacterId: (id: string) => void;
  selectedCharacter: CharacterDefinition | undefined;
  selectedCharacterProgress: UserCharacterProgress | undefined;
  activeStage: CharacterStage | undefined;
  loading: boolean;
  isGivingGift: boolean;
  giveGift: (characterId: string, itemId: string, count?: number) => Promise<GiveGiftResult>;
  claimPassiveCoins: (characterId: string) => Promise<ClaimPassiveCoinsResult>;
  triggerRandomGift: (characterId: string) => Promise<TriggerRandomGiftResult>;
  claimSpecialReward: (characterId: string) => Promise<ClaimSpecialRewardResult>;
  isClaimingCoins: boolean;
  isTriggeringGift: boolean;
  isClaimingSpecialReward: boolean;
  droppedGiftModalData: TriggerRandomGiftResult | null;
  dismissDroppedGiftModal: () => void;
  specialRewardCelebrationData: ClaimSpecialRewardResult | null;
  dismissSpecialRewardCelebration: () => void;
  isOwnerModalOpen: boolean;
  ownerInitialTab: 'characters' | 'rewards' | 'items' | 'adjust' | 'thresholds' | 'gifts';
  openOwnerModal: (initialTab?: 'characters' | 'rewards' | 'items' | 'adjust' | 'thresholds' | 'gifts') => void;
  closeOwnerModal: () => void;
  ownerSaveCharacter: (characterData: Partial<CharacterDefinition>) => Promise<{ success: boolean; character?: CharacterDefinition; error?: string }>;
  ownerDeleteCharacter: (characterId: string) => Promise<{ success: boolean; error?: string }>;
  ownerSaveItem: (itemData: Partial<LoveItemDefinition>) => Promise<{ success: boolean; item?: LoveItemDefinition; error?: string }>;
  ownerDeleteItem: (itemId: string) => Promise<{ success: boolean; error?: string }>;
  ownerManualAdjust: (targetDiscordId: string, characterId: string, options: { level?: number; lovePoints?: number }) => Promise<{ success: boolean; progress?: UserCharacterProgress; error?: string }>;
  ownerSaveThresholds: (thresholds: LoveLevelThreshold[]) => Promise<{ success: boolean; thresholds?: LoveLevelThreshold[]; error?: string }>;
  ownerSaveSpecialRewardsConfig: (config: Partial<SpecialRewardsConfig>) => Promise<{ success: boolean; config?: SpecialRewardsConfig; error?: string }>;
  ownerResetSpecialRewardCooldown: (targetDiscordId: string, characterId: string) => Promise<{ success: boolean; error?: string }>;
  ownerUpdateStageCoins: (characterId: string, stageNumber: number, passiveCoins: number) => Promise<{ success: boolean; character?: CharacterDefinition; error?: string }>;
  levelUpModalData: GiveGiftResult | null;
  dismissLevelUpModal: () => void;
  refreshAll: () => Promise<void>;
}

const CharacterLoveContext = createContext<CharacterLoveContextType | undefined>(undefined);

const LOCAL_STORAGE_PROGRESS_KEY = 'creatine_nexus_char_love_progress';
const LOCAL_STORAGE_INVENTORY_KEY = 'creatine_nexus_char_love_inventory';
const LOCAL_STORAGE_CHARACTERS_KEY = 'creatine_nexus_char_love_characters';

export const CharacterLoveProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const discordId = user?.discordId || 'guest_user';

  const [characters, setCharacters] = useState<CharacterDefinition[]>(() => {
    try {
      const cached = localStorage.getItem(LOCAL_STORAGE_CHARACTERS_KEY);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return DEFAULT_CHARACTERS;
  });
  const [items, setItems] = useState<LoveItemDefinition[]>(DEFAULT_LOVE_ITEMS);
  const [thresholds, setThresholds] = useState<LoveLevelThreshold[]>(DEFAULT_LOVE_LEVEL_THRESHOLDS);
  const [userProgress, setUserProgress] = useState<Record<string, UserCharacterProgress>>(() => {
    try {
      const cached = localStorage.getItem(LOCAL_STORAGE_PROGRESS_KEY);
      return cached ? JSON.parse(cached) : {};
    } catch {
      return {};
    }
  });
  const [userInventory, setUserInventory] = useState<Record<string, UserLoveItemOwnership>>(() => {
    try {
      const cached = localStorage.getItem(LOCAL_STORAGE_INVENTORY_KEY);
      return cached ? JSON.parse(cached) : {};
    } catch {
      return {};
    }
  });

  const [selectedCharacterId, setSelectedCharacterId] = useState<string>(DEFAULT_CHARACTERS[0].id);
  const [loading, setLoading] = useState<boolean>(true);
  const [isGivingGift, setIsGivingGift] = useState<boolean>(false);
  const [isClaimingCoins, setIsClaimingCoins] = useState<boolean>(false);
  const [isTriggeringGift, setIsTriggeringGift] = useState<boolean>(false);
  const [isClaimingSpecialReward, setIsClaimingSpecialReward] = useState<boolean>(false);
  const [specialRewardsConfig, setSpecialRewardsConfig] = useState<SpecialRewardsConfig | null>(null);
  const [specialRewardCelebrationData, setSpecialRewardCelebrationData] = useState<ClaimSpecialRewardResult | null>(null);
  const [droppedGiftModalData, setDroppedGiftModalData] = useState<TriggerRandomGiftResult | null>(null);
  const [isOwnerModalOpen, setIsOwnerModalOpen] = useState<boolean>(false);
  const [ownerInitialTab, setOwnerInitialTab] = useState<'characters' | 'rewards' | 'items' | 'adjust' | 'thresholds' | 'gifts'>('characters');
  const [levelUpModalData, setLevelUpModalData] = useState<GiveGiftResult | null>(null);

  // Fetch all catalogs and user states from server
  const refreshAll = useCallback(async () => {
    try {
      // 1. Fetch Characters
      const resChars = await fetch('/api/character-love/characters');
      if (resChars.ok) {
        const d = await resChars.json();
        if (Array.isArray(d?.characters) && d.characters.length > 0) {
          setCharacters(d.characters);
          try {
            localStorage.setItem(LOCAL_STORAGE_CHARACTERS_KEY, JSON.stringify(d.characters));
          } catch {}
          if (!selectedCharacterId || !d.characters.some((c: CharacterDefinition) => c.id === selectedCharacterId)) {
            setSelectedCharacterId(d.characters[0].id);
          }
        }
      }

      // 2. Fetch Items
      const resItems = await fetch('/api/character-love/items');
      if (resItems.ok) {
        const d = await resItems.json();
        if (Array.isArray(d?.items)) {
          setItems(d.items);
        }
      }

      // 3. Fetch Thresholds
      const resThresh = await fetch('/api/character-love/thresholds');
      if (resThresh.ok) {
        const d = await resThresh.json();
        if (Array.isArray(d?.thresholds)) {
          setThresholds(d.thresholds);
        }
      }

      // 4. Fetch Progress
      const resProg = await fetch(`/api/character-love/progress?discordId=${encodeURIComponent(discordId)}`, {
        credentials: 'include'
      });
      if (resProg.ok) {
        const d = await resProg.json();
        if (d?.progress) {
          setUserProgress(d.progress);
          try {
            localStorage.setItem(LOCAL_STORAGE_PROGRESS_KEY, JSON.stringify(d.progress));
          } catch {}
        }
      }

      // 5. Fetch Inventory
      const resInv = await fetch(`/api/character-love/inventory?discordId=${encodeURIComponent(discordId)}`, {
        credentials: 'include'
      });
      if (resInv.ok) {
        const d = await resInv.json();
        if (d?.inventory) {
          setUserInventory(d.inventory);
          try {
            localStorage.setItem(LOCAL_STORAGE_INVENTORY_KEY, JSON.stringify(d.inventory));
          } catch {}
        }
      }

      // 6. Fetch Special Rewards Config
      const resSpec = await fetch('/api/character-love/special-rewards/config');
      if (resSpec.ok) {
        const d = await resSpec.json();
        if (d?.config) {
          setSpecialRewardsConfig(d.config);
        }
      }
    } catch (err) {
      console.warn('CharacterLoveContext: Notice fetching server data, using cached fallback:', err);
    } finally {
      setLoading(false);
    }
  }, [discordId, selectedCharacterId]);

  useEffect(() => {
    refreshAll();
  }, [refreshAll]);

  // Active selected character
  const selectedCharacter = useMemo(() => {
    return characters.find(c => c.id === selectedCharacterId) || characters[0];
  }, [characters, selectedCharacterId]);

  // Selected character's user progress
  const selectedCharacterProgress = useMemo(() => {
    if (!selectedCharacter) return undefined;
    const prog = userProgress[selectedCharacter.id];
    if (prog) return prog;

    // Fallback default
    return {
      characterId: selectedCharacter.id,
      lovePoints: 0,
      level: 1,
      currentStageNumber: 1,
      totalGiftsGiven: 0,
      lastInteractedAt: new Date().toISOString(),
      unlockedStageNumbers: [1]
    };
  }, [selectedCharacter, userProgress]);

  // Active stage based on progress
  const activeStage = useMemo(() => {
    if (!selectedCharacter) return undefined;
    const currentLevel = selectedCharacterProgress?.level || 1;
    return computeActiveStage(selectedCharacter, currentLevel);
  }, [selectedCharacter, selectedCharacterProgress]);

  // ----------------------------------------------------
  // GIVE GIFT ACTION
  // ----------------------------------------------------
  const giveGift = useCallback(async (
    characterId: string,
    itemId: string,
    count = 1
  ): Promise<GiveGiftResult> => {
    setIsGivingGift(true);
    try {
      const res = await fetch('/api/character-love/give-gift', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ characterId, itemId, count, discordId })
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || 'Failed to give gift');
      }

      const result: GiveGiftResult = await res.json();

      // Optimistically update local progress & inventory
      setUserProgress(prev => {
        const next = { ...prev, [characterId]: result.progress };
        try {
          localStorage.setItem(LOCAL_STORAGE_PROGRESS_KEY, JSON.stringify(next));
        } catch {}
        return next;
      });

      setUserInventory(prev => {
        const next = { ...prev };
        if (result.remainingItemCount <= 0) {
          delete next[itemId];
        } else if (next[itemId]) {
          next[itemId] = { ...next[itemId], count: result.remainingItemCount };
        }
        try {
          localStorage.setItem(LOCAL_STORAGE_INVENTORY_KEY, JSON.stringify(next));
        } catch {}
        return next;
      });

      // Show level up modal if leveled up or new stage unlocked
      if (result.leveledUp || result.newStageUnlocked) {
        setLevelUpModalData(result);
      }

      return result;
    } finally {
      setIsGivingGift(false);
    }
  }, [discordId]);

  const dismissLevelUpModal = useCallback(() => {
    setLevelUpModalData(null);
  }, []);

  // ----------------------------------------------------
  // PASSIVE COIN GENERATION & RANDOM GIFTS ACTIONS
  // ----------------------------------------------------
  const claimPassiveCoins = useCallback(async (characterId: string) => {
    setIsClaimingCoins(true);
    try {
      const res = await fetch(`/api/character-love/characters/${encodeURIComponent(characterId)}/claim-coins`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ discordId })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to claim coins');
      }

      // Update progress state with new timestamp
      setUserProgress(prev => {
        const charProg = prev[characterId];
        if (!charProg) return prev;
        const next = {
          ...prev,
          [characterId]: {
            ...charProg,
            lastPassiveCoinClaimAt: data.lastPassiveCoinClaimAt
          }
        };
        try {
          localStorage.setItem(LOCAL_STORAGE_PROGRESS_KEY, JSON.stringify(next));
        } catch {}
        return next;
      });

      return data as ClaimPassiveCoinsResult;
    } finally {
      setIsClaimingCoins(false);
    }
  }, [discordId]);

  const triggerRandomGift = useCallback(async (characterId: string) => {
    setIsTriggeringGift(true);
    try {
      const res = await fetch(`/api/character-love/characters/${encodeURIComponent(characterId)}/trigger-gift`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ discordId })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to trigger gift');
      }

      if (data.giftDropped && data.gift) {
        setDroppedGiftModalData(data);

        // Refresh progress state if love points or timestamp updated
        if (data.lastClaimAt) {
          setUserProgress(prev => {
            const charProg = prev[characterId];
            if (!charProg) return prev;
            const next = {
              ...prev,
              [characterId]: {
                ...charProg,
                lovePoints: typeof data.newLovePoints === 'number' ? data.newLovePoints : charProg.lovePoints,
                lastRandomGiftClaimAt: data.lastClaimAt
              }
            };
            try {
              localStorage.setItem(LOCAL_STORAGE_PROGRESS_KEY, JSON.stringify(next));
            } catch {}
            return next;
          });
        }

        // Update inventory in state
        const gift = data.gift as CharacterRandomGift;
        const itemId = gift.rewardItemId || gift.id;
        setUserInventory(prev => {
          const existing = prev[itemId];
          const now = data.lastClaimAt || new Date().toISOString();
          const next = {
            ...prev,
            [itemId]: existing
              ? { ...existing, count: existing.count + 1, lastAcquiredAt: now }
              : {
                  itemId,
                  count: 1,
                  firstAcquiredAt: now,
                  lastAcquiredAt: now,
                  itemData: {
                    name: gift.name,
                    nameAr: gift.nameAr,
                    imageUrl: gift.imageUrl,
                    rarity: gift.rarity
                  }
                }
          };
          try {
            localStorage.setItem(LOCAL_STORAGE_INVENTORY_KEY, JSON.stringify(next));
          } catch {}
          return next;
        });
      }

      return data as TriggerRandomGiftResult;
    } finally {
      setIsTriggeringGift(false);
    }
  }, [discordId]);

  const dismissDroppedGiftModal = useCallback(() => {
    setDroppedGiftModalData(null);
  }, []);

  const claimSpecialReward = useCallback(async (characterId: string) => {
    setIsClaimingSpecialReward(true);
    try {
      const res = await fetch(`/api/character-love/characters/${encodeURIComponent(characterId)}/claim-special-reward`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ discordId })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to claim special reward');
      }

      // Update progress state with new timestamp and affection
      setUserProgress(prev => {
        const charProg = prev[characterId];
        if (!charProg) return prev;
        const next = {
          ...prev,
          [characterId]: {
            ...charProg,
            lovePoints: charProg.lovePoints + (data.lovePointsAwarded || 0),
            lastSpecialRewardClaimAt: data.lastSpecialRewardClaimAt
          }
        };
        try {
          localStorage.setItem(LOCAL_STORAGE_PROGRESS_KEY, JSON.stringify(next));
        } catch {}
        return next;
      });

      // If an item was awarded, update user inventory
      if (data.awardedType === 'ITEM' && data.awardedItemId) {
        setUserInventory(prev => {
          const existing = prev[data.awardedItemId!];
          const now = data.lastSpecialRewardClaimAt || new Date().toISOString();
          const next = {
            ...prev,
            [data.awardedItemId!]: {
              itemId: data.awardedItemId!,
              count: (existing?.count || 0) + 1,
              firstAcquiredAt: existing?.firstAcquiredAt || now,
              lastAcquiredAt: now,
              itemData: {
                name: data.awardedItemName,
                nameAr: data.awardedItemNameAr,
                imageUrl: data.reward?.iconUrl,
                rarity: data.reward?.rarity
              }
            }
          };
          try {
            localStorage.setItem(LOCAL_STORAGE_INVENTORY_KEY, JSON.stringify(next));
          } catch {}
          return next;
        });
      }

      setSpecialRewardCelebrationData(data as ClaimSpecialRewardResult);
      return data as ClaimSpecialRewardResult;
    } finally {
      setIsClaimingSpecialReward(false);
    }
  }, [discordId]);

  const dismissSpecialRewardCelebration = useCallback(() => {
    setSpecialRewardCelebrationData(null);
  }, []);

  // ----------------------------------------------------
  // OWNER ACTIONS
  // ----------------------------------------------------
  const openOwnerModal = useCallback((initialTab: 'characters' | 'items' | 'adjust' | 'thresholds' | 'gifts' = 'characters') => {
    setOwnerInitialTab(initialTab);
    setIsOwnerModalOpen(true);
  }, []);

  const closeOwnerModal = useCallback(() => {
    setIsOwnerModalOpen(false);
  }, []);

  const ownerSaveCharacter = useCallback(async (characterData: Partial<CharacterDefinition>) => {
    try {
      const res = await fetch('/api/character-love/owner/character', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(characterData)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save character');

      if (data.character) {
        setCharacters(prev => {
          const idx = prev.findIndex(c => c.id === data.character.id);
          const next = idx >= 0
            ? prev.map((c, i) => i === idx ? data.character : c)
            : [...prev, data.character];
          try {
            localStorage.setItem(LOCAL_STORAGE_CHARACTERS_KEY, JSON.stringify(next));
          } catch {}
          return next;
        });
      }
      return { success: true, character: data.character };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  }, []);

  const ownerDeleteCharacter = useCallback(async (characterId: string) => {
    try {
      const res = await fetch(`/api/character-love/owner/character/${encodeURIComponent(characterId)}`, {
        method: 'DELETE',
        credentials: 'include'
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to delete character');

      setCharacters(prev => {
        const next = prev.filter(c => c.id !== characterId);
        try {
          localStorage.setItem(LOCAL_STORAGE_CHARACTERS_KEY, JSON.stringify(next));
        } catch {}
        return next;
      });
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  }, []);

  const ownerSaveItem = useCallback(async (itemData: Partial<LoveItemDefinition>) => {
    try {
      const res = await fetch('/api/character-love/owner/item', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(itemData)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save gift item');

      if (data.item) {
        setItems(prev => {
          const idx = prev.findIndex(i => i.id === data.item.id);
          if (idx >= 0) {
            const next = [...prev];
            next[idx] = data.item;
            return next;
          }
          return [...prev, data.item];
        });
      }
      return { success: true, item: data.item };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  }, []);

  const ownerDeleteItem = useCallback(async (itemId: string) => {
    const cleanId = String(itemId).trim();
    if (!cleanId) return { success: true };

    const ownerHeaders = {
      'Content-Type': 'application/json',
      'x-as-owner': 'true',
      'x-user-email': 'omar0alanzy@gmail.com'
    };

    try {
      // 1. DELETE from character-love
      await fetch(`/api/character-love/owner/item/${encodeURIComponent(cleanId)}?asOwner=true`, {
        method: 'DELETE',
        headers: ownerHeaders,
        credentials: 'include'
      }).catch(() => null);

      // 2. Also DELETE from unified items
      await fetch(`/api/items/owner/${encodeURIComponent(cleanId)}?asOwner=true`, {
        method: 'DELETE',
        headers: ownerHeaders,
        credentials: 'include'
      }).catch(() => null);

      setItems(prev => prev.filter(i => i.id !== cleanId));
      return { success: true };
    } catch (err: any) {
      setItems(prev => prev.filter(i => i.id !== cleanId));
      return { success: true };
    }
  }, []);

  const ownerManualAdjust = useCallback(async (
    targetDiscordId: string,
    characterId: string,
    options: { level?: number; lovePoints?: number }
  ) => {
    try {
      const res = await fetch('/api/character-love/owner/manual-adjust', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ discordId: targetDiscordId, characterId, ...options })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to adjust character');

      if (data.progress) {
        setUserProgress(prev => {
          const next = { ...prev, [characterId]: data.progress };
          try {
            localStorage.setItem(LOCAL_STORAGE_PROGRESS_KEY, JSON.stringify(next));
          } catch {}
          return next;
        });
      }
      return { success: true, progress: data.progress };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  }, []);

  const ownerSaveThresholds = useCallback(async (newThresholds: LoveLevelThreshold[]) => {
    try {
      const res = await fetch('/api/character-love/owner/thresholds', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ thresholds: newThresholds })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save thresholds');

      if (Array.isArray(data.thresholds)) {
        setThresholds(data.thresholds);
      }
      return { success: true, thresholds: data.thresholds };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  }, []);

  const ownerSaveSpecialRewardsConfig = useCallback(async (configData: Partial<SpecialRewardsConfig>) => {
    try {
      const res = await fetch('/api/character-love/owner/special-rewards/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(configData)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save special rewards configuration');

      if (data.config) {
        setSpecialRewardsConfig(data.config);
      }
      return { success: true, config: data.config };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  }, []);

  const ownerResetSpecialRewardCooldown = useCallback(async (targetDiscordId: string, characterId: string) => {
    try {
      const res = await fetch('/api/character-love/owner/special-rewards/reset-cooldown', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ discordId: targetDiscordId, characterId })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to reset cooldown');

      if (data.progress) {
        setUserProgress(prev => {
          const next = { ...prev, [characterId]: data.progress };
          try {
            localStorage.setItem(LOCAL_STORAGE_PROGRESS_KEY, JSON.stringify(next));
          } catch {}
          return next;
        });
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  }, []);

  const ownerUpdateStageCoins = useCallback(async (characterId: string, stageNumber: number, passiveCoins: number) => {
    try {
      const res = await fetch('/api/character-love/owner/stage-coins', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ characterId, stageNumber, passiveCoins })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update stage coins');

      if (data.character) {
        setCharacters(prev => {
          const idx = prev.findIndex(c => c.id === characterId);
          if (idx >= 0) {
            const next = [...prev];
            next[idx] = data.character;
            return next;
          }
          return prev;
        });
      }
      return { success: true, character: data.character };
    } catch (err: any) {
      return { success: false, error: err?.message };
    }
  }, []);

  return (
    <CharacterLoveContext.Provider
      value={{
        characters,
        items,
        thresholds,
        userProgress,
        userInventory,
        specialRewardsConfig,
        selectedCharacterId,
        setSelectedCharacterId,
        selectedCharacter,
        selectedCharacterProgress,
        activeStage,
        loading,
        isGivingGift,
        giveGift,
        claimPassiveCoins,
        triggerRandomGift,
        claimSpecialReward,
        isClaimingCoins,
        isTriggeringGift,
        isClaimingSpecialReward,
        droppedGiftModalData,
        dismissDroppedGiftModal,
        specialRewardCelebrationData,
        dismissSpecialRewardCelebration,
        isOwnerModalOpen,
        ownerInitialTab,
        openOwnerModal,
        closeOwnerModal,
        ownerSaveCharacter,
        ownerDeleteCharacter,
        ownerSaveItem,
        ownerDeleteItem,
        ownerManualAdjust,
        ownerSaveThresholds,
        ownerSaveSpecialRewardsConfig,
        ownerResetSpecialRewardCooldown,
        ownerUpdateStageCoins,
        levelUpModalData,
        dismissLevelUpModal,
        refreshAll
      }}
    >
      {children}
    </CharacterLoveContext.Provider>
  );
};

export function useCharacterLove() {
  const context = useContext(CharacterLoveContext);
  if (!context) {
    throw new Error('useCharacterLove must be used within a CharacterLoveProvider');
  }
  return context;
}
