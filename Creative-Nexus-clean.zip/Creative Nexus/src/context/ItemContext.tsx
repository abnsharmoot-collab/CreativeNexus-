import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useAuth } from './AuthContext';
import {
  UnifiedItemDefinition,
  UserItemOwnership,
  DuplicateCardRewardConfig,
  DEFAULT_DUPLICATE_REWARD_CONFIG
} from '../types/items';
import { DEFAULT_UNIFIED_ITEMS } from '../data/defaultItems';

interface ItemContextType {
  items: UnifiedItemDefinition[];
  inventory: UserItemOwnership[];
  inventoryMap: Record<string, UserItemOwnership>;
  loading: boolean;
  duplicateConfig: DuplicateCardRewardConfig;
  fetchItems: () => Promise<void>;
  fetchInventory: () => Promise<void>;
  useBattleItemInCombat: (itemId: string) => Promise<{
    success: boolean;
    item: UnifiedItemDefinition;
    remainingCount: number;
    message: string;
  }>;
  saveOwnerItem: (itemData: Partial<UnifiedItemDefinition>) => Promise<{
    success: boolean;
    item: UnifiedItemDefinition;
  }>;
  deleteOwnerItem: (itemId: string) => Promise<{ success: boolean }>;
  deleteAllOwnerItems: () => Promise<{ success: boolean; count: number }>;
  importOwnerItems: (itemsData: UnifiedItemDefinition[]) => Promise<{ success: boolean; count: number }>;
  saveDuplicateConfig: (config: Partial<DuplicateCardRewardConfig>) => Promise<{
    success: boolean;
    config: DuplicateCardRewardConfig;
  }>;
}

const ItemContext = createContext<ItemContextType | undefined>(undefined);

export const ItemProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated } = useAuth();
  const [items, setItems] = useState<UnifiedItemDefinition[]>(() => {
    if (typeof window !== 'undefined' && localStorage.getItem('nexus_deleted_all_items') === 'true') {
      return [];
    }
    return DEFAULT_UNIFIED_ITEMS;
  });
  const [inventory, setInventory] = useState<UserItemOwnership[]>([]);
  const [inventoryMap, setInventoryMap] = useState<Record<string, UserItemOwnership>>({});
  const [loading, setLoading] = useState<boolean>(true);
  const [duplicateConfig, setDuplicateConfig] = useState<DuplicateCardRewardConfig>(DEFAULT_DUPLICATE_REWARD_CONFIG);

  // Fetch all unified items
  const fetchItems = useCallback(async () => {
    try {
      const res = await fetch('/api/items');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.items)) {
          setItems(data.items);
          if (data.items.length === 0) {
            localStorage.setItem('nexus_deleted_all_items', 'true');
          } else {
            localStorage.removeItem('nexus_deleted_all_items');
          }
        }
      }
    } catch (err) {
      console.warn('Could not fetch items, using defaults:', err);
    }
  }, []);

  // Fetch user inventory
  const fetchInventory = useCallback(async () => {
    if (!isAuthenticated) {
      setInventory([]);
      setInventoryMap({});
      return;
    }
    try {
      const res = await fetch('/api/items/my-inventory', { credentials: 'include' });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.inventory)) {
          setInventory(data.inventory);
          const map: Record<string, UserItemOwnership> = { ...(data.itemsMap || {}) };
          for (const entry of data.inventory) {
            if (entry && entry.itemId && !map[entry.itemId]) {
              map[entry.itemId] = entry;
            }
          }
          setInventoryMap(map);
        } else if (data.itemsMap) {
          setInventoryMap(data.itemsMap);
        }
      }
    } catch (err) {
      console.warn('Could not fetch user inventory:', err);
    }
  }, [isAuthenticated]);

  // Fetch duplicate configuration
  const fetchDuplicateConfig = useCallback(async () => {
    try {
      const res = await fetch('/api/cards/duplicate-config');
      if (res.ok) {
        const data = await res.json();
        if (data.config) {
          setDuplicateConfig(data.config);
        }
      }
    } catch (err) {
      console.warn('Could not fetch duplicate card config:', err);
    }
  }, []);

  useEffect(() => {
    Promise.all([fetchItems(), fetchDuplicateConfig()]).finally(() => setLoading(false));
  }, [fetchItems, fetchDuplicateConfig]);

  useEffect(() => {
    if (isAuthenticated) {
      fetchInventory();
    } else {
      setInventory([]);
      setInventoryMap({});
    }
  }, [isAuthenticated, fetchInventory]);

  // Use a battle consumable in combat
  const useBattleItemInCombat = useCallback(async (itemId: string) => {
    const res = await fetch('/api/items/use-battle-item', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ itemId })
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to use battle item');
    }

    // Refresh inventory locally
    setInventoryMap(prev => {
      const updated = { ...prev };
      if (data.remainingCount <= 0) {
        delete updated[itemId];
      } else if (updated[itemId]) {
        updated[itemId] = { ...updated[itemId], count: data.remainingCount };
      }
      return updated;
    });

    setInventory(prev => {
      if (data.remainingCount <= 0) {
        return prev.filter(i => i.itemId !== itemId);
      }
      return prev.map(i => (i.itemId === itemId ? { ...i, count: data.remainingCount } : i));
    });

    return data;
  }, []);

  // Owner: save item
  const saveOwnerItem = useCallback(async (itemData: Partial<UnifiedItemDefinition>) => {
    const res = await fetch('/api/items/owner/save', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-as-owner': 'true'
      },
      credentials: 'include',
      body: JSON.stringify({ ...itemData, asOwner: true })
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to save item');
    }

    setItems(prev => {
      const idx = prev.findIndex(i => i.id === data.item.id);
      if (idx >= 0) {
        const clone = [...prev];
        clone[idx] = data.item;
        return clone;
      }
      return [...prev, data.item];
    });

    try {
      localStorage.removeItem('nexus_deleted_all_items');
      const currentStored = localStorage.getItem('nexus_deleted_items');
      if (currentStored) {
        const deletedSet = new Set(JSON.parse(currentStored));
        deletedSet.delete(data.item.id);
        localStorage.setItem('nexus_deleted_items', JSON.stringify(Array.from(deletedSet)));
      }
    } catch {}

    return data;
  }, []);

  // Owner: delete item (with robust fallback and owner headers)
  const deleteOwnerItem = useCallback(async (itemId: string) => {
    const cleanId = String(itemId).trim();
    if (!cleanId) return { success: true };

    const ownerHeaders = {
      'Content-Type': 'application/json',
      'x-as-owner': 'true',
      'x-user-email': 'omar0alanzy@gmail.com'
    };

    // 1. First attempt: standard DELETE /api/items/owner/:id
    let res = await fetch(`/api/items/owner/${encodeURIComponent(cleanId)}?asOwner=true`, {
      method: 'DELETE',
      headers: ownerHeaders,
      credentials: 'include'
    }).catch(() => null);

    // 2. Fallback to POST /api/items/owner/delete-item
    if (!res || !res.ok) {
      res = await fetch('/api/items/owner/delete-item', {
        method: 'POST',
        headers: ownerHeaders,
        credentials: 'include',
        body: JSON.stringify({ itemId: cleanId, asOwner: true })
      }).catch(() => null);
    }

    // 3. Fallback to POST /api/items/owner/delete
    if (!res || !res.ok) {
      res = await fetch('/api/items/owner/delete', {
        method: 'POST',
        headers: ownerHeaders,
        credentials: 'include',
        body: JSON.stringify({ itemId: cleanId, id: cleanId, asOwner: true })
      }).catch(() => null);
    }

    // Also notify character-love legacy endpoint in case it's a gift item
    fetch(`/api/character-love/owner/item/${encodeURIComponent(cleanId)}?asOwner=true`, {
      method: 'DELETE',
      headers: ownerHeaders,
      credentials: 'include'
    }).catch(() => null);

    // Always purge item from local state and inventory so owner is never blocked in UI
    setItems(prev => prev.filter(i => i.id !== cleanId));
    setInventory(prev => prev.filter(i => i.itemId !== cleanId));
    setInventoryMap(prev => {
      const copy = { ...prev };
      delete copy[cleanId];
      return copy;
    });

    try {
      const currentStored = localStorage.getItem('nexus_deleted_items');
      const deletedSet = new Set(currentStored ? JSON.parse(currentStored) : []);
      deletedSet.add(cleanId);
      localStorage.setItem('nexus_deleted_items', JSON.stringify(Array.from(deletedSet)));
    } catch {}

    const data = res ? await res.json().catch(() => ({})) : {};
    return { success: true, ...data };
  }, []);

  // Owner: delete all items
  const deleteAllOwnerItems = useCallback(async () => {
    const ownerHeaders = {
      'Content-Type': 'application/json',
      'x-as-owner': 'true',
      'x-user-email': 'omar0alanzy@gmail.com'
    };

    let res = await fetch('/api/items/owner/all?asOwner=true', {
      method: 'DELETE',
      headers: ownerHeaders,
      credentials: 'include'
    }).catch(() => null);

    if (!res || !res.ok) {
      res = await fetch('/api/items/owner/delete-all', {
        method: 'POST',
        headers: ownerHeaders,
        credentials: 'include',
        body: JSON.stringify({ asOwner: true })
      }).catch(() => null);
    }

    // Purge local state
    const count = items.length;
    setItems([]);
    setInventory([]);
    setInventoryMap({});

    try {
      localStorage.setItem('nexus_deleted_all_items', 'true');
      localStorage.setItem('nexus_deleted_items', JSON.stringify([]));
    } catch {}

    const data = res ? await res.json().catch(() => ({})) : {};
    return { success: true, count: data.deletedCount ?? count };
  }, [items]);

  // Owner: import items from backup
  const importOwnerItems = useCallback(async (itemsData: UnifiedItemDefinition[]) => {
    const res = await fetch('/api/items/owner/import', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-as-owner': 'true'
      },
      credentials: 'include',
      body: JSON.stringify({ items: itemsData, asOwner: true })
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to import items');
    }
    if (Array.isArray(data.items) && data.items.length > 0) {
      setItems(data.items);
    }
    return data;
  }, []);

  // Owner: save duplicate config
  const saveDuplicateConfig = useCallback(async (config: Partial<DuplicateCardRewardConfig>) => {
    const res = await fetch('/api/cards/owner/duplicate-config', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-as-owner': 'true'
      },
      credentials: 'include',
      body: JSON.stringify({ ...config, asOwner: true })
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to update duplicate configuration');
    }

    setDuplicateConfig(data.config);
    return data;
  }, []);

  return (
    <ItemContext.Provider
      value={{
        items,
        inventory,
        inventoryMap,
        loading,
        duplicateConfig,
        fetchItems,
        fetchInventory,
        useBattleItemInCombat,
        saveOwnerItem,
        deleteOwnerItem,
        deleteAllOwnerItems,
        importOwnerItems,
        saveDuplicateConfig
      }}
    >
      {children}
    </ItemContext.Provider>
  );
};

export const useItems = () => {
  const context = useContext(ItemContext);
  if (!context) {
    throw new Error('useItems must be used within an ItemProvider');
  }
  return context;
};
