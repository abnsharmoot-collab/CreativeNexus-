import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { StoryChapterDefinition, StoryBattleDefinition, UserStoryProgress } from '../types/story';
import { STORY_CHAPTERS } from '../config/storyConfig';
import { useAuth } from './AuthContext';
import { useCards } from './CardContext';

interface StoryContextType {
  chapters: StoryChapterDefinition[];
  progress: UserStoryProgress | null;
  loading: boolean;
  isChapterUnlocked: (chapterId: string) => boolean;
  isBattleUnlocked: (battleId: string) => boolean;
  isBattleCompleted: (battleId: string) => boolean;
  hasClaimedFirstClear: (battleId: string) => boolean;
  completeBattle: (battleId: string, outcome: 'VICTORY' | 'DEFEAT') => Promise<{
    success: boolean;
    coinsAwarded: number;
    xpAwarded: number;
    isFirstClear: boolean;
    message: string;
    newBalance?: number;
  }>;
  saveBattle: (battleData: Partial<StoryBattleDefinition>) => Promise<{
    success: boolean;
    battle?: StoryBattleDefinition;
    error?: string;
  }>;
  deleteBattle: (battleId: string) => Promise<{
    success: boolean;
    error?: string;
  }>;
  saveChapter: (chapterData: Partial<StoryChapterDefinition>) => Promise<{
    success: boolean;
    chapter?: StoryChapterDefinition;
    error?: string;
  }>;
  deleteChapter: (chapterId: string) => Promise<{
    success: boolean;
    error?: string;
  }>;
  refreshProgress: () => Promise<void>;
}

const StoryContext = createContext<StoryContextType | undefined>(undefined);

export const StoryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated } = useAuth();
  const { refreshProfile } = useCards();

  const [chapters, setChapters] = useState<StoryChapterDefinition[]>(STORY_CHAPTERS);
  const [progress, setProgress] = useState<UserStoryProgress | null>(() => {
    try {
      const saved = localStorage.getItem('nexus_user_story_progress');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState<boolean>(true);

  // Load chapters & user progress
  const refreshProgress = useCallback(async () => {
    try {
      setLoading(true);
      // Fetch chapters definitions (with populated cards and owner customizations)
      const chaptersRes = await fetch('/api/story/chapters');
      const chaptersData = await chaptersRes.json();
      if (chaptersData.success && Array.isArray(chaptersData.chapters)) {
        setChapters(chaptersData.chapters);
      }

      if (isAuthenticated) {
        const progRes = await fetch('/api/story/progress', { credentials: 'include' });
        const progData = await progRes.json();
        if (progData.success && progData.progress) {
          setProgress(progData.progress);
          try {
            localStorage.setItem('nexus_user_story_progress', JSON.stringify(progData.progress));
          } catch {}
        }
      }
    } catch (err: any) {
      console.warn('StoryContext: Error fetching story state:', err?.message);
    } finally {
      setLoading(false);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    refreshProgress();
  }, [refreshProgress]);

  // Check if a chapter is unlocked (Chapter K is locked until Chapter K-1 has all battles completed)
  const isChapterUnlocked = useCallback(
    (chapterId: string): boolean => {
      const chIdx = chapters.findIndex(c => c.id === chapterId);
      if (chIdx <= 0) return true; // Chapter 1 is always unlocked
      
      // All preceding chapters must be 100% completed
      for (let i = 0; i < chIdx; i++) {
        const prevCh = chapters[i];
        if (!prevCh || !Array.isArray(prevCh.battles) || prevCh.battles.length === 0) continue;
        const allCompleted = prevCh.battles.every(b => 
          progress && Array.isArray(progress.completedBattleIds) && progress.completedBattleIds.includes(b.id)
        );
        if (!allCompleted) return false;
      }
      return true;
    },
    [chapters, progress]
  );

  // Check if a battle is unlocked (Battle N is only unlocked if Battle N-1 was completed and won)
  const isBattleUnlocked = useCallback(
    (battleId: string): boolean => {
      // Find battle in chapters
      for (let chIdx = 0; chIdx < chapters.length; chIdx++) {
        const ch = chapters[chIdx];
        const bIdx = ch.battles.findIndex(item => item.id === battleId);
        if (bIdx !== -1) {
          // If chapter is locked, battle is locked
          if (chIdx > 0 && !isChapterUnlocked(ch.id)) return false;

          // First battle of any unlocked chapter is unlocked
          if (bIdx === 0 || ch.battles[bIdx].battleNumber === 1) return true;
          
          // Battle N is strictly locked until Battle N-1 is completed
          const prevBattle = ch.battles[bIdx - 1];
          if (!prevBattle) return true;
          if (!progress || !Array.isArray(progress.completedBattleIds)) return false;
          return progress.completedBattleIds.includes(prevBattle.id);
        }
      }
      return false;
    },
    [chapters, progress, isChapterUnlocked]
  );

  // Check if completed
  const isBattleCompleted = useCallback(
    (battleId: string): boolean => {
      if (!progress) return false;
      return progress.completedBattleIds.includes(battleId);
    },
    [progress]
  );

  // Check if first-clear bonus was claimed
  const hasClaimedFirstClear = useCallback(
    (battleId: string): boolean => {
      if (!progress) return false;
      return progress.claimedRewardBattleIds.includes(battleId);
    },
    [progress]
  );

  // Owner saves/creates/updates a story battle
  const saveBattle = useCallback(
    async (battleData: Partial<StoryBattleDefinition>): Promise<{
      success: boolean;
      battle?: StoryBattleDefinition;
      error?: string;
    }> => {
      try {
        const res = await fetch('/api/story/battles', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify(battleData)
        });
        const data = await res.json();
        if (res.ok && data.success) {
          await refreshProgress();
          return { success: true, battle: data.battle };
        }
        return { success: false, error: data.error || 'Failed to save battle' };
      } catch (err: any) {
        return { success: false, error: err.message || 'Network error saving battle' };
      }
    },
    [refreshProgress]
  );

  // Owner saves/creates/updates a story chapter
  const saveChapter = useCallback(
    async (chapterData: Partial<StoryChapterDefinition>): Promise<{
      success: boolean;
      chapter?: StoryChapterDefinition;
      error?: string;
    }> => {
      try {
        const res = await fetch('/api/story/chapters', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify(chapterData)
        });
        const data = await res.json();
        if (res.ok && data.success) {
          await refreshProgress();
          return { success: true, chapter: data.chapter };
        }
        return { success: false, error: data.error || 'Failed to save chapter' };
      } catch (err: any) {
        return { success: false, error: err.message || 'Network error saving chapter' };
      }
    },
    [refreshProgress]
  );

  // Owner deletes a story chapter
  const deleteChapter = useCallback(
    async (chapterId: string): Promise<{ success: boolean; error?: string }> => {
      try {
        const res = await fetch(`/api/story/chapters/${encodeURIComponent(chapterId)}`, {
          method: 'DELETE',
          credentials: 'include'
        });
        const data = await res.json();
        if (res.ok && data.success) {
          await refreshProgress();
          return { success: true };
        }
        return { success: false, error: data.error || 'Failed to delete chapter' };
      } catch (err: any) {
        return { success: false, error: err.message || 'Network error deleting chapter' };
      }
    },
    [refreshProgress]
  );

  // Owner deletes a story battle
  const deleteBattle = useCallback(
    async (battleId: string): Promise<{ success: boolean; error?: string }> => {
      try {
        const res = await fetch(`/api/story/battles/${encodeURIComponent(battleId)}`, {
          method: 'DELETE',
          credentials: 'include'
        });
        const data = await res.json();
        if (res.ok && data.success) {
          await refreshProgress();
          return { success: true };
        }
        return { success: false, error: data.error || 'Failed to delete battle' };
      } catch (err: any) {
        return { success: false, error: err.message || 'Network error deleting battle' };
      }
    },
    [refreshProgress]
  );

  // Complete battle
  const completeBattle = async (
    battleId: string,
    outcome: 'VICTORY' | 'DEFEAT'
  ): Promise<{
    success: boolean;
    coinsAwarded: number;
    xpAwarded: number;
    isFirstClear: boolean;
    message: string;
    newBalance?: number;
  }> => {
    try {
      const res = await fetch('/api/story/complete-battle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ battleId, outcome })
      });
      const data = await res.json();

      if (data.success) {
        if (data.progress) {
          setProgress(data.progress);
          try {
            localStorage.setItem('nexus_user_story_progress', JSON.stringify(data.progress));
          } catch {}
        }
        await refreshProfile();
        return {
          success: true,
          coinsAwarded: data.coinsAwarded || 0,
          xpAwarded: data.xpAwarded || 0,
          isFirstClear: Boolean(data.isFirstClear),
          message: data.message || 'Battle outcome recorded',
          newBalance: data.newBalance
        };
      }

      return {
        success: false,
        coinsAwarded: 0,
        xpAwarded: 0,
        isFirstClear: false,
        message: data.error || 'Failed to submit battle result'
      };
    } catch (err: any) {
      return {
        success: false,
        coinsAwarded: 0,
        xpAwarded: 0,
        isFirstClear: false,
        message: err?.message || 'Network error submitting battle'
      };
    }
  };

  return (
    <StoryContext.Provider
      value={{
        chapters,
        progress,
        loading,
        isChapterUnlocked,
        isBattleUnlocked,
        isBattleCompleted,
        hasClaimedFirstClear,
        completeBattle,
        saveBattle,
        deleteBattle,
        saveChapter,
        deleteChapter,
        refreshProgress
      }}
    >
      {children}
    </StoryContext.Provider>
  );
};

export const useStory = () => {
  const context = useContext(StoryContext);
  if (!context) {
    throw new Error('useStory must be used within a StoryProvider');
  }
  return context;
};
