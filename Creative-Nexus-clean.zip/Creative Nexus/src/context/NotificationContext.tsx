import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { doc, onSnapshot, collection, setDoc, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from './AuthContext';
import { AppNotification, NotificationType } from '../types/notification';

export type NotificationFilter =
  | 'ALL'
  | 'UNREAD'
  | 'POINTS'
  | 'RANK'
  | 'ACHIEVEMENT'
  | 'STAFF'
  | 'ANNOUNCEMENT';

interface NotificationContextType {
  notifications: AppNotification[];
  filteredNotifications: AppNotification[];
  unreadCount: number;
  totalCount: number;
  loading: boolean;
  error: string | null;
  filter: NotificationFilter;
  setFilter: (filter: NotificationFilter) => void;
  markAsRead: (notificationId: string) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  deleteNotification: (notificationId: string) => Promise<void>;
  refreshNotifications: () => Promise<void>;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isAuthenticated } = useAuth();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<NotificationFilter>('ALL');

  // Fetch notifications from server REST API
  const refreshNotifications = useCallback(async () => {
    if (!isAuthenticated || !user) {
      setNotifications([]);
      setLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/notifications', {
        credentials: 'include',
        headers: { 'Accept': 'application/json' }
      });

      if (res.ok) {
        const data = await res.json();
        if (data && Array.isArray(data.notifications)) {
          setNotifications(data.notifications);
          setError(null);
        }
      } else {
        console.warn('GET /api/notifications response status:', res.status);
      }
    } catch (err: any) {
      console.warn('Notice: Error fetching notifications from server:', err);
      setError(err?.message || 'Failed to fetch notifications');
    } finally {
      setLoading(false);
    }
  }, [isAuthenticated, user]);

  // Initial fetch and on user change
  useEffect(() => {
    refreshNotifications();
  }, [refreshNotifications]);

  // Real-time Firestore listener for user read state
  useEffect(() => {
    if (!user || !user.discordId) return;

    let unsubscribeState: (() => void) | null = null;
    try {
      const stateDocRef = doc(db, 'user_notification_state', user.discordId);
      unsubscribeState = onSnapshot(
        stateDocRef,
        (snap) => {
          if (snap.exists()) {
            const data = snap.data();
            const readIds: string[] = Array.isArray(data.readIds) ? data.readIds : [];
            const dismissedIds: string[] = Array.isArray(data.dismissedIds) ? data.dismissedIds : [];
            const readAllBefore: string | null = data.readAllBefore || null;
            const readIdsSet = new Set(readIds);
            const dismissedSet = new Set(dismissedIds);
            const readAllTime = readAllBefore ? new Date(readAllBefore).getTime() : 0;

            setNotifications((prev) =>
              prev
                .filter((item) => !dismissedSet.has(item.id))
                .map((item) => {
                  const itemTime = new Date(item.createdAt).getTime();
                  const isRead = readIdsSet.has(item.id) || (readAllTime > 0 && itemTime <= readAllTime);
                  if (item.read !== isRead) {
                    return { ...item, read: isRead };
                  }
                  return item;
                })
            );
          }
        },
        (err) => {
          console.warn('Notice: Firestore user_notification_state snapshot notice:', err);
        }
      );
    } catch (initErr) {
      console.warn('Firestore state listener notice:', initErr);
    }

    // Also listen to rank_applications and announcements for live reactive event stream
    let unsubscribeApps: (() => void) | null = null;
    let unsubscribeAnnouncements: (() => void) | null = null;
    try {
      unsubscribeApps = onSnapshot(collection(db, 'rank_applications'), () => {
        // Trigger background refresh when rank applications change
        refreshNotifications();
      });
      unsubscribeAnnouncements = onSnapshot(collection(db, 'announcements'), () => {
        // Trigger background refresh when announcements change
        refreshNotifications();
      });
    } catch (fsErr) {
      console.warn('Firestore event listener notice:', fsErr);
    }

    return () => {
      if (unsubscribeState) unsubscribeState();
      if (unsubscribeApps) unsubscribeApps();
      if (unsubscribeAnnouncements) unsubscribeAnnouncements();
    };
  }, [user, refreshNotifications]);

  // Listen for local theme unlock event (immediate notification without waiting for network)
  useEffect(() => {
    const handleThemeUnlocked = () => {
      const newNotif: AppNotification = {
        id: `theme_unlocked_local_${Date.now()}`,
        recipientDiscordId: user?.discordId || 'guest',
        type: 'THEME_UNLOCKED',
        title: 'تم فتح ثيم جديد! / New Theme Unlocked!',
        description: 'تهانينا! لقد أنهيت اللعبة السرية وفتحت ثيم بلاد الرافدين الحصري. يمكنك تفعيله الآن من صفحة الإعدادات.',
        read: false,
        link: '/settings',
        createdAt: new Date().toISOString(),
        metadata: { theme: 'kohan-iraqi' }
      };
      setNotifications((prev) => [newNotif, ...prev.filter((n) => n.type !== 'THEME_UNLOCKED')]);
      refreshNotifications();
    };

    window.addEventListener('creatine_theme_unlocked', handleThemeUnlocked);
    return () => {
      window.removeEventListener('creatine_theme_unlocked', handleThemeUnlocked);
    };
  }, [user, refreshNotifications]);

  // Mark single notification as read
  const markAsRead = useCallback(async (notificationId: string) => {
    if (!notificationId) return;

    // Optimistic UI update
    setNotifications((prev) =>
      prev.map((item) => (item.id === notificationId ? { ...item, read: true } : item))
    );

    // Call server REST API
    try {
      await fetch('/api/notifications/mark-read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ notificationId })
      });
    } catch (apiErr) {
      console.warn('Server mark-read notice:', apiErr);
    }

    // Direct Firestore update for instant cross-device and multi-tab sync
    if (user?.discordId) {
      try {
        const stateDocRef = doc(db, 'user_notification_state', user.discordId);
        await setDoc(
          stateDocRef,
          {
            discordId: user.discordId,
            readIds: Array.from(new Set([...notifications.filter((n) => n.read).map((n) => n.id), notificationId])).slice(-200),
            updatedAt: new Date().toISOString()
          },
          { merge: true }
        );
      } catch (fsErr) {
        console.warn('Firestore state update notice:', fsErr);
      }
    }
  }, [user, notifications]);

  // Mark all notifications as read
  const markAllAsRead = useCallback(async () => {
    const nowIso = new Date().toISOString();

    // Optimistic UI update
    setNotifications((prev) => prev.map((item) => ({ ...item, read: true })));

    // Call server REST API
    try {
      await fetch('/api/notifications/mark-all-read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include'
      });
    } catch (apiErr) {
      console.warn('Server mark-all-read notice:', apiErr);
    }

    // Direct Firestore update
    if (user?.discordId) {
      try {
        const stateDocRef = doc(db, 'user_notification_state', user.discordId);
        await setDoc(
          stateDocRef,
          {
            discordId: user.discordId,
            readIds: [],
            readAllBefore: nowIso,
            updatedAt: nowIso
          },
          { merge: true }
        );
      } catch (fsErr) {
        console.warn('Firestore mark all read notice:', fsErr);
      }
    }
  }, [user]);

  // Delete / dismiss single notification
  const deleteNotification = useCallback(
    async (notificationId: string) => {
      if (!notificationId) return;

      // Optimistic UI update
      setNotifications((prev) => prev.filter((item) => item.id !== notificationId));

      // Call server REST API
      try {
        await fetch('/api/notifications/delete', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({ notificationId })
        });
      } catch (apiErr) {
        console.warn('Server notification delete notice:', apiErr);
      }

      // Direct Firestore update
      if (user?.discordId) {
        try {
          const stateDocRef = doc(db, 'user_notification_state', user.discordId);
          const snap = await getDoc(stateDocRef);
          const existingDismissed: string[] = snap.exists() && Array.isArray(snap.data().dismissedIds)
            ? snap.data().dismissedIds
            : [];
          const existingRead: string[] = snap.exists() && Array.isArray(snap.data().readIds)
            ? snap.data().readIds
            : [];
          await setDoc(
            stateDocRef,
            {
              discordId: user.discordId,
              dismissedIds: Array.from(new Set([...existingDismissed, notificationId])).slice(-300),
              readIds: Array.from(new Set([...existingRead, notificationId])).slice(-300),
              updatedAt: new Date().toISOString()
            },
            { merge: true }
          );
        } catch (fsErr) {
          console.warn('Firestore notification delete notice:', fsErr);
        }
      }
    },
    [user]
  );

  // Filter notifications based on active tab
  const filteredNotifications = useMemo(() => {
    return notifications.filter((item) => {
      switch (filter) {
        case 'UNREAD':
          return !item.read;
        case 'POINTS':
          return item.type === 'POINTS_ADDED' || item.type === 'POINTS_REMOVED';
        case 'RANK':
          return (
            item.type === 'RANK_APPLICATION_SUBMITTED' ||
            item.type === 'RANK_APPLICATION_APPROVED' ||
            item.type === 'RANK_APPLICATION_REJECTED'
          );
        case 'ACHIEVEMENT':
          return item.type === 'ACHIEVEMENT_EARNED';
        case 'STAFF':
          return item.type === 'STAFF_STATUS_CHANGED';
        case 'ANNOUNCEMENT':
          return item.type === 'ANNOUNCEMENT';
        case 'ALL':
        default:
          return true;
      }
    });
  }, [notifications, filter]);

  const unreadCount = useMemo(() => {
    return notifications.filter((item) => !item.read).length;
  }, [notifications]);

  const value = useMemo(
    () => ({
      notifications,
      filteredNotifications,
      unreadCount,
      totalCount: notifications.length,
      loading,
      error,
      filter,
      setFilter,
      markAsRead,
      markAllAsRead,
      deleteNotification,
      refreshNotifications
    }),
    [
      notifications,
      filteredNotifications,
      unreadCount,
      loading,
      error,
      filter,
      markAsRead,
      markAllAsRead,
      deleteNotification,
      refreshNotifications
    ]
  );

  return <NotificationContext.Provider value={value}>{children}</NotificationContext.Provider>;
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};
