import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  CombatRulesConfig, 
  DEFAULT_COMBAT_RULES, 
  CombatRoundRequest, 
  CombatRoundResult,
  CombatSkillDefinition,
  MatchupMatrix
} from '../types/combatRules';
import { useAuth } from './AuthContext';

interface CombatContextType {
  rules: CombatRulesConfig;
  isLoading: boolean;
  error: string | null;
  fetchRules: () => Promise<void>;
  resolveRound: (req: CombatRoundRequest) => Promise<CombatRoundResult>;
  updateRules: (newRules: Partial<CombatRulesConfig>) => Promise<boolean>;
  applyPreset: (presetName: string) => Promise<boolean>;
  saveSkill: (skill: CombatSkillDefinition) => Promise<boolean>;
  deleteSkill: (skillId: string) => Promise<boolean>;
  resetToDefaults: () => Promise<boolean>;
  activePreset: string;
}

const CombatContext = createContext<CombatContextType | null>(null);

export const CombatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [rules, setRules] = useState<CombatRulesConfig>(DEFAULT_COMBAT_RULES);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchRules = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/combat/rules');
      if (res.ok) {
        const data = await res.json();
        if (data.rules) {
          setRules(data.rules);
        }
      }
    } catch (err: any) {
      console.warn('Could not load remote combat rules, using defaults:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRules();
  }, [fetchRules]);

  // Server-authoritative round resolution
  const resolveRound = useCallback(async (req: CombatRoundRequest): Promise<CombatRoundResult> => {
    try {
      const res = await fetch('/api/combat/resolve-round', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req)
      });

      if (res.ok) {
        const data = await res.json();
        if (data.result) return data.result;
      }
    } catch (err) {
      console.warn('Server round resolution failed, fallback to client engine:', err);
    }

    // Client-side fallback if server connection interrupted
    // (Import dynamic fallback resolver)
    const { resolveCombatRound } = await import('../../server/combatEngine');
    return resolveCombatRound(req, rules);
  }, [rules]);

  const updateRules = useCallback(async (newRules: Partial<CombatRulesConfig>): Promise<boolean> => {
    try {
      const res = await fetch('/api/combat/rules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRules)
      });
      if (res.ok) {
        const data = await res.json();
        setRules(data.rules);
        return true;
      }
    } catch (err) {
      console.error('Failed to update combat rules:', err);
    }
    return false;
  }, []);

  const applyPreset = useCallback(async (presetName: string): Promise<boolean> => {
    try {
      const res = await fetch('/api/combat/preset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ presetName })
      });
      if (res.ok) {
        const data = await res.json();
        setRules(data.rules);
        return true;
      }
    } catch (err) {
      console.error('Failed to apply preset:', err);
    }
    return false;
  }, []);

  const saveSkill = useCallback(async (skill: CombatSkillDefinition): Promise<boolean> => {
    try {
      const res = await fetch('/api/combat/skills', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(skill)
      });
      if (res.ok) {
        const data = await res.json();
        setRules(prev => ({ ...prev, skills: data.skills }));
        return true;
      }
    } catch (err) {
      console.error('Failed to save skill:', err);
    }
    return false;
  }, []);

  const deleteSkill = useCallback(async (skillId: string): Promise<boolean> => {
    try {
      const res = await fetch(`/api/combat/skills/${skillId}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        const data = await res.json();
        setRules(prev => ({ ...prev, skills: data.skills }));
        return true;
      }
    } catch (err) {
      console.error('Failed to delete skill:', err);
    }
    return false;
  }, []);

  const resetToDefaults = useCallback(async (): Promise<boolean> => {
    try {
      const res = await fetch('/api/combat/reset-defaults', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setRules(data.rules);
        return true;
      }
    } catch (err) {
      console.error('Failed to reset defaults:', err);
    }
    return false;
  }, []);

  return (
    <CombatContext.Provider
      value={{
        rules,
        isLoading,
        error,
        fetchRules,
        resolveRound,
        updateRules,
        applyPreset,
        saveSkill,
        deleteSkill,
        resetToDefaults,
        activePreset: rules.presetName || 'Classic'
      }}
    >
      {children}
    </CombatContext.Provider>
  );
};

export const useCombat = () => {
  const ctx = useContext(CombatContext);
  if (!ctx) {
    throw new Error('useCombat must be used within a CombatProvider');
  }
  return ctx;
};
