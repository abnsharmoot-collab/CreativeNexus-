import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useAuth } from './AuthContext';
import {
  CollectibleCardData,
  CardRarity,
  UserCardProfile,
  CardOwnership,
  PackDefinition,
  PackOpenResult,
  CoinTransaction
} from '../types/cards';
import { PlayerProfileData, ProfileCustomizePayload } from '../types/progression';
import { CARD_PACKS, DEFAULT_COLLECTIBLE_CARDS } from '../data/defaultCards';

interface CardContextType {
  profile: UserCardProfile | null;
  playerProfile: PlayerProfileData | null;
  coins: number;
  isUnlimitedCoins: boolean;
  catalog: CollectibleCardData[];
  cards: CollectibleCardData[];
  packs: PackDefinition[];
  loading: boolean;
  canClaimDaily: boolean;
  nextClaimInMs: number;
  isClaimingDaily: boolean;
  claimDaily: () => Promise<{ success: boolean; message: string }>;
  isOpeningPack: boolean;
  activePackType: CardRarity | null;
  lastOpenedResult: PackOpenResult | null;
  buyAndOpenPack: (packType: CardRarity) => Promise<PackOpenResult>;
  clearPackModal: () => void;
  toggleShowcase: (cardId: string) => Promise<boolean>;
  isCardShowcased: (cardId: string) => boolean;
  getCardOwnership: (cardId: string) => CardOwnership | undefined;
  refreshProfile: () => Promise<void>;
  customizeProfile: (payload: ProfileCustomizePayload) => Promise<PlayerProfileData>;
  fetchPlayerProfile: (discordId: string) => Promise<PlayerProfileData | null>;
  setFavoriteCard: (cardId: string | null) => Promise<boolean>;
  updateShowcaseCards: (cardIds: string[]) => Promise<boolean>;
  setSelectedTitle: (titleId: string | null) => Promise<boolean>;
  setFeaturedBadges: (badgeIds: string[]) => Promise<boolean>;
  selectedCardForDetail: CollectibleCardData | null;
  setSelectedCardForDetail: (card: CollectibleCardData | null) => void;
  fetchCatalog: () => Promise<void>;
  ownerGiveCoins: (targetDiscordId: string, amount: number, reason?: string) => Promise<any>;
  ownerSaveCard: (cardData: Partial<CollectibleCardData>) => Promise<any>;
  ownerImportCards: (cardsData: any, itemsData?: any[]) => Promise<{ success: boolean; count: number; cards: CollectibleCardData[]; itemsCount?: number; savedCards?: any[] }>;
  ownerDeleteCard: (cardId: string) => Promise<any>;
  ownerBulkDeleteCards: (cardIds: string[]) => Promise<any>;
  ownerDeleteAllCards: () => Promise<any>;
  ownerRestoreDefaultCards: () => Promise<any>;
  ownerSavePackImages: (packImages: Record<string, string>) => Promise<any>;
  ownerSavePackCustomizations: (packCustomizations: Record<string, { name?: string; imageUrl?: string; openImageUrl?: string }>) => Promise<any>;
  cardBackImageUrl: string;
  ownerSaveCardBackImage: (url: string) => Promise<any>;
  globalRatingSettings: { fontSize: number; offsetX: number; offsetY: number };
  ownerSaveGlobalRatingSettings: (settings: { fontSize: number; offsetX: number; offsetY: number }) => Promise<any>;
}

const CardContext = createContext<CardContextType | undefined>(undefined);

export const CardProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isAuthenticated, isOwner } = useAuth();
  const [profile, setProfile] = useState<UserCardProfile | null>(null);
  const [playerProfile, setPlayerProfile] = useState<PlayerProfileData | null>(null);
  const [catalog, setCatalog] = useState<CollectibleCardData[]>(DEFAULT_COLLECTIBLE_CARDS);
  const [packs, setPacks] = useState<PackDefinition[]>(CARD_PACKS);
  const [loading, setLoading] = useState<boolean>(true);
  const [isClaimingDaily, setIsClaimingDaily] = useState<boolean>(false);
  const [isOpeningPack, setIsOpeningPack] = useState<boolean>(false);
  const [activePackType, setActivePackType] = useState<CardRarity | null>(null);
  const [lastOpenedResult, setLastOpenedResult] = useState<PackOpenResult | null>(null);
  const [selectedCardForDetail, setSelectedCardForDetail] = useState<CollectibleCardData | null>(null);
  const [nextClaimInMs, setNextClaimInMs] = useState<number>(0);
  const [globalRatingSettings, setGlobalRatingSettings] = useState<{ fontSize: number; offsetX: number; offsetY: number }>(() => {
    try {
      const stored = localStorage.getItem('nexus_global_card_rating_settings');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (typeof parsed?.fontSize === 'number') {
          return {
            fontSize: parsed.fontSize,
            offsetX: parsed.offsetX ?? 16,
            offsetY: parsed.offsetY ?? 14,
          };
        }
      }
    } catch {}
    return { fontSize: 24, offsetX: 16, offsetY: 14 };
  });
  const [cardBackImageUrl, setCardBackImageUrl] = useState<string>(() => {
    try {
      return localStorage.getItem('nexus_card_back_png') || '';
    } catch {
      return '';
    }
  });

  // Fetch card back image from backend
  useEffect(() => {
    fetch('/api/cards/card-back')
      .then(r => r.json())
      .then(data => {
        if (data.success && typeof data.imageUrl === 'string') {
          setCardBackImageUrl(data.imageUrl);
          try {
            localStorage.setItem('nexus_card_back_png', data.imageUrl);
          } catch {}
        }
      })
      .catch(() => {});
  }, []);

  const ownerSaveCardBackImage = useCallback(async (url: string) => {
    setCardBackImageUrl(url);
    try {
      localStorage.setItem('nexus_card_back_png', url);
    } catch {}
    const res = await fetch('/api/cards/owner/card-back', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ imageUrl: url })
    });
    return res.json();
  }, []);

  // Fetch catalog of cards and packs
  const fetchCatalog = useCallback(async () => {
    try {
      const res = await fetch('/api/cards/catalog');
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.cards)) {
          setCatalog(data.cards);
        }
        if (Array.isArray(data.packs) && data.packs.length > 0) {
          setPacks(data.packs);
        }
        if (data.ratingSettings && typeof data.ratingSettings.fontSize === 'number') {
          setGlobalRatingSettings(data.ratingSettings);
          try {
            localStorage.setItem('nexus_global_card_rating_settings', JSON.stringify(data.ratingSettings));
          } catch {}
        }
      }
    } catch (err) {
      console.warn('Could not fetch dynamic card catalog, using defaults:', err);
    }
  }, []);

  // Fetch user profile & coins
  const refreshProfile = useCallback(async () => {
    if (!isAuthenticated || !user) {
      setProfile(null);
      setPlayerProfile(null);
      setLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/cards/me', { credentials: 'include' });
      if (res.ok) {
        const data = await res.json();
        if (data.profile) {
          setProfile(data.profile);
          if (data.profile.lastDailyClaim) {
            const last = new Date(data.profile.lastDailyClaim).getTime();
            const elapsed = Date.now() - last;
            const cooldown = 24 * 60 * 60 * 1000;
            if (elapsed < cooldown) {
              setNextClaimInMs(cooldown - elapsed);
            } else {
              setNextClaimInMs(0);
            }
          } else {
            setNextClaimInMs(0);
          }
        }
        if (data.playerProfile) {
          setPlayerProfile(data.playerProfile);
        }
      }
    } catch (err) {
      console.warn('Could not fetch user card profile:', err);
    } finally {
      setLoading(false);
    }
  }, [isAuthenticated, user?.discordId]);

  const fetchPlayerProfile = useCallback(async (discordId: string): Promise<PlayerProfileData | null> => {
    try {
      const res = await fetch(`/api/cards/profile/${encodeURIComponent(discordId)}`, { credentials: 'include' });
      if (res.ok) {
        const data = await res.json();
        if (data.profile) {
          if (user && user.discordId === discordId) {
            setPlayerProfile(data.profile);
          }
          return data.profile;
        }
      }
    } catch (err) {
      console.warn('Failed to fetch player profile:', err);
    }
    return null;
  }, [user?.discordId]);

  const customizeProfile = useCallback(async (payload: ProfileCustomizePayload): Promise<PlayerProfileData> => {
    const res = await fetch('/api/cards/profile/customize', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to update player profile');
    }
    if (data.profile) {
      setPlayerProfile(data.profile);
      setProfile(prev => prev ? ({
        ...prev,
        favoriteCardId: data.profile.favoriteCardId,
        showcaseCardIds: data.profile.showcaseCardIds,
        selectedTitleId: data.profile.selectedTitleId,
        featuredBadgeIds: data.profile.featuredBadgeIds,
        bannerUrl: data.profile.bannerUrl,
        xp: data.profile.xp,
        level: data.profile.level,
      }) : null);
    }
    return data.profile;
  }, []);

  const setFavoriteCard = useCallback(async (cardId: string | null): Promise<boolean> => {
    try {
      await customizeProfile({ favoriteCardId: cardId });
      return true;
    } catch (err: any) {
      alert(err.message || 'Failed to update favorite card');
      return false;
    }
  }, [customizeProfile]);

  const updateShowcaseCards = useCallback(async (cardIds: string[]): Promise<boolean> => {
    try {
      await customizeProfile({ showcaseCardIds: cardIds });
      return true;
    } catch (err: any) {
      alert(err.message || 'Failed to update showcase');
      return false;
    }
  }, [customizeProfile]);

  const setSelectedTitle = useCallback(async (titleId: string | null): Promise<boolean> => {
    try {
      await customizeProfile({ selectedTitleId: titleId });
      return true;
    } catch (err: any) {
      alert(err.message || 'Failed to select title');
      return false;
    }
  }, [customizeProfile]);

  const setFeaturedBadges = useCallback(async (badgeIds: string[]): Promise<boolean> => {
    try {
      await customizeProfile({ featuredBadgeIds: badgeIds });
      return true;
    } catch (err: any) {
      alert(err.message || 'Failed to feature badges');
      return false;
    }
  }, [customizeProfile]);

  useEffect(() => {
    fetchCatalog();
  }, [fetchCatalog]);

  useEffect(() => {
    refreshProfile();
  }, [refreshProfile]);

  // Live countdown timer for daily claim cooldown
  useEffect(() => {
    if (nextClaimInMs <= 0) return;
    const interval = setInterval(() => {
      setNextClaimInMs(prev => {
        if (prev <= 1000) return 0;
        return prev - 1000;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [nextClaimInMs]);

  // Daily Claim Action
  const claimDaily = useCallback(async (): Promise<{ success: boolean; message: string }> => {
    if (!isAuthenticated) {
      return { success: false, message: 'Please log in with Discord first.' };
    }
    setIsClaimingDaily(true);
    try {
      const res = await fetch('/api/cards/daily-claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include'
      });
      const data = await res.json();
      if (!res.ok) {
        if (data.nextClaimInMs) {
          setNextClaimInMs(data.nextClaimInMs);
        }
        return { success: false, message: data.error || 'Failed to claim daily reward' };
      }

      setNextClaimInMs(data.nextClaimInMs || 24 * 60 * 60 * 1000);
      await refreshProfile();
      return { success: true, message: data.message || `+${data.coinsAwarded} Coins Claimed!` };
    } catch (err: any) {
      return { success: false, message: err?.message || 'Network error claiming reward' };
    } finally {
      setIsClaimingDaily(false);
    }
  }, [isAuthenticated, refreshProfile]);

  // Buy and Open Pack Action
  const buyAndOpenPack = useCallback(async (packType: CardRarity): Promise<PackOpenResult> => {
    const isOwnerUser = Boolean(
      isOwner ||
      profile?.isUnlimitedCoins ||
      (user?.discordId && ['871043296280076308', '831102094521532418', '1099135885699727460', '1306936292197797929', '1371864097523765358'].includes(String(user.discordId))) ||
      user?.isOwner ||
      user?.role === 'OWNER'
    );

    if (!isAuthenticated && !isOwnerUser) {
      throw new Error('Please log in with Discord first to buy packs.');
    }
    setIsOpeningPack(true);
    setActivePackType(packType);
    try {
      const res = await fetch('/api/cards/open-pack', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-as-owner': isOwnerUser ? 'true' : 'false'
        },
        credentials: 'include',
        body: JSON.stringify({ packType, asOwner: isOwnerUser })
      });
      const data: PackOpenResult = await res.json();
      if (!res.ok) {
        throw new Error((data as any).error || 'Failed to open pack');
      }

      setLastOpenedResult(data);
      // Update local profile state
      setProfile(prev => {
        if (!prev) return null;
        return {
          ...prev,
          coins: isOwnerUser ? 999999999 : data.remainingCoins,
          isUnlimitedCoins: isOwnerUser ? true : prev.isUnlimitedCoins,
          cards: data.cards,
          totalPacksOpened: (prev.totalPacksOpened || 0) + 1
        };
      });

      return data;
    } catch (err: any) {
      setIsOpeningPack(false);
      setActivePackType(null);
      throw err;
    }
  }, [isAuthenticated, isOwner, profile?.isUnlimitedCoins, user]);

  const clearPackModal = useCallback(() => {
    setIsOpeningPack(false);
    setActivePackType(null);
    setLastOpenedResult(null);
  }, []);

  // Toggle card in showcase
  const toggleShowcase = useCallback(async (cardId: string): Promise<boolean> => {
    if (!isAuthenticated) return false;
    try {
      const res = await fetch('/api/cards/showcase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ cardId })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to update showcase');
      }
      setProfile(prev => {
        if (!prev) return null;
        return {
          ...prev,
          showcaseCardIds: data.showcaseCardIds
        };
      });
      return data.isShowcased;
    } catch (err: any) {
      alert(err.message || 'Error updating showcase');
      return false;
    }
  }, [isAuthenticated]);

  const isCardShowcased = useCallback((cardId: string): boolean => {
    if (!profile || !profile.showcaseCardIds) return false;
    return profile.showcaseCardIds.includes(cardId);
  }, [profile]);

  const getCardOwnership = useCallback((cardId: string): CardOwnership | undefined => {
    if (!profile || !profile.cards) return undefined;
    return profile.cards[cardId];
  }, [profile]);

  // Owner Actions
  const ownerGiveCoins = useCallback(async (targetDiscordId: string, amount: number, reason?: string) => {
    const res = await fetch('/api/cards/owner/give-coins', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ targetDiscordId, amount, reason })
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to grant coins');
    }
    await refreshProfile();
    return data;
  }, [refreshProfile]);

  const ownerSaveCard = useCallback(async (cardData: Partial<CollectibleCardData>) => {
    const res = await fetch('/api/cards/owner/manage-card', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(cardData)
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to save card');
    }
    await fetchCatalog();
    return data.card;
  }, [fetchCatalog]);

  const ownerImportCards = useCallback(async (cardsData: any, itemsData?: any[]) => {
    let listCards: any[] = [];
    let listItems: any[] = Array.isArray(itemsData) ? itemsData : [];

    if (Array.isArray(cardsData)) {
      listCards = cardsData;
    } else if (cardsData && typeof cardsData === 'object') {
      if (Array.isArray(cardsData.cards)) listCards = cardsData.cards;
      else if (Array.isArray(cardsData.catalog)) listCards = cardsData.catalog;
      else listCards = [cardsData];

      if (listItems.length === 0 && Array.isArray(cardsData.items)) {
        listItems = cardsData.items;
      }
    }

    const res = await fetch('/api/cards/owner/import-cards', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-as-owner': 'true'
      },
      credentials: 'include',
      body: JSON.stringify({
        cards: listCards,
        items: listItems,
        asOwner: true
      })
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Failed to import cards into database');
    }
    if (Array.isArray(data.cards) && data.cards.length > 0) {
      setCatalog(data.cards);
    }
    await fetchCatalog();
    return data;
  }, [fetchCatalog]);

  const ownerDeleteCard = useCallback(async (cardId: string) => {
    setCatalog(prev => prev.filter(c => c.id !== cardId));
    const res = await fetch(`/api/cards/owner/cards/${encodeURIComponent(cardId)}?asOwner=true`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        'x-as-owner': 'true'
      },
      credentials: 'include'
    });
    const data = await res.json();
    if (!res.ok) {
      await fetchCatalog();
      throw new Error(data.error || 'Failed to delete card');
    }
    await fetchCatalog();
    return data;
  }, [fetchCatalog]);

  const ownerBulkDeleteCards = useCallback(async (cardIds: string[]) => {
    const toDeleteSet = new Set(cardIds);
    setCatalog(prev => prev.filter(c => !toDeleteSet.has(c.id)));
    const res = await fetch('/api/cards/owner/bulk-delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ cardIds })
    });
    const data = await res.json();
    if (!res.ok) {
      await fetchCatalog();
      throw new Error(data.error || 'Failed to bulk delete cards');
    }
    await fetchCatalog();
    return data;
  }, [fetchCatalog]);

  const ownerDeleteAllCards = useCallback(async () => {
    setCatalog([]);
    const res = await fetch('/api/cards/owner/delete-all', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include'
    });
    const data = await res.json();
    if (!res.ok) {
      await fetchCatalog();
      throw new Error(data.error || 'Failed to clear all cards');
    }
    await fetchCatalog();
    return data;
  }, [fetchCatalog]);

  const ownerRestoreDefaultCards = useCallback(async () => {
    const res = await fetch('/api/cards/owner/restore-defaults', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include'
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to restore default cards');
    }
    await fetchCatalog();
    return data;
  }, [fetchCatalog]);

  const ownerSavePackImages = useCallback(async (packImages: Record<string, string>) => {
    const res = await fetch('/api/cards/owner/pack-images', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ packImages })
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to update pack artwork');
    }
    if (Array.isArray(data.packs)) {
      setPacks(data.packs);
    }
    return data.packs;
  }, []);

  const ownerSavePackCustomizations = useCallback(async (packCustomizations: Record<string, { name?: string; imageUrl?: string; openImageUrl?: string }>) => {
    const res = await fetch('/api/cards/owner/pack-customizations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ packCustomizations })
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to update pack customizations');
    }
    if (Array.isArray(data.packs)) {
      setPacks(data.packs);
    }
    return data.packs;
  }, []);

  const ownerSaveGlobalRatingSettings = useCallback(async (settings: { fontSize: number; offsetX: number; offsetY: number }) => {
    setGlobalRatingSettings(settings);
    try {
      localStorage.setItem('nexus_global_card_rating_settings', JSON.stringify(settings));
    } catch {}

    // Immediately update all cards in catalog in client memory
    setCatalog(prev => prev.map(c => ({
      ...c,
      ratingFontSize: settings.fontSize,
      ratingOffsetX: settings.offsetX,
      ratingOffsetY: settings.offsetY,
    })));

    try {
      const res = await fetch('/api/cards/owner/rating-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(settings)
      });
      const data = await res.json();
      if (data.success && data.ratingSettings) {
        setGlobalRatingSettings(data.ratingSettings);
        if (Array.isArray(data.cards)) {
          setCatalog(data.cards);
        }
      }
      return data;
    } catch (err) {
      console.warn('Could not persist global rating settings to server, saved locally:', err);
    }
  }, []);

  const isUnlimitedCoins = Boolean(
    isOwner ||
    profile?.isUnlimitedCoins ||
    (user?.discordId && ['871043296280076308', '831102094521532418', '1099135885699727460', '1306936292197797929', '1371864097523765358'].includes(String(user.discordId))) ||
    user?.isOwner ||
    user?.role === 'OWNER'
  );
  const coins = isUnlimitedCoins ? 999999999 : (profile ? profile.coins : 0);
  const canClaimDaily = Boolean(profile ? nextClaimInMs <= 0 : true);

  return (
    <CardContext.Provider
      value={{
        profile,
        playerProfile,
        coins,
        isUnlimitedCoins,
        catalog,
        cards: catalog,
        packs,
        loading,
        canClaimDaily,
        nextClaimInMs,
        isClaimingDaily,
        claimDaily,
        isOpeningPack,
        activePackType,
        lastOpenedResult,
        buyAndOpenPack,
        clearPackModal,
        toggleShowcase,
        isCardShowcased,
        getCardOwnership,
        refreshProfile,
        customizeProfile,
        fetchPlayerProfile,
        setFavoriteCard,
        updateShowcaseCards,
        setSelectedTitle,
        setFeaturedBadges,
        selectedCardForDetail,
        setSelectedCardForDetail,
        fetchCatalog,
        ownerGiveCoins,
        ownerSaveCard,
        ownerImportCards,
        ownerDeleteCard,
        ownerBulkDeleteCards,
        ownerDeleteAllCards,
        ownerRestoreDefaultCards,
        ownerSavePackImages,
        ownerSavePackCustomizations,
        cardBackImageUrl,
        ownerSaveCardBackImage,
        globalRatingSettings,
        ownerSaveGlobalRatingSettings
      }}
    >
      {children}
    </CardContext.Provider>
  );
};

export const useCards = () => {
  const context = useContext(CardContext);
  if (!context) {
    throw new Error('useCards must be used within a CardProvider');
  }
  return context;
};
