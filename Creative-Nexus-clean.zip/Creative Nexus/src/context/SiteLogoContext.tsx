import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

export interface SiteLogoSettings {
  mode: 'vector' | 'image';
  titleEn: string;
  titleAr: string;
  subtitleEn: string;
  subtitleAr: string;
  showSubtitle: boolean;
  imageUrl?: string;
  iconType?: 'dual_star' | 'nexus_core' | 'crown' | 'dragon' | 'shield';
  accentColor?: string;
  gradientFrom?: string;
  gradientTo?: string;
  glowIntensity?: 'subtle' | 'radiant' | 'blazing';
  updatedBy?: string;
  updatedAt?: string;
}

export const DEFAULT_SITE_LOGO: SiteLogoSettings = {
  mode: 'vector',
  titleEn: 'Creative Nexus',
  titleAr: 'مركز الإبداع',
  subtitleEn: 'COMMUNITY PORTAL // NEXUS',
  subtitleAr: 'CREATIVE NEXUS // شبكة الإبداع',
  showSubtitle: true,
  imageUrl: '',
  iconType: 'dual_star',
  accentColor: '#5eead4',
  gradientFrom: '#ffffff',
  gradientTo: '#2dd4bf',
  glowIntensity: 'radiant'
};

const STORAGE_KEY = 'creative_nexus_site_logo_v1';

interface SiteLogoContextType {
  logoSettings: SiteLogoSettings;
  isLoading: boolean;
  updateLogoSettings: (newSettings: Partial<SiteLogoSettings>) => Promise<boolean>;
  resetLogoSettings: () => Promise<boolean>;
}

const SiteLogoContext = createContext<SiteLogoContextType>({
  logoSettings: DEFAULT_SITE_LOGO,
  isLoading: false,
  updateLogoSettings: async () => false,
  resetLogoSettings: async () => false,
});

export const SiteLogoProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [logoSettings, setLogoSettings] = useState<SiteLogoSettings>(() => {
    try {
      const cached = localStorage.getItem(STORAGE_KEY);
      if (cached) {
        return { ...DEFAULT_SITE_LOGO, ...JSON.parse(cached) };
      }
    } catch {}
    return DEFAULT_SITE_LOGO;
  });
  const [isLoading, setIsLoading] = useState(false);

  // Fetch live site logo from server
  const fetchLogo = useCallback(async () => {
    try {
      const res = await fetch('/api/settings/site-logo');
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.logo) {
          const merged = { ...DEFAULT_SITE_LOGO, ...data.logo };
          setLogoSettings(merged);
          try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
          } catch {}
        }
      }
    } catch (err) {
      console.warn('Could not fetch site logo settings:', err);
    }
  }, []);

  useEffect(() => {
    fetchLogo();
  }, [fetchLogo]);

  const updateLogoSettings = useCallback(async (newSettings: Partial<SiteLogoSettings>): Promise<boolean> => {
    setIsLoading(true);
    const merged = { ...logoSettings, ...newSettings };
    // Optimistically update React state and local storage immediately
    setLogoSettings(merged);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
    } catch {}

    try {
      const res = await fetch('/api/settings/site-logo', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-as-owner': 'true'
        },
        credentials: 'include',
        body: JSON.stringify({ ...merged, asOwner: true })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.logo) {
          const finalLogo = { ...DEFAULT_SITE_LOGO, ...data.logo };
          setLogoSettings(finalLogo);
          try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(finalLogo));
          } catch {}
        }
      }
      return true;
    } catch (err) {
      console.warn('Network sync notice for site logo (saved locally):', err);
      return true; // Still true because saved locally and applied
    } finally {
      setIsLoading(false);
    }
  }, [logoSettings]);

  const resetLogoSettings = useCallback(async (): Promise<boolean> => {
    setIsLoading(true);
    setLogoSettings(DEFAULT_SITE_LOGO);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_SITE_LOGO));
    } catch {}

    try {
      const res = await fetch('/api/settings/site-logo/reset', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-as-owner': 'true'
        },
        credentials: 'include',
        body: JSON.stringify({ asOwner: true })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.logo) {
          const finalLogo = { ...DEFAULT_SITE_LOGO, ...data.logo };
          setLogoSettings(finalLogo);
          try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(finalLogo));
          } catch {}
        }
      }
      return true;
    } catch (err) {
      console.warn('Reset notice (reset locally):', err);
      return true;
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <SiteLogoContext.Provider
      value={{
        logoSettings,
        isLoading,
        updateLogoSettings,
        resetLogoSettings,
      }}
    >
      {children}
    </SiteLogoContext.Provider>
  );
};

export const useSiteLogo = () => useContext(SiteLogoContext);
