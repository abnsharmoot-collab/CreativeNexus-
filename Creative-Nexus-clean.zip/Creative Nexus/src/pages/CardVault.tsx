import React, { useState, useMemo, useEffect } from 'react';
import { useLocation, useSearchParams, Link } from 'react-router-dom';
import { useCards } from '../context/CardContext';
import { useItems } from '../context/ItemContext';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { PackItemCard } from '../components/cards/PackItemCard';
import { CollectibleCard } from '../components/cards/CollectibleCard';
import { PackOpeningModal } from '../components/cards/PackOpeningModal';
import { CardDetailModal } from '../components/cards/CardDetailModal';
import { OwnerCoinManagementModal } from '../components/cards/OwnerCoinManagementModal';
import { OwnerCardStudioModal } from '../components/cards/OwnerCardStudioModal';
import { OwnerPackArtworkModal } from '../components/cards/OwnerPackArtworkModal';
import { OwnerRevealAudioModal } from '../components/cards/OwnerRevealAudioModal';
import { LegendaryCombatAudioModal } from '../components/cards/LegendaryCombatAudioModal';
import { OwnerUnifiedItemManagerModal } from '../components/items/OwnerUnifiedItemManagerModal';
import { PlayerInventoryModal } from '../components/items/PlayerInventoryModal';
import { PackDefinition, CardRarity, CollectibleCardData } from '../types/cards';
import { useEasterEggs } from '../context/EasterEggContext';
import {
  ShoppingBag, Layers, Star, Shield, Sparkles, Search,
  Filter, Plus, Trophy, Coins, RefreshCw, Image as ImageIcon,
  HelpCircle, X, Clock, CheckCircle2,
  Edit3, Trash2, Film, Zap, AlertTriangle, Music,
  CheckSquare, Square, AlertOctagon, RotateCcw, Palette,
  Crown, Play, Flame, Award, Swords, HardDrive, FileUp, Download,
  Backpack
} from 'lucide-react';
import { MesopotamianCornerBrackets } from '../components/atoms/MesopotamianCornerBrackets';
import { easterEggSound } from '../utils/easterEggAudio';
import { MODERN_CARD_ASSETS } from '../assets/modernCardAssets';
import { CARD_PACKS } from '../data/defaultCards';
import { DownloadHtmlButton } from '../components/export/DownloadHtmlButton';

type VaultTab = 'shop' | 'collection' | 'showcase' | 'management';

interface CardVaultProps {
  initialTab?: VaultTab;
}

export const CardVault: React.FC<CardVaultProps> = ({ initialTab }) => {
  const location = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();
  const {
    profile,
    coins,
    catalog,
    packs,
    loading,
    buyAndOpenPack,
    isOpeningPack,
    activePackType,
    lastOpenedResult,
    clearPackModal,
    selectedCardForDetail,
    setSelectedCardForDetail,
    refreshProfile,
    canClaimDaily,
    nextClaimInMs,
    isClaimingDaily,
    claimDaily,
    ownerDeleteCard,
    ownerBulkDeleteCards,
    ownerDeleteAllCards,
    ownerRestoreDefaultCards,
    ownerImportCards,
    fetchCatalog
  } = useCards();

  const { items: allUnifiedItems, importOwnerItems, fetchItems: refreshVaultItems } = useItems();
  const { isAuthenticated, isOwner, loginWithDiscord } = useAuth();
  const { t, language } = useLanguage();
  const { activeTheme } = useEasterEggs();
  const isRtl = language === 'ar';
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  const resolveTabFromUrl = (): VaultTab => {
    if (initialTab) return initialTab;
    const tabParam = searchParams.get('tab');
    if (tabParam === 'management' || tabParam === 'manage') return 'management';
    if (tabParam === 'collection') return 'collection';
    if (tabParam === 'showcase') return 'showcase';
    if (tabParam === 'shop') return 'shop';
    if (location.pathname.includes('/cards/management') || location.pathname.includes('/card-management')) return 'management';
    if (location.pathname.includes('/cards/collection')) return 'collection';
    if (location.pathname.includes('/cards/showcase')) return 'showcase';
    return 'shop';
  };

  const [activeTab, setActiveTab] = useState<VaultTab>(resolveTabFromUrl);

  useEffect(() => {
    const desired = resolveTabFromUrl();
    if (desired === 'management') {
      if (isOwner) {
        setActiveTab('management');
      }
    } else {
      setActiveTab(desired);
    }
  }, [location.pathname, searchParams, isOwner, initialTab]);
  const [selectedRarityFilter, setSelectedRarityFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'rarity_desc' | 'rarity_asc' | 'name' | 'number' | 'copies'>('rarity_desc');
  const [showOwnedOnly, setShowOwnedOnly] = useState<boolean>(false);
  const [isOddsModalOpen, setIsOddsModalOpen] = useState<boolean>(false);
  const [dailyFeedback, setDailyFeedback] = useState<string | null>(null);

  // Owner Card Management Filtering & Actions
  const [ownerSearchQuery, setOwnerSearchQuery] = useState<string>('');
  const [ownerRarityFilter, setOwnerRarityFilter] = useState<string>('ALL');
  const [ownerStatusFilter, setOwnerStatusFilter] = useState<'ALL' | 'ACTIVE' | 'INACTIVE'>('ALL');
  const [cardActionFeedback, setCardActionFeedback] = useState<string | null>(null);
  const [isDeletingCard, setIsDeletingCard] = useState<string | null>(null);
  const [cardToDeleteSingle, setCardToDeleteSingle] = useState<CollectibleCardData | null>(null);
  const [selectedCardIds, setSelectedCardIds] = useState<Set<string>>(new Set());
  const [showBulkDeleteModal, setShowBulkDeleteModal] = useState<boolean>(false);
  const [isBulkDeleting, setIsBulkDeleting] = useState<boolean>(false);
  const [isDeletingAll, setIsDeletingAll] = useState<boolean>(false);
  const [showDeleteAllConfirmModal, setShowDeleteAllConfirmModal] = useState<boolean>(false);
  const [showRestoreDefaultsModal, setShowRestoreDefaultsModal] = useState<boolean>(false);
  const [isRestoringDefaults, setIsRestoringDefaults] = useState<boolean>(false);

  // Selected Pack Index for Tab Navigation
  const [selectedPackIndex, setSelectedPackIndex] = useState<number>(0);

  // Modals state
  const [isCoinManageOpen, setIsCoinManageOpen] = useState(false);
  const [isStudioOpen, setIsStudioOpen] = useState(false);
  const [isPackArtworkOpen, setIsPackArtworkOpen] = useState(false);
  const [isRevealAudioOpen, setIsRevealAudioOpen] = useState(false);
  const [isLegendaryAudioModalOpen, setIsLegendaryAudioModalOpen] = useState(false);
  const [isUnifiedItemsOpen, setIsUnifiedItemsOpen] = useState(false);
  const [isPlayerInventoryOpen, setIsPlayerInventoryOpen] = useState(false);
  const [cardToEdit, setCardToEdit] = useState<CollectibleCardData | null>(null);

  // User collection stats
  const ownedCardsMap = profile?.cards || {};
  const allCatalog = Array.isArray(catalog) ? catalog : [];
  const totalUniqueCards = allCatalog.length;
  const ownedUniqueCount = Object.keys(ownedCardsMap).filter(id => (ownedCardsMap[id]?.count || 0) > 0).length;
  const collectionPercentage = totalUniqueCards > 0 ? Math.round((ownedUniqueCount / totalUniqueCards) * 100) : 0;

  // Daily tribute countdown
  const hours = Math.floor(nextClaimInMs / (1000 * 60 * 60));
  const minutes = Math.floor((nextClaimInMs % (1000 * 60 * 60)) / (1000 * 60));

  const handleClaimTribute = async () => {
    if (!isAuthenticated) {
      loginWithDiscord();
      return;
    }
    try {
      easterEggSound.playAccessGrantedSound();
    } catch {}
    const res = await claimDaily();
    setDailyFeedback(res.message);
    setTimeout(() => setDailyFeedback(null), 3500);
  };

  // Filtered & Sorted Collection Cards
  const processedCards = useMemo(() => {
    let result = [...catalog];

    if (selectedRarityFilter !== 'ALL') {
      result = result.filter(c => c.rarity === selectedRarityFilter);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(c =>
        c.name.toLowerCase().includes(q) ||
        c.title.toLowerCase().includes(q) ||
        c.element.toLowerCase().includes(q) ||
        c.series.toLowerCase().includes(q)
      );
    }

    if (showOwnedOnly) {
      result = result.filter(c => (ownedCardsMap[c.id]?.count || 0) > 0);
    }

    const rarityWeights: Record<CardRarity, number> = {
      HALLOWEEN_2026: 6,
      LEGENDARY: 5,
      EPIC: 4,
      RARE: 3,
      UNCOMMON: 2,
      COMMON: 1
    };

    result.sort((a, b) => {
      if (sortBy === 'rarity_desc') {
        const diff = (rarityWeights[b.rarity] || 0) - (rarityWeights[a.rarity] || 0);
        return diff !== 0 ? diff : a.cardNumber - b.cardNumber;
      }
      if (sortBy === 'rarity_asc') {
        const diff = (rarityWeights[a.rarity] || 0) - (rarityWeights[b.rarity] || 0);
        return diff !== 0 ? diff : a.cardNumber - b.cardNumber;
      }
      if (sortBy === 'name') {
        return a.name.localeCompare(b.name);
      }
      if (sortBy === 'copies') {
        const countA = ownedCardsMap[a.id]?.count || 0;
        const countB = ownedCardsMap[b.id]?.count || 0;
        return countB - countA;
      }
      return a.cardNumber - b.cardNumber;
    });

    return result;
  }, [catalog, selectedRarityFilter, searchQuery, showOwnedOnly, sortBy, ownedCardsMap]);

  // Showcase cards
  const showcaseCards = useMemo(() => {
    const showcaseIds = profile?.showcaseCardIds || [];
    return showcaseIds
      .map(id => catalog.find(c => c.id === id))
      .filter((c): c is CollectibleCardData => Boolean(c));
  }, [profile, catalog]);

  // Featured Legendary card for Spotlight display
  const featuredRelic = useMemo(() => {
    return catalog.find(c => c.rarity === 'LEGENDARY') || catalog[0] || null;
  }, [catalog]);

  // Filtered cards for Owner Management
  const ownerFilteredCards = useMemo(() => {
    let result = [...catalog];
    if (ownerRarityFilter !== 'ALL') {
      result = result.filter(c => c.rarity === ownerRarityFilter);
    }
    if (ownerStatusFilter === 'ACTIVE') {
      result = result.filter(c => c.isActive !== false);
    } else if (ownerStatusFilter === 'INACTIVE') {
      result = result.filter(c => c.isActive === false);
    }
    if (ownerSearchQuery.trim()) {
      const q = ownerSearchQuery.toLowerCase().trim();
      result = result.filter(c =>
        c.name.toLowerCase().includes(q) ||
        c.title.toLowerCase().includes(q) ||
        (c.series && c.series.toLowerCase().includes(q)) ||
        c.id.toLowerCase().includes(q)
      );
    }
    return result;
  }, [catalog, ownerRarityFilter, ownerStatusFilter, ownerSearchQuery]);

  const handleInitiateSingleDelete = (card: CollectibleCardData) => {
    setCardToDeleteSingle(card);
  };

  const confirmSingleDelete = async () => {
    if (!cardToDeleteSingle) return;
    const target = cardToDeleteSingle;
    setIsDeletingCard(target.id);
    try {
      const res = await ownerDeleteCard(target.id);
      setSelectedCardIds(prev => {
        const next = new Set(prev);
        next.delete(target.id);
        return next;
      });
      setCardActionFeedback(res?.message || `Card "${target.name}" was permanently removed from catalog.`);
      setCardToDeleteSingle(null);
      setTimeout(() => setCardActionFeedback(null), 3500);
    } catch (err: any) {
      setCardActionFeedback(`Failed to delete card: ${err.message}`);
      setTimeout(() => setCardActionFeedback(null), 4000);
    } finally {
      setIsDeletingCard(null);
    }
  };

  const handleToggleCardSelection = (cardId: string) => {
    setSelectedCardIds(prev => {
      const next = new Set(prev);
      if (next.has(cardId)) {
        next.delete(cardId);
      } else {
        next.add(cardId);
      }
      return next;
    });
  };

  const handleSelectAllFiltered = () => {
    if (selectedCardIds.size === ownerFilteredCards.length && ownerFilteredCards.length > 0) {
      setSelectedCardIds(new Set());
    } else {
      setSelectedCardIds(new Set(ownerFilteredCards.map(c => c.id)));
    }
  };

  const handleInitiateBulkDelete = () => {
    if (selectedCardIds.size === 0) return;
    setShowBulkDeleteModal(true);
  };

  const confirmBulkDelete = async () => {
    if (selectedCardIds.size === 0) return;
    const count = selectedCardIds.size;
    setIsBulkDeleting(true);
    try {
      const res = await ownerBulkDeleteCards(Array.from(selectedCardIds));
      setCardActionFeedback(res?.message || `Successfully removed ${count} card(s) from catalog.`);
      setSelectedCardIds(new Set());
      setShowBulkDeleteModal(false);
      setTimeout(() => setCardActionFeedback(null), 3500);
    } catch (err: any) {
      setCardActionFeedback(`Failed to delete cards: ${err.message}`);
      setTimeout(() => setCardActionFeedback(null), 4000);
    } finally {
      setIsBulkDeleting(false);
    }
  };

  const confirmDeleteAllCards = async () => {
    setIsDeletingAll(true);
    try {
      const res = await ownerDeleteAllCards();
      setCardActionFeedback(res?.message || 'All cards have been cleared from the catalog.');
      setSelectedCardIds(new Set());
      setShowDeleteAllConfirmModal(false);
      setTimeout(() => setCardActionFeedback(null), 3500);
    } catch (err: any) {
      setCardActionFeedback(`Failed to clear cards: ${err.message}`);
      setTimeout(() => setCardActionFeedback(null), 4000);
    } finally {
      setIsDeletingAll(false);
    }
  };

  const confirmRestoreDefaults = async () => {
    setIsRestoringDefaults(true);
    try {
      const res = await ownerRestoreDefaultCards();
      setCardActionFeedback(res?.message || 'Starter relic cards restored to catalog.');
      setShowRestoreDefaultsModal(false);
      setTimeout(() => setCardActionFeedback(null), 3500);
    } catch (err: any) {
      setCardActionFeedback(`Failed to restore default cards: ${err.message}`);
      setTimeout(() => setCardActionFeedback(null), 4000);
    } finally {
      setIsRestoringDefaults(false);
    }
  };

  const handleOpenPack = async (pack: PackDefinition) => {
    if (!isAuthenticated) {
      loginWithDiscord();
      return;
    }
    try {
      easterEggSound.playFlagFoundSound();
    } catch {}
    try {
      await buyAndOpenPack(pack.rarity);
    } catch (err: any) {
      alert(err.message || 'Failed to open pack');
    }
  };

  const bulkImportInputRef = React.useRef<HTMLInputElement>(null);
  const [isBulkImporting, setIsBulkImporting] = useState(false);

  const handleExportAllCards = () => {
    // Export full active catalog with complete fidelity (cards + items sync)
    const cardsToExport = Array.isArray(catalog) && catalog.length > 0 ? catalog : [];
    const itemsToExport = Array.isArray(allUnifiedItems) && allUnifiedItems.length > 0 ? allUnifiedItems : [];
    const exportPayload = {
      app: 'Creative Nexus Sovereign Card Studio',
      version: 2,
      backupType: 'full_catalog_backup',
      exportedAt: new Date().toISOString(),
      count: cardsToExport.length,
      cards: cardsToExport,
      items: itemsToExport,
      itemsCount: itemsToExport.length
    };
    const jsonStr = JSON.stringify(exportPayload, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `nexus-all-cards-items-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setCardActionFeedback(
      itemsToExport.length > 0
        ? `Successfully exported all ${cardsToExport.length} cards and ${itemsToExport.length} items to backup file!`
        : `Successfully exported all ${cardsToExport.length} cards to backup file!`
    );
    setTimeout(() => setCardActionFeedback(null), 4000);
  };

  const handleBulkImportFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsBulkImporting(true);
    try {
      const text = await file.text();
      let parsed: any;
      try {
        parsed = JSON.parse(text);
      } catch {
        throw new Error('Invalid JSON file format. Please upload a valid JSON backup file.');
      }

      let cardsToImport: any[] = [];
      let itemsToImport: any[] = [];

      // Extract items if present
      if (Array.isArray(parsed?.items)) {
        itemsToImport = parsed.items;
      } else if (Array.isArray(parsed?.gameItems)) {
        itemsToImport = parsed.gameItems;
      }

      if (Array.isArray(parsed)) {
        cardsToImport = parsed;
      } else if (parsed && typeof parsed === 'object') {
        if (Array.isArray(parsed.cards)) {
          cardsToImport = parsed.cards;
        } else if (Array.isArray(parsed.catalog)) {
          cardsToImport = parsed.catalog;
        } else if (Array.isArray(parsed.data)) {
          cardsToImport = parsed.data;
        } else if (Array.isArray(parsed.items) && !parsed.cards) {
          // If only items array is at top level
          itemsToImport = parsed.items;
        } else if (Array.isArray(parsed.cardList)) {
          cardsToImport = parsed.cardList;
        } else if (Array.isArray(parsed.customCards)) {
          cardsToImport = parsed.customCards;
        } else if (Array.isArray(parsed.cardsToExport)) {
          cardsToImport = parsed.cardsToExport;
        } else if (Array.isArray(parsed.allCards)) {
          cardsToImport = parsed.allCards;
        } else if (parsed.backup && typeof parsed.backup === 'object' && Array.isArray(parsed.backup.cards)) {
          cardsToImport = parsed.backup.cards;
        } else if (parsed.name && typeof parsed.name === 'string') {
          cardsToImport = [parsed];
        } else {
          // Check for dictionary object e.g. { "card_1": {...}, "card_2": {...} }
          const values = Object.values(parsed);
          const cardLike = values.filter((v: any) => v && typeof v === 'object' && (v.name || v.id || v.title));
          if (cardLike.length > 0) {
            cardsToImport = cardLike;
          }
        }
      }

      // Import items if present in backup file
      let importedItemsCount = 0;
      if (itemsToImport.length > 0) {
        try {
          const itemRes = await importOwnerItems(itemsToImport);
          importedItemsCount = itemRes?.count || itemsToImport.length;
          await refreshVaultItems();
        } catch (itemErr: any) {
          console.warn('Notice importing items from backup:', itemErr);
        }
      }

      if (cardsToImport.length > 0) {
        const result = await ownerImportCards(cardsToImport);
        await fetchCatalog();
        const count = result?.count ?? (Array.isArray(result?.savedCards) ? result.savedCards.length : cardsToImport.length);
        setCardActionFeedback(
          importedItemsCount > 0
            ? `✅ Successfully restored & imported ${count} card(s) and ${importedItemsCount} item(s) into catalog!`
            : `✅ Successfully restored & imported ${count} card(s) into the catalog with all attributes preserved!`
        );
      } else if (importedItemsCount > 0) {
        setCardActionFeedback(`✅ Successfully restored & imported ${importedItemsCount} item(s) into catalog!`);
      } else {
        throw new Error('No readable cards or items found in this file. Please verify the JSON structure.');
      }

      setTimeout(() => setCardActionFeedback(null), 6000);
    } catch (err: any) {
      alert(`Error importing backup: ${err.message || 'Unknown error'}`);
    } finally {
      setIsBulkImporting(false);
      if (bulkImportInputRef.current) {
        bulkImportInputRef.current.value = '';
      }
    }
  };

  const activePackDef = activePackType ? packs.find(p => p.rarity === activePackType) || null : null;

  return (
    <div
      className={`w-full max-w-full sm:max-w-6xl mx-auto min-w-0 box-border px-4 sm:px-6 lg:px-8 py-4 sm:py-6 space-y-4 sm:space-y-6 relative min-h-screen overflow-x-hidden ${
        isMesopotamian ? 'text-amber-100' : 'text-[#eafffa]'
      }`}
      style={{ boxSizing: 'border-box' }}
    >
      {/* ============================================================ */}
      {/* 3D VOLUMETRIC GRADIENT AMBIENCE                              */}
      {/* ============================================================ */}
      <div className="absolute inset-0 pointer-events-none select-none overflow-hidden max-w-full" aria-hidden="true">
        <div className="absolute top-[5%] start-1/2 -translate-x-1/2 w-full max-w-[500px] h-[300px] bg-gradient-to-b from-[#5eead4]/10 via-teal-500/5 to-transparent blur-[120px] rounded-full" />
      </div>

      {/* ============================================================ */}
      {/* STREAMLINED LUXURY HEADER & LIVE STATUS HUD                  */}
      {/* ============================================================ */}
      <div className="relative z-10 pt-1 space-y-3 w-full max-w-full min-w-0 box-border">
        {/* Title & Brand Kicker */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2.5 w-full max-w-full min-w-0 box-border">
          <div className="w-full max-w-full min-w-0 box-border">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold font-display tracking-tight text-[#eafffa] drop-shadow-sm">
              CARD VAULT
            </h1>
            <p className="text-xs sm:text-sm text-slate-300/85 leading-relaxed w-full max-w-xl min-w-0 break-words whitespace-normal mt-0.5">
              Sovereign relics & booster packs.
            </p>
          </div>

          {/* Quick Odds & Sync Controls */}
          <div className="flex items-center gap-2 self-start sm:self-auto shrink-0 w-full sm:w-auto justify-between sm:justify-end pt-1 sm:pt-0">
            <button
              type="button"
              onClick={() => setIsPlayerInventoryOpen(true)}
              className="px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold bg-[#140b20] hover:bg-[#201234] text-purple-300 border border-purple-500/40 flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs whitespace-nowrap"
              title="Inspect Upgrade Shards & Items"
            >
              <Backpack size={13} className="text-purple-400 shrink-0" />
              <span>{isRtl ? 'الحقيبة والشظايا' : 'Shards & Bag'}</span>
            </button>

            <button
              type="button"
              onClick={() => setIsOddsModalOpen(true)}
              className="px-3.5 py-1.5 rounded-xl text-xs font-mono font-bold bg-[#051d1b] hover:bg-[#0d3834] text-[#5eead4] border border-[#2dd4bf]/30 flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs whitespace-nowrap"
            >
              <HelpCircle size={13} className="shrink-0" />
              <span>Drop Rates</span>
            </button>

            <button
              type="button"
              onClick={() => refreshProfile()}
              title="Refresh Vault Data"
              className="p-2 rounded-xl bg-[#051d1b] hover:bg-[#0d3834] text-stone-400 hover:text-[#5eead4] border border-white/10 transition-colors cursor-pointer shrink-0"
            >
              <RefreshCw size={13} className={loading ? 'animate-spin' : ''} />
            </button>
          </div>
        </div>

        {/* UNIFIED COMMAND HUD BAR (Sovereign Treasury, Daily Tribute Claim, Collection Mastery) */}
        <div className="relative rounded-3xl bg-gradient-to-b from-[#09221f]/95 via-[#041211]/98 to-[#020908]/98 border border-amber-500/30 p-3.5 sm:p-5 shadow-[0_15px_50px_rgba(0,0,0,0.85),0_0_30px_rgba(245,158,11,0.08)] flex flex-col md:flex-row md:items-center justify-between gap-4 w-full max-w-full min-w-0 box-border overflow-hidden">
          {/* Top Hairline Metallic Bevel */}
          <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-amber-400/70 to-transparent pointer-events-none" />

          {/* Left: Enhanced Physical 3D Sovereign Coin & Treasury Balance */}
          <div className="flex items-center justify-between sm:justify-start gap-4 min-w-0">
            <div className="flex items-center gap-3 min-w-0">
              {/* Pure Sovereign Coin */}
              <div className="relative shrink-0 flex items-center justify-center">
                <span className="text-3xl sm:text-4xl select-none filter drop-shadow-[0_4px_12px_rgba(245,158,11,0.55)] transition-transform hover:scale-110 duration-200">
                  🪙
                </span>
              </div>

              {/* Balance Title */}
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-mono font-bold tracking-wider text-amber-300/90 uppercase">
                    {isRtl ? 'رصيد العملات' : 'Treasury Balance'}
                  </span>
                </div>

                <div className="flex items-baseline gap-1.5 mt-0.5">
                  <span className="text-2xl sm:text-3xl font-display font-black tracking-tight bg-gradient-to-r from-white via-amber-200 to-amber-400 bg-clip-text text-transparent drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)] tabular-nums">
                    {coins.toLocaleString()}
                  </span>
                  <span className="text-[11px] font-mono font-extrabold text-amber-400 tracking-wider uppercase">
                    COINS
                  </span>
                </div>
              </div>
            </div>

            {/* Mobile Mastery Progress Tag */}
            <div className="md:hidden text-end min-w-0">
              <span className="text-xs font-mono font-bold text-[#5eead4] tabular-nums block">
                {ownedUniqueCount}/{totalUniqueCards}
              </span>
              <span className="text-[10px] font-mono text-stone-400">
                {collectionPercentage}% {isRtl ? 'مجمعة' : 'Collected'}
              </span>
            </div>
          </div>

          {/* Center: Daily Reward Claim */}
          <div className="flex items-center gap-2.5 flex-wrap w-full md:w-auto justify-start md:justify-center">
            {!isAuthenticated ? (
              <button
                type="button"
                onClick={loginWithDiscord}
                className="w-full sm:w-auto px-4 py-2.5 rounded-2xl text-xs font-display font-extrabold uppercase bg-[#5865F2] hover:bg-[#4752C4] text-white flex items-center justify-center gap-2 shadow-md cursor-pointer box-border transition-transform active:scale-95"
              >
                <Sparkles size={14} />
                <span>Login with Discord (+20 🪙)</span>
              </button>
            ) : canClaimDaily ? (
              <button
                type="button"
                disabled={isClaimingDaily}
                onClick={handleClaimTribute}
                className="w-full sm:w-auto px-5 py-2.5 rounded-2xl text-xs font-display font-black uppercase bg-gradient-to-r from-amber-400 via-[#f6d98a] to-yellow-500 hover:brightness-110 text-stone-950 flex items-center justify-center gap-2 shadow-lg shadow-amber-500/30 transition-all active:scale-95 cursor-pointer box-border animate-pulse"
              >
                <Sparkles size={15} className="shrink-0" />
                <span>{isRtl ? 'استلام المكافأة اليومية (+20 🪙)' : 'Claim Daily Tribute (+20 🪙)'}</span>
              </button>
            ) : (
              <div className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 rounded-2xl bg-black/60 border border-white/10 text-xs font-mono text-stone-300 box-border">
                <CheckCircle2 size={14} className="text-emerald-400 shrink-0" />
                <span className="text-emerald-400 font-bold">{isRtl ? 'تم الاستلام' : 'Daily Claimed'}</span>
                <span className="text-stone-400 flex items-center gap-1 ms-1 text-[11px] truncate">
                  <Clock size={12} className="text-[#f6d98a] shrink-0" />
                  {hours}h {minutes}m
                </span>
              </div>
            )}

            {dailyFeedback && (
              <span className="text-[10px] text-[#f6d98a] font-mono italic truncate">
                {dailyFeedback}
              </span>
            )}
          </div>

          {/* Right: Collection Progress (Desktop) */}
          <div className="hidden md:flex items-center gap-3.5 min-w-0 shrink-0">
            <div className="text-end">
              <span className="text-xs font-mono font-black text-[#5eead4] tabular-nums block">
                {ownedUniqueCount}/{totalUniqueCards} {isRtl ? 'بطاقة' : 'Cards'}
              </span>
              <span className="text-[10px] font-mono text-stone-400">
                {collectionPercentage}% {isRtl ? 'إتقان' : 'Mastered'}
              </span>
            </div>
            <div className="w-24 sm:w-28 h-2.5 bg-stone-900/90 rounded-full overflow-hidden p-[1px] border border-white/15 shrink-0 shadow-inner">
              <div
                className="h-full bg-gradient-to-r from-[#14b8a6] via-[#5eead4] to-[#f6d98a] rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(94,234,212,0.6)]"
                style={{ width: `${collectionPercentage}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* LUXURY FLOATING SEGMENTED TAB MENU                           */}
      {/* ============================================================ */}
      <div
        className="relative z-10 w-full max-w-full min-w-0 box-border overflow-x-auto overflow-y-hidden no-scrollbar pb-1"
        style={{ WebkitOverflowScrolling: 'touch' }}
      >
        <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-black/60 backdrop-blur-xl border border-white/10 shadow-[0_8px_30px_rgba(0,0,0,0.6)] w-max min-w-full">
          <button
            type="button"
            onClick={() => setActiveTab('shop')}
            className={`px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-xl font-display font-extrabold text-xs uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 box-border ${
              activeTab === 'shop'
                ? 'bg-gradient-to-r from-[#5eead4] via-[#2dd4bf] to-[#14b8a6] text-stone-950 shadow-lg shadow-[#5eead4]/30 font-black'
                : 'text-stone-400 hover:text-[#5eead4] hover:bg-white/5'
            }`}
          >
            <ShoppingBag size={14} className="shrink-0" />
            <span>Booster Shop</span>
            <span className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full ${
              activeTab === 'shop' ? 'bg-stone-950/20 text-stone-950' : 'bg-white/10 text-stone-300'
            }`}>
              {packs.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('collection')}
            className={`px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-xl font-display font-extrabold text-xs uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 box-border ${
              activeTab === 'collection'
                ? 'bg-gradient-to-r from-[#5eead4] via-[#2dd4bf] to-[#14b8a6] text-stone-950 shadow-lg shadow-[#5eead4]/30 font-black'
                : 'text-stone-400 hover:text-[#5eead4] hover:bg-white/5'
            }`}
          >
            <Layers size={14} className="shrink-0" />
            <span>Collection</span>
            <span className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full ${
              activeTab === 'collection' ? 'bg-stone-950/20 text-stone-950' : 'bg-white/10 text-stone-300'
            }`}>
              {ownedUniqueCount}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('showcase')}
            className={`px-4 py-2.5 rounded-xl font-display font-extrabold text-xs uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 box-border ${
              activeTab === 'showcase'
                ? 'bg-gradient-to-r from-[#5eead4] via-[#2dd4bf] to-[#14b8a6] text-stone-950 shadow-lg shadow-[#5eead4]/30 font-black'
                : 'text-stone-400 hover:text-[#5eead4] hover:bg-white/5'
            }`}
          >
            <Star size={14} className="shrink-0" />
            <span>Showcase Hall</span>
            <span className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full ${
              activeTab === 'showcase' ? 'bg-stone-950/20 text-stone-950' : 'bg-white/10 text-stone-300'
            }`}>
              {showcaseCards.length}/5
            </span>
          </button>

          <Link
            to="/card-upgrade"
            className="px-4 py-2.5 rounded-xl font-display font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 box-border text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.2)]"
          >
            <Sparkles size={14} className="text-emerald-400 shrink-0" />
            <span>Card Upgrade</span>
            <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300">
              Ascend
            </span>
          </Link>


          {isOwner && (
            <button
              type="button"
              onClick={() => setActiveTab('management')}
              className={`px-4 py-2.5 rounded-xl font-display font-black text-xs uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 box-border ${
                activeTab === 'management'
                  ? 'bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-500 text-stone-950 shadow-lg shadow-amber-500/25'
                  : 'text-amber-300 border border-amber-500/30 hover:bg-amber-950/40'
              }`}
            >
              <Crown size={14} className="shrink-0" />
              <span>Card Studio</span>
              <span className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-full ${
                activeTab === 'management' ? 'bg-stone-950/20 text-stone-950' : 'bg-amber-500/20 text-amber-200'
              }`}>
                Owner
              </span>
            </button>
          )}

          {/* Standalone HTML Website Download Button */}
          <div className="ms-auto shrink-0 ps-2">
            <DownloadHtmlButton variant="compact" />
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: CARD SHOP                                                          */}
      {/* ========================================================================= */}
      {activeTab === 'shop' && (
        <div className="pt-2 sm:pt-4 space-y-6 w-full max-w-full min-w-0 box-border">
          {/* Shop Hero Banner */}
          <div className="relative rounded-3xl bg-gradient-to-r from-[#031d20]/95 via-[#021416]/98 to-[#0b1f24]/95 border border-[rgba(158,255,230,0.22)] p-4 sm:p-5 shadow-xl overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h2 className="text-xl sm:text-2xl font-display font-black text-white tracking-tight">
                Packages Shop Center
              </h2>
            </div>

            <div className="flex items-center gap-2.5 flex-wrap justify-center shrink-0">
              <button
                type="button"
                onClick={() => setIsOddsModalOpen(true)}
                className="px-3.5 py-2 rounded-xl font-mono font-bold text-xs bg-black/60 hover:bg-black/90 text-[#5eead4] border border-[#2dd4bf]/40 flex items-center gap-1.5 cursor-pointer transition-colors"
              >
                <HelpCircle size={13} />
                <span>Drop Rates</span>
              </button>
            </div>
          </div>

          {/* ======================================================= */}
          {/* RESPONSIVE BOOSTER PACKS GRID                           */}
          {/* Desktop: 3 cards/row | Tablet: 2/row | Mobile: 1/row    */}
          {/* ======================================================= */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-6 sm:gap-6 lg:gap-8 justify-items-center w-full max-w-full min-w-0 box-border">
            {packs.map((pack, idx) => (
              <div
                key={pack.id}
                id={`pack-card-${pack.rarity.toLowerCase()}`}
                className={`w-full flex justify-center ${
                  idx === 3
                    ? 'lg:col-span-2 lg:col-start-2'
                    : idx === 4
                    ? 'sm:col-span-2 lg:col-span-2'
                    : 'lg:col-span-2'
                }`}
              >
                <PackItemCard
                  pack={pack}
                  userCoins={coins}
                  onOpenPack={handleOpenPack}
                  isLoading={isOpeningPack && activePackType === pack.rarity}
                  onShowOdds={() => setIsOddsModalOpen(true)}
                />
              </div>
            ))}
          </div>

          {/* CREATIVE NEXUS HIGHLIGHT: Vault Spotlight Relic */}
          {featuredRelic && (
            <div className="mt-6 p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-[#031d20]/90 via-[#021214]/95 to-[#031d20]/90 border border-[rgba(158,255,230,0.18)] shadow-md flex flex-col md:flex-row items-center justify-between gap-3.5 w-full max-w-full min-w-0 box-border overflow-hidden">
              <div className="flex items-center gap-3 w-full md:w-auto min-w-0">
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl overflow-hidden border border-amber-500/40 shrink-0 shadow-sm">
                  <img
                    src={featuredRelic?.imageUrl || MODERN_CARD_ASSETS.cardApexSovereign}
                    alt={featuredRelic?.name || 'Vault Spotlight Relic'}
                    className="w-full h-full object-cover"
                    style={{ maxWidth: '100%', height: 'auto' }}
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[9px] font-mono uppercase font-bold text-amber-300 bg-amber-950/70 border border-amber-500/40 px-1.5 py-0.2 rounded shrink-0">
                      VAULT SPOTLIGHT
                    </span>
                    <span className="text-[10px] font-mono text-stone-400 shrink-0">
                      {featuredRelic.rarity} RELIC
                    </span>
                  </div>
                  <h4 className="text-xs sm:text-sm font-serif font-bold text-[#eafffa] truncate">
                    {featuredRelic.name}
                  </h4>
                  <p className="text-[10px] text-[#8db8b1] truncate italic">
                    "{featuredRelic.title}"
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full md:w-auto justify-end shrink-0 min-w-0">
                <button
                  type="button"
                  onClick={() => {
                    const legendaryPack = packs.find(p => p.rarity === 'LEGENDARY') || packs[packs.length - 1];
                    if (legendaryPack) handleOpenPack(legendaryPack);
                  }}
                  className="flex-1 md:flex-initial px-3.5 py-1.5 rounded-xl text-xs font-serif font-bold text-stone-950 bg-gradient-to-r from-amber-400 via-[#f6d98a] to-amber-500 hover:brightness-110 flex items-center justify-center gap-1.5 shadow-sm transition-transform active:scale-95 cursor-pointer box-border truncate"
                >
                  <Sparkles size={12} className="shrink-0" />
                  <span className="truncate">Unseal Gold</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: MY COLLECTION                                                      */}
      {/* ========================================================================= */}
      {activeTab === 'collection' && (
        <div className="space-y-4 w-full max-w-full min-w-0 box-border">
          {/* Filters & Search Controls */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-xl bg-black/40 border border-white/10 w-full max-w-full min-w-0 box-border">
            {/* Rarity Buttons with isolated horizontal scroll */}
            <div
              className="w-full lg:w-auto max-w-full min-w-0 overflow-x-auto overflow-y-hidden no-scrollbar"
              style={{ WebkitOverflowScrolling: 'touch' }}
            >
              <div className="flex items-center gap-1 w-max min-w-full pb-0.5">
                {['ALL', 'COMMON', 'UNCOMMON', 'RARE', 'EPIC', 'LEGENDARY'].map((rarity) => (
                  <button
                    key={rarity}
                    type="button"
                    onClick={() => setSelectedRarityFilter(rarity)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold uppercase tracking-wider transition-colors whitespace-nowrap cursor-pointer shrink-0 box-border ${
                      selectedRarityFilter === rarity
                        ? 'bg-[#5eead4] text-stone-950 font-bold'
                        : 'bg-stone-900 text-stone-400 hover:text-[#5eead4]'
                    }`}
                  >
                    {rarity}
                  </button>
                ))}
              </div>
            </div>

            {/* Search, Sort, Owned Toggle */}
            <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto justify-between lg:justify-end min-w-0">
              <div className="relative min-w-[120px] flex-1 sm:flex-initial">
                <Search size={12} className="absolute start-2.5 top-2.5 text-stone-500" />
                <input
                  type="text"
                  placeholder="Search relics..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full ps-7 pe-2 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-xs text-[#eafffa] placeholder-stone-500 focus:outline-hidden focus:border-[#5eead4] box-border"
                />
              </div>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-2 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-xs text-[#f6d98a] font-mono focus:outline-hidden focus:border-[#5eead4] box-border shrink-0"
              >
                <option value="rarity_desc">Rarity: High to Low</option>
                <option value="rarity_asc">Rarity: Low to High</option>
                <option value="number">Catalog #</option>
                <option value="name">Name (A-Z)</option>
                <option value="copies">Copies Owned</option>
              </select>

              <button
                type="button"
                onClick={() => setShowOwnedOnly(prev => !prev)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-mono font-bold flex items-center gap-1 transition-colors cursor-pointer shrink-0 box-border ${
                  showOwnedOnly
                    ? 'bg-amber-950/80 text-amber-300 border border-amber-500/50'
                    : 'bg-stone-900 text-stone-400 border border-stone-800 hover:text-stone-200'
                }`}
              >
                <Filter size={11} className="shrink-0" />
                <span className="truncate">{showOwnedOnly ? 'Owned Only' : 'All'}</span>
              </button>
            </div>
          </div>

          {/* Cards Grid */}
          {processedCards.length === 0 ? (
            <div className="py-12 text-center text-stone-500 space-y-2 w-full">
              <Layers size={28} className="mx-auto text-stone-600 mb-1" />
              <p className="text-sm font-serif">No cards match the current search filters.</p>
              <button
                type="button"
                onClick={() => {
                  setSelectedRarityFilter('ALL');
                  setSearchQuery('');
                  setShowOwnedOnly(false);
                }}
                className="text-xs text-[#5eead4] hover:underline font-mono cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 min-[460px]:grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 sm:gap-4.5 w-full max-w-full min-w-0 box-border">
              {processedCards.map((card) => {
                const count = ownedCardsMap[card.id]?.count || 0;
                const isOwned = count > 0;
                return (
                  <CollectibleCard
                    key={card.id}
                    card={card}
                    isOwned={isOwned}
                    duplicateCount={count}
                    isShowcased={profile?.showcaseCardIds?.includes(card.id)}
                    onClickDetail={() => setSelectedCardForDetail(card)}
                    size="compact"
                  />
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: ROYAL SHOWCASE                                                     */}
      {/* ========================================================================= */}
      {activeTab === 'showcase' && (
        <div className="space-y-4 w-full max-w-full min-w-0 box-border">
          <div className="text-center max-w-md mx-auto space-y-1 w-full px-2">
            <h2 className="text-lg sm:text-xl font-black font-serif text-[#eafffa]">
              ROYAL SHOWCASE
            </h2>
            <p className="text-xs text-stone-400">
              Pin up to 5 of your most prized sovereign relics to this royal dais.
            </p>
          </div>

          {showcaseCards.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-black/40 border border-white/10 max-w-md mx-auto space-y-3 w-full box-border">
              <Star size={24} className="text-[#f6d98a] mx-auto opacity-70" />
              <h3 className="text-sm font-bold font-serif text-[#eafffa]">
                Your Showcase is Empty
              </h3>
              <p className="text-xs text-stone-400">
                Browse your collection, inspect your favorite relics, and tap "Pin to Showcase".
              </p>
              <button
                type="button"
                onClick={() => setActiveTab('collection')}
                className="px-4 py-2 rounded-xl font-bold font-serif text-xs uppercase bg-[#5eead4] text-stone-950 hover:bg-teal-300 transition-colors cursor-pointer"
              >
                Browse Collection
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 w-full max-w-full min-w-0 box-border">
              {showcaseCards.map((card) => {
                const count = ownedCardsMap[card.id]?.count || 1;
                return (
                  <div key={card.id} className="flex flex-col items-center min-w-0 w-full">
                    <CollectibleCard
                      card={card}
                      isOwned={true}
                      duplicateCount={count}
                      isShowcased={true}
                      onClickDetail={() => setSelectedCardForDetail(card)}
                      size="compact"
                    />
                    <div className="mt-1.5 px-2.5 py-0.5 rounded-full text-[9px] font-mono text-[#f6d98a] bg-amber-950/60 border border-amber-500/40 truncate max-w-full">
                      Featured Relic
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: OWNER CARD MANAGEMENT // تعديل الكروت                                */}
      {/* ========================================================================= */}
      {activeTab === 'management' && isOwner && (
        <div className="space-y-5 w-full max-w-full min-w-0 box-border">
          {/* Sovereign Management Master Banner */}
          <div className="p-5 sm:p-7 rounded-3xl bg-gradient-to-b from-[#052423]/95 via-[#031718]/98 to-[#010c0e]/98 border border-[#5eead4]/25 shadow-2xl relative overflow-hidden box-border">
            {/* Top Hairline Metallic Bevel */}
            <div className="absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#5eead4]/70 to-transparent pointer-events-none" />

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-5 pb-5 border-b border-white/10 relative z-10">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#5eead4]/10 border border-[#5eead4]/30 text-[#5eead4] text-xs font-mono mb-2">
                  <Crown size={13} />
                  <span>Card Studio · إدارة وصياغة البطاقات</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black font-sans text-white tracking-wide">
                  Card Studio
                </h2>
                <p className="text-xs text-teal-200/70 mt-0.5">
                  Forge, curate, and customize cards with full control.
                </p>
              </div>

              {/* Action Suite - Simple & Mobile Optimized */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                {/* Primary CTA */}
                <button
                  type="button"
                  onClick={() => {
                    setCardToEdit(null);
                    setIsStudioOpen(true);
                  }}
                  className="w-full sm:w-auto px-6 py-2.5 rounded-full font-bold font-mono text-xs uppercase tracking-wider bg-gradient-to-r from-[#5eead4] via-teal-300 to-[#2dd4bf] hover:brightness-110 text-stone-950 flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-teal-500/25 transition-all active:scale-95"
                >
                  <Plus size={16} className="font-extrabold" />
                  <span>+ Forge New Card</span>
                </button>

                {/* Secondary Tools Horizontal Pill Dock (Smooth horizontal scroll on mobile) */}
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => setIsPackArtworkOpen(true)}
                    className="px-3.5 py-2 rounded-full font-bold font-mono text-xs bg-[#052123] hover:bg-[#093539] text-[#5eead4] border border-[#5eead4]/30 flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 whitespace-nowrap shrink-0"
                    title="Packs Art"
                  >
                    <ImageIcon size={13} />
                    <span>Packs</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsCoinManageOpen(true)}
                    className="px-3.5 py-2 rounded-full font-bold font-mono text-xs bg-[#241703] hover:bg-[#3d2705] text-amber-300 border border-amber-500/40 flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 whitespace-nowrap shrink-0"
                    title="Economy & Coins"
                  >
                    <Coins size={13} />
                    <span>Coins</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsUnifiedItemsOpen(true)}
                    className="px-3.5 py-2 rounded-full font-bold font-mono text-xs bg-[#1a0f2e] hover:bg-[#2c1a4e] text-purple-300 border border-purple-500/40 flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 whitespace-nowrap shrink-0 shadow-[0_0_12px_rgba(168,85,247,0.3)]"
                    title="Unified Items & Duplicate Cards Rewards"
                  >
                    <Layers size={13} className="text-purple-400" />
                    <span>{isRtl ? 'العناصر والمكررات' : 'Items & Duplicates'}</span>
                  </button>

                  {/* Hidden JSON file input for importing all cards in one file */}
                  <input
                    type="file"
                    ref={bulkImportInputRef}
                    accept=".json,application/json"
                    className="hidden"
                    onChange={handleBulkImportFileChange}
                  />

                  {/* Import / Export JSON buttons */}
                  <button
                    type="button"
                    disabled={isBulkImporting}
                    onClick={() => bulkImportInputRef.current?.click()}
                    className="px-3 py-2 rounded-full font-bold font-mono text-xs bg-[#051c22] hover:bg-[#092d37] text-teal-300 border border-teal-500/30 flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 disabled:opacity-50 whitespace-nowrap shrink-0"
                    title="Import JSON"
                  >
                    <FileUp size={13} className={isBulkImporting ? 'animate-bounce' : ''} />
                    <span>Import</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleExportAllCards}
                    className="px-3 py-2 rounded-full font-bold font-mono text-xs bg-[#051c22] hover:bg-[#092d37] text-teal-300 border border-teal-500/30 flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 whitespace-nowrap shrink-0"
                    title="Export JSON"
                  >
                    <HardDrive size={13} />
                    <span>Export</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsRevealAudioOpen(true)}
                    className="p-2 rounded-full bg-[#120826] hover:bg-[#1f0f42] text-purple-300 border border-purple-500/40 flex items-center justify-center cursor-pointer transition-all active:scale-95 shrink-0"
                    title="Pack Reveal Audio SFX"
                  >
                    <Music size={13} />
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowRestoreDefaultsModal(true)}
                    className="p-2 rounded-full bg-[#032128] hover:bg-[#063743] text-cyan-300 border border-cyan-500/40 flex items-center justify-center cursor-pointer transition-all active:scale-95 shrink-0"
                    title="Restore default cards"
                  >
                    <RotateCcw size={13} />
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowDeleteAllConfirmModal(true)}
                    className="p-2 rounded-full bg-[#26080c] hover:bg-[#400e15] text-rose-300 border border-rose-500/40 flex items-center justify-center cursor-pointer transition-all active:scale-95 shrink-0"
                    title="Clear catalog"
                  >
                    <Trash2 size={13} />
                  </button>

                  <button
                    type="button"
                    onClick={async () => {
                      await fetchCatalog();
                      setCardActionFeedback('Synced with database!');
                      setTimeout(() => setCardActionFeedback(null), 2500);
                    }}
                    className="p-2 rounded-full bg-[#052123] hover:bg-[#093539] text-[#5eead4] border border-[#5eead4]/30 flex items-center justify-center cursor-pointer transition-all active:scale-95 shrink-0"
                    title="Refresh Catalog"
                  >
                    <RefreshCw size={13} />
                  </button>
                </div>
              </div>
            </div>

            {/* Compact Metrics Pill Bar - Rounded-full & Clean */}
            <div className="flex items-center gap-2 pt-3 flex-wrap text-xs font-mono text-teal-200/80">
              <span className="px-3 py-1 rounded-full bg-black/60 border border-[#5eead4]/20 shadow-xs">
                <strong className="text-amber-300 font-bold">{catalog.length}</strong> Total Cards
              </span>
              <span className="px-3 py-1 rounded-full bg-black/60 border border-[#5eead4]/20 shadow-xs">
                <strong className="text-emerald-400 font-bold">{catalog.filter(c => c.isActive !== false).length}</strong> Active
              </span>
              <span className="px-3 py-1 rounded-full bg-black/60 border border-[#5eead4]/20 shadow-xs">
                <strong className="text-cyan-300 font-bold">{catalog.filter(c => c.isCustom).length}</strong> Custom
              </span>
              <span className="px-3 py-1 rounded-full bg-black/60 border border-[#5eead4]/20 ms-auto shadow-xs">
                <strong className="text-amber-300 font-bold">{coins.toLocaleString()}</strong> 🪙
              </span>
            </div>
          </div>

          {/* Action Feedback Banner */}
          {cardActionFeedback && (
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/90 via-[#04241d] to-emerald-950/90 border border-emerald-500/50 text-emerald-200 text-xs sm:text-sm flex items-center justify-between shadow-lg">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 size={18} className="text-emerald-400 shrink-0" />
                <span className="font-medium">{cardActionFeedback}</span>
              </div>
              <button
                type="button"
                onClick={() => setCardActionFeedback(null)}
                className="text-stone-400 hover:text-white cursor-pointer p-1"
              >
                <X size={15} />
              </button>
            </div>
          )}

          {/* Cards Search & Rarity Filter Bar */}
          <div className="p-4 rounded-3xl bg-[#041615]/90 border border-[rgba(158,255,230,0.18)] shadow-xl space-y-3 box-border">
            <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
              {/* Search bar */}
              <div className="relative w-full sm:w-80">
                <Search size={14} className="absolute start-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
                <input
                  type="text"
                  value={ownerSearchQuery}
                  onChange={(e) => setOwnerSearchQuery(e.target.value)}
                  placeholder="Search by card name, series, title..."
                  className="w-full ps-9 pe-8 py-2 rounded-xl bg-black/60 border border-teal-900/60 text-xs text-stone-200 placeholder:text-stone-500 focus:outline-hidden focus:border-amber-400 focus:ring-1 focus:ring-amber-400/50 transition-all"
                />
                {ownerSearchQuery && (
                  <button
                    type="button"
                    onClick={() => setOwnerSearchQuery('')}
                    className="absolute end-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-white"
                  >
                    <X size={13} />
                  </button>
                )}
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-1 p-1 rounded-2xl bg-black/60 border border-white/10 self-stretch sm:self-auto overflow-x-auto">
                <button
                  type="button"
                  onClick={() => setOwnerStatusFilter('ALL')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-serif font-bold uppercase transition-all cursor-pointer ${
                    ownerStatusFilter === 'ALL'
                      ? 'bg-amber-500 text-stone-950 shadow-sm'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  All ({catalog.length})
                </button>
                <button
                  type="button"
                  onClick={() => setOwnerStatusFilter('ACTIVE')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-serif font-bold uppercase transition-all cursor-pointer ${
                    ownerStatusFilter === 'ACTIVE'
                      ? 'bg-emerald-500 text-stone-950 shadow-sm'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  Active ({catalog.filter(c => c.isActive !== false).length})
                </button>
                <button
                  type="button"
                  onClick={() => setOwnerStatusFilter('INACTIVE')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-serif font-bold uppercase transition-all cursor-pointer ${
                    ownerStatusFilter === 'INACTIVE'
                      ? 'bg-rose-500 text-stone-950 shadow-sm'
                      : 'text-stone-400 hover:text-white'
                  }`}
                >
                  Vaulted ({catalog.filter(c => c.isActive === false).length})
                </button>
              </div>
            </div>

            {/* Rarity Filter Chips */}
            <div className="flex items-center gap-2 overflow-x-auto pt-1 pb-1 text-xs no-scrollbar">
              <span className="text-[10px] font-mono text-stone-400 uppercase tracking-wider shrink-0 font-bold">
                Rarity Tier:
              </span>
              {[
                { key: 'ALL', label: 'All Tiers', color: '#94a3b8' },
                { key: 'COMMON', label: 'Common', color: '#94a3b8' },
                { key: 'UNCOMMON', label: 'Uncommon', color: '#10b981' },
                { key: 'RARE', label: 'Rare', color: '#3b82f6' },
                { key: 'EPIC', label: 'Epic', color: '#a855f7' },
                { key: 'LEGENDARY', label: 'Legendary', color: '#f59e0b' }
              ].map((r) => {
                const isSelected = ownerRarityFilter === r.key;
                return (
                  <button
                    key={r.key}
                    type="button"
                    onClick={() => setOwnerRarityFilter(r.key)}
                    className={`px-3 py-1 rounded-xl text-[11px] font-mono font-bold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 border ${
                      isSelected
                        ? 'bg-amber-500/20 text-[#f6d98a] border-amber-500/80 shadow-sm'
                        : 'bg-black/40 text-stone-400 hover:text-stone-200 border-white/10 hover:border-white/20'
                    }`}
                  >
                    <span
                      className="w-2 h-2 rounded-full shrink-0"
                      style={{ backgroundColor: r.color }}
                    />
                    <span>{r.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Cards Management List / Grid */}
          <div className="space-y-4">
            {/* Multi-Selection Action Ribbon */}
            <div className={`p-3.5 sm:p-4 rounded-3xl transition-all border flex flex-wrap items-center justify-between gap-3 ${
              selectedCardIds.size > 0
                ? 'bg-gradient-to-r from-[#1c080b] via-[#2d0e13] to-[#1c080b] border-rose-500/50 shadow-xl shadow-rose-950/40'
                : 'bg-black/60 border-white/10'
            }`}>
              <div className="flex items-center gap-3 flex-wrap">
                <button
                  type="button"
                  onClick={handleSelectAllFiltered}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-200 border border-white/10 text-xs font-mono font-bold cursor-pointer transition-all active:scale-95"
                >
                  {selectedCardIds.size === ownerFilteredCards.length && ownerFilteredCards.length > 0 ? (
                    <>
                      <CheckSquare size={16} className="text-amber-400" />
                      <span>Deselect All Filtered</span>
                    </>
                  ) : (
                    <>
                      <Square size={16} className="text-stone-400" />
                      <span>Select All Filtered ({ownerFilteredCards.length})</span>
                    </>
                  )}
                </button>

                <span className="text-xs font-mono text-stone-300">
                  Selected: <strong className="text-amber-300 font-bold text-sm">{selectedCardIds.size}</strong> of {ownerFilteredCards.length} cards
                </span>
              </div>

              {selectedCardIds.size > 0 && (
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => setSelectedCardIds(new Set())}
                    className="px-3 py-2 rounded-xl text-xs font-mono text-stone-400 hover:text-white cursor-pointer transition-colors"
                  >
                    Clear Selection
                  </button>

                  <button
                    type="button"
                    disabled={isBulkDeleting}
                    onClick={handleInitiateBulkDelete}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:brightness-110 text-white font-serif font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-rose-950/60 cursor-pointer disabled:opacity-50 transition-all active:scale-95 animate-pulse"
                  >
                    <Trash2 size={14} className="shrink-0" />
                    <span>Delete Selected ({selectedCardIds.size})</span>
                  </button>
                </div>
              )}
            </div>

            {ownerFilteredCards.length === 0 ? (
              <div className="p-12 rounded-3xl bg-black/30 border border-dashed border-white/10 text-center space-y-3">
                <Shield size={36} className="mx-auto text-amber-500/40" />
                <h4 className="text-base font-bold font-serif text-stone-200">No cards matched your filter</h4>
                <p className="text-xs text-stone-400 max-w-md mx-auto">
                  {catalog.length === 0
                    ? 'The card catalog is currently empty. Click "Forge New Card" to craft custom artifacts, or "Restore Starter Relics" to reset default cards.'
                    : 'Try clearing your search query or switching your status and rarity filters.'}
                </p>
                {catalog.length === 0 && (
                  <button
                    type="button"
                    onClick={() => setShowRestoreDefaultsModal(true)}
                    className="px-4 py-2 rounded-xl bg-cyan-900/60 hover:bg-cyan-800/80 text-cyan-200 text-xs font-serif font-bold uppercase tracking-wider border border-cyan-500/40 cursor-pointer mt-2 inline-flex items-center gap-1.5"
                  >
                    <RotateCcw size={14} />
                    <span>Restore Starter Relics</span>
                  </button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {ownerFilteredCards.map((c) => {
                  const isCardActive = c.isActive !== false;
                  const abilitiesCount = Array.isArray(c.abilities) ? c.abilities.length : 0;
                  const hasVideo = Boolean(c.revealVideoUrl);
                  const isSelected = selectedCardIds.has(c.id);
                  const effectiveBorder = c.borderColor || c.accentColor || '#f59e0b';

                  return (
                    <div
                      key={c.id}
                      onClick={() => setSelectedCardForDetail(c)}
                      className={`group relative rounded-3xl p-4 sm:p-5 transition-all duration-300 backdrop-blur-xl border flex flex-col justify-between gap-4 cursor-pointer select-none overflow-hidden ${
                        isSelected
                          ? 'bg-gradient-to-br from-[#0c2e28]/95 via-[#07201c]/95 to-[#021412]/98 border-amber-400 ring-2 ring-amber-400/50 shadow-[0_16px_40px_rgba(245,158,11,0.2)]'
                          : 'bg-gradient-to-br from-[#05221e]/85 via-[#031715]/90 to-[#010e0d]/95 border-[rgba(158,255,230,0.14)] hover:border-[rgba(158,255,230,0.4)] hover:bg-[#062823]/90 shadow-[0_12px_32px_rgba(0,0,0,0.5)] hover:shadow-[0_16px_48px_rgba(0,0,0,0.7)]'
                      }`}
                    >
                      {/* Top Luminous Accent Line */}
                      <div
                        className="absolute top-0 inset-x-0 h-[2px] transition-all duration-300 opacity-80 group-hover:opacity-100 pointer-events-none"
                        style={{
                          background: `linear-gradient(90deg, transparent 0%, ${effectiveBorder} 50%, transparent 100%)`,
                          boxShadow: `0 0 10px ${effectiveBorder}`
                        }}
                      />

                      {/* Header Row: Selection + Clean Typographic Rarity + Active Beacon */}
                      <div className="flex items-center justify-between gap-2.5">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleCardSelection(c.id);
                            }}
                            className={`p-1.5 rounded-xl border transition-all cursor-pointer flex items-center justify-center ${
                              isSelected
                                ? 'bg-amber-500 text-stone-950 border-amber-400 shadow-md shadow-amber-500/40'
                                : 'bg-black/60 text-stone-400 border-white/15 hover:text-white hover:border-white/35'
                            }`}
                            title={isSelected ? 'Deselect card' : 'Select card'}
                          >
                            {isSelected ? <CheckSquare size={15} /> : <Square size={15} />}
                          </button>

                          <span className="text-[10px] font-mono font-bold tracking-widest text-stone-300 px-2 py-0.5 rounded-lg bg-black/60 border border-white/10">
                            #{String(c.cardNumber).padStart(3, '0')}
                          </span>
                        </div>

                        {/* Clean Unboxed Element & Number */}
                        <div className="flex items-center gap-2 min-w-0">
                          <span
                            className="text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-1.5 truncate"
                            style={{ color: effectiveBorder }}
                          >
                            <span
                              className="w-2 h-2 rounded-full shrink-0 shadow-[0_0_8px_currentColor]"
                              style={{ backgroundColor: effectiveBorder }}
                            />
                            <span>{c.element}</span>
                          </span>
                        </div>

                        {/* Active / Vaulted Status Beacon */}
                        <div className="shrink-0">
                          {isCardActive ? (
                            <span className="inline-flex items-center gap-1.5 text-[10px] font-mono text-emerald-300 font-bold bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-0.5 rounded-full">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_6px_#34d399]" />
                              <span>Active</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 text-[10px] font-mono text-stone-400 font-medium bg-black/60 border border-white/10 px-2.5 py-0.5 rounded-full">
                              <span className="w-1.5 h-1.5 rounded-full bg-stone-500" />
                              <span>Vaulted</span>
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Middle: Artwork Thumbnail + Info */}
                      <div className="flex gap-4 items-start">
                        <div className="w-20 h-28 sm:w-22 sm:h-32 rounded-2xl overflow-hidden border border-white/15 bg-black relative shrink-0 shadow-lg group-hover:scale-[1.03] transition-transform">
                          <img
                            src={c.imageUrl}
                            alt={c.name}
                            className="w-full h-full object-cover"
                          />
                          <div
                            className="absolute top-1.5 start-1.5 w-2.5 h-2.5 rounded-full border border-black shadow"
                            style={{ backgroundColor: effectiveBorder }}
                            title={`Color: ${effectiveBorder}`}
                          />
                          {c.foilStyle && c.foilStyle !== 'standard' && (
                            <div className="absolute bottom-1 inset-x-1 py-0.5 text-[8px] font-mono font-bold uppercase bg-amber-500/90 text-stone-950 text-center rounded-sm truncate">
                              ✨ {c.foilStyle.replace('_', ' ')}
                            </div>
                          )}
                          {c.isCustom && !c.foilStyle && (
                            <div className="absolute bottom-1 inset-x-1 py-0.5 text-[8px] font-mono font-bold uppercase bg-amber-500/90 text-stone-950 text-center rounded-sm">
                              Custom
                            </div>
                          )}
                        </div>

                        <div className="min-w-0 grow space-y-1.5">
                          <h4
                            className="text-base sm:text-lg font-black font-serif transition-colors truncate"
                            style={{ color: c.nameColor || c.borderColor || c.accentColor || '#eafffa' }}
                          >
                            {c.name}
                          </h4>
                          <p className="text-xs text-stone-300/80 truncate font-sans">
                            {c.title}
                          </p>

                          {/* Series Tag */}
                          {c.series && (
                            <p className="text-[10px] font-mono text-stone-400 tracking-wider uppercase truncate">
                              {c.series}
                            </p>
                          )}

                          {/* Lore Inscription Preview */}
                          {c.lore && (
                            <p className="text-[11px] text-stone-400/90 line-clamp-1 italic font-serif">
                              {c.lore}
                            </p>
                          )}

                          {/* Abilities & Video Tags */}
                          <div className="flex items-center gap-2 flex-wrap pt-0.5">
                            {abilitiesCount > 0 ? (
                              <span className="text-amber-300 text-[10px] font-mono flex items-center gap-1 bg-amber-950/60 px-2 py-0.5 rounded-md border border-amber-500/30">
                                <Zap size={11} />
                                <span>{abilitiesCount} {abilitiesCount === 1 ? 'Ability' : 'Abilities'}</span>
                              </span>
                            ) : (
                              <span className="text-[10px] font-mono text-stone-500">No abilities</span>
                            )}

                            {hasVideo && (
                              <span className="text-cyan-300 text-[10px] font-mono flex items-center gap-1 bg-cyan-950/60 px-2 py-0.5 rounded-md border border-cyan-500/30">
                                <Film size={11} />
                                <span>Video Reveal</span>
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Combat Stats + Action Buttons Toolbar */}
                      <div className="space-y-2 pt-2 border-t border-white/10">
                        {/* Combat Stats Row */}
                        <div className="flex items-center justify-between text-[11px] font-mono tabular-nums text-stone-400">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-amber-300 font-bold bg-amber-950/60 px-2 py-0.5 rounded border border-amber-500/30">
                              OVR: <strong>{Math.min(100, Math.round((c.overallRating || c.powerRating || c.power || 50) > 100 ? (c.overallRating || c.powerRating || c.power || 50) / 10 : (c.overallRating || c.powerRating || c.power || 50)))}</strong>
                            </span>
                            <span className="text-white/20">·</span>
                            <span>ATK: <strong className="text-rose-300 font-bold">{Math.min(100, Math.round(c.attack > 100 ? c.attack / 10 : c.attack))}</strong></span>
                            <span className="text-white/20">·</span>
                            <span>DEF: <strong className="text-cyan-300 font-bold">{Math.min(100, Math.round(c.defense > 100 ? c.defense / 10 : c.defense))}</strong></span>
                          </div>
                        </div>

                        {/* Action Buttons Toolbar - Rounded-full & Modern */}
                        <div className="flex items-center gap-2 pt-1" onClick={(e) => e.stopPropagation()}>
                          {/* Studio Editor Button (Customization + Management Unified) */}
                          <button
                            type="button"
                            onClick={() => {
                              setCardToEdit(c);
                              setIsStudioOpen(true);
                            }}
                            className="flex-1 py-2 px-3 rounded-full bg-gradient-to-r from-[#5eead4]/20 via-teal-500/20 to-[#2dd4bf]/20 hover:from-[#5eead4] hover:to-teal-400 text-[#5eead4] hover:text-stone-950 border border-[#5eead4]/40 text-xs font-mono font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
                            title="Studio Editor: Customize Colors, Name, Artwork, Foil, Lore & Stats"
                          >
                            <Palette size={13} />
                            <span>Edit Card</span>
                          </button>

                          {/* Inspect 3D */}
                          <button
                            type="button"
                            onClick={() => setSelectedCardForDetail(c)}
                            className="w-8 h-8 rounded-full bg-stone-900/80 hover:bg-stone-800 text-stone-300 hover:text-white border border-white/10 transition-colors flex items-center justify-center cursor-pointer active:scale-95 shrink-0"
                            title="Inspect 3D Card Dossier"
                          >
                            <Layers size={13} />
                          </button>

                          {/* Delete */}
                          <button
                            type="button"
                            disabled={isDeletingCard === c.id}
                            onClick={() => handleInitiateSingleDelete(c)}
                            className="w-8 h-8 rounded-full bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-500/40 transition-colors flex items-center justify-center cursor-pointer disabled:opacity-50 active:scale-95 shrink-0"
                            title="Delete Card from Catalog"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* DROP RATES & PROBABILITIES MODAL                                          */}
      {/* ========================================================================= */}
      {isOddsModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md"
          onClick={() => setIsOddsModalOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-md bg-[#031515] border border-[rgba(158,255,230,0.25)] rounded-2xl p-4 sm:p-5 shadow-2xl space-y-3.5 max-h-[90vh] overflow-y-auto box-border"
          >
            <div className="flex items-center justify-between pb-2.5 border-b border-white/10">
              <div className="flex items-center gap-2 min-w-0">
                <HelpCircle size={16} className="text-[#5eead4] shrink-0" />
                <h3 className="text-sm sm:text-base font-bold font-serif text-[#eafffa] truncate">
                  Reliquary Drop Probabilities
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsOddsModalOpen(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-white cursor-pointer shrink-0"
              >
                <X size={15} />
              </button>
            </div>

            <p className="text-xs text-stone-300 leading-relaxed">
              Every booster pack purchased guarantees authentic collectible cards with fixed transparent drop rates.
            </p>

            <div className="space-y-2">
              {packs.map((p) => (
                <div key={p.id} className="p-2.5 rounded-xl bg-black/50 border border-white/5 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-serif font-bold text-[#eafffa] flex items-center gap-1.5 truncate">
                      <span
                        className="w-2 h-2 rounded-full shrink-0"
                        style={{ backgroundColor: p.accentHex }}
                      />
                      <span className="truncate">{p.name}</span>
                    </span>
                    <span className="text-xs font-mono font-bold text-[#f6d98a] shrink-0">
                      {p.price} 🪙
                    </span>
                  </div>
                  <p className="text-[10px] font-mono text-stone-300 bg-stone-950/80 px-2 py-0.5 rounded border border-white/5 truncate">
                    {p.chancesText}
                  </p>
                </div>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setIsOddsModalOpen(false)}
              className="w-full py-2 rounded-xl text-xs font-serif font-bold bg-[#5eead4] text-stone-950 hover:bg-teal-300 transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SINGLE CARD DELETE CONFIRMATION MODAL                                     */}
      {/* ========================================================================= */}
      {cardToDeleteSingle && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md"
          onClick={() => {
            if (!isDeletingCard) setCardToDeleteSingle(null);
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-md bg-[#160608] border border-rose-500/50 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4 box-border"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2 text-rose-400">
                <Trash2 size={20} className="shrink-0" />
                <h3 className="text-base font-bold font-serif text-white">
                  Delete Card from Catalog
                </h3>
              </div>
              <button
                type="button"
                disabled={Boolean(isDeletingCard)}
                onClick={() => setCardToDeleteSingle(null)}
                className="p-1 rounded-lg text-stone-400 hover:text-white cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <div className="flex items-center gap-3 p-3 rounded-2xl bg-black/60 border border-rose-500/20">
              <img
                src={cardToDeleteSingle.imageUrl}
                alt={cardToDeleteSingle.name}
                className="w-14 h-18 rounded-xl object-cover border border-white/10 shrink-0"
              />
              <div className="min-w-0">
                <span className="text-[10px] font-mono font-bold uppercase text-amber-300">
                  {cardToDeleteSingle.rarity}
                </span>
                <h4 className="text-sm font-bold font-serif text-white truncate">
                  {cardToDeleteSingle.name}
                </h4>
                <p className="text-xs text-stone-400 truncate">
                  {cardToDeleteSingle.title}
                </p>
              </div>
            </div>

            <p className="text-xs text-stone-300 leading-relaxed">
              Are you sure you want to permanently remove this card from the catalog? It will no longer drop from booster packs.
            </p>

            <div className="pt-2 flex items-center gap-3">
              <button
                type="button"
                disabled={Boolean(isDeletingCard)}
                onClick={() => setCardToDeleteSingle(null)}
                className="flex-1 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-300 font-serif font-bold text-xs uppercase cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={Boolean(isDeletingCard)}
                onClick={confirmSingleDelete}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-700 hover:brightness-110 text-white font-serif font-bold text-xs uppercase flex items-center justify-center gap-1.5 shadow-lg shadow-rose-950/60 cursor-pointer disabled:opacity-50"
              >
                <Trash2 size={14} />
                <span>{isDeletingCard ? 'Deleting...' : 'Confirm Delete'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* BULK CARDS DELETE CONFIRMATION MODAL                                      */}
      {/* ========================================================================= */}
      {showBulkDeleteModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md"
          onClick={() => {
            if (!isBulkDeleting) setShowBulkDeleteModal(false);
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-lg bg-[#160608] border border-rose-500/50 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4 box-border max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2 text-rose-400">
                <Trash2 size={20} className="shrink-0" />
                <h3 className="text-base font-bold font-serif text-white">
                  Delete {selectedCardIds.size} Selected Cards
                </h3>
              </div>
              <button
                type="button"
                disabled={isBulkDeleting}
                onClick={() => setShowBulkDeleteModal(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-white cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <p className="text-xs text-stone-300 leading-relaxed">
              You have selected <strong className="text-rose-300 font-bold">{selectedCardIds.size} card(s)</strong> for deletion. They will be permanently removed from the catalog and pack drops.
            </p>

            {/* Selected Cards Mini Preview List */}
            <div className="max-h-48 overflow-y-auto space-y-1.5 p-2 rounded-2xl bg-black/60 border border-rose-500/20">
              {catalog.filter(c => selectedCardIds.has(c.id)).map(c => (
                <div key={c.id} className="flex items-center justify-between gap-2 p-1.5 rounded-xl bg-white/5 text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <img src={c.imageUrl} alt={c.name} className="w-7 h-9 rounded object-cover shrink-0" />
                    <span className="font-serif font-bold text-stone-200 truncate">{c.name}</span>
                  </div>
                  <span className="text-[10px] font-mono text-amber-300 shrink-0">{c.rarity}</span>
                </div>
              ))}
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                type="button"
                disabled={isBulkDeleting}
                onClick={() => setShowBulkDeleteModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-300 font-serif font-bold text-xs uppercase cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={isBulkDeleting}
                onClick={confirmBulkDelete}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:brightness-110 text-white font-serif font-bold text-xs uppercase flex items-center justify-center gap-1.5 shadow-lg shadow-rose-950/60 cursor-pointer disabled:opacity-50"
              >
                <Trash2 size={14} />
                <span>{isBulkDeleting ? 'Deleting...' : `Confirm Delete (${selectedCardIds.size})`}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* DELETE ALL CARDS CONFIRMATION MODAL                                       */}
      {/* ========================================================================= */}
      {showDeleteAllConfirmModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md"
          onClick={() => {
            if (!isDeletingAll) setShowDeleteAllConfirmModal(false);
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-md bg-[#160608] border border-rose-500/50 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4 box-border"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2 text-rose-400">
                <AlertOctagon size={22} className="shrink-0" />
                <h3 className="text-base font-bold font-serif text-white">
                  Danger: Clear Entire Card Catalog
                </h3>
              </div>
              <button
                type="button"
                disabled={isDeletingAll}
                onClick={() => setShowDeleteAllConfirmModal(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-white cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-2 text-xs text-stone-300 leading-relaxed">
              <p>
                You are about to permanently delete all <strong className="text-rose-300 font-bold">{catalog.length} cards</strong> from the entire catalog.
              </p>
              <div className="p-3.5 rounded-2xl bg-black/60 border border-rose-500/30 text-[11px] text-rose-200/90 space-y-1">
                <p>• All cards will be removed from booster packs.</p>
                <p>• You can restore the starter default relics at any time using "Restore Starter Relics".</p>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                type="button"
                disabled={isDeletingAll}
                onClick={() => setShowDeleteAllConfirmModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-300 font-serif font-bold text-xs uppercase cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={isDeletingAll}
                onClick={confirmDeleteAllCards}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:brightness-110 text-white font-serif font-bold text-xs uppercase flex items-center justify-center gap-1.5 shadow-lg shadow-rose-950/60 cursor-pointer disabled:opacity-50"
              >
                <Trash2 size={14} />
                <span>{isDeletingAll ? 'Clearing Catalog...' : 'Confirm Delete All'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* RESTORE STARTER RELICS CONFIRMATION MODAL                                */}
      {/* ========================================================================= */}
      {showRestoreDefaultsModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md"
          onClick={() => {
            if (!isRestoringDefaults) setShowRestoreDefaultsModal(false);
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-md bg-[#041c24] border border-cyan-500/50 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4 box-border"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2 text-cyan-300">
                <RotateCcw size={20} className="shrink-0" />
                <h3 className="text-base font-bold font-serif text-white">
                  Restore Starter Relic Cards
                </h3>
              </div>
              <button
                type="button"
                disabled={isRestoringDefaults}
                onClick={() => setShowRestoreDefaultsModal(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-white cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <p className="text-xs text-stone-300 leading-relaxed">
              This will restore all original default Mesopotamian collectible cards back into the catalog and make them available in booster pack drops.
            </p>

            <div className="pt-2 flex items-center gap-3">
              <button
                type="button"
                disabled={isRestoringDefaults}
                onClick={() => setShowRestoreDefaultsModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-stone-300 font-serif font-bold text-xs uppercase cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={isRestoringDefaults}
                onClick={confirmRestoreDefaults}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-teal-600 hover:brightness-110 text-white font-serif font-bold text-xs uppercase flex items-center justify-center gap-1.5 shadow-lg shadow-cyan-950/60 cursor-pointer disabled:opacity-50"
              >
                <RotateCcw size={14} className={isRestoringDefaults ? 'animate-spin' : ''} />
                <span>{isRestoringDefaults ? 'Restoring...' : 'Confirm Restore'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODALS */}
      <PackOpeningModal
        isOpen={Boolean(isOpeningPack && activePackDef && lastOpenedResult)}
        pack={activePackDef}
        result={lastOpenedResult}
        userCoins={coins}
        onClose={clearPackModal}
        onOpenAnother={handleOpenPack}
        onInspectCard={(card) => {
          clearPackModal();
          setSelectedCardForDetail(card);
        }}
      />

      <CardDetailModal
        card={selectedCardForDetail}
        onClose={() => setSelectedCardForDetail(null)}
        onEditInStudio={(c) => {
          setSelectedCardForDetail(null);
          setCardToEdit(c);
          setIsStudioOpen(true);
        }}
      />

      <OwnerCoinManagementModal
        isOpen={isCoinManageOpen}
        onClose={() => setIsCoinManageOpen(false)}
      />

      <OwnerCardStudioModal
        card={cardToEdit}
        isOpen={isStudioOpen}
        onClose={() => {
          setIsStudioOpen(false);
          setCardToEdit(null);
        }}
      />

      <OwnerPackArtworkModal
        isOpen={isPackArtworkOpen}
        onClose={() => setIsPackArtworkOpen(false)}
      />

      <OwnerRevealAudioModal
        isOpen={isRevealAudioOpen}
        onClose={() => setIsRevealAudioOpen(false)}
      />

      {isLegendaryAudioModalOpen && (
        <LegendaryCombatAudioModal
          isOpen={isLegendaryAudioModalOpen}
          onClose={() => setIsLegendaryAudioModalOpen(false)}
          legendaryCards={allCatalog?.filter(c => c.rarity === 'LEGENDARY') || []}
          isAr={isRtl}
        />
      )}

      {isUnifiedItemsOpen && (
        <OwnerUnifiedItemManagerModal
          isOpen={isUnifiedItemsOpen}
          onClose={() => setIsUnifiedItemsOpen(false)}
        />
      )}

      <PlayerInventoryModal
        isOpen={isPlayerInventoryOpen}
        onClose={() => setIsPlayerInventoryOpen(false)}
        isAr={isRtl}
        onSelectCardToUpgrade={(cardId) => {
          const card = allCatalog.find(c => c.id === cardId);
          if (card) {
            setSelectedCardForDetail(card);
          }
        }}
      />
    </div>
  );
};
