import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, 
  Activity, 
  Users, 
  Search, 
  RefreshCw, 
  Clock, 
  Copy, 
  Check, 
  MousePointer, 
  LogIn, 
  LogOut, 
  Globe, 
  FileText, 
  Trash2, 
  ChevronDown, 
  ChevronUp, 
  Sliders, 
  AlertCircle,
  Eye,
  Crown,
  Laptop
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { AuditLogEntry, AuditLogStats, AuditEventType } from '../types/auditLog';
import { Link } from 'react-router-dom';

export const OwnerAuditLog: React.FC = () => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { user, role } = useAuth();

  const isOwner = role === 'OWNER' || user?.isOwner === true || user?.isGuildOwner === true || user?.discordId === '871043296280076308';

  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [stats, setStats] = useState<AuditLogStats | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [selectedEventType, setSelectedEventType] = useState<string>('ALL');
  const [selectedUserType, setSelectedUserType] = useState<'all' | 'authenticated' | 'guests'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [autoRefresh, setAutoRefresh] = useState<boolean>(true);
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState<boolean>(false);
  const [clearing, setClearing] = useState<boolean>(false);

  // Fetch logs from backend
  const fetchLogs = useCallback(async (showIndicator = false) => {
    if (showIndicator) setRefreshing(true);
    try {
      const params = new URLSearchParams();
      if (selectedEventType !== 'ALL') params.set('eventType', selectedEventType);
      if (selectedUserType !== 'all') params.set('userType', selectedUserType);
      if (searchQuery.trim()) params.set('searchQuery', searchQuery.trim());
      params.set('limit', '300');

      const res = await fetch(`/api/audit-logs?${params.toString()}`, {
        credentials: 'include',
        headers: { 'Accept': 'application/json' }
      });

      if (!res.ok) {
        if (res.status === 401 || res.status === 403) {
          throw new Error(isAr ? 'غير مصرح: هذا السجل مخصص للمالكين فقط' : 'Access Denied: Owner authorization required');
        }
        throw new Error(isAr ? 'فشل تحميل سجل العمليات' : 'Failed to fetch audit records');
      }

      const data = await res.json();
      setLogs(data.logs || []);
      setStats(data.stats || null);
      setError(null);
    } catch (err: any) {
      console.error('Audit log fetch error:', err);
      setError(err.message || 'Error loading logs');
    } finally {
      setLoading(false);
      if (showIndicator) setRefreshing(false);
    }
  }, [selectedEventType, selectedUserType, searchQuery, isAr]);

  // Initial load
  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  // Auto-refresh interval (every 6 seconds)
  useEffect(() => {
    if (!autoRefresh || !isOwner) return;
    const interval = setInterval(() => {
      fetchLogs(false);
    }, 6000);
    return () => clearInterval(interval);
  }, [autoRefresh, isOwner, fetchLogs]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearLogs = async () => {
    setClearing(true);
    try {
      const res = await fetch('/api/audit-logs/clear', {
        method: 'DELETE',
        credentials: 'include'
      });
      if (!res.ok) throw new Error('Failed to clear logs');
      setShowClearConfirm(false);
      await fetchLogs(true);
    } catch (err: any) {
      alert(err?.message || 'Error clearing logs');
    } finally {
      setClearing(false);
    }
  };

  // Helper formatting relative time
  const formatRelativeTime = (timestampMs: number) => {
    const diff = Math.floor((Date.now() - timestampMs) / 1000);
    if (diff < 5) return isAr ? 'الآن' : 'Just now';
    if (diff < 60) return isAr ? `منذ ${diff} ثانية` : `${diff}s ago`;
    const mins = Math.floor(diff / 60);
    if (mins < 60) return isAr ? `منذ ${mins} دقيقة` : `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return isAr ? `منذ ${hours} ساعة` : `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return isAr ? `منذ ${days} يوم` : `${days}d ago`;
  };

  // Helper event color and icon
  const getEventBadge = (type: AuditEventType) => {
    switch (type) {
      case 'AUTH_LOGIN':
        return {
          icon: <LogIn size={13} />,
          label: isAr ? 'تسجيل دخول' : 'Login',
          bg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
        };
      case 'AUTH_LOGOUT':
        return {
          icon: <LogOut size={13} />,
          label: isAr ? 'تسجيل خروج' : 'Logout',
          bg: 'bg-amber-500/10 text-amber-400 border-amber-500/30'
        };
      case 'PAGE_VIEW':
        return {
          icon: <FileText size={13} />,
          label: isAr ? 'تصفح صفحة' : 'Page View',
          bg: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
        };
      case 'CLICK':
        return {
          icon: <MousePointer size={13} />,
          label: isAr ? 'نقرة' : 'Click',
          bg: 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30'
        };
      case 'ADMIN_ACTION':
        return {
          icon: <Shield size={13} />,
          label: isAr ? 'إجراء إداري' : 'Admin Action',
          bg: 'bg-rose-500/10 text-rose-300 border-rose-500/30'
        };
      default:
        return {
          icon: <Activity size={13} />,
          label: isAr ? 'تفاعل' : 'Interaction',
          bg: 'bg-blue-500/10 text-blue-300 border-blue-500/30'
        };
    }
  };

  // Helper role badge
  const getRoleBadge = (logRole: string, isGuest: boolean) => {
    if (isGuest) {
      return (
        <span className="inline-flex items-center gap-1 text-[10px] font-mono font-medium px-2 py-0.5 rounded-full bg-slate-800/80 text-slate-300 border border-slate-700">
          <Globe size={10} />
          {isAr ? 'زائر' : 'Guest'}
        </span>
      );
    }
    if (logRole === 'OWNER') {
      return (
        <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
          <Crown size={10} />
          {isAr ? 'المالك' : 'Owner'}
        </span>
      );
    }
    if (['ADMIN', 'SUPER_ADMIN', 'MODERATOR', 'STAFF'].includes(logRole)) {
      return (
        <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
          <Shield size={10} />
          {isAr ? 'طاقم الإدارة' : 'Staff'}
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 text-[10px] font-mono font-medium px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
        <Users size={10} />
        {isAr ? 'عضو' : 'Member'}
      </span>
    );
  };

  // Non-owner gatekeeper screen
  if (!isOwner) {
    return (
      <div className="flex-1 w-full max-w-4xl mx-auto px-4 py-20 text-center">
        <div className="w-20 h-20 mx-auto rounded-3xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-6 shadow-xl shadow-rose-950/40">
          <Shield size={40} />
        </div>
        <h1 className="text-2xl font-bold text-archive-paper mb-3">
          {isAr ? 'منطقة مقيدة للمالكين فقط' : 'Restricted to Server Owners'}
        </h1>
        <p className="text-sm text-archive-paper-muted max-w-md mx-auto mb-8 leading-relaxed">
          {isAr
            ? 'سجل العمليات ومراقبة تفاعلات الزوار محمي ومشفر بالكامل، ومتاح حصرياً لمالكي سيرفر CREATINE NEXUS.'
            : 'The comprehensive audit log and user telemetry feed is protected by server-side RBAC and strictly accessible to CREATINE NEXUS Owners.'}
        </p>
        <div className="flex items-center justify-center gap-3">
          <Link
            to="/"
            className="px-5 py-2.5 rounded-xl bg-archive-card border border-archive-cyan/30 text-archive-paper hover:text-archive-cyan transition-colors text-sm font-semibold"
          >
            {isAr ? 'العودة للرئيسية' : 'Return Home'}
          </Link>
          <Link
            to="/staff-management"
            className="px-5 py-2.5 rounded-xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/30 transition-colors text-sm font-semibold"
          >
            {isAr ? 'لوحة الإدارة' : 'Staff Management'}
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" dir={isAr ? 'rtl' : 'ltr'}>
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8 pb-6 border-b border-white/10">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shadow-sm">
              <Activity size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h1 className="text-xl sm:text-2xl font-bold text-archive-paper tracking-tight">
                  {isAr ? 'سجل العمليات والتفاعلات' : 'Owner Audit & Interaction Log'}
                </h1>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                  <Crown size={11} />
                  {isAr ? 'خاص بالمالك' : 'Owner Only'}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-archive-paper-muted mt-0.5">
                {isAr
                  ? 'مراقبة حية وشاملة لكل نقرة، زيارة، وتسجيل دخول في الموقع'
                  : 'Real-time telemetry tracking of every click, interaction, and login across the platform'}
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Live Polling Toggle */}
          <button
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 border transition-all cursor-pointer ${
              autoRefresh
                ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                : 'bg-archive-dark/60 text-archive-paper-muted border-white/10 hover:text-archive-paper'
            }`}
            title={isAr ? 'تحديث تلقائي كل 6 ثوانٍ' : 'Auto-refresh every 6 seconds'}
          >
            <span className={`w-2 h-2 rounded-full ${autoRefresh ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`} />
            <span>{isAr ? (autoRefresh ? 'بث مباشر نشط' : 'البث متوقف') : (autoRefresh ? 'Live Monitoring' : 'Paused')}</span>
          </button>

          {/* Manual Refresh */}
          <button
            onClick={() => fetchLogs(true)}
            disabled={refreshing}
            className="p-2 sm:px-3 sm:py-2 rounded-xl bg-archive-dark/70 hover:bg-archive-card border border-archive-cyan/20 text-archive-paper hover:text-archive-cyan text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            title={isAr ? 'تحديث الآن' : 'Refresh Now'}
          >
            <RefreshCw size={14} className={refreshing ? 'animate-spin text-cyan-400' : ''} />
            <span className="hidden sm:inline">{isAr ? 'تحديث' : 'Refresh'}</span>
          </button>

          {/* Clear Logs Button */}
          <button
            onClick={() => setShowClearConfirm(true)}
            className="p-2 sm:px-3 sm:py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
            title={isAr ? 'مسح السجل' : 'Clear Log'}
          >
            <Trash2 size={14} />
            <span className="hidden sm:inline">{isAr ? 'مسح السجل' : 'Clear'}</span>
          </button>
        </div>
      </div>

      {/* Overview Stats Cards */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 mb-8">
          <div className="p-3.5 rounded-2xl bg-archive-card/60 border border-archive-cyan/15 backdrop-blur-sm">
            <div className="flex items-center justify-between text-archive-paper-muted text-xs mb-1">
              <span>{isAr ? 'إجمالي الأحداث' : 'Total Events'}</span>
              <Activity size={14} className="text-cyan-400" />
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-archive-paper">
              {stats.totalEvents.toLocaleString()}
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-archive-card/60 border border-archive-cyan/15 backdrop-blur-sm">
            <div className="flex items-center justify-between text-archive-paper-muted text-xs mb-1">
              <span>{isAr ? 'تسجيلات الدخول' : 'Logins'}</span>
              <LogIn size={14} className="text-emerald-400" />
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-400">
              {stats.totalLogins.toLocaleString()}
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-archive-card/60 border border-archive-cyan/15 backdrop-blur-sm">
            <div className="flex items-center justify-between text-archive-paper-muted text-xs mb-1">
              <span>{isAr ? 'النقرات والتفاعل' : 'Clicks & UI'}</span>
              <MousePointer size={14} className="text-indigo-400" />
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-indigo-300">
              {stats.totalInteractions.toLocaleString()}
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-archive-card/60 border border-archive-cyan/15 backdrop-blur-sm">
            <div className="flex items-center justify-between text-archive-paper-muted text-xs mb-1">
              <span>{isAr ? 'تصفح الصفحات' : 'Page Views'}</span>
              <FileText size={14} className="text-cyan-400" />
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-cyan-300">
              {stats.totalPageViews.toLocaleString()}
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-archive-card/60 border border-archive-cyan/15 backdrop-blur-sm">
            <div className="flex items-center justify-between text-archive-paper-muted text-xs mb-1">
              <span>{isAr ? 'أعضاء مسجلين' : 'Active Users'}</span>
              <Users size={14} className="text-amber-400" />
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-amber-300">
              {stats.uniqueUsers.toLocaleString()}
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-archive-card/60 border border-archive-cyan/15 backdrop-blur-sm">
            <div className="flex items-center justify-between text-archive-paper-muted text-xs mb-1">
              <span>{isAr ? 'زوار ضيوف' : 'Guest Visitors'}</span>
              <Globe size={14} className="text-slate-400" />
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono text-slate-300">
              {stats.uniqueGuests.toLocaleString()}
            </div>
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-archive-card/80 border border-archive-cyan/20 mb-6 backdrop-blur-md space-y-4">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search size={16} className={`absolute top-3 ${isAr ? 'right-3.5' : 'left-3.5'} text-archive-paper-muted`} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                isAr
                  ? 'بحث باسم المستخدم، الـ Discord ID، الإجراء، أو الرابط...'
                  : 'Search by username, Discord ID, action, button text, or URL...'
              }
              className={`w-full py-2.5 ${isAr ? 'pr-10 pl-4' : 'pl-10 pr-4'} bg-archive-dark/80 border border-archive-cyan/20 rounded-xl text-xs text-archive-paper placeholder:text-archive-paper-muted/60 focus:outline-none focus:border-archive-cyan/60 transition-colors`}
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className={`absolute top-2.5 ${isAr ? 'left-3' : 'right-3'} text-xs text-archive-paper-muted hover:text-archive-paper cursor-pointer`}
              >
                ✕
              </button>
            )}
          </div>

          {/* User Type Filter */}
          <div className="flex items-center gap-1.5 p-1 bg-archive-dark/80 rounded-xl border border-archive-cyan/20 shrink-0">
            <button
              onClick={() => setSelectedUserType('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                selectedUserType === 'all'
                  ? 'bg-archive-cyan text-archive-dark shadow-xs'
                  : 'text-archive-paper-muted hover:text-archive-paper'
              }`}
            >
              {isAr ? 'الكل' : 'All'}
            </button>
            <button
              onClick={() => setSelectedUserType('authenticated')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                selectedUserType === 'authenticated'
                  ? 'bg-archive-cyan text-archive-dark shadow-xs'
                  : 'text-archive-paper-muted hover:text-archive-paper'
              }`}
            >
              {isAr ? 'مسجلين' : 'Members'}
            </button>
            <button
              onClick={() => setSelectedUserType('guests')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                selectedUserType === 'guests'
                  ? 'bg-archive-cyan text-archive-dark shadow-xs'
                  : 'text-archive-paper-muted hover:text-archive-paper'
              }`}
            >
              {isAr ? 'ضيوف' : 'Guests'}
            </button>
          </div>
        </div>

        {/* Event Type Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <span className="text-archive-paper-muted text-[11px] font-medium me-1 shrink-0 flex items-center gap-1">
            <Sliders size={12} />
            {isAr ? 'النوع:' : 'Type:'}
          </span>
          {[
            { id: 'ALL', label: isAr ? 'جميع الأحداث' : 'All Events' },
            { id: 'AUTH_LOGIN', label: isAr ? 'تسجيل دخول' : 'Logins', icon: <LogIn size={12} /> },
            { id: 'CLICK', label: isAr ? 'النقرات' : 'Clicks', icon: <MousePointer size={12} /> },
            { id: 'PAGE_VIEW', label: isAr ? 'زيارات الصفحات' : 'Page Views', icon: <FileText size={12} /> },
            { id: 'ADMIN_ACTION', label: isAr ? 'إجراءات إدارية' : 'Admin Actions', icon: <Shield size={12} /> },
            { id: 'AUTH_LOGOUT', label: isAr ? 'تسجيل خروج' : 'Logouts', icon: <LogOut size={12} /> }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedEventType(tab.id)}
              className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                selectedEventType === tab.id
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-xs'
                  : 'bg-archive-dark/40 text-archive-paper-muted hover:text-archive-paper hover:bg-archive-dark/70 border border-transparent'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2 mb-6">
          <AlertCircle size={16} />
          <span>{error}</span>
        </div>
      )}

      {/* Logs Feed */}
      {loading ? (
        <div className="py-20 text-center">
          <RefreshCw size={28} className="animate-spin mx-auto text-cyan-400 mb-3" />
          <p className="text-xs text-archive-paper-muted">
            {isAr ? 'جاري قراءة سجلات التفاعل...' : 'Loading audit feed...'}
          </p>
        </div>
      ) : logs.length === 0 ? (
        <div className="py-16 text-center rounded-2xl bg-archive-card/40 border border-archive-cyan/10">
          <Activity size={36} className="mx-auto text-archive-paper-muted/40 mb-3" />
          <p className="text-sm font-semibold text-archive-paper mb-1">
            {isAr ? 'لا توجد سجلات مطابقة' : 'No Audit Records Found'}
          </p>
          <p className="text-xs text-archive-paper-muted max-w-sm mx-auto">
            {isAr
              ? 'لم يتم تسجيل أي أحداث تطابق معايير البحث الحالية.'
              : 'No interactions match the selected filters. Telemetry updates will appear here live.'}
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {logs.map((log) => {
            const badge = getEventBadge(log.eventType);
            const isExpanded = expandedLogId === log.id;

            return (
              <div
                key={log.id}
                className="rounded-xl bg-archive-card/70 border border-archive-cyan/15 hover:border-archive-cyan/35 transition-all overflow-hidden shadow-xs"
              >
                {/* Main Row */}
                <div 
                  className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer"
                  onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                >
                  {/* Left Identity + Action */}
                  <div className="flex items-start sm:items-center gap-3 min-w-0">
                    {/* User Avatar */}
                    <div className="relative shrink-0 mt-0.5 sm:mt-0">
                      {log.avatarUrl ? (
                        <img
                          src={log.avatarUrl}
                          alt={log.displayName}
                          className="w-8 h-8 rounded-full object-cover border border-archive-cyan/30"
                        />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300">
                          {log.isGuest ? <Globe size={15} /> : <Users size={15} />}
                        </div>
                      )}
                    </div>

                    {/* Content Details */}
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <span className="text-xs font-bold text-archive-paper truncate max-w-[140px] sm:max-w-[200px]">
                          {log.displayName || log.username}
                        </span>
                        
                        {!log.isGuest && log.username && (
                          <span className="text-[11px] font-mono text-archive-paper-muted">
                            @{log.username}
                          </span>
                        )}

                        {getRoleBadge(log.role, log.isGuest)}

                        {/* Event Category Pill */}
                        <span className={`inline-flex items-center gap-1 text-[10px] font-mono font-semibold px-2 py-0.5 rounded-md border ${badge.bg}`}>
                          {badge.icon}
                          <span>{badge.label}</span>
                        </span>
                      </div>

                      {/* Action Headline */}
                      <p className="text-xs text-archive-paper font-medium leading-snug">
                        {log.action}
                      </p>
                    </div>
                  </div>

                  {/* Right: Path + Timestamp + Toggle */}
                  <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-white/5">
                    {/* Path Badge */}
                    {log.path && (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-archive-dark/90 text-cyan-300 border border-cyan-500/20 max-w-[150px] truncate">
                        {log.path}
                      </span>
                    )}

                    {/* Relative Time */}
                    <div className="flex items-center gap-1.5 text-[11px] font-mono text-archive-paper-muted whitespace-nowrap">
                      <Clock size={12} className="text-archive-cyan/60" />
                      <span>{formatRelativeTime(log.timestampMs)}</span>
                    </div>

                    <button
                      className="p-1 rounded text-archive-paper-muted hover:text-archive-paper transition-colors"
                      title={isExpanded ? 'Hide Details' : 'Show Details'}
                    >
                      {isExpanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
                    </button>
                  </div>
                </div>

                {/* Expanded Details Drawer */}
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="border-t border-archive-cyan/10 bg-archive-dark/80 p-4 text-xs font-mono space-y-2.5"
                    >
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-[11px]">
                        <div>
                          <span className="text-archive-paper-muted block mb-0.5">{isAr ? 'معرف المستخدم (ID):' : 'User Discord ID:'}</span>
                          <div className="flex items-center gap-1.5">
                            <span className="text-cyan-300 bg-black/40 px-2 py-0.5 rounded border border-white/5 truncate">
                              {log.userId}
                            </span>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleCopy(log.userId, log.id);
                              }}
                              className="p-1 rounded hover:bg-white/10 text-archive-paper-muted hover:text-white"
                              title="Copy ID"
                            >
                              {copiedId === log.id ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                            </button>
                          </div>
                        </div>

                        <div>
                          <span className="text-archive-paper-muted block mb-0.5">{isAr ? 'الوقت الدقيق:' : 'Exact Timestamp:'}</span>
                          <span className="text-archive-paper bg-black/40 px-2 py-0.5 rounded border border-white/5 block truncate">
                            {new Date(log.timestamp).toLocaleString(isAr ? 'ar-EG' : 'en-US')}
                          </span>
                        </div>

                        <div>
                          <span className="text-archive-paper-muted block mb-0.5">{isAr ? 'عنوان IP:' : 'Client IP:'}</span>
                          <span className="text-amber-300 bg-black/40 px-2 py-0.5 rounded border border-white/5 block truncate">
                            {log.ip || '127.0.0.1'}
                          </span>
                        </div>

                        <div>
                          <span className="text-archive-paper-muted block mb-0.5">{isAr ? 'العنصر المستهدف:' : 'Target Element:'}</span>
                          <span className="text-archive-paper bg-black/40 px-2 py-0.5 rounded border border-white/5 block truncate">
                            {log.targetElement || 'N/A'}
                          </span>
                        </div>
                      </div>

                      {/* User Agent */}
                      {log.userAgent && (
                        <div className="pt-2 border-t border-white/5">
                          <span className="text-archive-paper-muted block mb-1 text-[11px]">{isAr ? 'متصفح الزائر / الجهاز:' : 'Browser / Device Agent:'}</span>
                          <div className="bg-black/40 p-2 rounded-lg text-slate-300 text-[10px] break-all border border-white/5">
                            {log.userAgent}
                          </div>
                        </div>
                      )}

                      {/* Additional Details */}
                      {log.details && (
                        <div className="pt-2 border-t border-white/5">
                          <span className="text-archive-paper-muted block mb-1 text-[11px]">{isAr ? 'بيانات إضافية (JSON):' : 'Event Metadata (JSON):'}</span>
                          <pre className="bg-black/50 p-2.5 rounded-lg text-cyan-300 text-[10px] overflow-x-auto border border-white/5">
                            {typeof log.details === 'string' ? log.details : JSON.stringify(log.details, null, 2)}
                          </pre>
                        </div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      )}

      {/* Confirmation Modal to Clear Logs */}
      <AnimatePresence>
        {showClearConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md p-6 rounded-2xl bg-archive-card border border-rose-500/40 shadow-2xl shadow-rose-950/40 text-center"
            >
              <div className="w-14 h-14 mx-auto rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-4">
                <Trash2 size={28} />
              </div>
              <h3 className="text-lg font-bold text-archive-paper mb-2">
                {isAr ? 'تأكيد مسح السجلات' : 'Clear Audit Log?'}
              </h3>
              <p className="text-xs text-archive-paper-muted mb-6 leading-relaxed">
                {isAr
                  ? 'هل أنت متأكد من رغبتك في مسح سجل التفاعلات الحالي؟ سيتم إعادة تعيين السجل المؤقت في الذاكرة.'
                  : 'Are you sure you want to clear recent in-memory audit logs? This action is logged permanently for administrative compliance.'}
              </p>
              <div className="flex items-center justify-center gap-3">
                <button
                  onClick={() => setShowClearConfirm(false)}
                  disabled={clearing}
                  className="px-4 py-2 rounded-xl bg-archive-dark border border-white/10 text-archive-paper text-xs font-semibold hover:bg-white/5 transition-colors cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  onClick={handleClearLogs}
                  disabled={clearing}
                  className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {clearing ? <RefreshCw size={14} className="animate-spin" /> : <Trash2 size={14} />}
                  <span>{isAr ? 'تأكيد المسح' : 'Yes, Clear Log'}</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
