import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  Sparkles,
  ArrowRight,
  Shield,
  Zap,
  Crown,
  Layers,
  Sliders,
  CheckCircle2,
  AlertCircle,
  Search,
  X,
  Swords,
  Lock,
  ArrowLeft,
  ChevronRight
} from 'lucide-react';
import { useCards } from '../context/CardContext';
import { useItems } from '../context/ItemContext';
import { useCardUpgrade } from '../context/CardUpgradeContext';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import {
  CollectibleCardData,
  CardRarity,
  getUnifiedCardStats,
  calculateCardOverallRating,
  calculateCardPowerRating
} from '../types/cards';
import {
  getNextRarityTier,
  CardUpgradeTransitionRule,
  CardUpgradeAttemptResult,
  DEFAULT_CARD_UPGRADE_CONFIG
} from '../types/cardUpgrade';
import { CollectibleCard } from '../components/cards/CollectibleCard';
import { OwnerUnifiedItemManagerModal } from '../components/items/OwnerUnifiedItemManagerModal';
import { playBattleSound } from '../utils/battleAudio';

export const CardUpgradePage: React.FC = () => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { isOwner, isAuthenticated, loginWithDiscord } = useAuth();
  const { catalog, profile, fetchCatalog, refreshProfile } = useCards();
  const { inventory, items, fetchInventory } = useItems();
  const { upgradeConfig, attemptUpgradeCard } = useCardUpgrade();

  const [searchParams, setSearchParams] = useSearchParams();
  const initialCardId = searchParams.get('cardId');

  const [selectedCardId, setSelectedCardId] = useState<string | null>(initialCardId || null);
  const [rarityFilter, setRarityFilter] = useState<'ALL' | CardRarity>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [isUpgrading, setIsUpgrading] = useState(false);
  const [attemptResult, setAttemptResult] = useState<CardUpgradeAttemptResult | null>(null);
  const [showResultModal, setShowResultModal] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // All user-owned cards
  const ownedCardsList = useMemo(() => {
    if (!profile?.cards) return [];
    return catalog.filter(card => {
      const ownership = profile.cards[card.id];
      return ownership && (ownership.count || 0) > 0;
    });
  }, [catalog, profile?.cards]);

  // Default to first card if none selected
  useEffect(() => {
    if (!selectedCardId && ownedCardsList.length > 0) {
      setSelectedCardId(ownedCardsList[0].id);
    }
  }, [ownedCardsList, selectedCardId]);

  // Sync with URL query parameter
  useEffect(() => {
    if (initialCardId && catalog.some(c => c.id === initialCardId)) {
      setSelectedCardId(initialCardId);
    }
  }, [initialCardId, catalog]);

  // Currently selected card object
  const selectedCard = useMemo(() => {
    if (!selectedCardId) return null;
    return catalog.find(c => c.id === selectedCardId) || null;
  }, [selectedCardId, catalog]);

  // Selected card ownership details
  const cardOwnership = useMemo(() => {
    if (!selectedCardId || !profile?.cards) return null;
    return profile.cards[selectedCardId] || null;
  }, [selectedCardId, profile?.cards]);

  // Current effective rarity
  const currentRarity: CardRarity = useMemo(() => {
    if (!selectedCard) return 'COMMON';
    return (cardOwnership?.upgradedRarity as CardRarity) || selectedCard.rarity;
  }, [selectedCard, cardOwnership]);

  // Next rarity tier
  const nextRarity = useMemo(() => {
    return getNextRarityTier(currentRarity);
  }, [currentRarity]);

  // Transition rule
  const transitionRule: CardUpgradeTransitionRule | null = useMemo(() => {
    if (!nextRarity) return null;
    const transitionKey = `${currentRarity}_TO_${nextRarity}`;
    return upgradeConfig.transitions[transitionKey] || DEFAULT_CARD_UPGRADE_CONFIG.transitions[transitionKey] || null;
  }, [currentRarity, nextRarity, upgradeConfig.transitions]);

  // Resource calculations
  const totalCopiesOwned = cardOwnership?.count || 0;
  const availableDuplicates = Math.max(0, totalCopiesOwned - 1);
  const requiredDuplicates = transitionRule?.requiredDuplicates ?? 0;
  const missingDuplicates = Math.max(0, requiredDuplicates - availableDuplicates);
  const hasEnoughDuplicates = availableDuplicates >= requiredDuplicates;

  // Shards
  const requiredShardCount = transitionRule?.requiredShardCount ?? 0;
  const primaryShardItemId = transitionRule?.requiredShardItemId || '';
  const primaryShardItem = useMemo(() => {
    if (!primaryShardItemId) return null;
    return items.find(i => i.id === primaryShardItemId) || null;
  }, [primaryShardItemId, items]);

  const ownedPrimaryShards = primaryShardItemId ? (inventory[primaryShardItemId]?.count || 0) : 0;
  const universalShardCount = upgradeConfig.allowUniversalShards && upgradeConfig.universalShardItemId
    ? (inventory[upgradeConfig.universalShardItemId]?.count || 0)
    : 0;

  const totalEffectiveShards = ownedPrimaryShards + (ownedPrimaryShards < requiredShardCount ? universalShardCount : 0);
  const missingShards = Math.max(0, requiredShardCount - totalEffectiveShards);
  const hasEnoughShards = requiredShardCount === 0 || totalEffectiveShards >= requiredShardCount;

  const isLegendary = currentRarity === 'LEGENDARY';
  const canUpgrade = Boolean(
    isAuthenticated &&
    selectedCard &&
    nextRarity &&
    transitionRule &&
    hasEnoughDuplicates &&
    hasEnoughShards &&
    !isUpgrading &&
    !isLegendary
  );

  // Filtered owned cards for dock
  const filteredOwnedCards = useMemo(() => {
    return ownedCardsList.filter(card => {
      const ownership = profile?.cards[card.id];
      const effRarity = (ownership?.upgradedRarity as CardRarity) || card.rarity;

      if (rarityFilter !== 'ALL' && effRarity !== rarityFilter) return false;

      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchesName = card.name.toLowerCase().includes(query);
        const matchesTitle = card.title?.toLowerCase().includes(query);
        if (!matchesName && !matchesTitle) return false;
      }

      return true;
    });
  }, [ownedCardsList, profile?.cards, rarityFilter, searchQuery]);

  // Projected stats
  const currentStats = useMemo(() => {
    if (!selectedCard) return [];
    return cardOwnership?.upgradedStats || getUnifiedCardStats(selectedCard);
  }, [selectedCard, cardOwnership]);

  const currentOvr = useMemo(() => {
    return calculateCardOverallRating(currentStats, currentRarity);
  }, [currentStats, currentRarity]);

  const projectedOvr = useMemo(() => {
    if (!transitionRule || !nextRarity) return currentOvr;
    const mult = transitionRule.statMultiplier || 1.15;
    const boostAtk = transitionRule.flatAttackBoost || 10;
    const boostDef = transitionRule.flatDefenseBoost || 8;
    const boostHp = transitionRule.flatHpBoost || 12;

    const projectedStats = currentStats.map(s => {
      let boosted = Math.round((s.value || 50) * mult);
      if (s.id === 'attack') boosted += boostAtk;
      else if (s.id === 'defense') boosted += boostDef;
      else if (s.id === 'hp') boosted += boostHp;
      return {
        ...s,
        value: Math.min(100, boosted)
      };
    });
    return calculateCardOverallRating(projectedStats, nextRarity);
  }, [currentStats, transitionRule, nextRarity, currentOvr]);

  const handleSelectCard = (card: CollectibleCardData) => {
    setSelectedCardId(card.id);
    setSearchParams({ cardId: card.id });
    setErrorMessage(null);
    playBattleSound('TACTICAL_SELECT', 0.6);
  };

  const handlePerformUpgrade = async () => {
    if (!canUpgrade || !selectedCard) return;

    setIsUpgrading(true);
    setErrorMessage(null);
    playBattleSound('ENERGY_SURGE', 0.9);

    try {
      const res = await attemptUpgradeCard(selectedCard.id);
      setAttemptResult(res);
      setShowResultModal(true);

      if (res.success) {
        playBattleSound('VICTORY_FANFARE', 1.0);
      } else {
        playBattleSound('DEFEAT_CHORD', 0.8);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Upgrade failed');
      playBattleSound('GUARD_BREAK', 0.8);
    } finally {
      setIsUpgrading(false);
      await Promise.all([fetchCatalog(), refreshProfile(), fetchInventory()]);
    }
  };

  return (
    <div
      dir={isAr ? 'rtl' : 'ltr'}
      className="relative min-h-[calc(100vh-4rem)] w-full py-2.5 sm:py-5 px-2.5 sm:px-4 max-w-6xl mx-auto flex flex-col font-sans box-border"
    >
      {/* Sleek, Minimalist Top Navigation Header */}
      <div className="flex items-center justify-between gap-2 pb-2.5 mb-3 border-b border-white/10 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <Link
            to="/decks"
            className="p-1.5 sm:p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white border border-white/10 transition-colors cursor-pointer shrink-0"
            title={isAr ? 'العودة للتشكيلات والحقيبة' : 'Back to Decks & Inventory'}
          >
            <ArrowLeft size={15} className={isAr ? 'rotate-180' : ''} />
          </Link>
          <div className="min-w-0">
            <h1 className="text-base sm:text-xl font-bold font-sans text-white tracking-tight flex items-center gap-1.5 truncate">
              <span>{isAr ? 'ترقية البطاقة' : 'Card Upgrade'}</span>
              <Sparkles size={15} className="text-amber-400 shrink-0 animate-pulse" />
            </h1>
          </div>
        </div>

        {/* Quick Nav Links */}
        <div className="flex items-center gap-1.5 shrink-0">
          {isOwner && (
            <button
              type="button"
              onClick={() => setIsSettingsModalOpen(true)}
              className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 text-[11px] font-mono font-bold flex items-center gap-1 transition-all cursor-pointer"
              title="Settings"
            >
              <Sliders size={13} />
              <span className="hidden sm:inline">{isAr ? 'الإعدادات' : 'Settings'}</span>
            </button>
          )}

          <Link
            to="/decks"
            className="px-2.5 py-1.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-slate-300 border border-white/10 text-[11px] font-mono font-semibold flex items-center gap-1 transition-colors cursor-pointer"
          >
            <Layers size={13} className="text-cyan-400" />
            <span>{isAr ? 'التشكيلات والحقيبة' : 'Decks & Bag'}</span>
          </Link>
        </div>
      </div>

      {/* Main Content View */}
      {!isAuthenticated ? (
        <div className="p-6 rounded-2xl bg-slate-950/80 border border-amber-500/30 text-center max-w-sm mx-auto my-auto space-y-3 shadow-xl">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
            <Lock size={20} />
          </div>
          <h2 className="text-sm font-bold text-white">
            {isAr ? 'سجّل الدخول لترقية بطاقاتك' : 'Sign In Required'}
          </h2>
          <button
            type="button"
            onClick={loginWithDiscord}
            className="w-full py-2 rounded-xl bg-[#5865F2] hover:bg-[#4752c4] text-white text-xs font-bold font-mono transition-colors cursor-pointer"
          >
            {isAr ? 'تسجيل الدخول عبر ديسكورد' : 'Login with Discord'}
          </button>
        </div>
      ) : ownedCardsList.length === 0 ? (
        <div className="p-6 rounded-2xl bg-slate-950/80 border border-white/10 text-center max-w-sm mx-auto my-auto space-y-3">
          <Layers size={24} className="text-slate-400 mx-auto" />
          <h2 className="text-sm font-bold text-white">
            {isAr ? 'لا توجد بطاقات في حقيبتك' : 'No Cards Owned'}
          </h2>
          <Link
            to="/cards/shop"
            className="inline-block px-4 py-1.5 rounded-xl bg-amber-400 text-stone-950 text-xs font-bold font-mono"
          >
            {isAr ? 'متجر الحزم' : 'Card Shop'}
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {/* ========================================================= */}
          {/* THE ASCENSION ALTAR - NORMAL WIDE CARD & CONTROLS         */}
          {/* ========================================================= */}
          <div className="rounded-3xl p-4 sm:p-6 bg-gradient-to-b from-[#02181b]/95 via-[#031317]/95 to-[#01090c]/98 border border-[#5eead4]/30 shadow-2xl backdrop-blur-md relative overflow-hidden">
            <div className="absolute top-0 inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-[#5eead4]/60 to-transparent pointer-events-none" />

            <div className="flex flex-col lg:flex-row items-center lg:items-start gap-6 sm:gap-8">
              {/* Left: Normal Full-Width Uncompressed Collectible Card */}
              <div className="w-full max-w-[450px] sm:max-w-[480px] lg:max-w-[500px] xl:max-w-[520px] shrink-0 flex flex-col items-center mx-auto lg:mx-0">
                {selectedCard && (
                  <div className="w-full transition-transform duration-300 hover:scale-[1.01]">
                    <CollectibleCard
                      card={{
                        ...selectedCard,
                        rarity: currentRarity,
                        attack: cardOwnership?.customAttack ?? selectedCard.attack,
                        defense: cardOwnership?.customDefense ?? selectedCard.defense,
                        hp: cardOwnership?.customHp ?? selectedCard.hp,
                        overallRating: currentOvr,
                        powerRating: calculateCardPowerRating(currentStats, currentRarity)
                      }}
                      size="normal"
                      isOwned={true}
                      duplicateCount={totalCopiesOwned}
                    />
                  </div>
                )}
                {/* Duplicates Badge Underneath Card */}
                <div className="mt-3 inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-black/80 border border-white/15 text-xs font-mono shadow-sm">
                  <span className="text-slate-400">{isAr ? 'النسخ المملوكة:' : 'Total Copies:'}</span>
                  <strong className="text-amber-300 font-bold">{totalCopiesOwned}</strong>
                  <span className="text-slate-600">·</span>
                  <span className="text-slate-400">{isAr ? 'المكررات:' : 'Duplicates:'}</span>
                  <strong className={availableDuplicates > 0 ? 'text-emerald-400 font-bold' : 'text-slate-400 font-bold'}>
                    {availableDuplicates}
                  </strong>
                </div>
              </div>

              {/* Right: Sleek Requirements & Action Center */}
              <div className="flex-1 w-full min-w-0 flex flex-col justify-between space-y-4">
                {/* Tier & OVR Metric Pill */}
                <div className="flex items-center justify-between gap-2 p-2 rounded-xl bg-black/50 border border-white/10 text-xs font-mono">
                  <div className="flex items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded-md bg-slate-900 text-slate-200 text-[10px] font-bold border border-white/10">
                      {currentRarity}
                    </span>
                    {!isLegendary && nextRarity ? (
                      <>
                        <ArrowRight size={12} className={`text-amber-400 ${isAr ? 'rotate-180' : ''}`} />
                        <span className="px-2 py-0.5 rounded-md bg-gradient-to-r from-amber-400 to-yellow-500 text-stone-950 text-[10px] font-black">
                          {nextRarity}
                        </span>
                      </>
                    ) : (
                      <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                        MAX
                      </span>
                    )}
                  </div>

                  {/* OVR progression */}
                  <div className="flex items-center gap-1 text-[11px]">
                    <span className="text-slate-400">OVR:</span>
                    <span className="font-black text-cyan-300">{currentOvr}</span>
                    {!isLegendary && nextRarity && (
                      <>
                        <span className="text-slate-500">➔</span>
                        <span className="font-black text-emerald-300">{projectedOvr}</span>
                        <span className="text-[10px] text-emerald-400 font-bold">(+{projectedOvr - currentOvr})</span>
                      </>
                    )}
                  </div>
                </div>

                {/* Compact Slots */}
                <div className="space-y-1.5">
                  {/* Slot 1: Exact Card Duplicates */}
                  <div className={`p-2 rounded-xl border flex items-center justify-between gap-2 transition-all text-xs font-mono ${
                    hasEnoughDuplicates
                      ? 'bg-emerald-950/20 border-emerald-500/40'
                      : 'bg-black/40 border-white/10'
                  }`}>
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-7 h-7 rounded-lg overflow-hidden bg-slate-950 shrink-0 border border-white/15">
                        {selectedCard?.imageUrl ? (
                          <img src={selectedCard.imageUrl} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <Layers size={14} className="text-amber-400 m-auto" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <span className="text-[11px] font-bold text-white block truncate">
                          {isAr ? 'نسخة مكررة' : 'Duplicate Card'}
                        </span>
                        <span className="text-[9.5px] text-slate-400 block">
                          {isAr ? 'نفس البطاقة' : 'Exact Match'}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <span className={`font-black text-xs ${hasEnoughDuplicates ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {availableDuplicates} / {requiredDuplicates}
                      </span>
                      {hasEnoughDuplicates && (
                        <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                      )}
                    </div>
                  </div>

                  {/* Slot 2: Shards (if needed) */}
                  {requiredShardCount > 0 && (
                    <div className={`p-2 rounded-xl border flex items-center justify-between gap-2 transition-all text-xs font-mono ${
                      hasEnoughShards
                        ? 'bg-emerald-950/20 border-emerald-500/40'
                        : 'bg-black/40 border-white/10'
                    }`}>
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="w-7 h-7 rounded-lg bg-black/60 flex items-center justify-center shrink-0 border border-white/15">
                          {primaryShardItem?.imageUrl ? (
                            <img src={primaryShardItem.imageUrl} alt="" className="w-6 h-6 object-contain" />
                          ) : (
                            <Sparkles size={14} className="text-cyan-400" />
                          )}
                        </div>
                        <div className="min-w-0">
                          <span className="text-[11px] font-bold text-white block truncate">
                            {primaryShardItem?.name || (isAr ? 'شظية الترقية' : 'Ascension Shard')}
                          </span>
                          <span className="text-[9.5px] text-cyan-300 block">
                            {primaryShardItem?.rarity || currentRarity}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className={`font-black text-xs ${hasEnoughShards ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {totalEffectiveShards} / {requiredShardCount}
                        </span>
                        {hasEnoughShards && (
                          <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Error Banner if any */}
                {errorMessage && (
                  <div className="p-2 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-[11px] flex items-center gap-1.5 font-mono">
                    <AlertCircle size={13} className="shrink-0 text-rose-400" />
                    <span className="truncate">{errorMessage}</span>
                  </div>
                )}

                {/* Upgrade Action Button with Success Rate */}
                <div className="pt-1">
                  <button
                    type="button"
                    disabled={!canUpgrade || isUpgrading}
                    onClick={handlePerformUpgrade}
                    className={`w-full py-2.5 sm:py-3 px-4 rounded-xl font-mono font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md ${
                      canUpgrade
                        ? 'bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-400 hover:brightness-110 text-stone-950 shadow-amber-500/25 active:scale-98'
                        : 'bg-slate-900/90 text-slate-500 border border-white/10 cursor-not-allowed opacity-60'
                    }`}
                  >
                    <Sparkles size={15} className={isUpgrading ? 'animate-spin' : ''} />
                    <span>
                      {isUpgrading
                        ? (isAr ? 'جاري الترقية...' : 'Upgrading...')
                        : isLegendary
                        ? (isAr ? 'الحد الأقصى (LEGENDARY)' : 'Maximum Rarity Reached')
                        : !hasEnoughDuplicates
                        ? (isAr ? `ينقصك ${missingDuplicates} نسخة مكررة` : `Need ${missingDuplicates} More Duplicate`)
                        : !hasEnoughShards
                        ? (isAr ? `ينقصك ${missingShards} شظية` : `Need ${missingShards} More Shards`)
                        : (isAr ? `ترقية إلى ${nextRarity} (${transitionRule?.successRatePercent ?? 85}%)` : `Ascend to ${nextRarity} (${transitionRule?.successRatePercent ?? 85}%)`)}
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* ========================================================= */}
          {/* COMPACT CARD SELECTOR DOCK                                */}
          {/* ========================================================= */}
          <div className="p-2.5 sm:p-3 rounded-2xl bg-black/40 border border-white/10 space-y-2 backdrop-blur-md">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-white">
                <Layers size={13} className="text-cyan-400" />
                <span>{isAr ? 'اختر بطاقة من حقيبتك' : 'Select Card'}</span>
                <span className="text-[10px] text-slate-400 font-normal">({filteredOwnedCards.length})</span>
              </div>

              {/* Rarity filter pills */}
              <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
                {(['ALL', 'COMMON', 'UNCOMMON', 'RARE', 'EPIC', 'LEGENDARY'] as const).map(rarity => (
                  <button
                    key={rarity}
                    type="button"
                    onClick={() => setRarityFilter(rarity)}
                    className={`px-2 py-0.5 rounded-full text-[9px] font-mono font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                      rarityFilter === rarity
                        ? 'bg-amber-400 text-stone-950 font-black'
                        : 'bg-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    {rarity}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick search input */}
            <div className="relative w-full">
              <Search size={12} className="absolute start-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder={isAr ? 'بحث سريع عن بطاقة...' : 'Filter cards...'}
                className="w-full ps-7 pe-7 py-1 rounded-lg bg-black/50 border border-white/10 text-xs text-white placeholder:text-slate-500 focus:outline-hidden focus:border-amber-400/60"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute end-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X size={12} />
                </button>
              )}
            </div>

            {/* Compact Cards Reel / Grid */}
            <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-1.5 max-h-[170px] sm:max-h-[200px] overflow-y-auto custom-scrollbar p-0.5">
              {filteredOwnedCards.map(card => {
                const ownership = profile?.cards[card.id];
                const effRarity = (ownership?.upgradedRarity as CardRarity) || card.rarity;
                const count = ownership?.count || 1;
                const isSelected = selectedCardId === card.id;

                return (
                  <button
                    key={card.id}
                    type="button"
                    onClick={() => handleSelectCard(card)}
                    className={`relative p-1 rounded-xl border transition-all text-start cursor-pointer group flex flex-col items-center ${
                      isSelected
                        ? 'bg-amber-500/20 border-amber-400 shadow-[0_0_12px_rgba(245,158,11,0.4)] scale-[1.02]'
                        : 'bg-black/50 border-white/10 hover:border-white/30'
                    }`}
                  >
                    <div className="w-full aspect-[5/7] rounded-lg overflow-hidden bg-slate-950 relative">
                      <img
                        src={card.imageUrl}
                        alt={card.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                      <span className="absolute top-0.5 end-0.5 px-1 py-0.2 rounded-sm bg-black/80 text-[8px] font-mono text-amber-300 font-bold">
                        x{count}
                      </span>
                    </div>
                    <span className="w-full text-[9px] font-bold text-white truncate text-center mt-1">
                      {card.name}
                    </span>
                    <span className="text-[7.5px] font-mono text-slate-400 truncate">
                      {effRarity}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* COMPACT ASCENSION RESULT MODAL                            */}
      {/* ========================================================= */}
      <AnimatePresence>
        {showResultModal && attemptResult && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className={`relative w-full max-w-sm rounded-2xl p-5 border shadow-2xl flex flex-col items-center text-center ${
                attemptResult.success
                  ? 'bg-gradient-to-b from-[#05211f] to-black border-[#5eead4]/60'
                  : 'bg-gradient-to-b from-[#210507] to-black border-rose-500/50'
              }`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-2.5 ${
                attemptResult.success
                  ? 'bg-amber-400 text-stone-950 shadow-md'
                  : 'bg-rose-950 text-rose-400 border border-rose-500/40'
              }`}>
                {attemptResult.success ? <Crown size={22} /> : <AlertCircle size={22} />}
              </div>

              <h2 className="text-base font-bold text-white">
                {attemptResult.success
                  ? (isAr ? 'تمت الترقية بنجاح!' : 'Upgrade Success!')
                  : (isAr ? 'فشلت الترقية' : 'Upgrade Failed')}
              </h2>

              <p className="text-xs text-slate-300 mt-1">
                {isAr ? attemptResult.messageAr : attemptResult.message}
              </p>

              {/* Rarity & OVR Jump */}
              <div className="flex items-center gap-1.5 my-3 px-3 py-1.5 rounded-xl bg-black/60 border border-white/10 font-mono text-xs">
                <span className="text-slate-300 font-bold">{attemptResult.previousRarity}</span>
                <ArrowRight size={11} className="text-amber-400" />
                <span className={`font-black ${attemptResult.success ? 'text-amber-300' : 'text-slate-400'}`}>
                  {attemptResult.newRarity}
                </span>
                {attemptResult.success && (
                  <span className="ms-1.5 text-emerald-300 font-bold text-[11px]">
                    OVR: {attemptResult.previousOvr} ➔ {attemptResult.newOvr}
                  </span>
                )}
              </div>

              <button
                type="button"
                onClick={() => setShowResultModal(false)}
                className="w-full mt-2 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 text-stone-950 font-mono font-bold text-xs uppercase cursor-pointer"
              >
                {isAr ? 'حسناً' : 'Done'}
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Owner Settings Modal */}
      {isSettingsModalOpen && (
        <OwnerUnifiedItemManagerModal
          isOpen={isSettingsModalOpen}
          onClose={() => setIsSettingsModalOpen(false)}
        />
      )}
    </div>
  );
};
