import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronLeft, ChevronRight, Shield, Star, Calendar, Activity, 
  Plus, Minus, Edit3, UserX, UserCheck, Trash2, Copy, Check, 
  Award, History, AlertCircle, Loader, ArrowUpRight, ArrowDownRight, Clock,
  Trophy
} from 'lucide-react';
import { doc, onSnapshot, collection } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useLanguage } from '../context/LanguageContext';
import { useStaff } from '../context/StaffContext';
import { useAuth } from '../context/AuthContext';
import { useAchievements } from '../context/AchievementContext';
import { AchievementCard } from '../components/achievements/AchievementCard';
import { StaffMember, StaffHistoryEvent, StaffPointTransaction } from '../types/staff';
import { getRankBadgeConfig, getStatusBadgeConfig, formatRelativeTime } from '../utils/staffHelpers';
import { PointsModal } from '../components/staff/PointsModal';
import { EditStaffModal } from '../components/staff/EditStaffModal';

export function StaffProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t, language } = useLanguage();
  const isAr = language === 'ar';
  const { staff, getStaffDetails, suspendStaff, reactivateStaff, removeStaff } = useStaff();
  const { hasPermission } = useAuth();
  const { evaluateMemberAchievements } = useAchievements();

  const canEdit = hasPermission('EDIT_STAFF');
  const canSuspend = hasPermission('SUSPEND_STAFF');
  const canRemove = hasPermission('REMOVE_STAFF');
  const canManagePoints = hasPermission('MANAGE_POINTS') || hasPermission('ADD_POINTS');

  const [member, setMember] = useState<StaffMember | null>(null);
  const [history, setHistory] = useState<StaffHistoryEvent[]>([]);
  const [pointTransactions, setPointTransactions] = useState<StaffPointTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState(false);

  // Tabs & filters
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'POINTS' | 'AUDIT' | 'ACHIEVEMENTS'>('OVERVIEW');
  const [pointsFilter, setPointsFilter] = useState<'ALL' | 'ADD' | 'REMOVE'>('ALL');
  const [pointsSort, setPointsSort] = useState<'NEWEST' | 'HIGHEST'>('NEWEST');

  // Evaluated achievements for this staff member
  const memberAchievements = useMemo(() => {
    if (!member) return [];
    return evaluateMemberAchievements(member);
  }, [member, evaluateMemberAchievements]);

  const unlockedAchievementsCount = useMemo(() => {
    return memberAchievements.filter((a) => a.isUnlocked).length;
  }, [memberAchievements]);

  // Modals
  const [isPointsOpen, setIsPointsOpen] = useState(false);
  const [pointsType, setPointsType] = useState<'ADD' | 'REMOVE'>('ADD');
  const [isEditOpen, setIsEditOpen] = useState(false);

  // 1. Initial Load & Hydration
  const loadProfile = useCallback(async () => {
    if (!id) return;
    try {
      // First check local state for immediate response
      const localMatch = staff.find(s => String(s.id) === String(id) || s.discordId === id);
      if (localMatch) {
        setMember(localMatch);
      }

      // Then fetch authoritative details from API
      const details = await getStaffDetails(id);
      if (details.staff) {
        setMember(details.staff);
        setHistory(details.history || []);
        setPointTransactions(details.pointTransactions || []);
      }
    } catch (err) {
      console.warn('Could not load profile via API:', err);
    } finally {
      setLoading(false);
    }
  }, [id, staff, getStaffDetails]);

  useEffect(() => {
    loadProfile();
  }, [loadProfile]);

  // 2. Real-time Firestore sync
  useEffect(() => {
    if (!member) return;
    const resolvedDocId = member.discordId ? `staff_${member.discordId}` : String(member.id);
    const staffRef = doc(db, 'staff', resolvedDocId);

    const unsub = onSnapshot(staffRef, (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setMember(prev => prev ? ({
          ...prev,
          displayName: data.displayName || prev.displayName,
          username: data.username || prev.username,
          avatarUrl: data.avatarUrl || prev.avatarUrl,
          rank: data.rank || prev.rank,
          points: typeof data.points === 'number' ? data.points : prev.points,
          status: data.status || prev.status,
          notes: data.notes ?? prev.notes,
          updatedAt: data.updatedAt || prev.updatedAt
        }) : null);
      }
    }, (err) => {
      // Ignore quiet permission error on Firestore
    });

    return () => unsub();
  }, [member?.discordId, member?.id]);

  if (loading) {
    return (
      <main className="flex-1 pt-32 pb-24 px-4 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-slate-400 font-sans">
          <Loader className="w-8 h-8 animate-spin text-cyan-400" />
          <span className="text-sm">{isAr ? 'جاري تحميل ملف الإداري...' : 'Loading staff profile...'}</span>
        </div>
      </main>
    );
  }

  if (!member) {
    return (
      <main className="flex-1 pt-32 pb-24 px-4 max-w-2xl mx-auto w-full text-center">
        <div className="p-8 rounded-3xl bg-slate-900/60 border border-slate-800 text-slate-400 space-y-4">
          <AlertCircle size={40} className="mx-auto text-amber-400" />
          <h2 className="text-xl font-bold text-white font-display">
            {isAr ? 'عضو الإدارة غير موجود' : 'Staff Member Not Found'}
          </h2>
          <p className="text-xs text-slate-400 font-sans">
            {isAr 
              ? 'لم يتم العثور على سجل الإداري المطلوب أو قد تم استبعاده من الطاقم.' 
              : 'The requested staff profile does not exist or has been removed from service.'}
          </p>
          <Link
            to="/staff-management"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30 border border-cyan-500/30 text-xs font-semibold transition-colors"
          >
            {isAr ? <ChevronRight size={15} /> : <ChevronLeft size={15} />}
            <span>{isAr ? 'العودة لإدارة الطاقم' : 'Back to Staff Management'}</span>
          </Link>
        </div>
      </main>
    );
  }

  const rankCfg = getRankBadgeConfig(member.rank);
  const statusCfg = getStatusBadgeConfig(member.status);

  const handleCopyId = () => {
    navigator.clipboard.writeText(member.discordId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleToggleStatus = async () => {
    try {
      if (member.status === 'ACTIVE') {
        await suspendStaff(member.id);
      } else {
        await reactivateStaff(member.id);
      }
      loadProfile();
    } catch (e: any) {
      alert(e?.message || 'Failed to update status');
    }
  };

  const handleRemove = async () => {
    if (!confirm(isAr ? 'هل أنت متأكد من رغبتك في استبعاد هذا الإداري من الطاقم؟' : 'Are you sure you want to remove this staff member?')) return;
    try {
      await removeStaff(member.id);
      navigate('/staff-management');
    } catch (e: any) {
      alert(e?.message || 'Failed to remove staff member');
    }
  };

  // Points computation
  const pointsEarned = pointTransactions.filter(pt => pt.type === 'ADD').reduce((sum, pt) => sum + pt.amount, 0);
  const pointsRemoved = pointTransactions.filter(pt => pt.type === 'REMOVE').reduce((sum, pt) => sum + pt.amount, 0);

  let filteredTransactions = [...pointTransactions];
  if (pointsFilter !== 'ALL') {
    filteredTransactions = filteredTransactions.filter(pt => pt.type === pointsFilter);
  }
  if (pointsSort === 'NEWEST') {
    filteredTransactions.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } else {
    filteredTransactions.sort((a, b) => b.amount - a.amount);
  }

  return (
    <main className="flex-1 pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto w-full relative z-10" dir={isAr ? 'rtl' : 'ltr'}>
      {/* Breadcrumb Navigation */}
      <div className="mb-6 flex items-center justify-between">
        <Link
          to="/staff-management"
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
        >
          {isAr ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          <span>{isAr ? 'العودة لإدارة الطاقم' : 'Back to Staff Management'}</span>
        </Link>
      </div>

      {/* Profile Header Hero */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl bg-slate-900/80 border border-slate-800 shadow-2xl backdrop-blur-xl mb-8"
      >
        {/* Banner with Role-Specific Ambient Gradient */}
        <div className={`h-32 bg-gradient-to-r ${rankCfg.gradientClass} relative`}>
          <div className="absolute inset-0 bg-slate-950/40" />
        </div>

        {/* Content */}
        <div className="px-6 sm:px-8 pb-8 -mt-16 relative">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            {/* Avatar & User Details */}
            <div className="flex flex-col sm:flex-row sm:items-end gap-5">
              <div className="relative shrink-0">
                <img
                  src={member.avatarUrl}
                  alt={member.displayName}
                  className="w-28 h-28 rounded-3xl border-4 border-slate-900 bg-slate-950 object-cover shadow-2xl"
                />
                <span className={`absolute bottom-1 end-1 w-5 h-5 rounded-full border-2 border-slate-900 ${statusCfg.dotClass}`} />
              </div>

              <div>
                <div className="flex flex-wrap items-center gap-3 mb-1">
                  <h1 className="text-2xl sm:text-3xl font-bold text-white font-display">
                    {member.displayName}
                  </h1>
                  <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${rankCfg.bgClass} ${rankCfg.textClass} ${rankCfg.borderClass}`}>
                    <Shield size={13} />
                    <span>{isAr ? rankCfg.labelAr : rankCfg.label}</span>
                  </span>
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border ${statusCfg.bgClass} ${statusCfg.textClass} ${statusCfg.borderClass}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${statusCfg.dotClass}`} />
                    <span>{isAr ? statusCfg.labelAr : statusCfg.label}</span>
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 font-sans">
                  <span>@{member.username}</span>
                  <span>•</span>
                  <button
                    onClick={handleCopyId}
                    className="inline-flex items-center gap-1.5 font-mono text-xs bg-slate-800/80 hover:bg-slate-800 text-slate-300 px-2.5 py-1 rounded-lg border border-slate-700/60 transition-colors"
                  >
                    <span>ID: {member.discordId}</span>
                    {copiedId ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                  </button>
                </div>
              </div>
            </div>

            {/* Top Right Action Buttons */}
            <div className="flex flex-wrap items-center gap-2.5">
              {canManagePoints && (
                <>
                  <button
                    onClick={() => { setPointsType('ADD'); setIsPointsOpen(true); }}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 transition-colors"
                  >
                    <Plus size={15} />
                    <span>{isAr ? 'إضافة نقاط' : 'Grant Points'}</span>
                  </button>

                  <button
                    onClick={() => { setPointsType('REMOVE'); setIsPointsOpen(true); }}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 border border-rose-500/30 transition-colors"
                  >
                    <Minus size={15} />
                    <span>{isAr ? 'خصم نقاط' : 'Deduct Points'}</span>
                  </button>
                </>
              )}

              {canEdit && (
                <button
                  onClick={() => setIsEditOpen(true)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-400 border border-cyan-500/30 transition-colors"
                >
                  <Edit3 size={15} />
                  <span>{isAr ? 'تعديل البيانات' : 'Edit Profile'}</span>
                </button>
              )}

              {canSuspend && (
                <button
                  onClick={handleToggleStatus}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-amber-500/15 hover:bg-amber-500/25 text-amber-400 border border-amber-500/30 transition-colors"
                >
                  {member.status === 'ACTIVE' ? (
                    <>
                      <UserX size={15} />
                      <span>{isAr ? 'إيقاف مؤقت' : 'Suspend'}</span>
                    </>
                  ) : (
                    <>
                      <UserCheck size={15} />
                      <span>{isAr ? 'إلغاء الإيقاف' : 'Reactivate'}</span>
                    </>
                  )}
                </button>
              )}

              {canRemove && (
                <button
                  onClick={handleRemove}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 transition-colors"
                  title={isAr ? 'استبعاد الإداري' : 'Remove staff'}
                >
                  <Trash2 size={15} />
                </button>
              )}
            </div>
          </div>

          {/* Quick Metrics Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800/80">
            <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Star size={14} className="text-amber-400" />
                <span>{isAr ? 'رصيد النقاط' : 'Current Points'}</span>
              </div>
              <div className="text-2xl font-bold text-white font-display mt-1">
                {member.points.toLocaleString()}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <ArrowUpRight size={14} className="text-emerald-400" />
                <span>{isAr ? 'النقاط الممنوحة' : 'Points Earned'}</span>
              </div>
              <div className="text-2xl font-bold text-emerald-400 font-display mt-1">
                +{pointsEarned.toLocaleString()}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Calendar size={14} className="text-cyan-400" />
                <span>{isAr ? 'تاريخ الانضمام' : 'Enrolled'}</span>
              </div>
              <div className="text-xs font-medium text-slate-200 mt-2 truncate">
                {formatRelativeTime(member.joinedAt, isAr)}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Clock size={14} className="text-purple-400" />
                <span>{isAr ? 'آخر نشاط' : 'Last Updated'}</span>
              </div>
              <div className="text-xs font-medium text-slate-200 mt-2 truncate">
                {formatRelativeTime(member.updatedAt, isAr)}
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 mb-6 font-sans">
        <button
          onClick={() => setActiveTab('OVERVIEW')}
          className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-colors ${
            activeTab === 'OVERVIEW'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          {isAr ? 'نظرة عامة' : 'Overview & Info'}
        </button>

        <button
          onClick={() => setActiveTab('POINTS')}
          className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'POINTS'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>{isAr ? 'سجل النقاط' : 'Points Ledger'}</span>
          <span className="px-2 py-0.5 text-[10px] rounded-full bg-slate-800 text-slate-300">
            {pointTransactions.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('AUDIT')}
          className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'AUDIT'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>{isAr ? 'السجل الرقابي' : 'Audit Trail'}</span>
          <span className="px-2 py-0.5 text-[10px] rounded-full bg-slate-800 text-slate-300">
            {history.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('ACHIEVEMENTS')}
          className={`pb-3 px-4 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'ACHIEVEMENTS'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Trophy size={14} className={activeTab === 'ACHIEVEMENTS' ? 'text-amber-400' : 'text-slate-400'} />
          <span>{isAr ? 'الإنجازات' : 'Achievements'}</span>
          <span className="px-2 py-0.5 text-[10px] rounded-full bg-slate-800 text-amber-300 font-mono">
            {unlockedAchievementsCount}/40
          </span>
        </button>
      </div>

      {/* Tab Panels */}
      {activeTab === 'OVERVIEW' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-sans">
          {/* Notes & Specializations */}
          <div className="lg:col-span-2 space-y-6">
            <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-3 flex items-center gap-2">
                <Shield size={16} className="text-cyan-400" />
                <span>{isAr ? 'ملاحظات الإدارة والمسؤوليات' : 'Administrative Notes & Responsibilities'}</span>
              </h3>
              {member.notes ? (
                <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-wrap bg-slate-950/40 p-4 rounded-2xl border border-slate-800/80">
                  {member.notes}
                </p>
              ) : (
                <p className="text-xs text-slate-500 italic">
                  {isAr ? 'لا توجد ملاحظات إدارية مخصصة لهذا الإداري.' : 'No internal administrative notes recorded for this staff member.'}
                </p>
              )}
            </div>

            {/* Quick Summary of Recent Activity */}
            <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                  <Award size={16} className="text-amber-400" />
                  <span>{isAr ? 'آخر معاملات النقاط' : 'Latest Point Awards'}</span>
                </h3>
                <button
                  onClick={() => setActiveTab('POINTS')}
                  className="text-xs text-cyan-400 hover:underline"
                >
                  {isAr ? 'عرض الكل' : 'View all'}
                </button>
              </div>

              {pointTransactions.length === 0 ? (
                <div className="text-xs text-slate-500 py-4 text-center">
                  {isAr ? 'لا توجد عمليات نقاط مسجلة بعد.' : 'No point transactions logged yet.'}
                </div>
              ) : (
                <div className="space-y-2.5">
                  {pointTransactions.slice(0, 4).map((pt, i) => (
                    <div
                      key={i}
                      className="p-3 rounded-2xl bg-slate-950/50 border border-slate-800/80 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-1.5 rounded-lg ${
                          pt.type === 'ADD' 
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}>
                          {pt.type === 'ADD' ? <Plus size={14} /> : <Minus size={14} />}
                        </div>
                        <div>
                          <div className="font-semibold text-white">{pt.reason}</div>
                          <div className="text-[11px] text-slate-400">
                            {formatRelativeTime(pt.createdAt, isAr)} • by {pt.performedBy}
                          </div>
                        </div>
                      </div>
                      <div className={`font-mono font-bold text-sm ${
                        pt.type === 'ADD' ? 'text-emerald-400' : 'text-rose-400'
                      }`}>
                        {pt.type === 'ADD' ? `+${pt.amount}` : `-${pt.amount}`}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Sidebar Info Card */}
          <div className="space-y-6">
            <div className="p-6 rounded-3xl bg-slate-900/60 border border-slate-800 space-y-4 text-xs">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300">
                {isAr ? 'تفاصيل السجل' : 'Roster Metadata'}
              </h3>

              <div className="space-y-3">
                <div>
                  <div className="text-slate-500 uppercase text-[10px] tracking-wider mb-0.5">
                    {isAr ? 'معرف الديسكورد الفريد' : 'Discord Snowflake'}
                  </div>
                  <div className="font-mono text-slate-200 bg-slate-950 p-2 rounded-xl border border-slate-800 select-all">
                    {member.discordId}
                  </div>
                </div>

                <div>
                  <div className="text-slate-500 uppercase text-[10px] tracking-wider mb-0.5">
                    {isAr ? 'رقم السجل الداخلي' : 'Internal Record ID'}
                  </div>
                  <div className="font-mono text-slate-200 bg-slate-950 p-2 rounded-xl border border-slate-800">
                    {member.id}
                  </div>
                </div>

                <div>
                  <div className="text-slate-500 uppercase text-[10px] tracking-wider mb-0.5">
                    {isAr ? 'تاريخ التسجيل' : 'Enrolled At'}
                  </div>
                  <div className="text-slate-200 font-medium">
                    {new Date(member.joinedAt).toLocaleString()}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Points Ledger */}
      {activeTab === 'POINTS' && (
        <div className="space-y-4 font-sans">
          {/* Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-semibold uppercase">
                {isAr ? 'التصنيف:' : 'Filter:'}
              </span>
              <button
                onClick={() => setPointsFilter('ALL')}
                className={`px-3 py-1 rounded-xl text-xs font-semibold transition-colors ${
                  pointsFilter === 'ALL'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {isAr ? 'الكل' : 'All'}
              </button>
              <button
                onClick={() => setPointsFilter('ADD')}
                className={`px-3 py-1 rounded-xl text-xs font-semibold transition-colors ${
                  pointsFilter === 'ADD'
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {isAr ? 'إضافات (+)' : 'Granted (+)'}
              </button>
              <button
                onClick={() => setPointsFilter('REMOVE')}
                className={`px-3 py-1 rounded-xl text-xs font-semibold transition-colors ${
                  pointsFilter === 'REMOVE'
                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {isAr ? 'خصومات (-)' : 'Deductions (-)'}
              </button>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-semibold uppercase">
                {isAr ? 'الترتيب:' : 'Sort:'}
              </span>
              <button
                onClick={() => setPointsSort(pointsSort === 'NEWEST' ? 'HIGHEST' : 'NEWEST')}
                className="px-3 py-1 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
              >
                {pointsSort === 'NEWEST' ? (isAr ? 'الأحدث أولاً' : 'Newest First') : (isAr ? 'الأعلى قيمة' : 'Highest Amount')}
              </button>
            </div>
          </div>

          {/* Transactions List */}
          {filteredTransactions.length === 0 ? (
            <div className="p-8 rounded-3xl bg-slate-900/40 border border-slate-800 text-center text-slate-500 text-sm">
              {isAr ? 'لا توجد معاملات نقاط مطابقة.' : 'No matching point transactions found.'}
            </div>
          ) : (
            <div className="space-y-3">
              {filteredTransactions.map((pt, i) => (
                <div
                  key={i}
                  className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-start gap-3.5">
                    <div className={`p-2 rounded-xl shrink-0 mt-0.5 ${
                      pt.type === 'ADD'
                        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20'
                        : 'bg-rose-500/15 text-rose-400 border border-rose-500/20'
                    }`}>
                      {pt.type === 'ADD' ? <Plus size={16} /> : <Minus size={16} />}
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-white mb-0.5">{pt.reason}</div>
                      {pt.note && (
                        <p className="text-xs text-slate-400 italic mb-1">"{pt.note}"</p>
                      )}
                      <div className="text-[11px] text-slate-500">
                        {new Date(pt.createdAt).toLocaleString()} • by <span className="text-slate-300 font-medium">{pt.performedBy}</span>
                      </div>
                    </div>
                  </div>

                  <div className={`text-lg font-bold font-mono text-end ${
                    pt.type === 'ADD' ? 'text-emerald-400' : 'text-rose-400'
                  }`}>
                    {pt.type === 'ADD' ? `+${pt.amount}` : `-${pt.amount}`}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab: Audit Trail */}
      {activeTab === 'AUDIT' && (
        <div className="space-y-3 font-sans">
          {history.length === 0 ? (
            <div className="p-8 rounded-3xl bg-slate-900/40 border border-slate-800 text-center text-slate-500 text-sm">
              {isAr ? 'لا توجد سجلات رقابية مسجلة لهذا الإداري.' : 'No audit history events recorded for this staff member.'}
            </div>
          ) : (
            <div className="space-y-2.5">
              {history.map((evt, i) => (
                <div
                  key={i}
                  className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-start justify-between gap-3 text-xs"
                >
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-slate-800 text-cyan-400 border border-slate-700">
                        {evt.action}
                      </span>
                      <span className="text-slate-400 text-[11px]">
                        {formatRelativeTime(evt.createdAt, isAr)}
                      </span>
                    </div>
                    <p className="text-slate-200 text-xs font-medium">
                      {evt.description}
                    </p>
                    <div className="text-[10px] text-slate-500 mt-1">
                      {isAr ? 'بواسطة:' : 'Triggered by:'} <span className="text-slate-400">{evt.performedBy}</span> • {new Date(evt.createdAt).toLocaleString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Achievements Tab Panel */}
      {activeTab === 'ACHIEVEMENTS' && (
        <div className="space-y-6">
          <div className="p-5 rounded-3xl bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                <Trophy size={22} />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-sans">
                  {isAr ? `إنجازات الإداري (${member.displayName || member.username})` : `Staff Achievements (${member.displayName || member.username})`}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {isAr 
                    ? `تم فتح ${unlockedAchievementsCount} من أصل 40 إنجازاً رسمياً في سيرفر CREATINE NEXUS`
                    : `Unlocked ${unlockedAchievementsCount} of 40 official CREATINE NEXUS achievements`}
                </p>
              </div>
            </div>

            <Link
              to="/achievements"
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 transition-colors inline-flex items-center gap-1.5 shrink-0"
            >
              <span>{isAr ? 'لوحة الإنجازات العامة' : 'Open Achievements Board'}</span>
              <ArrowUpRight size={14} />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {memberAchievements.map((achievement, idx) => (
              <AchievementCard
                key={achievement.definition.id}
                achievement={{
                  ...achievement,
                  isNew: false // Inspected on a profile, no reveal animation
                }}
                index={idx}
                isAr={isAr}
              />
            ))}
          </div>
        </div>
      )}

      {/* Points Modal */}
      <PointsModal
        isOpen={isPointsOpen}
        member={member}
        initialType={pointsType}
        onClose={() => setIsPointsOpen(false)}
        onSuccess={loadProfile}
      />

      {/* Edit Staff Modal */}
      <EditStaffModal
        isOpen={isEditOpen}
        member={member}
        onClose={() => setIsEditOpen(false)}
        onSuccess={loadProfile}
      />
    </main>
  );
}
