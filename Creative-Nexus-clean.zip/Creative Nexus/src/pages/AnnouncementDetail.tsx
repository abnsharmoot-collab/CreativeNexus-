import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, ArrowRight, Pin, Calendar, Clock, User, 
  Share2, Check, Edit2, Trash2, Shield, AlertCircle, Megaphone, Sparkles,
  Image as ImageIcon, ZoomIn
} from 'lucide-react';
import { useAnnouncements } from '../context/AnnouncementContext';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { AnnouncementContentRenderer } from '../components/announcements/AnnouncementContentRenderer';
import { AnnouncementModal } from '../components/announcements/AnnouncementModal';
import { PhotoLightboxModal } from '../components/announcements/PhotoLightboxModal';
import { Announcement, ANNOUNCEMENT_CATEGORIES } from '../types/announcement';

export const AnnouncementDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { role } = useAuth();
  const isOwner = role === 'OWNER';

  const {
    getAnnouncementById,
    updateAnnouncement,
    togglePin,
    deleteAnnouncement
  } = useAnnouncements();

  const [announcement, setAnnouncement] = useState<Announcement | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  // Photo Lightbox State
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxImages, setLightboxImages] = useState<string[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  const handleOpenLightbox = (images: string[], index = 0) => {
    setLightboxImages(images);
    setLightboxIndex(index);
    setLightboxOpen(true);
  };

  // Load announcement by ID
  useEffect(() => {
    let isMounted = true;

    async function loadData() {
      if (!id) return;
      try {
        setLoading(true);
        setError(null);
        const data = await getAnnouncementById(id);
        if (isMounted) {
          if (data) {
            setAnnouncement(data);
            document.title = `${data.title} | CREATINE NEXUS Announcements`;
          } else {
            setError(isAr ? 'لم يتم العثور على الإعلان المطلوب' : 'Announcement not found');
          }
        }
      } catch (err: any) {
        if (isMounted) {
          console.error('Error loading announcement:', err);
          setError(err.message || 'Failed to load announcement');
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadData();
    return () => {
      isMounted = false;
    };
  }, [id, getAnnouncementById, isAr]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleEditSubmit = async (data: {
    title: string;
    content: string;
    category: string;
    isPinned: boolean;
    authorDisplayName?: string;
    imageUrl?: string;
    images?: string[];
  }) => {
    if (!announcement) return;
    const updated = await updateAnnouncement(announcement.id, data);
    setAnnouncement(updated);
    setActionNotice(isAr ? 'تم حفظ التعديلات بنجاح' : 'Announcement updated successfully');
    setTimeout(() => setActionNotice(null), 3000);
  };

  const handleTogglePin = async () => {
    if (!announcement) return;
    const newPinned = !announcement.isPinned;
    await togglePin(announcement.id, newPinned);
    setAnnouncement((prev) => (prev ? { ...prev, isPinned: newPinned } : null));
    setActionNotice(newPinned
      ? (isAr ? 'تم تثبيت الإعلان في الأعلى' : 'Announcement pinned')
      : (isAr ? 'تم إلغاء تثبيت الإعلان' : 'Announcement unpinned')
    );
    setTimeout(() => setActionNotice(null), 3000);
  };

  const handleDelete = async () => {
    if (!announcement) return;
    try {
      setIsDeleting(true);
      await deleteAnnouncement(announcement.id);
      navigate('/announcements');
    } catch (err: any) {
      console.error('Failed to delete:', err);
      alert(err.message || 'Failed to delete announcement');
      setIsDeleting(false);
    }
  };

  // Format dates
  const formatDate = (isoString?: string) => {
    if (!isoString) return '';
    try {
      const date = new Date(isoString);
      return new Intl.DateTimeFormat(isAr ? 'ar-EG' : 'en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }).format(date);
    } catch {
      return isoString;
    }
  };

  const categoryConfig = announcement
    ? ANNOUNCEMENT_CATEGORIES.find((c) => c.id.toLowerCase() === (announcement.category || '').toLowerCase())
    : null;

  return (
    <div className="flex-1 w-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-20">
      {/* Toast Notice */}
      <AnimatePresence>
        {actionNotice && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-20 start-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full bg-archive-cyan text-archive-dark font-bold text-xs sm:text-sm shadow-xl shadow-cyan-950/50 flex items-center gap-2 border border-archive-cyan/40"
          >
            <Sparkles size={16} />
            <span>{actionNotice}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navigation & Back Link */}
      <div className="flex items-center justify-between gap-4 mb-6 sm:mb-8">
        <Link
          to="/announcements"
          className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-archive-paper-muted hover:text-archive-cyan transition-colors group"
        >
          {isAr ? (
            <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
          ) : (
            <ArrowLeft size={16} className="transition-transform group-hover:-translate-x-1" />
          )}
          <span>{isAr ? 'العودة إلى الإعلانات' : 'Back to Announcements'}</span>
        </Link>

        {/* Share Button */}
        <button
          onClick={handleCopyLink}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-archive-cyan/20 bg-archive-dark/70 hover:bg-archive-card text-archive-paper-muted hover:text-archive-cyan transition-colors text-xs font-medium"
          title={isAr ? 'نسخ رابط الإعلان' : 'Copy link to announcement'}
        >
          {copiedLink ? (
            <>
              <Check size={14} className="text-emerald-400" />
              <span className="text-emerald-400">{isAr ? 'تم النسخ' : 'Copied!'}</span>
            </>
          ) : (
            <>
              <Share2 size={14} />
              <span>{isAr ? 'مشاركة' : 'Share'}</span>
            </>
          )}
        </button>
      </div>

      {loading ? (
        <div className="py-24 text-center">
          <div className="inline-block w-8 h-8 border-2 border-archive-cyan border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-sm text-archive-paper-muted">{isAr ? 'جاري تحميل تفاصيل الإعلان...' : 'Loading announcement details...'}</p>
        </div>
      ) : error || !announcement ? (
        <div className="rounded-2xl border border-archive-cyan/20 bg-archive-card/60 p-10 text-center max-w-md mx-auto my-12">
          <AlertCircle size={32} className="text-rose-400 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-archive-paper mb-2">
            {error || (isAr ? 'الإعلان غير موجود' : 'Announcement Not Found')}
          </h3>
          <p className="text-xs text-archive-paper-muted mb-6">
            {isAr ? 'ربما تم حذفه أو أن الرابط غير صحيح.' : 'This announcement may have been removed or the link is invalid.'}
          </p>
          <Link
            to="/announcements"
            className="px-4 py-2 rounded-xl bg-archive-cyan text-archive-dark font-bold text-xs hover:bg-archive-cyan/90 transition-all inline-block"
          >
            {isAr ? 'العودة للقائمة' : 'Return to Announcements'}
          </Link>
        </div>
      ) : (
        /* Full Announcement Article */
        <article className="rounded-3xl border border-archive-cyan/20 bg-archive-card/90 shadow-2xl shadow-cyan-950/30 overflow-hidden">
          {/* Top Banner Accent */}
          {announcement.isPinned && (
            <div className="h-1.5 w-full bg-gradient-to-r from-amber-500 via-archive-cyan to-amber-500" />
          )}

          {/* Cover Photo Banner (if present) */}
          {announcement.imageUrl && (
            <div 
              className="relative w-full max-h-[460px] overflow-hidden cursor-pointer group bg-archive-dark/95"
              onClick={() => handleOpenLightbox([announcement.imageUrl!], 0)}
            >
              <img 
                src={announcement.imageUrl} 
                alt={announcement.title} 
                className="w-full h-full object-cover group-hover:scale-[1.015] transition-transform duration-500 max-h-[460px]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-archive-card via-black/20 to-transparent opacity-85" />
              <div className="absolute bottom-4 end-4 px-3.5 py-1.5 rounded-xl bg-archive-dark/85 backdrop-blur-md border border-archive-cyan/30 text-xs font-semibold text-archive-cyan flex items-center gap-1.5 shadow-lg group-hover:border-archive-cyan/60 transition-colors">
                <ZoomIn size={14} />
                <span>{isAr ? 'عرض الصورة بالحجم الكامل' : 'View Full Image'}</span>
              </div>
            </div>
          )}

          {/* Article Header */}
          <div className="p-6 sm:p-10 border-b border-archive-cyan/15 bg-gradient-to-b from-archive-dark/60 to-transparent">
            {/* Meta Tags Row */}
            <div className="flex items-center gap-2.5 flex-wrap mb-4">
              {announcement.isPinned && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  <Pin size={12} className="rotate-45" />
                  <span>{isAr ? 'إعلان مثبت' : 'Pinned Announcement'}</span>
                </span>
              )}

              {announcement.category && (
                <span
                  className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border ${
                    categoryConfig ? categoryConfig.color : 'bg-archive-cyan/15 text-archive-cyan border-archive-cyan/30'
                  }`}
                >
                  {categoryConfig
                    ? isAr
                      ? categoryConfig.labelAr
                      : categoryConfig.labelEn
                    : announcement.category}
                </span>
              )}

              <div className="flex items-center gap-1.5 text-xs text-archive-paper-muted ms-auto">
                <Calendar size={13} className="text-archive-cyan/70" />
                <span>{formatDate(announcement.publishedAt)}</span>
              </div>
            </div>

            {/* Headline Title */}
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-black text-archive-paper tracking-tight leading-tight mb-6">
              {announcement.title}
            </h1>

            {/* Author & Action Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-4 border-t border-archive-cyan/10">
              {/* Author profile */}
              <div className="flex items-center gap-3">
                {announcement.authorAvatarUrl ? (
                  <img
                    src={announcement.authorAvatarUrl}
                    alt={announcement.authorDisplayName}
                    className="w-10 h-10 rounded-full object-cover border-2 border-archive-cyan/40 shadow-sm"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-archive-cyan/15 border border-archive-cyan/30 flex items-center justify-center text-archive-cyan">
                    <User size={20} />
                  </div>
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-archive-paper">
                      {announcement.authorDisplayName}
                    </span>
                    <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      👑 {isAr ? 'المالك' : 'Server Owner'}
                    </span>
                  </div>
                  <span className="text-xs text-archive-paper-muted">
                    {isAr ? 'بيان معتمد من إدارة CREATINE NEXUS' : 'CREATINE NEXUS Official Leadership'}
                  </span>
                </div>
              </div>

              {/* Owner Action Buttons */}
              {isOwner && (
                <div className="flex items-center gap-2 self-end sm:self-center">
                  <button
                    onClick={handleTogglePin}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-colors ${
                      announcement.isPinned
                        ? 'border-amber-500/40 bg-amber-500/15 text-amber-300 hover:bg-amber-500/25'
                        : 'border-archive-cyan/20 bg-archive-dark/60 text-archive-paper-muted hover:text-amber-300 hover:bg-archive-dark'
                    }`}
                  >
                    <Pin size={13} className={announcement.isPinned ? 'rotate-45' : ''} />
                    <span>{announcement.isPinned ? (isAr ? 'إلغاء التثبيت' : 'Unpin') : (isAr ? 'تثبيت' : 'Pin')}</span>
                  </button>

                  <button
                    onClick={() => setIsEditModalOpen(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-archive-cyan/20 bg-archive-dark/60 text-archive-paper-muted hover:text-archive-cyan hover:bg-archive-dark transition-colors text-xs font-semibold"
                  >
                    <Edit2 size={13} />
                    <span>{isAr ? 'تعديل' : 'Edit'}</span>
                  </button>

                  <button
                    onClick={() => setShowConfirmDelete(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 transition-colors text-xs font-semibold"
                  >
                    <Trash2 size={13} />
                    <span>{isAr ? 'حذف' : 'Delete'}</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Article Body Content */}
          <div className="p-6 sm:p-10">
            <AnnouncementContentRenderer 
              content={announcement.content} 
              onImageClick={(url) => handleOpenLightbox([url], 0)}
            />

            {/* Attached Photos Gallery */}
            {announcement.images && announcement.images.length > 0 && (
              <div className="mt-10 pt-8 border-t border-archive-cyan/15">
                <div className="flex items-center gap-2 mb-4">
                  <ImageIcon size={18} className="text-archive-cyan" />
                  <h3 className="text-sm sm:text-base font-bold text-archive-paper">
                    {isAr ? 'الصور والوسائط المرفقة' : 'Attached Photos & Media'}
                  </h3>
                  <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-archive-cyan/15 text-archive-cyan border border-archive-cyan/30">
                    {announcement.images.length}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3.5">
                  {announcement.images.map((img, idx) => (
                    <div
                      key={idx}
                      onClick={() => handleOpenLightbox(announcement.images!, idx)}
                      className="group relative rounded-2xl overflow-hidden border border-archive-cyan/20 hover:border-archive-cyan/50 bg-archive-dark/80 aspect-video cursor-pointer transition-all shadow-md hover:shadow-cyan-950/30"
                    >
                      <img 
                        src={img} 
                        alt={`Attachment ${idx + 1}`} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        loading="lazy" 
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/35 transition-colors flex items-center justify-center">
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity p-2 rounded-xl bg-archive-dark/80 backdrop-blur-md border border-archive-cyan/40 text-archive-cyan">
                          <ZoomIn size={16} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Archival Gazette Watermark & Endplate */}
            <div className="mt-8 pt-4 border-t border-archive-cyan/10 flex flex-wrap items-center justify-between gap-3 text-[11px] text-archive-paper-muted">
              <div className="flex items-center gap-2">
                <span className="font-mono text-[10px] tracking-wider uppercase text-archive-paper-muted/80">
                  CREATINE NEXUS GAZETTE // ARCHIVAL VERIFIED
                </span>
              </div>
              {announcement.updatedAt && announcement.updatedAt !== announcement.publishedAt && (
                <p className="italic">
                  {isAr ? 'آخر تحديث:' : 'Last modified:'} {formatDate(announcement.updatedAt)}
                </p>
              )}
            </div>
          </div>
        </article>
      )}

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {showConfirmDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm rounded-2xl bg-archive-dark border border-rose-500/40 p-6 shadow-2xl"
            >
              <div className="w-12 h-12 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 mx-auto mb-4">
                <Trash2 size={24} />
              </div>
              <h4 className="text-base font-bold text-archive-paper text-center mb-2">
                {isAr ? 'تأكيد حذف الإعلان' : 'Confirm Announcement Deletion'}
              </h4>
              <p className="text-xs text-archive-paper-muted text-center mb-6 leading-relaxed">
                {isAr
                  ? 'هل أنت متأكد من رغبتك في حذف هذا الإعلان نهائياً من قاعدة البيانات؟ لا يمكن التراجع عن هذه الخطوة.'
                  : 'Are you sure you want to permanently delete this announcement? This action cannot be undone.'}
              </p>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowConfirmDelete(false)}
                  className="flex-1 py-2 rounded-xl border border-archive-cyan/20 text-xs font-semibold text-archive-paper-muted hover:text-archive-paper transition-colors"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  onClick={handleDelete}
                  disabled={isDeleting}
                  className="flex-1 py-2 rounded-xl bg-rose-500 text-white font-bold text-xs hover:bg-rose-600 transition-colors disabled:opacity-50"
                >
                  {isDeleting ? '...' : isAr ? 'نعم، حذف' : 'Yes, Delete'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Announcement Modal */}
      {isOwner && announcement && (
        <AnnouncementModal
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          onSubmit={handleEditSubmit}
          initialData={announcement}
          mode="edit"
        />
      )}

      {/* Fullscreen Photo Lightbox Modal */}
      <PhotoLightboxModal
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        images={lightboxImages}
        currentIndex={lightboxIndex}
        onIndexChange={setLightboxIndex}
      />
    </div>
  );
};
