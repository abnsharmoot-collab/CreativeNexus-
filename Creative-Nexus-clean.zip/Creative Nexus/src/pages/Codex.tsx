import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, useLocation, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { HANDBOOK_BOOKS } from '../data/handbookData';
import { LibraryView } from '../components/handbook/LibraryView';
import { BookReaderView } from '../components/handbook/BookReaderView';
import { useLanguage } from '../context/LanguageContext';

export const Codex: React.FC = () => {
  const { bookId } = useParams<{ bookId?: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { language } = useLanguage();
  const isAr = language === 'ar';

  // Read progress state persisted in localStorage
  const [readProgressMap, setReadProgressMap] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem('cn_handbook_progress');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const handleUpdateProgress = useCallback((bId: string, percent: number) => {
    setReadProgressMap((prev) => {
      const current = prev[bId] || 0;
      const target = Math.max(current, percent);
      if (current === target) return prev; // Do not trigger state update if unchanged
      const updated = { ...prev, [bId]: target };
      try {
        localStorage.setItem('cn_handbook_progress', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
  }, []);

  // Determine active book
  const chapterParam = searchParams.get('ch') || undefined;
  
  // Also support legacy hash redirects like #section-rules or ?book=book-rules-procedures
  const activeBookId = useMemoActiveBookId(bookId, location.hash, searchParams.get('book'));

  const activeBook = HANDBOOK_BOOKS.find((b) => b.id === activeBookId);

  // Set document title and sync handbook exploration
  useEffect(() => {
    try {
      localStorage.setItem('creatine_handbook_explored', 'true');
      window.dispatchEvent(new Event('storage'));
    } catch {}

    if (activeBook) {
      document.title = `${isAr ? activeBook.titleAr : activeBook.titleEn} | CN GUIDEBOOK`;
    } else {
      document.title = isAr 
        ? 'دليل موقع مركز الابداع (CREATIVE NEXUS)' 
        : 'CN GUIDEBOOK | Your guide to the CREATIVE NEXUS website';
    }
  }, [activeBook, isAr]);

  const handleSelectBook = useCallback((selectedId: string, chapterId?: string) => {
    let basePath = '/guidebook';
    if (location.pathname.startsWith('/codex')) basePath = '/codex';
    else if (location.pathname.startsWith('/handbook')) basePath = '/handbook';
    const chQuery = chapterId ? `?ch=${chapterId}` : '';
    navigate(`${basePath}/${selectedId}${chQuery}`);
  }, [location.pathname, navigate]);

  const handleBackToLibrary = useCallback(() => {
    let basePath = '/guidebook';
    if (location.pathname.startsWith('/codex')) basePath = '/codex';
    else if (location.pathname.startsWith('/handbook')) basePath = '/handbook';
    navigate(basePath);
  }, [location.pathname, navigate]);

  return (
    <div 
      className="codex-root min-h-screen pt-20 sm:pt-24 pb-20 px-3 sm:px-6 lg:px-12 max-w-7xl mx-auto text-[#eafffa] w-full overflow-x-hidden selection:bg-[#5eead4]/30 selection:text-[#eafffa]"
      data-theme-scope="guidebook"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      <AnimatePresence mode="wait">
        {activeBook ? (
          <motion.div
            key={`book-${activeBook.id}`}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
          >
            <BookReaderView
              book={activeBook}
              initialChapterId={chapterParam}
              onBackToLibrary={handleBackToLibrary}
              onSelectBook={handleSelectBook}
              onUpdateProgress={handleUpdateProgress}
            />
          </motion.div>
        ) : (
          <motion.div
            key="library-view"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
          >
            <LibraryView
              onSelectBook={handleSelectBook}
              readProgressMap={readProgressMap}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// Helper to support legacy hash/query routing and ID aliasing
function useMemoActiveBookId(
  paramBookId?: string, 
  hash?: string, 
  queryBook?: string | null
): string | undefined {
  const rawId = paramBookId || queryBook;

  if (rawId) {
    // Exact match check
    const exact = HANDBOOK_BOOKS.find((b) => b.id === rawId);
    if (exact) return exact.id;

    // Normalizations & legacy mappings
    if (rawId === 'book-server-structure' || rawId === 'getting-started') return 'guide-getting-started';
    if (rawId === 'profile') return 'guide-profile';
    if (rawId === 'book-achievements' || rawId === 'achievements') return 'guide-achievements';
    if (rawId === 'book-rank-progression' || rawId === 'rank-points' || rawId === 'ranks') return 'guide-rank-points';
    if (rawId === 'applications' || rawId === 'rank-applications') return 'guide-applications';
    if (rawId === 'notifications') return 'guide-notifications';
    if (rawId === 'announcements') return 'guide-announcements';
    if (rawId === 'history' || rawId === 'archive') return 'guide-history';
    if (rawId === 'book-rules-procedures' || rawId === 'rules' || rawId === 'server-rules') return 'guide-rules';
    if (rawId === 'book-administration' || rawId === 'administration' || rawId === 'admin') return 'guide-administration';
  }

  if (hash) {
    const h = hash.toLowerCase();
    if (h.includes('rule')) return 'guide-rules';
    if (h.includes('getting') || h.includes('start') || h.includes('nav')) return 'guide-getting-started';
    if (h.includes('profile')) return 'guide-profile';
    if (h.includes('achieve')) return 'guide-achievements';
    if (h.includes('rank') || h.includes('point')) return 'guide-rank-points';
    if (h.includes('app') || h.includes('apply')) return 'guide-applications';
    if (h.includes('notif')) return 'guide-notifications';
    if (h.includes('announc')) return 'guide-announcements';
    if (h.includes('hist') || h.includes('archive')) return 'guide-history';
    if (h.includes('admin') || h.includes('owner')) return 'guide-administration';
  }

  return undefined;
}

export default Codex;
