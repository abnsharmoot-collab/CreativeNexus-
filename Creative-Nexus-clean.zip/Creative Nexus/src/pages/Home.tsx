import React from 'react';
import { Hero } from '../components/organisms/Hero';
import { CreativeNexusMarquee } from '../components/home/CreativeNexusMarquee';
import { HomeUnifiedHub } from '../components/home/HomeUnifiedHub';
import { MainMenuBackgroundLayer } from '../components/home/MainMenuBackgroundLayer';
import { useEasterEggs } from '../context/EasterEggContext';

export function Home() {
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  return (
    <main className={`relative overflow-hidden ${
      isMesopotamian
        ? 'bg-transparent text-amber-100 selection:bg-amber-500/30 selection:text-amber-100'
        : 'bg-[#010807] text-[#eafffa] selection:bg-[#5eead4]/30 selection:text-[#eafffa]'
    }`}>
      {/* Custom Owner Main Menu Full Page Background Layer */}
      <MainMenuBackgroundLayer scope="full_page" />

      {/* Atmospheric Spatial Background Gradients & Radiant Glow Meshes (Darkened for obsidian depth) */}
      {!isMesopotamian && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-0" aria-hidden="true">
          {/* Top Hero Cyan / Teal Radiant Nebula */}
          <div className="absolute -top-32 start-1/2 -translate-x-1/2 w-[1100px] h-[650px] bg-gradient-to-b from-[#5eead4]/10 via-teal-600/6 to-transparent blur-[180px] rounded-full" />
          
          {/* Features Section Luminous Ambient Aura */}
          <div className="absolute top-[28%] -start-40 w-[800px] h-[550px] bg-gradient-to-r from-teal-500/10 via-cyan-400/6 to-transparent blur-[170px] rounded-full" />
          <div className="absolute top-[34%] -end-40 w-[750px] h-[500px] bg-gradient-to-l from-indigo-500/8 via-[#2dd4bf]/8 to-transparent blur-[180px] rounded-full" />
          
          {/* Codex & Stats Section Deep Glow Meshes */}
          <div className="absolute top-[62%] start-1/4 w-[900px] h-[600px] bg-gradient-to-tr from-cyan-500/10 via-teal-500/8 to-transparent blur-[180px] rounded-full" />
          <div className="absolute top-[78%] end-10 w-[850px] h-[500px] bg-gradient-to-tl from-emerald-500/10 via-teal-600/8 to-transparent blur-[180px] rounded-full" />
        </div>
      )}

      {/* Hero Section (Main Creative Nexus 3D Portal) */}
      <section id="home" className="relative z-10">
        <Hero />
      </section>

      {/* Marquee Animated Ticker */}
      <section className="relative z-10">
        <CreativeNexusMarquee />
      </section>

      {/* Unified Master Stage: Guidebook CODEX, Live Server Status & Start Your Journey */}
      <div className="relative z-10">
        <HomeUnifiedHub />
      </div>
    </main>
  );
}
