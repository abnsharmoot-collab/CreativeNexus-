import React, { useState, useMemo } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useDecks } from '../context/DeckContext';
import { useCards } from '../context/CardContext';
import { useItems } from '../context/ItemContext';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { DeckCard } from '../components/decks/DeckCard';
import { DeckBuilderModal } from '../components/decks/DeckBuilderModal';
import { CardDetailModal } from '../components/cards/CardDetailModal';
import { BrawlStarsItemDisplay } from '../components/items/BrawlStarsItemDisplay';
import { PlayerDeck, calculateDeckStats } from '../types/decks';
import { CollectibleCardData, CardRarity, getUnifiedCardStats, calculateCardOverallRating } from '../types/cards';
import { UnifiedItemDefinition, ItemCategory, UserItemOwnership } from '../types/items';
import { 
  Layers, Plus, Crown, Swords, Shield, Zap, Sparkles, 
  ArrowRight, ArrowLeft, Play, AlertCircle, Loader2,
  Backpack, Search, X, Check, ArrowUpRight, Filter, Info, Trash2, Edit2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { playBattleSound } from '../utils/battleAudio';

export const Decks: React.FC = () => {
  const { decks, activeDeck, activeDeckCards, loading: decksLoading, saveDeck, setActiveDeck, deleteDeck, getDeckCards } = useDecks();
  const { catalog, profile, loading: cardsLoading, getCardOwnership } = useCards();
  const { items, inventory, inventoryMap, loading: itemsLoading } = useItems();
  const { isAuthenticated, loginWithDiscord } = useAuth();
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  // Active Main Tab: 'DECKS' | 'CARDS' | 'ITEMS'
  const initialTab = (searchParams.get('tab') as 'DECKS' | 'CARDS' | 'ITEMS') || 'DECKS';
  const [activeTab, setActiveTab] = useState<'DECKS' | 'CARDS' | 'ITEMS'>(initialTab);

  // Deck Builder Modal State
  const [isBuilderOpen, setIsBuilderOpen] = useState(false);
  const [deckToEdit, setDeckToEdit] = useState<PlayerDeck | null>(null);

  // Card Detail Modal State
  const [inspectingCard, setInspectingCard] = useState<CollectibleCardData | null>(null);

  // Quick Slot Replace Modal State (when equipping card to active deck that has 4 cards)
  const [cardToEquip, setCardToEquip] = useState<CollectibleCardData | null>(null);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  // Cards Collection Tab Filters & Search
  const [cardSearchQuery, setCardSearchQuery] = useState('');
  const [cardRarityFilter, setCardRarityFilter] = useState<'ALL' | CardRarity>('ALL');

  // Items Inventory Tab Filters & Search
  const [itemCategoryFilter, setItemCategoryFilter] = useState<'ALL' | ItemCategory>('ALL');
  const [itemSearchQuery, setItemSearchQuery] = useState('');

  // Handle Tab Change & URL sync
  const handleTabChange = (tab: 'DECKS' | 'CARDS' | 'ITEMS') => {
    setActiveTab(tab);
    setSearchParams({ tab });
  };

  // Owned cards with ownership details
  const ownedCardsList = useMemo(() => {
    if (!profile?.cards) return [];
    return Object.keys(profile.cards)
      .map(cardId => {
        const ownership = profile.cards[cardId];
        const cardDef = catalog.find(c => c.id === cardId);
        if (!cardDef || !ownership || (ownership.count || 0) <= 0) return null;
        return {
          card: cardDef,
          count: ownership.count,
          upgradedRarity: (ownership.upgradedRarity as CardRarity) || cardDef.rarity,
          upgradedStats: ownership.upgradedStats || getUnifiedCardStats(cardDef)
        };
      })
      .filter((item): item is { card: CollectibleCardData; count: number; upgradedRarity: CardRarity; upgradedStats: any } => Boolean(item));
  }, [catalog, profile?.cards]);

  // Filtered owned cards for Cards tab
  const filteredOwnedCards = useMemo(() => {
    return ownedCardsList.filter(({ card, upgradedRarity }) => {
      if (cardRarityFilter !== 'ALL' && upgradedRarity !== cardRarityFilter) {
        return false;
      }
      if (cardSearchQuery.trim()) {
        const query = cardSearchQuery.toLowerCase().trim();
        const matchesName = card.name.toLowerCase().includes(query);
        const matchesTitle = card.title?.toLowerCase().includes(query);
        if (!matchesName && !matchesTitle) return false;
      }
      return true;
    });
  }, [ownedCardsList, cardRarityFilter, cardSearchQuery]);

  // Only items owned by the player in their inventory (count > 0)
  const ownedInventoryItems = useMemo(() => {
    const list: Array<{ item: UnifiedItemDefinition; count: number }> = [];
    const seenIds = new Set<string>();

    if (Array.isArray(inventory)) {
      for (const entry of inventory) {
        if (entry && entry.count > 0) {
          const found = items.find(i => i.id === entry.itemId) || (entry.itemData as UnifiedItemDefinition);
          if (found) {
            seenIds.add(found.id);
            list.push({ item: found, count: entry.count });
          }
        }
      }
    }

    if (inventoryMap && typeof inventoryMap === 'object') {
      for (const [id, entry] of Object.entries(inventoryMap) as [string, UserItemOwnership][]) {
        if (entry && entry.count > 0 && !seenIds.has(id)) {
          const found = items.find(i => i.id === id) || (entry.itemData as UnifiedItemDefinition);
          if (found) {
            seenIds.add(found.id);
            list.push({ item: found, count: entry.count });
          }
        }
      }
    }

    return list;
  }, [items, inventory, inventoryMap]);

  const totalShardsCount = useMemo(() => {
    return ownedInventoryItems
      .filter(({ item }) => (item.category || 'UPGRADE_MATERIAL') === 'UPGRADE_MATERIAL')
      .reduce((sum, { count }) => sum + count, 0);
  }, [ownedInventoryItems]);

  // Filtered owned items for Items tab
  const filteredInventoryItems = useMemo(() => {
    return ownedInventoryItems.filter(({ item }) => {
      if (itemCategoryFilter !== 'ALL' && (item.category || 'UPGRADE_MATERIAL') !== itemCategoryFilter) {
        return false;
      }
      if (itemSearchQuery.trim()) {
        const q = itemSearchQuery.toLowerCase().trim();
        const matchesName = item.name.toLowerCase().includes(q);
        const matchesDesc = (item.description || '').toLowerCase().includes(q);
        if (!matchesName && !matchesDesc) return false;
      }
      return true;
    });
  }, [ownedInventoryItems, itemCategoryFilter, itemSearchQuery]);

  // Active deck calculations
  const activeDeckStats = useMemo(() => {
    return calculateDeckStats(activeDeckCards);
  }, [activeDeckCards]);

  // Check if a card is in active deck
  const isCardInActiveDeck = (cardId: string) => {
    return Boolean(activeDeck?.cardIds?.includes(cardId));
  };

  // Fast Equip Card to Active Deck
  const handleQuickEquip = async (card: CollectibleCardData) => {
    if (!isAuthenticated) {
      setActionFeedback(isAr ? 'يرجى تسجيل الدخول أولاً' : 'Please log in first');
      setTimeout(() => setActionFeedback(null), 3000);
      return;
    }

    if (!activeDeck) {
      // Create a new active deck containing this card
      await saveDeck({
        name: isAr ? 'تشكيلة المعركة' : 'Battle Formation',
        cardIds: [card.id],
        isActive: true
      });
      playBattleSound('TACTICAL_SELECT', 0.8);
      setActionFeedback(isAr ? `تمت إضافة "${card.name}" إلى التشكيلة الجديدة` : `Added "${card.name}" to new deck`);
      setTimeout(() => setActionFeedback(null), 2500);
      return;
    }

    const currentCardIds = [...(activeDeck.cardIds || [])];

    if (currentCardIds.includes(card.id)) {
      setActionFeedback(isAr ? 'هذه البطاقة مجهزة بالفعل في التشكيلة' : 'Already in active deck');
      setTimeout(() => setActionFeedback(null), 2500);
      return;
    }

    if (currentCardIds.length < 4) {
      // Append directly
      currentCardIds.push(card.id);
      await saveDeck({
        id: activeDeck.id,
        name: activeDeck.name,
        banner: activeDeck.banner,
        cardIds: currentCardIds,
        itemIds: activeDeck.itemIds,
        isActive: true
      });
      playBattleSound('FORMATION_SUMMON', 0.8);
      setActionFeedback(isAr ? `تم تجهيز "${card.name}" في التشكيلة` : `Equipped "${card.name}" into deck`);
      setTimeout(() => setActionFeedback(null), 2500);
    } else {
      // Deck is full with 4 cards: prompt slot replace
      setCardToEquip(card);
    }
  };

  // Execute Slot Replacement
  const handleReplaceSlot = async (slotIndex: number) => {
    if (!activeDeck || !cardToEquip) return;
    const currentCardIds = [...(activeDeck.cardIds || [])];
    currentCardIds[slotIndex] = cardToEquip.id;

    await saveDeck({
      id: activeDeck.id,
      name: activeDeck.name,
      banner: activeDeck.banner,
      cardIds: currentCardIds,
      itemIds: activeDeck.itemIds,
      isActive: true
    });

    playBattleSound('FORMATION_SUMMON', 0.8);
    setActionFeedback(isAr ? `تم استبدال الخانة #${slotIndex + 1} بـ "${cardToEquip.name}"` : `Replaced slot #${slotIndex + 1} with "${cardToEquip.name}"`);
    setTimeout(() => setActionFeedback(null), 2500);
    setCardToEquip(null);
  };

  // Remove card from active deck
  const handleRemoveFromActiveDeck = async (cardId: string) => {
    if (!activeDeck) return;
    const currentCardIds = (activeDeck.cardIds || []).filter(id => id !== cardId);
    await saveDeck({
      id: activeDeck.id,
      name: activeDeck.name,
      banner: activeDeck.banner,
      cardIds: currentCardIds,
      itemIds: activeDeck.itemIds,
      isActive: true
    });
    playBattleSound('GUARD_BREAK', 0.6);
  };

  const handleOpenCreate = () => {
    setDeckToEdit(null);
    setIsBuilderOpen(true);
  };

  const handleOpenEdit = (deck: PlayerDeck) => {
    setDeckToEdit(deck);
    setIsBuilderOpen(true);
  };

  const handleDeleteDeck = async (deckId: string) => {
    if (confirm(isAr ? 'هل أنت متأكد من حذف هذه التشكيلة؟' : 'Are you sure you want to delete this deck?')) {
      await deleteDeck(deckId);
    }
  };

  return (
    <div className="min-h-screen py-4 sm:py-6 px-3 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full box-border font-sans" dir={isAr ? 'rtl' : 'ltr'}>
      {/* Top Floating Feedback Toast */}
      <AnimatePresence>
        {actionFeedback && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-18 start-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 text-slate-950 font-mono text-xs font-black shadow-xl shadow-teal-500/30 flex items-center gap-2"
          >
            <Check size={14} className="stroke-[3]" />
            <span>{actionFeedback}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Hub Banner */}
      <div className="relative rounded-2xl sm:rounded-3xl p-4 sm:p-6 bg-gradient-to-r from-[#02181a]/95 via-[#041f23]/95 to-[#010c0e]/95 border border-[#5eead4]/25 shadow-2xl overflow-hidden mb-5 backdrop-blur-xl">
        <div className="absolute top-0 inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-[#5eead4]/70 to-transparent pointer-events-none" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5 min-w-0">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#5eead4]/10 border border-[#5eead4]/30 text-[#5eead4] text-[11px] font-mono">
              <Layers size={13} />
              <span>{isAr ? 'مركز التشكيلات والحقيبة التكتيكية' : 'Battle Decks & Tactical Inventory'}</span>
            </div>

            <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-white font-sans tracking-tight">
              {isAr ? 'التشكيلات والحقيبة القتالية' : 'Battle Decks & Inventory'}
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl font-sans">
              {isAr
                ? 'تحكّم في تشكيلاتك القتالية لطور القصة، استعرض بطاقاتك المكتسبة وجهزها، وراقب شظايا وعناصر حقيبتك.'
                : 'Construct and adjust your 4-card battle decks, inspect and equip your cards, and manage tactical items.'}
            </p>
          </div>

          {/* Quick Header CTAs */}
          <div className="flex items-center gap-2 shrink-0 flex-wrap">
            <button
              type="button"
              onClick={handleOpenCreate}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#5eead4] via-teal-300 to-[#2dd4bf] hover:brightness-110 active:scale-95 text-[#031211] font-bold text-xs font-mono flex items-center gap-1.5 shadow-md shadow-teal-500/20 transition-all cursor-pointer"
            >
              <Plus size={15} className="text-black stroke-[2.5]" />
              <span>{isAr ? 'تشكيلة جديدة' : 'New Deck'}</span>
            </button>

            <Link
              to="/story"
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 via-teal-400 to-[#5eead4] hover:brightness-110 active:scale-95 text-[#031211] font-bold text-xs font-mono flex items-center gap-1.5 shadow-md shadow-cyan-500/20 transition-all cursor-pointer"
            >
              <Play size={14} className="text-black fill-black" />
              <span>{isAr ? 'طور القصة' : 'Story Mode'}</span>
            </Link>
          </div>
        </div>

        {/* Master Navigation Tabs */}
        <div className="flex items-center gap-1.5 mt-4 pt-3 border-t border-white/10 overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => handleTabChange('DECKS')}
            className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'DECKS'
                ? 'bg-gradient-to-r from-[#5eead4] to-[#2dd4bf] text-slate-950 font-black shadow-md shadow-teal-500/25 scale-[1.02]'
                : 'bg-black/40 text-slate-300 hover:text-white hover:bg-black/60 border border-white/10'
            }`}
          >
            <Swords size={14} />
            <span>{isAr ? 'التشكيلات القتالية' : 'Battle Decks'}</span>
            <span className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono ${
              activeTab === 'DECKS' ? 'bg-black/20 text-slate-950 font-black' : 'bg-white/10 text-slate-400'
            }`}>
              {decks.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleTabChange('CARDS')}
            className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'CARDS'
                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-stone-950 font-black shadow-md shadow-amber-500/25 scale-[1.02]'
                : 'bg-black/40 text-slate-300 hover:text-white hover:bg-black/60 border border-white/10'
            }`}
          >
            <Layers size={14} />
            <span>{isAr ? 'بطاقات اللاعب' : 'My Cards'}</span>
            <span className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono ${
              activeTab === 'CARDS' ? 'bg-black/20 text-stone-950 font-black' : 'bg-white/10 text-slate-400'
            }`}>
              {ownedCardsList.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleTabChange('ITEMS')}
            className={`px-3.5 py-2 rounded-xl text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer shrink-0 ${
              activeTab === 'ITEMS'
                ? 'bg-gradient-to-r from-purple-400 to-indigo-500 text-white font-black shadow-md shadow-purple-500/25 scale-[1.02]'
                : 'bg-black/40 text-slate-300 hover:text-white hover:bg-black/60 border border-white/10'
            }`}
          >
            <Backpack size={14} />
            <span>{isAr ? 'حقيبة العناصر والمواد' : 'Items & Bag'}</span>
            <span className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono ${
              activeTab === 'ITEMS' ? 'bg-black/30 text-white font-black' : 'bg-white/10 text-slate-400'
            }`}>
              {ownedInventoryItems.length}
            </span>
          </button>
        </div>
      </div>

      {/* Guest Warning */}
      {!isAuthenticated && (
        <div className="p-3 sm:p-4 rounded-2xl bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs font-mono flex items-center justify-between gap-3 mb-5 shadow-md">
          <div className="flex items-center gap-2 min-w-0">
            <AlertCircle size={16} className="text-amber-400 shrink-0" />
            <span className="truncate">
              {isAr
                ? 'سجّل الدخول بحساب ديسكورد لحفظ وتعديل تشكيلاتك القتالية واستخدام حقيبتك'
                : 'Log in with Discord to permanently save decks and manage inventory'}
            </span>
          </div>

          <button
            type="button"
            onClick={loginWithDiscord}
            className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-black font-bold text-xs shrink-0 cursor-pointer shadow-xs"
          >
            {isAr ? 'تسجيل الدخول' : 'Log In'}
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 1: BATTLE DECKS (Active Deck + Saved Decks)                          */}
      {/* ========================================================================= */}
      {activeTab === 'DECKS' && (
        <div className="space-y-6">
          {/* Active Battle Deck Showcase */}
          {activeDeck && (
            <div className="p-4 sm:p-6 rounded-2xl sm:rounded-3xl bg-gradient-to-b from-[#021418] via-[#010e11] to-[#01080a] border border-[#5eead4]/35 shadow-2xl relative overflow-hidden backdrop-blur-xl">
              <div className="absolute top-0 inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-[#5eead4]/60 to-transparent pointer-events-none" />
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                <div className="flex items-center gap-2.5">
                  <span className="p-2 rounded-xl bg-amber-500/15 text-amber-300 border border-amber-500/35">
                    <Crown size={16} />
                  </span>
                  <div>
                    <span className="text-[10px] font-mono text-[#5eead4] uppercase tracking-wider block">
                      {isAr ? 'التشكيلة النشطة حالياً للمعركة' : 'Current Active Deck'}
                    </span>
                    <h3 className="text-lg sm:text-xl font-bold text-white font-sans">{activeDeck.name}</h3>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs font-mono font-bold">
                    {activeDeck.cardIds.length} / 4 {isAr ? 'بطاقات' : 'Cards'}
                  </span>

                  <button
                    type="button"
                    onClick={() => handleOpenEdit(activeDeck)}
                    className="px-3.5 py-1.5 rounded-lg bg-[#5eead4]/15 hover:bg-[#5eead4]/25 text-[#5eead4] hover:text-white text-xs font-mono border border-[#5eead4]/35 transition-all cursor-pointer shadow-xs active:scale-95 flex items-center gap-1.5"
                  >
                    <Edit2 size={12} />
                    <span>{isAr ? 'تعديل التشكيلة' : 'Edit in Builder'}</span>
                  </button>
                </div>
              </div>

              {/* 4 Interactive Tactical Slots */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3.5">
                {[0, 1, 2, 3].map(idx => {
                  const card = activeDeckCards[idx];
                  return (
                    <div
                      key={idx}
                      className={`relative rounded-xl sm:rounded-2xl border p-2.5 flex items-center gap-2.5 transition-all ${
                        card
                          ? 'bg-black/60 border-[#5eead4]/35 shadow-md hover:border-[#5eead4]/70 group'
                          : 'border-dashed border-teal-800/40 bg-black/25 flex-col justify-center text-center py-4 cursor-pointer hover:border-[#5eead4]/40 hover:bg-black/40'
                      }`}
                      onClick={() => {
                        if (!card) {
                          handleTabChange('CARDS');
                        }
                      }}
                    >
                      {card ? (
                        <>
                          <div 
                            className="relative w-12 h-16 rounded-lg overflow-hidden border border-white/10 shrink-0 cursor-pointer"
                            onClick={() => setInspectingCard(card)}
                            title={isAr ? 'فحص البطاقة' : 'Inspect Card'}
                          >
                            <img
                              src={card.imageUrl}
                              alt={card.name}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                            />
                            <span className="absolute bottom-0 inset-x-0 bg-black/80 text-[8px] font-mono text-center text-amber-300 font-bold">
                              OVR {card.overallRating || 75}
                            </span>
                          </div>

                          <div className="min-w-0 flex-1">
                            <h4 className="text-xs font-bold text-white truncate font-sans">
                              {card.name}
                            </h4>
                            <div className="text-[9.5px] font-mono text-teal-300/80 space-y-0.2 mt-0.5">
                              <p>ATK: <span className="text-white font-bold">{card.attack}</span></p>
                              <p>DEF: <span className="text-white font-bold">{card.defense}</span></p>
                            </div>

                            {/* Quick remove button */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleRemoveFromActiveDeck(card.id);
                              }}
                              className="mt-1 text-[9px] text-rose-400 hover:text-rose-300 font-mono underline cursor-pointer"
                            >
                              {isAr ? 'إزالة' : 'Remove'}
                            </button>
                          </div>
                        </>
                      ) : (
                        <div className="flex flex-col items-center justify-center space-y-1">
                          <Plus size={16} className="text-[#5eead4]/60" />
                          <span className="text-[10px] font-mono text-slate-400">
                            {isAr ? `خانة #${idx + 1}` : `Slot #${idx + 1}`}
                          </span>
                          <span className="text-[9px] font-mono text-[#5eead4]">
                            {isAr ? '+ إضافة بطاقة' : '+ Add Card'}
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Stats Bar */}
              <div className="mt-3.5 pt-3 border-t border-white/10 flex items-center justify-between gap-3 text-xs font-mono text-slate-300 flex-wrap">
                <div className="flex items-center gap-3">
                  <span>ATK: <strong className="text-rose-400">{activeDeckStats.totalAttack}</strong></span>
                  <span>DEF: <strong className="text-blue-400">{activeDeckStats.totalDefense}</strong></span>
                  <span>HP: <strong className="text-emerald-400">{activeDeckStats.totalHp}</strong></span>
                  <span>SPD: <strong className="text-amber-400">{activeDeckStats.totalSpeed}</strong></span>
                </div>
                <div className="text-[11px] text-[#5eead4]">
                  {isAr ? 'التناغم: ' : 'Synergy: '}
                  <strong className="text-white font-bold">+{activeDeckStats.synergyScore}%</strong>
                </div>
              </div>
            </div>
          )}

          {/* All Saved Decks Grid */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>{isAr ? 'جميع التشكيلات المحفوظة' : 'Saved Battle Decks'}</span>
                <span className="text-xs font-mono text-slate-400 font-normal">
                  ({decks.length})
                </span>
              </h2>
            </div>

            {decksLoading ? (
              <div className="p-8 text-center text-slate-400 font-mono text-xs flex items-center justify-center gap-2">
                <Loader2 size={16} className="animate-spin text-[#5eead4]" />
                <span>{isAr ? 'جاري تحميل التشكيلات...' : 'Loading decks...'}</span>
              </div>
            ) : decks.length === 0 ? (
              <div className="p-8 rounded-2xl bg-black/30 border border-dashed border-teal-900/40 text-center space-y-3">
                <Layers size={24} className="text-teal-400 mx-auto" />
                <p className="text-slate-400 text-xs sm:text-sm max-w-sm mx-auto">
                  {isAr
                    ? 'لم تقم بإنشاء أي تشكيلة بعد. أنشئ تشكيلتك الأولى بـ 4 بطاقات لبدء القتال!'
                    : 'No decks found. Create your first 4-card deck to start battling!'}
                </p>
                <button
                  type="button"
                  onClick={handleOpenCreate}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#5eead4] to-[#2dd4bf] text-[#031211] text-xs font-mono font-bold cursor-pointer"
                >
                  {isAr ? '+ إنشاء تشكيلة الآن' : '+ Create Deck Now'}
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {decks.map(deck => (
                  <DeckCard
                    key={deck.id}
                    deck={deck}
                    cards={getDeckCards(deck)}
                    onEdit={handleOpenEdit}
                    onSetActive={setActiveDeck}
                    onDelete={handleDeleteDeck}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: CARDS INVENTORY & FAST ADJUST WORKSTATION                          */}
      {/* ========================================================================= */}
      {activeTab === 'CARDS' && (
        <div className="space-y-4">
          {/* Cards Search & Rarity Filter Bar */}
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2.5">
            {/* Search Input */}
            <div className="relative w-full sm:w-72">
              <Search size={14} className="absolute start-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={cardSearchQuery}
                onChange={e => setCardSearchQuery(e.target.value)}
                placeholder={isAr ? 'بحث بالاسم في بطاقاتك...' : 'Search your cards...'}
                className="w-full ps-8 pe-8 py-1.5 rounded-xl bg-black/60 border border-white/10 text-xs text-white placeholder:text-slate-500 focus:outline-hidden focus:border-amber-400"
              />
              {cardSearchQuery && (
                <button
                  type="button"
                  onClick={() => setCardSearchQuery('')}
                  className="absolute end-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X size={12} />
                </button>
              )}
            </div>

            {/* Rarity filter pills */}
            <div className="flex items-center gap-1 overflow-x-auto no-scrollbar w-full sm:w-auto">
              {(['ALL', 'COMMON', 'UNCOMMON', 'RARE', 'EPIC', 'LEGENDARY'] as const).map(rarity => (
                <button
                  key={rarity}
                  type="button"
                  onClick={() => setCardRarityFilter(rarity)}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                    cardRarityFilter === rarity
                      ? 'bg-amber-400 text-stone-950 font-black'
                      : 'bg-black/50 text-slate-400 hover:text-white border border-white/10'
                  }`}
                >
                  {rarity}
                </button>
              ))}
            </div>
          </div>

          {/* Cards Grid */}
          {cardsLoading ? (
            <div className="p-12 text-center text-slate-400 font-mono text-xs flex items-center justify-center gap-2">
              <Loader2 size={16} className="animate-spin text-amber-400" />
              <span>{isAr ? 'جاري تحميل البطاقات...' : 'Loading cards...'}</span>
            </div>
          ) : filteredOwnedCards.length === 0 ? (
            <div className="p-8 rounded-2xl bg-black/40 border border-white/10 text-center space-y-3">
              <Layers size={24} className="text-slate-400 mx-auto" />
              <p className="text-xs text-slate-400">
                {isAr ? 'لم يتم العثور على بطاقات تطابق البحث' : 'No cards found matching your search'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 xs:grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
              {filteredOwnedCards.map(({ card, count, upgradedRarity, upgradedStats }) => {
                const inActive = isCardInActiveDeck(card.id);
                const ovr = calculateCardOverallRating(upgradedStats, upgradedRarity);

                return (
                  <div
                    key={card.id}
                    className={`rounded-2xl border p-2.5 flex flex-col justify-between transition-all group ${
                      inActive
                        ? 'bg-gradient-to-b from-teal-950/40 via-black to-black border-[#5eead4]/60 shadow-[0_0_15px_rgba(94,234,212,0.15)]'
                        : 'bg-black/50 border-white/10 hover:border-white/30 hover:bg-black/70'
                    }`}
                  >
                    {/* Card Thumbnail Artwork */}
                    <div
                      className="relative aspect-[5/7] rounded-xl overflow-hidden bg-slate-950 cursor-pointer mb-2"
                      onClick={() => setInspectingCard(card)}
                      title={isAr ? 'انقر لمعاينة البطاقة بالكامل' : 'Click to inspect full card'}
                    >
                      <img
                        src={card.imageUrl}
                        alt={card.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />

                      {/* Duplicates count tag */}
                      <span className="absolute top-1.5 end-1.5 px-2 py-0.5 rounded-full bg-black/85 border border-white/20 text-[9px] font-mono text-amber-300 font-bold">
                        x{count}
                      </span>

                      {/* Rarity & OVR pill */}
                      <div className="absolute bottom-1.5 inset-x-1.5 flex items-center justify-between px-2 py-1 rounded-lg bg-black/80 backdrop-blur-xs text-[9px] font-mono border border-white/10">
                        <span className="text-slate-300 truncate font-bold">{upgradedRarity}</span>
                        <span className="text-emerald-400 font-black">OVR {ovr}</span>
                      </div>
                    </div>

                    {/* Card Info */}
                    <div className="space-y-1 mb-2">
                      <h4 className="text-xs font-bold text-white truncate font-sans">
                        {card.name}
                      </h4>
                      <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                        <span>ATK: <strong className="text-white">{card.attack}</strong></span>
                        <span>DEF: <strong className="text-white">{card.defense}</strong></span>
                        <span>HP: <strong className="text-white">{card.hp}</strong></span>
                      </div>
                    </div>

                    {/* Interactive Action Buttons */}
                    <div className="space-y-1 pt-1 border-t border-white/10">
                      {inActive ? (
                        <button
                          type="button"
                          onClick={() => handleRemoveFromActiveDeck(card.id)}
                          className="w-full py-1.5 rounded-lg bg-teal-500/15 hover:bg-rose-500/20 text-teal-300 hover:text-rose-300 border border-teal-500/30 hover:border-rose-500/30 text-[10px] font-mono font-bold transition-all cursor-pointer flex items-center justify-center gap-1"
                        >
                          <Check size={11} className="stroke-[3]" />
                          <span>{isAr ? 'مجهزة (انقر للإزالة)' : 'Equipped (Remove)'}</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleQuickEquip(card)}
                          className="w-full py-1.5 rounded-lg bg-gradient-to-r from-[#5eead4] to-[#2dd4bf] hover:brightness-110 active:scale-95 text-slate-950 text-[10px] font-mono font-black transition-all cursor-pointer flex items-center justify-center gap-1"
                        >
                          <Plus size={12} className="stroke-[3]" />
                          <span>{isAr ? 'تجهيز في التشكيلة' : 'Equip to Deck'}</span>
                        </button>
                      )}

                      {/* Upgrade & Inspect Link Buttons */}
                      <div className="grid grid-cols-2 gap-1">
                        <Link
                          to={`/card-upgrade?cardId=${card.id}`}
                          className="py-1 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 text-[9.5px] font-mono font-bold text-center transition-colors flex items-center justify-center gap-1"
                        >
                          <Sparkles size={10} />
                          <span>{isAr ? 'ترقية' : 'Upgrade'}</span>
                        </Link>
                        <button
                          type="button"
                          onClick={() => setInspectingCard(card)}
                          className="py-1 rounded-lg bg-white/5 hover:bg-white/15 text-slate-300 text-[9.5px] font-mono font-bold text-center transition-colors cursor-pointer"
                        >
                          {isAr ? 'معاينة' : 'Inspect'}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: ITEMS INVENTORY & CONSUMABLES                                      */}
      {/* ========================================================================= */}
      {activeTab === 'ITEMS' && (
        <div className="space-y-4">
          {/* Items Header Filters & Search Bar */}
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2.5">
            {/* Search Input */}
            <div className="relative w-full sm:w-72">
              <Search size={14} className="absolute start-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={itemSearchQuery}
                onChange={e => setItemSearchQuery(e.target.value)}
                placeholder={isAr ? 'بحث في حقيبة المواد والعناصر...' : 'Search inventory items...'}
                className="w-full ps-8 pe-8 py-1.5 rounded-xl bg-black/60 border border-white/10 text-xs text-white placeholder:text-slate-500 focus:outline-hidden focus:border-purple-400"
              />
              {itemSearchQuery && (
                <button
                  type="button"
                  onClick={() => setItemSearchQuery('')}
                  className="absolute end-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X size={12} />
                </button>
              )}
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1 overflow-x-auto no-scrollbar w-full sm:w-auto">
              {[
                { id: 'ALL', labelAr: 'الكل', labelEn: 'All' },
                { id: 'UPGRADE_MATERIAL', labelAr: 'شظايا الترقية', labelEn: 'Shards' },
                { id: 'COMBAT_CONSUMABLE', labelAr: 'عناصر القتال', labelEn: 'Combat' },
                { id: 'CHARACTER_GIFT', labelAr: 'هدايا الرفقاء', labelEn: 'Gifts' },
              ].map(cat => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setItemCategoryFilter(cat.id as any)}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                    itemCategoryFilter === cat.id
                      ? 'bg-purple-500 text-white font-black shadow-xs'
                      : 'bg-black/50 text-slate-400 hover:text-white border border-white/10'
                  }`}
                >
                  {isAr ? cat.labelAr : cat.labelEn}
                </button>
              ))}
            </div>
          </div>

          {/* Items Summary Bar */}
          <div className="flex items-center justify-between text-xs font-mono text-slate-400 px-1">
            <span>
              {isAr ? 'إجمالي الشظايا المملوكة:' : 'Total Upgrade Shards:'}{' '}
              <strong className="text-amber-300 font-bold">{totalShardsCount}</strong>
            </span>
            <Link
              to="/card-upgrade"
              className="text-[#5eead4] hover:underline flex items-center gap-1"
            >
              <span>{isAr ? 'الذهاب لمحراب الترقية' : 'Open Card Upgrade Altar'}</span>
              <ArrowRight size={11} className={isAr ? 'rotate-180' : ''} />
            </Link>
          </div>

          {/* Items Grid */}
          {itemsLoading ? (
            <div className="p-12 text-center text-slate-400 font-mono text-xs flex items-center justify-center gap-2">
              <Loader2 size={16} className="animate-spin text-purple-400" />
              <span>{isAr ? 'جاري تحميل المواد...' : 'Loading items...'}</span>
            </div>
          ) : ownedInventoryItems.length === 0 ? (
            <div className="p-8 rounded-2xl bg-black/40 border border-white/10 text-center space-y-3">
              <Backpack size={28} className="text-purple-400 mx-auto" />
              <h3 className="text-sm font-bold text-white">
                {isAr ? 'حقيبتك فارغة حالياً' : 'Your Bag is Empty'}
              </h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                {isAr
                  ? 'لا تمتلك أي عناصر أو شظايا في حقيبتك حالياً. يمكنك جمعها من خلال معارك طور القصة أو فتح حزم البطاقات!'
                  : 'You have no items or shards in your inventory yet. Earn them by playing Story Mode battles or opening card packs!'}
              </p>
              <Link
                to="/story"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-purple-500 hover:bg-purple-600 text-white font-mono font-bold text-xs shadow-md"
              >
                <Swords size={14} />
                <span>{isAr ? 'خوض معارك طور القصة' : 'Battle in Story Mode'}</span>
              </Link>
            </div>
          ) : filteredInventoryItems.length === 0 ? (
            <div className="p-8 rounded-2xl bg-black/40 border border-white/10 text-center space-y-3">
              <Backpack size={24} className="text-slate-400 mx-auto" />
              <p className="text-xs text-slate-400">
                {isAr ? 'لم يتم العثور على عناصر تطابق هذا الفلتر' : 'No items match your search filter'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5">
              {filteredInventoryItems.map(({ item, count }) => (
                <div
                  key={item.id}
                  className="p-3 rounded-2xl border transition-all flex flex-col justify-between bg-gradient-to-b from-slate-900/90 to-black border-purple-500/30 hover:border-purple-500/60 shadow-md"
                >
                  <div>
                    {/* Visual Item Display */}
                    <div className="flex items-center gap-3 mb-2.5">
                      <div className="w-12 h-12 rounded-xl bg-black/60 border border-white/15 p-1 flex items-center justify-center shrink-0">
                        {item.imageUrl ? (
                          <img
                            src={item.imageUrl}
                            alt={item.name}
                            className="w-full h-full object-contain"
                          />
                        ) : (
                          <Sparkles size={20} className="text-purple-400" />
                        )}
                      </div>

                      <div className="min-w-0">
                        <h4 className="text-xs font-bold text-white truncate font-sans">
                          {item.name}
                        </h4>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[9px] px-1.5 py-0.2 rounded-md bg-purple-500/20 text-purple-300 font-mono font-bold">
                            {item.rarity || 'COMMON'}
                          </span>
                          <span className="text-[9px] font-mono text-slate-400">
                            {item.category === 'UPGRADE_MATERIAL' ? (isAr ? 'شظية' : 'Shard') : (isAr ? 'عنصر' : 'Item')}
                          </span>
                        </div>
                      </div>
                    </div>

                    <p className="text-[11px] text-slate-300 line-clamp-2 mb-2 font-sans">
                      {item.description || (isAr ? 'عنصر تكتيكي يمكن استخدامه في المعارك والترقيات.' : 'Tactical item for battle and upgrades.')}
                    </p>
                  </div>

                  {/* Quantity & CTA */}
                  <div className="pt-2 border-t border-white/10 flex items-center justify-between text-xs font-mono">
                    <div>
                      <span className="text-slate-400 text-[10px]">{isAr ? 'الكمية: ' : 'Owned: '}</span>
                      <strong className="text-amber-300 font-bold">
                        {count}
                      </strong>
                    </div>

                    {item.category === 'UPGRADE_MATERIAL' ? (
                      <Link
                        to="/card-upgrade"
                        className="px-2.5 py-1 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 text-[10px] font-bold transition-colors"
                      >
                        {isAr ? 'ترقية بطاقة' : 'Upgrade Card'}
                      </Link>
                    ) : (
                      <span className="text-[10px] text-emerald-400 font-mono font-bold">
                        {isAr ? 'جاهز للاستخدام' : 'Ready'}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* QUICK SLOT REPLACEMENT MODAL (When active deck is full)                   */}
      {/* ========================================================================= */}
      <AnimatePresence>
        {cardToEquip && activeDeck && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-md rounded-2xl p-5 bg-[#031518] border border-[#5eead4]/40 shadow-2xl space-y-4"
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="flex items-center gap-2">
                  <Swords size={16} className="text-[#5eead4]" />
                  <h3 className="text-sm font-bold text-white">
                    {isAr ? 'اختر الخانة لاستبدالها' : 'Select Slot to Replace'}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setCardToEquip(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  <X size={16} />
                </button>
              </div>

              <p className="text-xs text-slate-300">
                {isAr
                  ? `التشكيلة النشطة مكتملة بـ 4 بطاقات. اختر البطاقة التي تريد استبدالها بـ "${cardToEquip.name}":`
                  : `Active deck is full (4 cards). Choose which card to replace with "${cardToEquip.name}":`}
              </p>

              {/* 4 Active Slots */}
              <div className="grid grid-cols-2 gap-2">
                {[0, 1, 2, 3].map(idx => {
                  const currentCard = activeDeckCards[idx];
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleReplaceSlot(idx)}
                      className="p-2.5 rounded-xl border border-white/15 bg-black/50 hover:bg-[#5eead4]/15 hover:border-[#5eead4]/60 transition-all text-start cursor-pointer group flex items-center gap-2"
                    >
                      {currentCard?.imageUrl && (
                        <img
                          src={currentCard.imageUrl}
                          alt=""
                          className="w-8 h-11 rounded-md object-cover shrink-0"
                        />
                      )}
                      <div className="min-w-0">
                        <span className="text-[9px] font-mono text-slate-400 block">
                          {isAr ? `خانة #${idx + 1}` : `Slot #${idx + 1}`}
                        </span>
                        <span className="text-xs font-bold text-white truncate block">
                          {currentCard?.name || (isAr ? 'فارغ' : 'Empty')}
                        </span>
                        <span className="text-[9px] font-mono text-emerald-400 block">
                          {isAr ? 'انقر للاستبدال' : 'Click to replace'}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => setCardToEquip(null)}
                  className="px-4 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 text-xs font-mono"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Deck Builder Modal */}
      <DeckBuilderModal
        isOpen={isBuilderOpen}
        deckToEdit={deckToEdit}
        onClose={() => setIsBuilderOpen(false)}
        onSave={saveDeck}
      />

      {/* Card Detail Modal */}
      {inspectingCard && (
        <CardDetailModal
          card={inspectingCard}
          onClose={() => setInspectingCard(null)}
        />
      )}
    </div>
  );
};
