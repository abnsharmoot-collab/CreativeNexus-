import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useOwnerCardBackgrounds, OwnerStats, OwnerPhotoSlide } from '../context/OwnerCardBackgroundsContext';
import { findBaseOwner, BASE_OWNERS, BaseOwnerDefinition } from '../data/ownersData';
import { CountryFlag } from '../components/atoms/CountryFlag';
import { getAccentColor, ACCENT_COLOR_MAP } from '../utils/ownerCardStyles';
import { Owner3DCard } from '../components/history/Owner3DCard';
import { PhotoReelEditModal } from '../components/history/PhotoReelEditModal';
import PolaroidLineCarousel, { Slide } from '@/components/ui/polaroid-line-carousel';
import {
  Crown,
  Sparkles,
  Shield,
  Clock,
  ArrowLeft,
  ArrowRight,
  Edit3,
  Check,
  Copy,
  ExternalLink,
  Flame,
  Award,
  BarChart3,
  Sliders,
  X,
  Upload,
  Link as LinkIcon,
  MessageSquare,
  Globe,
  Share2,
  Lock,
  Layers,
  Compass,
  Star,
  CheckCircle2,
  AlertCircle,
  Camera,
  Image as ImageIcon,
} from 'lucide-react';

// Compression helper for avatar image upload
async function compressAvatarFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const MAX_DIM = 600;
        let w = img.width;
        let h = img.height;
        if (w > h) {
          if (w > MAX_DIM) {
            h = Math.round((h * MAX_DIM) / w);
            w = MAX_DIM;
          }
        } else {
          if (h > MAX_DIM) {
            w = Math.round((w * MAX_DIM) / h);
            h = MAX_DIM;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) return resolve(e.target?.result as string);
        ctx.drawImage(img, 0, 0, w, h);
        try {
          resolve(canvas.toDataURL('image/webp', 0.88));
        } catch {
          resolve(canvas.toDataURL('image/jpeg', 0.88));
        }
      };
      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

export function OwnerProfile() {
  const { ownerId } = useParams<{ ownerId: string }>();
  const navigate = useNavigate();
  const { t, language } = useLanguage();
  const isAr = language === 'ar';
  const { user, isOwner, isAuthenticated, loginWithDiscord } = useAuth();
  const { getCustomization, updateCard, allCustomCards } = useOwnerCardBackgrounds();

  // Motion preference
  const [reducedMotion, setReducedMotion] = useState(false);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReducedMotion(mq.matches);
    const handler = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  // Resolve base definition and custom card data
  const baseOwner: BaseOwnerDefinition | undefined = useMemo(() => {
    if (!ownerId) return BASE_OWNERS[0];
    return findBaseOwner(ownerId);
  }, [ownerId]);

  // Find any dynamically added custom card if not matching base
  const customCardDoc = useMemo(() => {
    if (!ownerId) return undefined;
    return allCustomCards.find(
      (c) =>
        c.cardId.toLowerCase() === ownerId.toLowerCase() ||
        c.displayName?.toLowerCase() === ownerId.toLowerCase() ||
        c.name?.toLowerCase() === ownerId.toLowerCase()
    );
  }, [ownerId, allCustomCards]);

  const targetCardId = baseOwner?.cardId || customCardDoc?.cardId || ownerId || 'owner_edgar';
  const fallbackCardId = baseOwner?.fallbackCardId;

  // Real-time synced Firestore customization
  const custom = getCustomization(targetCardId, fallbackCardId);

  // Computed display values
  const displayName =
    custom?.displayName ||
    custom?.name ||
    customCardDoc?.displayName ||
    customCardDoc?.name ||
    (baseOwner ? (baseOwner.nameKey.startsWith('owner.') ? t(baseOwner.nameKey) : baseOwner.defaultName) : 'Nexus Owner');

  const username =
    custom?.username ||
    (baseOwner?.defaultDiscordHandle ? `@${baseOwner.defaultDiscordHandle}` : `@${displayName.toLowerCase().replace(/\s+/g, '_')}`);

  const roleTitle =
    custom?.roleTitle ||
    customCardDoc?.roleTitle ||
    (baseOwner ? (baseOwner.titleKey.startsWith('owner.') ? t(baseOwner.titleKey) : baseOwner.defaultTitle) : 'Server Owner');

  const badgeText =
    custom?.badge ||
    customCardDoc?.badge ||
    (baseOwner ? (baseOwner.badgeKey.startsWith('owner.') ? t(baseOwner.badgeKey) : baseOwner.defaultBadge) : 'Sanctuary Custodian');

  const bioText =
    custom?.bio ||
    custom?.subtitle ||
    customCardDoc?.bio ||
    customCardDoc?.subtitle ||
    (baseOwner ? (baseOwner.descKey.startsWith('owner.') ? t(baseOwner.descKey) : baseOwner.defaultDesc) : '');

  const quoteText = custom?.quote || custom?.specialty || '';

  const status = (custom?.status || customCardDoc?.status || baseOwner?.status || 'present') as 'present' | 'former';
  const isPresent = status === 'present';

  const country = (custom?.country || customCardDoc?.country || baseOwner?.country) as string | undefined;

  const accentKey = custom?.accentColor || customCardDoc?.accentColor || baseOwner?.defaultAccent || 'amber';
  const accent = getAccentColor(accentKey);

  const avatarUrl =
    custom?.avatarUrl ||
    customCardDoc?.avatarUrl ||
    custom?.imageUrl ||
    baseOwner?.defaultAvatar ||
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80';

  const romanNumeral = customCardDoc?.order ? `№ ${customCardDoc.order}` : baseOwner?.romanNumeral || 'ARCHIVE';

  // Stats
  const stats: OwnerStats = useMemo(() => {
    const s = custom?.stats || baseOwner?.defaultStats || {
      leadership: 90,
      activity: 88,
      management: 90,
      communication: 92,
      creativity: 91,
      reliability: 93,
    };
    return {
      leadership: typeof s.leadership === 'number' ? s.leadership : 90,
      activity: typeof s.activity === 'number' ? s.activity : 88,
      management: typeof s.management === 'number' ? s.management : 90,
      communication: typeof s.communication === 'number' ? s.communication : 92,
      creativity: typeof s.creativity === 'number' ? s.creativity : 91,
      reliability: typeof s.reliability === 'number' ? s.reliability : 93,
    };
  }, [custom?.stats, baseOwner?.defaultStats]);

  // Polaroid Line Carousel slides tailored for this owner
  const ownerSlides = useMemo<Slide[]>(() => {
    if (custom?.photoReel && custom.photoReel.length > 0) {
      return custom.photoReel;
    }
    const seedBase = (baseOwner?.numericId ?? 1) * 19 + 7;
    const slides: Slide[] = [
      {
        image: avatarUrl,
        title: displayName,
        caption: isAr 
          ? `${roleTitle} • ${baseOwner?.era || 'CREATIVE NEXUS'}` 
          : `${roleTitle} • ${baseOwner?.era || 'CREATIVE NEXUS'}`,
        alt: displayName,
      },
      ...(custom?.backgroundImage ? [{
        image: custom.backgroundImage,
        title: isAr ? 'لوحة السيادة التاريخية' : 'Sovereign Chronicle Canvas',
        caption: isAr ? 'الخلفية الملحمية المعتمدة في الأرشيف' : 'Archival portrait chronicle canvas',
        alt: displayName,
      }] : []),
      {
        title: isAr ? 'فجر التأسيس' : 'Genesis Dawn',
        caption: isAr ? 'انطلاقة مسيرة الإبداع وبداية العهد في السيرفر' : 'The dawn of the creative sanctuary',
        palette: 'dawn',
        seed: seedBase + 3,
      },
      {
        title: isAr ? 'قمم المجد' : 'High Pass',
        caption: isAr ? 'تحديات السيرفر وبناء المجد المشترك عبر العصور' : 'Enduring legacy across server eras',
        palette: 'alpine',
        seed: seedBase + 11,
      },
      {
        title: isAr ? 'شفق النصر' : 'Ember Hour',
        caption: isAr ? 'السهرات الملحمية والأمسيات الدافئة مع المجتمع' : 'Golden twilight and legendary server memories',
        palette: 'dusk',
        seed: seedBase + 23,
      },
      {
        title: isAr ? 'الأرشيف الخالد' : 'Still Valley',
        caption: isAr ? 'أثر محفور في ذاكرة السيرفر وتاريخ قادته' : 'Etched forever in the sanctuary chronicle',
        palette: 'mist',
        seed: seedBase + 37,
      },
      {
        title: isAr ? 'سماء الإبداع' : 'Rose Ridge',
        caption: isAr ? 'رؤية القيادة والإلهام المستمر لكل الأعضاء' : 'A vision of eternal leadership and art',
        palette: 'dawn',
        seed: seedBase + 51,
      },
      {
        title: isAr ? 'العهد الأزلي' : 'Blue Hour',
        caption: isAr ? 'قيم الوفاء والأخوة التي تجمع قادة كريتيف' : 'Unbreakable bond and brotherhood of Creative Nexus',
        palette: 'alpine',
        seed: seedBase + 67,
      },
    ];
    return slides;
  }, [custom?.photoReel, avatarUrl, displayName, roleTitle, baseOwner, custom?.backgroundImage, isAr]);

  // Discord Information
  const discordUsername = custom?.discordUsername || baseOwner?.defaultDiscordHandle || '';
  const discordId = custom?.discordId || baseOwner?.defaultDiscordId || '';
  const isDiscordLinked = Boolean(custom?.isDiscordLinked || (user?.discordId && custom?.discordId === user.discordId));

  // Social accounts
  const socials = custom?.socials || {};

  // Permissions to edit: website owner, or match discord ID/username
  const canEdit =
    isOwner ||
    (Boolean(user?.discordId) && (user?.discordId === discordId || user?.username?.toLowerCase() === discordUsername.toLowerCase()));

  // UI Interactive States
  const [isEditing, setIsEditing] = useState(false);
  const [showCardPreview, setShowCardPreview] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Edit Form State
  const [editDisplayName, setEditDisplayName] = useState(displayName);
  const [editUsername, setEditUsername] = useState(username.replace(/^@/, ''));
  const [editRoleTitle, setEditRoleTitle] = useState(roleTitle);
  const [editBio, setEditBio] = useState(bioText);
  const [editQuote, setEditQuote] = useState(quoteText);
  const [editAvatarUrl, setEditAvatarUrl] = useState(avatarUrl);
  const [editBackgroundImage, setEditBackgroundImage] = useState(custom?.backgroundImage || custom?.imageUrl || '');
  const [editDiscordUsername, setEditDiscordUsername] = useState(discordUsername);
  const [editDiscordId, setEditDiscordId] = useState(discordId);
  const [editIsDiscordLinked, setEditIsDiscordLinked] = useState(isDiscordLinked);
  const [editStatus, setEditStatus] = useState<'present' | 'former'>(status);
  const [editAccentColor, setEditAccentColor] = useState(accentKey);
  const [editStats, setEditStats] = useState<OwnerStats>(stats);
  const [editSocialX, setEditSocialX] = useState(socials.twitter || '');
  const [editSocialYoutube, setEditSocialYoutube] = useState(socials.youtube || '');
  const [editSocialTwitch, setEditSocialTwitch] = useState(socials.twitch || '');

  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [avatarUploadLoading, setAvatarUploadLoading] = useState(false);
  const [bgUploadLoading, setBgUploadLoading] = useState(false);
  const [isPhotoReelModalOpen, setIsPhotoReelModalOpen] = useState(false);

  const avatarInputRef = useRef<HTMLInputElement>(null);
  const bgInputRef = useRef<HTMLInputElement>(null);

  // Sync edit form when viewing data updates - ONLY WHEN NOT ACTIVELY EDITING
  useEffect(() => {
    if (isEditing) return; // Prevent overwriting user input while actively editing
    setEditDisplayName(displayName);
    setEditUsername(username.replace(/^@/, ''));
    setEditRoleTitle(roleTitle);
    setEditBio(bioText);
    setEditQuote(quoteText);
    setEditAvatarUrl(avatarUrl);
    setEditBackgroundImage(custom?.backgroundImage || custom?.imageUrl || '');
    setEditDiscordUsername(discordUsername);
    setEditDiscordId(discordId);
    setEditIsDiscordLinked(isDiscordLinked);
    setEditStatus(status);
    setEditAccentColor(accentKey);
    setEditStats(stats);
    setEditSocialX(socials.twitter || '');
    setEditSocialYoutube(socials.youtube || '');
    setEditSocialTwitch(socials.twitch || '');
  }, [
    isEditing,
    displayName,
    username,
    roleTitle,
    bioText,
    quoteText,
    avatarUrl,
    custom?.backgroundImage,
    custom?.imageUrl,
    discordUsername,
    discordId,
    isDiscordLinked,
    status,
    accentKey,
  ]);

  const copyToClipboard = (text: string, fieldName: string) => {
    try {
      navigator.clipboard.writeText(text);
      setCopiedField(fieldName);
      setTimeout(() => setCopiedField(null), 2000);
    } catch {}
  };

  // 1-Click Link Current Active Discord User Session
  const handleLinkCurrentDiscord = () => {
    if (!user) {
      loginWithDiscord();
      return;
    }
    setEditDiscordUsername(user.username || '');
    if (user.discordId) {
      setEditDiscordId(user.discordId);
      setEditIsDiscordLinked(true);
    }
    if (user.avatarUrl && !editAvatarUrl) {
      setEditAvatarUrl(user.avatarUrl);
    }
  };

  // Handle avatar file upload
  const handleAvatarFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setAvatarUploadLoading(true);
      const compressedDataUrl = await compressAvatarFile(file);
      setEditAvatarUrl(compressedDataUrl);
    } catch (err) {
      console.error('Failed to compress avatar:', err);
    } finally {
      setAvatarUploadLoading(false);
    }
  };

  // Handle background wallpaper file upload
  const handleBgFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setBgUploadLoading(true);
      const compressedDataUrl = await compressAvatarFile(file);
      setEditBackgroundImage(compressedDataUrl);
    } catch (err) {
      console.error('Failed to compress background:', err);
    } finally {
      setBgUploadLoading(false);
    }
  };

  // Save changes persistently
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveSuccess(false);

    const cleanAvatar = editAvatarUrl.trim();
    const cleanBg = editBackgroundImage.trim() || cleanAvatar;

    const payload = {
      cardId: targetCardId,
      displayName: editDisplayName.trim() || displayName,
      name: editDisplayName.trim() || displayName,
      username: editUsername.trim() ? `@${editUsername.trim().replace(/^@/, '')}` : username,
      roleTitle: editRoleTitle.trim() || roleTitle,
      bio: editBio.trim(),
      subtitle: editBio.trim(),
      quote: editQuote.trim(),
      specialty: editQuote.trim(),
      avatarUrl: cleanAvatar,
      imageUrl: cleanBg,
      backgroundImage: cleanBg,
      discordUsername: editDiscordUsername.trim(),
      discordId: editDiscordId.trim(),
      isDiscordLinked: editIsDiscordLinked,
      status: editStatus,
      accentColor: editAccentColor,
      stats: editStats,
      socials: {
        discord: editDiscordUsername.trim(),
        twitter: editSocialX.trim() || undefined,
        youtube: editSocialYoutube.trim() || undefined,
        twitch: editSocialTwitch.trim() || undefined,
      },
    };

    const res = await updateCard(payload);
    setIsSaving(false);

    if (res.success) {
      setSaveSuccess(true);
      setTimeout(() => {
        setSaveSuccess(false);
        setIsEditing(false);
      }, 700);
    }
  };

  // Save updated photo reel from modal
  const handleSavePhotoReel = async (updatedSlides: OwnerPhotoSlide[]) => {
    await updateCard({
      cardId: targetCardId,
      photoReel: updatedSlides,
    });
  };

  return (
    <main className="relative min-h-screen w-full pt-24 pb-20 px-4 sm:px-6 lg:px-8 selection:bg-cyan-500/20 selection:text-white">
      {/* Background Ambient Radial Glow matching Owner Accent */}
      <div
        className="fixed top-20 start-1/2 -translate-x-1/2 rtl:translate-x-1/2 w-[700px] h-[360px] pointer-events-none rounded-full blur-[140px] opacity-25 z-0 transition-all duration-700"
        style={{ background: accent.hex }}
        aria-hidden="true"
      />

      <div className="relative z-10 max-w-4xl mx-auto w-full">
        {/* ============================================================ */}
        {/* TOP BAR / BREADCRUMB: Back to History Room                   */}
        {/* ============================================================ */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: 'easeOut' }}
          className="flex items-center justify-between gap-4 mb-8"
        >
          <button
            type="button"
            onClick={() => navigate('/history#owners')}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-slate-900/70 hover:bg-slate-800/80 border border-white/10 hover:border-white/20 text-slate-300 hover:text-white text-xs font-medium transition-all backdrop-blur-md cursor-pointer group active:scale-95 shadow-sm"
          >
            {isAr ? (
              <>
                <ArrowRight size={14} className="group-hover:translate-x-0.5 transition-transform text-cyan-400" />
                <span>العودة لأرشيف الملاك</span>
              </>
            ) : (
              <>
                <ArrowLeft size={14} className="group-hover:-translate-x-0.5 transition-transform text-cyan-400" />
                <span>Back to Owners Chronicle</span>
              </>
            )}
          </button>

          <div className="flex items-center gap-2.5">
            {/* Roman Numeral Era Pill */}
            <span className="font-serif text-[11px] font-bold tracking-widest text-slate-400 px-2.5 py-1 rounded-lg bg-black/40 border border-white/10 backdrop-blur-md uppercase">
              {romanNumeral}
            </span>

            {/* Edit Profile Button for authorized owners */}
            {canEdit && (
              <button
                type="button"
                onClick={() => setIsEditing(!isEditing)}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all backdrop-blur-md cursor-pointer shadow-sm active:scale-95 ${
                  isEditing
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30'
                    : 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/35 hover:bg-cyan-500/25 hover:border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.15)]'
                }`}
              >
                {isEditing ? (
                  <>
                    <X size={13} />
                    <span>{isAr ? 'إلغاء التعديل' : 'Close Editor'}</span>
                  </>
                ) : (
                  <>
                    <Edit3 size={13} className="text-cyan-400" />
                    <span>{isAr ? 'تعديل الملف' : 'Edit Profile'}</span>
                  </>
                )}
              </button>
            )}
          </div>
        </motion.div>

        {/* ============================================================ */}
        {/* EDIT PROFILE DRAWER / PANEL (Smooth Entrance)               */}
        {/* ============================================================ */}
        <AnimatePresence>
          {isEditing && (
            <motion.section
              initial={{ opacity: 0, height: 0, y: -20 }}
              animate={{ opacity: 1, height: 'auto', y: 0 }}
              exit={{ opacity: 0, height: 0, y: -20 }}
              transition={{ duration: 0.35, ease: 'easeInOut' }}
              className="overflow-hidden mb-8"
            >
              <div className="p-6 sm:p-8 rounded-3xl bg-[#031514]/95 border border-cyan-500/30 backdrop-blur-2xl shadow-2xl space-y-6">
                <div className="flex items-center justify-between border-b border-white/10 pb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                      <Sliders size={16} />
                    </div>
                    <div>
                      <h3 className="font-display font-bold text-lg text-white">
                        {isAr ? 'تعديل هوية المالك الرقمية' : 'Edit Owner Digital Identity'}
                      </h3>
                      <p className="text-xs text-slate-400 font-sans">
                        {isAr
                          ? 'تحديث البيانات، الرتبة، السيرة الذاتية، وربط حساب ديسكورد'
                          : 'Update public identity, bio, stats, and link Discord account'}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                  >
                    <X size={16} />
                  </button>
                </div>

                <form onSubmit={handleSaveProfile} className="space-y-6">
                  {/* Row 1: Display Name & Username Handle */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono text-slate-300 mb-1.5">
                        {isAr ? 'اسم العرض (Display Name)' : 'Display Name'}
                      </label>
                      <input
                        type="text"
                        value={editDisplayName}
                        onChange={(e) => setEditDisplayName(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-cyan-400 text-sm text-white font-sans focus:outline-hidden transition-colors"
                        placeholder="e.g. KOHAN, Edgar, SHADOW"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-slate-300 mb-1.5">
                        {isAr ? 'المعرف الرقمي (Username / Handle)' : 'Username / Handle'}
                      </label>
                      <input
                        type="text"
                        value={editUsername}
                        onChange={(e) => setEditUsername(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-cyan-400 text-sm text-white font-sans focus:outline-hidden transition-colors"
                        placeholder="e.g. edgar_creator"
                      />
                    </div>
                  </div>

                  {/* Row 2: Role / Rank Title & Status */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono text-slate-300 mb-1.5">
                        {isAr ? 'الرتبة واللقب القيادي (Rank Title)' : 'Rank / Role Title'}
                      </label>
                      <input
                        type="text"
                        value={editRoleTitle}
                        onChange={(e) => setEditRoleTitle(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-cyan-400 text-sm text-white font-sans focus:outline-hidden transition-colors"
                        placeholder="e.g. Server Owner, Sovereign Creator"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-slate-300 mb-1.5">
                        {isAr ? 'حالة التواجد (Server Presence)' : 'Server Presence'}
                      </label>
                      <select
                        value={editStatus}
                        onChange={(e) => setEditStatus(e.target.value as any)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-cyan-400 text-sm text-white font-sans focus:outline-hidden transition-colors"
                      >
                        <option value="present">{isAr ? 'حالي (Present & Active)' : 'Present & Active'}</option>
                        <option value="former">{isAr ? 'سابق (Former / Historic)' : 'Former / Historic'}</option>
                      </select>
                    </div>
                  </div>

                  {/* Row 3A: Avatar URL & File Upload */}
                  <div>
                    <label className="block text-xs font-mono text-slate-300 mb-1.5">
                      {isAr ? 'الصورة الشخصية (Avatar Image)' : 'Avatar Image URL or Upload'}
                    </label>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl border border-white/20 overflow-hidden bg-black/60 shrink-0">
                        {editAvatarUrl ? (
                          <img src={editAvatarUrl} alt="Preview" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-slate-500 text-xs">
                            None
                          </div>
                        )}
                      </div>
                      <input
                        type="url"
                        value={editAvatarUrl}
                        onChange={(e) => setEditAvatarUrl(e.target.value)}
                        className="flex-1 px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-cyan-400 text-sm text-white font-sans focus:outline-hidden transition-colors"
                        placeholder="https://images.unsplash.com/... or upload"
                      />
                      <input
                        ref={avatarInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleAvatarFile}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => avatarInputRef.current?.click()}
                        disabled={avatarUploadLoading}
                        className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-white/20 text-slate-200 text-xs font-medium flex items-center gap-1.5 cursor-pointer disabled:opacity-50 transition-colors shrink-0"
                      >
                        <Upload size={14} />
                        <span>{avatarUploadLoading ? (isAr ? 'جاري الرفع...' : 'Processing...') : isAr ? 'رفع صورة شخصية' : 'Upload Avatar'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Row 3B: Card Background Wallpaper / Artwork */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="block text-xs font-mono text-slate-300">
                        {isAr ? 'خلفية البطاقة التاريخية (Card Wallpaper Canvas)' : 'Card Wallpaper / Background Canvas'}
                      </label>
                      <span className="text-[10px] text-slate-400 font-sans">
                        {isAr ? 'خلفية البطاقة 3D والأرشيف' : 'Visible in 3D Card'}
                      </span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl border border-white/20 overflow-hidden bg-black/60 shrink-0">
                        {editBackgroundImage ? (
                          <img src={editBackgroundImage} alt="Background Preview" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-slate-500 text-xs">
                            Default
                          </div>
                        )}
                      </div>
                      <input
                        type="url"
                        value={editBackgroundImage}
                        onChange={(e) => setEditBackgroundImage(e.target.value)}
                        className="flex-1 px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-cyan-400 text-sm text-white font-sans focus:outline-hidden transition-colors"
                        placeholder="https://images.unsplash.com/... or upload custom background"
                      />
                      <input
                        ref={bgInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleBgFile}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => bgInputRef.current?.click()}
                        disabled={bgUploadLoading}
                        className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-white/20 text-slate-200 text-xs font-medium flex items-center gap-1.5 cursor-pointer disabled:opacity-50 transition-colors shrink-0"
                      >
                        <Upload size={14} />
                        <span>{bgUploadLoading ? (isAr ? 'جاري الرفع...' : 'Processing...') : isAr ? 'رفع خلفية' : 'Upload BG'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Row 3C: Photo Reel Quick Access */}
                  <div className="p-3.5 rounded-2xl bg-cyan-950/20 border border-cyan-500/25 flex items-center justify-between gap-3 flex-wrap">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300">
                        <Camera size={15} />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-white">
                          {isAr ? 'ألبوم الذكريات واللقطات الأثرية المعلقة' : 'Archival Snapshots & Photo Reel'}
                        </p>
                        <p className="text-[11px] text-slate-400">
                          {isAr ? `يحتوي حالياً على ${ownerSlides.length} لقطة معلقة على الحبل الأثري` : `${ownerSlides.length} prints hanging on the chronicle string`}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsPhotoReelModalOpen(true)}
                      className="px-3.5 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/35 border border-cyan-400/40 text-cyan-200 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
                    >
                      <Camera size={13} />
                      <span>{isAr ? 'تعديل صور الألبوم والقصص' : 'Edit Photos & Stories'}</span>
                    </button>
                  </div>

                  {/* Row 4: Biography */}
                  <div>
                    <label className="block text-xs font-mono text-slate-300 mb-1.5">
                      {isAr ? 'السيرة الذاتية الموجزة (Short Biography)' : 'Short Biography'}
                    </label>
                    <textarea
                      rows={3}
                      value={editBio}
                      onChange={(e) => setEditBio(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-cyan-400 text-sm text-white font-sans focus:outline-hidden transition-colors leading-relaxed"
                      placeholder="Write a refined, memorable description of this Owner's leadership and legacy..."
                    />
                  </div>

                  {/* Row 5: Quote / Specialty */}
                  <div>
                    <label className="block text-xs font-mono text-slate-300 mb-1.5">
                      {isAr ? 'مقولة أو تخصص (Quote / Philosophy)' : 'Quote / Philosophy / Specialty'}
                    </label>
                    <input
                      type="text"
                      value={editQuote}
                      onChange={(e) => setEditQuote(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 focus:border-cyan-400 text-sm text-white font-sans focus:outline-hidden transition-colors"
                      placeholder="e.g. Forging the sanctuary with art and unyielding passion."
                    />
                  </div>

                  {/* ============================================================ */}
                  {/* DISCORD ACCOUNT LINKING FIELD (Core Requirement)             */}
                  {/* ============================================================ */}
                  <div className="p-4 sm:p-5 rounded-2xl bg-black/50 border border-[#5865F2]/40 space-y-4">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-[#5865F2]/20 border border-[#5865F2]/40 flex items-center justify-center text-[#5865F2]">
                          <MessageSquare size={14} />
                        </div>
                        <span className="font-display font-semibold text-sm text-white">
                          {isAr ? 'ربط حساب ديسكورد الرسمي' : 'Official Discord Account Linking'}
                        </span>
                      </div>

                      {/* Real Status Badge */}
                      {editIsDiscordLinked ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/35">
                          <CheckCircle2 size={12} className="text-emerald-400" />
                          <span>{isAr ? 'موثق ومربوط بـ OAuth' : 'Verified & Linked via Discord'}</span>
                        </span>
                      ) : editDiscordUsername ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-medium bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                          <AlertCircle size={12} className="text-cyan-400" />
                          <span>{isAr ? 'معرف محفوظ كبيان شخصي' : 'Saved Profile Handle'}</span>
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-400">
                          {isAr ? 'لم يتم الربط بعد' : 'Not linked'}
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-mono text-slate-300 mb-1">
                          {isAr ? 'اسم مستخدم ديسكورد (Username / Tag)' : 'Discord Username / Tag'}
                        </label>
                        <input
                          type="text"
                          value={editDiscordUsername}
                          onChange={(e) => {
                            setEditDiscordUsername(e.target.value);
                            if (!e.target.value) setEditIsDiscordLinked(false);
                          }}
                          className="w-full px-3 py-2 rounded-xl bg-black/70 border border-white/15 focus:border-[#5865F2] text-xs text-white font-mono focus:outline-hidden"
                          placeholder="e.g. edgar_nexus"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-mono text-slate-300 mb-1">
                          {isAr ? 'معرف الحساب الرقمي (Discord User ID)' : 'Discord User ID (17-19 digits)'}
                        </label>
                        <input
                          type="text"
                          value={editDiscordId}
                          onChange={(e) => {
                            setEditDiscordId(e.target.value.replace(/\D/g, ''));
                            if (!e.target.value) setEditIsDiscordLinked(false);
                          }}
                          className="w-full px-3 py-2 rounded-xl bg-black/70 border border-white/15 focus:border-[#5865F2] text-xs text-white font-mono focus:outline-hidden"
                          placeholder="e.g. 871043296280076308"
                        />
                      </div>
                    </div>

                    {/* Integrated Sync Button using actual OAuth session */}
                    <div className="flex items-center justify-between gap-3 pt-2 border-t border-white/10 flex-wrap">
                      <p className="text-[11px] text-slate-400 font-sans max-w-md">
                        {isAr
                          ? 'يمكنك ربط جلسة ديسكورد الحالية الموثقة بنقرة واحدة لجلب المعرف والتوثيق فوراً.'
                          : 'You can link your active authenticated Discord session in one click to verify ownership.'}
                      </p>
                      {isAuthenticated && user?.discordId ? (
                        <button
                          type="button"
                          onClick={handleLinkCurrentDiscord}
                          className="px-3 py-1.5 rounded-xl bg-[#5865F2]/25 hover:bg-[#5865F2]/40 border border-[#5865F2]/50 text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95"
                        >
                          <Check size={13} className="text-[#5865F2]" />
                          <span>{isAr ? 'ربط حسابي الحالي المسجل' : 'Link My Logged-in Discord'}</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => loginWithDiscord()}
                          className="px-3 py-1.5 rounded-xl bg-[#5865F2] hover:bg-[#4752c4] text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95"
                        >
                          <ExternalLink size={13} />
                          <span>{isAr ? 'تسجيل الدخول بديسكورد للربط' : 'Login via Discord to Link'}</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Row 6: Stats Sliders */}
                  <div className="p-4 sm:p-5 rounded-2xl bg-black/40 border border-white/10 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs font-mono text-cyan-300">
                        <BarChart3 size={14} />
                        <span>{isAr ? 'إحصائيات القيادة والكفاءة (0 - 100)' : 'Leadership Attributes & Stats'}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">
                        Avg: {Math.round((Object.values(editStats) as number[]).reduce((a: number, b: number) => a + Number(b || 0), 0) / 6)}%
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {(Object.keys(editStats) as Array<keyof OwnerStats>).map((statKey) => (
                        <div key={statKey} className="space-y-1">
                          <div className="flex items-center justify-between text-[11px] font-mono text-slate-300">
                            <span className="capitalize">{statKey}</span>
                            <span className="text-cyan-400 font-bold">{editStats[statKey]}%</span>
                          </div>
                          <input
                            type="range"
                            min="50"
                            max="100"
                            value={editStats[statKey]}
                            onChange={(e) =>
                              setEditStats({ ...editStats, [statKey]: parseInt(e.target.value, 10) })
                            }
                            className="w-full accent-cyan-400 h-1 bg-slate-800 rounded-lg cursor-pointer"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Row 7: Accent Color Preset */}
                  <div>
                    <label className="block text-xs font-mono text-slate-300 mb-2">
                      {isAr ? 'لون الهالة الملكية (Aura Accent Color)' : 'Aura Accent Color'}
                    </label>
                    <div className="flex items-center gap-2 flex-wrap">
                      {Object.keys(ACCENT_COLOR_MAP).map((colorKey) => {
                        const acc = getAccentColor(colorKey);
                        const isSelected = editAccentColor === colorKey;
                        return (
                          <button
                            key={colorKey}
                            type="button"
                            onClick={() => setEditAccentColor(colorKey)}
                            className={`w-7 h-7 rounded-full transition-transform cursor-pointer relative flex items-center justify-center ${
                              isSelected ? 'scale-125 ring-2 ring-white shadow-lg' : 'hover:scale-110 opacity-70'
                            }`}
                            style={{ backgroundColor: acc.hex }}
                            title={acc.nameEn}
                          >
                            {isSelected && <Check size={12} className="text-black" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Submit Actions */}
                  <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
                    <button
                      type="button"
                      onClick={() => setIsEditing(false)}
                      className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white transition-colors cursor-pointer"
                    >
                      {isAr ? 'إلغاء' : 'Cancel'}
                    </button>
                    <button
                      type="submit"
                      disabled={isSaving}
                      className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 text-slate-950 text-xs font-bold font-cairo shadow-[0_0_20px_rgba(6,182,212,0.4)] hover:shadow-[0_0_25px_rgba(6,182,212,0.6)] transition-all cursor-pointer disabled:opacity-50 active:scale-95 flex items-center gap-2"
                    >
                      {saveSuccess ? (
                        <>
                          <Check size={14} />
                          <span>{isAr ? 'تم الحفظ بنجاح!' : 'Saved Successfully!'}</span>
                        </>
                      ) : isSaving ? (
                        <span>{isAr ? 'جاري الحفظ...' : 'Saving Changes...'}</span>
                      ) : (
                        <span>{isAr ? 'حفظ التعديلات' : 'Save Profile Changes'}</span>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </motion.section>
          )}
        </AnimatePresence>

        {/* ============================================================ */}
        {/* REFINED PROFILE HEADER (Minimal, High-end, Modern)           */}
        {/* ============================================================ */}
        <motion.header
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: 'easeOut' }}
          className="relative p-6 sm:p-8 md:p-10 rounded-3xl sm:rounded-[2.5rem] bg-gradient-to-b from-white/[0.05] via-slate-950/70 to-slate-950/95 border border-white/10 backdrop-blur-2xl shadow-2xl mb-8 overflow-hidden"
        >
          {/* Subtle Accent Glow Arc */}
          <div
            className="absolute top-0 inset-x-0 h-1 transition-all duration-500"
            style={{
              background: `linear-gradient(90deg, transparent 0%, ${accent.hex} 50%, transparent 100%)`,
              boxShadow: `0 0 20px ${accent.hex}`,
            }}
          />

          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 sm:gap-8">
            {/* Avatar Container with Luxury Ring & Status Glow */}
            <div className="relative group shrink-0">
              <div
                className="w-24 h-24 sm:w-28 sm:h-28 md:w-32 md:h-32 rounded-3xl p-1 border-2 transition-all duration-300"
                style={{
                  borderColor: `${accent.hex}80`,
                  boxShadow: `0 0 30px ${accent.hex}30`,
                }}
              >
                <img
                  src={avatarUrl}
                  alt={displayName}
                  className="w-full h-full object-cover rounded-[1.3rem] bg-slate-900 transition-transform duration-300 group-hover:scale-102"
                />
              </div>

              {/* Status Indicator Pip */}
              <div
                className={`absolute -bottom-1 -end-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold border backdrop-blur-md flex items-center gap-1.5 shadow-md ${
                  isPresent
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-slate-900/90 text-slate-400 border-slate-700/50'
                }`}
              >
                {isPresent ? (
                  <>
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400" />
                    </span>
                    <span>{isAr ? 'متواجد' : 'Active'}</span>
                  </>
                ) : (
                  <>
                    <Clock size={10} className="text-slate-400" />
                    <span>{isAr ? 'أرشيفي' : 'Historic'}</span>
                  </>
                )}
              </div>
            </div>

            {/* Identity Info */}
            <div className="flex-1 text-center sm:text-start min-w-0 space-y-2">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2.5">
                {/* Role / Rank Pill */}
                <span
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border backdrop-blur-md"
                  style={{
                    backgroundColor: `${accent.hex}18`,
                    borderColor: `${accent.hex}45`,
                    color: accent.hex,
                  }}
                >
                  <Crown size={13} className="shrink-0" />
                  <span>{roleTitle}</span>
                </span>

                {/* Country Flag Badge if present */}
                {country && (
                  <CountryFlag
                    country={country}
                    name={country.toUpperCase()}
                    className="border-white/10"
                  />
                )}

                {/* Badge Tag */}
                <span className="text-[11px] font-mono text-slate-400 px-2 py-0.5 rounded-md bg-white/5 border border-white/5">
                  {badgeText}
                </span>
              </div>

              {/* Display Name */}
              <h1 className="font-display font-extrabold text-3xl sm:text-4xl md:text-5xl text-white tracking-wide break-words drop-shadow-[0_2px_15px_rgba(0,0,0,0.8)]">
                {displayName}
              </h1>

              {/* Handle & Tenure */}
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 text-xs font-mono text-slate-400">
                <span className="text-cyan-300 font-semibold">{username}</span>
                <span className="text-slate-600">•</span>
                <span>{baseOwner?.era || 'CREATIVE NEXUS'}</span>
                {baseOwner?.joinedYear && (
                  <>
                    <span className="text-slate-600">•</span>
                    <span>Est. {baseOwner.joinedYear}</span>
                  </>
                )}
              </div>
            </div>
          </div>
        </motion.header>

        {/* ============================================================ */}
        {/* SHORT BIOGRAPHY & PHILOSOPHY (Minimal & Clean)               */}
        {/* ============================================================ */}
        <motion.section
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.1, ease: 'easeOut' }}
          className="p-6 sm:p-7 rounded-3xl bg-slate-950/60 border border-white/10 backdrop-blur-xl shadow-xl mb-8 space-y-4"
        >
          <div className="flex items-center justify-between border-b border-white/5 pb-3">
            <span className="font-mono text-xs uppercase tracking-widest text-slate-400 flex items-center gap-2">
              <Sparkles size={13} className="text-cyan-400" />
              <span>{isAr ? 'السيرة الذاتية والأثر' : 'Biography & Chronicle'}</span>
            </span>
            {canEdit && (
              <button
                type="button"
                onClick={() => setIsEditing(true)}
                className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Edit3 size={11} />
                <span>{isAr ? 'تعديل' : 'Edit'}</span>
              </button>
            )}
          </div>

          <p className="font-sans text-slate-200 text-sm sm:text-base leading-relaxed font-light">
            {bioText ||
              (isAr
                ? 'أحد القادة التاريخيين في مركز الابداع، ساهم في رسم مسيرة السيرفر وتثبيت دعائمه.'
                : 'A recognized leader in CREATIVE NEXUS who contributed to shaping server history and foundational culture.')}
          </p>

          {quoteText && (
            <div
              className="p-3.5 rounded-2xl border text-xs sm:text-sm font-sans italic text-slate-300 flex items-start gap-2.5"
              style={{
                backgroundColor: `${accent.hex}0d`,
                borderColor: `${accent.hex}30`,
              }}
            >
              <span className="text-lg leading-none" style={{ color: accent.hex }}>
                “
              </span>
              <p className="flex-1 not-italic font-serif">{quoteText}</p>
            </div>
          )}
        </motion.section>

        {/* ============================================================ */}
        {/* COMPACT STATS SECTION (Real Data from OwnerStats)            */}
        {/* ============================================================ */}
        <motion.section
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.15, ease: 'easeOut' }}
          className="p-6 sm:p-7 rounded-3xl bg-slate-950/60 border border-white/10 backdrop-blur-xl shadow-xl mb-8 space-y-5"
        >
          <div className="flex items-center justify-between border-b border-white/5 pb-3">
            <span className="font-mono text-xs uppercase tracking-widest text-slate-400 flex items-center gap-2">
              <BarChart3 size={13} className="text-cyan-400" />
              <span>{isAr ? 'مؤشرات الكفاءة والسمات القيادية' : 'Attributes & Performance Metrics'}</span>
            </span>
            <span className="font-mono text-[11px] text-cyan-400/80">
              Verified Archival Index
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {[
              { key: 'leadership', labelAr: 'القيادة والسيادة', labelEn: 'Leadership', val: stats.leadership },
              { key: 'activity', labelAr: 'النشاط والمواظبة', labelEn: 'Activity', val: stats.activity },
              { key: 'management', labelAr: 'إدارة وتوجيه', labelEn: 'Management', val: stats.management },
              { key: 'communication', labelAr: 'التواصل والاحتواء', labelEn: 'Communication', val: stats.communication },
              { key: 'creativity', labelAr: 'الإبداع والابتكار', labelEn: 'Creativity', val: stats.creativity },
              { key: 'reliability', labelAr: 'الموثوقية والوفاء', labelEn: 'Reliability', val: stats.reliability },
            ].map((stat) => (
              <div
                key={stat.key}
                className="p-3.5 rounded-2xl bg-black/40 border border-white/5 space-y-2 hover:border-white/15 transition-all"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-sans font-medium text-slate-300">
                    {isAr ? stat.labelAr : stat.labelEn}
                  </span>
                  <span className="font-mono font-bold text-cyan-300">{stat.val}%</span>
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${stat.val}%` }}
                    transition={{ duration: 0.8, ease: 'easeOut', delay: 0.2 }}
                    className="h-full rounded-full"
                    style={{
                      background: `linear-gradient(90deg, ${accent.hex}99, ${accent.hex})`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.section>

        {/* ============================================================ */}
        {/* ARCHIVAL SNAPSHOTS & PHOTO REEL — EDGE-TO-EDGE CAROUSEL      */}
        {/* ============================================================ */}
        <section className="relative my-10 sm:my-14 w-screen left-1/2 -translate-x-1/2 rtl:translate-x-1/2 overflow-hidden select-none">
          {/* Top Bar Header with Controls */}
          <div className="max-w-4xl mx-auto px-4 sm:px-6 mb-3 sm:mb-4 flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-2.5">
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center border shadow-xs shrink-0"
                style={{
                  backgroundColor: `${accent.hex}15`,
                  borderColor: `${accent.hex}40`,
                  color: accent.hex,
                }}
              >
                <Sparkles size={16} />
              </div>
              <div>
                <h3 className="font-display font-bold text-sm sm:text-base text-white flex items-center gap-2">
                  <span>{isAr ? 'أرشيف الذكريات واللقطات الأثرية' : 'Archival Snapshots & Photo Reel'}</span>
                  <span className="text-[10px] font-mono font-medium px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-slate-300">
                    {ownerSlides.length} {isAr ? 'لقطات' : 'Prints'}
                  </span>
                </h3>
                <p className="text-[11px] font-sans text-slate-400">
                  {isAr ? 'حبل الذكريات واللقطات الأثرية — اسحب الصور أو انقر للتنقل' : 'Suspended chronicle memories — drag or click prints'}
                </p>
              </div>
            </div>

            {/* Owner Reel Edit Controls */}
            {canEdit && (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsPhotoReelModalOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-400/40 text-cyan-300 hover:text-cyan-200 text-xs font-semibold shadow-sm transition-all cursor-pointer backdrop-blur-md active:scale-95"
                >
                  <Camera size={13} />
                  <span>{isAr ? 'تعديل ألبوم الصور' : 'Edit Photo Reel'}</span>
                </button>
              </div>
            )}
          </div>

          {/* Full-width Carousel with Large Rectangular Modern Prints (Only the string, no side holding brackets) */}
          <div className="relative w-full overflow-hidden">
            <PolaroidLineCarousel
              slides={ownerSlides}
              height="560px"
              cardWidth={460}
              sag={46}
              swing={1}
              autoplay={4500}
              string={accent.hex}
              background="transparent"
              ink="#f8fafc"
              variant="modern"
              aspectRatio="rectangular"
              ariaLabel={isAr ? `معرض ذكريات ${displayName}` : `${displayName}'s Archival Photo Reel`}
            />
          </div>
        </section>

        {/* ============================================================ */}
        {/* AUTHENTIC OWNER 3D CARD SHOWCASE TOGGLE                     */}
        {/* ============================================================ */}
        <motion.section
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.25, ease: 'easeOut' }}
          className="text-center pt-4"
        >
          <button
            type="button"
            onClick={() => setShowCardPreview(!showCardPreview)}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 text-slate-300 hover:text-white text-xs font-semibold transition-all cursor-pointer backdrop-blur-md shadow-md active:scale-95"
          >
            <Layers size={14} className="text-cyan-400" />
            <span>
              {showCardPreview
                ? isAr
                  ? 'إخفاء بطاقة الأرشيف التاريخية'
                  : 'Hide Historical Chronicle Card'
                : isAr
                ? 'استعراض بطاقة الأرشيف الثلاثية الأبعاد'
                : 'Inspect 3D Chronicle Card'}
            </span>
          </button>

          <AnimatePresence>
            {showCardPreview && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                transition={{ duration: 0.35, ease: 'easeOut' }}
                className="mt-8 flex justify-center"
              >
                <div className="w-full max-w-sm">
                  <Owner3DCard
                    cardId={targetCardId}
                    fallbackCardId={fallbackCardId}
                    romanNumeral={romanNumeral}
                    name={displayName}
                    displayName={displayName}
                    rankTitle={roleTitle}
                    subtitleAr={bioText}
                    subtitleEn={bioText}
                    badge={badgeText}
                    country={country}
                    status={status}
                    accentColor={accentKey}
                    avatarUrl={avatarUrl}
                    className="shadow-2xl"
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.section>
        <PhotoReelEditModal
          isOpen={isPhotoReelModalOpen}
          onClose={() => setIsPhotoReelModalOpen(false)}
          slides={ownerSlides}
          initialSlides={ownerSlides}
          onSave={handleSavePhotoReel}
          ownerName={displayName}
          accentColor={accent.hex}
        />
      </div>
    </main>
  );
}

export default OwnerProfile;
