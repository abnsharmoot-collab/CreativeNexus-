import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Megaphone, Pin, Search, Plus, Sparkles, Filter, 
  Calendar, ArrowRight, Shield, AlertCircle, RefreshCw 
} from 'lucide-react';
import { useAnnouncements } from '../context/AnnouncementContext';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { AnnouncementCard } from '../components/announcements/AnnouncementCard';
import { AnnouncementModal } from '../components/announcements/AnnouncementModal';
import { Announcement, ANNOUNCEMENT_CATEGORIES } from '../types/announcement';
import { HiddenIraqiFlag } from '../components/easterEggs/HiddenIraqiFlag';

export const Announcements: React.FC = () => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { role } = useAuth();
  const isOwner = role === 'OWNER';

  const {
    announcements,
    pinnedAnnouncements,
    regularAnnouncements,
    filteredAnnouncements,
    loading,
    error,
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    refreshAnnouncements,
    createAnnouncement,
    updateAnnouncement,
    togglePin,
    deleteAnnouncement
  } = useAnnouncements();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  // Set document title
  useEffect(() => {
    document.title = `${isAr ? 'إعلانات السيرفر' : 'CN Announcements'} | CREATINE NEXUS`;
  }, [isAr]);

  const handleOpenCreateModal = () => {
    setEditingAnnouncement(null);
    setModalMode('create');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (announcement: Announcement) => {
    setEditingAnnouncement(announcement);
    setModalMode('edit');
    setIsModalOpen(true);
  };

  const handleModalSubmit = async (data: {
    title: string;
    content: string;
    category: string;
    isPinned: boolean;
    authorDisplayName?: string;
    imageUrl?: string;
    images?: string[];
  }) => {
    if (modalMode === 'create') {
      await createAnnouncement(data);
      setActionNotice(isAr ? 'تم نشر الإعلان بنجاح' : 'Announcement published successfully');
    } else if (editingAnnouncement) {
      await updateAnnouncement(editingAnnouncement.id, data);
      setActionNotice(isAr ? 'تم تحديث الإعلان بنجاح' : 'Announcement updated successfully');
    }
    setTimeout(() => setActionNotice(null), 3000);
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteAnnouncement(id);
      setActionNotice(isAr ? 'تم حذف الإعلان' : 'Announcement deleted');
      setTimeout(() => setActionNotice(null), 3000);
    } catch (err: any) {
      console.error('Delete error:', err);
      alert(err.message || 'Failed to delete announcement');
    }
  };

  const handleTogglePin = async (id: string, isPinned: boolean) => {
    try {
      await togglePin(id, isPinned);
      setActionNotice(isPinned 
        ? (isAr ? 'تم تثبيت الإعلان في الأعلى' : 'Announcement pinned to top')
        : (isAr ? 'تم إلغاء تثبيت الإعلان' : 'Announcement unpinned')
      );
      setTimeout(() => setActionNotice(null), 3000);
    } catch (err: any) {
      console.error('Pin toggle error:', err);
    }
  };

  // Determine if searching/filtering is active
  const isFiltering = selectedCategory !== 'ALL' || searchQuery.trim().length > 0;

  return (
    <div className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 pt-28 pb-20">
      {/* Toast Notice */}
      <AnimatePresence>
        {actionNotice && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-20 start-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full bg-archive-cyan text-archive-dark font-bold text-xs sm:text-sm shadow-xl shadow-cyan-950/50 flex items-center gap-2 border border-archive-cyan/40"
          >
            <Sparkles size={16} />
            <span>{actionNotice}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Header Section */}
      <div className="relative mb-8 sm:mb-12">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-archive-cyan/15 pb-6 sm:pb-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-archive-cyan/10 border border-archive-cyan/25 text-archive-cyan text-xs font-semibold uppercase tracking-wider">
                <Megaphone size={13} />
                <span>{isAr ? 'البيانات الرسمية' : 'Official Dispatches'}</span>
                <HiddenIraqiFlag flagId="flag-announcements-press" title="Archival press watermark" />
              </div>
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-archive-paper tracking-tight">
              {isAr ? 'إعلانات السيرفر' : 'CN Announcements'}
            </h1>
            <p className="text-sm sm:text-base text-archive-paper-muted max-w-2xl mt-2 leading-relaxed">
              {isAr
                ? 'البيانات والتوجيهات والقرارات الرسمية المعتمدة من قيادة مجتمع CREATINE NEXUS.'
                : 'Directives, community updates, and major announcements from CREATINE NEXUS leadership.'}
            </p>
          </div>

          {/* Owner Action Buttons */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={refreshAnnouncements}
              title={isAr ? 'تحديث' : 'Refresh'}
              className="p-2.5 rounded-xl border border-archive-cyan/20 bg-archive-dark/60 hover:bg-archive-card text-archive-paper-muted hover:text-archive-cyan transition-colors"
            >
              <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
            </button>

            {isOwner && (
              <button
                onClick={handleOpenCreateModal}
                className="inline-flex items-center gap-2 px-4 sm:px-5 py-2.5 rounded-xl bg-archive-cyan text-archive-dark font-bold text-xs sm:text-sm hover:bg-archive-cyan/90 transition-all shadow-lg shadow-cyan-950/40 cursor-pointer"
              >
                <Plus size={16} />
                <span>{isAr ? 'إعلان جديد' : 'New Announcement'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Search & Category Filter Controls */}
      <div className="mb-8 space-y-3 sm:space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search size={16} className="absolute start-3.5 top-1/2 -translate-y-1/2 text-archive-paper-muted pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isAr ? 'البحث في عناوين ومحتوى الإعلانات...' : 'Search announcements by title, keyword, or author...'}
              className="w-full ps-10 pe-4 py-2.5 rounded-xl bg-archive-card/90 border border-archive-cyan/15 focus:border-archive-cyan focus:outline-none text-archive-paper text-xs sm:text-sm placeholder:text-archive-paper-muted/50 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute end-3 top-1/2 -translate-y-1/2 text-xs text-archive-paper-muted hover:text-archive-paper px-1.5 py-0.5"
              >
                ✕
              </button>
            )}
          </div>

          {/* Category Filter Pills (Mobile scrollable, desktop flex) */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            <button
              onClick={() => setSelectedCategory('ALL')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === 'ALL'
                  ? 'bg-archive-cyan text-archive-dark shadow-md shadow-cyan-900/30'
                  : 'bg-archive-card/80 text-archive-paper-muted border border-archive-cyan/10 hover:border-archive-cyan/30 hover:text-archive-paper'
              }`}
            >
              {isAr ? 'الكل' : 'All'}
            </button>

            {ANNOUNCEMENT_CATEGORIES.map((cat) => {
              const isSelected = selectedCategory.toLowerCase() === cat.id.toLowerCase();
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(isSelected ? 'ALL' : cat.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                    isSelected
                      ? `${cat.color} ring-1 ring-archive-cyan/40 scale-105 shadow-sm font-bold`
                      : 'bg-archive-card/80 text-archive-paper-muted border border-archive-cyan/10 hover:border-archive-cyan/30 hover:text-archive-paper'
                  }`}
                >
                  {isAr ? cat.labelAr : cat.labelEn}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Error Notice */}
      {error && (
        <div className="mb-6 p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm flex items-center gap-3">
          <AlertCircle size={18} className="shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Main Content Area */}
      {loading && announcements.length === 0 ? (
        <div className="py-24 text-center">
          <div className="inline-block w-8 h-8 border-2 border-archive-cyan border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-sm text-archive-paper-muted">{isAr ? 'جاري تحميل الإعلانات...' : 'Loading announcements...'}</p>
        </div>
      ) : filteredAnnouncements.length === 0 ? (
        /* Empty State */
        <div className="rounded-2xl border border-archive-cyan/20 bg-archive-card/60 p-10 sm:p-16 text-center max-w-xl mx-auto my-12">
          <div className="w-14 h-14 rounded-2xl bg-archive-cyan/10 border border-archive-cyan/20 flex items-center justify-center text-archive-cyan mx-auto mb-4">
            <Megaphone size={28} />
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-archive-paper mb-2">
            {isFiltering
              ? (isAr ? 'لا توجد نتائج مطابقة' : 'No Matching Announcements Found')
              : (isAr ? 'لا توجد إعلانات منشورة حتى الآن' : 'No Announcements Published Yet')}
          </h3>
          <p className="text-sm text-archive-paper-muted leading-relaxed mb-6">
            {isFiltering
              ? (isAr ? 'جرّب تغيير كلمات البحث أو التصنيف المحدد.' : 'Try adjusting your search terms or filter category.')
              : (isAr ? 'سيتم نشر البيانات والقرارات الرسمية هنا من قبل إدارة السيرفر.' : 'Official dispatches from server leadership will appear here.')}
          </p>

          {isFiltering ? (
            <button
              onClick={() => {
                setSelectedCategory('ALL');
                setSearchQuery('');
              }}
              className="px-4 py-2 rounded-xl bg-archive-dark border border-archive-cyan/30 text-archive-cyan text-xs font-semibold hover:bg-archive-card transition-colors"
            >
              {isAr ? 'إعادة ضبط البحث' : 'Clear Search & Filters'}
            </button>
          ) : isOwner ? (
            <button
              onClick={handleOpenCreateModal}
              className="px-5 py-2.5 rounded-xl bg-archive-cyan text-archive-dark font-bold text-xs sm:text-sm hover:bg-archive-cyan/90 transition-all inline-flex items-center gap-2"
            >
              <Plus size={16} />
              <span>{isAr ? 'نشر الإعلان الأول' : 'Publish First Announcement'}</span>
            </button>
          ) : null}
        </div>
      ) : isFiltering ? (
        /* Filtered Flat Grid */
        <div>
          <div className="flex items-center justify-between mb-4">
            <p className="text-xs font-semibold text-archive-paper-muted uppercase tracking-wider">
              {isAr
                ? `النتائج (${filteredAnnouncements.length})`
                : `Search Results (${filteredAnnouncements.length})`}
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredAnnouncements.map((announcement, idx) => (
              <AnnouncementCard
                key={announcement.id}
                announcement={announcement}
                hasPostageStamp={idx === 0}
                onEdit={isOwner ? handleOpenEditModal : undefined}
                onDelete={isOwner ? handleDelete : undefined}
                onTogglePin={isOwner ? handleTogglePin : undefined}
              />
            ))}
          </div>
        </div>
      ) : (
        /* Normal Layout: Featured / Pinned Section + Recent Feed */
        <div className="space-y-10">
          {/* Pinned Section */}
          {pinnedAnnouncements.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Pin size={16} className="text-amber-400 rotate-45" />
                <h2 className="text-sm sm:text-base font-bold text-archive-paper uppercase tracking-wider">
                  {isAr ? 'الإعلانات المثبتة' : 'Pinned Directives'}
                </h2>
                <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30">
                  {pinnedAnnouncements.length}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {pinnedAnnouncements.map((announcement, idx) => (
                  <AnnouncementCard
                    key={announcement.id}
                    announcement={announcement}
                    hasPostageStamp={idx === 0}
                    onEdit={isOwner ? handleOpenEditModal : undefined}
                    onDelete={isOwner ? handleDelete : undefined}
                    onTogglePin={isOwner ? handleTogglePin : undefined}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Regular Announcements Feed */}
          {regularAnnouncements.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Calendar size={16} className="text-archive-cyan" />
                <h2 className="text-sm sm:text-base font-bold text-archive-paper uppercase tracking-wider">
                  {isAr ? 'آخر الإعلانات' : 'Recent Announcements'}
                </h2>
                <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-archive-cyan/15 text-archive-cyan border border-archive-cyan/30">
                  {regularAnnouncements.length}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {regularAnnouncements.map((announcement, idx) => (
                  <AnnouncementCard
                    key={announcement.id}
                    announcement={announcement}
                    hasPostageStamp={pinnedAnnouncements.length === 0 && idx === 0}
                    onEdit={isOwner ? handleOpenEditModal : undefined}
                    onDelete={isOwner ? handleDelete : undefined}
                    onTogglePin={isOwner ? handleTogglePin : undefined}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Owner Create / Edit Modal */}
      {isOwner && (
        <AnnouncementModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onSubmit={handleModalSubmit}
          initialData={editingAnnouncement}
          mode={modalMode}
        />
      )}
    </div>
  );
};
