import React, { useState, useMemo, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useStory } from '../../src/context/StoryContext';
import { useDecks } from '../../src/context/DeckContext';
import { useCards } from '../../src/context/CardContext';
import { useAuth } from '../../src/context/AuthContext';
import { useLanguage } from '../../src/context/LanguageContext';
import { StoryBattleDefinition, StoryChapterDefinition, BattleDifficulty } from '../types/story';
import { CollectibleCardData } from '../types/cards';
import { StoryChapterFolderTabs } from '../components/story/StoryChapterFolderTabs';
import { CinematicStoryMap } from '../components/story/CinematicStoryMap';
import { VsScreenModal } from '../components/story/VsScreenModal';
import { BattleArena } from '../components/story/BattleArena';
import { StoryBattleEditorModal } from '../components/story/StoryBattleEditorModal';
import { StoryChapterEditorModal } from '../components/story/StoryChapterEditorModal';
import { FALLBACK_STARTER_CARDS } from '../utils/battleEngine';
import { Shield, Crown, Settings2, Plus, Sparkles, ChevronDown } from 'lucide-react';

export const StoryMode: React.FC = () => {
  const { 
    chapters, 
    isChapterUnlocked,
    isBattleUnlocked, 
    isBattleCompleted, 
    hasClaimedFirstClear, 
    completeBattle,
    saveBattle,
    deleteBattle,
    saveChapter,
    deleteChapter
  } = useStory();
  const { activeDeck, activeDeckCards } = useDecks();
  const { catalog } = useCards();
  const { isOwner } = useAuth();
  const { language } = useLanguage();
  const isAr = language === 'ar';

  // Combat Execution State
  const [activeBattleForCombat, setActiveBattleForCombat] = useState<StoryBattleDefinition | null>(null);
  const [battlePhase, setBattlePhase] = useState<'IDLE' | 'VS_SCREEN' | 'ARENA'>('IDLE');

  // Chapter Navigation State (Auto-syncs to newest unlocked fight on mount and data updates)
  const [selectedChapterId, setSelectedChapterId] = useState<string>('chapter_1');
  const [selectedBattleId, setSelectedBattleId] = useState<string | null>(null);
  const [userInteractedWithBattle, setUserInteractedWithBattle] = useState(false);

  // Calculate newest unlocked fight across all chapters (furthest linear progression node)
  const newestUnlockedProgression = useMemo(() => {
    let latestBattle: StoryBattleDefinition | null = null;
    let latestChapterId = chapters[0]?.id || 'chapter_1';

    for (const ch of chapters) {
      for (let idx = 0; idx < ch.battles.length; idx++) {
        const b = ch.battles[idx];
        const isPrevWon = idx === 0 || (ch.battles[idx - 1] && isBattleCompleted(ch.battles[idx - 1].id));
        if ((idx === 0 || isPrevWon) && isBattleUnlocked(b.id)) {
          latestBattle = b;
          latestChapterId = ch.id;
        }
      }
    }

    // Prefer the newest unlocked fight that is still uncompleted
    for (const ch of chapters) {
      for (let idx = 0; idx < ch.battles.length; idx++) {
        const b = ch.battles[idx];
        const isPrevWon = idx === 0 || (ch.battles[idx - 1] && isBattleCompleted(ch.battles[idx - 1].id));
        if ((idx === 0 || isPrevWon) && isBattleUnlocked(b.id) && !isBattleCompleted(b.id)) {
          return { battle: b, chapterId: ch.id };
        }
      }
    }

    return {
      battle: latestBattle || chapters[0]?.battles[0] || null,
      chapterId: latestChapterId
    };
  }, [chapters, isBattleUnlocked, isBattleCompleted]);

  // When entering story mode or when progress loads, auto-sync to newest fight unlocked
  useEffect(() => {
    if (!userInteractedWithBattle && newestUnlockedProgression.battle) {
      setSelectedChapterId(newestUnlockedProgression.chapterId);
      setSelectedBattleId(newestUnlockedProgression.battle.id);
    }
  }, [userInteractedWithBattle, newestUnlockedProgression]);

  // Owner Management Modal State
  const [isChapterModalOpen, setIsChapterModalOpen] = useState(false);
  const [chapterToEdit, setChapterToEdit] = useState<StoryChapterDefinition | null>(null);
  const [isBattleModalOpen, setIsBattleModalOpen] = useState(false);
  const [battleToEdit, setBattleToEdit] = useState<StoryBattleDefinition | null>(null);
  const [showAdminMenu, setShowAdminMenu] = useState(false);

  // Active Chapter & Battles
  const currentChapter = useMemo(() => {
    return chapters.find(c => c.id === selectedChapterId) || chapters[0];
  }, [chapters, selectedChapterId]);

  const currentBattles = useMemo(() => {
    return currentChapter?.battles || [];
  }, [currentChapter]);

  // When active chapter changes or battles update, auto-sync selected battle to the newest unlocked fight in this chapter
  useEffect(() => {
    if (!currentBattles || currentBattles.length === 0) return;
    const battleExistsInChapter = currentBattles.some(b => b.id === selectedBattleId);
    if (!battleExistsInChapter) {
      const unlockedList = currentBattles.filter((b, idx) => {
        const isPrevWon = idx === 0 || (currentBattles[idx - 1] && isBattleCompleted(currentBattles[idx - 1].id));
        return (idx === 0 || isPrevWon) && isBattleUnlocked(b.id);
      });
      const uncompleted = unlockedList.filter(b => !isBattleCompleted(b.id));
      const target = uncompleted[uncompleted.length - 1] || unlockedList[unlockedList.length - 1] || currentBattles[0];
      if (target) {
        setSelectedBattleId(target.id);
      }
    }
  }, [selectedChapterId, currentBattles, isBattleUnlocked, isBattleCompleted, selectedBattleId]);

  // Overall Progression Stats
  const completedCount = currentBattles.filter(b => isBattleCompleted(b.id)).length;
  const totalCount = currentBattles.length;

  // Resolve enemy deck cards from battle definition: strictly return the chosen squad (if less than 4, show only less than 4)
  const getEnemyCards = (cardIds?: string[], battle?: StoryBattleDefinition): CollectibleCardData[] => {
    // 1. Direct enemyCards attached to battle definition
    if (battle?.enemyCards && Array.isArray(battle.enemyCards) && battle.enemyCards.length > 0) {
      return battle.enemyCards.slice(0, 4);
    }
    // 2. Map cardIds from catalog
    const resolved = (cardIds || [])
      .map(id => catalog.find(c => c.id === id))
      .filter((c): c is CollectibleCardData => Boolean(c));
    
    // If cards were chosen, return strictly those cards (do not pad or add anything!)
    if (resolved.length > 0) {
      return resolved.slice(0, 4);
    }
    
    // Only if completely empty, return the minimal fallback
    return FALLBACK_STARTER_CARDS.slice(0, 2);
  };

  // Safe player cards for combat (fallback to catalog or starter cards)
  const combatPlayerCards = useMemo(() => {
    if (activeDeckCards.length > 0) return activeDeckCards;
    if (catalog.length > 0) return catalog.slice(0, 4);
    return FALLBACK_STARTER_CARDS;
  }, [activeDeckCards, catalog]);

  // Launch battle: Opens VS confirmation screen with both decks and overalls
  const handleStartBattle = (battle: StoryBattleDefinition) => {
    setActiveBattleForCombat(battle);
    setBattlePhase('VS_SCREEN');
  };

  const handleStartArena = () => {
    setBattlePhase('ARENA');
  };

  const handleExitBattle = () => {
    setBattlePhase('IDLE');
    setActiveBattleForCombat(null);
  };

  // Owner quick fight type update (Normal vs Boss vs Chapter Finale)
  const handleQuickUpdateFightType = async (battle: StoryBattleDefinition, fightType: 'NORMAL' | 'BOSS' | 'CHAPTER_FINALE') => {
    const updatedBattle: StoryBattleDefinition = {
      ...battle,
      fightType,
      difficulty: (fightType === 'CHAPTER_FINALE' ? 'CHAPTER_FINALE' : fightType === 'BOSS' ? 'BOSS' : 'NORMAL') as BattleDifficulty,
      isChapterFinale: fightType === 'CHAPTER_FINALE'
    };
    await saveBattle(updatedBattle);
  };

  // Open battle editor modal for specific battle
  const handleEditBattle = (battle: StoryBattleDefinition) => {
    setBattleToEdit(battle);
    setIsBattleModalOpen(true);
  };

  // Delete current chapter handler
  const handleDeleteCurrentChapter = async () => {
    if (!currentChapter) return;
    const confirmDelete = window.confirm(
      isAr 
        ? `هل أنت متأكد من حذف فصل "${currentChapter.title}"؟` 
        : `Are you sure you want to delete chapter "${currentChapter.title}"?`
    );
    if (!confirmDelete) return;

    const res = await deleteChapter(currentChapter.id);
    if (res.success) {
      const remaining = chapters.filter(c => c.id !== currentChapter.id);
      if (remaining.length > 0) {
        setSelectedChapterId(remaining[0].id);
      }
    }
  };

  return (
    <div 
      className="min-h-screen pt-24 pb-32 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto w-full box-border select-none relative z-10"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* ========================================================================= */}
      {/* TOP HEADER: Active Deck & Discreet Owner Admin                            */}
      {/* ========================================================================= */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4 mb-6">
        <div>
          <span className="text-[10px] font-mono tracking-widest text-[#5eead4] uppercase font-bold">
            {isAr ? 'حملة القصة التكتيكية' : 'TACTICAL STORY CAMPAIGN'}
          </span>
          <h1 className="text-xl sm:text-2xl font-black text-white font-sans tracking-tight">
            {isAr ? 'سجلات الملاذ القديم' : 'Sanctuary Chronicles'}
          </h1>
        </div>

        {/* Right Header: Active Deck & Discreet Owner Admin */}
        <div className="flex items-center gap-3 flex-wrap">
          {/* Active Combat Deck Mini Status */}
          <Link
            to="/decks"
            className="flex items-center gap-2.5 px-3.5 py-1.5 rounded-2xl bg-white/[0.04] border border-white/10 hover:border-white/20 transition-all text-xs font-mono text-slate-300"
          >
            <Shield size={14} className="text-[#5eead4]" />
            <span className="truncate max-w-[140px] font-sans font-bold text-white">
              {activeDeck ? activeDeck.name : (isAr ? 'اختر تشكيلة' : 'Select Deck')}
            </span>
            {activeDeck && (
              <span className="text-[10px] text-amber-400 font-mono">
                PWR {activeDeck.power}
              </span>
            )}
          </Link>

          {/* Discreet Owner Controls */}
          {isOwner && (
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowAdminMenu(!showAdminMenu)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs font-mono font-bold transition-all cursor-pointer"
              >
                <Crown size={13} />
                <span>{isAr ? 'إدارة المالك' : 'Admin'}</span>
                <ChevronDown size={12} className={showAdminMenu ? 'rotate-180 transition-transform' : 'transition-transform'} />
              </button>

              {showAdminMenu && (
                <div className="absolute right-0 sm:right-0 mt-2 w-52 bg-[#051114] border border-teal-500/30 rounded-2xl shadow-2xl p-2 z-30 space-y-1">
                  <button
                    type="button"
                    onClick={() => {
                      setShowAdminMenu(false);
                      setBattleToEdit(null);
                      setIsBattleModalOpen(true);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-mono text-slate-200 hover:bg-teal-500/20 hover:text-white transition-colors flex items-center gap-2"
                  >
                    <Plus size={13} className="text-[#5eead4]" />
                    <span>{isAr ? 'إضافة معركة جديدة' : 'Add Story Fight'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setShowAdminMenu(false);
                      setChapterToEdit(currentChapter);
                      setIsChapterModalOpen(true);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-mono text-slate-200 hover:bg-teal-500/20 hover:text-white transition-colors flex items-center gap-2"
                  >
                    <Settings2 size={13} className="text-[#5eead4]" />
                    <span>{isAr ? 'تخصيص الفصل الحالي' : 'Customize Chapter'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setShowAdminMenu(false);
                      setChapterToEdit(null);
                      setIsChapterModalOpen(true);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs font-mono text-slate-200 hover:bg-teal-500/20 hover:text-white transition-colors flex items-center gap-2"
                  >
                    <Plus size={13} className="text-[#5eead4]" />
                    <span>{isAr ? 'إنشاء فصل جديد' : 'New Chapter'}</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. TACTICAL CHAPTER FOLDER STYLE VIEWER                                   */}
      {/* Folder tabs representing every chapter, opening into dossier interior     */}
      {/* ========================================================================= */}
      <StoryChapterFolderTabs
        chapters={chapters}
        activeChapterId={currentChapter?.id || 'chapter_1'}
        onSelectChapter={(chId) => setSelectedChapterId(chId)}
        isBattleCompleted={isBattleCompleted}
        isChapterUnlocked={isChapterUnlocked}
        isOwner={isOwner}
        onNewChapter={() => {
          setChapterToEdit(null);
          setIsChapterModalOpen(true);
        }}
        onEditCurrentChapter={() => {
          setChapterToEdit(currentChapter);
          setIsChapterModalOpen(true);
        }}
        onDeleteCurrentChapter={chapters.length > 1 ? handleDeleteCurrentChapter : undefined}
        onAddBattleToCurrentChapter={() => {
          setBattleToEdit(null);
          setIsBattleModalOpen(true);
        }}
        isAr={isAr}
      />

      {/* ========================================================================= */}
      {/* 2. CINEMATIC VERTICAL 4-NODE ALTERNATING PROGRESSION MAP                 */}
      {/* With radial gradient mask fog-of-war and animated SVG connecting path    */}
      {/* ========================================================================= */}
      <CinematicStoryMap
        battles={currentBattles}
        isBattleUnlocked={isBattleUnlocked}
        isBattleCompleted={isBattleCompleted}
        hasClaimedFirstClear={hasClaimedFirstClear}
        getEnemyCards={getEnemyCards}
        onStartBattle={handleStartBattle}
        isAr={isAr}
        isOwner={isOwner}
        onEditBattle={handleEditBattle}
        onQuickUpdateFightType={handleQuickUpdateFightType}
        accentColor={currentChapter?.accentColor || '#2dd4bf'}
        selectedBattleId={selectedBattleId}
        onSelectBattle={(bId) => {
          setUserInteractedWithBattle(true);
          setSelectedBattleId(bId);
        }}
      />

      {/* ========================================================================= */}
      {/* 3. COMBAT MODALS                                                          */}
      {/* ========================================================================= */}

      {/* Dramatic VS Confirmation Screen */}
      {activeBattleForCombat && battlePhase === 'VS_SCREEN' && (
        <VsScreenModal
          isOpen={true}
          battle={activeBattleForCombat}
          activeDeck={activeDeck}
          playerCards={combatPlayerCards}
          enemyCards={getEnemyCards(activeBattleForCombat.enemyDeckCardIds, activeBattleForCombat)}
          onProceed={handleStartArena}
          onCancel={handleExitBattle}
          onComplete={handleStartArena}
        />
      )}

      {/* Live Tactical Combat Arena */}
      {activeBattleForCombat && battlePhase === 'ARENA' && (
        <BattleArena
          battle={activeBattleForCombat}
          activeDeck={activeDeck}
          playerCards={combatPlayerCards}
          playerDeckCards={combatPlayerCards}
          enemyCards={getEnemyCards(activeBattleForCombat.enemyDeckCardIds, activeBattleForCombat)}
          enemyDeckCards={getEnemyCards(activeBattleForCombat.enemyDeckCardIds, activeBattleForCombat)}
          onExit={handleExitBattle}
          onClose={handleExitBattle}
          onComplete={async (outcome) => {
            return await completeBattle(activeBattleForCombat.id, outcome);
          }}
        />
      )}

      {/* Owner Chapter Modal */}
      <StoryChapterEditorModal
        isOpen={isChapterModalOpen}
        chapterToEdit={chapterToEdit}
        onClose={() => {
          setIsChapterModalOpen(false);
          setChapterToEdit(null);
        }}
        onSave={saveChapter}
        onDelete={deleteChapter}
        canDelete={chapters.length > 1}
      />

      {/* Owner Story Battle Modal */}
      <StoryBattleEditorModal
        isOpen={isBattleModalOpen}
        battleToEdit={battleToEdit}
        existingBattles={currentBattles}
        chapters={chapters}
        currentChapterId={selectedChapterId}
        onClose={() => {
          setIsBattleModalOpen(false);
          setBattleToEdit(null);
        }}
        onSave={saveBattle}
      />
    </div>
  );
};

export default StoryMode;
