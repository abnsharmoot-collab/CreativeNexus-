import React, { useState, useEffect } from 'react';
import { 
  Settings as SettingsIcon, 
  Palette, 
  Volume2, 
  VolumeX, 
  Volume1, 
  Languages, 
  Sparkles, 
  Check, 
  Lock, 
  Gamepad2, 
  Sliders, 
  ShieldCheck, 
  Activity,
  Zap,
  RotateCcw,
  Crown,
  Edit3
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useEasterEggs } from '../context/EasterEggContext';
import { useAuth } from '../context/AuthContext';
import { useMainMenuBackground } from '../context/MainMenuBackgroundContext';
import { useSiteLogo } from '../context/SiteLogoContext';
import { OwnerLogoCustomizerModal } from '../components/organisms/OwnerLogoCustomizerModal';
import { DEFAULT_BIO, LOCAL_STORAGE_KEY } from '../components/home/CreativeNexusBio';
import { easterEggSound } from '../utils/easterEggAudio';

export const Settings: React.FC = () => {
  const { language, setLanguage } = useLanguage();
  const isAr = language === 'ar';
  const { isAuthenticated, isOwner, role, user } = useAuth();
  const isOwnerUser = Boolean(
    isOwner || 
    role === 'OWNER' || 
    user?.isOwner || 
    user?.isGuildOwner || 
    user?.discordId === '871043296280076308'
  );
  const { openEditModal: openMainMenuBgModal, background: menuBackground } = useMainMenuBackground();
  const { logoSettings } = useSiteLogo();
  const [isLogoModalOpen, setIsLogoModalOpen] = useState(false);

  const { 
    activeTheme, 
    setThemePreference, 
    iraqiThemeUnlocked, 
    flagsCount, 
    collectedFlagIds,
    finalRewardGranted,
    saddamMissionCompleted,
    saddamGameGoalReached, 
    saddamBestTime 
  } = useEasterEggs();

  // Audio State
  const [volume, setVolumeState] = useState<number>(() => easterEggSound.getVolume());
  const [muted, setMutedState] = useState<boolean>(() => easterEggSound.isMuted());
  const [sfxEnabled, setSfxState] = useState<boolean>(() => easterEggSound.isSfxEnabled());

  // Performance / Motion
  const [reducedMotion, setReducedMotion] = useState<boolean>(() => {
    try {
      return localStorage.getItem('creatine_reduced_motion') === 'true';
    } catch {
      return false;
    }
  });

  // Owner Creative Nexus Bio State
  const [bioAr, setBioAr] = useState<string>(() => {
    try {
      const cached = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (cached) return JSON.parse(cached).bioAr || DEFAULT_BIO.bioAr;
    } catch {}
    return DEFAULT_BIO.bioAr;
  });
  const [bioEn, setBioEn] = useState<string>(() => {
    try {
      const cached = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (cached) return JSON.parse(cached).bioEn || DEFAULT_BIO.bioEn;
    } catch {}
    return DEFAULT_BIO.bioEn;
  });
  const [isSavingBio, setIsSavingBio] = useState(false);
  const [bioFeedback, setBioFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Load bio on mount
  useEffect(() => {
    const fetchBio = async () => {
      try {
        const res = await fetch('/api/settings/creative-nexus-bio');
        if (res.ok) {
          const data = await res.json();
          if (data.bio) {
            if (data.bio.bioAr) setBioAr(data.bio.bioAr);
            if (data.bio.bioEn) setBioEn(data.bio.bioEn);
          }
        }
      } catch (err) {
        console.warn('Could not fetch bio in settings:', err);
      }
    };
    fetchBio();
  }, []);

  const handleSaveBio = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingBio(true);
    setBioFeedback(null);
    try {
      const res = await fetch('/api/settings/creative-nexus-bio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          bioAr: bioAr.trim() || DEFAULT_BIO.bioAr,
          bioEn: bioEn.trim() || DEFAULT_BIO.bioEn,
        }),
      });

      if (!res.ok) {
        throw new Error('Failed to update bio');
      }

      const data = await res.json();
      const updated = data.bio || { bioAr, bioEn };
      try {
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));
      } catch {}

      setBioFeedback({
        type: 'success',
        message: isAr ? 'تم حفظ وتحديث بايو السيرفر بنجاح!' : 'Server bio updated successfully!'
      });
      setTimeout(() => setBioFeedback(null), 3000);
    } catch (err: any) {
      setBioFeedback({
        type: 'error',
        message: err.message || (isAr ? 'فشل حفظ البايو، يرجى المحاولة لاحقاً.' : 'Failed to save bio.')
      });
    } finally {
      setIsSavingBio(false);
    }
  };

  const handleResetBio = () => {
    setBioAr(DEFAULT_BIO.bioAr);
    setBioEn(DEFAULT_BIO.bioEn);
  };

  const handleVolumeChange = (newVal: number) => {
    setVolumeState(newVal);
    easterEggSound.setVolume(newVal);
    if (newVal > 0 && muted) {
      setMutedState(false);
      easterEggSound.setMuted(false);
    }
  };

  const toggleMute = () => {
    const next = !muted;
    setMutedState(next);
    easterEggSound.setMuted(next);
    if (!next && volume === 0) {
      handleVolumeChange(0.5);
    }
  };

  const toggleSfx = () => {
    const next = !sfxEnabled;
    setSfxState(next);
    easterEggSound.setSfxEnabled(next);
  };

  const toggleReducedMotion = () => {
    const next = !reducedMotion;
    setReducedMotion(next);
    try {
      localStorage.setItem('creatine_reduced_motion', next ? 'true' : 'false');
      if (next) {
        document.documentElement.classList.add('reduce-motion');
      } else {
        document.documentElement.classList.remove('reduce-motion');
      }
    } catch {}
  };

  const testAudio = () => {
    easterEggSound.playTestChime();
  };

  const isGameCompleted = saddamGameGoalReached || saddamBestTime >= 120 || iraqiThemeUnlocked;

  return (
    <div className="flex-1 w-full max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Header */}
      <div className="mb-10 pb-6 border-b border-white/10">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shadow-sm">
            <SettingsIcon size={24} />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              {isAr ? 'الإعدادات العامة' : 'Application Settings'}
            </h1>
            <p className="text-sm text-white/50 mt-1">
              {isAr 
                ? 'تخصيص المظهر، التحكم بالصوتيات، تغيير لغة الواجهة، وضبط تجربة المستخدم.' 
                : 'Customize theme appearance, audio output, display language, and experience preferences.'}
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-8">
        {/* 1. Theme Selection */}
        <section className="bg-slate-900/60 border border-white/10 rounded-2xl p-6 backdrop-blur-md">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-teal-500/10 text-teal-400 border border-teal-500/20">
              <Palette size={20} />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">
                {isAr ? 'المظهر والثيم (Theme)' : 'Theme & Appearance'}
              </h2>
              <p className="text-xs text-white/50">
                {isAr ? 'اختر النمط البصري المفضل لديك للتنقل في المنصة' : 'Select your preferred visual style across the platform'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Default Theme Card */}
            <div
              onClick={() => setThemePreference('creative-nexus')}
              className={`relative cursor-pointer rounded-xl p-5 border transition-all duration-200 ${
                activeTheme === 'creative-nexus'
                  ? 'border-cyan-500/80 bg-cyan-500/10 shadow-lg shadow-cyan-500/5'
                  : 'border-white/10 bg-slate-950/40 hover:border-white/20 hover:bg-slate-950/60'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-4 h-4 rounded-full bg-cyan-400 shadow-sm shadow-cyan-400/50" />
                  <span className="font-medium text-white text-base">CREATIVE NEXUS</span>
                </div>
                {activeTheme === 'creative-nexus' && (
                  <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                    <Check size={12} /> {isAr ? 'المفعل حالياً' : 'Active'}
                  </span>
                )}
              </div>
              <p className="text-xs text-white/60 mt-3 leading-relaxed">
                {isAr 
                  ? 'المظهر الافتراضي الكلاسيكي المستوحى من تدرجات السيان والأزرق الداكن.' 
                  : 'Default clean digital aesthetic with deep obsidian and cyan gradients.'}
              </p>
              <div className="mt-4 flex gap-1.5">
                <div className="h-2 w-8 rounded-full bg-[#0a0f18] border border-white/20" />
                <div className="h-2 w-8 rounded-full bg-cyan-500" />
                <div className="h-2 w-8 rounded-full bg-teal-500" />
                <div className="h-2 w-8 rounded-full bg-indigo-500" />
              </div>
            </div>

            {/* Mesopotamian Theme Card */}
            {(() => {
              const hasAllFlags = flagsCount >= 5 || (Array.isArray(collectedFlagIds) && collectedFlagIds.length >= 5);
              const hasSurvivalWin = saddamGameGoalReached || saddamBestTime >= 120 || saddamMissionCompleted;
              const isMissionCompleted = hasAllFlags && hasSurvivalWin;
              const isMesopotamianUnlocked = Boolean(isOwnerUser || iraqiThemeUnlocked || finalRewardGranted || isMissionCompleted);

              return (
                <div
                  onClick={() => {
                    if (isMesopotamianUnlocked) {
                      setThemePreference('kohan-iraqi');
                    }
                  }}
                  className={`relative rounded-xl p-5 border transition-all duration-200 ${
                    !isMesopotamianUnlocked
                      ? 'border-white/10 bg-slate-950/20 opacity-75 cursor-not-allowed'
                      : activeTheme === 'kohan-iraqi'
                      ? 'border-amber-500/80 bg-amber-500/10 shadow-lg shadow-amber-500/5 cursor-pointer'
                      : 'border-white/10 bg-slate-950/40 hover:border-amber-500/40 hover:bg-slate-950/60 cursor-pointer'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-4 h-4 rounded-full bg-amber-400 shadow-sm shadow-amber-400/50" />
                      <span className="font-medium text-white text-base">
                        {isAr ? 'بلاد الرافدين (Mesopotamian)' : 'Mesopotamian Sovereign'}
                      </span>
                    </div>
                    {isMesopotamianUnlocked ? (
                      activeTheme === 'kohan-iraqi' ? (
                        <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          <Check size={12} /> {isAr ? 'المفعل حالياً' : 'Active'}
                        </span>
                      ) : isOwnerUser ? (
                        <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-xs">
                          <Crown size={12} /> {isAr ? 'مفتوح للمالك' : 'Owner Unlocked'}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          {isAr ? 'مفتوح للتبديل' : 'Unlocked'}
                        </span>
                      )
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full bg-slate-800 text-amber-400/80 border border-amber-500/20">
                        <Lock size={12} /> {isAr ? 'مقفل بالتحدي' : 'Locked (Challenge)'}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-white/60 mt-3 leading-relaxed">
                    {isMesopotamianUnlocked
                      ? (isAr 
                          ? 'الثيم الحصري المستوحى من الذهب الإمبراطوري والتراث العراقي. يمكنك التبديل إليه في أي وقت.' 
                          : 'Exclusive imperial theme with rich gold, emerald, and warm parchment highlights. Switch anytime.')
                      : (isAr 
                          ? 'ثيم سري حصري. يتطلب تسجيل الدخول وجمع الأعلام الـ 5 والفوز في لعبة صدام حسين (البقاء لدقيقتين).' 
                          : "Secret exclusive theme. Requires logging in, discovering all 5 hidden flags, and winning Kohan's challenge (survive 2:00 in Saddam Hussein game).")}
                  </p>

                  {/* Challenge Requirements Status for Logged-In Users */}
                  {!isMesopotamianUnlocked && (
                <div className="mt-3.5 pt-3 border-t border-white/5 flex flex-wrap gap-2 text-[11px]">
                  <span className={`px-2 py-0.5 rounded-md border ${
                    flagsCount >= 5 
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                      : 'bg-white/5 text-white/60 border-white/10'
                  }`}>
                    {isAr ? `الأعلام: ${flagsCount} / 5` : `Flags: ${flagsCount} / 5`}
                  </span>
                  <span className={`px-2 py-0.5 rounded-md border ${
                    saddamGameGoalReached || saddamBestTime >= 120
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                      : 'bg-white/5 text-white/60 border-white/10'
                  }`}>
                    {isAr 
                      ? (saddamGameGoalReached || saddamBestTime >= 120 ? 'لعبة صدام: مكتملة (2:00)' : `لعبة صدام: ${saddamBestTime}ث / 120ث`)
                      : (saddamGameGoalReached || saddamBestTime >= 120 ? 'Saddam Game: Won (2:00)' : `Saddam Game: ${saddamBestTime}s / 120s`)}
                  </span>
                </div>
              )}

                <div className="mt-4 flex gap-1.5">
                  <div className="h-2 w-8 rounded-full bg-[#16120b] border border-amber-500/30" />
                  <div className="h-2 w-8 rounded-full bg-amber-500" />
                  <div className="h-2 w-8 rounded-full bg-emerald-600" />
                  <div className="h-2 w-8 rounded-full bg-rose-600" />
                </div>
              </div>
            );
          })()}
          </div>
        </section>

        {/* 2. Audio & Sound Controls */}
        <section className="bg-slate-900/60 border border-white/10 rounded-2xl p-6 backdrop-blur-md">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                {muted || volume === 0 ? <VolumeX size={20} /> : volume < 0.5 ? <Volume1 size={20} /> : <Volume2 size={20} />}
              </div>
              <div>
                <h2 className="text-lg font-semibold text-white">
                  {isAr ? 'التحكم بالصوتيات (Audio)' : 'Sound & Audio'}
                </h2>
                <p className="text-xs text-white/50">
                  {isAr ? 'ضبط مستوى صوت المؤثرات، كتم الصوت، واختبار النغمات' : 'Control synthesizer volume, mute state, and test sounds'}
                </p>
              </div>
            </div>

            <button
              onClick={testAudio}
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/30 transition-colors"
            >
              <Sparkles size={14} />
              {isAr ? 'تجربة الصوت' : 'Test Sound'}
            </button>
          </div>

          <div className="space-y-6">
            {/* Master Volume Slider */}
            <div>
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-white/70 font-medium">
                  {isAr ? 'مستوى الصوت العام' : 'Master Volume'}
                </span>
                <span className="text-cyan-400 font-mono text-xs">
                  {muted ? (isAr ? 'مكتوم' : 'Muted') : `${Math.round(volume * 100)}%`}
                </span>
              </div>
              <div className="flex items-center gap-4">
                <button
                  onClick={toggleMute}
                  className={`p-2 rounded-lg border transition-colors ${
                    muted 
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/40' 
                      : 'bg-white/5 text-white/60 hover:text-white border-white/10'
                  }`}
                  title={muted ? (isAr ? 'إلغاء الكتم' : 'Unmute') : (isAr ? 'كتم الصوت' : 'Mute')}
                >
                  {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={muted ? 0 : volume}
                  onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                  className="flex-1 h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                />
              </div>
            </div>

            {/* SFX Toggle */}
            <div className="flex items-center justify-between pt-4 border-t border-white/5">
              <div>
                <span className="text-sm font-medium text-white block">
                  {isAr ? 'المؤثرات الصوتية التفاعلية' : 'Sound Effects (SFX)'}
                </span>
                <span className="text-xs text-white/50">
                  {isAr ? 'تشغيل نغمات الاكتشافات والألعاب والجوائز' : 'Play interactive chimes for discoveries and games'}
                </span>
              </div>
              <button
                onClick={toggleSfx}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  sfxEnabled ? 'bg-cyan-500' : 'bg-slate-800'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    sfxEnabled ? (isAr ? '-translate-x-6' : 'translate-x-6') : (isAr ? '-translate-x-1' : 'translate-x-1')
                  }`}
                />
              </button>
            </div>
          </div>
        </section>

        {/* 3. Language Selection */}
        <section className="bg-slate-900/60 border border-white/10 rounded-2xl p-6 backdrop-blur-md">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Languages size={20} />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">
                {isAr ? 'اللغة والواجهة (Language)' : 'Language & Localization'}
              </h2>
              <p className="text-xs text-white/50">
                {isAr ? 'تبديل لغة الموقع مع ضبط تلقائي للاتجاه (RTL / LTR)' : 'Switch interface language with full RTL / LTR layout mirroring'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Arabic */}
            <button
              onClick={() => setLanguage('ar')}
              className={`flex items-center justify-between p-4 rounded-xl border text-right transition-all ${
                isAr
                  ? 'border-emerald-500/80 bg-emerald-500/10 text-white'
                  : 'border-white/10 bg-slate-950/40 text-white/70 hover:border-white/20 hover:text-white'
              }`}
            >
              <div>
                <div className="font-semibold text-base">العربية (Arabic)</div>
                <div className="text-xs text-white/50 mt-0.5">اتجاه اليمين إلى اليسار (RTL)</div>
              </div>
              {isAr && (
                <div className="p-1 rounded-full bg-emerald-500/20 text-emerald-400">
                  <Check size={16} />
                </div>
              )}
            </button>

            {/* English */}
            <button
              onClick={() => setLanguage('en')}
              className={`flex items-center justify-between p-4 rounded-xl border text-left transition-all ${
                !isAr
                  ? 'border-emerald-500/80 bg-emerald-500/10 text-white'
                  : 'border-white/10 bg-slate-950/40 text-white/70 hover:border-white/20 hover:text-white'
              }`}
            >
              <div>
                <div className="font-semibold text-base">English</div>
                <div className="text-xs text-white/50 mt-0.5">Left-to-Right layout (LTR)</div>
              </div>
              {!isAr && (
                <div className="p-1 rounded-full bg-emerald-500/20 text-emerald-400">
                  <Check size={16} />
                </div>
              )}
            </button>
          </div>
        </section>

        {/* 4. Experience & Performance */}
        <section className="bg-slate-900/60 border border-white/10 rounded-2xl p-6 backdrop-blur-md">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <Zap size={20} />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">
                {isAr ? 'الأداء والمؤثرات (Performance)' : 'Experience & Performance'}
              </h2>
              <p className="text-xs text-white/50">
                {isAr ? 'تخصيص الأداء وسرعة التصفح وتخفيف الرسوم المتحركة' : 'Optimize performance and minimize motion on low-powered devices'}
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm font-medium text-white block">
                  {isAr ? 'وضع توفير الحركة (Reduced Motion)' : 'Reduced Motion Mode'}
                </span>
                <span className="text-xs text-white/50">
                  {isAr ? 'إيقاف الخلفيات المتحركة الثقيلة والانتقالات المعقدة' : 'Disables heavy animated background glows for smoother rendering'}
                </span>
              </div>
              <button
                onClick={toggleReducedMotion}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  reducedMotion ? 'bg-purple-500' : 'bg-slate-800'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    reducedMotion ? (isAr ? '-translate-x-6' : 'translate-x-6') : (isAr ? '-translate-x-1' : 'translate-x-1')
                  }`}
                />
              </button>
            </div>
          </div>
        </section>

        {/* 5. Secret Discovery Status (سجل اللعبة السرية) - Only visible for authenticated users */}
        {isAuthenticated && (
          <section className="bg-slate-900/60 border border-white/10 rounded-2xl p-6 backdrop-blur-md">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <Gamepad2 size={20} />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-white">
                  {isAr ? 'اللعبة السرية (Secret Quest)' : 'Secret Discovery'}
                </h2>
                <p className="text-xs text-white/50">
                  {isAr ? 'حالة التحدي السري في الموقع' : 'Status of the secret challenge on the site'}
                </p>
              </div>
            </div>

            <div className="rounded-xl border border-white/10 bg-slate-950/40 p-4">
              {isGameCompleted ? (
                <div className="flex items-center gap-3 text-emerald-400">
                  <ShieldCheck size={22} className="shrink-0" />
                  <div>
                    <div className="text-sm font-semibold text-white">
                      {isAr ? 'تم إكمال اللعبة السرية بنجاح!' : 'Secret Game Completed!'}
                    </div>
                    <div className="text-xs text-white/60 mt-0.5">
                      {isAr 
                        ? 'لقد فتحت ثيم بلاد الرافدين بنجاح، ويمكنك اختياره دائماً من قسم المظهر أعلاه.' 
                        : 'You have conquered the secret challenge and unlocked the Mesopotamian theme.'}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-3 text-amber-400">
                  <Gamepad2 size={22} className="shrink-0" />
                  <div>
                    <div className="text-sm font-semibold text-white">
                      {isAr 
                        ? 'في لعبة سرية موجودة في الموقع، دور عليها!' 
                        : 'There is a secret game on the site, search for it!'}
                    </div>
                    <div className="text-xs text-white/60 mt-0.5">
                      {isAr 
                        ? 'استكشف زوايا السيرفر والموقع للعثور على المهمة السرية وفتح الثيم الخاص.' 
                        : 'Explore hidden corners of the community to discover the secret game and claim the theme.'}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </section>
        )}

        {/* 6. Owner Studio & Customization Hub (Owner Only) */}
        {isOwnerUser && (
          <div className="space-y-6 pt-6 border-t border-amber-500/20">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <Crown size={20} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-semibold text-white">
                    {isAr ? 'غرفة تخصيص المالك (Owner Studio)' : 'Owner Customization Room'}
                  </h2>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                    {isAr ? 'حصري للمالك' : 'Owner Exclusive'}
                  </span>
                </div>
                <p className="text-xs text-white/50">
                  {isAr 
                    ? 'مركز التحكم الشامل لتخصيص القائمة الرئيسية، الشعار، وهوية السيرفر والموقع.' 
                    : 'Central hub for customizing website logo, emblem, brand assets, and main menu background.'}
                </p>
              </div>
            </div>

            {/* Owner Website Logo & Brand Studio */}
            <section className="bg-gradient-to-r from-amber-950/40 via-slate-900/60 to-yellow-950/30 border border-amber-500/30 rounded-2xl p-6 backdrop-blur-md shadow-lg">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-300 border border-amber-500/30">
                    <Palette size={22} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-white font-cairo">
                        {isAr ? 'شعار وهوية الموقع (Website Brand & Logo)' : 'Website Brand & Logo'}
                      </h3>
                    </div>
                    <p className="text-xs text-slate-300 font-cairo mt-1">
                      {isAr 
                        ? 'تخصيص اسم الموقع، الشعار الرمزي أو رفع صورة الشعار، والألوان وتنسيقات القائمة العلوية' 
                        : 'Customize site title, 3D vector emblem or upload custom logo image, and color themes'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <button
                    type="button"
                    onClick={() => setIsLogoModalOpen(true)}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 font-cairo font-bold text-xs shadow-md shadow-amber-500/20 transition-all flex items-center gap-2 cursor-pointer"
                  >
                    <Palette size={15} />
                    <span>{isAr ? 'تخصيص الشعار' : 'Customize Logo'}</span>
                  </button>
                </div>
              </div>
            </section>

            {/* Owner Main Menu Background Configuration */}
            <section className="bg-gradient-to-r from-cyan-950/40 via-slate-900/60 to-teal-950/30 border border-cyan-500/30 rounded-2xl p-6 backdrop-blur-md shadow-lg">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                    <Sliders size={22} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-white font-cairo">
                        {isAr ? 'خلفية القائمة الرئيسية (Main Menu Background)' : 'Main Menu Background'}
                      </h3>
                    </div>
                    <p className="text-xs text-slate-300 font-cairo mt-1">
                      {isAr 
                        ? 'يمكنك وضع صورة خلفية في القائمة الرئيسية مع التحكم في مستوى الضبابية (Blur) والظهور (Visibility)' 
                        : 'Upload a custom background photo for the main menu with full blur & opacity controls'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  {menuBackground?.imageUrl && (
                    <span className="text-xs font-mono text-cyan-400 bg-cyan-950/70 px-2.5 py-1 rounded-lg border border-cyan-500/30">
                      Blur: {menuBackground.blur}px · {Math.round((menuBackground.opacity || 0.6) * 100)}%
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={openMainMenuBgModal}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-teal-400 to-cyan-500 text-slate-950 font-cairo font-bold text-xs hover:from-teal-300 hover:to-cyan-400 shadow-md shadow-cyan-500/20 transition-all flex items-center gap-2 cursor-pointer"
                  >
                    <Sliders size={15} />
                    <span>{isAr ? 'تخصيص الخلفية' : 'Configure Background'}</span>
                  </button>
                </div>
              </div>
            </section>

            {/* Owner Creative Nexus Bio Configuration */}
            <section className="bg-gradient-to-r from-emerald-950/40 via-slate-900/60 to-teal-950/30 border border-emerald-500/30 rounded-2xl p-6 backdrop-blur-md shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                  <Edit3 size={22} />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white font-cairo">
                    {isAr ? 'بايو ووصف السيرفر (CREATIVE NEXUS Bio)' : 'Server Headline Bio'}
                  </h3>
                  <p className="text-xs text-slate-300 font-cairo mt-0.5">
                    {isAr 
                      ? 'يظهر هذا النص التعريفي تحت اسم السيرفر في الصفحة الرئيسية لجميع الزوار' 
                      : 'This bio appears under the Creative Nexus title on the main menu for all visitors'}
                  </p>
                </div>
              </div>

              <form onSubmit={handleSaveBio} className="space-y-4 mt-4">
                <div>
                  <label className="block text-xs font-mono text-emerald-400 font-bold mb-1.5">
                    {isAr ? 'النص بالعربية (Arabic Bio):' : 'Arabic Bio:'}
                  </label>
                  <textarea
                    rows={3}
                    value={bioAr}
                    onChange={(e) => setBioAr(e.target.value)}
                    dir="rtl"
                    placeholder="اكتب بايو السيرفر بالعربية..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#031413] border border-emerald-500/20 focus:border-emerald-400 text-sm text-white placeholder-slate-500 outline-none focus:ring-1 focus:ring-emerald-400/40"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono text-emerald-400 font-bold mb-1.5">
                    {isAr ? 'النص بالإنجليزية (English Bio):' : 'English Bio:'}
                  </label>
                  <textarea
                    rows={3}
                    value={bioEn}
                    onChange={(e) => setBioEn(e.target.value)}
                    dir="ltr"
                    placeholder="Enter English bio text..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#031413] border border-emerald-500/20 focus:border-emerald-400 text-sm text-white placeholder-slate-500 outline-none focus:ring-1 focus:ring-emerald-400/40"
                  />
                </div>

                {/* Live Preview Box */}
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-white/10">
                  <div className="text-[10px] font-mono text-white/50 uppercase tracking-wider mb-1">
                    {isAr ? 'معاينة مباشرة في الصفحة الرئيسية:' : 'Live Main Menu Preview:'}
                  </div>
                  <p className="text-sm font-cairo text-[#8db8b1] leading-relaxed">
                    {isAr ? (bioAr || DEFAULT_BIO.bioAr) : (bioEn || DEFAULT_BIO.bioEn)}
                  </p>
                </div>

                {bioFeedback && (
                  <div className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-2 ${
                    bioFeedback.type === 'success'
                      ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                      : 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                  }`}>
                    {bioFeedback.type === 'success' ? <Check size={14} /> : <Lock size={14} />}
                    <span>{bioFeedback.message}</span>
                  </div>
                )}

                <div className="flex items-center justify-between pt-1">
                  <button
                    type="button"
                    onClick={handleResetBio}
                    className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white px-2 py-1 transition-colors cursor-pointer"
                  >
                    <RotateCcw size={13} />
                    <span>{isAr ? 'استعادة الافتراضي' : 'Reset Default'}</span>
                  </button>

                  <button
                    type="submit"
                    disabled={isSavingBio}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-500 text-slate-950 font-cairo font-bold text-xs hover:from-emerald-300 hover:to-teal-400 shadow-md shadow-emerald-500/20 transition-all flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                  >
                    {isSavingBio ? (
                      <span>{isAr ? 'جارِ الحفظ...' : 'Saving...'}</span>
                    ) : (
                      <>
                        <Check size={14} />
                        <span>{isAr ? 'حفظ البايو' : 'Save Bio'}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </section>
          </div>
        )}
      </div>

      {/* Owner Website Logo Customizer Modal */}
      <OwnerLogoCustomizerModal
        isOpen={isLogoModalOpen}
        onClose={() => setIsLogoModalOpen(false)}
      />
    </div>
  );
};
