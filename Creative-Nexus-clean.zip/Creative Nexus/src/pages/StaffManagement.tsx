import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';
import { 
  Plus, Shield, Users, RefreshCw, CheckCircle2, 
  AlertCircle, Sparkles, FilterX, Award, Crown 
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useStaff } from '../context/StaffContext';
import { useAuth } from '../context/AuthContext';
import { StaffStats } from '../components/staff/StaffStats';
import { StaffFilters } from '../components/staff/StaffFilters';
import { StaffTable } from '../components/staff/StaffTable';
import { StaffCardGrid } from '../components/staff/StaffCardGrid';
import { AddStaffModal } from '../components/staff/AddStaffModal';
import { StaffRoleSelection } from '../components/staff/StaffRoleSelection';
import { Button } from '../components/atoms/Button';
import { StaffRank, StaffStatus, StaffSortOption, StaffViewMode } from '../types/staff';

export function StaffManagement() {
  const { t, language } = useLanguage();
  const { staff, loading, syncWithDiscord } = useStaff();
  const { hasPermission, user, role } = useAuth();
  const isAr = language === 'ar';

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<StaffStatus | 'All'>('All');
  const [rankFilter, setRankFilter] = useState<StaffRank | 'All'>('All');
  const [sortBy, setSortBy] = useState<StaffSortOption>('POINTS_DESC');
  const [viewMode, setViewMode] = useState<StaffViewMode>(() => {
    return (localStorage.getItem('cn_staff_view_mode') as StaffViewMode) || 'grid';
  });

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isRoleConfigOpen, setIsRoleConfigOpen] = useState(false);
  const [roleConfigTab, setRoleConfigTab] = useState<'staff' | 'owner' | 'both'>('staff');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncFeedback, setSyncFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const isOwner = role === 'OWNER' || user?.isGuildOwner || user?.discordId === '871043296280076308' || !user;
  const canManageStaffRoles = isOwner || hasPermission('ADMIN') || hasPermission('MANAGE_GUILD') || hasPermission('MANAGE_ROLES');
  const canAddStaff = hasPermission('ADD_STAFF');
  const canSync = hasPermission('MANAGE_ROLES') || hasPermission('MANAGE_GUILD') || hasPermission('ADMIN');

  // Persist view mode preference
  const handleViewModeChange = (mode: StaffViewMode) => {
    setViewMode(mode);
    localStorage.setItem('cn_staff_view_mode', mode);
  };

  // Sync Discord Roster
  const handleSyncRoster = async () => {
    setIsSyncing(true);
    setSyncFeedback(null);
    try {
      const res = await syncWithDiscord();
      setSyncFeedback({
        type: 'success',
        message: isAr
          ? `تم مزامنة الطاقم بنجاح (${res.synced} إداري تم تحديثهم)`
          : `Roster synchronized with Discord (${res.synced} staff updated)`
      });
      setTimeout(() => setSyncFeedback(null), 4000);
    } catch (err: any) {
      setSyncFeedback({
        type: 'error',
        message: err?.message || (isAr ? 'فشل الاتصال بديسكورد' : 'Failed to sync with Discord')
      });
      setTimeout(() => setSyncFeedback(null), 5000);
    } finally {
      setIsSyncing(false);
    }
  };

  // Filter & Sort staff
  const filteredAndSortedStaff = useMemo(() => {
    // 1. Filter out permanently removed staff
    let list = staff.filter(member => member.status !== 'REMOVED');

    // 2. Search query match
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(member => 
        (member.displayName || '').toLowerCase().includes(q) ||
        (member.username || '').toLowerCase().includes(q) ||
        (member.discordId || '').includes(q) ||
        (member.notes || '').toLowerCase().includes(q)
      );
    }

    // 3. Status filter
    if (statusFilter !== 'All') {
      list = list.filter(member => member.status === statusFilter);
    }

    // 4. Rank filter
    if (rankFilter !== 'All') {
      list = list.filter(member => member.rank === rankFilter);
    }

    // 5. Sorting
    list.sort((a, b) => {
      if (sortBy === 'POINTS_DESC') {
        return (b.points || 0) - (a.points || 0);
      }
      if (sortBy === 'POINTS_ASC') {
        return (a.points || 0) - (b.points || 0);
      }
      if (sortBy === 'NAME_ASC') {
        return (a.displayName || a.username || '').localeCompare(b.displayName || b.username || '');
      }
      if (sortBy === 'JOINED_DESC') {
        return new Date(b.joinedAt || 0).getTime() - new Date(a.joinedAt || 0).getTime();
      }
      return 0;
    });

    return list;
  }, [staff, searchQuery, statusFilter, rankFilter, sortBy]);

  const activeStaffCount = staff.filter(s => s.status !== 'REMOVED').length;

  return (
    <main 
      id="staff-management-page"
      className="flex-1 pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-8 relative z-10 overflow-hidden"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-5 border-b border-slate-800/80 pb-6">
        <motion.div 
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-2"
        >
          <h1 className="font-display font-bold text-3xl sm:text-4xl text-white tracking-tight">
            {isAr ? 'إدارة طاقم العمل' : 'Staff Management'}
          </h1>
          
          <p className="font-sans text-sm sm:text-base text-slate-400 max-w-2xl leading-relaxed">
            {isAr 
              ? 'إدارة صلاحيات ورتب الإداريين، رصد النقاط وسجلات الإنجاز، ومزامنة أعضاء السيرفر مع ديسكورد.' 
              : 'Direct authority over staff credentials, merit point transactions, audit timelines, and Discord role synchronization.'}
          </p>
        </motion.div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-3">
          <Link to="/rank-points">
            <Button
              variant="outline"
              className="text-xs sm:text-sm font-semibold py-2.5 px-4 bg-slate-900 hover:bg-slate-800 border-slate-700/80 text-cyan-300 hover:text-cyan-200"
            >
              <Award size={15} className="text-cyan-400" />
              <span>{isAr ? 'خريطة نقاط الرتب' : 'Rank Points Map'}</span>
            </Button>
          </Link>

          {canManageStaffRoles && (
            <Button
              variant="outline"
              onClick={() => {
                if (isRoleConfigOpen && roleConfigTab === 'staff') {
                  setIsRoleConfigOpen(false);
                } else {
                  setRoleConfigTab('staff');
                  setIsRoleConfigOpen(true);
                }
              }}
              className={`text-xs sm:text-sm font-semibold py-2.5 px-4 transition-all ${
                isRoleConfigOpen && roleConfigTab === 'staff'
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-lg shadow-cyan-950/50'
                  : 'bg-slate-900 hover:bg-slate-800 border-slate-700/80 text-slate-200'
              }`}
            >
              <Shield size={15} className="text-cyan-400" />
              <span>{isAr ? 'تحديد رتب الإدارة' : 'Staff Roles'}</span>
            </Button>
          )}

          {isOwner && (
            <Button
              variant="outline"
              onClick={() => {
                if (isRoleConfigOpen && roleConfigTab === 'owner') {
                  setIsRoleConfigOpen(false);
                } else {
                  setRoleConfigTab('owner');
                  setIsRoleConfigOpen(true);
                }
              }}
              className={`text-xs sm:text-sm font-semibold py-2.5 px-4 transition-all ${
                isRoleConfigOpen && roleConfigTab === 'owner'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-lg shadow-amber-950/50'
                  : 'bg-slate-900 hover:bg-slate-800 border-slate-700/80 text-amber-300 hover:text-amber-200'
              }`}
            >
              <Crown size={15} className="text-amber-400" />
              <span>{isAr ? 'رتب المالك' : 'Owner Roles'}</span>
            </Button>
          )}

          {canSync && (
            <Button
              variant="outline"
              onClick={handleSyncRoster}
              disabled={isSyncing}
              className="text-xs sm:text-sm font-semibold py-2.5 px-4 bg-slate-900 hover:bg-slate-800 border-slate-700/80 text-slate-200"
            >
              <RefreshCw size={15} className={isSyncing ? 'animate-spin text-cyan-400' : 'text-slate-400'} />
              <span>{isSyncing ? (isAr ? 'جاري المزامنة...' : 'Syncing...') : (isAr ? 'مزامنة ديسكورد' : 'Sync Discord')}</span>
            </Button>
          )}

          {canAddStaff && (
            <Button 
              variant="primary" 
              className="gap-2 text-xs sm:text-sm font-semibold py-2.5 px-5" 
              onClick={() => setIsAddModalOpen(true)}
            >
              <Plus size={16} />
              <span>{isAr ? 'إضافة إداري جديد' : 'Enroll Staff'}</span>
            </Button>
          )}
        </div>
      </div>

      {/* Staff & Owner Role Selection Section (Owner Control) */}
      <AnimatePresence>
        {isRoleConfigOpen && (
          <StaffRoleSelection
            isOpen={isRoleConfigOpen}
            initialTab={roleConfigTab}
            onClose={() => setIsRoleConfigOpen(false)}
            onRolesUpdated={() => {
              // Notifies context or refreshes silently
            }}
          />
        )}
      </AnimatePresence>

      {/* Sync Feedback Toast */}
      <AnimatePresence>
        {syncFeedback && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`p-4 rounded-2xl flex items-center justify-between gap-3 text-xs font-sans ${
              syncFeedback.type === 'success'
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
            }`}
          >
            <div className="flex items-center gap-2">
              {syncFeedback.type === 'success' ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />}
              <span className="font-medium">{syncFeedback.message}</span>
            </div>
            <button
              onClick={() => setSyncFeedback(null)}
              className="text-slate-400 hover:text-white text-xs underline"
            >
              {isAr ? 'إغلاق' : 'Dismiss'}
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Metrics & KPI Stats Bar */}
      <StaffStats />

      {/* Staff Roster Section */}
      <div className="space-y-5 pt-2">
        {/* Section Heading */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Users className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-white font-display">
              {isAr ? 'دليل أعضاء الإدارة' : 'Staff Members Directory'}
            </h2>
          </div>

          <span className="text-xs text-slate-400 font-mono bg-slate-900 px-3 py-1 rounded-full border border-slate-800">
            {filteredAndSortedStaff.length} / {activeStaffCount} {isAr ? 'عضو' : 'staff'}
          </span>
        </div>

        {/* Filter and Search Controls */}
        <StaffFilters 
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          statusFilter={statusFilter}
          setStatusFilter={setStatusFilter}
          rankFilter={rankFilter}
          setRankFilter={setRankFilter}
          sortBy={sortBy}
          setSortBy={setSortBy}
          viewMode={viewMode}
          setViewMode={handleViewModeChange}
          totalCount={activeStaffCount}
          filteredCount={filteredAndSortedStaff.length}
        />

        {/* Roster Display */}
        {filteredAndSortedStaff.length === 0 ? (
          <div className="w-full py-16 text-center rounded-3xl bg-slate-900/40 border border-slate-800 p-8 space-y-4">
            <FilterX size={44} className="mx-auto text-slate-600" />
            <div>
              <h3 className="text-base font-semibold text-white font-display">
                {isAr ? 'لم يتم العثور على أعضاء مطابقة' : 'No staff members match your criteria'}
              </h3>
              <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                {searchQuery || statusFilter !== 'All' || rankFilter !== 'All'
                  ? (isAr ? 'حاول تغيير شروط البحث أو الفلاتر المحددة.' : 'Try adjusting or clearing your search filters.')
                  : (isAr ? 'لا يوجد أعضاء في الطاقم حتى الآن. يمكنك إضافة عضو جديد الآن.' : 'No staff members registered in the directory. You can enroll a staff member now.')}
              </p>
            </div>

            {(searchQuery || statusFilter !== 'All' || rankFilter !== 'All') ? (
              <Button
                variant="outline"
                className="text-xs px-4 py-2"
                onClick={() => {
                  setSearchQuery('');
                  setStatusFilter('All');
                  setRankFilter('All');
                }}
              >
                {isAr ? 'إعادة ضبط الفلاتر' : 'Clear Filters'}
              </Button>
            ) : canAddStaff ? (
              <Button
                variant="primary"
                className="text-xs px-5 py-2.5"
                onClick={() => setIsAddModalOpen(true)}
              >
                <Plus size={14} className="me-1.5" />
                <span>{isAr ? 'إضافة أول إداري' : 'Enroll First Staff Member'}</span>
              </Button>
            ) : null}
          </div>
        ) : viewMode === 'grid' ? (
          <StaffCardGrid 
            staff={filteredAndSortedStaff} 
          />
        ) : (
          <StaffTable 
            staff={filteredAndSortedStaff} 
          />
        )}
      </div>

      {/* Add Staff Modal */}
      {canAddStaff && (
        <AddStaffModal 
          isOpen={isAddModalOpen} 
          onClose={() => setIsAddModalOpen(false)} 
        />
      )}
    </main>
  );
}
