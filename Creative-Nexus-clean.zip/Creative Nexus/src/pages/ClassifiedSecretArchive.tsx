import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useEasterEggs } from '../context/EasterEggContext';
import { useAuth } from '../context/AuthContext';
import { ShieldAlert, ArrowLeft, Image as ImageIcon, Sparkles, Terminal, FileCode, Gamepad2, Lock, AlertOctagon } from 'lucide-react';
import { motion } from 'motion/react';

interface DossierData {
  titleEn: string;
  titleAr: string;
  messageEn: string;
  messageAr: string;
  warningNoticeEn: string;
  warningNoticeAr: string;
  imageUrl: string;
}

export const ClassifiedSecretArchive: React.FC = () => {
  const { language } = useLanguage();
  const { setIsKohanGameOpen, isSecretArchiveRevealed } = useEasterEggs();
  const { isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();
  const isAr = language === 'ar';

  const [dossier, setDossier] = useState<DossierData | null>(null);
  const [isVerifying, setIsVerifying] = useState<boolean>(true);
  const [accessDenied, setAccessDenied] = useState<boolean>(false);

  useEffect(() => {
    // If auth state is still resolving, wait
    if (isLoading) return;

    // Critical: Logged-out users or unrevealed attempts cannot access
    if (!isAuthenticated || !isSecretArchiveRevealed) {
      setAccessDenied(true);
      setIsVerifying(false);
      return;
    }

    let isMounted = true;
    setIsVerifying(true);

    // Call server-authoritative dossier endpoint
    fetch('/api/secret-archive/dossier')
      .then((res) => {
        if (!res.ok) {
          throw new Error(`Unauthorized ${res.status}`);
        }
        return res.json();
      })
      .then((data: { dossier: DossierData }) => {
        if (isMounted) {
          if (data && data.dossier) {
            setDossier(data.dossier);
            setAccessDenied(false);
          } else {
            setAccessDenied(true);
          }
          setIsVerifying(false);
        }
      })
      .catch((err) => {
        if (isMounted) {
          console.warn('Secret Archive access rejected by server:', err);
          setAccessDenied(true);
          setIsVerifying(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [isAuthenticated, isSecretArchiveRevealed, isLoading]);

  // Loading state
  if (isLoading || isVerifying) {
    return (
      <main id="classified-secret-archive-page" className="relative min-h-[85vh] flex flex-col items-center justify-center px-4 py-16 text-center select-none overflow-hidden">
        <div className="flex flex-col items-center gap-4 text-neutral-400 font-mono text-sm">
          <div className="w-8 h-8 border-2 border-rose-500/40 border-t-rose-500 rounded-full animate-spin" />
          <span>{isAr ? 'جاري التحقق من التصريح الأمني...' : 'Verifying clearance authorization...'}</span>
        </div>
      </main>
    );
  }

  // Access Denied (Not logged in, or attempted direct URL visit without trigger)
  if (!isAuthenticated || !isSecretArchiveRevealed || accessDenied || !dossier) {
    return (
      <main id="classified-secret-archive-page" className="relative min-h-[85vh] flex flex-col items-center justify-center px-4 py-16 text-center select-none overflow-hidden">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative z-10 w-full max-w-lg rounded-3xl border border-neutral-800 bg-neutral-950/90 backdrop-blur-xl p-8 sm:p-12 shadow-2xl"
        >
          <div className="w-16 h-16 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-500 mx-auto mb-6">
            <Lock size={28} />
          </div>

          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neutral-900 border border-neutral-800 text-neutral-400 font-mono text-xs uppercase tracking-wider mb-4">
            <AlertOctagon size={13} />
            <span>{isAr ? 'منطقة محظورة' : 'RESTRICTED ARCHIVE'}</span>
          </div>

          <h1 className="text-xl sm:text-2xl font-bold text-neutral-200 font-display mb-3">
            {isAr ? 'الملف السري غير متوفر' : 'Classified Document Unavailable'}
          </h1>

          <p className="text-xs sm:text-sm text-neutral-400 font-mono max-w-sm mx-auto mb-8 leading-relaxed">
            {isAr
              ? 'هذا السجل محمي ومشفر بالكامل، ولا يمكن الوصول إليه إلا للمستخدمين المسجلين بعد تفعيل الإشارة المخصصة.'
              : 'This encrypted archival node requires active authenticated clearance and designated community activation.'}
          </p>

          <Link
            id="restricted-return-home-btn"
            to="/"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 py-3 px-6 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-mono font-bold transition-all"
          >
            <ArrowLeft size={15} />
            <span>{isAr ? 'العودة إلى الصفحة الرئيسية' : 'Return to Home'}</span>
          </Link>
        </motion.div>
      </main>
    );
  }

  const hasConfiguredImage = Boolean(dossier.imageUrl && dossier.imageUrl.trim().length > 0);

  return (
    <main id="classified-secret-archive-page" className="relative min-h-[85vh] flex flex-col items-center justify-center px-4 py-16 text-center select-none overflow-hidden">
      {/* Background ambient warm bronze and torchlight glow */}
      <div className="absolute top-1/3 start-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-amber-900/20 blur-[150px] pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 25 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-10 w-full max-w-2xl rounded-3xl border border-amber-600/40 mesopotamian-stone-bg p-7 sm:p-12 shadow-[0_25px_70px_rgba(0,0,0,0.8),0_0_35px_rgba(217,119,6,0.2)]"
      >
        {/* Top Header Tag */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-950/60 border border-amber-500/40 text-amber-300 font-mono text-xs uppercase tracking-widest mb-4 shadow-inner">
          <ShieldAlert size={14} className="animate-pulse text-amber-400" />
          <span>{isAr ? dossier.titleAr : dossier.titleEn}</span>
        </div>

        {/* Mesopotamian Cuneiform Seal Frieze */}
        <div className="text-[11px] font-mono text-amber-500/50 tracking-[0.3em] mb-4 select-none">
          𒀭 𒆠 𒈗 𒂍 𒂗 𒈨
        </div>

        {/* Humorous Headline */}
        <h1 className="text-2xl sm:text-4xl font-extrabold mesopotamian-gold-text font-serif mb-4 tracking-tight">
          {isAr ? dossier.messageAr : dossier.messageEn}
        </h1>

        <p className="text-xs sm:text-sm text-amber-200/70 font-mono max-w-md mx-auto mb-8 leading-relaxed">
          {isAr ? dossier.warningNoticeAr : dossier.warningNoticeEn}
        </p>

        {/* Image Display Area (Served securely from backend) */}
        <div className="mb-8 rounded-2xl border border-amber-600/30 bg-[#160f09]/80 p-4 sm:p-6 overflow-hidden relative shadow-inner">
          {hasConfiguredImage ? (
            <div className="relative rounded-xl overflow-hidden shadow-2xl mx-auto">
              <img
                id="owner-configured-secret-image"
                src={dossier.imageUrl}
                alt={isAr ? dossier.titleAr : dossier.titleEn}
                className="w-full max-h-[420px] object-contain rounded-xl mx-auto"
                referrerPolicy="no-referrer"
              />
              <div className="mt-3 text-xs font-mono text-amber-300/80">
                {isAr ? dossier.messageAr : dossier.messageEn}
              </div>
            </div>
          ) : (
            <div className="py-12 px-4 flex flex-col items-center justify-center text-center">
              {/* Classified Redacted Stamp Box */}
              <div className="w-16 h-16 rounded-2xl bg-amber-950/40 border border-amber-600/40 flex items-center justify-center text-amber-400 mb-4 shadow-inner">
                <ImageIcon size={30} />
              </div>

              <div className="inline-block px-4 py-1 rounded-md bg-[#24150b] border border-amber-500/40 text-amber-300 font-mono font-bold text-xs uppercase tracking-widest mb-3">
                [ {isAr ? 'الصورة بانتظار الإعداد من مالك الموقع' : 'IMAGE PENDING OWNER CONFIGURATION'} ]
              </div>

              <p className="text-xs text-amber-200/60 max-w-md font-mono mb-4 leading-relaxed">
                {isAr
                  ? 'يمكن لمالك الموقع تعيين رابط أو مسار الصورة السرية في ملف الإعدادات:'
                  : 'The website owner can provide their designated secret image URL or path inside the config file:'}
              </p>

              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#0d0805] border border-amber-600/30 font-mono text-[11px] text-amber-300/90 mb-2">
                <FileCode size={13} className="text-amber-400" />
                <span>src/config/easterEggs.ts &rarr; CLASSIFIED_ARCHIVE_CONFIG.imageUrl</span>
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            id="launch-secret-game-from-archive-btn"
            type="button"
            onClick={() => setIsKohanGameOpen(true)}
            className="w-full sm:w-auto py-3 px-6 rounded-xl mesopotamian-btn-gold text-xs font-mono font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
          >
            <Gamepad2 size={16} />
            <span>{isAr ? '🎮 تشغيل اللعبة السرية (تحدي كوهان)' : '🎮 Play Secret Game (Kohan Challenge)'}</span>
          </button>

          <Link
            id="return-to-safety-btn"
            to="/"
            className="w-full sm:w-auto py-3 px-6 rounded-xl mesopotamian-btn-stone text-xs font-mono font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
          >
            <ArrowLeft size={15} />
            <span>{isAr ? 'العودة إلى الأمان (الصفحة الرئيسية)' : 'Return to Safety (Home)'}</span>
          </Link>
        </div>
      </motion.div>
    </main>
  );
};
