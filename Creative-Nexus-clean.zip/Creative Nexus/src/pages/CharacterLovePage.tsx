import React from 'react';
import { motion } from 'motion/react';
import { Heart, Crown, Sparkles, Gift, Sliders, Shield, BookOpen, Layers } from 'lucide-react';
import { useCharacterLove } from '../context/CharacterLoveContext';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { useEasterEggs } from '../context/EasterEggContext';
import { CharacterLoveDisplay } from '../components/characterLove/CharacterLoveDisplay';
import { CharacterLoveSelector } from '../components/characterLove/CharacterLoveSelector';
import { CharacterLoveLevelUpModal } from '../components/characterLove/CharacterLoveLevelUpModal';
import { CharacterSurpriseGiftModal } from '../components/characterLove/CharacterSurpriseGiftModal';
import { SpecialRewardCelebrationModal } from '../components/characterLove/SpecialRewardCelebrationModal';
import { OwnerCharacterLoveModal } from '../components/characterLove/OwnerCharacterLoveModal';

export const CharacterLovePage: React.FC = () => {
  const { language } = useLanguage();
  const isAr = language === 'ar';
  const { role, isOwner } = useAuth();
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';

  const {
    characters,
    items,
    thresholds,
    userProgress,
    userInventory,
    selectedCharacterId,
    setSelectedCharacterId,
    selectedCharacter,
    selectedCharacterProgress,
    activeStage,
    giveGift,
    isGivingGift,
    openOwnerModal,
    levelUpModalData,
    dismissLevelUpModal,
    droppedGiftModalData,
    dismissDroppedGiftModal,
    specialRewardCelebrationData,
    dismissSpecialRewardCelebration
  } = useCharacterLove();

  const isOwnerUser = Boolean(isOwner || role === 'OWNER');

  return (
    <div className={`min-h-screen py-6 sm:py-8 px-4 sm:px-6 md:px-8 max-w-7xl mx-auto space-y-8 ${
      isMesopotamian ? 'text-amber-100' : 'text-[#eafffa]'
    }`}>
      {/* Page Header */}
      <div className="relative flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-3 py-0.5 rounded-full text-[10px] font-mono font-bold tracking-wider uppercase bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1">
              <Heart size={11} className="fill-rose-400" />
              {isAr ? 'نظام مودة ورفقاء الملاذ' : 'COMPANION LOVE SYSTEM'}
            </span>
          </div>
          <h1 className={`text-2xl sm:text-3xl md:text-4xl font-black font-cairo ${
            isMesopotamian ? 'text-amber-200' : 'text-white'
          }`}>
            {isAr ? 'محراب المحبة والأرواح الحارسة' : 'Sanctuary of Love & Devotion'}
          </h1>
          <p className="font-cairo text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
            {isAr
              ? 'تفاعل مع شخصيات الملاذ الأسطورية، وأهدِها نفائس الآثار والهدايا لرفع مستوى المحبة وفتح مظاهر حصرية وتأثيرات بصرية ثلاثية الأبعاد.'
              : 'Form bonds with legendary companions. Offer sacred gifts to increase affection, unlock new appearance stages, and unveil unique 3D visual forms.'}
          </p>
        </div>

        {/* Owner Controls Action Button */}
        {isOwnerUser && (
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => openOwnerModal('characters')}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-rose-500 via-pink-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-white font-cairo font-bold text-xs shadow-lg shadow-rose-500/25 flex items-center gap-2 transition-all cursor-pointer hover:scale-105 active:scale-95"
            >
              <Crown size={15} />
              <span>{isAr ? 'لوحة تحكم المالك' : 'Owner Controls'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Main Interactive Stage Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: 3D Character Viewport */}
        <div className="lg:col-span-5 flex flex-col items-center">
          {selectedCharacter && selectedCharacterProgress && activeStage && (
            <CharacterLoveDisplay
              character={selectedCharacter}
              progress={selectedCharacterProgress}
              activeStage={activeStage}
              thresholds={thresholds}
              isMesopotamian={isMesopotamian}
              items={items}
              inventory={userInventory}
              onGiveGift={giveGift}
            />
          )}
        </div>

        {/* Right Column: Character Selection & Gift Inventory */}
        <div className="lg:col-span-7 space-y-8">
          {/* Character Selector */}
          <CharacterLoveSelector
            characters={characters}
            selectedId={selectedCharacterId}
            onSelect={setSelectedCharacterId}
            progressMap={userProgress}
            isMesopotamian={isMesopotamian}
          />
        </div>
      </div>

      {/* Level Up & New Stage Celebratory Modal */}
      <CharacterLoveLevelUpModal
        data={levelUpModalData}
        character={selectedCharacter}
        onClose={dismissLevelUpModal}
        isMesopotamian={isMesopotamian}
      />

      {/* Surprise Gift Celebration Modal */}
      <CharacterSurpriseGiftModal
        data={droppedGiftModalData}
        onClose={dismissDroppedGiftModal}
        companionName={selectedCharacter?.name}
        companionNameAr={selectedCharacter?.nameAr}
        companionImage={selectedCharacter?.avatarUrl}
        isMesopotamian={isMesopotamian}
      />

      {/* 3-Day Special Reward Celebratory Modal */}
      <SpecialRewardCelebrationModal
        data={specialRewardCelebrationData}
        onClose={dismissSpecialRewardCelebration}
        companionName={selectedCharacter?.name}
        companionNameAr={selectedCharacter?.nameAr}
        isMesopotamian={isMesopotamian}
      />

      {/* Owner Management Modal */}
      <OwnerCharacterLoveModal />
    </div>
  );
};
