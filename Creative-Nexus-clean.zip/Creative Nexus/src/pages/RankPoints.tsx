import React, { useState, useMemo, useRef } from 'react';
import { motion } from 'motion/react';
import { 
  Award, 
  Sparkles, 
  Shield, 
  Users, 
  AlertCircle, 
  Crown, 
  TrendingUp, 
  RefreshCw,
  Compass,
  ArrowUp,
  ArrowDown,
  Navigation,
  Lock,
  Unlock,
  BookOpen
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useStaff } from '../context/StaffContext';
import { useLanguage } from '../context/LanguageContext';
import { StaffMember } from '../types/staff';
import { 
  RANK_TIERS, 
  RANK_SECTIONS,
  isSectionUnlocked,
  groupStaffByTier, 
  getTierForPoints 
} from '../types/rankMap';
import { RankNodeCard } from '../components/rankMap/RankNodeCard';
import { RankSectionBanner } from '../components/rankMap/RankSectionBanner';
import { UserProgressHero } from '../components/rankMap/UserProgressHero';
import { StaffInspectionModal } from '../components/rankMap/StaffInspectionModal';
import { RankMapConnectingPath } from '../components/rankMap/RankMapConnectingPath';
import { OwnerRankApplicationsPanel } from '../components/rankMap/OwnerRankApplicationsPanel';
import { Button } from '../components/atoms/Button';

export const RankPoints: React.FC = () => {
  const { user, role, hasPermission } = useAuth();
  const { staff, loading, refreshStaff } = useStaff();
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const [selectedMember, setSelectedMember] = useState<StaffMember | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const mapContainerRef = useRef<HTMLDivElement>(null);

  // Authority & Visibility Verification:
  // Visible to the Owner and all recognized Staff members
  const isOwner = role === 'OWNER' || user?.discordId === '871043296280076308' || !!user?.isGuildOwner;
  const isStaffRole = role === 'SUPER_ADMIN' || role === 'ADMIN' || role === 'MODERATOR' || hasPermission('VIEW_STAFF');
  const isInStaffDirectory = staff.some(s => s.discordId === user?.discordId && s.status !== 'REMOVED');
  const isAuthorized = isOwner || isStaffRole || isInStaffDirectory;

  // Find authenticated user's staff profile if present
  const currentUserStaffMember = useMemo(() => {
    if (!user) return undefined;
    return staff.find(s => s.discordId === user.discordId && s.status !== 'REMOVED');
  }, [user, staff]);

  const currentUserPoints = currentUserStaffMember?.points || 0;

  // Group real staff members by rank tier
  const staffByTier = useMemo(() => {
    return groupStaffByTier(staff);
  }, [staff]);

  // Group tiers sequentially by Section (1 to 4)
  const sectionsData = useMemo(() => {
    return RANK_SECTIONS.map((section) => {
      const sectionTiers = RANK_TIERS.filter((t) => t.section === section.id);
      const isUnlocked = isSectionUnlocked(section.id, currentUserPoints, isOwner);
      return {
        section,
        isUnlocked,
        tiers: sectionTiers.map((tier) => {
          const globalIndex = RANK_TIERS.findIndex((t) => t.id === tier.id);
          const stepNumber = globalIndex + 1; // 1 to 35
          return {
            tier,
            stepNumber,
            members: staffByTier[tier.id] || []
          };
        })
      };
    });
  }, [currentUserPoints, isOwner, staffByTier]);

  // Handle manual refresh
  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await refreshStaff();
    } finally {
      setIsRefreshing(false);
    }
  };

  // Jump to user rank on map
  const handleJumpToMyRank = () => {
    if (!currentUserStaffMember) return;
    const tier = getTierForPoints(currentUserStaffMember.points || 0);
    const el = document.getElementById(`rank-platform-${tier.id}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // Jump directly to a specific section banner
  const handleJumpToSection = (sectionId: string) => {
    const el = document.getElementById(`section-banner-${sectionId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // Scroll to Top (Lowest Rank - CN Team)
  const handleScrollToStart = () => {
    const el = document.getElementById('rank-platform-cn_team');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Scroll to Bottom (Supreme Zenith - HIGH COUNCIL MANAGER)
  const handleScrollToZenith = () => {
    const el = document.getElementById('rank-platform-high_council_manager');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // If unauthorized, render friendly restricted notice
  if (!loading && !isAuthorized) {
    return (
      <main 
        id="rank-points-restricted"
        className="flex-1 pt-32 pb-24 px-4 sm:px-6 lg:px-8 max-w-3xl mx-auto w-full text-center space-y-6"
        dir={isAr ? 'rtl' : 'ltr'}
      >
        <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto text-amber-400">
          <Shield size={32} />
        </div>
        <h1 className="text-3xl font-display font-bold text-white">
          {isAr ? 'منطقة مخصصة لطاقم الإدارة' : 'Staff Only Area'}
        </h1>
        <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
          {isAr 
            ? 'خريطة نقاط الرتب مخصصة لمالك السيرفر وأعضاء طاقم الإدارة المعتمدين في CREATINE NEXUS. إذا كنت إدارياً، يرجى تسجيل الدخول بحساب ديسكورد الإداري الخاص بك.'
            : 'The Rank Points progression map is strictly reserved for recognized CREATINE NEXUS staff members and the Server Owner. If you are a staff member, please log in with your verified Discord account.'}
        </p>
        <div className="pt-4 flex items-center justify-center gap-4">
          <Link to="/">
            <Button variant="outline">{isAr ? 'العودة للرئيسية' : 'Return Home'}</Button>
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main 
      id="rank-points-page"
      className="flex-1 pt-28 pb-32 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto w-full space-y-10 relative z-10"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-5 border-b border-slate-800/80 pb-6">
        <motion.div 
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-2"
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <TrendingUp size={20} />
            </div>
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
              {isAr ? 'خريطة الرتب العمودية الموحدة' : 'Unified Vertical Rank Progression Map'}
            </span>
          </div>

          <h1 className="font-display font-bold text-3xl sm:text-4xl text-white tracking-tight">
            {isAr ? 'نقاط الرتب والتدرج الإداري' : 'Rank Progression & Points'}
          </h1>
          
          <p className="font-sans text-sm sm:text-base text-slate-400 max-w-2xl leading-relaxed">
            {isAr 
              ? 'خريطة الصعود الإداري العمودية — استكشف المراحل الأربع المتتالية من بوابة البداية حتى قمة المجلس الأعلى.'
              : 'Ascending vertical rank progression map — explore the 4 sequential milestones from the entry gateway to the supreme High Council.'}
          </p>
        </motion.div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-3">
          <Button
            variant="outline"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="text-xs sm:text-sm font-semibold py-2.5 px-4 bg-slate-900 hover:bg-slate-800 border-slate-700/80 text-slate-200"
          >
            <RefreshCw size={15} className={isRefreshing ? 'animate-spin text-cyan-400' : 'text-slate-400'} />
            <span>{isRefreshing ? (isAr ? 'تحديث...' : 'Refreshing...') : (isAr ? 'تحديث الخريطة' : 'Refresh Map')}</span>
          </Button>

          <Link to="/codex/guide-rank-points">
            <Button 
              variant="outline"
              className="gap-2 text-xs sm:text-sm font-semibold py-2.5 px-4 bg-slate-900 hover:bg-slate-800 border-cyan-500/30 text-cyan-300 hover:text-white"
            >
              <BookOpen size={16} className="text-cyan-400" />
              <span>{isAr ? 'دليل الرتب والنقاط' : 'Rank Guide'}</span>
            </Button>
          </Link>

          <Link to="/staff-management">
            <Button 
              variant="outline"
              className="gap-2 text-xs sm:text-sm font-semibold py-2.5 px-4 bg-slate-900 hover:bg-slate-800 border-slate-700/80 text-slate-200"
            >
              <Users size={16} className="text-cyan-400" />
              <span>{isAr ? 'دليل الإدارة' : 'Staff Directory'}</span>
            </Button>
          </Link>
        </div>
      </div>

      {/* MANDATORY PROMOTION NOTICE BANNER */}
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl border border-amber-500/30 bg-amber-950/20 p-4 sm:p-5 flex items-start gap-3.5 shadow-sm"
      >
        <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center shrink-0 text-amber-400 mt-0.5">
          <AlertCircle size={18} />
        </div>
        <div className="space-y-1 text-xs sm:text-sm">
          <p className="font-bold text-amber-300 flex items-center gap-2">
            <span>{isAr ? 'الترقية تتطلب موافقة المالك' : 'Promotion requires Owner approval.'}</span>
          </p>
          <p className="text-slate-300 leading-relaxed font-sans">
            {isAr 
              ? 'الوصول إلى النقاط لا يمنح الرتبة تلقائياً بأي حال. النقاط تحدد الأهلية وموقع التدرج فقط. الترقية تتطلب دائماً تقديم طلب وموافقة مالك السيرفر Edgar، ولا يتم تعديل رتب الديسكورد تلقائياً.'
              : 'Points determine eligibility and progression position only. Reaching a threshold does NOT automatically promote the actual rank. Promotion strictly requires Owner approval. Never automatically changes Discord roles.'}
          </p>
        </div>
      </motion.div>

      {/* Authenticated User Status Hero */}
      <UserProgressHero
        user={user}
        staffMember={currentUserStaffMember}
        isOwner={isOwner}
        isAr={isAr}
      />

      {/* OWNER-ONLY RANK APPLICATIONS CONTROL AREA */}
      {isOwner && (
        <OwnerRankApplicationsPanel
          staffList={staff}
          onSelectMember={setSelectedMember}
          isAr={isAr}
        />
      )}

      {/* Progression Map Navigation Bar with Section Selectors */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pt-2 border-t border-slate-800/60">
        <div className="flex items-center gap-2">
          <Compass size={18} className="text-cyan-400" />
          <h2 className="text-xl sm:text-2xl font-display font-bold text-white">
            {isAr ? 'خريطة التدرج والتسلسل الإداري' : 'Hierarchy & Progression Map'}
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            (4 {isAr ? 'مراحل' : 'Sections'} • 35 {isAr ? 'رتبة' : 'Tiers'})
          </span>
        </div>

        {/* Quick Jump Controls */}
        <div className="flex items-center gap-2 text-xs flex-wrap">
          {currentUserStaffMember && (
            <button
              type="button"
              onClick={handleJumpToMyRank}
              className="px-3 py-1.5 rounded-xl bg-cyan-950 text-cyan-300 border border-cyan-800/80 hover:bg-cyan-900/80 font-bold flex items-center gap-1.5 transition-colors"
            >
              <Navigation size={12} className="text-cyan-400" />
              <span>{isAr ? 'موقعي الحالي' : 'Jump to My Rank'}</span>
            </button>
          )}

          {/* Jump to Sections */}
          <button
            type="button"
            onClick={() => handleJumpToSection('staff')}
            className="px-2.5 py-1.5 rounded-xl bg-slate-900 text-cyan-300 border border-cyan-800/50 hover:bg-slate-800 font-medium transition-colors"
          >
            {isAr ? '1. الإدارة' : '1. Staff'}
          </button>

          <button
            type="button"
            onClick={() => handleJumpToSection('grand_staff')}
            className="px-2.5 py-1.5 rounded-xl bg-slate-900 text-amber-300 border border-amber-800/50 hover:bg-slate-800 font-medium transition-colors"
          >
            {isAr ? '2. 🟡 جراند ستاف' : '2. 🟡 Grand Staff'}
          </button>

          <button
            type="button"
            onClick={() => handleJumpToSection('guard')}
            className="px-2.5 py-1.5 rounded-xl bg-slate-900 text-purple-300 border border-purple-800/50 hover:bg-slate-800 font-medium transition-colors"
          >
            {isAr ? '3. 🟣 الحرس' : '3. 🟣 Guard'}
          </button>

          <button
            type="button"
            onClick={() => handleJumpToSection('high_council')}
            className="px-2.5 py-1.5 rounded-xl bg-slate-900 text-white border border-slate-600/70 hover:bg-slate-800 font-medium transition-colors"
          >
            {isAr ? '4. ⚪ المجلس الأعلى' : '4. ⚪ High Council'}
          </button>

          <button
            type="button"
            onClick={handleScrollToStart}
            className="px-3 py-1.5 rounded-xl bg-slate-900 text-slate-300 border border-slate-700 hover:bg-slate-800 font-semibold flex items-center gap-1.5 transition-colors"
          >
            <ArrowUp size={12} className="text-slate-400" />
            <span>{isAr ? 'البداية' : 'Start'}</span>
          </button>

          <button
            type="button"
            onClick={handleScrollToZenith}
            className="px-3 py-1.5 rounded-xl bg-slate-900 text-white border border-slate-700 hover:bg-slate-800 font-semibold flex items-center gap-1.5 transition-colors"
          >
            <ArrowDown size={12} className="text-white" />
            <span>{isAr ? 'القمة (280)' : 'Zenith (280)'}</span>
          </button>
        </div>
      </div>

      {/* Visual Map Layout — Vertical Progression from Lowest (top) to Highest (bottom) */}
      <div 
        ref={mapContainerRef}
        className="relative space-y-12 sm:space-y-16 py-8"
      >
        {/* Animated Vertical Line Running Through Entire Page */}
        <RankMapConnectingPath isAr={isAr} />

        {/* 
          Sequential Sections & Platforms:
          Section 1: Existing Staff (0–51 PTS)
          Section 2: CN GRAND STAFF (52–88+ PTS) — Yellow identity
          Section 3: CN GUARD (95–160+ PTS) — Purple identity
          Section 4: CN HIGH COUNCIL (175–280+ PTS) — White / Elite identity
        */}
        {sectionsData.map(({ section, isUnlocked, tiers }) => (
          <div key={section.id} className="relative z-10">
            {/* Distinct Section Banner showing Unlock condition & identity */}
            <RankSectionBanner
              section={section}
              isUnlocked={isUnlocked}
              currentUserPoints={currentUserPoints}
              isOwner={isOwner}
              isAr={isAr}
            />

            {/* Ranks inside this Section */}
            <div className="space-y-6 sm:space-y-8">
              {tiers.map(({ tier, stepNumber, members }) => (
                <RankNodeCard
                  key={tier.id}
                  tier={tier}
                  stepNumber={stepNumber}
                  totalSteps={35}
                  members={members}
                  currentUserId={user?.discordId}
                  isLocked={!isUnlocked}
                  unlockThreshold={section.unlockThreshold}
                  onSelectMember={setSelectedMember}
                  isAr={isAr}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Staff Member Inspection Modal — Strict No-Discord-ID Policy */}
      <StaffInspectionModal
        member={selectedMember}
        isOpen={!!selectedMember}
        onClose={() => setSelectedMember(null)}
        canManageStaff={isOwner || role === 'SUPER_ADMIN' || role === 'ADMIN'}
        isOwner={isOwner}
        currentUserId={user?.discordId}
        isAr={isAr}
      />
    </main>
  );
};

export default RankPoints;
