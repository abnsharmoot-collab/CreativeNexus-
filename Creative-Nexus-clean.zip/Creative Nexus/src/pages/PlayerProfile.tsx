import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCards } from '../context/CardContext';
import { useStaff } from '../context/StaffContext';
import { useRankApplications } from '../context/RankApplicationContext';
import { useLanguage } from '../context/LanguageContext';
import { PlayerProfileData } from '../types/progression';
import { CollectibleCardData } from '../types/cards';
import { getTierForPoints, RANK_TIERS } from '../types/rankMap';
import { ProfileHeader } from '../components/profile/ProfileHeader';
import { ModeratorDossierSection } from '../components/profile/ModeratorDossierSection';
import { BannerSelectorModal } from '../components/profile/BannerSelectorModal';
import { FavoriteCardSection } from '../components/profile/FavoriteCardSection';
import { ShowcaseSection } from '../components/profile/ShowcaseSection';
import { CollectionStatsSection } from '../components/profile/CollectionStatsSection';
import { BadgesSection } from '../components/profile/BadgesSection';
import { TitlesSection } from '../components/profile/TitlesSection';
import { ProfileCustomizerModal } from '../components/profile/ProfileCustomizerModal';
import { CardDetailModal } from '../components/cards/CardDetailModal';
import { 
  Sparkles, Shield, User, Loader2, ArrowLeft, ArrowRight, 
  ExternalLink, Layers, Award, Trophy, Hash, Calendar, Check, Copy, Crown, LayoutGrid
} from 'lucide-react';

type ProfileSectionTab = 'all' | 'dossier' | 'cards' | 'achievements' | 'identity';

export const PlayerProfile: React.FC = () => {
  const { discordId } = useParams<{ discordId?: string }>();
  const navigate = useNavigate();
  const { user, isAuthenticated, role: authRole, loading: authLoading, loginWithDiscord } = useAuth();
  const { 
    playerProfile: myPlayerProfile, 
    catalog, 
    fetchPlayerProfile, 
    customizeProfile,
    setSelectedTitle
  } = useCards();
  const { staff } = useStaff();
  const { getStatusForMember, getApplicationForMember, applyForRank } = useRankApplications();
  const { language } = useLanguage();
  const isAr = language === 'ar';

  // Automatically synchronize /profile with the logged-in user's Discord ID
  useEffect(() => {
    if (!discordId && user?.discordId) {
      navigate(`/profile/${user.discordId}`, { replace: true });
    }
  }, [discordId, user?.discordId, navigate]);

  const targetDiscordId = discordId || user?.discordId;
  const isOwnProfile = Boolean(user && targetDiscordId && user.discordId === targetDiscordId);

  const [profileData, setProfileData] = useState<PlayerProfileData | null>(() => {
    if ((!discordId || (user && discordId === user.discordId)) && myPlayerProfile) {
      return myPlayerProfile;
    }
    return null;
  });

  const [loading, setLoading] = useState<boolean>(() => {
    if ((!discordId || (user && discordId === user.discordId)) && myPlayerProfile) return false;
    if (!discordId && !authLoading && (!isAuthenticated || !user)) return false;
    return true;
  });

  const [activeSection, setActiveSection] = useState<ProfileSectionTab>('all');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isBannerModalOpen, setIsBannerModalOpen] = useState(false);
  const [inspectCard, setInspectCard] = useState<CollectibleCardData | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  // Failsafe timer: Ensure profile NEVER stays in a loading loop forever
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  // Synchronize when myPlayerProfile updates in context
  useEffect(() => {
    if (isOwnProfile && myPlayerProfile) {
      setProfileData(myPlayerProfile);
      setLoading(false);
    }
  }, [isOwnProfile, myPlayerProfile]);

  // Fetch profile data
  useEffect(() => {
    let isCancelled = false;

    if (!targetDiscordId) {
      if (!authLoading) setLoading(false);
      return;
    }

    // Viewing another user
    if (discordId && (!user || user.discordId !== discordId)) {
      setLoading(true);
      fetchPlayerProfile(discordId)
        .then((fetched) => {
          if (!isCancelled) {
            if (fetched) setProfileData(fetched);
            setLoading(false);
          }
        })
        .catch(() => {
          if (!isCancelled) setLoading(false);
        });
      return () => { isCancelled = true; };
    }

    // Viewing own profile
    if (isOwnProfile) {
      if (myPlayerProfile) {
        setProfileData(myPlayerProfile);
        setLoading(false);
      } else if (user) {
        fetchPlayerProfile(user.discordId)
          .then((fetched) => {
            if (!isCancelled) {
              if (fetched) setProfileData(fetched);
              setLoading(false);
            }
          })
          .catch(() => {
            if (!isCancelled) setLoading(false);
          });
      } else if (!authLoading) {
        setLoading(false);
      }
    }

    return () => {
      isCancelled = true;
    };
  }, [discordId, isOwnProfile, user?.discordId, targetDiscordId, authLoading, myPlayerProfile, fetchPlayerProfile]);

  // Staff and Role Resolution across the entire website
  const effectiveDiscordId = targetDiscordId || profileData?.discordId || '';

  const staffMember = useMemo(() => {
    if (!effectiveDiscordId) return null;
    return staff.find(
      s => s.discordId === effectiveDiscordId || String(s.id) === effectiveDiscordId
    ) || null;
  }, [staff, effectiveDiscordId]);

  const isOwner = Boolean(
    profileData?.isOwner || 
    (isOwnProfile && authRole === 'OWNER') || 
    profileData?.role === 'OWNER' ||
    effectiveDiscordId === '871043296280076308'
  );

  const isModerator = Boolean(
    isOwner ||
    profileData?.isModerator || 
    profileData?.role === 'MODERATOR' || 
    profileData?.role === 'ADMIN' || 
    profileData?.role === 'SUPER_ADMIN' ||
    (staffMember && ['MODERATOR', 'ADMINISTRATOR', 'SUPER_ADMIN'].includes(staffMember.rank)) ||
    (isOwnProfile && ['MODERATOR', 'ADMIN', 'SUPER_ADMIN'].includes(authRole))
  );

  const isStaff = Boolean(isModerator || isOwner || staffMember || profileData?.isStaff);

  const effectiveRole = isOwner 
    ? 'OWNER' 
    : (staffMember?.rank === 'SUPER_ADMIN' || profileData?.role === 'SUPER_ADMIN') 
    ? 'SUPER_ADMIN'
    : (staffMember?.rank === 'ADMINISTRATOR' || profileData?.role === 'ADMIN') 
    ? 'ADMIN'
    : isModerator 
    ? 'MODERATOR' 
    : isStaff 
    ? 'STAFF' 
    : 'MEMBER';

  // Points that he got
  const staffPoints = staffMember?.points ?? profileData?.staffInfo?.points ?? (isOwner ? 9999 : 0);
  const currentTier = getTierForPoints(staffPoints);
  const eligibleTier = getTierForPoints(staffPoints);
  const tierIndex = RANK_TIERS.findIndex(t => t.id === currentTier.id);
  const nextTier = (tierIndex >= 0 && tierIndex < RANK_TIERS.length - 1) ? RANK_TIERS[tierIndex + 1] : null;
  const moderatorLevel = tierIndex >= 0 ? tierIndex + 1 : Math.max(1, Math.floor(staffPoints / 10));

  const minPoints = currentTier.minPoints;
  const maxPoints = currentTier.maxPoints;
  const range = Math.max(1, maxPoints - minPoints);
  const staffProgressPercent = Math.min(100, Math.max(0, Math.round(((staffPoints - minPoints) / range) * 100)));

  // Application status: did he apply to it or not?
  const applicationStatus = staffMember 
    ? getStatusForMember(effectiveDiscordId, staffMember, eligibleTier.id)
    : 'NOT_APPLIED';
  const rankApplication = staffMember 
    ? getApplicationForMember(effectiveDiscordId, eligibleTier.id)
    : undefined;

  const handleApplyForRank = async () => {
    if (staffMember) {
      await applyForRank(staffMember, eligibleTier.id);
    }
  };

  const handleSaveCustomization = async (payload: {
    favoriteCardId?: string | null;
    showcaseCardIds?: string[];
    selectedTitleId?: string | null;
    featuredBadgeIds?: string[];
    bannerUrl?: string | null;
  }) => {
    const updated = await customizeProfile(payload);
    setProfileData(updated);
    return updated;
  };

  const handleSaveBanner = async (bannerUrl: string | null) => {
    const updated = await customizeProfile({ bannerUrl });
    setProfileData(updated);
  };

  const handleQuickSelectTitle = async (titleId: string) => {
    await setSelectedTitle(titleId);
    if (profileData) {
      setProfileData(prev => prev ? ({
        ...prev,
        selectedTitleId: titleId,
        selectedTitle: prev.allTitles.find(t => t.id === titleId) || prev.selectedTitle
      }) : null);
    }
  };

  const handleCopyDiscordId = () => {
    if (!effectiveDiscordId) return;
    navigator.clipboard.writeText(effectiveDiscordId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  // Not authenticated and visiting personal /profile
  if (!targetDiscordId && !authLoading && (!isAuthenticated || !user)) {
    return (
      <main className="min-h-screen pt-32 pb-20 px-4 max-w-xl mx-auto flex flex-col items-center justify-center text-center space-y-5">
        <div className="w-20 h-20 rounded-3xl bg-[#061e1b] border border-[rgba(158,255,230,0.25)] flex items-center justify-center text-[#5eead4] shadow-2xl">
          <User size={36} />
        </div>
        <div className="space-y-2">
          <h1 className="text-2xl sm:text-3xl font-display font-black text-white">
            {isAr ? 'الملف الشخصي الشامل للموقع' : 'Official Portal Profile'}
          </h1>
          <p className="text-sm text-[#8db8b1] leading-relaxed">
            {isAr 
              ? 'سجل دخولك عبر ديسكورد للوصول إلى هويتك الملكية، ورتبتك، ونقاطك، وتخصيص غلافك المفضل.'
              : 'Sign in with Discord to access your identity, roles, rank points, custom banner, and card collection.'}
          </p>
        </div>
        <button
          onClick={loginWithDiscord}
          className="flex items-center gap-2 px-6 py-3 rounded-2xl text-xs font-bold text-[#031211] bg-gradient-to-r from-amber-400 via-amber-300 to-[#5eead4] hover:brightness-110 shadow-xl shadow-cyan-500/20 transition-all cursor-pointer"
        >
          <Sparkles size={16} />
          <span>{isAr ? 'تسجيل الدخول عبر ديسكورد' : 'Sign in with Discord'}</span>
        </button>
      </main>
    );
  }

  // Loading state
  if (loading && !profileData) {
    return (
      <main className="min-h-screen pt-28 pb-20 px-4 flex flex-col items-center justify-center space-y-4">
        <Loader2 size={36} className="animate-spin text-[#5eead4]" />
        <p className="text-sm font-mono text-[#8db8b1] tracking-wide">
          {isAr ? 'جاري استحضار سجلات الملف الشخصي...' : 'Loading comprehensive user profile...'}
        </p>
      </main>
    );
  }

  if (!profileData) {
    return (
      <main className="min-h-screen pt-32 pb-20 px-4 max-w-lg mx-auto flex flex-col items-center justify-center text-center space-y-4">
        <div className="p-4 rounded-2xl bg-black/40 border border-white/10 text-rose-400">
          <Shield size={32} />
        </div>
        <h2 className="text-xl font-bold text-white">
          {isAr ? 'الملف الشخصي غير موجود' : 'Profile Not Found'}
        </h2>
        <p className="text-xs text-[#8db8b1]">
          {isAr 
            ? 'لم يتم العثور على سجلات لهذا المستخدم في أرشيف السيرفر.'
            : 'No user records were found in the community portal archives.'}
        </p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-[#5eead4] bg-[#5eead4]/10 hover:bg-[#5eead4]/20 border border-[#5eead4]/30 transition-all"
        >
          {isAr ? <ArrowRight size={14} /> : <ArrowLeft size={14} />}
          <span>{isAr ? 'العودة للصفحة الرئيسية' : 'Return Home'}</span>
        </Link>
      </main>
    );
  }

  return (
    <main className="min-h-screen pt-18 xs:pt-20 sm:pt-24 pb-20 sm:pb-24 px-2.5 xs:px-3.5 sm:px-6 lg:px-10 max-w-7xl mx-auto space-y-5 sm:space-y-8 w-full max-w-full min-w-0 box-border">
      {/* ========================================================================= */}
      {/* 1. UPGRADED PROFILE HEADER & CUSTOM BANNER (NO WORDS ABOVE)               */}
      {/* ========================================================================= */}
      <ProfileHeader
        profileData={profileData}
        isOwnProfile={isOwnProfile}
        onOpenEdit={() => setIsEditModalOpen(true)}
        onOpenBannerSelector={() => setIsBannerModalOpen(true)}
        onDirectUploadBanner={handleSaveBanner}
        staffMember={staffMember}
        effectiveRole={effectiveRole}
        moderatorLevel={moderatorLevel}
        currentTier={currentTier}
        nextTier={nextTier}
        isAr={isAr}
      />

      {/* ========================================================================= */}
      {/* 2. UNCOMPLICATED SECTION NAVIGATION CONTROLS                              */}
      {/* ========================================================================= */}
      <div 
        className="w-full max-w-full min-w-0 overflow-x-auto no-scrollbar pb-1 touch-pan-x"
        style={{ WebkitOverflowScrolling: 'touch' }}
      >
        <div className="inline-flex items-center gap-1 sm:gap-1.5 p-1 sm:p-1.5 rounded-2xl bg-black/60 backdrop-blur-xl border border-white/10 shadow-lg shrink-0">
          <button
            type="button"
            onClick={() => setActiveSection('all')}
            className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-xl text-[11px] sm:text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 sm:gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              activeSection === 'all'
                ? 'bg-gradient-to-r from-[#5eead4] via-[#2dd4bf] to-[#14b8a6] text-[#031211] shadow-md shadow-cyan-500/25 font-black'
                : 'text-[#8db8b1] hover:text-white hover:bg-white/5'
            }`}
          >
            <LayoutGrid size={13} className="shrink-0" />
            <span>{isAr ? 'عرض كل الأقسام' : 'All Sections'}</span>
          </button>

          {isStaff && (
            <button
              type="button"
              onClick={() => setActiveSection('dossier')}
              className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-xl text-[11px] sm:text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 sm:gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                activeSection === 'dossier'
                  ? 'bg-gradient-to-r from-indigo-500 via-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-500/30'
                  : 'text-indigo-300 hover:text-white hover:bg-indigo-950/40 border border-indigo-500/20'
              }`}
            >
              <Shield size={13} className="shrink-0" />
              <span>{isAr ? 'الملف الإداري والرتبة' : 'Role & Moderation'}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-black/40 text-amber-300 shrink-0">
                {staffPoints} PTS
              </span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setActiveSection('cards')}
            className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-xl text-[11px] sm:text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 sm:gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              activeSection === 'cards'
                ? 'bg-gradient-to-r from-[#5eead4] via-[#2dd4bf] to-[#14b8a6] text-[#031211] shadow-md shadow-cyan-500/25 font-black'
                : 'text-[#8db8b1] hover:text-white hover:bg-white/5'
            }`}
          >
            <Layers size={13} className="shrink-0" />
            <span>{isAr ? 'البطاقات والمعرض' : 'Cards & Showcase'}</span>
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-white/10 text-stone-300 shrink-0">
              {profileData.stats.uniqueCards}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('achievements')}
            className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-xl text-[11px] sm:text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 sm:gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              activeSection === 'achievements'
                ? 'bg-gradient-to-r from-[#5eead4] via-[#2dd4bf] to-[#14b8a6] text-[#031211] shadow-md shadow-cyan-500/25 font-black'
                : 'text-[#8db8b1] hover:text-white hover:bg-white/5'
            }`}
          >
            <Trophy size={13} className="shrink-0" />
            <span>{isAr ? 'الإنجازات والألقاب' : 'Achievements & Titles'}</span>
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-white/10 text-stone-300 shrink-0">
              {profileData.unlockedBadges.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('identity')}
            className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-xl text-[11px] sm:text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 sm:gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              activeSection === 'identity'
                ? 'bg-gradient-to-r from-[#5eead4] via-[#2dd4bf] to-[#14b8a6] text-[#031211] shadow-md shadow-cyan-500/25 font-black'
                : 'text-[#8db8b1] hover:text-white hover:bg-white/5'
            }`}
          >
            <User size={13} className="shrink-0" />
            <span>{isAr ? 'بيانات الحساب والهوية' : 'Account & Identity'}</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. MODERATOR DOSSIER SECTION (Points, Role, and If he applied or not)     */}
      {/* ========================================================================= */}
      {isStaff && (activeSection === 'all' || activeSection === 'dossier') && (
        <ModeratorDossierSection
          profileData={profileData}
          staffMember={staffMember}
          application={rankApplication}
          applicationStatus={applicationStatus}
          currentTier={currentTier}
          nextTier={nextTier}
          points={staffPoints}
          progressPercent={staffProgressPercent}
          isOwnProfile={isOwnProfile}
          onApplyForRank={handleApplyForRank}
          isAr={isAr}
        />
      )}

      {/* ========================================================================= */}
      {/* 4. CARDS & SHOWCASE SECTIONS                                              */}
      {/* ========================================================================= */}
      {(activeSection === 'all' || activeSection === 'cards') && (
        <div className="space-y-6 sm:space-y-8">
          {/* Favorite Card Section */}
          <FavoriteCardSection
            favoriteCard={profileData.favoriteCard}
            isOwnProfile={isOwnProfile}
            onOpenEdit={() => setIsEditModalOpen(true)}
            onClickDetail={(card) => setInspectCard(card)}
            isAr={isAr}
          />

          {/* 5-Card Showcase Section */}
          <ShowcaseSection
            showcaseCards={profileData.showcaseCards}
            isOwnProfile={isOwnProfile}
            onOpenEdit={() => setIsEditModalOpen(true)}
            onClickDetail={(card) => setInspectCard(card)}
            isAr={isAr}
          />

          {/* Collection Statistics */}
          <CollectionStatsSection
            stats={profileData.stats}
            isAr={isAr}
          />
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. ACHIEVEMENTS & TITLES SECTIONS                                         */}
      {/* ========================================================================= */}
      {(activeSection === 'all' || activeSection === 'achievements') && (
        <div className="space-y-6 sm:space-y-8">
          {/* Badges & Milestones */}
          <BadgesSection
            unlockedBadges={profileData.unlockedBadges}
            allBadges={profileData.allBadges}
            featuredBadgeIds={profileData.featuredBadgeIds}
            isOwnProfile={isOwnProfile}
            onOpenEdit={() => setIsEditModalOpen(true)}
            isAr={isAr}
          />

          {/* Unlocked Titles */}
          <TitlesSection
            unlockedTitles={profileData.unlockedTitles}
            allTitles={profileData.allTitles}
            selectedTitleId={profileData.selectedTitleId || null}
            isOwnProfile={isOwnProfile}
            onSelectTitle={handleQuickSelectTitle}
            isAr={isAr}
          />
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. ACCOUNT IDENTITY & DISCORD CREDENTIALS                                 */}
      {/* ========================================================================= */}
      {(activeSection === 'all' || activeSection === 'identity') && (
        <div className="rounded-2xl sm:rounded-3xl bg-gradient-to-br from-[#041619]/95 via-[#020e11]/98 to-[#01080a]/98 border border-[rgba(158,255,230,0.18)] p-3.5 xs:p-4 sm:p-7 shadow-xl space-y-3.5 sm:space-y-4 w-full max-w-full min-w-0 box-border overflow-hidden">
          <div className="flex items-center justify-between border-b border-white/10 pb-3 gap-2 flex-wrap min-w-0">
            <div className="flex items-center gap-2 xs:gap-2.5 min-w-0">
              <div className="p-1.5 xs:p-2 rounded-xl bg-[#5eead4]/15 text-[#5eead4] shrink-0">
                <User size={16} className="xs:w-[18px] xs:h-[18px]" />
              </div>
              <h3 className="text-sm xs:text-base font-bold text-white font-display truncate">
                {isAr ? 'بيانات توثيق الحساب والمجتمع' : 'Community Credentials & Discord Identity'}
              </h3>
            </div>
            <span className="text-[9px] xs:text-[10px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-full shrink-0">
              ACTIVE SESSION
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 xs:gap-3 pt-1 w-full min-w-0">
            {/* Discord ID */}
            <div className="p-3 xs:p-3.5 rounded-2xl bg-black/40 border border-white/5 flex items-center justify-between min-w-0 gap-2">
              <div className="min-w-0 flex-1">
                <p className="text-[10px] font-mono text-[#8db8b1] uppercase">Discord User ID</p>
                <p className="text-xs font-mono font-bold text-white break-all">
                  {effectiveDiscordId}
                </p>
              </div>
              <button
                type="button"
                onClick={handleCopyDiscordId}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-stone-300 hover:text-white transition-colors cursor-pointer shrink-0"
                title="Copy Discord ID"
              >
                {copiedId ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              </button>
            </div>

            {/* Portal Role */}
            <div className="p-3 xs:p-3.5 rounded-2xl bg-black/40 border border-white/5 min-w-0">
              <p className="text-[10px] font-mono text-[#8db8b1] uppercase">{isAr ? 'الرتبة الرسمية' : 'Portal Role'}</p>
              <p className="text-xs font-mono font-bold text-[#5eead4] truncate">
                {effectiveRole}
              </p>
            </div>

            {/* Member Since / Joined */}
            <div className="p-3 xs:p-3.5 rounded-2xl bg-black/40 border border-white/5 min-w-0">
              <p className="text-[10px] font-mono text-[#8db8b1] uppercase">{isAr ? 'تاريخ الانضمام' : 'Registered At'}</p>
              <p className="text-xs font-mono font-bold text-white truncate">
                {profileData.joinedAt ? new Date(profileData.joinedAt).toLocaleDateString() : (isAr ? 'عضوية معتمدة' : 'Verified')}
              </p>
            </div>

            {/* Coins Balance */}
            <div className="p-3 xs:p-3.5 rounded-2xl bg-black/40 border border-white/5 min-w-0">
              <p className="text-[10px] font-mono text-[#8db8b1] uppercase">{isAr ? 'رصيد العملات' : 'Coin Vault'}</p>
              <p className="text-xs font-mono font-bold text-amber-300 truncate">
                {profileData.coins.toLocaleString()} 🪙
              </p>
            </div>
          </div>

          {/* Discord Server Roles Badges */}
          {Array.isArray(profileData.roleNames) && profileData.roleNames.length > 0 && (
            <div className="pt-2 w-full min-w-0">
              <p className="text-[10px] font-mono text-[#8db8b1] uppercase mb-1.5">
                {isAr ? 'رتب ديسكورد الرسمية بالسيرفر:' : 'Assigned Discord Roles:'}
              </p>
              <div className="flex items-center gap-1.5 flex-wrap w-full min-w-0">
                {profileData.roleNames.map((roleTitle, idx) => (
                  <span
                    key={idx}
                    className="px-2 xs:px-2.5 py-0.5 rounded-lg text-[10px] font-mono font-semibold bg-white/5 text-stone-200 border border-white/10 break-words [overflow-wrap:anywhere] max-w-full"
                  >
                    @{roleTitle}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODALS                                                                    */}
      {/* ========================================================================= */}

      {/* Banner Selector Modal */}
      {isOwnProfile && (
        <BannerSelectorModal
          isOpen={isBannerModalOpen}
          onClose={() => setIsBannerModalOpen(false)}
          currentBannerUrl={profileData.bannerUrl}
          userAvatarUrl={profileData.avatarUrl}
          displayName={profileData.displayName}
          onSaveBanner={handleSaveBanner}
          isAr={isAr}
        />
      )}

      {/* Profile Customizer Modal */}
      {isOwnProfile && (
        <ProfileCustomizerModal
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          profileData={profileData}
          catalog={catalog}
          onSave={handleSaveCustomization}
          isAr={isAr}
        />
      )}

      {/* Card Detail Modal */}
      <CardDetailModal
        card={inspectCard}
        onClose={() => setInspectCard(null)}
      />
    </main>
  );
};
