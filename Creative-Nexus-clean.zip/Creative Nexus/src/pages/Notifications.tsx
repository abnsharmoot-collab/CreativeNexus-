import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { 
  Bell, 
  CheckCheck, 
  RotateCw, 
  Search, 
  Filter, 
  Coins, 
  FileText, 
  Trophy, 
  Shield, 
  Megaphone,
  CheckCircle2,
  Sparkles,
  BookOpen
} from 'lucide-react';
import { useNotifications, NotificationFilter } from '../context/NotificationContext';
import { NotificationItemCard } from '../components/notifications/NotificationItemCard';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';

export const Notifications: React.FC = () => {
  const { 
    notifications, 
    unreadCount, 
    totalCount, 
    loading, 
    filter, 
    setFilter, 
    markAsRead, 
    markAllAsRead, 
    deleteNotification,
    refreshNotifications 
  } = useNotifications();
  const { user, isAuthenticated } = useAuth();
  const { language, t } = useLanguage();
  const isAr = language === 'ar';

  const [searchQuery, setSearchQuery] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await refreshNotifications();
    setTimeout(() => setIsRefreshing(false), 500);
  };

  // Filter and search
  const displayedNotifications = useMemo(() => {
    return notifications.filter((item) => {
      // 1. Category Filter
      let matchesFilter = true;
      switch (filter) {
        case 'UNREAD':
          matchesFilter = !item.read;
          break;
        case 'POINTS':
          matchesFilter = item.type === 'POINTS_ADDED' || item.type === 'POINTS_REMOVED';
          break;
        case 'RANK':
          matchesFilter =
            item.type === 'RANK_APPLICATION_SUBMITTED' ||
            item.type === 'RANK_APPLICATION_APPROVED' ||
            item.type === 'RANK_APPLICATION_REJECTED';
          break;
        case 'ACHIEVEMENT':
          matchesFilter = item.type === 'ACHIEVEMENT_EARNED';
          break;
        case 'STAFF':
          matchesFilter = item.type === 'STAFF_STATUS_CHANGED';
          break;
        case 'ANNOUNCEMENT':
          matchesFilter = item.type === 'ANNOUNCEMENT';
          break;
        case 'ALL':
        default:
          matchesFilter = true;
      }

      if (!matchesFilter) return false;

      // 2. Search Query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const titleMatch = item.title.toLowerCase().includes(query);
        const descMatch = item.description.toLowerCase().includes(query);
        return titleMatch || descMatch;
      }

      return true;
    });
  }, [notifications, filter, searchQuery]);

  const filterTabs: { id: NotificationFilter; label: string; icon: React.ReactNode; count?: number }[] = [
    { 
      id: 'ALL', 
      label: t('notifications.filterAll'), 
      icon: <Bell size={14} />,
      count: totalCount 
    },
    { 
      id: 'UNREAD', 
      label: t('notifications.filterUnread'), 
      icon: <Sparkles size={14} className="text-archive-cyan" />,
      count: unreadCount 
    },
    { 
      id: 'POINTS', 
      label: t('notifications.filterPoints'), 
      icon: <Coins size={14} className="text-emerald-400" /> 
    },
    { 
      id: 'RANK', 
      label: t('notifications.filterRank'), 
      icon: <FileText size={14} className="text-cyan-400" /> 
    },
    { 
      id: 'ACHIEVEMENT', 
      label: t('notifications.filterAchievement'), 
      icon: <Trophy size={14} className="text-yellow-400" /> 
    },
    { 
      id: 'STAFF', 
      label: t('notifications.filterStaff'), 
      icon: <Shield size={14} className="text-purple-400" /> 
    },
    { 
      id: 'ANNOUNCEMENT', 
      label: t('notifications.filterAnnouncement'), 
      icon: <Megaphone size={14} className="text-sky-400" /> 
    }
  ];

  return (
    <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Header Banner */}
      <div className="relative rounded-2xl bg-gradient-to-b from-white/[0.05] to-white/[0.01] border border-white/10 p-6 sm:p-8 mb-8 overflow-hidden">
        {/* Subtle Ambient Glow */}
        <div className="absolute top-0 -right-20 w-80 h-80 bg-archive-cyan/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 -left-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-archive-cyan/10 border border-archive-cyan/20 text-archive-cyan text-xs font-semibold tracking-wider uppercase">
                <Bell size={13} />
                <span>CREATINE NEXUS DISPATCH</span>
              </div>
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight">
              {t('notifications.title')}
            </h1>
            <p className="text-sm sm:text-base text-white/60 mt-1 max-w-2xl leading-relaxed">
              {t('notifications.subtitle')}
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 shrink-0">
            <Link
              to="/codex/guide-notifications"
              className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-archive-cyan/10 hover:bg-archive-cyan/20 text-xs font-semibold text-archive-cyan border border-archive-cyan/25 transition-colors"
            >
              <BookOpen size={14} />
              <span>{isAr ? 'دليل الإشعارات' : 'Notifications Guide'}</span>
            </Link>

            <button
              id="btn-refresh-notifications"
              type="button"
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-white/80 hover:text-white border border-white/10 transition-colors disabled:opacity-50"
              title="Refresh notifications"
            >
              <RotateCw size={14} className={isRefreshing ? 'animate-spin' : ''} />
              <span className="hidden sm:inline">Refresh</span>
            </button>

            {unreadCount > 0 && (
              <button
                id="btn-mark-all-read-page"
                type="button"
                onClick={markAllAsRead}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-archive-cyan/15 hover:bg-archive-cyan/25 text-archive-cyan border border-archive-cyan/30 text-xs font-bold transition-all shadow-sm shadow-archive-cyan/20"
              >
                <CheckCheck size={16} />
                <span>{t('notifications.markAllRead')}</span>
              </button>
            )}
          </div>
        </div>

        {/* Stats Row */}
        <div className="relative z-10 mt-6 pt-6 border-t border-white/5 flex flex-wrap items-center gap-6">
          <div className="flex items-center gap-2.5">
            <span className="text-xs text-white/50">{t('notifications.all')}:</span>
            <span className="px-2.5 py-0.5 rounded-lg bg-white/5 text-xs font-bold text-white border border-white/10 tabular-nums">
              {totalCount}
            </span>
          </div>
          <div className="flex items-center gap-2.5">
            <span className="text-xs text-white/50">{t('notifications.unread')}:</span>
            <span className="px-2.5 py-0.5 rounded-lg bg-archive-cyan/15 text-xs font-bold text-archive-cyan border border-archive-cyan/25 tabular-nums">
              {unreadCount}
            </span>
          </div>
          {user && (
            <div className="hidden sm:flex items-center gap-2 text-xs text-white/40 ml-auto">
              <span>Account:</span>
              <span className="font-semibold text-white/80">{user.displayName || user.username}</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-white/10 text-archive-cyan border border-white/10">
                {user.role}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Control Bar: Search & Category Tabs */}
      <div className="space-y-4 mb-6">
        {/* Search Input */}
        <div className="relative">
          <Search
            size={16}
            className={`absolute top-1/2 -translate-y-1/2 text-white/40 pointer-events-none ${
              isAr ? 'right-3.5' : 'left-3.5'
            }`}
          />
          <input
            id="input-notifications-search"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search notification titles or descriptions..."
            className={`w-full bg-white/[0.03] border border-white/10 rounded-xl py-2.5 text-sm text-white placeholder-white/40 focus:outline-none focus:border-archive-cyan/50 focus:bg-white/[0.05] transition-all ${
              isAr ? 'pr-10 pl-4 text-right' : 'pl-10 pr-4'
            }`}
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className={`absolute top-1/2 -translate-y-1/2 text-xs text-white/40 hover:text-white ${
                isAr ? 'left-3' : 'right-3'
              }`}
            >
              Clear
            </button>
          )}
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {filterTabs.map((tab) => {
            const isActive = filter === tab.id;
            return (
              <button
                key={tab.id}
                id={`filter-tab-${tab.id.toLowerCase()}`}
                type="button"
                onClick={() => setFilter(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all duration-200 border ${
                  isActive
                    ? 'bg-archive-cyan/15 text-archive-cyan border-archive-cyan/40 shadow-sm font-semibold'
                    : 'bg-white/[0.02] text-white/60 hover:text-white hover:bg-white/[0.06] border-white/5'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
                {typeof tab.count === 'number' && (
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full tabular-nums ${
                      isActive
                        ? 'bg-archive-cyan text-archive-dark font-bold'
                        : 'bg-white/10 text-white/70'
                    }`}
                  >
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Notifications List */}
      <div className="space-y-3">
        {loading ? (
          <div className="rounded-2xl bg-white/[0.02] border border-white/5 p-12 text-center">
            <div className="w-8 h-8 border-2 border-archive-cyan/30 border-t-archive-cyan rounded-full animate-spin mx-auto mb-3" />
            <p className="text-sm text-white/50">Synchronizing notification archive...</p>
          </div>
        ) : displayedNotifications.length === 0 ? (
          <div className="rounded-2xl bg-white/[0.02] border border-white/5 p-12 sm:p-16 text-center">
            <div className="w-16 h-16 rounded-2xl bg-white/5 text-white/30 flex items-center justify-center mx-auto mb-4 border border-white/10">
              <CheckCircle2 size={32} className="text-archive-cyan/60" />
            </div>
            <h3 className="text-base sm:text-lg font-semibold text-white mb-1">
              {filter === 'UNREAD'
                ? t('notifications.emptyUnread')
                : t('notifications.empty')}
            </h3>
            <p className="text-xs sm:text-sm text-white/50 max-w-md mx-auto leading-relaxed">
              {searchQuery
                ? `No notifications found matching "${searchQuery}".`
                : t('notifications.emptyDesc')}
            </p>
          </div>
        ) : (
          displayedNotifications.map((notification) => (
            <NotificationItemCard
              key={notification.id}
              notification={notification}
              onMarkAsRead={markAsRead}
              onDelete={deleteNotification}
            />
          ))
        )}
      </div>
    </main>
  );
};
