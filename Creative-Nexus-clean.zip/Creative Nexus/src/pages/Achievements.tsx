import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, 
  Award, 
  Sparkles, 
  Lock, 
  CheckCircle2, 
  Search, 
  Coins,
  TrendingUp,
  Shield,
  Crown,
  BookOpen,
  Check,
  Loader2,
  X,
  Zap,
  Gift
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useStaff } from '../context/StaffContext';
import { useLanguage } from '../context/LanguageContext';
import { useAchievements, UserAchievementStatus } from '../context/AchievementContext';
import { ACHIEVEMENT_CATEGORIES, AchievementCategory, isStaffOnlyAchievement } from '../types/achievements';
import { AchievementCard } from '../components/achievements/AchievementCard';
import { Button } from '../components/atoms/Button';

export const Achievements: React.FC = () => {
  const { user, isAuthenticated, role, loginWithDiscord } = useAuth();
  const { staff } = useStaff();
  const { language } = useLanguage();
  const isAr = language === 'ar';

  const { 
    achievements, 
    stats, 
    loading, 
    isStaff, 
    roleMultiplier, 
    markAsSeen,
    claimAllRewards 
  } = useAchievements();

  const [selectedCategory, setSelectedCategory] = useState<AchievementCategory | 'all'>('all');
  const [filterState, setFilterState] = useState<'all' | 'claimable' | 'unlocked' | 'locked'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isClaimingAll, setIsClaimingAll] = useState(false);
  const [claimSuccessMessage, setClaimSuccessMessage] = useState<string | null>(null);

  // Authenticated user's staff profile
  const currentStaffMember = useMemo(() => {
    if (!user) return undefined;
    return staff.find((s) => s.discordId === user.discordId && s.status !== 'REMOVED');
  }, [user, staff]);

  // Mark single achievement as seen when its reveal completes
  const handleRevealComplete = (id: string) => {
    markAsSeen([id]);
  };

  // Visible achievements: Staff achievements are for staff members only; community/cards/packages are for everyone
  const visibleAchievements = useMemo(() => {
    return achievements.filter((item) => {
      const isStaffOnly = isStaffOnlyAchievement(item.definition);
      if (isStaffOnly && !isStaff) {
        return false;
      }
      return true;
    });
  }, [achievements, isStaff]);

  // Available categories: Hide staff-only categories from non-staff visitors
  const availableCategories = useMemo(() => {
    if (isStaff) return ACHIEVEMENT_CATEGORIES;
    return ACHIEVEMENT_CATEGORIES.filter(cat => 
      !['progression', 'points', 'activity', 'promotions', 'applications', 'sections'].includes(cat.id)
    );
  }, [isStaff]);

  // Claimable achievements list
  const claimableList = useMemo(() => {
    return visibleAchievements.filter(a => a.canClaim);
  }, [visibleAchievements]);

  const claimableCoinsTotal = useMemo(() => {
    return claimableList.reduce((acc, a) => acc + (a.calculatedReward || a.baseReward || 10), 0);
  }, [claimableList]);

  // Claim all rewards handler
  const handleClaimAll = async () => {
    if (isClaimingAll || !claimableList.length) return;
    if (!isAuthenticated) {
      loginWithDiscord();
      return;
    }

    setIsClaimingAll(true);
    try {
      const res = await claimAllRewards();
      if (res.totalCoins > 0) {
        setClaimSuccessMessage(
          isAr
            ? `تهانينا! تم استلام ${res.count} إنجازات وإيداع +${res.totalCoins} عملة بنجاح!`
            : `Success! Claimed ${res.count} achievements and awarded +${res.totalCoins} coins!`
        );
        setTimeout(() => setClaimSuccessMessage(null), 4500);
      }
    } catch (err) {
      console.error('Error claiming all rewards:', err);
    } finally {
      setIsClaimingAll(false);
    }
  };

  // Filter and search achievements
  const filteredAchievements = useMemo(() => {
    return visibleAchievements.filter((item) => {
      // Category filter
      if (selectedCategory !== 'all' && item.definition.category !== selectedCategory) {
        return false;
      }

      // Status filter
      if (filterState === 'claimable' && !item.canClaim) return false;
      if (filterState === 'unlocked' && !item.isUnlocked) return false;
      if (filterState === 'locked' && item.isUnlocked) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = item.definition.name.toLowerCase().includes(q);
        const matchesNameAr = item.definition.nameAr.toLowerCase().includes(q);
        const matchesDesc = item.definition.description.toLowerCase().includes(q);
        const matchesDescAr = item.definition.descriptionAr.toLowerCase().includes(q);
        return matchesName || matchesNameAr || matchesDesc || matchesDescAr;
      }

      return true;
    });
  }, [visibleAchievements, selectedCategory, filterState, searchQuery]);

  const unlockedCount = visibleAchievements.filter(a => a.isUnlocked).length;
  const totalCount = visibleAchievements.length;
  const completionPercent = totalCount > 0 ? Math.round((unlockedCount / totalCount) * 100) : 0;

  return (
    <main
      id="achievements-page"
      className="flex-1 pt-24 sm:pt-28 pb-32 px-3.5 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-6 sm:space-y-8 relative z-10 box-border"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* ========================================================================= */}
      {/* 1. UPGRADED HERO BANNER & STATS BAR                                       */}
      {/* ========================================================================= */}
      <div className="relative rounded-3xl bg-gradient-to-b from-[#031d20]/90 via-[#021417]/95 to-[#01090b]/98 border border-[rgba(158,255,230,0.22)] p-5 sm:p-8 shadow-[0_20px_50px_rgba(0,0,0,0.85)] overflow-hidden">
        {/* Ambient subtle cyan/gold glow in background */}
        <div className="absolute top-0 end-0 w-96 h-96 bg-cyan-500/10 blur-3xl pointer-events-none rounded-full" />
        <div className="absolute bottom-0 start-0 w-96 h-96 bg-amber-500/10 blur-3xl pointer-events-none rounded-full" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2.5 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-amber-500/15 text-amber-300 border border-amber-500/30 shrink-0">
                <Trophy size={16} />
              </span>
              <span className="text-xs font-mono font-bold tracking-wider text-amber-300 uppercase">
                {isAr ? 'سجل إنجازات وأوسمة الملاذ' : 'CREATINE NEXUS HALL OF ACHIEVEMENTS'}
              </span>
              {roleMultiplier.multiplier > 1.0 && (
                <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  <Zap size={10} />
                  <span>{roleMultiplier.multiplier.toFixed(1)}x {isAr ? 'مضاعف الرتبة' : 'Multiplier'}</span>
                </span>
              )}
            </div>

            <h1 className="font-display font-bold text-2xl sm:text-4xl text-white tracking-tight leading-tight">
              {isStaff 
                ? (isAr ? 'لوحة إنجازات الطاقم والملاذ' : 'Staff & Sanctuary Achievements Showcase')
                : (isAr ? 'لوحة إنجازات المجتمع والملاذ' : 'Community & Sanctuary Achievements Showcase')}
            </h1>

            <p className="font-sans text-xs sm:text-sm text-[#8db8b1] leading-relaxed">
              {isStaff
                ? (isAr
                    ? 'إنجازات موثقة ومتزامنة فورياً مع تصرفاتك بالموقع، حزم البطاقات ومسيرتك الإدارية — تمنح عملات وتتضاعف مع رتبتك حتى 3x.'
                    : 'Real-time documented achievements honoring your community actions, card collections, and administrative journey with progressive coin rewards.')
                : (isAr
                    ? 'إنجازات مفتوحة لجميع رواد الملاذ — استكشف الموقع، افتح حزم البطاقات، اجمع البطاقات النادرة واستلم عملاتك فورياً.'
                    : 'Universal achievements open to all visitors — explore the portal, open packs, collect rare cards and claim real coin rewards.')}
            </p>
          </div>

          {/* User Progress Summary Widget */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 bg-black/50 border border-white/10 rounded-2xl p-4 sm:p-5 shrink-0 backdrop-blur-xl">
            {/* Progress ratio */}
            <div className="flex items-center gap-3.5">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500/20 via-cyan-500/15 to-purple-500/20 border border-amber-500/30 flex flex-col items-center justify-center text-amber-300 shrink-0 shadow-[0_0_15px_rgba(245,158,11,0.15)]">
                <span className="text-base font-mono font-bold leading-none">
                  {unlockedCount}
                </span>
                <span className="text-[10px] font-mono text-slate-400 leading-none mt-1">
                  / {totalCount}
                </span>
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-300 font-medium">
                    {isAr ? 'معدل الإنجاز' : 'Completion'}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#5eead4]">
                    {completionPercent}%
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-36 sm:w-44 h-2 bg-black/60 rounded-full overflow-hidden border border-white/10">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-400 via-amber-300 to-emerald-400 rounded-full transition-all duration-500"
                    style={{ width: `${completionPercent}%` }}
                  />
                </div>

                <div className="flex items-center gap-2 text-[11px] text-[#8db8b1]">
                  <span>{claimableList.length} {isAr ? 'مكافأة قابلة للاستلام' : 'claimable'}</span>
                </div>
              </div>
            </div>

            {/* Quick Links */}
            <div className="sm:border-s sm:border-white/10 sm:ps-4 flex flex-row sm:flex-col gap-2 justify-center">
              <Link to="/codex/guide-achievements" className="flex-1 sm:flex-initial">
                <Button
                  variant="outline"
                  className="w-full text-xs font-semibold py-1.5 px-3 bg-black/40 hover:bg-black/80 border-amber-500/30 text-amber-300 justify-center gap-1.5"
                >
                  <BookOpen size={13} className="text-amber-400" />
                  <span>{isAr ? 'الدليل' : 'Guide'}</span>
                </Button>
              </Link>

              {isStaff && (
                <Link to="/rank-points" className="flex-1 sm:flex-initial">
                  <Button
                    variant="outline"
                    className="w-full text-xs font-semibold py-1.5 px-3 bg-black/40 hover:bg-black/80 border-cyan-500/30 text-[#5eead4] justify-center gap-1.5"
                  >
                    <TrendingUp size={13} className="text-[#5eead4]" />
                    <span>{isAr ? 'الرتب' : 'Rank Map'}</span>
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>

        {/* Claim All Rewards Alert Banner (Shows when rewards are waiting) */}
        {claimableList.length > 0 && (
          <div className="mt-5 p-3.5 sm:p-4 rounded-2xl bg-gradient-to-r from-amber-500/15 via-[#5eead4]/15 to-amber-500/10 border border-amber-400/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-amber-400 text-black font-bold shrink-0 shadow-md">
                <Gift size={18} />
              </div>
              <div>
                <p className="text-xs sm:text-sm font-bold text-white">
                  {isAr 
                    ? `لديك ${claimableList.length} إنجازات جاهزة للاستلام بمجموع (+${claimableCoinsTotal} عملة)!`
                    : `You have ${claimableList.length} claimable rewards totaling (+${claimableCoinsTotal} coins)!`}
                </p>
                <p className="text-[11px] text-[#8db8b1]">
                  {isAr 
                    ? 'انقر على استلام الكل لتضاف جميع العملات فورياً إلى محفظتك.'
                    : 'Click Claim All to deposit all coins directly into your vault balance.'}
                </p>
              </div>
            </div>

            <button
              type="button"
              disabled={isClaimingAll}
              onClick={handleClaimAll}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl text-xs font-bold text-[#031211] bg-gradient-to-r from-amber-400 to-[#5eead4] hover:brightness-110 active:scale-95 shadow-md shadow-amber-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 shrink-0"
            >
              {isClaimingAll ? (
                <Loader2 size={14} className="animate-spin text-black" />
              ) : (
                <Coins size={14} className="text-black" />
              )}
              <span>{isClaimingAll ? (isAr ? 'جاري الاستلام...' : 'Claiming...') : (isAr ? `استلام الكل (+${claimableCoinsTotal} 🪙)` : `Claim All (+${claimableCoinsTotal} 🪙)`)}</span>
            </button>
          </div>
        )}

        {/* Global Feedback message when Claim All succeeds */}
        <AnimatePresence>
          {claimSuccessMessage && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mt-4 p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 font-mono font-bold"
            >
              <Check size={14} className="text-emerald-400" />
              <span>{claimSuccessMessage}</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ========================================================================= */}
      {/* 2. FILTER & CATEGORY NAVIGATION BAR                                       */}
      {/* ========================================================================= */}
      <div className="space-y-4">
        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          <button
            type="button"
            onClick={() => setSelectedCategory('all')}
            className={`shrink-0 px-3.5 py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-[#5eead4] text-[#031211] border-[#5eead4] shadow-md shadow-cyan-500/20 font-black'
                : 'bg-black/40 text-[#8db8b1] border-white/10 hover:bg-white/5 hover:text-white'
            }`}
          >
            {isAr ? `الكل (${visibleAchievements.length})` : `All (${visibleAchievements.length})`}
          </button>

          {availableCategories.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            const categoryAchievements = visibleAchievements.filter((a) => a.definition.category === cat.id);
            const categoryCount = categoryAchievements.length;
            const unlockedInCat = categoryAchievements.filter((a) => a.isUnlocked).length;

            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`shrink-0 px-3.5 py-2 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 cursor-pointer ${
                  isSelected
                    ? 'bg-[#5eead4]/15 text-[#5eead4] border-[#5eead4] shadow-md shadow-cyan-500/15'
                    : 'bg-black/40 text-[#8db8b1] border-white/10 hover:bg-white/5 hover:text-white'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{isAr ? cat.nameAr : cat.name}</span>
                <span className="text-[10px] font-mono opacity-70">
                  ({unlockedInCat}/{categoryCount})
                </span>
              </button>
            );
          })}
        </div>

        {/* Search Bar & Status Filter segmented control */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-black/40 p-3 rounded-2xl border border-white/10">
          {/* Search box */}
          <div className="relative w-full sm:max-w-xs">
            <Search
              size={14}
              className={`absolute top-1/2 -translate-y-1/2 text-slate-500 ${
                isAr ? 'right-3' : 'left-3'
              }`}
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isAr ? 'ابحث عن إنجاز بالاسم أو الوصف...' : 'Search achievements...'}
              className={`w-full text-xs bg-black/60 border border-white/10 rounded-xl py-2 text-white placeholder:text-slate-600 focus:outline-none focus:border-[#5eead4] ${
                isAr ? 'pr-9 pl-8' : 'pl-9 pr-8'
              }`}
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className={`absolute top-1/2 -translate-y-1/2 text-slate-400 hover:text-white ${
                  isAr ? 'left-2.5' : 'right-2.5'
                }`}
              >
                <X size={12} />
              </button>
            )}
          </div>

          {/* Status Filters */}
          <div className="flex items-center gap-1.5 w-full sm:w-auto justify-end overflow-x-auto no-scrollbar">
            <button
              type="button"
              onClick={() => setFilterState('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                filterState === 'all'
                  ? 'bg-white/15 text-white'
                  : 'text-[#8db8b1] hover:text-white'
              }`}
            >
              {isAr ? 'الكل' : 'All'}
            </button>

            <button
              type="button"
              onClick={() => setFilterState('claimable')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                filterState === 'claimable'
                  ? 'bg-amber-500/25 text-amber-300 border border-amber-500/40'
                  : 'text-amber-400/80 hover:text-amber-300'
              }`}
            >
              <Coins size={12} className="text-amber-400" />
              <span>{isAr ? `قابلة للاستلام (${claimableList.length})` : `Claimable (${claimableList.length})`}</span>
            </button>

            <button
              type="button"
              onClick={() => setFilterState('unlocked')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                filterState === 'unlocked'
                  ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30'
                  : 'text-[#8db8b1] hover:text-emerald-300'
              }`}
            >
              <CheckCircle2 size={12} />
              <span>{isAr ? 'المكتملة' : 'Unlocked'}</span>
            </button>

            <button
              type="button"
              onClick={() => setFilterState('locked')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                filterState === 'locked'
                  ? 'bg-black/60 text-slate-300 border border-white/15'
                  : 'text-[#8db8b1] hover:text-white'
              }`}
            >
              <Lock size={12} />
              <span>{isAr ? 'المغلقة' : 'Locked'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. ACHIEVEMENTS GRID (SMOOTH IN-VIEW PLACEMENT INTO HOLE, ZERO SHAKING)   */}
      {/* ========================================================================= */}
      <div>
        {filteredAchievements.length === 0 ? (
          <div className="text-center py-20 bg-black/40 rounded-3xl border border-white/10 space-y-3">
            <Trophy size={36} className="mx-auto text-slate-600" />
            <p className="text-sm font-semibold text-slate-300">
              {isAr ? 'لا توجد إنجازات تطابق الفلتر المحدد' : 'No achievements match the selected filter.'}
            </p>
            <p className="text-xs text-slate-500">
              {isAr ? 'جرّب تعديل عبارة البحث أو إعادة ضبط الفلتر' : 'Try adjusting your search query or reset filter.'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5">
            {filteredAchievements.map((achievement, idx) => (
              <AchievementCard
                key={achievement.definition.id}
                achievement={achievement}
                index={idx}
                isAr={isAr}
                onRevealComplete={handleRevealComplete}
              />
            ))}
          </div>
        )}
      </div>

      {/* Hall of Legends Colophon */}
      <div className="pt-10 pb-4 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-white/10 text-xs font-mono text-[#8db8b1]">
        <div className="flex items-center gap-2">
          <span>CREATINE NEXUS // SANCTUARY ARCHIVAL REGISTRY</span>
        </div>
        <span>{visibleAchievements.length} {isAr ? 'إنجازاً موثقاً' : 'Documented Achievements'}</span>
      </div>
    </main>
  );
};

export default Achievements;
