import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { useEasterEggs } from '../context/EasterEggContext';
import { StoryTimeline } from '../components/history/StoryTimeline';
import { OwnersTimeline } from '../components/history/OwnersTimeline';
import { EdgarCrownCard } from '../components/home/EdgarCrownCard';
import { 
  Sparkles, 
  Flame, 
  Shield, 
  Crown, 
  Sun, 
  Users, 
  Scroll, 
  ArrowUp,
  Compass,
  CheckCircle2
} from 'lucide-react';

interface QuickJumpItem {
  id: string;
  href: string;
  labelAr: string;
  labelEn: string;
  eraAr: string;
  eraEn: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  accentColor: string;
  glowColor: string;
}

export function History() {
  const { t, language } = useLanguage();
  const { activeTheme } = useEasterEggs();
  const isMesopotamian = activeTheme === 'kohan-iraqi';
  const isRtl = language === 'ar';

  const [activeSection, setActiveSection] = useState<string>('chapter-01');
  const [showFloatingDock, setShowFloatingDock] = useState<boolean>(false);

  const QUICK_JUMPS: QuickJumpItem[] = [
    { 
      id: 'chapter-01',
      href: '#chapter-01', 
      labelAr: 'البداية', 
      labelEn: 'Genesis',
      eraAr: '2023',
      eraEn: '2023',
      icon: Sparkles,
      accentColor: 'from-cyan-500/20 to-teal-500/10 border-cyan-400/30 text-cyan-200',
      glowColor: 'shadow-[0_0_15px_rgba(6,182,212,0.25)]'
    },
    { 
      id: 'chapter-02',
      href: '#chapter-02', 
      labelAr: 'السقوط', 
      labelEn: 'The Fall',
      eraAr: '2023',
      eraEn: '2023',
      icon: Flame,
      accentColor: 'from-rose-500/20 to-red-500/10 border-rose-400/30 text-rose-200',
      glowColor: 'shadow-[0_0_15px_rgba(244,63,94,0.25)]'
    },
    { 
      id: 'chapter-03',
      href: '#chapter-03', 
      labelAr: 'النهوض', 
      labelEn: 'The Rise',
      eraAr: '2024',
      eraEn: '2024',
      icon: Shield,
      accentColor: 'from-purple-500/20 to-indigo-500/10 border-purple-400/30 text-purple-200',
      glowColor: 'shadow-[0_0_15px_rgba(168,85,247,0.25)]'
    },
    { 
      id: 'chapter-04',
      href: '#chapter-04', 
      labelAr: 'العصر الذهبي', 
      labelEn: 'Golden Era', 
      eraAr: '2024',
      eraEn: '2024',
      icon: Crown,
      accentColor: 'from-amber-500/20 to-yellow-500/10 border-amber-400/40 text-amber-200',
      glowColor: 'shadow-[0_0_18px_rgba(245,158,11,0.3)]'
    },
    { 
      id: 'sovereign-crown',
      href: '#sovereign-crown', 
      labelAr: 'عرش إيدجر', 
      labelEn: 'Edgar Crown',
      eraAr: 'السيادة',
      eraEn: 'Sovereign',
      icon: Sun,
      accentColor: 'from-amber-400/25 to-orange-500/15 border-amber-300/50 text-yellow-200',
      glowColor: 'shadow-[0_0_18px_rgba(251,191,36,0.35)]'
    },
    { 
      id: 'owners', 
      href: '#owners',
      labelAr: 'ملاك كريتيف', 
      labelEn: 'Owners of Creative',
      eraAr: 'الأرشيف',
      eraEn: 'Chronicle',
      icon: Crown,
      accentColor: 'from-amber-500/20 to-yellow-500/10 border-amber-400/30 text-amber-200',
      glowColor: 'shadow-[0_0_15px_rgba(245,158,11,0.25)]'
    },
  ];

  // Track scroll position for floating quick-jump dock and active section spy
  useEffect(() => {
    try {
      localStorage.setItem('cn_history_explored', 'true');
      localStorage.setItem('creatine_history_explored', 'true');
      localStorage.setItem('nexus_history_read', 'true');
      window.dispatchEvent(new Event('storage'));
    } catch {}

    const handleScroll = () => {
      const scrollPos = window.scrollY;
      setShowFloatingDock(scrollPos > 400);

      // Section spy
      const sections = QUICK_JUMPS.map(j => document.getElementById(j.id)).filter(Boolean) as HTMLElement[];
      for (let i = sections.length - 1; i >= 0; i--) {
        const sec = sections[i];
        const rect = sec.getBoundingClientRect();
        if (rect.top <= 200) {
          setActiveSection(sec.id);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSmoothScroll = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <main className={`min-h-screen pt-24 sm:pt-28 pb-24 px-4 sm:px-6 md:px-10 relative z-10 overflow-x-hidden ${
      isMesopotamian ? 'bg-transparent text-amber-100' : 'bg-[#031211] text-[#eafffa]'
    }`}>
      {/* Background Soft Gradients */}
      <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
        {isMesopotamian ? null : (
          <>
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[850px] h-[500px] bg-gradient-to-b from-teal-950/30 via-[#031211] to-transparent blur-[140px] opacity-80" />
            <div className="absolute top-1/3 end-0 w-[550px] h-[600px] bg-gradient-to-l from-cyan-900/15 to-transparent blur-[160px] opacity-60" />
            <div className="absolute bottom-1/4 start-0 w-[550px] h-[600px] bg-gradient-to-r from-emerald-950/20 to-transparent blur-[160px] opacity-50" />
          </>
        )}
      </div>

      <div className="max-w-5xl mx-auto">
        {/* ============================================================ */}
        {/* PAGE HERO (Clean, Minimal, Modern)                           */}
        {/* ============================================================ */}
        <header className="relative pt-6 sm:pt-10 pb-10 sm:pb-14 text-center">
          {/* Main Title with 3D Volumetric Extrusion & Radiant Glow Behind It */}
          <div className="relative inline-block max-w-full my-3 sm:my-5">
            {/* Luminous Glow Behind THE HISTORY CHRONICLE (Volumetric Backlight Aura - Direction Agnostic) */}
            <div 
              className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[110%] sm:w-[125%] h-24 sm:h-36 rounded-full pointer-events-none select-none blur-[40px] sm:blur-[60px] -z-10 transition-opacity duration-700 animate-pulse ${
                isMesopotamian 
                  ? 'bg-gradient-to-r from-amber-500/25 via-yellow-400/35 to-amber-600/25' 
                  : 'bg-gradient-to-r from-teal-500/25 via-[#2dd4bf]/40 to-emerald-500/25'
              }`}
              aria-hidden="true"
            />
            {/* Inner Core Soft Radiance (Centered & Balanced to prevent washing out Arabic words) */}
            <div 
              className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4/5 sm:w-2/3 h-16 sm:h-24 rounded-full pointer-events-none select-none blur-[22px] sm:blur-[34px] -z-10 ${
                isMesopotamian ? 'bg-amber-300/25' : 'bg-teal-300/30'
              }`}
              aria-hidden="true"
            />

            {/* Subtle Horizon Ambient Glow Accent */}
            <div 
              className={`absolute bottom-0 left-1/2 -translate-x-1/2 w-3/4 max-w-xl h-[1px] pointer-events-none select-none -z-10 ${
                isMesopotamian
                  ? 'bg-gradient-to-r from-transparent via-amber-400/60 to-transparent'
                  : 'bg-gradient-to-r from-transparent via-[#5eead4]/60 to-transparent'
              }`}
              aria-hidden="true"
            />

            {/* Animated Title Text with Entrance Spring & 3D Extrusion */}
            <motion.div
              initial={{ opacity: 0, y: 28, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 1.0, ease: [0.16, 1, 0.3, 1] }}
              className="relative overflow-visible px-2 py-2 sm:py-3 history-3d-perspective-stage"
            >
              {/* 3D Dimensional Title with Unified Inseparable Shadow Layer (Part of the word itself) */}
              <div className="history-3d-container relative inline-block select-none">
                <h1 
                  className={`relative z-10 font-messiri text-4xl sm:text-6xl md:text-7xl lg:text-8xl select-none ${
                    isRtl ? 'font-bold tracking-normal py-1 leading-[1.2]' : 'font-black tracking-tight leading-tight'
                  } ${isMesopotamian ? 'history-3d-word-meso' : 'history-3d-word'}`}
                >
                  {isRtl ? 'سجل تاريخ السيرفر' : 'THE HISTORY CHRONICLE'}
                </h1>
              </div>
            </motion.div>
          </div>

          {/* Subtitle with Delayed Entrance */}
          <motion.p 
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.35, ease: 'easeOut' }}
            className="font-cairo text-[#8db8b1] text-base sm:text-lg md:text-xl max-w-2xl mx-auto leading-relaxed mb-8 font-medium"
          >
            {isRtl 
              ? '« لكل مجتمع بداية... مجتمعنا كان له أكثر من بداية حتى بلغ السيادة. »' 
              : '"Every community has a beginning. Ours was forged through multiple eras."'}
          </motion.p>

          {/* Simple, Modern, Premium Chapter Navigation with Gradient (No enclosing circle) */}
          <nav
            className="inline-flex flex-wrap items-center justify-center gap-2 sm:gap-2.5 max-w-full mx-auto"
            aria-label="Story chapter jumps"
          >
            {QUICK_JUMPS.map((jump) => {
              const Icon = jump.icon;
              const isActive = activeSection === jump.id;

              return (
                <a
                  key={jump.id}
                  href={jump.href}
                  onClick={(e) => handleSmoothScroll(e, jump.href)}
                  className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all duration-300 flex items-center gap-2 cursor-pointer whitespace-nowrap shadow-sm ${
                    isActive
                      ? 'bg-gradient-to-r from-teal-500/35 via-[#5eead4]/40 to-emerald-500/35 text-white border border-[#5eead4]/60 font-bold shadow-[0_0_20px_rgba(94,234,212,0.35)]'
                      : 'bg-gradient-to-b from-white/[0.08] to-white/[0.02] text-slate-300 hover:text-white hover:bg-gradient-to-b hover:from-white/[0.15] hover:to-white/[0.05] border border-white/10 hover:border-white/25 hover:shadow-[0_0_15px_rgba(255,255,255,0.08)]'
                  }`}
                  title={isRtl ? jump.labelAr : jump.labelEn}
                >
                  <Icon size={14} className={`shrink-0 ${isActive ? 'text-[#5eead4]' : 'text-slate-400'}`} />
                  <span>{isRtl ? jump.labelAr : jump.labelEn}</span>
                </a>
              );
            })}
          </nav>
        </header>

        {/* ============================================================ */}
        {/* STORY TIMELINE: 4 Connected Chapters                         */}
        {/* ============================================================ */}
        <StoryTimeline />

        {/* ============================================================ */}
        {/* HISTORICAL OWNERS TIMELINE & EDGAR SOVEREIGN CARD            */}
        {/* ============================================================ */}
        <section id="owners" className="pt-20 pb-16 border-t border-[rgba(158,255,230,0.15)] scroll-mt-24">
          <div className="text-center max-w-3xl mx-auto mb-14">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/40 border border-cyan-500/25 text-cyan-300 text-xs font-mono tracking-widest uppercase mb-4">
              <Users size={13} />
              <span>THE COMPLETE ARCHIVE</span>
            </div>
            <h2 className="font-display font-bold text-3xl sm:text-4xl text-white tracking-wide mb-3">
              {t('history.owners.sectionTitle')}
            </h2>
            <p className="font-sans text-sm sm:text-base text-[#8db8b1] font-light max-w-xl mx-auto">
              {t('history.owners.sectionDesc')}
            </p>
          </div>

          {/* Edgar Sovereign Card with Direct Anchor */}
          <div id="sovereign-crown" className="mb-16 scroll-mt-28">
            <EdgarCrownCard />
          </div>

          {/* Historical Owners Chronicle (Strict I - X Roman counting, no glitch) */}
          <OwnersTimeline />
        </section>
      </div>

      {/* ============================================================ */}
      {/* FLOATING QUICK-JUMP DOCK (Appears on deep scroll)             */}
      {/* ============================================================ */}
      <AnimatePresence>
        {showFloatingDock && (
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ duration: 0.3 }}
            className="fixed bottom-6 start-1/2 -translate-x-1/2 rtl:translate-x-1/2 z-40 max-w-fit p-1.5 rounded-2xl bg-gradient-to-r from-[#031514]/95 via-[#062421]/95 to-[#031514]/95 border border-[rgba(94,234,212,0.3)] shadow-[0_16px_45px_rgba(0,0,0,0.8),0_0_30px_rgba(45,212,191,0.2)] backdrop-blur-2xl flex items-center gap-1.5"
          >
            {QUICK_JUMPS.map((jump) => {
              const Icon = jump.icon;
              const isActive = activeSection === jump.id;

              return (
                <a
                  key={jump.id}
                  href={jump.href}
                  onClick={(e) => handleSmoothScroll(e, jump.href)}
                  aria-label={jump.id}
                  className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl transition-all duration-300 flex items-center justify-center cursor-pointer shadow-sm ${
                    isActive
                      ? 'bg-gradient-to-r from-teal-500/35 via-[#5eead4]/40 to-emerald-500/35 text-white border border-[#5eead4]/60 font-bold shadow-[0_0_16px_rgba(94,234,212,0.35)] scale-105'
                      : 'bg-gradient-to-b from-white/[0.08] to-white/[0.02] text-slate-300 hover:text-white hover:bg-gradient-to-b hover:from-white/[0.15] hover:to-white/[0.05] border border-white/10 hover:border-white/25 hover:scale-105'
                  }`}
                >
                  <Icon size={16} className={`shrink-0 ${isActive ? 'text-[#5eead4]' : 'text-slate-400'}`} />
                </a>
              );
            })}

            <div className="w-[1px] h-4 bg-gradient-to-b from-transparent via-white/20 to-transparent mx-0.5" />

            {/* Back to top button */}
            <button
              type="button"
              onClick={scrollToTop}
              aria-label="top"
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-b from-white/[0.08] to-white/[0.02] text-slate-400 hover:text-white hover:bg-gradient-to-b hover:from-white/[0.15] hover:to-white/[0.05] border border-white/10 hover:border-white/25 transition-all cursor-pointer shadow-sm flex items-center justify-center hover:scale-105 active:scale-95"
            >
              <ArrowUp size={16} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
