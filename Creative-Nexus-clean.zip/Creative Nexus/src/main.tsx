import './data/defaultItems';
import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { installStandaloneInterceptor } from './utils/standaloneMock';

// Initialize standalone in-browser interceptor safely
try {
  installStandaloneInterceptor();
} catch (e) {
  console.warn('Standalone interceptor initialization notice:', e);
}

const rootEl = document.getElementById('root');
if (rootEl) {
  createRoot(rootEl).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}
