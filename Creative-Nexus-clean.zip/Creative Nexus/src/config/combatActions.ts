/**
 * Centralized Single Source of Truth for Combat Actions
 * Standardizes IDs across AI, UI, combat resolver, animations, battle log, and server.
 */

export const VALID_ACTIONS = [
  "strike",
  "heavy",
  "defense",
  "skill"
] as const;

export type ValidCombatAction = typeof VALID_ACTIONS[number];

export interface ActionDefinition {
  id: ValidCombatAction;
  name: string;
  nameAr: string;
  type: "basic" | "special";
  staminaCost: number;
  priority: number;
  icon: string;
  color: string;
  badgeBg: string;
  description: string;
  descriptionAr: string;
}

export const ACTIONS: Record<ValidCombatAction, ActionDefinition> = {
  strike: {
    id: "strike",
    name: "Strike",
    nameAr: "هجوم سريع",
    type: "basic",
    staminaCost: 15,
    priority: 1,
    icon: "🗡️",
    color: "#38bdf8",
    badgeBg: "bg-cyan-950/90 border-cyan-400/60 text-cyan-200",
    description: "Fast, agile strike. Interrupts Heavy startup. Counters Heavy.",
    descriptionAr: "هجوم سريع ورشيق. يباغت الهجوم الثقيل ويقاطعه."
  },

  heavy: {
    id: "heavy",
    name: "Heavy",
    nameAr: "هجوم ثقيل",
    type: "basic",
    staminaCost: 25,
    priority: 0,
    icon: "💥",
    color: "#f59e0b",
    badgeBg: "bg-amber-950/90 border-amber-400/60 text-amber-200",
    description: "Devastating strike that breaks Defense guards. Countered by Strike.",
    descriptionAr: "ضربة ساحقة كاسرة للدروع والدفاعات. يهزم الدفاع."
  },

  defense: {
    id: "defense",
    name: "Defense",
    nameAr: "دفاع محكم",
    type: "basic",
    staminaCost: 8,
    priority: 2,
    icon: "🛡️",
    color: "#3b82f6",
    badgeBg: "bg-blue-950/90 border-blue-400/60 text-blue-200",
    description: "Guarding stance that blocks Strike and recovers +25 stamina on standoff.",
    descriptionAr: "وضعية حراسة دفاعية تصد الهجوم السريع وتستعيد الجهد."
  },

  skill: {
    id: "skill",
    name: "Skill",
    nameAr: "مهارة تكتيكية",
    type: "special",
    staminaCost: 30,
    priority: 2,
    icon: "✨",
    color: "#a855f7",
    badgeBg: "bg-purple-950/90 border-purple-400/60 text-purple-200",
    description: "Signature combat skill. Only available for cards with active tactical skills.",
    descriptionAr: "المهارة القتالية الخاصة بالبطاقة للبطاقات النادرة والملحمية والأسطورية."
  }
};

/**
 * Normalizes any action representation (uppercase/lowercase, synonyms) to ValidCombatAction.
 * Strictly returns null for invalid actions like "action", "attack", "none", null, undefined.
 */
export function normalizeCombatAction(action: unknown): ValidCombatAction | null {
  if (!action || typeof action !== 'string') return null;
  const clean = action.trim().toLowerCase();

  // Strict check: explicitly reject generic words
  if (clean === 'action' || clean === 'attack' || clean === 'none' || clean === 'undefined' || clean === 'null') {
    return null;
  }

  if (clean === 'strike') return 'strike';
  if (clean === 'heavy') return 'heavy';
  if (clean === 'defense' || clean === 'defend') return 'defense';
  if (clean === 'skill' || clean === 'ability' || clean === 'ultimate') return 'skill';

  return null;
}

/**
 * Validates action strictly against VALID_ACTIONS.
 */
export function validateAIAction(action: unknown): ValidCombatAction | null {
  if (!action) return null;
  const normalized = normalizeCombatAction(action);
  if (!normalized || !VALID_ACTIONS.includes(normalized)) {
    return null;
  }
  return normalized;
}

/**
 * Alias for general combat validation
 */
export const validateCombatAction = validateAIAction;

/**
 * Checks if a card is legally permitted to use Skill based on:
 * - Card existence and configuration
 * - Card rarity (Rare, Epic, Legendary only - Common & Uncommon NEVER receive Skill)
 * - Card hasSkill flag
 * - Cooldown status (must be 0)
 * - Stamina affordability
 * - Not defeated or disabled
 */
export function canCardUseSkill(
  card: {
    currentHp?: number;
    isDefeated?: boolean;
    currentStamina?: number;
    rarity?: string;
    hasSkill?: boolean;
    card?: { rarity?: string };
    skill?: {
      id?: string;
      cooldown?: number;
      currentCooldown?: number;
      staminaCost?: number;
      energyCost?: number;
    };
  } | null | undefined,
  staminaOverride?: number
): boolean {
  if (!card) return false;
  if (card.isDefeated || (card.currentHp !== undefined && card.currentHp <= 0)) return false;

  // If card has an explicit hasSkill flag set to false, reject
  if (card.hasSkill === false) return false;

  const rawRarity = (card.rarity || card.card?.rarity || 'COMMON').toUpperCase();
  const isRareTierOrAbove = rawRarity === 'RARE' || rawRarity === 'EPIC' || rawRarity === 'LEGENDARY';
  if (!isRareTierOrAbove) return false;

  if (!card.skill || !card.skill.id) return false;

  const cd = card.skill.currentCooldown ?? 0;
  if (cd > 0) return false;

  const cost = card.skill.staminaCost ?? 30;
  const curStamina = staminaOverride ?? card.currentStamina ?? 100;
  if (curStamina < cost) return false;

  return true;
}

/**
 * Direct alias for canCardUseSkill matching prompt specification
 */
export const canUseSkill = canCardUseSkill;

/**
 * Builds the explicit candidate action list for a combatant.
 * The AI or Player is NEVER allowed to invent an action.
 * Decision space: Strike, Heavy, Defense, Skill (only when available).
 */
export function getAvailableCombatActions(
  card: Parameters<typeof canCardUseSkill>[0],
  stamina?: number
): ValidCombatAction[] {
  const currentStamina = stamina ?? card?.currentStamina ?? 100;
  const isExhausted = currentStamina <= 0;

  // Base actions: Strike and Defense are always foundational candidates
  const available: ValidCombatAction[] = ["strike", "defense"];

  // Heavy requires stamina >= 25 and cannot be used while exhausted
  if (!isExhausted && currentStamina >= ACTIONS.heavy.staminaCost) {
    available.push("heavy");
  }

  // Skill is added ONLY if all skill criteria pass
  if (canCardUseSkill(card, currentStamina)) {
    available.push("skill");
  }

  return available;
}
