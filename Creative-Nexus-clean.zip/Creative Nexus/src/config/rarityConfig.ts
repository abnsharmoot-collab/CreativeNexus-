import { CardRarity } from '../types/cards';

export interface RarityVisualConfig {
  id: CardRarity;
  name: string;
  nameAr: string;
  primaryColor: string;
  accentColor: string;
  borderColor: string;
  glowColor: string;
  bgGradient: string;
  badgeBg: string;
  badgeBorder: string;
  badgeText: string;
  description: string;
  cardFrameStyle: string;
  borderClass: string;
  particleStyle?: 'none' | 'subtle' | 'energy' | 'gold_particles';
  shimmerEnabled: boolean;
  saturationClass: string;
  depthShadow: string;
  tierRank: number; // 1 = Common, 5 = Legendary
}

export const RARITY_CONFIG: Record<string, RarityVisualConfig> = {
  common: {
    id: 'COMMON',
    name: 'COMMON',
    nameAr: 'شائعة',
    primaryColor: '#777777',
    accentColor: '#8a8a8a',
    borderColor: '#555555',
    glowColor: 'rgba(119, 119, 119, 0.15)',
    bgGradient: 'linear-gradient(145deg, #18181b 0%, #111113 50%, #09090b 100%)',
    badgeBg: 'bg-zinc-800/90',
    badgeBorder: 'border-zinc-600/70',
    badgeText: 'text-zinc-400',
    description: 'Basic ordinary mass-produced card with desaturated finish.',
    cardFrameStyle: 'border-zinc-600/60 bg-zinc-900/90',
    borderClass: 'border-zinc-600/60 hover:border-zinc-500',
    particleStyle: 'none',
    shimmerEnabled: false,
    saturationClass: 'grayscale-[35%] brightness-[88%] contrast-[95%]',
    depthShadow: '0 8px 24px rgba(0, 0, 0, 0.8), 0 0 6px rgba(119, 119, 119, 0.12)',
    tierRank: 1
  },
  uncommon: {
    id: 'UNCOMMON',
    name: 'UNCOMMON',
    nameAr: 'غير شائعة',
    primaryColor: '#35C759',
    accentColor: '#4ade80',
    borderColor: '#22c55e',
    glowColor: 'rgba(53, 199, 89, 0.28)',
    bgGradient: 'linear-gradient(145deg, #092612 0%, #06190c 50%, #030d06 100%)',
    badgeBg: 'bg-emerald-950/90',
    badgeBorder: 'border-emerald-500/70',
    badgeText: 'text-emerald-400',
    description: 'Noticeable emerald luster with subtle green glow and shimmer.',
    cardFrameStyle: 'border-emerald-500/70 bg-emerald-950/40',
    borderClass: 'border-emerald-500/70 hover:border-emerald-400 shadow-[0_0_12px_rgba(53,199,89,0.25)]',
    particleStyle: 'subtle',
    shimmerEnabled: true,
    saturationClass: 'saturate-[105%] brightness-[98%]',
    depthShadow: '0 10px 28px rgba(0, 0, 0, 0.85), 0 0 14px rgba(53, 199, 89, 0.25)',
    tierRank: 2
  },
  rare: {
    id: 'RARE',
    name: 'RARE',
    nameAr: 'نادرة',
    primaryColor: '#3B82F6',
    accentColor: '#60a5fa',
    borderColor: '#3b82f6',
    glowColor: 'rgba(59, 130, 246, 0.38)',
    bgGradient: 'linear-gradient(145deg, #081d3d 0%, #041026 50%, #020712 100%)',
    badgeBg: 'bg-blue-950/90',
    badgeBorder: 'border-blue-400/80',
    badgeText: 'text-blue-300',
    description: 'Valuable azure polish with blue accent lighting and animated sweep.',
    cardFrameStyle: 'border-blue-500/80 bg-blue-950/50',
    borderClass: 'border-blue-500/80 hover:border-blue-400 shadow-[0_0_18px_rgba(59,130,246,0.35)]',
    particleStyle: 'subtle',
    shimmerEnabled: true,
    saturationClass: 'saturate-[115%] brightness-[102%]',
    depthShadow: '0 12px 32px rgba(0, 0, 0, 0.9), 0 0 20px rgba(59, 130, 246, 0.35)',
    tierRank: 3
  },
  epic: {
    id: 'EPIC',
    name: 'EPIC',
    nameAr: 'ملحمية',
    primaryColor: '#A855F7',
    accentColor: '#c084fc',
    borderColor: '#a855f7',
    glowColor: 'rgba(168, 85, 247, 0.45)',
    bgGradient: 'linear-gradient(145deg, #240a3d 0%, #150524 50%, #080210 100%)',
    badgeBg: 'bg-purple-950/90',
    badgeBorder: 'border-purple-400/80',
    badgeText: 'text-purple-300',
    description: 'Powerful arcane amethyst energy with border energy and ambient glow.',
    cardFrameStyle: 'border-purple-500/90 bg-purple-950/60',
    borderClass: 'border-purple-500/90 hover:border-purple-300 shadow-[0_0_24px_rgba(168,85,247,0.45)]',
    particleStyle: 'energy',
    shimmerEnabled: true,
    saturationClass: 'saturate-[120%] brightness-[105%]',
    depthShadow: '0 14px 36px rgba(0, 0, 0, 0.92), 0 0 26px rgba(168, 85, 247, 0.42)',
    tierRank: 4
  },
  legendary: {
    id: 'LEGENDARY',
    name: 'LEGENDARY',
    nameAr: 'أسطورية',
    primaryColor: '#F59E0B',
    accentColor: '#FFD700',
    borderColor: '#f59e0b',
    glowColor: 'rgba(245, 158, 11, 0.55)',
    bgGradient: 'linear-gradient(145deg, #381b03 0%, #1f0d01 50%, #0a0400 100%)',
    badgeBg: 'bg-amber-950/95',
    badgeBorder: 'border-amber-400',
    badgeText: 'text-amber-300',
    description: 'Unmistakable royal gilded luster, floating golden aura, and supreme prestige.',
    cardFrameStyle: 'border-amber-400 bg-amber-950/70',
    borderClass: 'border-amber-400/95 hover:border-yellow-300 shadow-[0_0_30px_rgba(245,158,11,0.55),0_0_12px_rgba(255,215,0,0.4)]',
    particleStyle: 'gold_particles',
    shimmerEnabled: true,
    saturationClass: 'saturate-[125%] brightness-[108%]',
    depthShadow: '0 16px 42px rgba(0, 0, 0, 0.95), 0 0 32px rgba(245, 158, 11, 0.52), 0 0 14px rgba(255, 215, 0, 0.35)',
    tierRank: 5
  },
  halloween_2026: {
    id: 'HALLOWEEN_2026',
    name: 'HALLOWEEN',
    nameAr: 'هالوين',
    primaryColor: '#ff5e00',
    accentColor: '#b026ff',
    borderColor: '#ff6200',
    glowColor: 'rgba(255, 94, 0, 0.75)',
    bgGradient: 'linear-gradient(145deg, #3d0e00 0%, #1f051f 50%, #08000a 100%)',
    badgeBg: 'bg-orange-950/95',
    badgeBorder: 'border-orange-500',
    badgeText: 'text-orange-300',
    description: 'Limited Time Halloween Edition. Superior to Legendary with cursed embers, witchfire violet vortex, and supreme seasonal potency.',
    cardFrameStyle: 'border-orange-500 bg-orange-950/80',
    borderClass: 'border-orange-500/95 hover:border-orange-400 shadow-[0_0_35px_rgba(255,94,0,0.65),0_0_15px_rgba(176,38,255,0.5)]',
    particleStyle: 'energy',
    shimmerEnabled: true,
    saturationClass: 'saturate-[135%] brightness-[110%]',
    depthShadow: '0 18px 48px rgba(0, 0, 0, 0.98), 0 0 38px rgba(255, 94, 0, 0.65), 0 0 20px rgba(176, 38, 255, 0.55)',
    tierRank: 6
  }
};

/**
 * Normalizes any raw rarity string into canonical key ('common' | 'uncommon' | 'rare' | 'epic' | 'legendary' | 'halloween_2026')
 */
export function getRarityKey(rarity?: string | null): 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary' | 'halloween_2026' {
  if (!rarity) return 'common';
  const clean = rarity.toLowerCase().trim();
  if (clean === 'halloween_2026' || clean === 'halloween' || clean === 'halloween 2026' || clean === 'mythic_halloween') return 'halloween_2026';
  if (clean === 'legendary') return 'legendary';
  if (clean === 'epic') return 'epic';
  if (clean === 'rare') return 'rare';
  if (clean === 'uncommon') return 'uncommon';
  return 'common';
}

/**
 * Returns the centralized visual configuration for a given card rarity.
 */
export function getRarityConfig(rarity?: string | null): RarityVisualConfig {
  const key = getRarityKey(rarity);
  return RARITY_CONFIG[key] || RARITY_CONFIG.common;
}
