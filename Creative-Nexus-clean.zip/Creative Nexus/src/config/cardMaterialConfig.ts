import {
  CardRarity,
  CardFoilStyle,
  HolographicBehavior,
  FoilIntensity,
  CardFrameStyle,
  CollectibleCardData,
} from '../types/cards';

export interface RarityMaterialConfig {
  rarity: CardRarity;
  label: string;
  nameAr: string;

  // Visual Identity Colors
  primaryColor: string;      // Canonical border and accent color
  secondaryColor: string;    // Specular highlight tint
  deepColor: string;         // Deep shadow / dark tone
  ambientGlow: string;       // Subtle outer aura rgba
  borderSheen: string;       // Border reflective highlight rgba
  metallicGrain: string;     // Surface specular grain tint rgba

  // Gradients for chassis face
  faceGradient: string;
  textGradient: string;

  // Base Physical Material Properties
  baseFoilOpacity: number;   // Continuous idle foil peak opacity (0 - 1)
  hoverFoilOpacity: number;  // Hover peak opacity (0 - 1)
  defaultFoilIntensity: FoilIntensity; // 'low' | 'medium' | 'high' | 'ultra'
  defaultBehavior: HolographicBehavior;
  defaultFrameStyle: CardFrameStyle;

  // Material Metrics (0 - 100)
  metallicStrength: number;
  surfaceShine: number;
  edgeReflection: number;
  reflectionStrength: number;
  iridescence: number;

  // Base Animation Cycle Duration in seconds (Requirement 10: 8-12s, 7-11s, 6-10s, 5-9s, 4-8s)
  baseCycleSeconds: number;

  // Edge Lighting / Box Shadow Specs
  glowBlurStatic: string;
  glowBlurHover: string;
  glowOpacityStatic: string;
  glowOpacityHover: string;
}

export const RARITY_MATERIAL_SYSTEM: Record<CardRarity, RarityMaterialConfig> = {
  // COMMON: Muted gray, ordinary / cheap / basic / mass-produced, desaturated.
  // Gray border, dark gray frame, subtle gray glow, almost no special effects.
  COMMON: {
    rarity: 'COMMON',
    label: 'COMMON',
    nameAr: 'شائع',
    primaryColor: '#777777', // Muted gray
    secondaryColor: '#999999', // Soft gray
    deepColor: '#18181b', // Charcoal base
    ambientGlow: 'rgba(119, 119, 119, 0.15)',
    borderSheen: 'rgba(119, 119, 119, 0.20)',
    metallicGrain: 'rgba(255, 255, 255, 0.02)',
    faceGradient: 'from-[#141416]/96 via-zinc-950/92 to-[#09090b]/98',
    textGradient: 'from-zinc-200 via-zinc-400 to-zinc-500',
    baseFoilOpacity: 0.04, // Very weak foil
    hoverFoilOpacity: 0.08, // Minimal reflection
    defaultFoilIntensity: 'low',
    defaultBehavior: 'diagonal_sweep',
    defaultFrameStyle: 'minimalist',
    metallicStrength: 20,
    surfaceShine: 15,
    edgeReflection: 15,
    reflectionStrength: 12,
    iridescence: 2,
    baseCycleSeconds: 12.0,
    glowBlurStatic: '8px',
    glowBlurHover: '12px',
    glowOpacityStatic: '15',
    glowOpacityHover: '25',
  },

  // UNCOMMON: Green border, slight green tint, subtle green glow, small shimmer (#35C759)
  UNCOMMON: {
    rarity: 'UNCOMMON',
    label: 'UNCOMMON',
    nameAr: 'غير شائع',
    primaryColor: '#35C759', // Emerald green
    secondaryColor: '#4ade80', // Bright jade highlight
    deepColor: '#092612', // Deep green shadow
    ambientGlow: 'rgba(53, 199, 89, 0.32)',
    borderSheen: 'rgba(53, 199, 89, 0.45)',
    metallicGrain: 'rgba(53, 199, 89, 0.08)',
    faceGradient: 'from-[#062010]/96 via-slate-950/92 to-[#031108]/98',
    textGradient: 'from-emerald-100 via-teal-100 to-emerald-300',
    baseFoilOpacity: 0.20,
    hoverFoilOpacity: 0.32,
    defaultFoilIntensity: 'medium',
    defaultBehavior: 'edge_shimmer',
    defaultFrameStyle: 'cyber_sleek',
    metallicStrength: 50,
    surfaceShine: 45,
    edgeReflection: 45,
    reflectionStrength: 40,
    iridescence: 25,
    baseCycleSeconds: 8.5,
    glowBlurStatic: '16px',
    glowBlurHover: '26px',
    glowOpacityStatic: '40',
    glowOpacityHover: '58',
  },

  // RARE: Blue, blue border, blue accent lighting, subtle blue glow, animated sweep (#3B82F6)
  RARE: {
    rarity: 'RARE',
    label: 'RARE',
    nameAr: 'نادر',
    primaryColor: '#3B82F6', // Sapphire blue
    secondaryColor: '#60a5fa', // Blue accent highlight
    deepColor: '#081d3d', // Deep oceanic blue
    ambientGlow: 'rgba(59, 130, 246, 0.40)',
    borderSheen: 'rgba(59, 130, 246, 0.60)',
    metallicGrain: 'rgba(59, 130, 246, 0.14)',
    faceGradient: 'from-[#061d38]/96 via-slate-950/92 to-[#020e1d]/98',
    textGradient: 'from-blue-100 via-sky-100 to-blue-300',
    baseFoilOpacity: 0.34,
    hoverFoilOpacity: 0.50,
    defaultFoilIntensity: 'medium',
    defaultBehavior: 'horizontal_sweep',
    defaultFrameStyle: 'runic_rare',
    metallicStrength: 70,
    surfaceShine: 65,
    edgeReflection: 68,
    reflectionStrength: 65,
    iridescence: 50,
    baseCycleSeconds: 7.2,
    glowBlurStatic: '24px',
    glowBlurHover: '36px',
    glowOpacityStatic: '55',
    glowOpacityHover: '75',
  },

  // EPIC: Purple, purple border, ambient glow, animated border energy (#A855F7)
  EPIC: {
    rarity: 'EPIC',
    label: 'EPIC',
    nameAr: 'ملحمي',
    primaryColor: '#A855F7', // Royal purple
    secondaryColor: '#c084fc', // Arcane purple highlight
    deepColor: '#240a3d', // Deep astral purple
    ambientGlow: 'rgba(168, 85, 247, 0.50)',
    borderSheen: 'rgba(168, 85, 247, 0.70)',
    metallicGrain: 'rgba(168, 85, 247, 0.20)',
    faceGradient: 'from-[#1c0830]/96 via-slate-950/92 to-[#0a0212]/98',
    textGradient: 'from-purple-100 via-fuchsia-200 to-purple-300',
    baseFoilOpacity: 0.46,
    hoverFoilOpacity: 0.66,
    defaultFoilIntensity: 'high',
    defaultBehavior: 'iridescent_flow',
    defaultFrameStyle: 'crystal_epic',
    metallicStrength: 85,
    surfaceShine: 82,
    edgeReflection: 86,
    reflectionStrength: 82,
    iridescence: 75,
    baseCycleSeconds: 6.0,
    glowBlurStatic: '30px',
    glowBlurHover: '44px',
    glowOpacityStatic: '65',
    glowOpacityHover: '85',
  },

  // LEGENDARY: Gold / warm orange, gold border, golden gradient, elegant glow, floating particles (#F59E0B / #FFD700)
  LEGENDARY: {
    rarity: 'LEGENDARY',
    label: 'LEGENDARY',
    nameAr: 'أسطوري',
    primaryColor: '#F59E0B', // Royal gold / warm orange
    secondaryColor: '#FFD700', // Pure gold highlight
    deepColor: '#381b03', // Deep burnished amber
    ambientGlow: 'rgba(245, 158, 11, 0.70)',
    borderSheen: 'rgba(254, 240, 138, 0.88)',
    metallicGrain: 'rgba(254, 240, 138, 0.26)',
    faceGradient: 'from-[#2a1703]/98 via-slate-950/94 to-[#0f0701]/98',
    textGradient: 'from-yellow-100 via-amber-200 to-amber-400',
    baseFoilOpacity: 0.58, // Premium highest holographic foil
    hoverFoilOpacity: 0.82,
    defaultFoilIntensity: 'ultra',
    defaultBehavior: 'prismatic_shift',
    defaultFrameStyle: 'ornate_legendary',
    metallicStrength: 98,
    surfaceShine: 95,
    edgeReflection: 96,
    reflectionStrength: 95,
    iridescence: 90,
    baseCycleSeconds: 5.0, // 4-8s range
    glowBlurStatic: '36px',
    glowBlurHover: '50px',
    glowOpacityStatic: '75',
    glowOpacityHover: '95',
  },

  // HALLOWEEN 2026: Mythic seasonal genre, better than Legendary.
  // Blazing pumpkin orange (#ff5e00), witchfire spectral purple (#b026ff), cursed embers, ultra iridescence.
  HALLOWEEN_2026: {
    rarity: 'HALLOWEEN_2026',
    label: 'HALLOWEEN 2026',
    nameAr: 'هالوين 2026',
    primaryColor: '#ff5e00', // Cursed pumpkin flame
    secondaryColor: '#b026ff', // Spectral witchfire purple
    deepColor: '#28061e', // Dark haunted vortex
    ambientGlow: 'rgba(255, 94, 0, 0.75)',
    borderSheen: 'rgba(255, 140, 0, 0.95)',
    metallicGrain: 'rgba(176, 38, 255, 0.35)',
    faceGradient: 'from-[#330c02]/98 via-purple-950/94 to-[#09010d]/98',
    textGradient: 'from-orange-100 via-amber-200 to-purple-300',
    baseFoilOpacity: 0.68,
    hoverFoilOpacity: 0.90,
    defaultFoilIntensity: 'ultra',
    defaultBehavior: 'prismatic_shift',
    defaultFrameStyle: 'halloween_spectral',
    metallicStrength: 100,
    surfaceShine: 98,
    edgeReflection: 98,
    reflectionStrength: 98,
    iridescence: 95,
    baseCycleSeconds: 4.2,
    glowBlurStatic: '40px',
    glowBlurHover: '55px',
    glowOpacityStatic: '85',
    glowOpacityHover: '100',
  },
};

export const FOIL_INTENSITY_MULTIPLIERS: Record<FoilIntensity, number> = {
  low: 0.65,
  medium: 1.0,
  high: 1.35,
  ultra: 1.65,
};

/**
 * Returns the authoritative base material config for a card rarity.
 */
export function getRarityMaterialConfig(rarity?: CardRarity): RarityMaterialConfig {
  if (!rarity || !RARITY_MATERIAL_SYSTEM[rarity]) {
    return RARITY_MATERIAL_SYSTEM.COMMON;
  }
  return RARITY_MATERIAL_SYSTEM[rarity];
}

export interface ResolvedCardMaterial {
  rarity: CardRarity;
  primaryColor: string;
  secondaryColor: string;
  ambientGlow: string;
  borderSheen: string;
  metallicGrain: string;
  faceGradient: string;
  textGradient: string;
  activeBehavior: HolographicBehavior;
  effectiveFoilStyle: CardFoilStyle;
  effectiveFoilIntensity: FoilIntensity;
  idlePeakOpacity: number;
  hoverPeakOpacity: number;
  cycleDurationSec: number;
  bandWidth: number;
  reflectionAngle: number;
  metallicStrength: number;
  surfaceShine: number;
  edgeReflection: number;
  iridescence: number;
  dynamicBoxShadow: (isHovered: boolean, containedLighting?: boolean) => string;
}

/**
 * Pure reusable resolver connecting Card -> Rarity Config -> Foil Config -> Holographic Behavior -> Material Renderer.
 * Respects owner custom overrides when explicitly provided, while ensuring baseline rarity identity is always intact.
 */
export function resolveEffectiveCardMaterial(
  card: Partial<Omit<CollectibleCardData, 'rarity'>> & { rarity?: CardRarity | string }
): ResolvedCardMaterial {
  const rarity = (card.rarity as CardRarity) || 'COMMON';
  const base = getRarityMaterialConfig(rarity);
  const isLegendary = rarity === 'LEGENDARY';

  // Only LEGENDARY cards allow custom color choosing; all other rarities are strictly decided by rarity!
  const primaryColor = isLegendary
    ? (card.borderColor || (card.isCustom ? card.accentColor : undefined) || base.primaryColor)
    : base.primaryColor;
  const secondaryColor = base.secondaryColor;

  const activeBehavior: HolographicBehavior =
    card.holographicBehavior && card.holographicBehavior !== undefined
      ? card.holographicBehavior
      : base.defaultBehavior;

  const effectiveFoilStyle: CardFoilStyle = card.foilStyle || 'standard';
  const effectiveFoilIntensity: FoilIntensity = card.foilIntensity || base.defaultFoilIntensity;

  const intensityMult = FOIL_INTENSITY_MULTIPLIERS[effectiveFoilIntensity] || 1.0;
  const userOpacityFactor = typeof card.foilOpacity === 'number'
    ? Math.max(0, Math.min(100, card.foilOpacity)) / 50
    : 1.0;
  const strengthMult = typeof card.reflectionStrength === 'number'
    ? Math.max(0, Math.min(100, card.reflectionStrength)) / 50
    : (base.reflectionStrength / 50);

  const idlePeakOpacity = Math.min(0.95, base.baseFoilOpacity * intensityMult * userOpacityFactor * strengthMult);
  const hoverPeakOpacity = Math.min(1.0, base.hoverFoilOpacity * intensityMult * userOpacityFactor * strengthMult);

  const speedMult = Math.max(0.4, Math.min(2.5, Number(card.reflectionSpeed) || 1.0));
  const cycleDurationSec = Math.max(2.5, base.baseCycleSeconds / speedMult);

  const bandWidth = typeof card.reflectionWidth === 'number'
    ? Math.max(15, Math.min(80, card.reflectionWidth))
    : 42;

  const reflectionAngle = typeof card.reflectionAngle === 'number'
    ? card.reflectionAngle
    : 35;

  const metallicStrength = typeof card.metallicStrength === 'number'
    ? card.metallicStrength
    : base.metallicStrength;

  const surfaceShine = typeof card.surfaceShine === 'number'
    ? card.surfaceShine
    : base.surfaceShine;

  const edgeReflection = typeof card.edgeReflection === 'number'
    ? card.edgeReflection
    : base.edgeReflection;

  const iridescence = typeof card.iridescence === 'number'
    ? card.iridescence
    : base.iridescence;

  const dynamicBoxShadow = (isHovered: boolean, containedLighting = false) => {
    if (containedLighting) {
      return isHovered
        ? '0 25px 60px -10px rgba(0,0,0,0.95)'
        : '0 16px 40px -12px rgba(0,0,0,0.9)';
    }

    const glowColor = isLegendary ? (card.glowColor || primaryColor) : base.primaryColor;
    const blur = isHovered ? base.glowBlurHover : base.glowBlurStatic;
    const opacityHex = isHovered ? base.glowOpacityHover : base.glowOpacityStatic;

    return isHovered
      ? `0 30px 70px rgba(0,0,0,0.94), 0 0 ${blur} ${glowColor}${opacityHex}`
      : `0 20px 50px rgba(0,0,0,0.88), 0 0 ${blur} ${glowColor}${opacityHex}`;
  };

  return {
    rarity,
    primaryColor,
    secondaryColor,
    ambientGlow: base.ambientGlow,
    borderSheen: base.borderSheen,
    metallicGrain: base.metallicGrain,
    faceGradient: base.faceGradient,
    textGradient: base.textGradient,
    activeBehavior,
    effectiveFoilStyle,
    effectiveFoilIntensity,
    idlePeakOpacity,
    hoverPeakOpacity,
    cycleDurationSec,
    bandWidth,
    reflectionAngle,
    metallicStrength,
    surfaceShine,
    edgeReflection,
    iridescence,
    dynamicBoxShadow,
  };
}
