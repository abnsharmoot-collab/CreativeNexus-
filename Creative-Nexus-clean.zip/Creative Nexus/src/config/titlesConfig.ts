import { PlayerTitle, CollectionStatistics } from '../types/progression';

export const DATA_DRIVEN_TITLES: PlayerTitle[] = [
  {
    id: 'NOVICE_SEEKER',
    name: 'Novice Seeker',
    nameAr: 'الباحث المبتدئ',
    description: 'Initial initiate of the Sanctuary Card Vault.',
    descriptionAr: 'المبتدئ الأول في خزينة بطاقات الملاذ التاريخي.',
    rarity: 'COMMON',
    unlockCondition: {
      type: 'DEFAULT',
      target: 0,
    },
  },
  {
    id: 'PACK_OPENER',
    name: 'Pack Opener',
    nameAr: 'فاتح الحزم',
    description: 'Opened at least 3 sealed relic card booster packs.',
    descriptionAr: 'فتح 3 حزم بطاقات أثرية مختومة على الأقل.',
    rarity: 'UNCOMMON',
    unlockCondition: {
      type: 'PACKS_OPENED',
      target: 3,
    },
  },
  {
    id: 'RELIC_COLLECTOR',
    name: 'Relic Collector',
    nameAr: 'جامع الآثار',
    description: 'Discovered and bound at least 8 unique collectible cards.',
    descriptionAr: 'اكتشف وامتلك 8 بطاقات أثرية فريدة على الأقل.',
    rarity: 'RARE',
    unlockCondition: {
      type: 'CARDS_UNIQUE',
      target: 8,
    },
  },
  {
    id: 'CARD_HOARDER',
    name: 'Card Hoarder',
    nameAr: 'مكتنز البطاقات',
    description: 'Amassed an inventory of 20 or more total cards.',
    descriptionAr: 'جمع مخزوناً يتجاوز 20 بطاقة مقتناة إجمالاً.',
    rarity: 'RARE',
    unlockCondition: {
      type: 'CARDS_TOTAL',
      target: 20,
    },
  },
  {
    id: 'THE_ARCHIVIST',
    name: 'The Archivist',
    nameAr: 'المؤرشف الملكي',
    description: 'Curated 15 unique cards in the community archives.',
    descriptionAr: 'أرشف 15 بطاقة فريدة ونادرة في الأرشيف الرسمي.',
    rarity: 'EPIC',
    unlockCondition: {
      type: 'CARDS_UNIQUE',
      target: 15,
    },
  },
  {
    id: 'LEGENDARY_HUNTER',
    name: 'Legendary Hunter',
    nameAr: 'صياد الأساطير',
    description: 'Successfully drew at least one divine Legendary card.',
    descriptionAr: 'استخرج بطاقة أسطورية ذهبية مذهلة واحدة على الأقل.',
    rarity: 'LEGENDARY',
    unlockCondition: {
      type: 'LEGENDARY_OWNED',
      target: 1,
    },
  },
  {
    id: 'MASTER_COLLECTOR',
    name: 'Master Collector',
    nameAr: 'سيد المقتنيات',
    description: 'Achieved Account Level 10 or collected 20 unique cards.',
    descriptionAr: 'بلغ المستوى العاشر أو امتلك 20 بطاقة فريدة.',
    rarity: 'LEGENDARY',
    unlockCondition: {
      type: 'LEVEL_REACHED',
      target: 10,
    },
  },
  {
    id: 'SOVEREIGN_CHRONICLER',
    name: 'Sovereign Chronicler',
    nameAr: 'مؤرخ السيادة',
    description: 'Command at least 3 Legendary cards simultaneously.',
    descriptionAr: 'استحوذ على 3 بطاقات أسطورية في آن واحد.',
    rarity: 'LEGENDARY',
    unlockCondition: {
      type: 'LEGENDARY_OWNED',
      target: 3,
    },
  },
];

/**
 * Checks whether a given title is unlocked based on live player statistics
 * or explicit historical unlock IDs.
 */
export function isTitleUnlocked(
  title: PlayerTitle,
  stats: CollectionStatistics,
  explicitUnlockedIds?: string[]
): boolean {
  if (explicitUnlockedIds && explicitUnlockedIds.includes(title.id)) {
    return true;
  }

  const cond = title.unlockCondition;
  switch (cond.type) {
    case 'DEFAULT':
      return true;
    case 'CARDS_UNIQUE':
      return stats.uniqueCards >= cond.target;
    case 'CARDS_TOTAL':
      return stats.totalCards >= cond.target;
    case 'PACKS_OPENED':
      return stats.packsOpened >= cond.target;
    case 'LEGENDARY_OWNED':
      return stats.legendaryCount >= cond.target;
    case 'LEVEL_REACHED':
      return stats.accountLevel >= cond.target;
    case 'SETS_COMPLETED':
      return stats.setsCompleted >= cond.target;
    default:
      return false;
  }
}
