import { PlayerBadge, CollectionStatistics } from '../types/progression';

export const DATA_DRIVEN_BADGES: PlayerBadge[] = [
  {
    id: 'FIRST_PACK',
    name: 'First Pack',
    nameAr: 'الحزمة الأولى',
    description: 'Unsealed your very first booster pack from the sanctuary shop.',
    descriptionAr: 'فتحت أول حزمة بطاقات مختومة من متجر الملاذ.',
    icon: 'Package',
    rarity: 'COMMON',
    category: 'PACKS',
    unlockCondition: {
      type: 'PACKS_OPENED',
      target: 1,
    },
  },
  {
    id: 'DAILY_DEVOTEE',
    name: 'Daily Devotee',
    nameAr: 'المخلص اليومي',
    description: 'Claimed your daily login coin grant from the vault.',
    descriptionAr: 'استلمت منحة العملات اليومية من خزينة الملاذ.',
    icon: 'Clock',
    rarity: 'COMMON',
    category: 'DAILY_CLAIM',
    unlockCondition: {
      type: 'DAILY_CLAIM',
      target: 1,
    },
  },
  {
    id: 'COLLECTOR',
    name: 'Collector',
    nameAr: 'الجامع',
    description: 'Bound 10 unique collectible cards into your personal vault.',
    descriptionAr: 'جمعت 10 بطاقات فريدة ومميزة في خزانتك الشخصية.',
    icon: 'Layers',
    rarity: 'UNCOMMON',
    category: 'COLLECTION',
    unlockCondition: {
      type: 'CARDS_UNIQUE',
      target: 10,
    },
  },
  {
    id: 'VAULT_KEEPER',
    name: 'Vault Keeper',
    nameAr: 'حارس الخزينة',
    description: 'Accumulated 150 or more coins in your balance.',
    descriptionAr: 'جمعت رصيداً يتجاوز 150 عملة في الخزينة.',
    icon: 'Coins',
    rarity: 'RARE',
    category: 'ECONOMY',
    unlockCondition: {
      type: 'COINS_HELD',
      target: 150,
    },
  },
  {
    id: 'ARCHIVIST',
    name: 'Archivist',
    nameAr: 'المؤرشف',
    description: 'Reached a milestone of 20 unique cards in your archives.',
    descriptionAr: 'حققت إنجاز توثيق 20 بطاقة فريدة في أرشيفك الشخصي.',
    icon: 'BookOpen',
    rarity: 'EPIC',
    category: 'COLLECTION',
    unlockCondition: {
      type: 'CARDS_UNIQUE',
      target: 20,
    },
  },
  {
    id: 'LEGENDARY_HUNTER',
    name: 'Legendary Hunter',
    nameAr: 'صياد الأساطير',
    description: 'Discovered your first divine Legendary rarity card.',
    descriptionAr: 'حصلت على أول بطاقة أسطورية ملكية فائقة الندرة.',
    icon: 'Crown',
    rarity: 'LEGENDARY',
    category: 'RARITY',
    unlockCondition: {
      type: 'LEGENDARY_OWNED',
      target: 1,
    },
  },
  {
    id: 'MYTHIC_VAULT',
    name: 'Mythic Vault',
    nameAr: 'الخزينة الأسطورية',
    description: 'Hold at least 3 Legendary cards in your collection.',
    descriptionAr: 'تمتلك 3 بطاقات أسطورية في خزانتك في نفس الوقت.',
    icon: 'Sparkles',
    rarity: 'LEGENDARY',
    category: 'RARITY',
    unlockCondition: {
      type: 'LEGENDARY_OWNED',
      target: 3,
    },
  },
  {
    id: 'MASTER_COLLECTOR',
    name: 'Master Collector',
    nameAr: 'سيد المقتنيات',
    description: 'Ascended to Account Level 10 across the progression matrix.',
    descriptionAr: 'بلغت المستوى العاشر (Level 10) في منظومة التقدم.',
    icon: 'Trophy',
    rarity: 'LEGENDARY',
    category: 'LEVEL',
    unlockCondition: {
      type: 'LEVEL_REACHED',
      target: 10,
    },
  },
];

/**
 * Checks whether a given badge is unlocked based on live player statistics
 * or explicit historical unlock IDs.
 */
export function isBadgeUnlocked(
  badge: PlayerBadge,
  stats: CollectionStatistics,
  extraMeta?: { hasClaimedDaily?: boolean; coins?: number },
  explicitUnlockedIds?: string[]
): boolean {
  if (explicitUnlockedIds && explicitUnlockedIds.includes(badge.id)) {
    return true;
  }

  const cond = badge.unlockCondition;
  switch (cond.type) {
    case 'DEFAULT':
      return true;
    case 'PACKS_OPENED':
      return stats.packsOpened >= cond.target;
    case 'DAILY_CLAIM':
      return !!extraMeta?.hasClaimedDaily;
    case 'CARDS_UNIQUE':
      return stats.uniqueCards >= cond.target;
    case 'CARDS_TOTAL':
      return stats.totalCards >= cond.target;
    case 'LEGENDARY_OWNED':
      return stats.legendaryCount >= cond.target;
    case 'LEVEL_REACHED':
      return stats.accountLevel >= cond.target;
    case 'COINS_HELD':
      return (extraMeta?.coins ?? stats.coinsEarned) >= cond.target;
    case 'SETS_COMPLETED':
      return stats.setsCompleted >= cond.target;
    default:
      return false;
  }
}
