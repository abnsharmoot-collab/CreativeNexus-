/**
 * ============================================================================
 * CREATIVE NEXUS — EASTER EGGS CONFIGURATION
 * ============================================================================
 * 
 * Website Owner Configuration File:
 * This file contains configurable assets and settings for the secret Easter Eggs.
 */

export interface ClassifiedArchiveConfig {
  /**
   * WEBSITE OWNER CONFIGURATION:
   * Provide the image URL or public path for the secret Easter Egg archive page.
   * 
   * Examples:
   *  - "/assets/secret_vault.jpg" (local public asset)
   *  - "https://your-domain.com/images/classified_art.png"
   * 
   * When empty (""), the website displays an elegant classified/redacted archive vault
   * placeholder with instructions for the owner to configure their image.
   */
  imageUrl: string;

  /**
   * Title shown at the top of the classified archive vault
   */
  titleEn: string;
  titleAr: string;

  /**
   * Message displayed on the secret page
   */
  messageEn: string;
  messageAr: string;

  /**
   * Secondary notice
   */
  warningNoticeEn: string;
  warningNoticeAr: string;
}

export const CLASSIFIED_ARCHIVE_CONFIG: ClassifiedArchiveConfig = {
  // <<== WEBSITE OWNER: PASTE YOUR SECRET IMAGE URL OR PATH HERE ==>>
  imageUrl: '',

  titleEn: 'RESTRICTED ARCHIVE // VAULT ACCESS',
  titleAr: 'الأرشيف السري // تصريح الخزينة',

  messageEn: 'Classified Community Archival Record',
  messageAr: 'سجل أرشيفي سري للمجتمع',

  warningNoticeEn: 'Confidential community archive dossier.',
  warningNoticeAr: 'ملف أرشيفي سري للمجتمع.',
};

// Aliases for compatibility
export type Rule34EasterEggConfig = ClassifiedArchiveConfig;
export const RULE34_EASTER_EGG_CONFIG = CLASSIFIED_ARCHIVE_CONFIG;

/**
 * 8 Hidden Iraqi Flags Easter Egg System Constants
 */
export const TOTAL_IRAQI_FLAGS = 5;

export interface IraqiFlagLocationMeta {
  id: string;
  nameEn: string;
  nameAr: string;
  locationHintEn: string;
  locationHintAr: string;
}

export const IRAQI_FLAG_LOCATIONS: Record<string, IraqiFlagLocationMeta> = {
  'flag-home-hero': {
    id: 'flag-home-hero',
    nameEn: 'Mesopotamian Standard Crest',
    nameAr: 'شعار بلاد الرافدين التأسيسي',
    locationHintEn: 'Hidden beside the scroll guide at the base of the community hero banner.',
    locationHintAr: 'مخفي بجانب مؤشر التمرير في أسفل واجهة البداية.',
  },
  'flag-home-stats': {
    id: 'flag-home-stats',
    nameEn: 'Millennium Cornerstone Mark',
    nameAr: 'علامة ركيزة الأرقام التاريخية',
    locationHintEn: 'Concealed in the community live statistics grid frame.',
    locationHintAr: 'مخفي في إطار شبكة إحصائيات المجتمع المباشرة.',
  },
  'flag-announcements-press': {
    id: 'flag-announcements-press',
    nameEn: 'Press Dispatch Stamp',
    nameAr: 'طابع البيانات الرسمية',
    locationHintEn: 'Stamped discreetly in the official dispatches header.',
    locationHintAr: 'مطبوع بهدوء في ترويسة البيانات الرسمية.',
  },
  'flag-codex-scroll': {
    id: 'flag-codex-scroll',
    nameEn: 'Scribe’s Archival Footnote',
    nameAr: 'حاشية السجل الإرشادي',
    locationHintEn: 'Hidden quietly inside the guidebook codex library.',
    locationHintAr: 'مخفي برقة داخل مكتبة دليل الموقع.',
  },
  'flag-footer-archive': {
    id: 'flag-footer-archive',
    nameEn: 'Subterranean Archival Mark',
    nameAr: 'طابع الأرشيف السفلي',
    locationHintEn: 'Anchored discreetly into the bottom footer archival seal.',
    locationHintAr: 'راسٍ في تذييل الأرشيف أسفل الموقع.',
  },
};
