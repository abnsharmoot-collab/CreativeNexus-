import { LevelProgression } from '../types/progression';

/**
 * XP rewards configuration for progression actions
 */
export const XP_CONFIG = {
  PACK_OPEN: 50,
  NEW_CARD_DISCOVERED: 100,
  DAILY_CLAIM: 30,
  BADGE_UNLOCKED: 150,
};

/**
 * Cumulative XP required to reach a specific level (1-indexed).
 * Level 1 starts at 0 XP.
 * Level 2 requires 200 XP.
 * Level 3 requires 500 XP.
 * Level 4 requires 900 XP.
 */
export function getCumulativeXpForLevel(level: number): number {
  if (level <= 1) return 0;
  // Sum of (100 * (i + 1)) for i = 1 to level - 1
  return (100 * (level - 1) * (level + 2)) / 2;
}

/**
 * XP required to go from `level` to `level + 1`.
 */
export function getXpRequiredForNextLevel(level: number): number {
  const safeLevel = Math.max(1, Math.floor(level));
  return 100 * (safeLevel + 1);
}

/**
 * Dynamically calculate level, XP progress, and percentages from total XP.
 * Safe against negative numbers and arbitrary integers.
 */
export function calculateLevelProgression(rawXp: number): LevelProgression {
  const currentXp = Math.max(0, Math.floor(rawXp || 0));

  // Determine current level by stepping or quadratic inverse
  let level = 1;
  while (getCumulativeXpForLevel(level + 1) <= currentXp) {
    level++;
    if (level >= 999) break; // sanity bound
  }

  const currentLevelStartExp = getCumulativeXpForLevel(level);
  const nextLevelRequiredExp = getCumulativeXpForLevel(level + 1);
  const xpNeededForNextLevel = nextLevelRequiredExp - currentLevelStartExp;
  const xpIntoLevel = Math.max(0, currentXp - currentLevelStartExp);
  const progressPercent = xpNeededForNextLevel > 0
    ? Math.min(100, Math.max(0, Math.round((xpIntoLevel / xpNeededForNextLevel) * 100)))
    : 100;

  return {
    level,
    currentXp,
    currentLevelStartExp,
    nextLevelRequiredExp,
    xpIntoLevel,
    xpNeededForNextLevel,
    progressPercent,
  };
}

/**
 * Extensible Level Rewards Foundation
 */
export interface LevelReward {
  level: number;
  titleId?: string;
  badgeId?: string;
  coinsBonus?: number;
  cosmeticReward?: string;
  description: string;
  descriptionAr: string;
}

export const LEVEL_REWARDS: LevelReward[] = [
  { level: 2, coinsBonus: 25, description: 'Starter Vault Grant: +25 Coins', descriptionAr: 'منحة البداية: +25 عملة' },
  { level: 5, coinsBonus: 50, titleId: 'RELIC_COLLECTOR', description: 'Level 5 Honor: Relic Collector Title + 50 Coins', descriptionAr: 'شرف المستوى 5: لقب جامع الآثار + 50 عملة' },
  { level: 10, coinsBonus: 100, badgeId: 'MASTER_COLLECTOR', titleId: 'MASTER_COLLECTOR', description: 'Master Collector Milestone: 100 Coins & Master Title', descriptionAr: 'إنجاز سيد المقتنيات: 100 عملة ولقب فخري' },
  { level: 15, coinsBonus: 150, description: 'Veteran Archive Stature: +150 Coins', descriptionAr: 'مكانة الأرشيف المتقدم: +150 عملة' },
  { level: 20, coinsBonus: 250, titleId: 'SOVEREIGN_CHRONICLER', description: 'Apex Sovereign Milestone: Sovereign Chronicler Title + 250 Coins', descriptionAr: 'إنجاز السيادة العظمى: لقب مؤرخ السيادة + 250 عملة' },
];
