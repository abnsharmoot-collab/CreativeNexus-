// Modern Ultra-Premium Creative Card & Pack Artwork Assets
import packCommonApex from './images/pack_common_apex_1790930925971.jpg';
import packUncommonPrism from './images/pack_uncommon_prism_1790930937753.jpg';
import packRareAzure from './images/pack_rare_azure_1790930951669.jpg';
import packEpicHyperion from './images/pack_epic_hyperion_1790930972693.jpg';
import packLegendarySovereign from './images/pack_legendary_sovereign_1790930990391.jpg';

import cardApexSovereign from './images/card_apex_sovereign_1790931003409.jpg';
import cardAegisValkyrie from './images/card_aegis_valkyrie_1790931013805.jpg';
import cardChronoArchitect from './images/card_chrono_architect_1790931027063.jpg';
import cardAstralEmpress from './images/card_astral_empress_1790931039781.jpg';
import cardShadowOperative from './images/card_shadow_operative_1790931052024.jpg';

export const MODERN_CARD_ASSETS = {
  // Booster Packs
  packCommonApex,
  packUncommonPrism,
  packRareAzure,
  packEpicHyperion,
  packLegendarySovereign,

  // Signature Cards
  cardApexSovereign,
  cardAegisValkyrie,
  cardChronoArchitect,
  cardAstralEmpress,
  cardShadowOperative
};
