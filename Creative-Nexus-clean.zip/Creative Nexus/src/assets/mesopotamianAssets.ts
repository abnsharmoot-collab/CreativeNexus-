import heroBg from './images/mesopotamian_legendary_bg_1791923268946.jpg';
import mesoHeroBg from './images/mesopotamian_hero_bg_1789787787421.jpg';
import papyrusClayTexture from './images/papyrus_clay_texture_1792006845652.jpg';
import lamassuRelief from './images/meso_lamassu_relief_1789787803401.jpg';
import kingRelief from './images/meso_king_relief_1789787818475.jpg';
import eagleRelief from './images/meso_eagle_relief_1789787831630.jpg';
import palmRelief from './images/meso_palm_relief_1789787845308.jpg';
import friezeBanner from './images/meso_frieze_banner_1789787857985.jpg';
import packCommonBronze from './images/pack_common_bronze_1790928074694.jpg';
import packUncommonJade from './images/pack_uncommon_jade_1790928088611.jpg';
import packRareLapis from './images/pack_rare_lapis_1790928101634.jpg';
import packEpicAmethyst from './images/pack_epic_amethyst_1790928113353.jpg';
import packLegendaryGold from './images/pack_legendary_gold_1790928127508.jpg';

export const MESOPOTAMIAN_ASSETS = {
  heroBg,
  mesoHeroBg,
  legendaryCivilizationBg: heroBg,
  papyrusClayTexture,
  lamassuRelief,
  kingRelief,
  eagleRelief,
  palmRelief,
  friezeBanner,
  packCommonBronze,
  packUncommonJade,
  packRareLapis,
  packEpicAmethyst,
  packLegendaryGold,
};
