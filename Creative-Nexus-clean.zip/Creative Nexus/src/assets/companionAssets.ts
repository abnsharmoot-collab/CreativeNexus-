import companionStage1 from './images/companion_stage1_1792010085166.jpg';
import companionStage2 from './images/companion_stage2_1792010100821.jpg';
import companionStage3 from './images/companion_stage3_1792010120955.jpg';

export const COMPANION_ASSETS = {
  companionStage1,
  companionStage2,
  companionStage3,
};
